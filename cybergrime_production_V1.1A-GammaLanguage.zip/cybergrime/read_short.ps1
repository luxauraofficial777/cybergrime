$j = Get-Content telemetry_short.json -Raw | ConvertFrom-Json
Write-Host "=== SHORT 2M Run State ==="
Write-Host "Status: $($j.Pass_Status)"
Write-Host "Instructions: $($j.Instructions_Executed)"
Write-Host "VBlanks: $($j.VBlank_Count)"
Write-Host "Crashed: $($j.Crashed)"
Write-Host "PC: $($j.Register_Dump.PC)"
Write-Host "GP: $($j.Register_Dump.gp)"
Write-Host ""
$tty = $j.TTY_Tail
Write-Host "TTY Tail (full):"
Write-Host $tty
