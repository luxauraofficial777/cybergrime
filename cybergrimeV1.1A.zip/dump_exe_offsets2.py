import struct

exe_path = "../translation/SLUSP012.06"
with open(exe_path, "rb") as f:
    data = f.read()

def file_to_ram(foff):
    return foff - 0x800 + 0x80017F00

def decode_mips(insn):
    op = (insn >> 26) & 0x3F
    rs = (insn >> 21) & 0x1F
    rt = (insn >> 16) & 0x1F
    rd = (insn >> 11) & 0x1F
    sh = (insn >> 6) & 0x1F
    fn = insn & 0x3F
    imm = insn & 0xFFFF
    simm = imm if imm < 0x8000 else imm - 0x10000
    target = insn & 0x3FFFFFF
    regs = ["zero","at","v0","v1","a0","a1","a2","a3","t0","t1","t2","t3","t4","t5","t6","t7","s0","s1","s2","s3","s4","s5","s6","s7","t8","t9","k0","k1","gp","sp","fp","ra"]
    if insn == 0: return "nop"
    if op == 0x0F: return f"lui ${regs[rt]},0x{imm:04X}"
    if op == 0x09: return f"addiu ${regs[rt]},${regs[rs]},0x{imm:04X} ({simm})"
    if op == 0x08: return f"addi ${regs[rt]},${regs[rs]},0x{imm:04X} ({simm})"
    if op == 0x23: return f"lw ${regs[rt]},0x{imm:04X}(${regs[rs]})"
    if op == 0x2B: return f"sw ${regs[rt]},0x{imm:04X}(${regs[rs]})"
    if op == 0x0C: return f"andi ${regs[rt]},${regs[rs]},0x{imm:04X}"
    if op == 0x0D: return f"ori ${regs[rt]},${regs[rs]},0x{imm:04X}"
    if op == 0x00:
        if fn == 0x21: return f"addu ${regs[rd]},${regs[rs]},${regs[rt]}"
        if fn == 0x25: return f"or ${regs[rd]},${regs[rs]},${regs[rt]}"
        if fn == 0x08: return f"jr ${regs[rs]}"
        if fn == 0x00: return f"sll ${regs[rd]},${regs[rt]},{sh}"
        if fn == 0x02: return f"srl ${regs[rd]},${regs[rt]},{sh}"
        if fn == 0x03: return f"sra ${regs[rd]},${regs[rt]},{sh}"
        if fn == 0x2A: return f"slt ${regs[rd]},${regs[rs]},${regs[rt]}"
        if fn == 0x2B: return f"sltu ${regs[rd]},${regs[rs]},${regs[rt]}"
        if fn == 0x24: return f"and ${regs[rd]},${regs[rs]},${regs[rt]}"
        if fn == 0x23: return f"subu ${regs[rd]},${regs[rs]},${regs[rt]}"
        return f"special fn=0x{fn:02X}"
    if op == 0x04: return f"beq ${regs[rs]},${regs[rt]},+{simm*4+4:#x}"
    if op == 0x05: return f"bne ${regs[rs]},${regs[rt]},+{simm*4+4:#x}"
    if op == 0x06: return f"blez ${regs[rs]},+{simm*4+4:#x}"
    if op == 0x07: return f"bgtz ${regs[rs]},+{simm*4+4:#x}"
    if op == 0x02: return f"j 0x{(target<<2):08X}"
    if op == 0x03: return f"jal 0x{(target<<2):08X}"
    if op == 0x24: return f"lbu ${regs[rt]},0x{imm:04X}(${regs[rs]})"
    if op == 0x20: return f"lb ${regs[rt]},0x{imm:04X}(${regs[rs]})"
    if op == 0x28: return f"sb ${regs[rt]},0x{imm:04X}(${regs[rs]})"
    if op == 0x29: return f"sh ${regs[rt]},0x{imm:04X}(${regs[rs]})"
    return f"op=0x{op:02X} raw=0x{insn:08X}"

def dump_at(foff, label, count=6):
    ram = file_to_ram(foff)
    print(f"--- {label} ---")
    for i in range(count):
        off = foff + i*4
        if off+4 > len(data):
            print(f"  0x{off:06X} (RAM 0x{ram+i*4:08X}): <BEYOND EOF>")
            continue
        insn = struct.unpack_from("<I", data, off)[0]
        print(f"  0x{off:06X} (RAM 0x{ram+i*4:08X}): 0x{insn:08X}  {decode_mips(insn)}")
    print()

# Tree pointer candidates
print("=== TREE POINTER CANDIDATES (lui $v0,0x800F + addiu $v0,$v0,0xF1C8) ===\n")
for foff in [0x03EBEC, 0x03EC34, 0x0571FC, 0x057244]:
    dump_at(foff, f"Tree ptr at file 0x{foff:06X}", 6)

# Offset_b mask candidates
print("=== OFFSET_B MASK CANDIDATES (andi $v0,$v0,0xFFFE) ===\n")
for foff in [0x01AFB8, 0x01C5F8, 0x07CAA4]:
    dump_at(foff, f"andi at file 0x{foff:06X}", 4)

# Tree hook candidate
print("=== TREE HOOK CANDIDATE (lw $s1,12($s4)) ===\n")
dump_at(0x03EBB8, "Tree hook at file 0x03EBB8", 8)

# All addiu with 0xF1C8
print("=== ALL addiu *,*,0xF1C8 ===\n")
pos = 0x800
while pos < len(data) - 4:
    insn = struct.unpack_from("<I", data, pos)[0]
    if (insn & 0xFFFF) == 0xF1C8 and ((insn >> 26) & 0x3F) == 0x09:
        rt = (insn >> 16) & 0x1F
        rs = (insn >> 21) & 0x1F
        regs = ["zero","at","v0","v1","a0","a1","a2","a3","t0","t1","t2","t3","t4","t5","t6","t7","s0","s1","s2","s3","s4","s5","s6","s7","t8","t9","k0","k1","gp","sp","fp","ra"]
        ram = file_to_ram(pos)
        prev = struct.unpack_from("<I", data, pos-4)[0] if pos >= 4 else 0
        print(f"  file 0x{pos:06X} (RAM 0x{ram:08X}): addiu ${regs[rt]},${regs[rs]},0xF1C8  prev=0x{prev:08X} {decode_mips(prev)}")
    pos += 4
