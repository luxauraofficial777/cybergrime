#!/usr/bin/env python3
"""
Search for all ways the game calls B0(07) Setloc:
1. addiu $t1, $zero, 7 (0x24090007) — direct function number load
2. Any instruction with immediate 7 that feeds into a jr $t2 pattern
3. Also search for the Setloc wrapper — a function that takes BCD MSF pointer in $a0
   and calls B0(07). Look for functions that load $t1=7 and jump to 0xB0.
"""
import struct

disc_path = r"C:\LuxAura\VoidWalkers_Project\DQLOSTTRANSLATION\build_staging\dq4_gold.bin"
SECTOR_SIZE = 2352
USER_SIZE = 2048
EXE_LBA = 24
HEADER = 24
LOAD_ADDR = 0x80017F00

with open(disc_path, "rb") as f:
    disc = f.read()

def read_exe_from_disc(disc, start_lba, exe_size):
    exe = bytearray()
    sectors_needed = (exe_size + USER_SIZE - 1) // USER_SIZE
    for i in range(sectors_needed):
        sec_start = (start_lba + i) * SECTOR_SIZE + HEADER
        chunk = disc[sec_start:sec_start + USER_SIZE]
        exe.extend(chunk)
    return bytes(exe[:exe_size])

exe = read_exe_from_disc(disc, EXE_LBA, 677888)

# Search for 0x24090007 (addiu $t1, $zero, 7) — B0(07) Setloc function number
pat = struct.pack("<I", 0x24090007)
idx = 0
matches = []
while True:
    idx = exe.find(pat, idx)
    if idx == -1: break
    matches.append(idx)
    idx += 1

print(f"Found {len(matches)} occurrences of addiu $t1, $zero, 7 (B0(07) Setloc):")
for m in matches:
    ram = m + LOAD_ADDR
    # Check if this is in a jr $t2 delay slot (4 bytes before should be jr $t2)
    prev_word = struct.unpack("<I", exe[m-4:m])[0] if m >= 4 else 0
    is_delay_slot = (prev_word & 0xFC1FFFFF) == 0x01400008  # jr $t2
    
    # Check if $t2 is loaded with 0xB0 nearby (within 8 bytes before)
    prev2_word = struct.unpack("<I", exe[m-8:m-4])[0] if m >= 8 else 0
    has_t2_b0 = (prev2_word & 0xFFFF) == 0x00B0 and ((prev2_word >> 26) == 0x09)
    
    ctx = exe[m-12:m+8].hex()
    print(f"  0x{ram:08X}  delay_slot={is_delay_slot} t2_b0={has_t2_b0}  ctx: {ctx}")

# Also search for the BIOS call via syscall
# In PSX, C0 functions use syscall with function number in $a0
# But B0 functions use the jr $t2 pattern

# Let's also look for functions that set up $a0 with a BCD MSF pointer
# and then call B0(07). The Setloc wrapper would:
# 1. Save $ra
# 2. Set $a0 = pointer to BCD MSF buffer
# 3. Call B0(07)
# 4. Restore $ra and return

# Search for all jr $t2 instructions (0x01400008)
pat_jr_t2 = struct.pack("<I", 0x01400008)
idx = 0
jr_t2_matches = []
while True:
    idx = exe.find(pat_jr_t2, idx)
    if idx == -1: break
    jr_t2_matches.append(idx)
    idx += 1

print(f"\nFound {len(jr_t2_matches)} occurrences of jr $t2:")
for m in jr_t2_matches:
    ram = m + LOAD_ADDR
    # Check delay slot for function number
    ds_word = struct.unpack("<I", exe[m+4:m+8])[0] if m+8 <= len(exe) else 0
    ds_imm = ds_word & 0xFFFF
    ds_op = (ds_word >> 26) & 0x3F
    func_num = ds_imm if ds_op == 0x09 else -1  # addiu
    
    # Check if $t2 is loaded with 0xB0 before
    prev_word = struct.unpack("<I", exe[m-4:m])[0] if m >= 4 else 0
    prev_imm = prev_word & 0xFFFF
    prev_op = (prev_word >> 26) & 0x3F
    has_b0 = (prev_imm == 0x00B0) and (prev_op == 0x09)
    
    if func_num == 7 or has_b0:
        print(f"  0x{ram:08X}  func={func_num}  has_b0={has_b0}  ctx: {exe[m-8:m+8].hex()}")

# Now let's search for the actual FMV seek function
# It likely loads BCD values into a buffer and calls Setloc
# Look for sb (store byte) instructions that store to $sp or $a0
# near a B0(07) call

# Search for pattern: sb $reg, offset($sp) ... (3 times for M,S,F) ... jal/jr to B0(07)
# This is complex, so let's try a different approach:
# Find all functions that contain a B0(07) call pattern

# Actually, let me search for all jal instructions and check if they target
# any address near 0x800A28F8-0x800A2900 (the B0 dispatch table area)
print("\n=== Searching for jal to 0x800A28xx range ===")
for target_page in range(0x800A2800, 0x800A2B00, 4):
    jal_target = (target_page & 0x0FFFFFFF) >> 2
    jal_insn = 0x0C000000 | jal_target
    pat = struct.pack("<I", jal_insn)
    idx = 0
    while True:
        idx = exe.find(pat, idx)
        if idx == -1: break
        ram = idx + LOAD_ADDR
        print(f"  jal 0x{target_page:08X} at 0x{ram:08X}")
        idx += 1

# Also search for j (0x08xxxxxx) to the same range
print("\n=== Searching for j to 0x800A28xx range ===")
for target_page in range(0x800A2800, 0x800A2B00, 4):
    j_target = (target_page & 0x0FFFFFFF) >> 2
    j_insn = 0x08000000 | j_target
    pat = struct.pack("<I", j_insn)
    idx = 0
    while True:
        idx = exe.find(pat, idx)
        if idx == -1: break
        ram = idx + LOAD_ADDR
        print(f"  j 0x{target_page:08X} at 0x{ram:08X}")
        idx += 1
