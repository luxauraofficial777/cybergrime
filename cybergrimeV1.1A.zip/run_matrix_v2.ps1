# PSX Matrix test with vblank-pass detection
$base = "C:\LuxAura\VoidWalkers_Project\DQLOSTTRANSLATION"
$runner = "$base\cybergrime\psx_agent_runner.exe"
$disc = "$base\build_staging\dq4_reverse_a.bin"
$profile = "frank_fmv_stub_v2"
$maxInstrs = 55000000
$jsonOut = "$base\cybergrime\telemetry_frank_fmv_stub_v2.json"

Stop-Process -Name 'duckstation-qt-x64-ReleaseLTCG' -Force -ErrorAction SilentlyContinue
Stop-Process -Name 'psx_agent_runner' -Force -ErrorAction SilentlyContinue

Write-Output "=== PSX Matrix Test v2 (vblank-pass) ==="

# Run with --vblank-pass and --verbose to detect VBlank wait loop exit
$proc = Start-Process -FilePath $runner `
    -ArgumentList $disc, $profile, $maxInstrs, $jsonOut, 180000, "--vblank-pass", "--verbose" `
    -NoNewWindow -PassThru `
    -WorkingDirectory "$base\cybergrime" `
    -RedirectStandardOutput "matrix_v2_stdout.txt" `
    -RedirectStandardError "matrix_v2_stderr.txt"

Write-Output "Process started (PID: $($proc.Id))"
$proc | Wait-Process -Timeout 180 -ErrorAction SilentlyContinue

if (-not $proc.HasExited) {
    Write-Output "Process timed out, killing..."
    $proc | Stop-Process -Force
    Start-Sleep -Seconds 2
}

Write-Output "Exit code: $($proc.ExitCode)"

# Check for telemetry
if (Test-Path $jsonOut) {
    Write-Output ""
    Write-Output "=== Telemetry JSON ==="
    $content = Get-Content $jsonOut -Raw
    Write-Output $content.Substring(0, [Math]::Min(2000, $content.Length))
} else {
    Write-Output "No telemetry JSON"
}

# Show key lines from stdout
Write-Output ""
Write-Output "=== Key stdout lines ==="
$out = Get-Content "$base\cybergrime\matrix_v2_stdout.txt" -ErrorAction SilentlyContinue
if ($out) {
    $out | Where-Object { $_ -match 'VBPASS|VBlank|STATUS|FREEZE|CRASH|BOOT|CDROM|HBD|sector|ERROR|ASSERT|FMV|stub' } | Select-Object -First 50
    Write-Output "--- Last 10 lines ---"
    $out | Select-Object -Last 10
}
