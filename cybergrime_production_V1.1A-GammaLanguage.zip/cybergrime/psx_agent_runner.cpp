// ============================================================================
// PSX AGENT RUNNER — Automated Test Harness Main Entry Point
// ============================================================================
// Replaces psx_headless.cpp for batch regression testing.
// Integrates AgentHarness with the existing cybergrime emulator.
//
// Usage:
//   psx_agent_runner.exe <disc.bin> <profile_name> [max_instrs] [json_path]
//
// The runner:
//   1. Initializes the harness with TTY pipe redirection
//   2. Loads the disc and boots the EXE (same as psx_headless)
//   3. Runs the emulation loop with freeze detection
//   4. Hooks VFS access logging into find_cd_file / cd_read
//   5. On crash/freeze/timeout: dumps full state, writes JSON telemetry
//
// Compile with -DAGENT_HARNESS_ENABLED to redirect all printf through harness.
// ============================================================================

#include "agent_harness.h"
#include "psx_test_station.h"
#include "psx_savestate.h"
#include "psx_timeline.h"
#include "psx_rewind.h"
#include "psx_gdb_stub.h"
#include "psx_lua.h"
#include "txrt_hle.h"
#include "orchestration_engine.h"
#include "instrumentation_bus.h"
#include <cstdio>
#include <cstring>
#include <cstdlib>

// Thread blob injection (defined in psx_emulator_core.cpp)
extern void load_thread_blob();
extern int get_thread_blob(uint8_t* out, int max_size);

// Timeline global (defined in psx_emulator_core.cpp)
extern PSXTimeline g_timeline;

// Rewind and GDB stub (local to runner)
static PSXRewind g_rewind;
static PSXGdbStub g_gdb;
static PSXLuaEngine g_lua;

// ── Global emulator state (same as psx_headless.cpp) ────────────────────────
static PSX_Memory mem;
static MIPS_CPU cpu;
static AgentHarness harness;

// ── VFS Hook: wraps find_cd_file to log access attempts ─────────────────────
static int hooked_find_cd_file(const char* path, uint32_t& out_lba, uint32_t& out_size) {
    int result = mem.find_cd_file(path, out_lba, out_size);
    if (g_harness && g_harness->is_active()) {
        g_harness->log_vfs(path, out_lba, out_size, result >= 0,
                          g_cpu ? g_cpu->pc : 0,
                          result >= 0 ? nullptr : "File not found in ISO9660 directory");
    }
    return result;
}

// ── VFS Hook: wraps cd_read to log sector reads ─────────────────────────────
static int hooked_cd_read(int fd, uint32_t ram_buf, int nbytes) {
    int result = mem.cd_read(fd, ram_buf, nbytes);
    if (g_harness && g_harness->is_active() && g_cpu) {
        if (fd >= 0 && fd < PSX_Memory::MAX_FDESCS && mem.fdescs[fd].in_use) {
            char id[HARNESS_RESOURCE_ID_LEN];
            snprintf(id, sizeof(id), "cdrom:%s:offset=%u",
                     mem.fdescs[fd].name, mem.fdescs[fd].offset);
            g_harness->log_vfs(id, mem.fdescs[fd].lba, nbytes,
                              result >= 0, g_cpu->pc,
                              result < 0 ? "cd_read failed" : nullptr);
        }
    }
    return result;
}

// ── CD-ROM sector read hook ──────────────────────────────────────────────────
static bool hooked_read_cd_sector(uint32_t lba, uint8_t* out) {
    bool result = mem.read_cd_sector(lba, out);
    if (g_harness && g_harness->is_active() && g_cpu) {
        g_harness->log_cdrom_read(lba, result, g_cpu->pc);
    }
    return result;
}

// ── Main ─────────────────────────────────────────────────────────────────────
int main(int argc, char* argv[]) {
    setvbuf(stdout, NULL, _IONBF, 0);
    setvbuf(stderr, NULL, _IONBF, 0);
    // Open diagnostic log — bypasses harness stdout pipe so we get output even if process is killed
    g_diaglog = fopen("diag_traps.log", "w");
    if (g_diaglog) { fprintf(g_diaglog, "=== DIAG TRAP LOG START ===\n"); fflush(g_diaglog); }
    // ── Parse arguments ──────────────────────────────────────────────────
    if (argc < 3) {
        fprintf(stderr, "Usage: psx_agent_runner.exe <disc.bin> <profile_name> [max_instrs] [json_path] [wallclock_ms]\n");
        return 2;
    }

    const char* disc = argv[1];
    const char* profile = argv[2];
    uint64_t max_instrs = 200000000;
    if (argc >= 4) max_instrs = strtoull(argv[3], nullptr, 10);

    // Default JSON path: telemetry_<profile>.json
    char json_path[512];
    if (argc >= 5) {
        strncpy(json_path, argv[4], 511);
    } else {
        snprintf(json_path, sizeof(json_path),
                 "telemetry_%s.json", profile);
    }
    json_path[511] = 0;

    uint32_t wallclock_ms = 0;
    if (argc >= 6) wallclock_ms = (uint32_t)strtoul(argv[5], nullptr, 10);

    // ── Address resolution helper ───────────────────────────────────────
    auto resolve_addr = [&](const char* token) -> uint32_t {
        uint32_t out = 0;
        if (harness.resolve_symbol(token, &out)) return out;
        // Fallback: parse as raw hex/dec
        return (uint32_t)strtoull(token, nullptr, 0);
    };

    // ── Phase 2: Triage log path ────────────────────────────────────────
    char triage_path[512];
    snprintf(triage_path, sizeof(triage_path), "emulator_triage_%s.log", profile);
    // Scan for --triage flag in remaining args
    for (int i = 6; i < argc - 1; i++) {
        if (strcmp(argv[i], "--triage") == 0) {
            strncpy(triage_path, argv[i + 1], 511);
            triage_path[511] = 0;
        }
    }

    // ── Phase 5: Breakpoint & Watchpoint CLI ─────────────────────────────
    bool bp_halt_set[16] = {false};  // which breakpoints should halt
    bool trace_from_set = false;
    uint32_t trace_from_addr = 0;
    const char* trace_to_path = nullptr;
    FILE* trace_file = nullptr;
    bool console_enabled = false;
    bool diag_pc_quit = false;
    uint32_t diag_mem_addr = 0;
    bool diag_mem_set = false;
    const char* savestate_out_path = nullptr;
    const char* loadstate_path = nullptr;
    const char* screenshot_path = nullptr;
    const char* timeline_path = nullptr;
    bool gdb_enabled = false;
    int gdb_port = 3333;
    bool rewind_enabled = false;
    const char* lua_script = nullptr;
    bool no_preload = false;  // Skip HBD pre-load, CD flags, thread blob for clean ROM testing
    const char* bios_path = nullptr;  // Path to real BIOS file (--bios <path>)

    for (int i = 6; i < argc; i++) {
        if (strcmp(argv[i], "--verbose") == 0) {
            g_verbose = true;
        } else if (strcmp(argv[i], "--no-preload") == 0) {
            no_preload = true;
            harness.tty_printf("[CONFIG] --no-preload: skipping HBD pre-load, CD flags, and thread blob injection\n");
        } else if (strcmp(argv[i], "--bios") == 0) {
            if (i + 1 >= argc) break;
            bios_path = argv[i + 1];
            harness.tty_printf("[CONFIG] --bios: loading real BIOS from %s\n", bios_path);
            i++;
        } else if (strcmp(argv[i], "--bp") == 0) {
            if (i + 1 >= argc) break;
            uint32_t bp_addr = resolve_addr(argv[i + 1]);
            cpu.add_breakpoint(bp_addr);
            i++;
        } else if (strcmp(argv[i], "--bp-halt") == 0) {
            if (i + 1 >= argc) break;
            uint32_t bp_addr = resolve_addr(argv[i + 1]);
            cpu.add_breakpoint(bp_addr);
            if (cpu.bp_count - 1 < 16) bp_halt_set[cpu.bp_count - 1] = true;
            i++;
        } else if (strcmp(argv[i], "--wp") == 0) {
            if (i + 1 >= argc) break;
            uint32_t wp_addr = resolve_addr(argv[i + 1]);
            mem.add_watchpoint(wp_addr, 0xFFFFFFFF, true, true);
            i++;
        } else if (strcmp(argv[i], "--trace-from") == 0) {
            if (i + 1 >= argc) break;
            trace_from_addr = resolve_addr(argv[i + 1]);
            trace_from_set = true;
            i++;
        } else if (strcmp(argv[i], "--trace-to") == 0) {
            if (i + 1 >= argc) break;
            trace_to_path = argv[i + 1];
            i++;
        } else if (strcmp(argv[i], "--inject") == 0) {
            if (i + 1 >= argc) break;
            harness.load_injections(argv[i + 1]);
            i++;
        } else if (strcmp(argv[i], "--symbols") == 0) {
            if (i + 1 >= argc) break;
            harness.load_symbols(argv[i + 1]);
            i++;
        } else if (strcmp(argv[i], "--monitor") == 0) {
            if (i + 1 >= argc) break;
            harness.load_monitors(argv[i + 1]);
            i++;
        } else if (strcmp(argv[i], "--console") == 0) {
            console_enabled = true;
        } else if (strcmp(argv[i], "--savestate-out") == 0) {
            if (i + 1 >= argc) break;
            savestate_out_path = argv[i + 1];
            i++;
        } else if (strcmp(argv[i], "--loadstate") == 0) {
            if (i + 1 >= argc) break;
            loadstate_path = argv[i + 1];
            i++;
        } else if (strcmp(argv[i], "--screenshot") == 0) {
            if (i + 1 >= argc) break;
            screenshot_path = argv[i + 1];
            i++;
        } else if (strcmp(argv[i], "--timeline") == 0) {
            if (i + 1 >= argc) break;
            timeline_path = argv[i + 1];
            g_timeline.enable();
            i++;
        } else if (strcmp(argv[i], "--gdb") == 0) {
            gdb_enabled = true;
            if (i + 1 < argc && argv[i + 1][0] >= '0' && argv[i + 1][0] <= '9') {
                gdb_port = atoi(argv[i + 1]);
                i++;
            }
        } else if (strcmp(argv[i], "--rewind") == 0) {
            rewind_enabled = true;
            g_rewind.enable();
        } else if (strcmp(argv[i], "--lua") == 0) {
            if (i + 1 >= argc) break;
            lua_script = argv[i + 1];
            i++;
        } else if (strcmp(argv[i], "--diag-pc") == 0) {
            if (i + 1 >= argc) break;
            uint32_t diag_pc = resolve_addr(argv[i + 1]);
            harness.queue_pc_dump(diag_pc, "CLI diag dump");
            i++;
        } else if (strcmp(argv[i], "--diag-pc-quit") == 0) {
            diag_pc_quit = true;
            harness.set_diag_pc_quit(true);
        } else if (strcmp(argv[i], "--diag-mem") == 0) {
            if (i + 1 >= argc) break;
            diag_mem_addr = resolve_addr(argv[i + 1]);
            diag_mem_set = true;
            harness.set_diag_mem_addr(diag_mem_addr);
            i++;
        } else if (strcmp(argv[i], "--psn00b-align") == 0) {
            // Map watchpoints to standard BIOS interrupt vector offsets + GTE registers
            // PSX BIOS interrupt vector table at 0x80000000-0x80000080
            // GTE register file at 0x1F801000-0x1F801020 (control registers)
            struct { uint32_t addr; const char* name; } psn00b_watches[] = {
                { 0x80000000, "BIOS_VEC_RESET" },
                { 0x80000080, "BIOS_VEC_EXCEPTION" },
                { 0x800000A0, "BIOS_VEC_A0_TABLE" },
                { 0x800000B0, "BIOS_VEC_B0_TABLE" },
                { 0x800000C0, "BIOS_VEC_C0_TABLE" },
                { 0x1F801010, "GTE_CTRL_REG" },
                { 0x1F801014, "GTE_MATRIX_A11" },
                { 0x1F801018, "GTE_MATRIX_A12" },
                { 0x1F80101C, "GTE_MATRIX_A13" },
                { 0x1F801020, "GTE_MATRIX_A21" },
                { 0x1F801030, "GTE_TRX" },
                { 0x1F801034, "GTE_TRY" },
                { 0x1F801038, "GTE_TRZ" },
                { 0x1F801040, "GTE_IR1" },
                { 0x1F801044, "GTE_IR2" },
                { 0x1F801048, "GTE_IR3" },
                { 0x1F801050, "GTE_SX" },
                { 0x1F801054, "GTE_SY" },
                { 0x1F801058, "GTE_SZ" },
                { 0x1F801060, "GTE_RGB0" },
                { 0x1F801064, "GTE_RGB1" },
                { 0x1F801068, "GTE_RGB2" },
                { 0x1F801070, "GTE_MAC0" },
                { 0x1F801074, "GTE_MAC1" },
                { 0x1F801078, "GTE_MAC2" },
                { 0x1F80107C, "GTE_MAC3" },
            };
            int n_watches = sizeof(psn00b_watches) / sizeof(psn00b_watches[0]);
            for (int w = 0; w < n_watches; w++) {
                mem.add_watchpoint(psn00b_watches[w].addr, 0xFFFFFFFF, true, true);
            }
            // Also add harness monitors on key PSn00bSDK structural addresses
            harness.add_monitor(0x80000080, 4, MONITOR_VALUE_CHANGE, 0, 0, "BIOS exception vector");
            harness.add_monitor(0x1F801010, 4, MONITOR_VALUE_CHANGE, 0, 0, "GTE control register");
            harness.add_monitor(0x1F801030, 4, MONITOR_VALUE_CHANGE, 0, 0, "GTE translation X");
            harness.add_monitor(0x1F801040, 4, MONITOR_VALUE_CHANGE, 0, 0, "GTE interpolation IR1");
            harness.tty_printf("[PSN00B] Aligned %d watchpoints to BIOS vector + GTE register layout\n", n_watches);
        } else if (strcmp(argv[i], "--huffman-trace") == 0) {
            // Active memory hook targeting text-rendering character pointer streams
            // DW7 Huffman tree root at 0x800EF1C8, decompression at 0x80073670
            // Text cache buffer pointers at 0x80120000-0x80130000 (96KB region)
            // Character pointer stream flows through $a0 (src) and $v0 (dst) in decompression
            harness.add_monitor(0x800EF1C8, 4, MONITOR_VALUE_CHANGE, 0, 0,
                                "Huffman tree root pointer");
            harness.add_monitor(0x80073670, 4, MONITOR_VALUE_CHANGE, 0, 0,
                                "Decompression function code word");
            harness.add_monitor(0x80120000, 4, MONITOR_VALUE_CHANGE, 0, 0,
                                "Text cache buffer start");
            harness.add_monitor(0x80120040, 4, MONITOR_OVERFLOW, 0, 0x00010000,
                                "Text cache buffer overflow guard (64KB)");
            harness.add_monitor(0x80130000, 4, MONITOR_VALUE_NONZERO, 0, 0,
                                "Text cache buffer end sentinel");
            // Set breakpoint at decompression entry to trace character streams
            cpu.add_breakpoint(0x80073670);
            // Also watch the second decompression function
            cpu.add_breakpoint(0x80084BF0);
            harness.tty_printf("[HUFFMAN] Active trace on decompression + text cache buffer (0x80120000-0x80130000)\n");
            harness.tty_printf("[HUFFMAN] Breakpoints at 0x80073670 and 0x80084BF0 (decompression entries)\n");
        } else if (strcmp(argv[i], "--live-instrument") == 0) {
            // Live instrumentation bus: named pipe to Python sidecar
            if (i + 1 >= argc) {
                harness.tty_printf("[INSTR] WARNING: --live-instrument requires interval argument\n");
                break;
            }
            uint64_t interval = strtoull(argv[i + 1], nullptr, 10);
            g_instr_bus = new InstrumentationBus();
            if (g_instr_bus->start("\\\\.\\pipe\\cybergrime_live", interval)) {
                harness.tty_printf("[INSTR] Live instrumentation enabled (emit every %llu instrs)\n",
                                   (unsigned long long)interval);
                // Wait for Python sidecar to connect (poll for 5 seconds max)
                harness.tty_printf("[INSTR] Waiting 5s for Python sidecar to connect...\n");
                for (int wait = 0; wait < 50; wait++) {
                    if (g_instr_bus->is_connected()) break;
                    Sleep(100);
                }
                if (g_instr_bus->is_connected()) {
                    harness.tty_printf("[INSTR] Python sidecar connected!\n");
                } else {
                    harness.tty_printf("[INSTR] WARNING: Sidecar not connected — continuing without it\n");
                }
            } else {
                harness.tty_printf("[INSTR] WARNING: Failed to start instrumentation bus\n");
                delete g_instr_bus;
                g_instr_bus = nullptr;
            }
            i++;
        } else if (strcmp(argv[i], "--render-trace") == 0) {
            // DQ4 Dialogue Renderer trace: break on GPU_cw call, indirect render
            // dispatch, and font tile table access to identify the System String Renderer
            //
            // Key addresses (DQ4 JP EXE, load=0x80017F00):
            //   0x8009F790 — GPU display setup function (6 callers)
            //   0x8009F828 — JAL to GPU_cw trampoline (sole call site)
            //   0x8009F8CC — jalr through *(0x800BF300) — indirect render dispatch
            //   0x8009F8E8 — jalr through *(gpu_ctx+0x34) — second indirect dispatch
            //   0x800A5DA0 — GPU_cw trampoline (BIOS A:0x49)
            //   0x800A4A20 — most-called function (230 calls, wrapper)
            //   0x80041CE8 — Huffman decompression
            //   0x800E95B8 — font tile base in RAM

            // Break on GPU_cw JAL call site — logs GP0 command word in $a0
            cpu.add_breakpoint(0x8009F828);
            // Break on indirect render dispatch — logs function pointer in $v0
            cpu.add_breakpoint(0x8009F8CC);
            // Break on second indirect dispatch — logs function pointer in $v0
            cpu.add_breakpoint(0x8009F8E8);
            // Break on GPU display setup entry — logs mode in $a0
            cpu.add_breakpoint(0x8009F790);
            // Break on decompression entry
            cpu.add_breakpoint(0x80041CE8);

            // Watch the function pointer at 0x800BF300 (indirect render target)
            harness.add_monitor(0x800BF300, 4, MONITOR_VALUE_CHANGE, 0, 0,
                                "Render dispatch function pointer");
            // Watch the GPU context pointer at 0x800BF2FC
            harness.add_monitor(0x800BF2FC, 4, MONITOR_VALUE_CHANGE, 0, 0,
                                "GPU context pointer");
            // Watch font tile mapping tables
            harness.add_monitor(0x800BF384, 4, MONITOR_VALUE_CHANGE, 0, 0,
                                "Font tile index table A");
            harness.add_monitor(0x800BF390, 4, MONITOR_VALUE_CHANGE, 0, 0,
                                "Font tile index table B");
            // Watch work buffer at 0x800BF304
            harness.add_monitor(0x800BF304, 4, MONITOR_VALUE_CHANGE, 0, 0,
                                "Render work buffer");

            harness.tty_printf("[RENDER] Dialogue renderer trace enabled\n");
            harness.tty_printf("[RENDER] Breakpoints: 0x8009F790 (GPU setup), 0x8009F828 (GPU_cw JAL), "
                               "0x8009F8CC (indirect dispatch), 0x8009F8E8 (2nd dispatch), 0x80041CE8 (decomp)\n");
            harness.tty_printf("[RENDER] Watchpoints: 0x800BF300 (render fptr), 0x800BF2FC (GPU ctx), "
                               "0x800BF384/0x800BF390 (font tables), 0x800BF304 (work buf)\n");
        } else if (strcmp(argv[i], "--battle-audit") == 0) {
            // Battle Integrity Audit: monitor GTE registers, CPU register file,
            // stack pointer, and sprite-rendering buffers during battle encounters.
            //
            // GTE registers (memory-mapped at 0x1F801000-0x1F80107F):
            //   0x1F801010 — GTE control register
            //   0x1F801030-0x1F801038 — Translation (TRX/TRY/TRZ)
            //   0x1F801040-0x1F801048 — Interpolation (IR1/IR2/IR3)
            //   0x1F801050-0x1F801058 — Screen (SX/SY/SZ)
            //   0x1F801060-0x1F801068 — Color (RGB0/RGB1/RGB2)
            //   0x1F801070-0x1F80107C — MAC0-MAC3 (multiply-accumulate)
            //
            // Stack safety: $sp should stay in 0x801F0000-0x80200000 range
            // Battle damage calc: typically uses multiply (mult/multu) + HI/LO
            // Sprite buffers: GPU DMA regions at 0x1F8010A0-0x1F8010F0

            bool battle_audit = true;
            (void)battle_audit;

            // GTE register monitors — track all math operation registers
            harness.add_monitor(0x1F801010, 4, MONITOR_VALUE_CHANGE, 0, 0, "GTE_CTRL");
            harness.add_monitor(0x1F801030, 4, MONITOR_VALUE_CHANGE, 0, 0, "GTE_TRX");
            harness.add_monitor(0x1F801034, 4, MONITOR_VALUE_CHANGE, 0, 0, "GTE_TRY");
            harness.add_monitor(0x1F801038, 4, MONITOR_VALUE_CHANGE, 0, 0, "GTE_TRZ");
            harness.add_monitor(0x1F801040, 4, MONITOR_VALUE_CHANGE, 0, 0, "GTE_IR1");
            harness.add_monitor(0x1F801044, 4, MONITOR_VALUE_CHANGE, 0, 0, "GTE_IR2");
            harness.add_monitor(0x1F801048, 4, MONITOR_VALUE_CHANGE, 0, 0, "GTE_IR3");
            harness.add_monitor(0x1F801050, 4, MONITOR_VALUE_CHANGE, 0, 0, "GTE_SX");
            harness.add_monitor(0x1F801054, 4, MONITOR_VALUE_CHANGE, 0, 0, "GTE_SY");
            harness.add_monitor(0x1F801058, 4, MONITOR_VALUE_CHANGE, 0, 0, "GTE_SZ");
            harness.add_monitor(0x1F801060, 4, MONITOR_VALUE_CHANGE, 0, 0, "GTE_RGB0");
            harness.add_monitor(0x1F801064, 4, MONITOR_VALUE_CHANGE, 0, 0, "GTE_RGB1");
            harness.add_monitor(0x1F801068, 4, MONITOR_VALUE_CHANGE, 0, 0, "GTE_RGB2");
            harness.add_monitor(0x1F801070, 4, MONITOR_VALUE_CHANGE, 0, 0, "GTE_MAC0");
            harness.add_monitor(0x1F801074, 4, MONITOR_VALUE_CHANGE, 0, 0, "GTE_MAC1");
            harness.add_monitor(0x1F801078, 4, MONITOR_VALUE_CHANGE, 0, 0, "GTE_MAC2");
            harness.add_monitor(0x1F80107C, 4, MONITOR_VALUE_CHANGE, 0, 0, "GTE_MAC3");

            // GPU DMA registers — sprite buffer transfer monitoring
            harness.add_monitor(0x1F8010A0, 4, MONITOR_VALUE_CHANGE, 0, 0, "DMA2_BASE (GPU)");
            harness.add_monitor(0x1F8010A4, 4, MONITOR_VALUE_CHANGE, 0, 0, "DMA2_BSIZE");
            harness.add_monitor(0x1F8010A8, 4, MONITOR_VALUE_CHANGE, 0, 0, "DMA2_CTRL");
            harness.add_monitor(0x1F8010B0, 4, MONITOR_VALUE_CHANGE, 0, 0, "DMA3_BASE (CD)");
            harness.add_monitor(0x1F8010B8, 4, MONITOR_VALUE_CHANGE, 0, 0, "DMA3_CTRL");

            // RAM watchpoints on battle-critical regions
            // Stack guard: watch for $sp going below 0x801F0000 (stack overflow)
            harness.add_monitor(0x801EFFF0, 4, MONITOR_VALUE_NONZERO, 0, 0,
                                "Stack overflow sentinel (below safe SP range)");

            // Break on COP2 (GTE) instruction execution — opcode 0x12
            // We can't directly break on opcode, but we can watch the GTE data
            // registers which change when GTE instructions execute.

            // Break on known battle function entry points (from Golden Path)
            // These are set by the Golden Path script at VBlank 3300+

            harness.tty_printf("[BATTLE] Battle Integrity Audit enabled\n");
            harness.tty_printf("[BATTLE] GTE monitors: 17 registers (CTRL, TR, IR, S, RGB, MAC)\n");
            harness.tty_printf("[BATTLE] DMA monitors: 5 channels (GPU base/size/ctrl, CD base/ctrl)\n");
            harness.tty_printf("[BATTLE] Stack guard: 0x801EFFF0 sentinel\n");
            harness.tty_printf("[BATTLE] On crash: full register file + stack frame + trace ring dump\n");
        } else if (strcmp(argv[i], "--rebuild-iso") == 0) {
            if (i + 1 >= argc) break;
            // Hook into ISO rebuild logic from a layout XML file
            // This creates a rebuild manifest that the Python iteration harness can use
            const char* layout_xml = argv[i + 1];
            i++;
            char manifest_path[512];
            snprintf(manifest_path, sizeof(manifest_path), "iso_rebuild_manifest_%s.json", profile);
            FILE* mf = fopen(manifest_path, "w");
            if (mf) {
                fprintf(mf, "{\n");
                fprintf(mf, "  \"layout_xml\": \"%s\",\n", layout_xml);
                fprintf(mf, "  \"source_disc\": \"%s\",\n", disc);
                fprintf(mf, "  \"profile\": \"%s\",\n", profile);
                fprintf(mf, "  \"exe_load_addr\": \"0x80017F00\",\n");
                fprintf(mf, "  \"exe_text_size\": 673792,\n");
                fprintf(mf, "  \"hbd_lba\": 354,\n");
                fprintf(mf, "  \"hbd_sector_count\": 155975,\n");
                fprintf(mf, "  \"dw7_preserved_lba\": 156330,\n");
                fprintf(mf, "  \"edc_ecc_required\": true,\n");
                fprintf(mf, "  \"notes\": \"Generated by --rebuild-iso for mkpsxiso/dumpsxiso pipeline\"\n");
                fprintf(mf, "}\n");
                fclose(mf);
                harness.tty_printf("[REBUILD] ISO rebuild manifest written to %s\n", manifest_path);
                harness.tty_printf("[REBUILD] Layout XML: %s\n", layout_xml);
                harness.tty_printf("[REBUILD] Use with: python iteration_harness.py --disc %s --patches <spec> --rebuild-manifest %s\n",
                       disc, manifest_path);
            } else {
                harness.tty_printf("[REBUILD] ERROR: Failed to create manifest at %s\n", manifest_path);
            }
        } else if (strcmp(argv[i], "--orchestrate") == 0) {
            g_orch.enabled = true;
            g_orch.auto_correct_enabled = true;
            g_orch.init_known_mappings();
            g_orch.init_telemetry("orchestration_telem.log");
            harness.tty_printf("[ORCH] Orchestration Engine enabled (auto-correct + telemetry + address map)\n");
        } else if (strcmp(argv[i], "--auto-correct") == 0) {
            g_orch.auto_correct_enabled = true;
            if (!g_orch.enabled) { g_orch.enabled = true; g_orch.init_known_mappings(); }
            harness.tty_printf("[ORCH] PC auto-corrector enabled\n");
        } else if (strcmp(argv[i], "--telemetry") == 0) {
            if (i + 1 >= argc) break;
            int interval = atoi(argv[i + 1]);
            if (!g_orch.enabled) { g_orch.enabled = true; g_orch.init_known_mappings(); }
            g_orch.telemetry_interval = interval;
            g_orch.init_telemetry("orchestration_telem.log");
            harness.tty_printf("[ORCH] Telemetry enabled (interval=%d)\n", interval);
            i++;
        } else if (strcmp(argv[i], "--hook") == 0) {
            if (i + 1 >= argc) break;
            char hook_spec[256];
            strncpy(hook_spec, argv[i + 1], 255); hook_spec[255] = 0;
            char* tok_pc = strtok(hook_spec, ",");
            char* tok_act = strtok(nullptr, ",");
            char* tok_val = strtok(nullptr, ",");
            char* tok_label = strtok(nullptr, ",");
            if (tok_pc && tok_act) {
                uint32_t hpc = (uint32_t)strtoul(tok_pc, nullptr, 0);
                if (!g_orch.enabled) { g_orch.enabled = true; g_orch.init_known_mappings(); }
                if (strcmp(tok_act, "redirect") == 0 && tok_val) {
                    uint32_t rval = (uint32_t)strtoul(tok_val, nullptr, 0);
                    g_orch.add_redirect(hpc, rval, tok_label ? tok_label : "cli_hook");
                    harness.tty_printf("[ORCH] Hook: redirect 0x%08X -> 0x%08X (%s)\n", hpc, rval, tok_label ? tok_label : "");
                } else if (strcmp(tok_act, "skip") == 0) {
                    g_orch.add_hook(hpc, HOOK_SKIP, tok_label ? tok_label : "cli_skip");
                    harness.tty_printf("[ORCH] Hook: skip at 0x%08X (%s)\n", hpc, tok_label ? tok_label : "");
                } else if (strcmp(tok_act, "log") == 0) {
                    g_orch.add_hook(hpc, HOOK_NONE, tok_label ? tok_label : "cli_log",
                                   HF_ENABLED | HF_PRE_EXEC | HF_LOG_REGS);
                    harness.tty_printf("[ORCH] Hook: log regs at 0x%08X (%s)\n", hpc, tok_label ? tok_label : "");
                }
            }
            i++;
        } else if (strcmp(argv[i], "--watch") == 0) {
            if (i + 1 >= argc) break;
            char watch_spec[256];
            strncpy(watch_spec, argv[i + 1], 255); watch_spec[255] = 0;
            char* tok_pc = strtok(watch_spec, ",");
            char* tok_label = strtok(nullptr, ",");
            if (tok_pc) {
                uint32_t wpc = (uint32_t)strtoul(tok_pc, nullptr, 0);
                if (!g_orch.enabled) { g_orch.enabled = true; g_orch.init_known_mappings(); }
                uint32_t mask = (0x3F << 2) | (0xF << 28);
                g_orch.add_watch(wpc, mask, tok_label ? tok_label : "cli_watch");
                harness.tty_printf("[ORCH] Watch: regs at 0x%08X (%s)\n", wpc, tok_label ? tok_label : "");
            }
            i++;
        }
    }

    // Open trace file if requested
    if (trace_to_path) {
        trace_file = fopen(trace_to_path, "w");
        if (trace_file) {
            fprintf(trace_file, "# PSX instruction trace\n");
            fprintf(trace_file, "# disc=%s profile=%s\n", disc, profile);
            fprintf(trace_file, "# columns: instr_count PC raw_instruction\n");
        }
    }

    // ── Initialize harness ───────────────────────────────────────────────
    g_harness = &harness;
    harness.set_freeze_threshold(500000000);  // 500M instrs — allow slow boot
    if (wallclock_ms > 0) harness.set_wallclock_timeout(wallclock_ms);
    harness.set_triage_path(triage_path);

    harness.begin(profile, disc, json_path, max_instrs);
    if (console_enabled) harness.enable_console(true);

    // Log breakpoints
    for (int i = 0; i < cpu.bp_count; i++) {
        harness.tty_printf("[HARNESS] Breakpoint #%d set at 0x%08X (%s)\n",
               i, cpu.breakpoints[i], bp_halt_set[i] ? "HALT" : "log");
    }
    for (int i = 0; i < mem.wp_count; i++) {
        harness.tty_printf("[HARNESS] Watchpoint #%d set at 0x%08X (read=%s write=%s)\n",
               i, mem.watchpoints[i].addr,
               mem.watchpoints[i].on_read ? "ON" : "off",
               mem.watchpoints[i].on_write ? "ON" : "off");
    }
    if (trace_from_set) harness.tty_printf("[HARNESS] Trace logging from 0x%08X\n", trace_from_addr);
    if (trace_file) harness.tty_printf("[HARNESS] Trace output to %s\n", trace_to_path);
    if (harness.pending_injections() > 0)
        harness.tty_printf("[HARNESS] %d RAM injections queued\n", harness.pending_injections());
    if (harness.active_monitors() > 0)
        harness.tty_printf("[HARNESS] %d buffer monitors active\n", harness.active_monitors());

    // ── Load disc ────────────────────────────────────────────────────────
    harness.tty_printf("[0] Disc: %s\n", disc);
    harness.tty_printf("[0] Max instructions: %llu\n", max_instrs);

    if (!mem.load_cd(disc)) {
        harness.tty_printf("FAILED to open disc: %s\n", disc);
        harness.log_error("BOOT", "Failed to open disc file", 0, 0);
        harness.end(PASS_BOOT_FAIL, cpu, mem);
        return 1;
    }
    harness.tty_printf("[2] Disc opened OK\n");

    // Load thread code blob for Direct RAM Injection
    load_thread_blob();

    // Parse ISO9660 directory
    mem.parse_iso_directory();

    // Log all ISO directory entries as VFS baseline
    if (g_harness && g_harness->is_active()) {
        for (int i = 0; i < mem.dir_entry_count; i++) {
            char id[HARNESS_RESOURCE_ID_LEN];
            snprintf(id, sizeof(id), "ISO_DIR:%s", mem.dir_entries[i].name);
            g_harness->log_vfs(id, mem.dir_entries[i].lba,
                              mem.dir_entries[i].size, true, 0, nullptr);
        }
    }

    // ── Real BIOS mode: load BIOS file, boot from 0xBFC00000 ────────────
    if (bios_path) {
        if (!mem.load_bios(bios_path)) {
            harness.tty_printf("FAILED to load BIOS: %s\n", bios_path);
            harness.log_error("BOOT", "Failed to load BIOS file", 0, 0);
            harness.end(PASS_BOOT_FAIL, cpu, mem);
            return 1;
        }
        harness.tty_printf("[2] BIOS loaded: %s (512KB) — real BIOS mode\n", bios_path);
    }

    // Auto-detect boot EXE from SYSTEM.CNF
    uint32_t exe_lba, exe_sectors;
    char exe_name[256];
    uint32_t pc = 0, dest = 0, size = 0;

    if (bios_path) {
        // Real BIOS mode: skip EXE pre-load, BIOS will load it via CD-ROM
        // Set placeholder values — the BIOS boot sequence will handle everything
        exe_lba = 0;
        exe_sectors = 0;
        exe_name[0] = 0;
        harness.tty_printf("[3] Real BIOS mode — skipping EXE pre-load (BIOS will load it)\n");
    } else {
    if (!mem.find_boot_exe(exe_lba, exe_sectors, exe_name, sizeof(exe_name))) {
        harness.tty_printf("FAILED to find boot EXE\n");
        harness.log_error("BOOT", "No boot EXE found in SYSTEM.CNF", 0, 0);
        harness.end(PASS_BOOT_FAIL, cpu, mem);
        return 1;
    }

    // Load EXE
    if (!mem.load_exe_from_cd(exe_lba, exe_sectors, pc, dest, size)) {
        harness.tty_printf("FAILED to load EXE\n");
        harness.log_error("BOOT", "Failed to load EXE from CD-ROM", 0, 0);
        harness.end(PASS_BOOT_FAIL, cpu, mem);
        return 1;
    }
    harness.tty_printf("[3] EXE loaded: %s PC=0x%08X dest=0x%08X size=0x%X\n",
                       exe_name, pc, dest, size);
    } // end else (not bios_path)

    // ── Robustness: EXE hardcoded LBA audit ──────────────────────────────
    {
        uint32_t hbd_lba = 0;
        for (int i = 0; i < mem.dir_entry_count; i++) {
            if (strstr(mem.dir_entries[i].name, "HBD1PS1D")) {
                hbd_lba = mem.dir_entries[i].lba;
                break;
            }
        }
        if (hbd_lba > 0 && g_verbose) {
            const uint32_t old_hbd_lba = 354;
            FILE* audit = fopen("exe_lba_audit.txt", "w");
            if (audit) {
                fprintf(audit, "EXE LBA audit for %s\n", disc);
                fprintf(audit, "ISO HBD LBA: %u, old expected HBD LBA: %u\n", hbd_lba, old_hbd_lba);
            }
            int unpatched_32 = 0, unpatched_imm = 0, suspicious_data = 0;
            // 32-bit exact matches
            for (uint32_t off = 0x800; off + 4 <= size; off += 4) {
                uint32_t val = mem.read32(dest + off - 0x800);
                if (val == old_hbd_lba) {
                    unpatched_32++;
                    if (audit) fprintf(audit, "0x%06X: 32-bit value == %u\n", off, old_hbd_lba);
                }
            }
            // 16-bit values
            for (uint32_t off = 0x800; off + 2 <= size; off += 2) {
                uint16_t val16 = mem.read16(dest + off - 0x800);
                if (val16 == old_hbd_lba) {
                    uint32_t instr = mem.read32(dest + (off & ~3) - 0x800);
                    uint32_t opcode = (instr >> 26) & 0x3F;
                    bool is_imm = ((off & 2) == 0 && opcode >= 0x08 && opcode <= 0x0F);
                    if (is_imm) {
                        unpatched_imm++;
                    } else {
                        suspicious_data++;
                    }
                    if (audit) {
                        fprintf(audit, "0x%06X: 16-bit value == %u (%s, opcode=0x%02X word=0x%08X)\n",
                                off, old_hbd_lba, is_imm ? "I-type imm" : "data", opcode, instr);
                    }
                }
            }
            if (audit) {
                fprintf(audit, "Summary: 32-bit=%d I-type-imm=%d suspicious-data=%d\n",
                        unpatched_32, unpatched_imm, suspicious_data);
                fclose(audit);
            }
            int total = unpatched_32 + unpatched_imm;
            harness.tty_printf("[AUDIT] HBD LBA references: 32-bit=%d I-type-imm=%d suspicious-data=%d\n",
                   unpatched_32, unpatched_imm, suspicious_data);
            if (total > 0) {
                harness.tty_printf("[AUDIT] WARNING: %d unpatched reference(s) to old HBD LBA %u found; ISO dir says HBD is at LBA %u\n",
                       total, old_hbd_lba, hbd_lba);
                harness.log_error("AUDIT", "Unpatched HBD LBA references in EXE", pc, 0);
            } else {
                harness.tty_printf("[AUDIT] OK: no obvious unpatched references to old HBD LBA %u\n", old_hbd_lba);
            }
        }
    }

    // ── HBD Pre-Load: populate RAM with HBD data using EXE pointer table ──
    // The game's CD-ROM loading thread can't start because its entry point
    // (0x800D9E80) is in zero-filled memory beyond the EXE load range.
    // We break the chicken-and-egg by pre-loading HBD data into RAM using
    // the EXE's absolute pointer table (offset 0x4184, 499 entries).
    // This populates the 0x8012xxxx-0x8013xxxx region with HBD data structures.
    // Skipped when --no-preload is set (for clean ROM base-case audit).
    if (!no_preload && !bios_path) {
        uint32_t hbd_lba = 0;
        uint32_t hbd_size = 0;
        for (int i = 0; i < mem.dir_entry_count; i++) {
            if (strstr(mem.dir_entries[i].name, "HBD1PS1D")) {
                hbd_lba = mem.dir_entries[i].lba;
                hbd_size = mem.dir_entries[i].size;
                break;
            }
        }

        if (hbd_lba > 0 && size >= 0x4184 + 499 * 8) {
            const uint32_t ABS_TABLE_OFFSET = 0x4184;
            const int ABS_TABLE_ENTRIES = 499;
            uint32_t exe_base = dest;
            int loaded = 0, skipped = 0, failed = 0;

            harness.tty_printf("[PRELOAD] HBD at LBA=%u. Pointer table at EXE offset 0x4184 (RAM 0x%08X)\n",
                               hbd_lba, exe_base + ABS_TABLE_OFFSET);

            for (int i = 0; i < ABS_TABLE_ENTRIES; i++) {
                uint32_t table_addr = exe_base + ABS_TABLE_OFFSET + i * 8;
                uint32_t hbd_sector = mem.read32(table_addr);
                uint32_t ram_addr = mem.read32(table_addr + 4);

                if (hbd_sector == 0 || ram_addr == 0) { skipped++; continue; }
                if (ram_addr < 0x80000000 || ram_addr >= 0x80200000) { skipped++; continue; }
                if (ram_addr >= exe_base && ram_addr < exe_base + size) { skipped++; continue; }

                uint32_t disc_lba = hbd_lba + hbd_sector;
                uint8_t sector_buf[2048];
                if (mem.read_cd_sector(disc_lba, sector_buf)) {
                    for (int b = 0; b < 2048 && ram_addr + b < 0x80200000; b++) {
                        mem.write8(ram_addr + b, sector_buf[b]);
                    }
                    loaded++;
                    if (loaded <= 5 || loaded % 100 == 0) {
                        harness.tty_printf("[PRELOAD] Entry %d: HBD sector %u -> RAM 0x%08X (disc LBA %u)\n",
                                           i, hbd_sector, ram_addr, disc_lba);
                    }
                } else {
                    failed++;
                    if (failed <= 3) {
                        harness.tty_printf("[PRELOAD] Entry %d: FAILED sector %u (disc LBA %u)\n",
                                           i, hbd_sector, disc_lba);
                    }
                }
            }
            harness.tty_printf("[PRELOAD] Done: %d loaded, %d skipped, %d failed\n", loaded, skipped, failed);

            // Check if thread entry is now populated
            uint32_t thread_entry = 0x800D9E80;
            uint32_t val = mem.read32(thread_entry);
            harness.tty_printf("[PRELOAD] Thread entry 0x%08X = 0x%08X %s\n",
                               thread_entry, val, (val != 0) ? "POPULATED" : "STILL ZERO");

            // Also check what's at 0x8012F3D0 (first pointer table target)
            uint32_t data_val = mem.read32(0x8012F3D0);
            harness.tty_printf("[PRELOAD] Data at 0x8012F3D0 = 0x%08X %s\n",
                               data_val, (data_val != 0) ? "POPULATED" : "ZERO");
        } else {
            harness.tty_printf("[PRELOAD] Skipped: HBD LBA=%u, EXE size=0x%X\n", hbd_lba, size);
        }
    } // end if (!no_preload) — HBD pre-load

    // ── CD Status Flags Pre-set: Set CD-ready flags before game starts ──
    // The game's main thread checks CD status flags before it will call
    // ChangeTh(1) to start the CD loading thread. Without these flags,
    // the game loops forever in VBlank waiting for CD to be "ready".
    // Skipped when --no-preload is set or real BIOS is loaded.
    if (!no_preload && !bios_path) {
        mem.write8(0x800B9164, 2);   // CD status: motor on
        mem.write8(0x800B91CC, 1);   // CD init done
        mem.write8(0x800B91CE, 1);   // CD ready
        harness.tty_printf("[PRELOAD] CD status flags set: 0x800B9164=2, 0x800B91CC=1, 0x800B91CE=1\n");
    }

    // ── Thread Code Preload: Inject extracted thread blob at 0x800D9E80 ──
    // If the HBD scan found real CD-ROM loading thread code, write it into RAM
    // before the CPU starts so the game can switch to a valid thread. Otherwise
    // fall back to the bubble gum stub that just returns to the main thread.
    // Skipped when --no-preload is set or real BIOS is loaded.
    if (!no_preload && !bios_path) {
        uint8_t blob[2048];
        int blob_size = get_thread_blob(blob, sizeof(blob));
        const uint32_t THREAD_ENTRY = 0x800D9E80;

        if (blob_size > 0) {
            for (int i = 0; i < blob_size; i++) {
                mem.write8(THREAD_ENTRY + i, blob[i]);
            }
            uint32_t verify = mem.read32(THREAD_ENTRY);
            harness.tty_printf("[PRELOAD] Thread code blob injected at 0x%08X: %d bytes, [0]=0x%08X\n",
                               THREAD_ENTRY, blob_size, verify);
        } else {
            // MIPS stub: set CD-ready flags at 0x800B91CC/91CE/9164, then
            // call ChangeTh(0) via BIOS B-table (0xB0) to return to main thread.
            // Must use lui+ori+addu for addresses >0x7FFF offset (MIPS sb
            // uses signed 16-bit offset, so 0x91CC would be negative).
            //   lui   $t0, 0x800B         ; t0 = 0x800B0000
            //   ori   $t1, $zero, 0x91CC  ; t1 = 0x91CC
            //   addu  $t0, $t0, $t1       ; t0 = 0x800B91CC
            //   addiu $t1, $zero, 1       ; t1 = 1
            //   sb    $t1, 0($t0)         ; *(0x800B91CC) = 1 (CD init done)
            //   sb    $t1, 2($t0)         ; *(0x800B91CE) = 1 (CD ready)
            //   addiu $t1, $zero, 2       ; t1 = 2
            //   sb    $t1, -0x68($t0)     ; *(0x800B9164) = 2 (CD status)
            //   addiu $a0, $zero, 0       ; a0 = 0 (thread 0 = main)
            //   addiu $t1, $zero, 0x10    ; t1 = ChangeTh function number
            //   addiu $t2, $zero, 0xB0    ; t2 = 0xB0 (BIOS B-table)
            //   jr    $t2                 ; jump to BIOS
            //   nop                       ; delay slot
            static const uint32_t thread_stub[] = {
                0x3C08800B,  // lui   $t0, 0x800B
                0x340991CC,  // ori   $t1, $zero, 0x91CC
                0x01094020,  // addu  $t0, $t0, $t1       -> t0 = 0x800B91CC
                0x24090001,  // addiu $t1, $zero, 1
                0xA1020000,  // sb    $t1, 0($t0)         -> *0x800B91CC = 1
                0xA1020002,  // sb    $t1, 2($t0)         -> *0x800B91CE = 1
                0x24090002,  // addiu $t1, $zero, 2
                0xA109FF98,  // sb    $t1, -0x68($t0)     -> *0x800B9164 = 2
                0x24040000,  // addiu $a0, $zero, 0       -> a0 = 0
                0x24090010,  // addiu $t1, $zero, 0x10    -> t1 = ChangeTh
                0x240A00B0,  // addiu $t2, $zero, 0xB0    -> t2 = BIOS B-table
                0x01400008,  // jr    $t2                 -> jump to 0xB0
                0x00000000,  // nop                       -> delay slot
            };
            const int STUB_WORDS = sizeof(thread_stub) / sizeof(thread_stub[0]);
            for (int i = 0; i < STUB_WORDS; i++) {
                mem.write32(THREAD_ENTRY + i * 4, thread_stub[i]);
            }
            uint32_t verify = mem.read32(THREAD_ENTRY);
            harness.tty_printf("[BUBBLEGUM] Fallback stub injected at 0x%08X: %d instructions (%d bytes)\n",
                               THREAD_ENTRY, STUB_WORDS, STUB_WORDS * 4);
            harness.tty_printf("[BUBBLEGUM] Verify: [0]=0x%08X (expected 0x3C08800B) %s\n",
                               verify, (verify == 0x3C08800B) ? "OK" : "FAIL");
        }
    } // end if (!no_preload) — thread blob

    // ── TXRT HLE: Load translation payload for Huffman bypass ──────────────
    // The DW7 global Huffman tree at 0x800EF1C8 is incompatible with DQ4
    // per-block trees. The TXRT HLE system intercepts at the decompression
    // function entry (0x80073670) and injects pre-decoded text directly,
    // completely bypassing the Huffman tree.
    {
        const char* txrt_path = "C:\\LuxAura\\VoidWalkers_Project\\DQLOSTTRANSLATION\\translation-tools\\txrt_payload.bin";
        // Check if payload exists
        FILE* test = fopen(txrt_path, "rb");
        if (test) {
            fclose(test);
            if (txrt_load(txrt_path)) {
                txrt_set_mode(BYPASS_PRE_DECOMP);
                harness.tty_printf("[TXRT] Payload loaded — mode: PRE-DECOMP (surgical bypass)\n");
            } else {
                harness.tty_printf("[TXRT] Payload load failed — bypass disabled\n");
            }
        } else {
            harness.tty_printf("[TXRT] Payload not found at %s — Huffman bypass disabled\n", txrt_path);
            harness.tty_printf("[TXRT] Run: python translation-tools/build_txrt_payload.py\n");
        }
    }

    // ── Setup CPU (same as psx_headless.cpp) ─────────────────────────────
    cpu.read32 = cb_read32; cpu.read16 = cb_read16; cpu.read8 = cb_read8;
    cpu.write32 = cb_write32; cpu.write16 = cb_write16; cpu.write8 = cb_write8;
    cpu.mem_ctx = &mem;
    g_mem = &mem;
    g_cpu = &cpu;
    if (bios_path) {
        // Real BIOS boot: start at 0xBFC00000 (BIOS reset vector)
        cpu.pc = 0xBFC00000;
        cpu.next_pc = 0xBFC00004;
        cpu.set_reg(29, 0x801FFF00);
        cpu.set_reg(28, 0x00000000);
        cpu.set_reg(31, 0x00000000);
        // Real BIOS initializes its own event system, interrupts, etc.
        // Don't init HLE events — the BIOS will do it via syscall tables
        // Enable VBlank interrupt in INTC mask (BIOS will configure this itself)
        mem.intc_mask = 0x01;
        // CP0 Status: master interrupt enable, kernel mode
        cpu.cp0_status = 0x00000000;
    } else {
        cpu.pc = pc;
        cpu.next_pc = pc + 4;
        cpu.set_reg(29, mem.exe_init_sp ? mem.exe_init_sp : 0x801FFF00);
        cpu.set_reg(28, mem.exe_init_gp ? mem.exe_init_gp : 0x800BC668);
        cpu.set_reg(31, 0x00000000);
        // Initialize HLE BIOS event system
        mem.init_events();
        mem.intc_mask = 0x01;
        cpu.cp0_status = 0x40000101;
    }

    // ── Load state (if specified) ────────────────────────────────────────
    if (loadstate_path) {
        struct { uint32_t pc, hi, lo, cp0_status, cp0_cause, cp0_epc; uint32_t regs[32]; } cpu_snap;
        uint64_t ss_instr = 0, ss_vblank = 0;
        if (PSXSaveState::load(loadstate_path,
                &cpu_snap, sizeof(cpu_snap),
                mem.ram, mem.RAM_SIZE,
                mem.bios, (uint32_t)sizeof(mem.bios),
                mem.scratch, (uint32_t)sizeof(mem.scratch),
                nullptr, 0,
                &mem.gte, sizeof(mem.gte),
                mem.vram, (uint32_t)sizeof(mem.vram),
                nullptr, 0, nullptr, 0, nullptr, 0,
                &ss_instr, &ss_vblank)) {
            cpu.pc = cpu_snap.pc; cpu.next_pc = cpu_snap.pc + 4;
            cpu.hi = cpu_snap.hi; cpu.lo = cpu_snap.lo;
            cpu.cp0_status = cpu_snap.cp0_status; cpu.cp0_cause = cpu_snap.cp0_cause; cpu.cp0_epc = cpu_snap.cp0_epc;
            for (int r = 0; r < 32; r++) cpu.set_reg(r, cpu_snap.regs[r]);
            cpu.instructions = ss_instr;
            mem.vblank_counter = (uint32_t)ss_vblank;
            mem.fb_dirty = true;
            harness.tty_printf("[LOADSTATE] Loaded %s (instr=%llu vblank=%d PC=0x%08X)\n",
                   loadstate_path, (unsigned long long)ss_instr, (int)ss_vblank, cpu.pc);
        } else {
            harness.tty_printf("[LOADSTATE] FAILED to load %s — continuing from boot\n", loadstate_path);
        }
    }

    harness.tty_printf("[5] C++ HLE exception handler active (HookEntryInt dispatch)\n");
    cpu.log_enabled = false;
    harness.tty_printf("[6] Running emulation...\n\n");

    // ── GDB stub startup ─────────────────────────────────────────────────
    if (gdb_enabled) {
        g_gdb.read_reg = [](uint32_t idx) -> uint32_t {
            if (idx < 32) return cpu.get_reg(idx);
            if (idx == 32) return cpu.cp0_status;
            if (idx == 33) return cpu.lo;
            if (idx == 34) return cpu.hi;
            if (idx == 35) return 0;  // badvaddr
            if (idx == 36) return cpu.cp0_cause;
            if (idx == 37) return cpu.pc;
            return 0;
        };
        g_gdb.write_reg = [](uint32_t idx, uint32_t val) {
            if (idx < 32) cpu.set_reg(idx, val);
            else if (idx == 32) cpu.cp0_status = val;
            else if (idx == 33) cpu.lo = val;
            else if (idx == 34) cpu.hi = val;
            else if (idx == 37) { cpu.pc = val; cpu.next_pc = val + 4; }
        };
        g_gdb.read_mem = [](uint32_t addr, uint32_t len) -> std::vector<uint8_t> {
            std::vector<uint8_t> data(len);
            for (uint32_t i = 0; i < len; i++)
                data[i] = mem.read8(addr + i);
            return data;
        };
        g_gdb.write_mem = [](uint32_t addr, const uint8_t* data, uint32_t len) {
            for (uint32_t i = 0; i < len; i++)
                mem.write8(addr + i, data[i]);
        };
        g_gdb.get_pc = []() -> uint32_t { return cpu.pc; };
        g_gdb.set_pc = [](uint32_t pc) { cpu.pc = pc; cpu.next_pc = pc + 4; };
        g_gdb.add_breakpoint = [](uint32_t addr) { cpu.add_breakpoint(addr); };
        g_gdb.remove_breakpoint = [](uint32_t addr) { cpu.remove_breakpoint(addr); };
        g_gdb.start(gdb_port);
    }

    // ── Lua script setup ─────────────────────────────────────────────────
    if (lua_script) {
        g_lua.read8 = [](uint32_t addr) -> uint8_t { return mem.read8(addr); };
        g_lua.read16 = [](uint32_t addr) -> uint16_t { return mem.read16(addr); };
        g_lua.read32 = [](uint32_t addr) -> uint32_t { return mem.read32(addr); };
        g_lua.write8 = [](uint32_t addr, uint8_t v) { mem.write8(addr, v); };
        g_lua.write16 = [](uint32_t addr, uint16_t v) { mem.write16(addr, v); };
        g_lua.write32 = [](uint32_t addr, uint32_t v) { mem.write32(addr, v); };
        g_lua.get_pc = []() -> uint32_t { return cpu.pc; };
        g_lua.get_reg = [](int idx) -> uint32_t { return cpu.get_reg(idx); };
        g_lua.set_reg = [](int idx, uint32_t v) { cpu.set_reg(idx, v); };
        g_lua.add_breakpoint = [](uint32_t addr) { cpu.add_breakpoint(addr); };
        g_lua.log_fn = [](const char* msg) { harness.tty_printf("[LUA] %s\n", msg); };

        if (g_lua.is_available()) {
            if (g_lua.load_script(lua_script)) {
                harness.tty_printf("[LUA] Script loaded: %s\n", lua_script);
            } else {
                harness.tty_printf("[LUA] Failed to load: %s — %s\n",
                    lua_script, g_lua.last_error.c_str());
            }
        } else {
            harness.tty_printf("[LUA] Lua support not compiled in (stub mode)\n");
        }
    }

    // ── Emulation Loop with Harness Hooks ────────────────────────────────
    int bios_count = 0;
    int irq_count = 0;
    uint64_t last_bios_instr = 0;
    uint64_t last_freeze_check = 0;
    uint64_t last_tty_drain = 0;
    PassStatus final_status = PASS_RUNNING;

    while (!cpu.crashed && cpu.instructions < max_instrs) {
        // ── BIOS call logging ────────────────────────────────────────────
        if (cpu.pc == 0xA0 || cpu.pc == 0xB0 || cpu.pc == 0xC0) {
            uint32_t fn = cpu.get_reg(9) & 0xFF;
            uint32_t a0 = cpu.get_reg(4), a1 = cpu.get_reg(5),
                     a2 = cpu.get_reg(6), a3 = cpu.get_reg(7);
            uint64_t gap = cpu.instructions - last_bios_instr;
            last_bios_instr = cpu.instructions;
            const char* tbl = cpu.pc == 0xA0 ? "A" : (cpu.pc == 0xB0 ? "B" : "C");
            harness.tty_printf("[BIOS] %s:0x%02X at instr #%llu (gap=%llu) $ra=0x%08X a0=0x%08X a1=0x%08X a2=0x%08X a3=0x%08X\n",
                   tbl, fn, cpu.instructions, gap, cpu.get_reg(31), a0, a1, a2, a3);
            bios_count++;

            // ── Phase 2: Log BIOS call for triage ────────────────────────
            harness.log_bios_call(tbl[0], (uint8_t)fn, cpu.get_reg(31),
                                  a0, a1, a2, a3, cpu.instructions);
            g_timeline.record_bios_call(cpu.instructions, cpu.pc,
                (uint8_t)(cpu.pc == 0xA0 ? 0xA0 : (cpu.pc == 0xB0 ? 0xB0 : 0xC0)),
                (uint8_t)fn, a0, a1);

            // Lua on_bios callback
            if (lua_script) {
                g_lua.call_on_bios(tbl[0], (uint8_t)fn, a0, a1);
            }

            // ── VFS Hook: intercept file open/read BIOS calls ──────────
            if (cpu.pc == 0xA0 && fn == 0x00) {
                // A:0x00 = open(path, mode) — read path from RAM for VFS log
                char path[256];
                for (int i = 0; i < 255; i++) {
                    path[i] = (char)mem.read8(a0 + i);
                    if (path[i] == 0) break;
                }
                path[255] = 0;
                uint32_t flba, fsize;
                int found = mem.find_cd_file(path, flba, fsize);
                harness.log_vfs(path, flba, fsize, found >= 0, cpu.pc,
                              found < 0 ? "File not found in ISO9660 directory" : nullptr);
            }
            if (cpu.pc == 0xB0 && fn == 0x32) {
                // B:0x32 = open(path, mode) — same hook
                char path[256];
                for (int i = 0; i < 255; i++) {
                    path[i] = (char)mem.read8(a0 + i);
                    if (path[i] == 0) break;
                }
                path[255] = 0;
                uint32_t flba, fsize;
                int found = mem.find_cd_file(path, flba, fsize);
                harness.log_vfs(path, flba, fsize, found >= 0, cpu.pc,
                              found < 0 ? "File not found in ISO9660 directory" : nullptr);
            }
            if ((cpu.pc == 0xA0 && fn == 0x02) || (cpu.pc == 0xB0 && fn == 0x34)) {
                // read(fd, buf, nbytes) — log the read
                if (a0 >= 0 && a0 < (uint32_t)PSX_Memory::MAX_FDESCS && mem.fdescs[a0].in_use) {
                    char id[HARNESS_RESOURCE_ID_LEN];
                    snprintf(id, sizeof(id), "read:fd=%d:%s:offset=%u",
                             a0, mem.fdescs[a0].name, mem.fdescs[a0].offset);
                    harness.log_vfs(id, mem.fdescs[a0].lba, a2, true, cpu.pc, nullptr);
                }
            }
        }

        // ── VBlank IRQ logging ───────────────────────────────────────────
        if (cpu.pc == 0x80000080) {
            irq_count++;
            if (irq_count <= 10 || irq_count % 100 == 0) {
                harness.tty_printf("[IRQ] VBlank #%d at instr #%llu EPC=0x%08X SR=0x%08X\n",
                       irq_count, cpu.instructions, cpu.cp0_epc, cpu.cp0_status);
            }
            // ── Phase 1: Notify harness of VBlank delivery ──────────────
            harness.notify_vblank(cpu.instructions);
            g_timeline.record_vblank(cpu.instructions, irq_count);
            g_timeline.record_irq(cpu.instructions, cpu.cp0_epc, 0);

            // Lua on_vblank callback
            if (lua_script) {
                g_lua.call_on_vblank(cpu.instructions);
            }
        }

        // ── Phase 11: Interactive console tick ─────────────────────────────
        if (cpu.instructions % 1000 == 0) {
            // GDB stub poll
            if (gdb_enabled) {
                g_gdb.poll();
            }
            // Rewind snapshot
            if (rewind_enabled && g_rewind.should_snapshot(cpu.instructions)) {
                auto read_mem_fn = [](uint32_t addr, uint8_t* buf, uint32_t len) {
                    for (uint32_t i = 0; i < len; i++)
                        buf[i] = mem.read8(addr + i);
                };
                g_rewind.snapshot(cpu.instructions, cpu.pc, cpu.next_pc,
                    cpu.hi, cpu.lo, cpu.cp0_status, cpu.cp0_cause, cpu.cp0_epc,
                    cpu.regs, mem.vblank_counter, read_mem_fn);
            }
            if (!harness.process_console(cpu, mem)) {
                final_status = PASS_CRASH;
                break;
            }
        }

        // If paused, spin unless a single step is requested
        if (harness.is_paused()) {
            if (harness.diag_dump_quit_requested()) {
                final_status = PASS_CRASH;
                break;
            }
            if (!harness.consume_step()) {
                Sleep(1);
                continue;
            }
        }

        // ── Phase 9b: Diagnostic PC dump before step ────────────────────────
        // Fires when PC is about to execute the target address, capturing state
        // before the instruction runs. This lets us inspect the call leading to a crash.
        harness.check_pc_dump_before_step(cpu, mem, cpu.instructions);
        if (harness.diag_dump_quit_requested()) {
            final_status = PASS_CRASH;
            break;
        }

        // ── Step the CPU ─────────────────────────────────────────────────
        if (!cpu.step()) break;

        // ── Live instrumentation bus tick ─────────────────────────────────
        if (g_instr_bus && g_instr_bus->is_enabled()) {
            g_instr_bus->tick(cpu.instructions, cpu.pc, cpu, mem);
        }

        // ── Phase 5: Breakpoint hit detection ─────────────────────────────
        if (cpu.hit_breakpoint) {
            cpu.hit_breakpoint = false;
            // Find which breakpoint was hit
            int bp_idx = -1;
            for (int i = 0; i < cpu.bp_count; i++) {
                if (cpu.breakpoints[i] == cpu.pc) { bp_idx = i; break; }
            }
            harness.tty_printf("[BP] Hit breakpoint #%d at 0x%08X instr #%llu $v0=0x%08X $a0=0x%08X $ra=0x%08X\n",
                   bp_idx, cpu.pc, cpu.instructions,
                   cpu.get_reg(2), cpu.get_reg(4), cpu.get_reg(31));

            // Notify instrumentation bus of breakpoint hit
            if (g_instr_bus && g_instr_bus->is_enabled()) {
                g_instr_bus->on_breakpoint(cpu.pc, cpu.instructions, cpu, mem);
            }
            // Enhanced logging for render-trace breakpoints
            if (cpu.pc == 0x8009F828) {
                harness.tty_printf("[RENDER] GPU_cw JAL: $a0=0x%08X (GPU ctx), $v0=0x%08X (GP0 cmd word)\n",
                       cpu.get_reg(4), cpu.get_reg(2));
            } else if (cpu.pc == 0x8009F8CC) {
                harness.tty_printf("[RENDER] Indirect dispatch: $v0=0x%08X (render fptr), $a0=0x%08X, $a1=0x%08X (mode=%d)\n",
                       cpu.get_reg(2), cpu.get_reg(4), cpu.get_reg(5), cpu.get_reg(5));
            } else if (cpu.pc == 0x8009F8E8) {
                harness.tty_printf("[RENDER] 2nd dispatch: $v0=0x%08X (fptr), $a0=0x%08X\n",
                       cpu.get_reg(2), cpu.get_reg(4));
            } else if (cpu.pc == 0x8009F790) {
                harness.tty_printf("[RENDER] GPU setup entry: $a0=0x%08X (mode=%d), $ra=0x%08X (caller)\n",
                       cpu.get_reg(4), cpu.get_reg(4), cpu.get_reg(31));
            } else if (cpu.pc == 0x80041CE8) {
                harness.tty_printf("[RENDER] Decompression entry: $a0=0x%08X (src), $a1=0x%08X (dst), $a2=0x%08X, $ra=0x%08X\n",
                       cpu.get_reg(4), cpu.get_reg(5), cpu.get_reg(6), cpu.get_reg(31));
            }
            if (bp_idx >= 0 && bp_halt_set[bp_idx]) {
                harness.tty_printf("[BP] HALT requested — stopping emulation\n");
                harness.log_error("BREAKPOINT", "Breakpoint halt requested", cpu.pc, cpu.instructions);
                final_status = PASS_CRASH;  // Use CRASH status for halt
                break;
            }
        }

        // ── Stall detection at 0x8009885C (event flag copy loop) ──────────
        // The game enters a copy loop at 0x80098848-0x8009885C when 0x800B679C
        // is non-zero. This loop reads the BIOS event table from RAM, which our
        // HLE BIOS doesn't maintain, causing an infinite spin.
        // Log the first hit and count subsequent visits to detect the stall.
        {
            static bool stall_logged = false;
            static uint64_t stall_count = 0;
            static uint64_t stall_first_instr = 0;
            if (cpu.pc == 0x8009885C) {
                stall_count++;
                if (!stall_logged) {
                    stall_logged = true;
                    stall_first_instr = cpu.instructions;
                    uint32_t evt_flag = mem.read8(0x800B679C);
                    uint32_t disp_flag = mem.read16(0x800B5312);
                    uint32_t cd_init = mem.read8(0x800B91CC);
                    uint32_t cd_ready = mem.read8(0x800B91CE);
                    harness.tty_printf("[STALL] First hit at 0x8009885C instr #%llu\n",
                           (unsigned long long)cpu.instructions);
                    harness.tty_printf("[STALL] $v1=0x%08X (event flag byte) $v0=0x%08X $ra=0x%08X $sp=0x%08X\n",
                           cpu.get_reg(3), cpu.get_reg(2), cpu.get_reg(31), cpu.get_reg(29));
                    harness.tty_printf("[STALL] 0x800B679C=%u 0x800B5312=0x%04X 0x800B91CC=%u 0x800B91CE=%u\n",
                           evt_flag, disp_flag, cd_init, cd_ready);
                    // Dump event table
                    harness.tty_printf("[STALL] Event table:\n");
                    for (int e = 0; e < 64; e++) {
                        uint32_t st = mem.events[e].status;
                        if (st != 0) {
                            harness.tty_printf("[STALL]   ev[%d]: status=%u class=0x%08X spec=0x%08X handler=0x%08X mode=0x%X\n",
                                   e, st, mem.events[e].ev_class, mem.events[e].ev_spec,
                                   mem.events[e].fhandler, mem.events[e].mode);
                        }
                    }
                }
                // Report every 100K visits
                if ((stall_count % 100000) == 0) {
                    harness.tty_printf("[STALL] 0x8009885C visited %lluK times (started at instr #%llu, now #%llu) EVT_FLAG=%u\n",
                           (unsigned long long)(stall_count / 1000),
                           (unsigned long long)stall_first_instr,
                           (unsigned long long)cpu.instructions,
                           mem.read8(0x800B679C));
                }
            }
        }

        // ── Phase 5: Watchpoint hit detection ─────────────────────────────
        for (int i = 0; i < mem.wp_count; i++) {
            if (mem.watchpoints[i].hit) {
                mem.watchpoints[i].hit = false;
                harness.tty_printf("[WP] Hit watchpoint #%d at 0x%08X instr #%llu PC=0x%08X\n",
                       i, mem.watchpoints[i].addr, cpu.instructions, cpu.pc);
            }
        }

        // ── Phase 5: Instruction trace from address ───────────────────────
        if (trace_from_set && cpu.pc == trace_from_addr) {
            // Enable trace logging from this point on
            trace_from_set = false;  // Only trigger once
            cpu.log_enabled = true;
            if (!cpu.log_file && trace_file) {
                cpu.log_file = trace_file;
            }
            harness.tty_printf("[TRACE] Trace logging enabled at 0x%08X instr #%llu\n",
                   trace_from_addr, cpu.instructions);
        }
        // Write to trace file if active
        if (trace_file && cpu.log_enabled && !trace_from_set) {
            uint32_t raw = cpu.read32(cpu.pc, cpu.mem_ctx);
            fprintf(trace_file, "%llu 0x%08X %08X\n", cpu.instructions, cpu.pc, raw);
            if (cpu.instructions % 10000 == 0) fflush(trace_file);
        }

        // ── Phase 9: Check RAM injections (every 10K instructions, or every
        // instruction while a diagnostic PC dump is pending so the exact PC is caught)
        if (cpu.instructions % 10000 == 0 || harness.has_pc_dump_pending()) {
            harness.check_injections(cpu, mem, cpu.instructions, mem.vblank_counter);
        }

        // ── Phase 10: Check buffer monitors (every 50K instructions) ──────
        if (cpu.instructions % 50000 == 0) {
            int triggers = harness.check_monitors(mem, cpu, cpu.instructions);
            if (triggers > 0) {
                harness.capture_registers(cpu);
                harness.tty_printf("[MONITOR] %d trigger(s) fired — register snapshot captured\n",
                       triggers);
            }
        }

        // ── Battle Audit: Stack overflow detection (every 10K instructions) ──
        if (cpu.instructions % 10000 == 0) {
            uint32_t sp = cpu.get_reg(29);
            // PSX user stack is typically 0x801FFF00 down to ~0x800B0000
            // EXE loads at 0x80017F00, size ~0xA5000, ends at ~0x800BCF00
            // Available stack: ~1.3MB (0x800BCF00 to 0x801FFF00)
            // If $sp goes below 0x800B0000, it's a true stack overflow into EXE code
            if (sp < 0x800B0000 && sp >= 0x80000000) {
                harness.tty_printf("[BATTLE] *** STACK OVERFLOW DETECTED *** $sp=0x%08X at instr #%llu PC=0x%08X\n",
                       sp, cpu.instructions, cpu.pc);
                harness.tty_printf("[BATTLE] Stack frame dump (256 bytes from $sp):\n");
                for (int off = 0; off < 256; off += 16) {
                    uint32_t v0 = cpu.read32(sp + off, cpu.mem_ctx);
                    uint32_t v1 = cpu.read32(sp + off + 4, cpu.mem_ctx);
                    uint32_t v2 = cpu.read32(sp + off + 8, cpu.mem_ctx);
                    uint32_t v3 = cpu.read32(sp + off + 12, cpu.mem_ctx);
                    harness.tty_printf("[BATTLE]   $sp+0x%02X: 0x%08X 0x%08X 0x%08X 0x%08X\n",
                           off, v0, v1, v2, v3);
                }
                // Dump full register file
                harness.tty_printf("[BATTLE] Register file at overflow:\n");
                const char* rnames[] = {
                    "zero","at","v0","v1","a0","a1","a2","a3",
                    "t0","t1","t2","t3","t4","t5","t6","t7",
                    "s0","s1","s2","s3","s4","s5","s6","s7",
                    "t8","t9","k0","k1","gp","sp","fp","ra"
                };
                for (int r = 0; r < 32; r++) {
                    harness.tty_printf("[BATTLE]   $%s=0x%08X%s",
                           rnames[r], cpu.get_reg(r), (r % 4 == 3) ? "\n" : "  ");
                }
                harness.tty_printf("[BATTLE]   HI=0x%08X LO=0x%08X\n", cpu.hi, cpu.lo);
                harness.tty_printf("[BATTLE]   CP0_Status=0x%08X CP0_Cause=0x%08X CP0_EPC=0x%08X\n",
                       cpu.cp0_status, cpu.cp0_cause, cpu.cp0_epc);
                // Dump trace ring for crash context
                cpu.dump_trace_ring("BATTLE STACK OVERFLOW");
                harness.log_error("BATTLE_OVERFLOW",
                    "Stack overflow: $sp below safe threshold",
                    cpu.pc, cpu.instructions);
                cpu.crashed = true;
                snprintf(cpu.crash_reason, 255,
                    "STACK OVERFLOW: $sp=0x%08X at instr #%llu PC=0x%08X",
                    sp, cpu.instructions, cpu.pc);
                final_status = PASS_CRASH;
                break;
            }
        }

        // ── Battle Audit: Periodic register snapshot (every 500K instructions) ─
        if (cpu.instructions % 500000 == 0 && cpu.instructions > 0) {
            harness.tty_printf("[BATTLE] Snapshot @ instr #%llu: PC=0x%08X $sp=0x%08X $ra=0x%08X "
                   "$v0=0x%08X $a0=0x%08X HI=0x%08X LO=0x%08X VBlank=%u\n",
                   cpu.instructions, cpu.pc, cpu.get_reg(29), cpu.get_reg(31),
                   cpu.get_reg(2), cpu.get_reg(4), cpu.hi, cpu.lo, mem.vblank_counter);
        }

        // ── Freeze detection (check every 100K instructions) ─────────────
        if (cpu.instructions - last_freeze_check >= 100000) {
            last_freeze_check = cpu.instructions;
            if (harness.check_freeze(cpu.pc, cpu.instructions)) {
                const char* ft_names[] = {"NONE","PC_STUCK","TIGHT_LOOP","VBLANK_STALL"};
                FreezeType ft = harness.get_freeze_type();
                harness.tty_printf("\n[HARNESS] FREEZE DETECTED: type=%s PC=0x%08X at instr #%llu\n",
                       ft_names[(int)ft], cpu.pc, cpu.instructions);
                // ── Safe MIPS register dump on infinite loop trigger ────────
                // Capture $v0, $ra, $pc immediately per Phase 12 directive
                uint32_t v0 = cpu.get_reg(2);
                uint32_t v1 = cpu.get_reg(3);
                uint32_t ra = cpu.get_reg(31);
                uint32_t sp = cpu.get_reg(29);
                uint32_t a0 = cpu.get_reg(4);
                uint32_t a1 = cpu.get_reg(5);
                uint32_t pc = cpu.pc;
                uint32_t cp0_status = cpu.cp0_status;
                uint32_t cp0_cause = cpu.cp0_cause;
                uint32_t cp0_epc = cpu.cp0_epc;
                harness.tty_printf("[FREEZE_REGS] $v0=0x%08X $v1=0x%08X $ra=0x%08X $pc=0x%08X\n",
                       v0, v1, ra, pc);
                harness.tty_printf("[FREEZE_REGS] $a0=0x%08X $a1=0x%08X $sp=0x%08X\n",
                       a0, a1, sp);
                harness.tty_printf("[FREEZE_REGS] CP0_Status=0x%08X CP0_Cause=0x%08X CP0_EPC=0x%08X\n",
                       cp0_status, cp0_cause, cp0_epc);
                // Dump interrupt controller state for VBLANK_STALL diagnosis
                {
                    uint32_t i_stat = mem.read32(0x1F801070);
                    uint32_t i_mask = mem.read32(0x1F801074);
                    harness.tty_printf("[FREEZE_IRQ] I_STAT=0x%08X I_MASK=0x%08X VBlank_IRQs=%u vblank_ctr=%u\n",
                           i_stat, i_mask, irq_count, mem.vblank_counter);
                    harness.tty_printf("[FREEZE_IRQ] IM_bits=(Status>>8)&0xFF=0x%02X  pending=(I_STAT&I_MASK)=0x%08X\n",
                           (cp0_status >> 8) & 0xFF, i_stat & i_mask);
                }
                // Read the instruction at the freeze PC for immediate diagnosis
                uint32_t freeze_instr = cpu.read32(pc, cpu.mem_ctx);
                harness.tty_printf("[FREEZE_REGS] Instruction at PC: 0x%08X (raw=0x%08X)\n",
                       pc, freeze_instr);
                if (ft == FREEZE_TIGHT_LOOP) {
                    uint32_t loop_pcs[32];
                    int n = harness.get_loop_body(loop_pcs, 32);
                    harness.tty_printf("[HARNESS] Loop body: %d unique PCs\n", n);
                    for (int i = 0; i < n; i++) {
                        harness.tty_printf("[HARNESS]   0x%08X\n", loop_pcs[i]);
                    }
                }
                harness.log_error("FREEZE",
                    ft == FREEZE_TIGHT_LOOP ? "Tight loop — branch cycling detected" :
                    ft == FREEZE_VBLANK_STALL ? "VBlank stall — no IRQ delivery" :
                    "PC stagnation — black screen / infinite loop detected",
                    cpu.pc, cpu.instructions);
                final_status = PASS_FREEZE;
                break;
            }
        }

        // ── Wall-clock timeout check ─────────────────────────────────────
        if (harness.check_wallclock_timeout()) {
            harness.tty_printf("\n[HARNESS] WALL-CLOCK TIMEOUT exceeded\n");
            harness.log_error("TIMEOUT",
                "Wall-clock timeout exceeded — emulation too slow or hung",
                cpu.pc, cpu.instructions);
            final_status = PASS_TIMEOUT;
            break;
        }

        // ── Periodic status (every 1M instructions) ──────────────────────
        if (cpu.instructions % 1000000 == 0) {
            uint32_t vblank_counter = mem.read32(0x800B63D8);
            uint16_t display_flag = mem.read16(0x800B5312);
            uint8_t event_flag = mem.read8(0x800B679C);
            harness.tty_printf("[STATUS] instr=%llu PC=0x%08X vblank=%u | vbcnt=0x%08X disp=0x%04X evt=0x%02X\n",
                   cpu.instructions, cpu.pc, mem.vblank_counter,
                   vblank_counter, display_flag, event_flag);
            fprintf(stderr, "[STATUS] instr=%llu PC=0x%08X vblank=%u | vbcnt=0x%08X disp=0x%04X evt=0x%02X\n",
                   (unsigned long long)cpu.instructions, cpu.pc, mem.vblank_counter,
                   vblank_counter, display_flag, event_flag);
            if (g_diaglog) {
                fprintf(g_diaglog, "[STATUS] instr=%llu PC=0x%08X vblank=%u | vbcnt=0x%08X disp=0x%04X evt=0x%02X ra=0x%08X\n",
                       (unsigned long long)cpu.instructions, cpu.pc, mem.vblank_counter,
                       vblank_counter, display_flag, event_flag, cpu.get_reg(31));
                fflush(g_diaglog);
            }

            // Check for black screen indicators
            if (cpu.instructions > 5000000 && mem.vblank_counter > 5) {
                // If we've had VBlanks but display flag is still 0, likely black screen
                if (display_flag == 0 && event_flag == 0) {
                    harness.tty_printf("[HARNESS] WARNING: Display not initialized after %u VBlanks — possible black screen\n",
                           mem.vblank_counter);
                }
            }
        }

        // ── Fine-grained PC sampler (every 10K) after 26M to diagnose loop ──
        if (cpu.instructions > 26000000 && cpu.instructions % 10000 == 0) {
            fprintf(stderr, "[SAMPLE] instr=%llu PC=0x%08X ra=0x%08X sp=0x%08X v0=0x%08X v1=0x%08X a0=0x%08X\n",
                   (unsigned long long)cpu.instructions, cpu.pc,
                   cpu.get_reg(31), cpu.get_reg(29), cpu.get_reg(2), cpu.get_reg(3), cpu.get_reg(4));
            if (g_diaglog) {
                fprintf(g_diaglog, "[SAMPLE] instr=%llu PC=0x%08X ra=0x%08X sp=0x%08X v0=0x%08X v1=0x%08X a0=0x%08X\n",
                       (unsigned long long)cpu.instructions, cpu.pc,
                       cpu.get_reg(31), cpu.get_reg(29), cpu.get_reg(2), cpu.get_reg(3), cpu.get_reg(4));
                fflush(g_diaglog);
            }
        }

        // ── ra==1 corruption trap ──────────────────────────────────────
        // ra=1 matches v0=1 set by exception handler — indicates context corruption
        static bool ra_trap_fired = false;
        if (!ra_trap_fired && cpu.instructions > 26000000 &&
            cpu.get_reg(31) == 1 && cpu.pc != 0xA0 && cpu.pc != 0xB0 && cpu.pc != 0xC0) {
            ra_trap_fired = true;
            if (g_diaglog) {
                fprintf(g_diaglog, "\n[RA_TRAP] ra=1 detected at instr #%llu PC=0x%08X\n",
                       (unsigned long long)cpu.instructions, cpu.pc);
                fprintf(g_diaglog, "[RA_TRAP] Full regs:");
                for (int i = 0; i < 32; i++) {
                    if (i % 4 == 0) fprintf(g_diaglog, "\n  ");
                    fprintf(g_diaglog, "$%-2d=0x%08X ", i, cpu.get_reg(i));
                }
                fprintf(g_diaglog, "\n[RA_TRAP] epc=0x%08X cause=0x%08X status=0x%08X\n",
                       cpu.cp0_epc, cpu.cp0_cause, cpu.cp0_status);
                fflush(g_diaglog);
            }
        }

        // ── Drain TTY pipe periodically (every 100K instructions) ────────
        if (cpu.instructions - last_tty_drain >= 100000) {
            last_tty_drain = cpu.instructions;
            harness.drain_pipe();
        }

        // ── GPU Framebuffer Dump (every 25 VBlanks ~ 1 second) ──────────
        static uint32_t last_gpu_diag_vblank = 0;
        if (mem.vblank_counter > 0 && mem.vblank_counter % 25 == 0 && mem.vblank_counter != last_gpu_diag_vblank) {
            last_gpu_diag_vblank = mem.vblank_counter;
            mem.gpu_render_framebuffer();
            // GPU diagnostics: count non-zero pixels in VRAM and framebuffer
            uint64_t vram_nonzero = 0;
            for (uint32_t i = 0; i < PSX_Memory::VRAM_W * PSX_Memory::VRAM_H; i++) {
                if (mem.vram[i] != 0) vram_nonzero++;
            }
            uint64_t fb_nonzero = 0;
            for (uint32_t i = 0; i < PSX_Memory::FB_W * PSX_Memory::FB_H; i++) {
                if ((mem.framebuffer[i] & 0x00FFFFFF) != 0) fb_nonzero++;
            }
            harness.tty_printf("[GPU_DIAG] VBlank=%u GP0_cmds=%llu GP1_cmds=%llu VRAM_writes=%llu\n",
                   mem.vblank_counter, mem.gpu_gp0_cmd_total, mem.gpu_gp1_cmd_total, mem.gpu_vram_write_total);
            harness.tty_printf("[GPU_DIAG] display_enabled=%d display_start=(%u,%u) res=%ux%u\n",
                   mem.gpu_display_enabled, mem.gpu_display_start_x, mem.gpu_display_start_y,
                   mem.gpu_horiz_res, mem.gpu_vert_res);
            harness.tty_printf("[GPU_DIAG] draw_area=(%d,%d)-(%d,%d) offset=(%d,%d) DMA_dir=%u\n",
                   mem.gpu_draw_x1, mem.gpu_draw_y1, mem.gpu_draw_x2, mem.gpu_draw_y2,
                   mem.gpu_off_x, mem.gpu_off_y, mem.gpu_dma_dir);
            harness.tty_printf("[GPU_DIAG] VRAM non-zero pixels: %llu / %llu  FB non-zero: %llu / %llu\n",
                   vram_nonzero, (uint64_t)(PSX_Memory::VRAM_W * PSX_Memory::VRAM_H),
                   fb_nonzero, (uint64_t)(PSX_Memory::FB_W * PSX_Memory::FB_H));
            fprintf(stderr, "[GPU_DIAG] VBlank=%u GP0_cmds=%llu GP1_cmds=%llu VRAM_writes=%llu\n",
                   mem.vblank_counter, (unsigned long long)mem.gpu_gp0_cmd_total, (unsigned long long)mem.gpu_gp1_cmd_total, (unsigned long long)mem.gpu_vram_write_total);
            fprintf(stderr, "[GPU_DIAG] display_enabled=%d display_start=(%u,%u) res=%ux%u\n",
                   mem.gpu_display_enabled, mem.gpu_display_start_x, mem.gpu_display_start_y,
                   mem.gpu_horiz_res, mem.gpu_vert_res);
            fprintf(stderr, "[GPU_DIAG] draw_area=(%d,%d)-(%d,%d) offset=(%d,%d) DMA_dir=%u\n",
                   mem.gpu_draw_x1, mem.gpu_draw_y1, mem.gpu_draw_x2, mem.gpu_draw_y2,
                   mem.gpu_off_x, mem.gpu_off_y, mem.gpu_dma_dir);
            fprintf(stderr, "[GPU_DIAG] VRAM non-zero: %llu / %llu  FB non-zero: %llu / %llu\n",
                   (unsigned long long)vram_nonzero, (unsigned long long)(PSX_Memory::VRAM_W * PSX_Memory::VRAM_H),
                   (unsigned long long)fb_nonzero, (unsigned long long)(PSX_Memory::FB_W * PSX_Memory::FB_H));
            char bmp_path[256];
            snprintf(bmp_path, sizeof(bmp_path), "frame_vblank_%03d.bmp", mem.vblank_counter);
            FILE* bmp = fopen(bmp_path, "wb");
            if (bmp) {
                int row_size = ((PSX_Memory::FB_W * 3 + 3) / 4) * 4;
                int img_size = row_size * PSX_Memory::FB_H;
                int file_size = 54 + img_size;
                uint8_t hdr[54] = {0};
                hdr[0] = 'B'; hdr[1] = 'M';
                *(int32_t*)(hdr+2) = file_size;
                *(int32_t*)(hdr+10) = 54;
                *(int32_t*)(hdr+14) = 40;
                *(int32_t*)(hdr+18) = PSX_Memory::FB_W;
                *(int32_t*)(hdr+22) = PSX_Memory::FB_H;
                *(int16_t*)(hdr+26) = 1;
                *(int16_t*)(hdr+28) = 24;
                *(int32_t*)(hdr+34) = img_size;
                fwrite(hdr, 1, 54, bmp);
                for (int y = PSX_Memory::FB_H - 1; y >= 0; y--) {
                    for (int x = 0; x < PSX_Memory::FB_W; x++) {
                        uint32_t px = mem.framebuffer[y * PSX_Memory::FB_W + x];
                        uint8_t bgr[3] = { (uint8_t)(px & 0xFF), (uint8_t)((px>>8)&0xFF), (uint8_t)((px>>16)&0xFF) };
                        fwrite(bgr, 1, 3, bmp);
                    }
                    int pad = row_size - PSX_Memory::FB_W * 3;
                    for (int p = 0; p < pad; p++) fputc(0, bmp);
                }
                fclose(bmp);
                harness.tty_printf("[FRAME] Dumped framebuffer to %s (VBlank %u)\n", bmp_path, mem.vblank_counter);
            }
            mem.fb_dirty = false;
        }
    }

    // ── Determine final status ───────────────────────────────────────────
    if (final_status == PASS_RUNNING) {
        if (cpu.crashed) {
            final_status = PASS_CRASH;
            harness.log_error("CPU", cpu.crash_reason, cpu.pc, cpu.instructions);
        } else if (cpu.instructions >= max_instrs) {
            final_status = PASS_COMPLETE;
        }
    }

    // ── Final summary output ─────────────────────────────────────────────
    harness.tty_printf("\n[DONE] instr=%llu crashed=%d\n", cpu.instructions, cpu.crashed);
    if (cpu.crashed) harness.tty_printf("[CRASH] %s\n", cpu.crash_reason);
    harness.tty_printf("[BIOS calls total: %d]\n", bios_count);
    harness.tty_printf("[VBlank IRQs delivered: %d]\n", irq_count);

    // End-of-run GPU summary to stderr
    fprintf(stderr, "[GPU_SUMMARY] GP0_total=%llu GP1_total=%llu VRAM_writes=%llu\n",
            (unsigned long long)mem.gpu_gp0_cmd_total, (unsigned long long)mem.gpu_gp1_cmd_total,
            (unsigned long long)mem.gpu_vram_write_total);
    fprintf(stderr, "[GPU_SUMMARY] display_enabled=%d DMA_dir=%u fb_dirty=%d\n",
            mem.gpu_display_enabled, mem.gpu_dma_dir, mem.fb_dirty);
    {
        uint64_t vram_nz = 0;
        for (uint32_t i = 0; i < PSX_Memory::VRAM_W * PSX_Memory::VRAM_H; i++) {
            if (mem.vram[i] != 0) vram_nz++;
        }
        fprintf(stderr, "[GPU_SUMMARY] VRAM non-zero=%llu / %llu\n",
                (unsigned long long)vram_nz, (unsigned long long)(PSX_Memory::VRAM_W * PSX_Memory::VRAM_H));
    }
    harness.tty_printf("[VBlank counter: %u]\n", mem.vblank_counter);
    harness.tty_printf("[CP0 Status: 0x%08X  Cause: 0x%08X  EPC: 0x%08X]\n",
           cpu.cp0_status, cpu.cp0_cause, cpu.cp0_epc);

    // Full state dump
    mem.dump_full_state(cpu);

    // ── Battle Audit: Crash-time stack frame and register dump ────────
    if (cpu.crashed) {
        uint32_t sp = cpu.get_reg(29);
        harness.tty_printf("\n[BATTLE_AUDIT] === CRASH-TIME STATE DUMP ===\n");
        harness.tty_printf("[BATTLE_AUDIT] Crash reason: %s\n", cpu.crash_reason);
        harness.tty_printf("[BATTLE_AUDIT] Instruction: #%llu  PC: 0x%08X  $sp: 0x%08X  $ra: 0x%08X\n",
               cpu.instructions, cpu.pc, sp, cpu.get_reg(31));

        // Full register file dump
        const char* rnames[] = {
            "zero","at","v0","v1","a0","a1","a2","a3",
            "t0","t1","t2","t3","t4","t5","t6","t7",
            "s0","s1","s2","s3","s4","s5","s6","s7",
            "t8","t9","k0","k1","gp","sp","fp","ra"
        };
        harness.tty_printf("[BATTLE_AUDIT] Register file:\n");
        for (int r = 0; r < 32; r++) {
            harness.tty_printf("[BATTLE_AUDIT]   $%s=0x%08X%s",
                   rnames[r], cpu.get_reg(r), (r % 4 == 3) ? "\n" : "  ");
        }
        harness.tty_printf("[BATTLE_AUDIT]   HI=0x%08X LO=0x%08X\n", cpu.hi, cpu.lo);
        harness.tty_printf("[BATTLE_AUDIT]   CP0_Status=0x%08X CP0_Cause=0x%08X CP0_EPC=0x%08X\n",
               cpu.cp0_status, cpu.cp0_cause, cpu.cp0_epc);

        // Stack frame dump (512 bytes from $sp, if in valid range)
        if (sp >= 0x80000000 && sp < 0x80200000) {
            harness.tty_printf("[BATTLE_AUDIT] Stack frame (512 bytes from $sp=0x%08X):\n", sp);
            for (int off = 0; off < 512; off += 16) {
                uint32_t a = sp + off;
                if (a + 16 > 0x80200000) break;
                uint32_t v0 = cpu.read32(a, cpu.mem_ctx);
                uint32_t v1 = cpu.read32(a + 4, cpu.mem_ctx);
                uint32_t v2 = cpu.read32(a + 8, cpu.mem_ctx);
                uint32_t v3 = cpu.read32(a + 12, cpu.mem_ctx);
                harness.tty_printf("[BATTLE_AUDIT]   $sp+0x%03X: 0x%08X 0x%08X 0x%08X 0x%08X\n",
                       off, v0, v1, v2, v3);
            }
        }

        // GTE register dump (hardware registers)
        harness.tty_printf("[BATTLE_AUDIT] GTE registers:\n");
        uint32_t gte_regs[] = {0x1F801010, 0x1F801030, 0x1F801034, 0x1F801038,
                                0x1F801040, 0x1F801044, 0x1F801048,
                                0x1F801050, 0x1F801054, 0x1F801058,
                                0x1F801060, 0x1F801064, 0x1F801068,
                                0x1F801070, 0x1F801074, 0x1F801078, 0x1F80107C};
        const char* gte_names[] = {"CTRL","TRX","TRY","TRZ","IR1","IR2","IR3",
                                    "SX","SY","SZ","RGB0","RGB1","RGB2",
                                    "MAC0","MAC1","MAC2","MAC3"};
        for (int g = 0; g < 17; g++) {
            uint32_t val = mem.read32(gte_regs[g]);
            harness.tty_printf("[BATTLE_AUDIT]   GTE_%s=0x%08X\n", gte_names[g], val);
        }

        // Instruction at crash PC
        uint32_t crash_instr = cpu.read32(cpu.pc, cpu.mem_ctx);
        harness.tty_printf("[BATTLE_AUDIT] Instruction at crash PC: 0x%08X (raw=0x%08X)\n",
               cpu.pc, crash_instr);

        // DMA channel state
        harness.tty_printf("[BATTLE_AUDIT] DMA state:\n");
        uint32_t dma_regs[] = {0x1F8010A0, 0x1F8010A4, 0x1F8010A8,
                                0x1F8010B0, 0x1F8010B4, 0x1F8010B8};
        const char* dma_names[] = {"DMA2_BASE(GPU)","DMA2_BSIZE","DMA2_CTRL",
                                    "DMA3_BASE(CD)","DMA3_BSIZE","DMA3_CTRL"};
        for (int d = 0; d < 6; d++) {
            uint32_t val = mem.read32(dma_regs[d]);
            harness.tty_printf("[BATTLE_AUDIT]   %s=0x%08X\n", dma_names[d], val);
        }

        // GPU state
        harness.tty_printf("[BATTLE_AUDIT] GPU: GP0=0x%08X GP1=0x%08X display=%d vblank=%u\n",
               mem.read32(0x1F801810), mem.read32(0x1F801814),
               mem.gpu_display_enabled, mem.vblank_counter);

        // Trace ring dump for crash context
        cpu.dump_trace_ring("BATTLE_AUDIT CRASH CONTEXT");

        harness.tty_printf("[BATTLE_AUDIT] === END CRASH-TIME STATE DUMP ===\n\n");
    }

    // ── Phase 2: Write triage log on any non-COMPLETE exit ───────────────
    if (final_status != PASS_COMPLETE) {
        harness.write_triage_log(cpu, mem);
        harness.tty_printf("[HARNESS] Triage log written to %s\n", triage_path);
        // Record final event in timeline
        if (final_status == PASS_FREEZE) {
            g_timeline.record_freeze(cpu.instructions, cpu.pc, "emulation_freeze");
        } else if (final_status == PASS_CRASH) {
            g_timeline.record(PSXTimeline::EV_CUSTOM, cpu.instructions, cpu.pc,
                              0, 0, 0, "emulation_crash");
        }
    }

    // ── Timeline export ──────────────────────────────────────────────────
    if (timeline_path) {
        g_timeline.export_json(timeline_path);
        g_timeline.print_summary();
        harness.tty_printf("[TIMELINE] Exported %zu events to %s\n",
               g_timeline.events.size(), timeline_path);
    }

    // ── Rewind status ────────────────────────────────────────────────────
    if (rewind_enabled) {
        g_rewind.print_status();
    }

    // ── GDB stub cleanup ─────────────────────────────────────────────────
    if (gdb_enabled) {
        g_gdb.stop();
        harness.tty_printf("[GDB] Stub stopped\n");
    }

    // ── Save state output ────────────────────────────────────────────────
    if (savestate_out_path) {
        // Pack CPU state into a simple struct for serialization
        struct { uint32_t pc, hi, lo, cp0_status, cp0_cause, cp0_epc; uint32_t regs[32]; } cpu_snap;
        cpu_snap.pc = cpu.pc; cpu_snap.hi = cpu.hi; cpu_snap.lo = cpu.lo;
        cpu_snap.cp0_status = cpu.cp0_status; cpu_snap.cp0_cause = cpu.cp0_cause; cpu_snap.cp0_epc = cpu.cp0_epc;
        for (int r = 0; r < 32; r++) cpu_snap.regs[r] = cpu.regs[r];

        PSXSaveState::save(savestate_out_path,
            &cpu_snap, sizeof(cpu_snap),
            mem.ram, mem.RAM_SIZE,
            mem.bios, (uint32_t)sizeof(mem.bios),
            mem.scratch, (uint32_t)sizeof(mem.scratch),
            nullptr, 0,  // hw_regs (not separately stored)
            &mem.gte, sizeof(mem.gte),
            mem.vram, (uint32_t)sizeof(mem.vram),
            nullptr, 0,  // spu state
            nullptr, 0,  // cdrom state
            nullptr, 0,  // mdec state
            cpu.instructions, mem.vblank_counter, profile);
        harness.tty_printf("[SAVESTATE] Written to %s (instr=%llu vblank=%d)\n",
               savestate_out_path, (unsigned long long)cpu.instructions, mem.vblank_counter);
    }

    // ── Screenshot output ────────────────────────────────────────────────
    if (screenshot_path) {
        // Render framebuffer from VRAM and write as BMP
        mem.gpu_render_framebuffer();
        FILE* bmp = fopen(screenshot_path, "wb");
        if (bmp) {
            // BMP header (320x240, 32-bit BGRA)
            uint32_t row_size = mem.FB_W * 4;
            uint32_t img_size = row_size * mem.FB_H;
            uint32_t file_size = 54 + img_size;
            uint8_t header[54] = {};
            header[0] = 'B'; header[1] = 'M';
            *(uint32_t*)(header + 2) = file_size;
            *(uint32_t*)(header + 10) = 54;
            *(uint32_t*)(header + 14) = 40;
            *(uint32_t*)(header + 18) = mem.FB_W;
            *(uint32_t*)(header + 22) = mem.FB_H;
            *(uint16_t*)(header + 26) = 1;
            *(uint16_t*)(header + 28) = 32;
            fwrite(header, 1, 54, bmp);
            // Write pixels bottom-up (BMP format)
            for (int y = (int)mem.FB_H - 1; y >= 0; y--) {
                for (uint32_t x = 0; x < mem.FB_W; x++) {
                    uint32_t px = mem.framebuffer[y * mem.FB_W + x];
                    uint8_t bgra[4] = { (uint8_t)(px & 0xFF), (uint8_t)((px >> 8) & 0xFF),
                                        (uint8_t)((px >> 16) & 0xFF), (uint8_t)((px >> 24) & 0xFF) };
                    fwrite(bgra, 1, 4, bmp);
                }
            }
            fclose(bmp);
            harness.tty_printf("[SCREENSHOT] Written to %s (%dx%d)\n", screenshot_path, mem.FB_W, mem.FB_H);
        } else {
            harness.tty_printf("[SCREENSHOT] Failed to open %s for writing\n", screenshot_path);
        }
    }

    // ── Finalize harness ─────────────────────────────────────────────────
    harness.end(final_status, cpu, mem);

    // ── Stop instrumentation bus ─────────────────────────────────────────
    if (g_instr_bus) {
        g_instr_bus->stop();
        delete g_instr_bus;
        g_instr_bus = nullptr;
    }

    if (cpu.log_file) { fflush(cpu.log_file); cpu.close_log(); }
    if (trace_file) { fflush(trace_file); fclose(trace_file); }

    // Orchestration engine cleanup
    if (g_orch.enabled) {
        g_orch.flush_telemetry();
        g_orch.close_telemetry();
        g_orch.audit_dump("orchestration_audit.log");
        printf("[ORCH] Corrections applied: %d/%d\n", g_orch.correction_count, g_orch.max_corrections);
        printf("[ORCH] Audit entries: %d\n", g_orch.audit_count);
    }

    // Return code: 0 = pass, 1 = fail (crash/freeze/timeout)
    return (final_status == PASS_COMPLETE) ? 0 : 1;
}
