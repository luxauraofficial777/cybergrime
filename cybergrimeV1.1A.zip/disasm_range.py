import struct, sys
from disasm_bios import disasm_mips

with open(r'..\dq4_frankenstein_v100.bin', 'rb') as f:
    exe_lba = 24; sector_size = 2352; user_offset = 24; user_size = 2048; exe_sectors = 340
    f.seek(exe_lba * sector_size)
    raw = f.read(exe_sectors * sector_size)

exe_data = bytearray()
for i in range(exe_sectors):
    sector = raw[i * sector_size:(i + 1) * sector_size]
    exe_data += sector[user_offset:user_offset + user_size]

load_addr = struct.unpack_from('<I', exe_data, 0x10)[0]

start = int(sys.argv[1], 16) if len(sys.argv) > 1 else 0x800966A0
end = int(sys.argv[2], 16) if len(sys.argv) > 2 else 0x80096708

for target in range(start, end, 4):
    off = target - load_addr + 0x800
    if off + 4 <= len(exe_data):
        word = struct.unpack_from('<I', exe_data, off)[0]
        print(f'  0x{target:08X}: 0x{word:08X}  {disasm_mips(word, target)}')
    else:
        print(f'  0x{target:08X}: (outside EXE)')
