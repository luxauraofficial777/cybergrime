/* =============================================================================
 * huffman_compat_hook.c
 *
 * C implementation of the dual-layer Huffman tree compatibility shim for
 * the Heartbeat Engine (DW7 SLUS_869.16 / SLUSP012.06).
 *
 * Purpose:
 *   Provides a GCC/MIPS cross-compiler-compatible C version of the runtime
 *   parser shim. This can be compiled with `mipsel-linux-gnu-gcc -mabi=32
 *   -march=r3000` and linked into the EXE code cave, or used as a reference
 *   for hand-writing the MIPS assembly version.
 *
 * Architecture:
 *   - PSX MIPS R3000A (little-endian, 32-bit)
 *   - EXE load address: 0x80017F00
 *   - Code cave: 0x800B4C70 (after bootstrap at 0x800B4A68 + 520 bytes)
 *   - Global tree buffer: 0x800BC700 (1480 bytes, Frankenstein hybrid tree)
 *   - Extended tree buffer: 0x80100000 (safe RAM for oversized trees)
 *
 * Block Header Format (24 bytes, 6 x uint32 LE):
 *   [0]  end     [4]  block_id  [8]  hts
 *   [12] treeEnd [16] textEnd   [20] unk1
 *
 * DQ4 detection: hts == 24 AND treeEnd != 0
 * DW7 detection: hts >= 100 AND treeEnd == 0
 *
 * Tree Format (shared DQ4/DW7):
 *   2-byte LE nodes, 0x8000 branch bit, 0x7FFF index mask
 *   Dual-array: Array A at [0, offset_b), Array B at [offset_b, tree_len)
 *   offset_b = (tree_len + 2) / 2 - 2
 *   Root at tree_len - 4
 *   DQ4: root_id = (value & 0x7FFF) + 1
 *   DW7: root_id = value & 0x7FFF
 *
 * Register Preservation:
 *   All $s0-$s7 and $ra are saved/restored per MIPS o32 ABI convention.
 *   $v0 = result code, $v1 = tree size (if applicable)
 *   $a0 = block pointer (input, preserved)
 *
 * Compilation:
 *   mipsel-linux-gnu-gcc -c -mabi=32 -march=r3000 -O2 \
 *     -fno-pic -fno-builtin huffman_compat_hook.c -o huffman_compat_hook.o
 *   mipsel-linux-gnu-objcopy -O binary huffman_compat_hook.o huffman_compat_hook.bin
 *
 * Integration:
 *   The resulting .bin is raw MIPS machine code to be placed at 0x800B4C70
 *   in the EXE. The first instruction at 0x800429F0 is replaced with a
 *   jump to the trampoline entry point.
 * =============================================================================
 */

#include <stdint.h>
#include <string.h>

/* --- Constants --- */

#define BLOCK_HDR_SIZE          24
#define BLOCK_HDR_END_OFF       0
#define BLOCK_HDR_BLOCKID_OFF   4
#define BLOCK_HDR_HTS_OFF       8
#define BLOCK_HDR_TREEEND_OFF   12
#define BLOCK_HDR_TEXTEND_OFF   16
#define BLOCK_HDR_UNK_OFF       20

#define DQ4_HTS_VALUE           24
#define DW7_HTS_THRESHOLD       100

#define TREE_METADATA_SIZE      10
#define TREE_META_TSTART_OFF    0
#define TREE_META_TMIDDLE_OFF   4
#define TREE_META_TNODES_OFF    8

#define GLOBAL_TREE_BUF         0x800BC700u
#define GLOBAL_TREE_MAX_SIZE    1480
#define EXT_TREE_BUF            0x80100000u

#define BRANCH_BIT              0x8000
#define INDEX_MASK              0x7FFF

#define SHIM_OK                  0
#define SHIM_DQ4_COPIED          1
#define SHIM_ERR_INVALID        -1
#define SHIM_ERR_TREE_TOO_LARGE -2

/* --- Types --- */

typedef struct {
    uint32_t end;
    uint32_t block_id;
    uint32_t hts;
    uint32_t tree_end;
    uint32_t text_end;
    uint32_t unk1;
} __attribute__((packed)) BlockHeader;

typedef struct {
    uint32_t tree_start;
    uint32_t tree_middle;
    uint16_t tree_nodes;
} __attribute__((packed)) TreeMetadata;

/* --- Low-level memory helpers (position-independent, no libc) --- */

static inline uint32_t rd32(const uint8_t *p) {
    return (uint32_t)p[0] | ((uint32_t)p[1] << 8) |
           ((uint32_t)p[2] << 16) | ((uint32_t)p[3] << 24);
}

static inline uint16_t rd16(const uint8_t *p) {
    return (uint16_t)p[0] | ((uint16_t)p[1] << 8);
}

static inline void wr16(uint8_t *p, uint16_t v) {
    p[0] = (uint8_t)(v & 0xFF);
    p[1] = (uint8_t)((v >> 8) & 0xFF);
}

static inline void memcpy8(uint8_t *dst, const uint8_t *src, uint32_t n) {
    for (uint32_t i = 0; i < n; i++)
        dst[i] = src[i];
}

/* =============================================================================
 * huffman_shim_main
 *
 * Main entry point for the runtime compatibility shim.
 * Called via trampoline from the patched block header reader.
 *
 * Args:
 *   block_ptr - pointer to block data in RAM (first 24 bytes = header)
 *
 * Returns:
 *   SHIM_OK (0)          - DW7 native block, no action taken
 *   SHIM_DQ4_COPIED (1)  - DQ4 per-block tree copied to global buffer
 *   SHIM_ERR_INVALID (-1)- Invalid block or tree data
 * =============================================================================
 */

int32_t huffman_shim_main(const uint8_t *block_ptr) {
    if (!block_ptr)
        return SHIM_ERR_INVALID;

    /* Read block header fields */
    uint32_t hts      = rd32(block_ptr + BLOCK_HDR_HTS_OFF);
    uint32_t tree_end = rd32(block_ptr + BLOCK_HDR_TREEEND_OFF);
    uint32_t text_end = rd32(block_ptr + BLOCK_HDR_TEXTEND_OFF);
    uint32_t end      = rd32(block_ptr + BLOCK_HDR_END_OFF);

    /* Check if DQ4 format: hts == 24 AND tree_end != 0 */
    if (hts != DQ4_HTS_VALUE || tree_end == 0) {
        /* DW7 native or stripped block: use global tree, no action needed */
        return SHIM_OK;
    }

    /* Validate DQ4 tree boundaries */
    if (text_end >= tree_end || tree_end > end) {
        return SHIM_ERR_INVALID;
    }

    /* Read tree metadata (10 bytes at block + text_end) */
    const uint8_t *meta = block_ptr + text_end;
    uint32_t tree_start = rd32(meta + TREE_META_TSTART_OFF);

    /* Validate tree_start */
    if (tree_start >= tree_end || tree_start < hts) {
        return SHIM_ERR_INVALID;
    }

    /* Calculate tree size */
    uint32_t tree_size = tree_end - tree_start;

    /* Sanity check tree size */
    if (tree_size < 4 || tree_size > 65536 || (tree_size & 1)) {
        return SHIM_ERR_INVALID;
    }

    /* Determine target buffer */
    uint8_t *tree_buf;
    if (tree_size <= GLOBAL_TREE_MAX_SIZE) {
        tree_buf = (uint8_t *)GLOBAL_TREE_BUF;
    } else {
        tree_buf = (uint8_t *)EXT_TREE_BUF;
    }

    /* Copy tree bytes from block to global/extended buffer */
    const uint8_t *tree_src = block_ptr + tree_start;
    memcpy8(tree_buf, tree_src, tree_size);

    /* Convert DQ4 tree convention to DW7 convention:
     * DQ4: root_id = (value & 0x7FFF) + 1
     * DW7: root_id = value & 0x7FFF
     *
     * For all branch nodes, decrement the index by 1.
     * Leaf nodes are unchanged.
     */
    for (uint32_t i = 0; i < tree_size; i += 2) {
        uint16_t val = rd16(tree_buf + i);
        if (val & BRANCH_BIT) {
            uint16_t new_id = (val & INDEX_MASK) - 1;
            /* Guard against underflow (DQ4 IDs start at 1, so 0 is invalid) */
            if (new_id == 0xFFFF)
                return SHIM_ERR_INVALID;
            wr16(tree_buf + i, new_id | BRANCH_BIT);
        }
    }

    /* If we used the extended buffer, the 24 LUI/ADDIU tree refs in the EXE
     * still point to 0x800EF1C8. For the common case (tree <= 744), the
     * tree is in the global buffer and existing refs work automatically.
     *
     * For the extended case, a full 24-site LUI/ADDIU patch would be needed.
     * This is handled by the pre-processing layer which ensures most trees
     * are re-encoded to fit within 744 bytes. The runtime shim only handles
     * edge cases where dynamic blocks couldn't be pre-processed.
     */
    if (tree_size > GLOBAL_TREE_MAX_SIZE) {
        /* Extended buffer: patch primary decompressor tree ref.
         * The decompressor at 0x80073670 loads the tree address via a
         * LUI/ADDIU pair. We patch it to load 0x80100000 instead.
         *
         * In practice, this is a simplified single-site patch.
         * Full 24-site patching is done by the pre-processing layer.
         *
         * The LUI/ADDIU pair for the tree address is at a known location
         * relative to the decompressor entry. We search for it by scanning
         * for LUI $reg, 0x800F followed by ADDIU $reg, $reg, 0xF1C8.
         */
        uint8_t *exe_base = (uint8_t *)0x80017F00u;
        uint32_t exe_scan_end = 0x800BC700u - 0x80017F00u;

        for (uint32_t off = 0; off + 8 <= exe_scan_end; off += 4) {
            uint32_t instr1 = rd32(exe_base + off);
            uint32_t instr2 = rd32(exe_base + off + 4);

            /* Check for LUI $reg, 0x800F (opcode 0x0F, rt=any, imm=0x800F) */
            uint32_t lui_op   = (instr1 >> 26) & 0x3F;
            uint32_t lui_imm  = instr1 & 0xFFFF;
            uint32_t lui_rt   = (instr1 >> 16) & 0x1F;

            /* Check for ADDIU $reg, $reg, 0xF1C8 (opcode 0x09, same rt) */
            uint32_t addiu_op  = (instr2 >> 26) & 0x3F;
            uint32_t addiu_rs  = (instr2 >> 21) & 0x1F;
            uint32_t addiu_rt  = (instr2 >> 16) & 0x1F;
            uint32_t addiu_imm = instr2 & 0xFFFF;

            if (lui_op == 0x0F && lui_imm == 0x800F &&
                addiu_op == 0x09 && addiu_rs == lui_rt &&
                addiu_rt == lui_rt && addiu_imm == 0xF1C8) {

                /* Patch LUI to 0x8010, ADDIU to 0x0000 */
                uint32_t new_lui = (instr1 & 0xFFFF0000) | 0x8010;
                uint32_t new_addiu = (instr2 & 0xFFFF0000) | 0x0000;

                /* Write patched instructions */
                exe_base[off+0] = (uint8_t)(new_lui & 0xFF);
                exe_base[off+1] = (uint8_t)((new_lui >> 8) & 0xFF);
                exe_base[off+2] = (uint8_t)((new_lui >> 16) & 0xFF);
                exe_base[off+3] = (uint8_t)((new_lui >> 24) & 0xFF);
                exe_base[off+4] = (uint8_t)(new_addiu & 0xFF);
                exe_base[off+5] = (uint8_t)((new_addiu >> 8) & 0xFF);
                exe_base[off+6] = (uint8_t)((new_addiu >> 16) & 0xFF);
                exe_base[off+7] = (uint8_t)((new_addiu >> 24) & 0xFF);

                /* Only patch first occurrence (primary decompressor) */
                break;
            }
        }
    }

    return SHIM_DQ4_COPIED;
}

/* =============================================================================
 * huffman_shim_entry
 *
 * Assembly entry wrapper with full register preservation.
 * This is the actual entry point called by the trampoline.
 * Saves all $s0-$s7 and $ra, calls huffman_shim_main, restores, returns.
 *
 * In MIPS assembly (what the compiler should generate):
 *
 *   addiu $sp, $sp, -32
 *   sw    $ra, 28($sp)
 *   sw    $s0, 16($sp)
 *   sw    $s1, 20($sp)
 *   sw    $s2, 24($sp)
 *   jal   huffman_shim_main
 *   nop
 *   lw    $ra, 28($sp)
 *   lw    $s0, 16($sp)
 *   lw    $s1, 20($sp)
 *   lw    $s2, 24($sp)
 *   addiu $sp, $sp, 32
 *   jr    $ra
 *   nop
 * =============================================================================
 */

/* The following is marked as used to prevent the compiler from optimizing
 * it away. In practice, this function would be placed at a known address
 * in the code cave and called via a trampoline from the patched header reader.
 */

__attribute__((used, section(".text.shim")))
void huffman_shim_entry(void) {
    /* This function is a placeholder — the actual entry is the assembly
     * wrapper above. The C compiler generates the register save/restore
     * automatically when compiled with -mabi=32 -O2.
     *
     * $a0 is passed through from the trampoline as the block pointer.
     */
    register int32_t result asm("$v0");
    register const uint8_t *block_ptr asm("$a0");

    result = huffman_shim_main(block_ptr);

    /* Result is in $v0, returned to trampoline */
}

/* =============================================================================
 * hdr_reader_trampoline
 *
 * Trampoline code that replaces the first instruction at 0x800429F0.
 * Saves $a0 and $ra, calls the shim, restores, executes the original
 * instruction, and jumps to the second instruction of the original function.
 *
 * In assembled form (raw bytes to write at EXE offset 0x431F0):
 *
 *   addiu $sp, $sp, -8       ; 27BDFFF8
 *   sw    $a0, 0($sp)        ; AFA40000
 *   sw    $ra, 4($sp)        ; AFBF0004
 *   jal   huffman_shim_entry ; 0FFFFFFxx  (target = 0x800B4C70)
 *   nop                      ; 00000000
 *   lw    $a0, 0($sp)        ; 8FA40000
 *   lw    $ra, 4($sp)        ; 8FBF0004
 *   addiu $sp, $sp, 8        ; 27BD0008
 *   <original_instr>         ; patched at build time
 *   j     0x800429F4         ; 08010A7D  (target = 0x800429F4)
 *   nop                      ; 00000000
 *
 * Total: 11 instructions = 44 bytes
 * =============================================================================
 */

/* =============================================================================
 * EXE Patch Table
 *
 * Patches required to install the runtime shim:
 *
 * | Offset (EXE file) | RAM Address  | Original    | Patch         | Description         |
 * |-------------------|--------------|-------------|---------------|---------------------|
 * | 0x431F0           | 0x800429F0   | (read EXE)  | j trampoline  | Hook header reader  |
 * | 0x9CD70           | 0x800B4C70   | 0x00000000  | shim code     | Inject shim body    |
 * | 0x9CD70+shim_size | (after shim) | 0x00000000  | trampoline    | Inject trampoline   |
 *
 * The original instruction at 0x431F0 must be saved and placed into the
 * trampoline's placeholder slot before writing the trampoline to the cave.
 * =============================================================================
 */
