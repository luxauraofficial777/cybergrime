#!/usr/bin/env python3
"""Verify MIPS instruction encodings for the CD-ROM intercept trampoline."""
from capstone import Cs, CS_ARCH_MIPS, CS_MODE_MIPS32, CS_MODE_LITTLE_ENDIAN

# Trampoline instructions (little-endian)
trampoline = [
    0xA0400000,  # 0: sb $zero, 0($v0) — will be replaced with orig_insn0
    0x24620100,  # 1: addiu $v0, $v1, 0x100 — will be replaced with orig_insn1
    0x24090002,  # 2: addiu $t1, $zero, 0x02
    0x1629000C,  # 3: bne $s1, $t1, +12
    0x00000000,  # 4: nop
    0x920A0000,  # 5: lbu $t2, 0($s0)
    0x24090031,  # 6: addiu $t1, $zero, 0x31
    0x012A582B,  # 7: sltu $t3, $t1, $t2
    0x11600007,  # 8: beq $t3, $zero, +7
    0x00000000,  # 9: nop
    0x24080023,  # 10: addiu $t0, $zero, 0x23
    0xA2080000,  # 11: sb $t0, 0($s0)
    0x24080031,  # 12: addiu $t0, $zero, 0x31
    0xA2080001,  # 13: sb $t0, 1($s0)
    0x24080015,  # 14: addiu $t0, $zero, 0x15
    0xA2080002,  # 15: sb $t0, 2($s0)
    0x03E00008,  # 16: jr $ra
    0x00000000,  # 17: nop
]

# Use placeholder values for orig_insn0 and orig_insn1
trampoline[0] = 0xA0400000  # sb $zero, 0($v0)
trampoline[1] = 0x24620100  # addiu $v0, $v1, 0x100

md = Cs(CS_ARCH_MIPS, CS_MODE_MIPS32 | CS_MODE_LITTLE_ENDIAN)

base = 0x800BD000
print("=== Trampoline disassembly verification ===")
for i, insn_word in enumerate(trampoline):
    raw = insn_word.to_bytes(4, 'little')
    addr = base + i * 4
    for d in md.disasm(raw, addr):
        print(f"  {i:2d}: 0x{addr:08X}: 0x{insn_word:08X}  {d.mnemonic:<8s} {d.op_str}")

# Verify branch targets
print("\n=== Branch target verification ===")
# bne at index 3: offset=12, target = (3+1)*4 + 12*4 = 16 + 48 = 64 = base+64
bne_target = base + (3 + 1 + 12) * 4
print(f"  bne at idx 3: target = 0x{bne_target:08X} (should be 0x{base + 16*4:08X} = jr $ra)")

# beq at index 8: offset=7, target = (8+1)*4 + 7*4 = 36 + 28 = 64 = base+64
beq_target = base + (8 + 1 + 7) * 4
print(f"  beq at idx 8: target = 0x{beq_target:08X} (should be 0x{base + 16*4:08X} = jr $ra)")

# Verify JAL encoding
jal_target = base  # trampoline at 0x800BD000
jal_insn = 0x0C000000 | ((jal_target >> 2) & 0x03FFFFFF)
print(f"\n  JAL to 0x{jal_target:08X}: 0x{jal_insn:08X}")
for d in md.disasm(jal_insn.to_bytes(4, 'little'), 0x80098608):
    print(f"    Disassembles as: {d.mnemonic} {d.op_str}")

# Verify $ra value when JAL is at 0x80098608
ra_value = 0x80098608 + 8
print(f"\n  JAL at 0x80098608: $ra = 0x{ra_value:08X} (should be 0x80098610)")
