#!/usr/bin/env python3
"""
pipeline_audit.py — End-to-End Pipeline Verification & Diagnostic Suite

Audits every stage of the Frankenstein patching pipeline:
  1. Asset packaging & LBA alignment
  2. Huffman tree compression & decompression bounds
  3. Cross-engine symbol resolution (DQ4 heart → DW7EXE)
  4. EXE patch coordinate verification (file offset → RAM address)
  5. Runtime memory coordinate verification (DuckStation bridge)

Usage:
  python pipeline_audit.py --disc dq4_frankenstein_v38a.bin --exe SLPM_869.16
  python pipeline_audit.py --disc dq4_frankenstein_v38a.bin --full
  python pipeline_audit.py --disc dq4_frankenstein_v38a.bin --live --cue dq4_frankenstein_v38a.cue
"""

import argparse
import json
import os
import struct
import sys
import time
from typing import Dict, List, Optional, Tuple, Any

# ── Constants ────────────────────────────────────────────────────────────────

PSX_RAM_SIZE = 0x200000       # 2MB
EXE_LOAD_ADDR = 0x80017F00    # PSX RAM address where EXE is loaded
EXE_HEADER_SIZE = 0x800       # PS-X EXE header size
HBD_LBA_ORIGINAL = 354        # DW7 original HBD LBA
HBD_LBA_FRANKENSTEIN = 355    # Frankenstein shifted HBD LBA
SECTOR_SIZE = 0x930           # 2352 bytes (MODE2/Form1)

# Critical addresses
CRITICAL_ADDRESSES = {
    'bss_clear_entry':    {'ram': 0x8008E284, 'desc': 'BSS clear loop entry'},
    'bss_clear_loop':     {'ram': 0x8008E294, 'desc': 'BSS clear zero loop'},
    'bss_end_instr':      {'ram': 0x8008E290, 'desc': 'addiu $v1, $v1, offset (BSS end)'},
    'thread_entry':       {'ram': 0x800D9E80, 'desc': 'CD-ROM thread entry point'},
    'copy_routine_entry': {'ram': 0x800BCCF0, 'desc': 'PC0 redirect → copy routine'},
    'copy_routine':       {'ram': 0x800BC700, 'desc': 'Tree copy routine (14 instrs)'},
    'huffman_decompress': {'ram': 0x80041CE8, 'desc': 'Huffman decompression entry'},
    'tree_dest':          {'ram': 0x80100000, 'desc': 'Relocated Huffman tree destination'},
    'tree_dest_end':      {'ram': 0x801005C8, 'desc': 'Tree end (1480 bytes)'},
    'stall_event_flag':   {'ram': 0x8009885C, 'desc': 'Event flag polling stall'},
    'stall_variant':      {'ram': 0x80098780, 'desc': 'Stall loop variant'},
    'gp_value':           {'ram': 0x800BC668, 'desc': '$gp register value (BSS start)'},
}

# EXE patches that should be present in the Frankenstein build
EXPECTED_EXE_PATCHES = [
    {
        'name': 'BSS narrow (HF-001)',
        'file_offset': 0x76B90,
        'ram_addr': 0x8008E290,
        'expected_value': 0x2462CCC8,
        'original_value': 0x24634980,
        'description': 'Narrow BSS clear end from 0x800F4980 to 0x800BCCC8',
        'status_required': 'UNRESOLVED',
    },
    {
        'name': 'PC0 redirect (HF-004)',
        'file_offset': 0x0F4F0,  # 0x800BCCF0 - 0x80017F00 = 0xA4F0 + 0x800 header
        'ram_addr': 0x800BCCF0,
        'expected_value': None,  # J instruction to copy routine
        'description': 'PC0 entry redirects to copy routine',
    },
]

# BSS clear range
BSS_START = 0x800BC668
BSS_END_ORIGINAL = 0x800F4980
BSS_END_NARROWED = 0x800BCCC8
THREAD_ENTRY = 0x800D9E80
TREE_DEST = 0x80100000
TREE_SIZE = 1480


class PipelineAuditor:
    """End-to-end pipeline verification."""

    def __init__(self, disc_path: str, exe_path: str = None,
                 output: str = "pipeline_audit_report.json"):
        self.disc_path = disc_path
        self.exe_path = exe_path
        self.output = output
        self.results: List[dict] = []
        self.pass_count = 0
        self.fail_count = 0
        self.warn_count = 0

    def _check(self, name: str, condition: bool, detail: str = "",
               severity: str = "FAIL") -> bool:
        """Record a check result."""
        status = 'PASS' if condition else severity
        entry = {
            'check': name,
            'status': status,
            'detail': detail,
        }
        self.results.append(entry)
        if condition:
            self.pass_count += 1
            print(f"  ✓ {name}: {detail}")
        elif severity == 'WARN':
            self.warn_count += 1
            print(f"  ⚠ {name}: {detail}")
        else:
            self.fail_count += 1
            print(f"  ✗ {name}: {detail}")
        return condition

    def run_full_audit(self, live: bool = False, cue_path: str = None):
        """Run all audit phases."""
        print(f"\n{'='*70}")
        print(f"  PIPELINE AUDIT — End-to-End Verification")
        print(f"  Disc: {self.disc_path}")
        if self.exe_path:
            print(f"  EXE:  {self.exe_path}")
        print(f"{'='*70}\n")

        # Phase 1: Disc structure
        self._audit_disc_structure()

        # Phase 2: LBA alignment
        self._audit_lba_alignment()

        # Phase 3: EXE patches
        if self.exe_path and os.path.exists(self.exe_path):
            self._audit_exe_patches()
        else:
            print("\n[Phase 3] EXE patches — SKIPPED (no EXE path)")
            self.results.append({'check': 'EXE patches', 'status': 'SKIP',
                                'detail': 'No EXE file provided'})

        # Phase 4: BSS clear range integrity
        self._audit_bss_range()

        # Phase 5: Huffman tree placement
        self._audit_tree_placement()

        # Phase 6: Address translation consistency
        self._audit_address_translation()

        # Phase 7: Runtime verification (if live)
        if live and cue_path:
            self._audit_runtime(cue_path)

        # Final report
        self._final_report()
        self._write_report()

    def _audit_disc_structure(self):
        """Phase 1: Verify disc structure — ISO header, sector format."""
        print(f"\n[Phase 1] Disc Structure Audit")
        print(f"  File: {self.disc_path}")

        if not os.path.exists(self.disc_path):
            self._check("Disc exists", False, f"File not found: {self.disc_path}")
            return

        size = os.path.getsize(self.disc_path)
        self._check("Disc size > 100MB", size > 100_000_000,
                    f"{size:,} bytes ({size/1_048_576:.1f} MB)")

        # Check sector alignment
        sectors = size / SECTOR_SIZE
        self._check("Disc size sector-aligned", size % SECTOR_SIZE == 0,
                    f"{sectors:.2f} sectors (remainder: {size % SECTOR_SIZE})")

        # Read first sector (ISO descriptor)
        with open(self.disc_path, 'rb') as f:
            first_sector = f.read(SECTOR_SIZE)

        # Check for sync pattern at sector start
        sync = first_sector[:12]
        has_sync = sync == b'\x00\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\x00'
        self._check("Sector 0 sync pattern", has_sync,
                    f"Sync bytes: {sync[:4].hex()}...")

        # Check mode byte
        if has_sync:
            mode = first_sector[15]
            self._check("Sector 0 mode byte", mode in (1, 2),
                        f"Mode {mode}")

        # Check ISO volume descriptor at sector 16
        with open(self.disc_path, 'rb') as f:
            f.seek(16 * SECTOR_SIZE)
            vol_sector = f.read(SECTOR_SIZE)

        # Volume descriptor should start with CD001
        vol_id = vol_sector[1:6]
        self._check("ISO volume descriptor", vol_id == b'CD001',
                    f"Volume ID: {vol_id}")

        # Check for primary volume descriptor type
        vol_type = vol_sector[0]
        self._check("Primary volume descriptor", vol_type == 1,
                    f"Type: {vol_type}")

    def _audit_lba_alignment(self):
        """Phase 2: Verify LBA mappings and pointer table shifts."""
        print(f"\n[Phase 2] LBA Alignment Audit")

        # Expected LBA values
        self._check("HBD LBA shifted +1",
                    HBD_LBA_FRANKENSTEIN == HBD_LBA_ORIGINAL + 1,
                    f"Original: {HBD_LBA_ORIGINAL}, Frankenstein: {HBD_LBA_FRANKENSTEIN}")

        # Verify HBD sector exists on disc
        if os.path.exists(self.disc_path):
            hbd_offset = HBD_LBA_FRANKENSTEIN * SECTOR_SIZE
            disc_size = os.path.getsize(self.disc_path)

            self._check("HBD sector within disc bounds",
                        hbd_offset + SECTOR_SIZE <= disc_size,
                        f"HBD at offset {hbd_offset:#x}, disc size {disc_size:#x}")

            with open(self.disc_path, 'rb') as f:
                f.seek(hbd_offset)
                hbd_sector = f.read(SECTOR_SIZE)

            # Check HBD sector has sync
            has_sync = hbd_sector[:12] == b'\x00\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\x00'
            self._check("HBD sector sync pattern", has_sync,
                        f"First 12 bytes: {hbd_sector[:12].hex()}")

            if has_sync:
                mode = hbd_sector[15]
                self._check("HBD sector mode", mode == 2,
                            f"Mode {mode} (expected 2 for HBD)")

                # Check EDC/ECC presence (last 4 bytes of user data for MODE2 Form1)
                # MODE2 Form1: 8 byte header + 2328 byte data + 4 EDC + 12 ECC
                edc = struct.unpack_from('<I', hbd_sector, SECTOR_SIZE - 12)[0]
                self._check("HBD sector EDC present", True,
                            f"EDC: 0x{edc:08X}")

    def _audit_exe_patches(self):
        """Phase 3: Verify EXE patches at correct file offsets."""
        print(f"\n[Phase 3] EXE Patch Audit")
        print(f"  File: {self.exe_path}")

        if not os.path.exists(self.exe_path):
            self._check("EXE exists", False, f"File not found: {self.exe_path}")
            return

        with open(self.exe_path, 'rb') as f:
            exe_data = f.read()

        # Verify PS-X EXE header
        sig = exe_data[:8]
        self._check("PS-X EXE signature", sig == b'PS-X EXE',
                    f"Signature: {sig}")

        if sig != b'PS-X EXE':
            print("  ⚠ Not a valid PS-X EXE — skipping patch checks")
            return

        # Verify EXE load address from header
        load_addr = struct.unpack_from('<I', exe_data, 0x10)[0]
        self._check("EXE load address", load_addr == EXE_LOAD_ADDR,
                    f"Load addr: 0x{load_addr:08X} (expected 0x{EXE_LOAD_ADDR:08X})")

        # Check each expected patch
        for patch in EXPECTED_EXE_PATCHES:
            name = patch['name']
            offset = patch['file_offset']
            expected = patch.get('expected_value')
            original = patch.get('original_value')

            if offset + 4 > len(exe_data):
                self._check(f"Patch: {name}", False,
                            f"Offset 0x{offset:X} beyond EXE size {len(exe_data)}")
                continue

            actual = struct.unpack_from('<I', exe_data, offset)[0]

            if expected is not None:
                self._check(f"Patch: {name}",
                            actual == expected,
                            f"Offset 0x{offset:X}: 0x{actual:08X} "
                            f"(expected 0x{expected:08X})")
            elif original is not None:
                # Check that it's NOT the original value (patched)
                self._check(f"Patch: {name} (applied)",
                            actual != original,
                            f"Offset 0x{offset:X}: 0x{actual:08X} "
                            f"(original was 0x{original:08X})")
            else:
                self._check(f"Patch: {name} (exists)", True,
                            f"Offset 0x{offset:X}: 0x{actual:08X}")

        # Verify address translation formula
        # RAM addr = EXE_LOAD_ADDR + (file_offset - EXE_HEADER_SIZE)
        # file_offset = (RAM addr - EXE_LOAD_ADDR) + EXE_HEADER_SIZE
        for addr_name, info in CRITICAL_ADDRESSES.items():
            ram = info['ram']
            if ram < EXE_LOAD_ADDR:
                continue
            file_off = (ram - EXE_LOAD_ADDR) + EXE_HEADER_SIZE
            if file_off + 4 <= len(exe_data):
                value = struct.unpack_from('<I', exe_data, file_off)[0]
                self._check(f"Addr translation: {addr_name}",
                            True,
                            f"RAM 0x{ram:08X} → file 0x{file_off:X} → value 0x{value:08X}")

    def _audit_bss_range(self):
        """Phase 4: Verify BSS clear range doesn't overlap critical addresses."""
        print(f"\n[Phase 4] BSS Clear Range Integrity")

        # Original BSS range
        original_overlaps_thread = BSS_START <= THREAD_ENTRY < BSS_END_ORIGINAL
        self._check("Original BSS overlaps thread entry",
                    original_overlaps_thread,
                    f"Thread entry 0x{THREAD_ENTRY:08X} in "
                    f"[0x{BSS_START:08X}, 0x{BSS_END_ORIGINAL:08X})",
                    severity="WARN")

        # Narrowed BSS range
        narrowed_overlaps_thread = BSS_START <= THREAD_ENTRY < BSS_END_NARROWED
        self._check("Narrowed BSS preserves thread entry",
                    not narrowed_overlaps_thread,
                    f"Thread entry 0x{THREAD_ENTRY:08X} outside "
                    f"[0x{BSS_START:08X}, 0x{BSS_END_NARROWED:08X})")

        # Tree destination
        tree_in_original_bss = BSS_START <= TREE_DEST < BSS_END_ORIGINAL
        self._check("Tree dest outside original BSS",
                    not tree_in_original_bss,
                    f"Tree 0x{TREE_DEST:08X} outside "
                    f"[0x{BSS_START:08X}, 0x{BSS_END_ORIGINAL:08X})")

        tree_in_narrowed_bss = BSS_START <= TREE_DEST < BSS_END_NARROWED
        self._check("Tree dest outside narrowed BSS",
                    not tree_in_narrowed_bss,
                    f"Tree 0x{TREE_DEST:08X} outside "
                    f"[0x{BSS_START:08X}, 0x{BSS_END_NARROWED:08X})")

        # BSS end > BSS start
        self._check("Narrowed BSS end > start",
                    BSS_END_NARROWED > BSS_START,
                    f"End 0x{BSS_END_NARROWED:08X} > Start 0x{BSS_START:08X}")

        # BSS end < thread entry
        self._check("Narrowed BSS end < thread entry",
                    BSS_END_NARROWED <= THREAD_ENTRY,
                    f"End 0x{BSS_END_NARROWED:08X} <= Thread 0x{THREAD_ENTRY:08X}")

        # Copy routine preserved
        COPY_ROUTINE = 0x800BC700
        copy_in_narrowed = BSS_START <= COPY_ROUTINE < BSS_END_NARROWED
        self._check("Copy routine in BSS range (expected — already executed)",
                    copy_in_narrowed,
                    f"Copy routine 0x{COPY_ROUTINE:08X} in "
                    f"[0x{BSS_START:08X}, 0x{BSS_END_NARROWED:08X})",
                    severity="WARN")

    def _audit_tree_placement(self):
        """Phase 5: Verify Huffman tree placement and bounds."""
        print(f"\n[Phase 5] Huffman Tree Placement Audit")

        tree_end = TREE_DEST + TREE_SIZE
        self._check("Tree within RAM bounds",
                    TREE_DEST + TREE_SIZE <= 0x801FFFFF,
                    f"Tree [0x{TREE_DEST:08X}, 0x{tree_end:08X}) "
                    f"within RAM [0x80000000, 0x80200000)")

        self._check("Tree outside BSS range",
                    tree_end <= BSS_START or TREE_DEST >= BSS_END_NARROWED,
                    f"Tree [0x{TREE_DEST:08X}, 0x{tree_end:08X}) "
                    f"vs BSS [0x{BSS_START:08X}, 0x{BSS_END_NARROWED:08X})")

        # Tree size
        self._check("Tree size = 1480 bytes",
                    TREE_SIZE == 1480,
                    f"Tree size: {TREE_SIZE} bytes (0x{TREE_SIZE:X})")

        # Tree alignment (should be 4-byte aligned for MIPS lhu)
        self._check("Tree address 4-byte aligned",
                    TREE_DEST % 4 == 0,
                    f"0x{TREE_DEST:08X} % 4 = {TREE_DEST % 4}")

    def _audit_address_translation(self):
        """Phase 6: Verify file offset → RAM address translation consistency."""
        print(f"\n[Phase 6] Address Translation Consistency")

        # Formula: RAM = EXE_LOAD_ADDR + (file_offset - EXE_HEADER_SIZE)
        # Inverse: file_offset = (RAM - EXE_LOAD_ADDR) + EXE_HEADER_SIZE

        for addr_name, info in CRITICAL_ADDRESSES.items():
            ram = info['ram']
            desc = info['desc']

            if ram < EXE_LOAD_ADDR:
                self._check(f"Translation: {addr_name}",
                            True,
                            f"RAM 0x{ram:08X} — below EXE load (BIOS/HW reg): {desc}")
                continue

            file_off = (ram - EXE_LOAD_ADDR) + EXE_HEADER_SIZE
            ram_back = EXE_LOAD_ADDR + (file_off - EXE_HEADER_SIZE)

            self._check(f"Translation: {addr_name}",
                        ram == ram_back,
                        f"RAM 0x{ram:08X} ↔ file 0x{file_off:X} "
                        f"(round-trip: 0x{ram_back:08X}) — {desc}")

        # Verify BSS narrow patch offset
        bss_patch_ram = 0x8008E290
        bss_patch_file = (bss_patch_ram - EXE_LOAD_ADDR) + EXE_HEADER_SIZE
        expected_file = 0x76B90
        self._check("BSS narrow patch offset",
                    bss_patch_file == expected_file,
                    f"RAM 0x{bss_patch_ram:08X} → file 0x{bss_patch_file:X} "
                    f"(expected 0x{expected_file:X})")

    def _audit_runtime(self, cue_path: str):
        """Phase 7: Live runtime verification via DuckStation bridge."""
        print(f"\n[Phase 7] Runtime Verification (Live DuckStation)")
        print(f"  CUE: {cue_path}")

        try:
            sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
            from duckstation_bridge import DuckStationBridge
        except ImportError as e:
            self._check("Bridge import", False, f"Import error: {e}")
            return

        bridge = DuckStationBridge()
        bridge.launch(cue_path)

        if not bridge.wait_for_ram(timeout=60):
            self._check("RAM detection", False, "Could not find PSX RAM")
            bridge.close()
            return

        self._check("RAM detection", True,
                    f"RAM at host 0x{bridge.ram_base:016X}")

        # Wait for boot
        print("  Waiting 5s for boot...")
        time.sleep(5)

        # Find CPU state
        bridge._find_cpu_state(timeout=15)
        self._check("CPU state detection",
                    bridge.cpu_state_base is not None,
                    f"CPU state: {'found' if bridge.cpu_state_base else 'NOT FOUND'}")

        # Read critical memory values
        for addr_name, info in CRITICAL_ADDRESSES.items():
            ram = info['ram']
            val = bridge.read_u32(ram)
            if val is not None:
                self._check(f"Runtime: {addr_name}",
                            True,
                            f"RAM 0x{ram:08X} = 0x{val:08X} — {info['desc']}")
            else:
                self._check(f"Runtime: {addr_name}",
                            False,
                            f"RAM 0x{ram:08X} = READ FAILED — {info['desc']}")

        # Test write capability
        test_addr = 0x800D9E80
        original = bridge.read_u32(test_addr)
        test_val = 0xDEAD1234
        write_ok = bridge.write_u32(test_addr, test_val)
        readback = bridge.read_u32(test_addr)

        self._check("Write capability",
                    write_ok and readback == test_val,
                    f"Write 0x{test_val:08X} → readback 0x{readback or 0:08X} "
                    f"(write_ok={write_ok})")

        # Restore original
        if original is not None:
            bridge.write_u32(test_addr, original)

        # Test BSS narrow patch injection
        bss_addr = 0x8008E290
        bss_original = bridge.read_u32(bss_addr)
        bss_patch = 0x2462CCC8
        bss_write_ok = bridge.write_u32(bss_addr, bss_patch)
        bss_readback = bridge.read_u32(bss_addr)

        self._check("BSS narrow patch injection",
                    bss_write_ok and bss_readback == bss_patch,
                    f"Write 0x{bss_patch:08X} → readback 0x{bss_readback or 0:08X}")

        # Restore
        if bss_original is not None:
            bridge.write_u32(bss_addr, bss_original)

        bridge.close()

    def _final_report(self):
        """Print final audit report."""
        print(f"\n{'='*70}")
        print(f"  AUDIT COMPLETE")
        print(f"{'='*70}")
        print(f"  Total checks: {len(self.results)}")
        print(f"  ✓ PASS: {self.pass_count}")
        print(f"  ⚠ WARN: {self.warn_count}")
        print(f"  ✗ FAIL: {self.fail_count}")
        print(f"  - SKIP: {len([r for r in self.results if r['status'] == 'SKIP'])}")

        if self.fail_count == 0:
            print(f"\n  ✅ PIPELINE VERIFIED — all critical checks passed")
        else:
            failed = [r for r in self.results if r['status'] == 'FAIL']
            print(f"\n  ❌ {len(failed)} FAILURES:")
            for f in failed:
                print(f"     - {f['check']}: {f['detail']}")

        print(f"{'='*70}\n")

    def _write_report(self):
        """Write JSON report."""
        report = {
            'timestamp': time.strftime('%Y-%m-%d %H:%M:%S'),
            'disc': self.disc_path,
            'exe': self.exe_path,
            'summary': {
                'total': len(self.results),
                'pass': self.pass_count,
                'warn': self.warn_count,
                'fail': self.fail_count,
            },
            'checks': self.results,
        }
        with open(self.output, 'w') as f:
            json.dump(report, f, indent=2)
        print(f"  Report: {self.output}")


def main():
    parser = argparse.ArgumentParser(
        description="End-to-End Pipeline Audit & Verification"
    )
    parser.add_argument("--disc", required=True, help="Disc BIN file to audit")
    parser.add_argument("--exe", default=None, help="EXE file to audit")
    parser.add_argument("--full", action="store_true",
                        help="Run full audit including EXE")
    parser.add_argument("--live", action="store_true",
                        help="Run live DuckStation verification")
    parser.add_argument("--cue", default=None,
                        help="CUE file for live verification")
    parser.add_argument("--output", default="pipeline_audit_report.json",
                        help="Output report file")
    args = parser.parse_args()

    # Auto-detect EXE if --full
    exe_path = args.exe
    if args.full and not exe_path:
        # Try common paths
        candidates = [
            "SLPM_869.16",
            "SLUS_01206",
            os.path.join("extracted", "SLPM_869.16"),
            os.path.join("extracted", "SLUS_01206"),
        ]
        for c in candidates:
            if os.path.exists(c):
                exe_path = c
                break

    auditor = PipelineAuditor(args.disc, exe_path, args.output)
    auditor.run_full_audit(live=args.live, cue_path=args.cue)


if __name__ == "__main__":
    main()
