#!/usr/bin/env python3
"""DuckStation Control Test Launcher

Launches DuckStation with verified logging for control tests and Frankenstein builds.
Clears old logs, launches with -batch flag, waits, kills, then analyzes the log.

Usage:
    python launch_duckstation_tests.py --control-a          # DQ4 JP original
    python launch_duckstation_tests.py --control-b          # DW7 US original
    python launch_duckstation_tests.py --frank-v18          # Frankenstein V18
    python launch_duckstation_tests.py --rc2                # RC2 fallback
    python launch_duckstation_tests.py --all                # Run all tests sequentially
    python launch_duckstation_tests.py --cue "path.cue" --name custom --duration 120
"""
import argparse
import os
import subprocess
import sys
import time
import json
from datetime import datetime
from pathlib import Path

DUCKSTATION_EXE = r"C:\LuxAura\VoidWalkers_Project\DuckStation\duckstation-qt-x64-ReleaseLTCG.exe"
DUCKSTATION_DIR = r"C:\LuxAura\VoidWalkers_Project\DuckStation"
LOG_DIR = r"C:\LuxAura\VoidWalkers_Project\DQLOSTTRANSLATION\tools\frankenstein_qa\logs"
RESULTS_DIR = r"C:\LuxAura\VoidWalkers_Project\DQLOSTTRANSLATION\tools\frankenstein_qa\results"
DS_LOG_FILE = os.path.join(LOG_DIR, "duckstation.log")

BASE = r"C:\LuxAura\VoidWalkers_Project\DQLOSTTRANSLATION"

TESTS = {
    "control_a_dq4_jp": {
        "cue": os.path.join(BASE, "Dragon Quest IV - Michibikareshi Mono Tachi (Japan).cue"),
        "duration": 90,
        "desc": "Control A: Original DQ4 JP disc",
    },
    "control_b_dw7_us": {
        "cue": os.path.join(BASE, "DW7D1", "DW7D1.cue"),
        "duration": 90,
        "desc": "Control B: Original DW7 US disc",
    },
    "frank_v18": {
        "cue": os.path.join(BASE, "dq4_frankenstein_v18.cue"),
        "duration": 120,
        "desc": "Frankenstein V18 (fixed HBD extraction)",
    },
    "rc2": {
        "cue": os.path.join(BASE, "_archive", "dq4_en_rc2.cue"),
        "duration": 90,
        "desc": "RC2 fallback (DQ4 EXE + patched HBD)",
    },
}


def ensure_dirs():
    os.makedirs(LOG_DIR, exist_ok=True)
    os.makedirs(RESULTS_DIR, exist_ok=True)


def clear_ds_log():
    """Clear the DuckStation log file so we only capture this run."""
    if os.path.exists(DS_LOG_FILE):
        os.remove(DS_LOG_FILE)
    # Also clear in settings dir
    alt_log = os.path.join(DUCKSTATION_DIR, "settings", "duckstation.log")
    if os.path.exists(alt_log):
        os.remove(alt_log)


def verify_files(cue_path):
    """Verify CUE and BIN files exist."""
    if not os.path.exists(cue_path):
        return False, f"CUE not found: {cue_path}", None
    with open(cue_path, 'r') as f:
        for line in f:
            line = line.strip()
            if line.startswith('FILE'):
                parts = line.split('"')
                if len(parts) >= 2:
                    bin_name = parts[1]
                    bin_path = os.path.join(os.path.dirname(cue_path), bin_name)
                    if os.path.exists(bin_path):
                        return True, "OK", bin_path
                    return False, f"BIN not found: {bin_path}", bin_path
    return False, "No FILE entry in CUE", None


def run_test(test_name, cue_path, duration, desc):
    """Run a single DuckStation test."""
    ensure_dirs()
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")

    print(f"\n{'='*60}")
    print(f"  TEST: {test_name}")
    print(f"  DESC: {desc}")
    print(f"  CUE:  {cue_path}")
    print(f"  DUR:  {duration}s")
    print(f"{'='*60}")

    ok, msg, bin_path = verify_files(cue_path)
    if not ok:
        print(f"  [FAIL] {msg}")
        return {"test_name": test_name, "verdict": "FAIL_MISSING_FILES", "error": msg}

    print(f"  BIN:  {bin_path} ({os.path.getsize(bin_path):,} bytes)")

    # Clear old log
    clear_ds_log()
    print(f"  [LOG] Cleared old DuckStation log")

    # Launch DuckStation with -batch (auto-exit on game close) and -earlyconsole (logging)
    print(f"  [LAUNCH] {DUCKSTATION_EXE}")
    try:
        proc = subprocess.Popen(
            [DUCKSTATION_EXE, "-batch", "-earlyconsole", cue_path],
            cwd=DUCKSTATION_DIR,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            creationflags=subprocess.CREATE_NEW_PROCESS_GROUP,
        )
        print(f"  [PID] {proc.pid}, waiting {duration}s...")
    except Exception as e:
        print(f"  [FAIL] Launch error: {e}")
        return {"test_name": test_name, "verdict": f"FAIL_LAUNCH: {e}"}

    # Wait for duration
    time.sleep(duration)

    # Kill the process
    try:
        proc.terminate()
        time.sleep(2)
        if proc.poll() is None:
            proc.kill()
        exit_code = proc.returncode
        print(f"  [KILL] Process terminated, exit code: {exit_code}")
    except Exception as e:
        print(f"  [WARN] Kill error: {e}")
        exit_code = None

    # Collect stdout
    stdout_data = ""
    try:
        if proc.stdout:
            stdout_data = proc.stdout.read().decode('utf-8', errors='replace')
    except Exception:
        pass

    # Collect DuckStation log file
    ds_log = ""
    log_sources = []
    if os.path.exists(DS_LOG_FILE) and os.path.getsize(DS_LOG_FILE) > 0:
        with open(DS_LOG_FILE, 'r', encoding='utf-8', errors='replace') as f:
            ds_log = f.read()
        log_sources.append(DS_LOG_FILE)
        print(f"  [LOG] DuckStation log: {DS_LOG_FILE} ({len(ds_log):,} chars)")
    else:
        alt_log = os.path.join(DUCKSTATION_DIR, "settings", "duckstation.log")
        if os.path.exists(alt_log) and os.path.getsize(alt_log) > 0:
            with open(alt_log, 'r', encoding='utf-8', errors='replace') as f:
                ds_log = f.read()
            log_sources.append(alt_log)
            print(f"  [LOG] DuckStation log (alt): {alt_log} ({len(ds_log):,} chars)")
        else:
            print(f"  [WARN] No DuckStation log file found!")

    # Save combined log
    combined_log = os.path.join(LOG_DIR, f"{test_name}_{timestamp}.log")
    with open(combined_log, 'w', encoding='utf-8') as f:
        if stdout_data:
            f.write("=== STDOUT ===\n\n")
            f.write(stdout_data)
            f.write("\n\n")
        if ds_log:
            f.write("=== DuckStation Log ===\n\n")
            f.write(ds_log)
    print(f"  [LOG] Combined log: {combined_log} ({os.path.getsize(combined_log):,} bytes)")

    # Analyze log
    all_text = stdout_data + "\n" + ds_log
    lines = all_text.split('\n')

    gpu_commands = 0
    fps_lines = 0
    cdrom_lines = 0
    bios_lines = 0
    error_lines = []
    first_gpu = None
    first_frame = None
    exe_loaded = False
    bios_loaded = False

    for i, line in enumerate(lines):
        ll = line.lower()

        if 'gpu' in ll and ('command' in ll or 'draw' in ll or 'render' in ll or 'packet' in ll):
            gpu_commands += 1
            if first_gpu is None:
                first_gpu = f"line {i}: {line.strip()[:200]}"

        if 'fps' in ll or ('frame' in ll and 'present' in ll):
            fps_lines += 1
            if first_frame is None and 'present' in ll:
                first_frame = f"line {i}: {line.strip()[:200]}"

        if 'cdrom' in ll or 'cd-rom' in ll or 'sector' in ll:
            cdrom_lines += 1

        if 'bios' in ll:
            bios_lines += 1
            if 'loaded' in ll or 'found' in ll or 'initialized' in ll:
                bios_loaded = True

        if 'exe' in ll and ('load' in ll or 'mapped' in ll or 'entry' in ll):
            exe_loaded = True

        if 'error' in ll or 'fatal' in ll or 'crash' in ll or 'failed' in ll:
            if len(error_lines) < 30:
                error_lines.append(f"line {i}: {line.strip()[:200]}")

    # Determine verdict
    if gpu_commands > 0:
        verdict = "PASS_GPU_ACTIVITY"
    elif fps_lines > 5:
        verdict = "PASS_FRAMES_PRESENTED"
    elif bios_loaded and exe_loaded and cdrom_lines > 0:
        verdict = "PARTIAL_BOOT_NO_GPU"
    elif error_lines:
        verdict = "FAIL_ERRORS"
    elif cdrom_lines > 0:
        verdict = "PARTIAL_CDROM_ONLY"
    elif bios_loaded:
        verdict = "PARTIAL_BIOS_ONLY"
    else:
        verdict = "FAIL_NO_OUTPUT"

    result = {
        "test_name": test_name,
        "desc": desc,
        "cue_path": cue_path,
        "bin_path": bin_path,
        "timestamp": timestamp,
        "duration_seconds": duration,
        "exit_code": exit_code,
        "log_file": combined_log,
        "log_size": os.path.getsize(combined_log),
        "gpu_commands": gpu_commands,
        "fps_lines": fps_lines,
        "cdrom_lines": cdrom_lines,
        "bios_lines": bios_lines,
        "bios_loaded": bios_loaded,
        "exe_loaded": exe_loaded,
        "first_gpu_command": first_gpu,
        "first_frame_presented": first_frame,
        "error_lines": error_lines[:10],
        "verdict": verdict,
    }

    # Save result JSON
    result_file = os.path.join(RESULTS_DIR, f"{test_name}_{timestamp}.json")
    with open(result_file, 'w') as f:
        json.dump(result, f, indent=2)

    print(f"\n  [RESULT] Verdict: {verdict}")
    print(f"  [RESULT] GPU commands: {gpu_commands}, FPS lines: {fps_lines}")
    print(f"  [RESULT] CDROM lines: {cdrom_lines}, BIOS loaded: {bios_loaded}, EXE loaded: {exe_loaded}")
    if error_lines:
        print(f"  [RESULT] Errors: {len(error_lines)} (showing first 3)")
        for e in error_lines[:3]:
            print(f"    {e}")
    print(f"  [RESULT] JSON: {result_file}")

    return result


def main():
    parser = argparse.ArgumentParser(description="DuckStation Control Test Launcher")
    parser.add_argument("--control-a", action="store_true", help="Run Control A: DQ4 JP original")
    parser.add_argument("--control-b", action="store_true", help="Run Control B: DW7 US original")
    parser.add_argument("--frank-v18", action="store_true", help="Run Frankenstein V18")
    parser.add_argument("--rc2", action="store_true", help="Run RC2 fallback")
    parser.add_argument("--all", action="store_true", help="Run all tests sequentially")
    parser.add_argument("--cue", help="Custom CUE file path")
    parser.add_argument("--name", default="custom_test", help="Test name (for custom CUE)")
    parser.add_argument("--duration", type=int, default=90, help="Duration in seconds")
    args = parser.parse_args()

    if args.all:
        results = []
        for name, cfg in TESTS.items():
            r = run_test(name, cfg["cue"], cfg["duration"], cfg["desc"])
            results.append(r)
            print()
        print("\n" + "=" * 60)
        print("  BATCH SUMMARY")
        print("=" * 60)
        for r in results:
            v = r.get("verdict", "UNKNOWN")
            tag = "PASS" if "PASS" in v else "FAIL" if "FAIL" in v else "PARTIAL"
            print(f"  {r['test_name']:30s} {tag:8s} {v}")
        print("=" * 60)
        summary = os.path.join(RESULTS_DIR, f"batch_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json")
        with open(summary, 'w') as f:
            json.dump(results, f, indent=2)
        print(f"\n  Batch summary: {summary}")
        return

    if args.cue:
        run_test(args.name, args.cue, args.duration, "Custom test")
        return

    ran_any = False
    if args.control_a:
        run_test("control_a_dq4_jp", TESTS["control_a_dq4_jp"]["cue"],
                 TESTS["control_a_dq4_jp"]["duration"], TESTS["control_a_dq4_jp"]["desc"])
        ran_any = True
    if args.control_b:
        run_test("control_b_dw7_us", TESTS["control_b_dw7_us"]["cue"],
                 TESTS["control_b_dw7_us"]["duration"], TESTS["control_b_dw7_us"]["desc"])
        ran_any = True
    if args.frank_v18:
        run_test("frank_v18", TESTS["frank_v18"]["cue"],
                 TESTS["frank_v18"]["duration"], TESTS["frank_v18"]["desc"])
        ran_any = True
    if args.rc2:
        run_test("rc2", TESTS["rc2"]["cue"],
                 TESTS["rc2"]["duration"], TESTS["rc2"]["desc"])
        ran_any = True

    if not ran_any:
        parser.print_help()
        print("\nAvailable tests:")
        for name, cfg in TESTS.items():
            print(f"  --{name.replace('_', '-'):20s} {cfg['desc']} ({cfg['duration']}s)")


if __name__ == "__main__":
    main()
