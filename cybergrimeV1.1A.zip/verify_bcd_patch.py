#!/usr/bin/env python3
"""Verify BCD patch in the EXE on the built disc."""
import struct

SECTOR_SIZE = 2352
USER_SIZE = 2048
EXE_LBA = 24
HEADER = 24
FMV_BCD_OFFSET = 0x092936

disc_path = r"C:\LuxAura\VoidWalkers_Project\DQLOSTTRANSLATION\build_staging\dq4_gold.bin"
with open(disc_path, "rb") as f:
    disc = f.read()

# Extract EXE from disc
exe_start = EXE_LBA * SECTOR_SIZE + HEADER
exe = disc[exe_start:exe_start + 677888]

# Check bytes at the patch offset
patched = exe[FMV_BCD_OFFSET:FMV_BCD_OFFSET+3]
print(f"Bytes at 0x{FMV_BCD_OFFSET:06X} in disc EXE: {patched.hex()}")
print(f"Expected (patched): 233108")
print(f"Expected (original): 323471")

# Also check context around it
ctx = exe[FMV_BCD_OFFSET-16:FMV_BCD_OFFSET+20]
print(f"Context: {ctx.hex()}")

# Now search the ENTIRE disc for BCD 32:34:71 in user data areas
# to see if there's another copy somewhere
pat = bytes([0x32, 0x34, 0x71])
print(f"\nSearching entire disc for 32:34:71 in user data...")
for sector_idx in range(len(disc) // SECTOR_SIZE):
    sec_start = sector_idx * SECTOR_SIZE + HEADER
    if sec_start + USER_SIZE > len(disc):
        break
    sec_data = disc[sec_start:sec_start + USER_SIZE]
    idx = sec_data.find(pat)
    if idx != -1:
        # Check if this is in the EXE sector range (24-354) or HBD range (355+)
        region = "EXE" if sector_idx < 355 else "HBD"
        ram = 0x80017F00 + (sector_idx - 24) * USER_SIZE + idx if sector_idx >= 24 and sector_idx < 355 else 0
        print(f"  Sector {sector_idx} ({region}), user offset {idx}: 32:34:71" + 
              (f" (RAM 0x{ram:08X})" if ram else ""))
