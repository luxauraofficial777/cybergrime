$j = Get-Content telemetry_puppeteer_inject2.json -Raw | ConvertFrom-Json
Write-Host "=== Inject2 Run State ==="
Write-Host "Status: $($j.Pass_Status)"
Write-Host "Instructions: $($j.Instructions_Executed)"
Write-Host "VBlanks: $($j.VBlank_Count)"
Write-Host "Crashed: $($j.Crashed)"
Write-Host "Crash Reason: $($j.Crash_Reason)"
Write-Host "PC: $($j.Register_Dump.PC)"
Write-Host "SP: $($j.Register_Dump.sp)"
Write-Host "GP: $($j.Register_Dump.gp)"
Write-Host "RA: $($j.Register_Dump.ra)"
Write-Host ""
$tty = $j.TTY_Tail
Write-Host "TTY Tail (first 3000 chars):"
Write-Host $tty.Substring(0, [Math]::Min(3000, $tty.Length))
