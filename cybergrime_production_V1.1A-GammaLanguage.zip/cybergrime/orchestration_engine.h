// ============================================================================
// ORCHESTRATION ENGINE — Dynamic MIPS Execution Control
// ============================================================================
// Header-only engine providing:
//   - Instruction-level hook/override table (64 slots)
//   - PC auto-corrector for illegal opcodes / unmapped addresses
//   - Register watches at specific PCs ($a0-$a3 monitoring)
//   - Audit log with rollback for all RAM modifications
//   - Live telemetry dashboard (periodic reg dumps)
//   - DQ4 <-> DW7 dual-binary address map with delta-patching
//   - Bulk opcode search-and-replace across RAM
//
// Global instance: g_orch (defined in psx_emulator_core.cpp)
// Wired into MIPS_CPU::step() via pre/post-exec hook checks.
// ============================================================================

#ifndef ORCHESTRATION_ENGINE_H
#define ORCHESTRATION_ENGINE_H

#include <cstdint>
#include <cstdio>
#include <cstring>
#include <cstdlib>

class MIPS_CPU;
class PSX_Memory;

// ── Hook System ─────────────────────────────────────────────────────────────

enum HookAction {
    HOOK_NONE = 0,
    HOOK_SKIP,
    HOOK_REDIRECT,
    HOOK_SET_REG,
    HOOK_OVERRIDE_INSTR,
    HOOK_CALL_HANDLER,
};

enum HookFlags {
    HF_ENABLED  = 0x01,
    HF_ONESHOT  = 0x02,
    HF_LOG_REGS = 0x04,
    HF_PRE_EXEC = 0x10,
    HF_POST_EXEC= 0x20,
};

struct HookEntry {
    uint32_t pc;
    uint32_t flags;
    HookAction action;
    uint32_t redirect_pc;
    uint32_t set_reg_num;
    uint32_t set_reg_val;
    uint32_t override_instr;
    char label[32];
    int hit_count;
    int max_hits;
    typedef void (*HandlerFn)(MIPS_CPU&, PSX_Memory&, HookEntry&);
    HandlerFn handler;

    void init() {
        pc = 0; flags = 0; action = HOOK_NONE;
        redirect_pc = 0; set_reg_num = 0; set_reg_val = 0;
        override_instr = 0; label[0] = 0;
        hit_count = 0; max_hits = 0; handler = nullptr;
    }
};

// ── Register Watch ──────────────────────────────────────────────────────────

struct RegWatch {
    uint32_t pc;
    uint32_t watch_mask;  // Bit N = log register N
    int max_samples;
    int sample_count;
    char label[32];

    void init() {
        pc = 0; watch_mask = 0; max_samples = 0;
        sample_count = 0; label[0] = 0;
    }
};

// ── Audit Log ───────────────────────────────────────────────────────────────

struct AuditEntry {
    uint64_t instr_count;
    uint32_t addr;
    uint32_t old_value;
    uint32_t new_value;
    int size;
    char reason[48];
    bool rolled_back;

    void init() {
        instr_count = 0; addr = 0; old_value = 0; new_value = 0;
        size = 0; reason[0] = 0; rolled_back = false;
    }
};

// ── Address Map (DQ4 <-> DW7) ───────────────────────────────────────────────

struct AddressMapEntry {
    uint32_t dq4_addr;
    uint32_t dw7_addr;
    int size;
    char description[48];
    bool is_code;

    void init() {
        dq4_addr = 0; dw7_addr = 0; size = 0;
        description[0] = 0; is_code = false;
    }
};

// ── Orchestration Engine ────────────────────────────────────────────────────

class OrchestrationEngine {
public:
    // --- Configuration ---
    bool enabled;
    bool auto_correct_enabled;
    bool telemetry_enabled;
    int telemetry_interval;
    int max_corrections;
    int correction_count;

    // Danger zone — HBD data region where garbage code causes crashes
    uint32_t danger_zone_start;
    uint32_t danger_zone_end;

    // --- Hook Table ---
    static const int MAX_HOOKS = 64;
    HookEntry hooks[MAX_HOOKS];
    int hook_count;

    // --- Register Watches ---
    static const int MAX_WATCHES = 32;
    RegWatch watches[MAX_WATCHES];
    int watch_count;

    // --- Audit Log ---
    static const int MAX_AUDIT = 4096;
    AuditEntry audit_log[MAX_AUDIT];
    int audit_count;

    // --- Address Map ---
    static const int MAX_MAP_ENTRIES = 256;
    AddressMapEntry addr_map[MAX_MAP_ENTRIES];
    int map_count;

    // --- DW7 Reference Buffer ---
    uint8_t dw7_exe[0x200000];  // 2MB max
    int dw7_exe_size;
    bool dw7_loaded;

    // --- Telemetry ---
    FILE* telemetry_file;
    uint64_t last_telem_instr;

    // --- Constructor / Init ---
    OrchestrationEngine() : telemetry_file(nullptr) { init(); }

    void init() {
        enabled = false;
        auto_correct_enabled = true;
        telemetry_enabled = false;
        telemetry_interval = 100000;
        max_corrections = 100;
        correction_count = 0;
        danger_zone_start = 0x800D0000;
        danger_zone_end = 0x800F0000;

        for (int i = 0; i < MAX_HOOKS; i++) hooks[i].init();
        hook_count = 0;

        for (int i = 0; i < MAX_WATCHES; i++) watches[i].init();
        watch_count = 0;

        for (int i = 0; i < MAX_AUDIT; i++) audit_log[i].init();
        audit_count = 0;

        for (int i = 0; i < MAX_MAP_ENTRIES; i++) addr_map[i].init();
        map_count = 0;

        dw7_exe_size = 0;
        dw7_loaded = false;

        if (telemetry_file) { fclose(telemetry_file); telemetry_file = nullptr; }
        last_telem_instr = 0;
    }

    // --- Hook Management ---
    int add_hook(uint32_t pc, HookAction action, const char* label,
                 uint32_t flags = HF_ENABLED | HF_PRE_EXEC,
                 int max_hits = 0) {
        for (int i = 0; i < MAX_HOOKS; i++) {
            if (hooks[i].pc == pc && (hooks[i].flags & HF_ENABLED)) {
                return i;  // Already hooked
            }
        }
        for (int i = 0; i < MAX_HOOKS; i++) {
            if (hooks[i].pc == 0 || !(hooks[i].flags & HF_ENABLED)) {
                hooks[i].init();
                hooks[i].pc = pc;
                hooks[i].action = action;
                hooks[i].flags = flags;
                hooks[i].max_hits = max_hits;
                if (label) strncpy(hooks[i].label, label, 31);
                hooks[i].label[31] = 0;
                if (hook_count <= i) hook_count = i + 1;
                return i;
            }
        }
        return -1;  // Table full
    }

    int add_redirect(uint32_t pc, uint32_t new_pc, const char* label) {
        int idx = add_hook(pc, HOOK_REDIRECT, label);
        if (idx >= 0) hooks[idx].redirect_pc = new_pc;
        return idx;
    }

    int add_set_reg(uint32_t pc, uint32_t reg_num, uint32_t reg_val, const char* label) {
        int idx = add_hook(pc, HOOK_SET_REG, label);
        if (idx >= 0) {
            hooks[idx].set_reg_num = reg_num;
            hooks[idx].set_reg_val = reg_val;
        }
        return idx;
    }

    int add_override(uint32_t pc, uint32_t new_instr, const char* label) {
        int idx = add_hook(pc, HOOK_OVERRIDE_INSTR, label);
        if (idx >= 0) hooks[idx].override_instr = new_instr;
        return idx;
    }

    int add_handler(uint32_t pc, HookEntry::HandlerFn fn, const char* label) {
        int idx = add_hook(pc, HOOK_CALL_HANDLER, label);
        if (idx >= 0) hooks[idx].handler = fn;
        return idx;
    }

    void remove_hook(uint32_t pc) {
        for (int i = 0; i < MAX_HOOKS; i++) {
            if (hooks[i].pc == pc) hooks[i].init();
        }
    }

    // Returns: 0=continue, 1=skip instruction, 2=PC was redirected
    int run_hooks(MIPS_CPU& cpu, PSX_Memory& mem, bool pre_exec);

    // --- Register Watches ---
    int add_watch(uint32_t pc, uint32_t reg_mask, const char* label, int max_samples = 100) {
        for (int i = 0; i < MAX_WATCHES; i++) {
            if (watches[i].pc == 0) {
                watches[i].init();
                watches[i].pc = pc;
                watches[i].watch_mask = reg_mask;
                watches[i].max_samples = max_samples;
                if (label) strncpy(watches[i].label, label, 31);
                watches[i].label[31] = 0;
                if (watch_count <= i) watch_count = i + 1;
                return i;
            }
        }
        return -1;
    }

    void sample_registers(MIPS_CPU& cpu, uint32_t cur_pc);

    // --- Audit Log ---
    void audit_write(uint64_t instr, uint32_t addr, uint32_t old_val,
                     uint32_t new_val, int sz, const char* reason) {
        if (audit_count >= MAX_AUDIT) return;
        AuditEntry& e = audit_log[audit_count++];
        e.instr_count = instr;
        e.addr = addr;
        e.old_value = old_val;
        e.new_value = new_val;
        e.size = sz;
        e.rolled_back = false;
        if (reason) strncpy(e.reason, reason, 47);
        e.reason[47] = 0;
    }

    bool audit_rollback_last(PSX_Memory& mem);
    int audit_rollback_to(PSX_Memory& mem, int target_count);
    void audit_dump(const char* path);

    // --- Address Map ---
    int add_mapping(uint32_t dq4, uint32_t dw7, int sz, const char* desc, bool code) {
        if (map_count >= MAX_MAP_ENTRIES) return -1;
        AddressMapEntry& e = addr_map[map_count];
        e.dq4_addr = dq4;
        e.dw7_addr = dw7;
        e.size = sz;
        e.is_code = code;
        if (desc) strncpy(e.description, desc, 47);
        e.description[47] = 0;
        return map_count++;
    }

    int32_t compute_delta(uint32_t dq4_addr, uint32_t dw7_addr) {
        return (int32_t)(dw7_addr - dq4_addr);
    }

    uint32_t translate_dq4_to_dw7(uint32_t dq4_addr) {
        for (int i = 0; i < map_count; i++) {
            if (addr_map[i].dq4_addr <= dq4_addr &&
                dq4_addr < addr_map[i].dq4_addr + (uint32_t)addr_map[i].size) {
                return dq4_addr - addr_map[i].dq4_addr + addr_map[i].dw7_addr;
            }
        }
        return 0;  // Not found
    }

    uint32_t translate_dw7_to_dq4(uint32_t dw7_addr) {
        for (int i = 0; i < map_count; i++) {
            if (addr_map[i].dw7_addr <= dw7_addr &&
                dw7_addr < addr_map[i].dw7_addr + (uint32_t)addr_map[i].size) {
                return dw7_addr - addr_map[i].dw7_addr + addr_map[i].dq4_addr;
            }
        }
        return 0;
    }

    // --- DW7 Reference Loading ---
    bool load_dw7_exe(const char* path) {
        FILE* f = fopen(path, "rb");
        if (!f) return false;
        // Skip 2048-byte PS-X EXE header
        fseek(f, 2048, SEEK_SET);
        dw7_exe_size = (int)fread(dw7_exe, 1, sizeof(dw7_exe), f);
        fclose(f);
        dw7_loaded = true;
        return true;
    }

    // Compare DQ4 RAM region against DW7 EXE reference
    int verify_region(PSX_Memory& mem, uint32_t dq4_addr, int size);

    // Bulk opcode search-and-replace in RAM
    struct SearchReplace {
        uint32_t pattern;
        uint32_t mask;       // AND with instruction before comparing
        uint32_t replacement;
        const char* reason;
    };

    int bulk_search_replace(PSX_Memory& mem, uint32_t start, uint32_t end,
                            const SearchReplace* ops, int num_ops);

    // --- PC Auto-Corrector ---
    // Called when step() detects an illegal opcode or unmapped PC.
    // Returns true if correction was applied (execution should continue),
    // false if uncorrectable (should crash).
    bool auto_correct(MIPS_CPU& cpu, uint32_t bad_pc, const char* reason);

    // --- Telemetry ---
    void init_telemetry(const char* path) {
        if (telemetry_file) fclose(telemetry_file);
        telemetry_file = fopen(path, "w");
        telemetry_enabled = true;
    }

    void dump_telemetry(MIPS_CPU& cpu, PSX_Memory& mem, uint64_t instr);

    void flush_telemetry() {
        if (telemetry_file) fflush(telemetry_file);
    }

    void close_telemetry() {
        if (telemetry_file) { fclose(telemetry_file); telemetry_file = nullptr; }
    }

    // --- Bubblegum Stub Generator ---
    // When injected thread code is invalid, writes a minimal MIPS stub
    // that sets CD-ready flags and returns to caller.
    static const uint32_t BUBBLEGUM_STUB_SIZE = 40;  // 10 instructions (incl. NOP delay slot)
    void write_bubblegum_stub(PSX_Memory& mem, uint32_t addr);
    bool verify_injected_code(PSX_Memory& mem, uint32_t addr, int size);

    // --- Pre-populate known address mappings ---
    void init_known_mappings() {
        add_mapping(0x80017F00, 0x80017F00, 0xA5000, "EXE load region", true);
        add_mapping(0x800BCF00, 0x800BC700, 0x800, "EXE end gap", false);
        add_mapping(0x800D9E80, 0x800D9E80, 0x800, "Thread entry (zero-filled)", true);
        add_mapping(0x8012F3D0, 0x8012F3D0, 0x1000, "HBD pointer table target", false);
        add_mapping(0x1F801800, 0x1F801800, 0x10, "CD-ROM hardware registers", false);
    }
};

// Global instance (defined in psx_emulator_core.cpp)
extern OrchestrationEngine g_orch;

#endif // ORCHESTRATION_ENGINE_H
