#!/usr/bin/env python3
"""Verify v33 disc: tree at 0x80100000, trampoline at 0x801005C8."""
import struct

SECTOR_SIZE = 2352
USER_OFFSET = 24
USER_SIZE = 2048
EXE_LBA = 24
DISC = r'c:\LuxAura\VoidWalkers_Project\DQLOSTTRANSLATION\dq4_frankenstein_v33.bin'
TREE_FILE = r'c:\LuxAura\VoidWalkers_Project\DQLOSTTRANSLATION\dw7_hybrid_tree.bin'

def read_sector_user(f, lba):
    f.seek(lba * SECTOR_SIZE + USER_OFFSET)
    return f.read(USER_SIZE)

with open(DISC, 'rb') as f:
    hdr = read_sector_user(f, EXE_LBA)
    pc0 = struct.unpack_from('<I', hdr, 0x10)[0]
    t_addr = struct.unpack_from('<I', hdr, 0x18)[0]
    t_size = struct.unpack_from('<I', hdr, 0x1C)[0]
    
    exe = bytearray()
    total_sectors = (0x800 + t_size + 2047) // 2048
    for i in range(total_sectors):
        exe.extend(read_sector_user(f, EXE_LBA + i))
    exe = exe[:0x800 + t_size]

print(f"EXE header:")
print(f"  PC0:     0x{pc0:08X}")
print(f"  t_addr:  0x{t_addr:08X}")
print(f"  t_size:  0x{t_size:X} ({t_size})")
print()

# Copy routine
copy_ram = 0x800BCCF0
copy_file_off = copy_ram - t_addr + 0x800
copy_disc = exe[copy_file_off:copy_file_off + 52]
print(f"Copy routine at 0x{copy_ram:08X} (file 0x{copy_file_off:X}):")
for i in range(0, 52, 4):
    w = struct.unpack_from('<I', copy_disc, i)[0]
    print(f"  0x{copy_ram + i:08X}: 0x{w:08X}")

# Decode copy routine
w0 = struct.unpack_from('<I', copy_disc, 0)[0]
w1 = struct.unpack_from('<I', copy_disc, 4)[0]
w2 = struct.unpack_from('<I', copy_disc, 8)[0]
w3 = struct.unpack_from('<I', copy_disc, 12)[0]
w4 = struct.unpack_from('<I', copy_disc, 16)[0]

src_hi = w0 & 0xFFFF
src_addr = ((src_hi << 16) + struct.unpack_from('<h', struct.pack('<H', w1 & 0xFFFF))[0]) & 0xFFFFFFFF
dst_hi = w2 & 0xFFFF
dst_addr = ((dst_hi << 16) + struct.unpack_from('<h', struct.pack('<H', w3 & 0xFFFF))[0]) & 0xFFFFFFFF
payload_size = struct.unpack_from('<h', struct.pack('<H', w4 & 0xFFFF))[0]

print(f"\n  Source (t0): 0x{src_addr:08X} (should be 0x800BC700)")
print(f"  Dest   (t1): 0x{dst_addr:08X} (should be 0x80100000)")
print(f"  Payload: {payload_size} bytes (should be 1520)")

# Trampoline target
with open(TREE_FILE, 'rb') as f:
    tree_data = f.read()
tramp_dest = (dst_addr + len(tree_data) + 3) & ~3
print(f"  Trampoline dest: 0x{tramp_dest:08X} (should be 0x801005C8)")

# CD-ROM intercept
CDROM_CMD_WRITE_OFF = 0x80F64
cdrom_insn = struct.unpack_from('<I', exe, CDROM_CMD_WRITE_OFF)[0]
if (cdrom_insn >> 26) == 0x02:
    target = ((cdrom_insn & 0x3FFFFFF) << 2) | 0x80000000
    print(f"\nCD-ROM intercept: j 0x{target:08X} (should be 0x{tramp_dest:08X})")
    print(f"  Match: {target == tramp_dest}")

# BSS clear range
bss_start = 0x800BC668
bss_end = 0x800F4980
print(f"\nBSS clear range: 0x{bss_start:08X} to 0x{bss_end:08X}")
print(f"Tree dest (0x{dst_addr:08X}) in BSS range? {bss_start <= dst_addr < bss_end}")
print(f"Tramp dest (0x{tramp_dest:08X}) in BSS range? {bss_start <= tramp_dest < bss_end}")

# Check game data references
print(f"\nGame data region: 0x800F4980 - 0x800F9E54+")
print(f"Tree dest (0x{dst_addr:08X}) in game data? {0x800F4980 <= dst_addr <= 0x800FA000}")
print(f"Tramp dest (0x{tramp_dest:08X}) in game data? {0x800F4980 <= tramp_dest <= 0x800FA000}")

# Stack
print(f"\nStack: 0x801FFFF0")
print(f"Tree+tramp end: 0x{tramp_dest + 40:08X}")
print(f"Safe margin to stack: {0x801FFFF0 - (tramp_dest + 40):,} bytes")
