"""Minimal MIPS I assembler with labels and pseudo-instructions."""

import re
import struct
from typing import Dict, List, Tuple, Union

from .opcode import (
    reg_index,
    cp0_reg_index,
    OPCODES,
    SPECIAL_FUNCS,
    REGIMM_FUNCS,
    COP0_FUNCS,
    OP_SPECIAL,
    OP_REGIMM,
    OP_J,
    OP_JAL,
    OP_COP0,
)


class AssembleError(Exception):
    pass


def _s16(value: int) -> int:
    v = int(value)
    if -32768 <= v <= 32767:
        return v & 0xFFFF
    raise AssembleError(f"Signed 16-bit immediate out of range: {v}")


def _u16(value: int) -> int:
    v = int(value)
    if 0 <= v <= 0xFFFF:
        return v
    raise AssembleError(f"Unsigned 16-bit immediate out of range: {v}")


def _imm16(value: int) -> int:
    """Accept signed or unsigned 16-bit bit-patterns (e.g. -4 or 0x9164)."""
    v = int(value)
    if -32768 <= v <= 0xFFFF:
        return v & 0xFFFF
    raise AssembleError(f"16-bit immediate out of range: {v}")


def _imm_or_label(tok: str, labels: Dict[str, int], bits: int = 16, signed: bool = True) -> int:
    """Resolve a token as an immediate or label offset."""
    if tok in labels:
        raise AssembleError(f"Label '{tok}' cannot be used here; use a branch/jump instruction")
    try:
        v = int(tok, 0)
    except ValueError:
        raise AssembleError(f"Unknown symbol or invalid immediate: {tok}")
    if signed:
        return _s16(v)
    return _u16(v)


def _parse_mem_operand(tok: str) -> Tuple[int, int]:
    """Parse 'offset($reg)' and return (offset, reg_index)."""
    m = re.match(r"^([\w\-]+)\s*\(\s*\$(\w+)\s*\)$", tok)
    if not m:
        raise AssembleError(f"Invalid memory operand: {tok}")
    offset = int(m.group(1), 0)
    reg = reg_index(m.group(2))
    return offset, reg


def _split_args(args: str) -> List[str]:
    return [a.strip() for a in args.split(",") if a.strip()]


def _encode_r_type(fn: int, rd: int = 0, rs: int = 0, rt: int = 0, sa: int = 0) -> int:
    return (OP_SPECIAL << 26) | (rs << 21) | (rt << 16) | (rd << 11) | (sa << 6) | fn


def _encode_i_type(op: int, rs: int, rt: int, imm: int) -> int:
    return (op << 26) | (rs << 21) | (rt << 16) | (imm & 0xFFFF)


def _encode_j_type(op: int, target: int) -> int:
    return (op << 26) | ((target >> 2) & 0x03FFFFFF)


class AssemblerState:
    def __init__(self, base_addr: int = 0):
        self.base_addr = base_addr
        self.labels: Dict[str, int] = {}
        self.fixups: List[Tuple[int, str, str, int]] = []  # (word_idx, label, kind, abs_addr)
        self.words: List[int] = []
        self.pending_bytes: List[int] = []  # bytes waiting to be packed into words

    def current_addr(self) -> int:
        return self.base_addr + len(self.words) * 4 + len(self.pending_bytes)

    def emit(self, word: int):
        self._flush_bytes()
        self.words.append(word & 0xFFFFFFFF)

    def emit_byte(self, b: int):
        self.pending_bytes.append(b & 0xFF)
        if len(self.pending_bytes) == 4:
            self._flush_bytes()

    def _flush_bytes(self):
        while len(self.pending_bytes) >= 4:
            chunk = self.pending_bytes[:4]
            word = chunk[0] | (chunk[1] << 8) | (chunk[2] << 16) | (chunk[3] << 24)
            self.words.append(word)
            self.pending_bytes = self.pending_bytes[4:]

    def finalize(self):
        """Flush remaining pending bytes with zero padding."""
        if self.pending_bytes:
            while len(self.pending_bytes) < 4:
                self.pending_bytes.append(0)
            self._flush_bytes()


def _handle_directive(line: str, state: AssemblerState) -> None:
    """Handle GAS-style assembler directives. Most are no-ops for our raw binary output."""
    parts = line.split(None, 1)
    directive = parts[0].lower()
    args = parts[1] if len(parts) > 1 else ""

    if directive in (".set", ".global", ".globl", ".ent", ".end", ".frame",
                      ".mask", ".fmask", ".type", ".size", ".section", ".text",
                      ".data", ".bss", ".align", ".space", ".skip"):
        return  # No-op for our purposes
    elif directive == ".org":
        # Flush any pending bytes first
        state.finalize()
        try:
            new_base = int(args, 0)
        except ValueError:
            raise AssembleError(f"Invalid .org directive: {args}")
        # If jumping forward, fill with zeros
        current = state.base_addr + len(state.words) * 4
        if new_base > current:
            for _ in range((new_base - current) // 4):
                state.words.append(0)
        state.base_addr = new_base - len(state.words) * 4
        return
    elif directive == ".byte":
        for tok in args.split(","):
            tok = tok.strip()
            if tok:
                state.emit_byte(int(tok, 0) & 0xFF)
        return
    elif directive == ".half" or directive == ".short":
        for tok in args.split(","):
            tok = tok.strip()
            if tok:
                # Emit two bytes in little-endian order
                val = int(tok, 0) & 0xFFFF
                state.emit_byte(val & 0xFF)
                state.emit_byte((val >> 8) & 0xFF)
        return
    elif directive == ".word":
        for tok in args.split(","):
            tok = tok.strip()
            if not tok:
                continue
            # Try integer first
            try:
                state.emit(int(tok, 0) & 0xFFFFFFFF)
            except ValueError:
                # It's a label reference — emit placeholder + fixup
                if tok in state.labels:
                    state.emit(state.labels[tok] & 0xFFFFFFFF)
                else:
                    state.fixups.append((len(state.words), tok, "W", state.current_addr()))
                    state.emit(0)
        return
    elif directive == ".ascii":
        s = args.strip()
        if s.startswith('"') and s.endswith('"'):
            s = s[1:-1]
        for c in s:
            state.emit_byte(ord(c))
        return
    elif directive == ".asciz":
        s = args.strip()
        if s.startswith('"') and s.endswith('"'):
            s = s[1:-1]
        for c in s:
            state.emit_byte(ord(c))
        state.emit_byte(0)
        return
    # Unknown directive — skip silently
    return


def _encode_cop0(rs_code: int, rt: int, rd: int) -> int:
    """Encode a COP0 instruction (mfc0/mtc0/cfc0/ctc0)."""
    return (OP_COP0 << 26) | (rs_code << 21) | (rt << 16) | (rd << 11)


def assemble_line(line: str, state: AssemblerState) -> None:
    """Assemble one line of MIPS text. Supports labels and pseudo-instructions."""
    line = line.split("#", 1)[0].strip()
    if not line:
        return

    # Handle assembler directives (skip or process)
    if line.startswith("."):
        _handle_directive(line, state)
        return

    # Label detection: "loop:" or "main: # comment"
    if line.endswith(":"):
        label = line[:-1].strip()
        if label in state.labels:
            raise AssembleError(f"Duplicate label: {label}")
        state.labels[label] = state.current_addr()
        return

    if ":" in line.split("(")[0]:  # label on same line as instruction
        label, rest = line.split(":", 1)
        label = label.strip()
        if label in state.labels:
            raise AssembleError(f"Duplicate label: {label}")
        state.labels[label] = state.current_addr()
        line = rest.strip()
        if not line:
            return

    parts = line.split(None, 1)
    mnem = parts[0].lower()
    args = parts[1] if len(parts) > 1 else ""
    toks = _split_args(args)

    # Pseudo-instructions
    if mnem == "nop":
        state.emit(_encode_r_type(0x00, 0, 0, 0, 0))
        return
    if mnem == "li" and len(toks) == 2:
        rt = reg_index(toks[0])
        val = int(toks[1], 0)
        state.emit(_encode_i_type(0x0F, 0, rt, (val >> 16) & 0xFFFF))  # lui
        if val & 0xFFFF:
            state.emit(_encode_i_type(0x0D, rt, rt, val & 0xFFFF))  # ori
        return
    if mnem == "la" and len(toks) == 2:
        rt = reg_index(toks[0])
        # Try integer first, then label
        try:
            val = int(toks[1], 0)
        except ValueError:
            if toks[1] in state.labels:
                val = state.labels[toks[1]]
            else:
                # Forward reference — emit lui/ori with fixups
                state.emit(_encode_i_type(0x0F, 0, rt, 0))
                state.emit(_encode_i_type(0x0D, rt, rt, 0))
                state.fixups.append((len(state.words) - 2, toks[1], "LUI", state.current_addr() - 8))
                state.fixups.append((len(state.words) - 1, toks[1], "ORI", state.current_addr() - 4))
                return
        state.emit(_encode_i_type(0x0F, 0, rt, (val >> 16) & 0xFFFF))
        if val & 0xFFFF:
            state.emit(_encode_i_type(0x0D, rt, rt, val & 0xFFFF))
        return
    if mnem == "move" and len(toks) == 2:
        rd, rs = reg_index(toks[0]), reg_index(toks[1])
        state.emit(_encode_r_type(0x21, rd, rs, 0, 0))  # addu rd, rs, $zero
        return

    # Regular instructions
    if mnem in OPCODES:
        fmt, op = OPCODES[mnem]
        if fmt == "J":
            if len(toks) != 1:
                raise AssembleError(f"{mnem} expects 1 target argument")
            if toks[0] in state.labels:
                target = state.labels[toks[0]]
            else:
                try:
                    target = int(toks[0], 0)
                except ValueError:
                    state.fixups.append((len(state.words), toks[0], "J", state.current_addr()))
                    target = 0
            state.emit(_encode_j_type(op, target))
            return

        if fmt == "B":
            if len(toks) != 3:
                raise AssembleError(f"{mnem} expects 3 arguments: rs, rt, target")
            rs, rt = reg_index(toks[0]), reg_index(toks[1])
            if toks[2] in state.labels:
                offset = (state.labels[toks[2]] - (state.current_addr() + 4)) // 4
            else:
                try:
                    offset = int(toks[2], 0)
                except ValueError:
                    state.fixups.append((len(state.words), toks[2], "B", state.current_addr()))
                    offset = 0
            state.emit(_encode_i_type(op, rs, rt, _s16(offset)))
            return

        if fmt == "Bz":
            if len(toks) != 2:
                raise AssembleError(f"{mnem} expects 2 arguments: rs, target")
            rs = reg_index(toks[0])
            if toks[1] in state.labels:
                offset = (state.labels[toks[1]] - (state.current_addr() + 4)) // 4
            else:
                try:
                    offset = int(toks[1], 0)
                except ValueError:
                    state.fixups.append((len(state.words), toks[1], "B", state.current_addr()))
                    offset = 0
            state.emit(_encode_i_type(op, rs, 0, _s16(offset)))
            return

        if fmt == "I":
            if len(toks) != 2:
                raise AssembleError(f"{mnem} expects 2 arguments: rt, offset(rs)")
            rt = reg_index(toks[0])
            offset, rs = _parse_mem_operand(toks[1])
            state.emit(_encode_i_type(op, rs, rt, _imm16(offset)))  # offsets are 16-bit bit-patterns
            return

        if fmt == "Iu":
            if len(toks) != 3:
                raise AssembleError(f"{mnem} expects 3 arguments: rt, rs, imm")
            rt, rs = reg_index(toks[0]), reg_index(toks[1])
            imm = _imm_or_label(toks[2], state.labels, signed=False)
            state.emit(_encode_i_type(op, rs, rt, imm))
            return

        if fmt == "Is":
            if len(toks) != 3:
                raise AssembleError(f"{mnem} expects 3 arguments: rt, rs, imm")
            rt, rs = reg_index(toks[0]), reg_index(toks[1])
            imm = _imm_or_label(toks[2], state.labels, signed=True)
            state.emit(_encode_i_type(op, rs, rt, imm))
            return

        if fmt == "Lui":
            if len(toks) != 2:
                raise AssembleError(f"{mnem} expects 2 arguments: rt, imm")
            rt = reg_index(toks[0])
            imm = _u16(int(toks[1], 0))
            state.emit(_encode_i_type(op, 0, rt, imm))
            return

        raise AssembleError(f"Unhandled format {fmt} for {mnem}")

    if mnem in SPECIAL_FUNCS:
        fmt, fn = SPECIAL_FUNCS[mnem]
        if fmt == "R":
            if len(toks) != 3:
                raise AssembleError(f"{mnem} expects 3 arguments: rd, rs, rt")
            rd, rs, rt = reg_index(toks[0]), reg_index(toks[1]), reg_index(toks[2])
            state.emit(_encode_r_type(fn, rd, rs, rt, 0))
            return
        if fmt == "R_sa":
            if len(toks) != 3:
                raise AssembleError(f"{mnem} expects 3 arguments: rd, rt, sa")
            rd, rt, sa = reg_index(toks[0]), reg_index(toks[1]), int(toks[2], 0)
            state.emit(_encode_r_type(fn, rd, 0, rt, sa & 0x1F))
            return
        if fmt == "R_j":
            if len(toks) == 0:
                raise AssembleError(f"{mnem} expects at least 1 argument: rs")
            rs = reg_index(toks[0])
            rd = reg_index(toks[1]) if len(toks) > 1 else 31
            if mnem == "jr":
                rd = 0
            state.emit(_encode_r_type(fn, rd, rs, 0, 0))
            return
        if fmt == "R_dst":
            if len(toks) != 1:
                raise AssembleError(f"{mnem} expects 1 argument: rd")
            rd = reg_index(toks[0])
            state.emit(_encode_r_type(fn, rd, 0, 0, 0))
            return
        if fmt == "R_src":
            if len(toks) != 1:
                raise AssembleError(f"{mnem} expects 1 argument: rs")
            rs = reg_index(toks[0])
            state.emit(_encode_r_type(fn, 0, rs, 0, 0))
            return
        if fmt == "R_mul":
            if len(toks) != 2:
                raise AssembleError(f"{mnem} expects 2 arguments: rs, rt")
            rs, rt = reg_index(toks[0]), reg_index(toks[1])
            state.emit(_encode_r_type(fn, 0, rs, rt, 0))
            return
        if fmt == "R_none":
            state.emit(_encode_r_type(fn, 0, 0, 0, 0))
            return

    if mnem in REGIMM_FUNCS:
        fmt, rt_code = REGIMM_FUNCS[mnem]
        if fmt == "Bz_l":
            if len(toks) != 2:
                raise AssembleError(f"{mnem} expects 2 arguments: rs, target")
            rs = reg_index(toks[0])
            if toks[1] in state.labels:
                offset = (state.labels[toks[1]] - (state.current_addr() + 4)) // 4
            else:
                try:
                    offset = int(toks[1], 0)
                except ValueError:
                    state.fixups.append((len(state.words), toks[1], "B", state.current_addr()))
                    offset = 0
            state.emit(_encode_i_type(OP_REGIMM, rs, rt_code, _s16(offset)))
            return

    # COP0 instructions (mtc0, mfc0, ctc0, cfc0)
    if mnem in COP0_FUNCS:
        fmt, rs_code = COP0_FUNCS[mnem]
        if fmt == "COP0_m":
            if len(toks) != 2:
                raise AssembleError(f"{mnem} expects 2 arguments: rt, cp0_reg")
            rt = reg_index(toks[0])
            rd = cp0_reg_index(toks[1])
            state.emit(_encode_cop0(rs_code, rt, rd))
            return

    raise AssembleError(f"Unknown mnemonic: {mnem}")


def assemble_lines(lines: List[str], base_addr: int = 0) -> Tuple[List[int], Dict[str, int]]:
    state = AssemblerState(base_addr)
    for line in lines:
        assemble_line(line, state)

    # Flush any remaining pending bytes
    state.finalize()

    # Resolve forward references
    for idx, label, kind, abs_addr in state.fixups:
        if label not in state.labels:
            raise AssembleError(f"Undefined label: {label}")
        addr = abs_addr
        if kind == "J":
            state.words[idx] = _encode_j_type((state.words[idx] >> 26) & 0x3F, state.labels[label])
        elif kind == "B":
            offset = (state.labels[label] - (addr + 4)) // 4
            state.words[idx] = (state.words[idx] & ~0xFFFF) | (_s16(offset) & 0xFFFF)
        elif kind == "W":
            state.words[idx] = state.labels[label] & 0xFFFFFFFF
        elif kind == "LUI":
            val = state.labels[label]
            state.words[idx] = (state.words[idx] & ~0xFFFF) | ((val >> 16) & 0xFFFF)
        elif kind == "ORI":
            val = state.labels[label]
            state.words[idx] = (state.words[idx] & ~0xFFFF) | (val & 0xFFFF)

    return state.words, state.labels


def assemble(text: str, base_addr: int = 0) -> Tuple[List[int], Dict[str, int]]:
    return assemble_lines(text.strip().splitlines(), base_addr)


def assemble_to_bytes(text: str, base_addr: int = 0) -> bytes:
    words, labels = assemble(text, base_addr)
    return b"".join(struct.pack("<I", w) for w in words)
