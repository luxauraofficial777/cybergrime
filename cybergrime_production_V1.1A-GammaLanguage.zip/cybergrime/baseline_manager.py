#!/usr/bin/env python3
"""
CyberGrime Baseline Manager — Phase 3.4
Stores baseline telemetry JSON for known-good builds.
Compares new runs against baselines to flag regressions automatically.

Usage:
    python baseline_manager.py save <build_id> <telemetry.json>
    python baseline_manager.py compare <build_id> <telemetry.json>
    python baseline_manager.py list
    python baseline_manager.py diff <build_id> <telemetry.json>
"""

import json
import os
import sqlite3
import sys
from pathlib import Path

BASE_DIR = Path(__file__).parent.resolve()
DB_PATH = BASE_DIR / "test_results.db"


def init_db(db_path):
    conn = sqlite3.connect(str(db_path))
    c = conn.cursor()
    c.execute("""
        CREATE TABLE IF NOT EXISTS baselines (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            build_id TEXT NOT NULL UNIQUE,
            created_timestamp TEXT NOT NULL,
            telemetry_json TEXT NOT NULL
        )
    """)
    conn.commit()
    return conn


def load_telemetry(path):
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)


def cmd_save(conn, build_id, telemetry_path):
    telemetry = load_telemetry(telemetry_path)
    c = conn.cursor()
    c.execute("DELETE FROM baselines WHERE build_id = ?", (build_id,))
    c.execute(
        "INSERT INTO baselines (build_id, created_timestamp, telemetry_json) VALUES (?, ?, ?)",
        (build_id, __import__("time").strftime("%Y-%m-%d %H:%M:%S"), json.dumps(telemetry))
    )
    conn.commit()
    print(f"Baseline saved: {build_id} from {telemetry_path}")


def cmd_compare(conn, build_id, telemetry_path):
    c = conn.cursor()
    c.execute("SELECT telemetry_json FROM baselines WHERE build_id = ?", (build_id,))
    row = c.fetchone()
    if not row:
        print(f"No baseline found for build_id: {build_id}")
        return 1

    baseline = json.loads(row[0])
    current = load_telemetry(telemetry_path)

    regressions = []

    # Compare instruction count (within 5% tolerance)
    base_instr = baseline.get("instruction_count", 0)
    curr_instr = current.get("instruction_count", 0)
    if base_instr > 0:
        delta = abs(curr_instr - base_instr) / base_instr
        if delta > 0.05:
            regressions.append(
                f"instruction_count: {curr_instr} vs baseline {base_instr} ({delta:.1%} delta)"
            )

    # Compare VBlank count
    base_vb = baseline.get("vblank_count", 0)
    curr_vb = current.get("vblank_count", 0)
    if base_vb > 0 and curr_vb < base_vb * 0.9:
        regressions.append(
            f"vblank_count: {curr_vb} vs baseline {base_vb} (regression)"
        )

    # Compare final PC
    base_pc = baseline.get("final_pc", 0)
    curr_pc = current.get("final_pc", 0)
    if base_pc != 0 and curr_pc != base_pc:
        regressions.append(
            f"final_pc: 0x{curr_pc:08X} vs baseline 0x{base_pc:08X}"
        )

    # Compare BIOS call histogram
    base_bios = baseline.get("bios_calls", [])
    curr_bios = current.get("bios_calls", [])
    if len(base_bios) > 0:
        base_hist = {}
        for call in base_bios:
            key = f"{call.get('table', '?')}:0x{call.get('function', 0):02X}"
            base_hist[key] = base_hist.get(key, 0) + 1
        curr_hist = {}
        for call in curr_bios:
            key = f"{call.get('table', '?')}:0x{call.get('function', 0):02X}"
            curr_hist[key] = curr_hist.get(key, 0) + 1
        for key, count in base_hist.items():
            curr_count = curr_hist.get(key, 0)
            if curr_count < count * 0.5:
                regressions.append(
                    f"bios_call {key}: {curr_count} vs baseline {count} (missing calls)"
                )

    if regressions:
        print(f"REGRESSIONS DETECTED vs baseline {build_id}:")
        for r in regressions:
            print(f"  - {r}")
        return 1
    else:
        print(f"No regressions detected vs baseline {build_id}")
        return 0


def cmd_list(conn):
    c = conn.cursor()
    c.execute("SELECT build_id, created_timestamp FROM baselines ORDER BY created_timestamp DESC")
    rows = c.fetchall()
    if not rows:
        print("No baselines stored.")
        return
    print(f"{'Build ID':<30} {'Created':<20}")
    print("-" * 50)
    for build_id, ts in rows:
        print(f"{build_id:<30} {ts:<20}")


def cmd_diff(conn, build_id, telemetry_path):
    c = conn.cursor()
    c.execute("SELECT telemetry_json FROM baselines WHERE build_id = ?", (build_id,))
    row = c.fetchone()
    if not row:
        print(f"No baseline found for build_id: {build_id}")
        return 1

    baseline = json.loads(row[0])
    current = load_telemetry(telemetry_path)

    print(f"{'Field':<25} {'Baseline':<20} {'Current':<20} {'Delta':<15}")
    print("-" * 80)

    fields = ["instruction_count", "vblank_count", "final_pc", "final_status",
              "crash_reason", "duration_ms"]
    for field in fields:
        base_val = baseline.get(field, "N/A")
        curr_val = current.get(field, "N/A")
        if field == "final_pc" and isinstance(base_val, int) and isinstance(curr_val, int):
            base_str = f"0x{base_val:08X}"
            curr_str = f"0x{curr_val:08X}"
            delta = "same" if base_val == curr_val else f"diff: {curr_val - base_val:+d}"
        else:
            base_str = str(base_val)
            curr_str = str(curr_val)
            delta = "same" if base_val == curr_val else "DIFF"
        print(f"{field:<25} {base_str:<20} {curr_str:<20} {delta:<15}")

    # BIOS call histogram diff
    base_bios = baseline.get("bios_calls", [])
    curr_bios = current.get("bios_calls", [])
    base_hist = {}
    curr_hist = {}
    for call in base_bios:
        key = f"{call.get('table', '?')}:0x{call.get('function', 0):02X}"
        base_hist[key] = base_hist.get(key, 0) + 1
    for call in curr_bios:
        key = f"{call.get('table', '?')}:0x{call.get('function', 0):02X}"
        curr_hist[key] = curr_hist.get(key, 0) + 1

    all_keys = sorted(set(base_hist.keys()) | set(curr_hist.keys()))
    print(f"\nBIOS Call Histogram:")
    print(f"{'Call':<15} {'Baseline':<10} {'Current':<10} {'Delta':<10}")
    print("-" * 45)
    for key in all_keys:
        base_count = base_hist.get(key, 0)
        curr_count = curr_hist.get(key, 0)
        delta = curr_count - base_count
        marker = " ***" if abs(delta) > base_count * 0.3 and base_count > 0 else ""
        print(f"{key:<15} {base_count:<10} {curr_count:<10} {delta:+d}{marker}")


def main():
    if len(sys.argv) < 2:
        print(__doc__)
        return 1

    cmd = sys.argv[1]
    conn = init_db(DB_PATH)

    if cmd == "save" and len(sys.argv) == 4:
        cmd_save(conn, sys.argv[2], sys.argv[3])
    elif cmd == "compare" and len(sys.argv) == 4:
        return cmd_compare(conn, sys.argv[2], sys.argv[3])
    elif cmd == "list":
        cmd_list(conn)
    elif cmd == "diff" and len(sys.argv) == 4:
        cmd_diff(conn, sys.argv[2], sys.argv[3])
    else:
        print(__doc__)
        return 1

    conn.close()
    return 0


if __name__ == "__main__":
    sys.exit(main())
