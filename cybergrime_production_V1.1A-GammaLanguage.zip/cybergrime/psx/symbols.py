"""Runtime symbol table to replace hardcoded addresses per build."""

import json
from pathlib import Path
from typing import Dict, Optional, Union


class SymbolTable:
    """Name -> address lookup table loaded from a JSON/YAML file."""

    def __init__(self, path: Optional[str] = None):
        self.symbols: Dict[str, int] = {}
        if path:
            self.load(path)

    def load(self, path: str) -> None:
        with open(path, "r") as f:
            data = json.load(f)
        for name, value in data.items():
            if isinstance(value, str):
                self.symbols[name] = int(value, 0)
            elif isinstance(value, int):
                self.symbols[name] = value
            else:
                raise ValueError(f"Invalid symbol value for {name}: {value}")

    def save(self, path: str) -> None:
        out = {name: f"0x{addr:08X}" for name, addr in self.symbols.items()}
        with open(path, "w") as f:
            json.dump(out, f, indent=2)

    def resolve(self, name_or_addr: Union[str, int]) -> int:
        if isinstance(name_or_addr, int):
            return name_or_addr
        if name_or_addr in self.symbols:
            return self.symbols[name_or_addr]
        return int(name_or_addr, 0)

    def __getitem__(self, name: str) -> int:
        return self.symbols[name]

    def __setitem__(self, name: str, value: int) -> None:
        self.symbols[name] = value

    def __contains__(self, name: str) -> bool:
        return name in self.symbols


# Known DQ4/DW7 structural addresses used by the toolchain.
DEFAULT_SYMBOLS = {
    "CD_STATUS": 0x800B9164,
    "CD_INIT_PARAM": 0x800BA65C,
    "VBC2": 0x800BA294,
    "VBC1": 0x800B63D8,
    "DISP_FLAG": 0x800B5312,
    "EVT_FLAG": 0x800B679C,
    "CD_INIT_DONE": 0x800B91CC,
    "CD_READY": 0x800B91CE,
    "CD_PTR": 0x800B915C,
    "T0_PTR": 0x800B9160,
    "VBC_SAVE": 0x800B9168,
    "HBD_THREAD_ENTRY": 0x800D9E80,
    "DW7_HUFFMAN_TREE": 0x800EF1C8,
    "DECOMP_FUNC_1": 0x80073670,
    "DECOMP_FUNC_2": 0x80084BF0,
    "TEXT_CACHE_START": 0x80120000,
    "TEXT_CACHE_END": 0x80130000,
    "EXE_LOAD_ADDR": 0x80017F00,
    "BIOS_EXCEPTION_VECTOR": 0x80000080,
    "BIOS_A0_TABLE": 0x800000A0,
    "BIOS_B0_TABLE": 0x800000B0,
    "BIOS_C0_TABLE": 0x800000C0,
}


def default_table() -> SymbolTable:
    st = SymbolTable()
    st.symbols = dict(DEFAULT_SYMBOLS)
    return st
