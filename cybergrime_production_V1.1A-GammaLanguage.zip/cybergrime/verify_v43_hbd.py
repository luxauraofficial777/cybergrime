#!/usr/bin/env python3
"""Verify that v43 HBD blocks are in DW7 global-tree format.

Checks:
  - All text blocks have tree_end=0 and text_end=0 (no per-block trees)
  - All text blocks have hts=1366 (DW7 convention)
  - No DQ4 sub-block types (32, 39, 40, 42, 46) remain in file entries

Exits 0 if all checks pass, 1 otherwise.
"""
import struct
import sys
import os

BASE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DISC = os.path.join(BASE, "dq4_frankenstein_v43.bin")
HBD_LBA = 355
SECTOR_SIZE = 2352
USER_OFFSET = 24
USER_SIZE = 2048
DW7_HTS = 1366
DQ4_TYPES = {32, 39, 40, 42, 46}


def read_sector_user(f, lba):
    f.seek(lba * SECTOR_SIZE + USER_OFFSET)
    return f.read(USER_SIZE)


def main():
    if not os.path.exists(DISC):
        print(f"FAIL: Disc not found: {DISC}")
        return 1

    print(f"Verifying HBD re-encoding on {os.path.basename(DISC)}...")

    with open(DISC, 'rb') as f:
        # Read first 100 HBD sectors to find folder headers
        blocks_checked = 0
        per_block_trees_found = 0
        wrong_hts = 0
        dq4_types_found = 0
        folders_parsed = 0

        # Read sector 0 (binary header)
        sec0 = read_sector_user(f, HBD_LBA)

        for sec_idx in range(1, 200):
            sec = read_sector_user(f, HBD_LBA + sec_idx)
            if not sec or len(sec) < 16:
                break

            file_count = struct.unpack_from('<I', sec, 0)[0]
            sector_count = struct.unpack_from('<I', sec, 4)[0]
            folder_size = struct.unpack_from('<I', sec, 8)[0]

            # Check for 60010108 entry
            if sec[0] == 0x60 and sec[1] == 0x01 and sec[2] == 0x01 and sec[3] == 0x80:
                continue

            # Check for zero/padding sector
            if sec[0] == 0 and sec[1] == 0 and sec[2] == 0 and sec[3] == 0:
                continue

            # Folder header validation
            if file_count > 0 and file_count <= 1000 and sector_count > 0 and sector_count <= 1000:
                if 16 + file_count * 16 > USER_SIZE:
                    continue

                folders_parsed += 1

                # Check file entries for DQ4 types
                for fi in range(file_count):
                    fh_off = 16 + fi * 16
                    if fh_off + 16 > len(sec):
                        break
                    type_id = struct.unpack_from('<H', sec, fh_off + 14)[0]
                    if type_id in DQ4_TYPES:
                        dq4_types_found += 1
                        print(f"  FAIL: DQ4 type {type_id} found in folder at sector {HBD_LBA + sec_idx}, file {fi}")

                # Read folder data across sectors to find block headers
                folder_data = bytearray()
                for s in range(sector_count):
                    if HBD_LBA + sec_idx + s > HBD_LBA + 500:
                        break
                    folder_data.extend(read_sector_user(f, HBD_LBA + sec_idx + s))
                    if len(folder_data) >= folder_size:
                        break

                # Parse file content for block headers
                content_start = 16 + file_count * 16
                running_offset = content_start
                for fi in range(file_count):
                    fh_off = 16 + fi * 16
                    if fh_off + 16 > len(folder_data):
                        break
                    fsize = struct.unpack_from('<I', folder_data, fh_off)[0]
                    ftype = struct.unpack_from('<H', folder_data, fh_off + 14)[0]

                    if running_offset + 24 > len(folder_data):
                        running_offset += fsize
                        continue

                    # Read block header (24 bytes = 6 uint32)
                    end_val = struct.unpack_from('<I', folder_data, running_offset)[0]
                    block_id = struct.unpack_from('<I', folder_data, running_offset + 4)[0]
                    hts = struct.unpack_from('<I', folder_data, running_offset + 8)[0]
                    tree_end = struct.unpack_from('<I', folder_data, running_offset + 12)[0]
                    text_end = struct.unpack_from('<I', folder_data, running_offset + 16)[0]

                    if hts >= 24 and hts < 65536 and end_val > hts and end_val < 1048576:
                        blocks_checked += 1
                        has_per_block_tree = (tree_end != 0 and text_end != 0)

                        if has_per_block_tree:
                            per_block_trees_found += 1
                            if per_block_trees_found <= 5:
                                print(f"  FAIL: Per-block tree found at folder {folders_parsed}, file {fi}: "
                                      f"hts={hts} tree_end={tree_end} text_end={text_end}")

                        if hts != DW7_HTS and has_per_block_tree:
                            wrong_hts += 1

                    running_offset += fsize

                # Skip past this folder's sectors
                sec_idx += sector_count - 1

        print(f"\n  Folders parsed: {folders_parsed}")
        print(f"  Blocks checked: {blocks_checked}")
        print(f"  Per-block trees found: {per_block_trees_found}")
        print(f"  Wrong hts (non-{DW7_HTS}): {wrong_hts}")
        print(f"  DQ4 types found: {dq4_types_found}")

        all_pass = (per_block_trees_found == 0 and dq4_types_found == 0)

        if all_pass:
            print("\n  PASS: All checked blocks are in DW7 global-tree format")
            return 0
        else:
            print(f"\n  FAIL: {per_block_trees_found} per-block trees, {dq4_types_found} DQ4 types remain")
            return 1


if __name__ == "__main__":
    sys.exit(main())
