$j = Get-Content telemetry_graft2_50m.json -Raw | ConvertFrom-Json
Write-Host "=== GRAFT2 50M Run State ==="
Write-Host "Status: $($j.Pass_Status)"
Write-Host "Instructions: $($j.Instructions_Executed)"
Write-Host "VBlanks: $($j.VBlank_Count)"
Write-Host "Crashed: $($j.Crashed)"
Write-Host "Crash Reason: $($j.Crash_Reason)"
Write-Host "Frozen: $($j.Frozen)"
Write-Host "PC: $($j.Register_Dump.PC)"
Write-Host "SP: $($j.Register_Dump.sp)"
Write-Host "GP: $($j.Register_Dump.gp)"
Write-Host "RA: $($j.Register_Dump.ra)"
Write-Host ""
$tty = $j.TTY_Tail
Write-Host "TTY Tail (first 4000 chars):"
Write-Host $tty.Substring(0, [Math]::Min(4000, $tty.Length))
