@echo off
call "C:\Program Files (x86)\Microsoft Visual Studio\2022\BuildTools\VC\Auxiliary\Build\vcvars64.bat"
cl /LD /EHsc /O2 psx_binary_ops.cpp /Fe:psx_ops.dll /link /DEF:psx_ops.def
