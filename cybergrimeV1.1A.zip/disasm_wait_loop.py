#!/usr/bin/env python3
"""Disassemble the full VBlank wait loop at 0x80096788."""
import struct

exe_path = r'C:\LuxAura\VoidWalkers_Project\DQLOSTTRANSLATION\translation\SLUSP012.06_clean.bin'
LOAD_ADDR = 0x80017F00

with open(exe_path, 'rb') as f:
    exe = f.read()

def rd32(off):
    return struct.unpack_from('<I', exe, off)[0]

def ram_to_off(ram):
    return ram - LOAD_ADDR + 0x800

def decode(word, addr):
    op = (word >> 26) & 0x3F
    rs = (word >> 21) & 0x1F
    rt = (word >> 16) & 0x1F
    imm = word & 0xFFFF
    target = word & 0x3FFFFFF
    rd = (word >> 11) & 0x1F
    funct = word & 0x3F
    shamt = (word >> 6) & 0x1F
    regs = ['zero','at','v0','v1','a0','a1','a2','a3',
            't0','t1','t2','t3','t4','t5','t6','t7',
            's0','s1','s2','s3','s4','s5','s6','s7',
            't8','t9','k0','k1','gp','sp','fp','ra']
    simm = struct.unpack('h', struct.pack('H', imm))[0]
    
    if word == 0: return 'nop'
    if op == 0:
        if funct == 0x08: return f'jr {regs[rs]}'
        if funct == 0x09: return f'jalr {regs[rd]}, {regs[rs]}'
        if funct == 0x21: return f'addu {regs[rd]}, {regs[rs]}, {regs[rt]}'
        if funct == 0x23: return f'subu {regs[rd]}, {regs[rs]}, {regs[rt]}'
        if funct == 0x24: return f'and {regs[rd]}, {regs[rs]}, {regs[rt]}'
        if funct == 0x25: return f'or {regs[rd]}, {regs[rs]}, {regs[rt]}'
        if funct == 0x2A: return f'slt {regs[rd]}, {regs[rs]}, {regs[rt]}'
        if funct == 0x2B: return f'sltu {regs[rd]}, {regs[rs]}, {regs[rt]}'
        if funct == 0x00: return f'sll {regs[rd]}, {regs[rt]}, {shamt}'
        if funct == 0x03: return f'sra {regs[rd]}, {regs[rt]}, {shamt}'
        if funct == 0x02: return f'srl {regs[rd]}, {regs[rt]}, {shamt}'
        if funct == 0x04: return f'sllv {regs[rd]}, {regs[rt]}, {regs[rs]}'
        if funct == 0x06: return f'srlv {regs[rd]}, {regs[rt]}, {regs[rs]}'
        if funct == 0x07: return f'srav {regs[rd]}, {regs[rt]}, {regs[rs]}'
        if funct == 0x10: return f'mfhi {regs[rd]}'
        if funct == 0x12: return f'mflo {regs[rd]}'
        if funct == 0x18: return f'mult {regs[rs]}, {regs[rt]}'
        if funct == 0x19: return f'multu {regs[rs]}, {regs[rt]}'
        if funct == 0x1A: return f'div {regs[rs]}, {regs[rt]}'
        if funct == 0x1B: return f'divu {regs[rs]}, {regs[rt]}'
        if funct == 0x0C: return f'syscall'
        if funct == 0x0D: return f'break'
        return f'.word 0x{word:08X}'
    if op == 0x01:
        if rt == 0: return f'bltz {regs[rs]}, 0x{addr + 4 + (simm << 2):08X}'
        if rt == 1: return f'bgez {regs[rs]}, 0x{addr + 4 + (simm << 2):08X}'
        return f'regimm rt={rt} {regs[rs]}, 0x{addr + 4 + (simm << 2):08X}'
    if op == 0x02: return f'j 0x{(addr & 0xF0000000) | (target << 2):08X}'
    if op == 0x03: return f'jal 0x{(addr & 0xF0000000) | (target << 2):08X}'
    if op == 0x04: return f'beq {regs[rs]}, {regs[rt]}, 0x{addr + 4 + (simm << 2):08X}'
    if op == 0x05: return f'bne {regs[rs]}, {regs[rt]}, 0x{addr + 4 + (simm << 2):08X}'
    if op == 0x06: return f'blez {regs[rs]}, 0x{addr + 4 + (simm << 2):08X}'
    if op == 0x07: return f'bgtz {regs[rs]}, 0x{addr + 4 + (simm << 2):08X}'
    if op == 0x08: return f'addi {regs[rt]}, {regs[rs]}, {simm}'
    if op == 0x09: return f'addiu {regs[rt]}, {regs[rs]}, {simm}'
    if op == 0x0A: return f'slti {regs[rt]}, {regs[rs]}, {simm}'
    if op == 0x0B: return f'sltiu {regs[rt]}, {regs[rs]}, {simm}'
    if op == 0x0C: return f'andi {regs[rt]}, {regs[rs]}, 0x{imm:04X}'
    if op == 0x0D: return f'ori {regs[rt]}, {regs[rs]}, 0x{imm:04X}'
    if op == 0x0E: return f'xori {regs[rt]}, {regs[rs]}, 0x{imm:04X}'
    if op == 0x0F: return f'lui {regs[rt]}, 0x{imm:04X}'
    if op == 0x20: return f'lb {regs[rt]}, {simm}({regs[rs]})'
    if op == 0x21: return f'lh {regs[rt]}, {simm}({regs[rs]})'
    if op == 0x23: return f'lw {regs[rt]}, {simm}({regs[rs]})'
    if op == 0x24: return f'lbu {regs[rt]}, {simm}({regs[rs]})'
    if op == 0x25: return f'lhu {regs[rt]}, {simm}({regs[rs]})'
    if op == 0x28: return f'sb {regs[rt]}, {simm}({regs[rs]})'
    if op == 0x29: return f'sh {regs[rt]}, {simm}({regs[rs]})'
    if op == 0x2B: return f'sw {regs[rt]}, {simm}({regs[rs]})'
    if op == 0x10: return f'mfc0 {regs[rt]}, {rd}'
    return f'.word 0x{word:08X} (op={op:02X})'

# Full wait loop: 0x80096788 to 0x800967F4
print("=== VBlank Wait Loop (0x80096788 - 0x800967F4) ===")
loop_off = ram_to_off(0x80096788)
for i in range(28):
    off = loop_off + i * 4
    if off + 4 > len(exe): break
    word = rd32(off)
    ram = LOAD_ADDR + off - 0x800
    d = decode(word, ram)
    print(f"  0x{ram:08X}: 0x{word:08X}  {d}")

# Check the caller — who calls this wait function?
# ra = 0x800966C4, so the caller is around 0x800966B0
print(f"\n=== Caller (around RA=0x800966C4) ===")
caller_off = ram_to_off(0x800966A0)
for i in range(20):
    off = caller_off + i * 4
    if off + 4 > len(exe): break
    word = rd32(off)
    ram = LOAD_ADDR + off - 0x800
    d = decode(word, ram)
    print(f"  0x{ram:08X}: 0x{word:08X}  {d}")

# Check what's at 0x800967F8 (the function after the wait loop)
print(f"\n=== Next Function (0x800967F8) ===")
next_off = ram_to_off(0x800967F8)
for i in range(20):
    off = next_off + i * 4
    if off + 4 > len(exe): break
    word = rd32(off)
    ram = LOAD_ADDR + off - 0x800
    d = decode(word, ram)
    print(f"  0x{ram:08X}: 0x{word:08X}  {d}")

# Check what's at 0x800A1FC8 (called from wait loop at 0x800967AC)
print(f"\n=== Function 0x800A1FC8 (called from wait loop) ===")
f_off = ram_to_off(0x800A1FC8)
for i in range(16):
    off = f_off + i * 4
    if off + 4 > len(exe): break
    word = rd32(off)
    ram = LOAD_ADDR + off - 0x800
    d = decode(word, ram)
    print(f"  0x{ram:08X}: 0x{word:08X}  {d}")

# Check string at 0x80027E7C (a0 in wait loop call to 0x800A1FC8)
str_off = ram_to_off(0x80027E7C)
print(f"\n=== String at 0x80027E7C ===")
s = exe[str_off:str_off+64]
null_pos = s.find(b'\x00')
if null_pos >= 0: s = s[:null_pos]
print(f"  '{s.decode('ascii', errors='replace')}'")

# Check what called the wait function — trace back further
# The wait function starts at 0x800967F8 (based on sp setup)
# Actually, let me look at 0x80096788 — what's before it?
print(f"\n=== Before Wait Loop (0x80096760 - 0x80096788) ===")
before_off = ram_to_off(0x80096760)
for i in range(10):
    off = before_off + i * 4
    if off + 4 > len(exe): break
    word = rd32(off)
    ram = LOAD_ADDR + off - 0x800
    d = decode(word, ram)
    print(f"  0x{ram:08X}: 0x{word:08X}  {d}")
