# The DW7 EXE uses lui $rt, 0x1F80 then addiu $rt, $rt, 0x1ADx to access CDROM regs
# Let's look at the code around the CDROM command writes, especially 0x80086B18 and 0x80086B34
# which reference 0x1AD3 (command register)
# Also check 0x1AD0-0x1AD2 (parameter registers)

$exePath = 'c:\LuxAura\VoidWalkers_Project\DQLOSTTRANSLATION\translation\SLUSP012.06'
$bytes = [System.IO.File]::ReadAllBytes($exePath)
$loadAddr = 0x80017F00

# Disassemble around 0x80086B18 (file offset = 0x80086B18 - 0x80017F00 + 0x800 = 0x6EC18)
# And 0x80086B34 (file offset = 0x6EC34)
function HexDump($start, $count) {
    for ($i = 0; $i -lt $count; $i += 4) {
        $off = $start + $i
        if ($off -lt 0 -or $off + 3 -ge $bytes.Length) { continue }
        $val = [BitConverter]::ToUInt32($bytes, $off)
        $ram = $loadAddr + $off - 0x800
        Write-Host ("  0x{0:X5} R{1:X8}: 0x{2:X8}" -f $off, $ram, $val)
    }
}

Write-Host "=== Code around 0x80086B18 (CDROM cmd reg 0x1AD3) ==="
HexDump (0x6EC18 - 64) 96

Write-Host ""
Write-Host "=== Code around 0x80086B34 (CDROM cmd reg 0x1AD3) ==="
HexDump (0x6EC34 - 32) 64

# Also look at the lui 0x1F80 at 0x800867F8 which is nearby
Write-Host ""
Write-Host "=== Code around 0x800867F8 (lui 0x1F80 near CDROM area) ==="
HexDump (0x6E7F8 - 32) 128

# The FMV function is at 0x8008AEF4 (XA/STR function)
# Let's look at what code calls Setloc
# Search for addiu with 0x1AD0 (parameter register 0)
Write-Host ""
Write-Host "=== Search for 0x1AD0 in any instruction ==="
for ($i = 0x800; $i -lt $bytes.Length - 3; $i += 4) {
    $insn = [BitConverter]::ToUInt32($bytes, $i)
    $imm = $insn -band 0x0000FFFF
    if ($imm -ge 0x1AD0 -and $imm -le 0x1AD3) {
        $ram = $loadAddr + $i - 0x800
        $prev = [BitConverter]::ToUInt32($bytes, [Math]::Max($i - 4, 0))
        Write-Host ("  RAM 0x{0:X8}: 0x{1:X8} (prev=0x{2:X8}) imm=0x{3:X4}" -f $ram, $insn, $prev, $imm)
    }
}

# Also search for 0x1120 (0x1F801120 = GPU stat) to distinguish from CDROM
# The real CDROM base is 0xBF801AD0 or 0x1F801AD0
# Let's search for addiu $rt, $rt, 0x1AD0 more broadly
Write-Host ""
Write-Host "=== Search for sb/sh to offset 0x1AD0 from $rt ==="
# sb $rt, 0x1AD0($rs) = 0xA0__1AD0 where __ = rt
# But 0x1AD0 doesn't fit in signed 16-bit offset for sb... actually it does (0x1AD0 = 6864)
for ($i = 0x800; $i -lt $bytes.Length - 3; $i += 4) {
    $insn = [BitConverter]::ToUInt32($bytes, $i)
    $imm = $insn -band 0x0000FFFF
    if ($imm -ge 0x1AD0 -and $imm -le 0x1AD3) {
        $ram = $loadAddr + $i - 0x800
        $opcode = $insn -shr 26
        $prev = [BitConverter]::ToUInt32($bytes, [Math]::Max($i - 4, 0))
        $prev2 = [BitConverter]::ToUInt32($bytes, [Math]::Max($i - 8, 0))
        Write-Host ("  RAM 0x{0:X8}: op={1} 0x{2:X8} (prev=0x{3:X8} prev2=0x{4:X8}) imm=0x{5:X4}" -f $ram, $opcode, $insn, $prev, $prev2, $imm)
    }
}
