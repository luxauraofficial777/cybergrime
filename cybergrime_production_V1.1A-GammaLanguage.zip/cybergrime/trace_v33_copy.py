#!/usr/bin/env python3
"""Trace v33 copy routine and verify trampoline at 0x801005C8.

Runs CyberGrime with breakpoints at:
  1. 0x800BCCF0 (copy routine entry) — dump registers
  2. 0x800BCD1C (copy routine j to original PC0) — dump 0x80100000-0x801005F0
  3. 0x801005C8 (trampoline target) — should only be hit if CD-ROM intercept fires

Also validates each trampoline instruction against DuckStation's IsValidInstruction logic.
"""
import struct
import json
import os
import subprocess
import sys

SECTOR_SIZE = 2352
USER_OFFSET = 24
USER_SIZE = 2048
EXE_LBA = 24
T_ADDR = 0x80017F00
T_SIZE = 0xA5000
DISC = r'c:\LuxAura\VoidWalkers_Project\DQLOSTTRANSLATION\dq4_frankenstein_v33.bin'
RUNNER = r'c:\LuxAura\VoidWalkers_Project\DQLOSTTRANSLATION\cybergrime\psx_agent_runner.exe'
TELEMETRY = r'c:\LuxAura\VoidWalkers_Project\DQLOSTTRANSLATION\cybergrime\telemetry\telemetry_v33_copy.json'
TRIAGE = r'c:\LuxAura\VoidWalkers_Project\DQLOSTTRANSLATION\cybergrime\emulator_triage_v33_copy.log'

def read_sector_user(f, lba):
    f.seek(lba * SECTOR_SIZE + USER_OFFSET)
    return f.read(USER_SIZE)

# ── Valid MIPS instruction check (mirrors DuckStation's IsValidInstruction) ──

VALID_OPS = set(range(64))  # Will filter below
VALID_OPS = {
    0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08, 0x09, 0x0A, 0x0B, 0x0C, 0x0D, 0x0E, 0x0F,
    0x20, 0x21, 0x22, 0x23, 0x24, 0x25, 0x26, 0x28, 0x29, 0x2A, 0x2B, 0x2C, 0x2D, 0x2E, 0x2F,
    0x30, 0x31, 0x32, 0x33, 0x38, 0x39, 0x3A, 0x3B,
    0x10, 0x11, 0x12, 0x13,  # cop0-3
}

VALID_FUNCTS = {
    0x00, 0x02, 0x03, 0x04, 0x06, 0x07, 0x08, 0x09, 0x0C, 0x0D,
    0x10, 0x11, 0x12, 0x13, 0x18, 0x19, 0x1A, 0x1B,
    0x20, 0x21, 0x22, 0x23, 0x24, 0x25, 0x26, 0x2A, 0x2B,
}

def is_valid_instruction(word):
    op = (word >> 26) & 0x3F
    if op == 0x00:  # funct
        funct = word & 0x3F
        return funct in VALID_FUNCTS
    return op in VALID_OPS

def decode_mips(word):
    op = (word >> 26) & 0x3F
    rs = (word >> 21) & 0x1F
    rt = (word >> 16) & 0x1F
    rd = (word >> 11) & 0x1F
    shamt = (word >> 6) & 0x1F
    funct = word & 0x3F
    imm = word & 0xFFFF
    simm = imm - 0x10000 if imm >= 0x8000 else imm
    target = (word & 0x3FFFFFF) << 2

    reg_names = ['zero','at','v0','v1','a0','a1','a2','a3',
                 't0','t1','t2','t3','t4','t5','t6','t7',
                 's0','s1','s2','s3','s4','s5','s6','s7',
                 't8','t9','k0','k1','gp','sp','fp','ra']

    if op == 0x00:
        names = {0x00:'sll',0x02:'srl',0x03:'sra',0x04:'sllv',0x06:'srlv',0x07:'srav',
                 0x08:'jr',0x09:'jalr',0x0C:'syscall',0x0D:'break',
                 0x10:'mfhi',0x11:'mthi',0x12:'mflo',0x13:'mtlo',
                 0x18:'mult',0x19:'multu',0x1A:'div',0x1B:'divu',
                 0x20:'add',0x21:'addu',0x22:'sub',0x23:'subu',
                 0x24:'and',0x25:'or',0x26:'xor',0x27:'nor',
                 0x2A:'slt',0x2B:'sltu'}
        name = names.get(funct, f'funct_{funct:02x}')
        if funct in (0x00,0x02,0x03):
            return f"{name} ${reg_names[rd]},${reg_names[rt]},{shamt}"
        elif funct in (0x08,):
            return f"{name} ${reg_names[rs]}"
        elif funct in (0x09,):
            return f"{name} ${reg_names[rd]},${reg_names[rs]}"
        elif funct in (0x0C,0x0D):
            return f"{name}"
        elif funct in (0x10,0x12):
            return f"{name} ${reg_names[rd]}"
        elif funct in (0x11,0x13):
            return f"{name} ${reg_names[rs]}"
        elif funct in (0x18,0x19,0x1A,0x1B):
            return f"{name} ${reg_names[rs]},${reg_names[rt]}"
        else:
            return f"{name} ${reg_names[rd]},${reg_names[rs]},${reg_names[rt]}"
    elif op == 0x02:
        return f"j 0x{(0x80000000 | target):08X}"
    elif op == 0x03:
        return f"jal 0x{(0x80000000 | target):08X}"
    elif op == 0x04:
        return f"beq ${reg_names[rs]},${reg_names[rt]},{simm}"
    elif op == 0x05:
        return f"bne ${reg_names[rs]},${reg_names[rt]},{simm}"
    elif op == 0x09:
        return f"addiu ${reg_names[rt]},${reg_names[rs]},{simm}"
    elif op == 0x0F:
        return f"lui ${reg_names[rt]},0x{imm:04X}"
    elif op == 0x23:
        return f"lw ${reg_names[rt]},{simm}(${reg_names[rs]})"
    elif op == 0x2B:
        return f"sw ${reg_names[rt]},{simm}(${reg_names[rs]})"
    elif op == 0x28:
        return f"sb ${reg_names[rt]},{simm}(${reg_names[rs]})"
    else:
        return f"op_{op:02x} ${reg_names[rs]},${reg_names[rt]},${reg_names[rd]},{simm}"

# ── Read EXE from disc ──
print("=== Reading EXE from disc ===")
with open(DISC, 'rb') as f:
    exe = bytearray()
    total_sectors = (0x800 + T_SIZE + USER_SIZE - 1) // USER_SIZE
    for i in range(total_sectors):
        exe.extend(read_sector_user(f, EXE_LBA + i))
    exe = exe[:0x800 + T_SIZE]

pc0 = struct.unpack_from('<I', exe, 0x10)[0]
load_addr = struct.unpack_from('<I', exe, 0x18)[0]
file_size = struct.unpack_from('<I', exe, 0x1C)[0]
memfill_start = struct.unpack_from('<I', exe, 0x30)[0]
memfill_size = struct.unpack_from('<I', exe, 0x34)[0]

print(f"EXE header:")
print(f"  PC0:          0x{pc0:08X}")
print(f"  load_addr:    0x{load_addr:08X}")
print(f"  file_size:    0x{file_size:X} ({file_size})")
print(f"  memfill_start: 0x{memfill_start:08X}")
print(f"  memfill_size:  0x{memfill_size:X} ({memfill_size})")
print(f"  Load end:     0x{load_addr + file_size:08X}")
print()

# ── Find tree, trampoline, copy routine in EXE ──
# Tree is at the end of original data
# Original file_size was 0xA4800, new is 0xA5000
orig_file_size = 0xA4800
tree_ram = load_addr + orig_file_size
tree_file_off = orig_file_size + 0x800  # file offset = data offset + header

# Calculate positions directly from known layout
# Original data size = 0xA4800 (before tree/trampoline/copy were appended)
orig_data_size = 0xA4800
tree_ram_on_disc = load_addr + orig_data_size  # 0x800BC700
tree_file_off = 0x800 + orig_data_size  # 0xA5000

# Read tree size from file
hybrid_tree_path = os.path.join(os.path.dirname(__file__), '..', 'translation-tools', 'dw7_hybrid_tree.bin')
if not os.path.exists(hybrid_tree_path):
    hybrid_tree_path = os.path.join(os.path.dirname(__file__), '..', 'dw7_hybrid_tree.bin')
tree_size = os.path.getsize(hybrid_tree_path) if os.path.exists(hybrid_tree_path) else 1480

tramp_ram_on_disc = (tree_ram_on_disc + tree_size + 3) & ~3
copy_ram = tramp_ram_on_disc + 40  # 10 instructions * 4 bytes
copy_pos = copy_ram - load_addr + 0x800

print(f"Tree on disc:     RAM 0x{tree_ram_on_disc:08X} (file 0x{tree_file_off:X})")
print(f"Trampoline disc:  RAM 0x{tramp_ram_on_disc:08X}")
print(f"Copy routine:     RAM 0x{copy_ram:08X} (file 0x{copy_pos:X})")
print(f"Tree size:        {tree_size} bytes")

if copy_pos + 52 > len(exe):
    print(f"ERROR: Copy routine at file 0x{copy_pos:X} extends past EXE end 0x{len(exe):X}!")
    sys.exit(1)

# Decode copy routine
print(f"\nCopy routine (13 instructions):")
copy_words = []
for i in range(13):
    w = struct.unpack_from('<I', exe, copy_pos + i*4)[0]
    copy_words.append(w)
    valid = is_valid_instruction(w)
    print(f"  0x{copy_ram + i*4:08X}: 0x{w:08X}  {decode_mips(w):30s}  {'VALID' if valid else 'INVALID!!!'}")

# Extract source, dest, payload size from copy routine
src_hi = copy_words[0] & 0xFFFF
src_lo = copy_words[1] & 0xFFFF
src_addr = ((src_hi << 16) + (src_lo - 0x10000 if src_lo >= 0x8000 else src_lo)) & 0xFFFFFFFF

dst_hi = copy_words[2] & 0xFFFF
dst_lo = copy_words[3] & 0xFFFF
dst_addr = ((dst_hi << 16) + (dst_lo - 0x10000 if dst_lo >= 0x8000 else dst_lo)) & 0xFFFFFFFF

payload_lo = copy_words[4] & 0xFFFF
payload_size = payload_lo - 0x10000 if payload_lo >= 0x8000 else payload_lo

print(f"\n  Source:      0x{src_addr:08X}")
print(f"  Dest:        0x{dst_addr:08X}")
print(f"  Payload:     {payload_size} bytes (0x{payload_size:X})")
print(f"  Copy end:    0x{src_addr + payload_size:08X}")

# Jump target (original PC0)
j_target = (copy_words[11] & 0x3FFFFFF) << 2
j_target |= 0x80000000
print(f"  Jump target: 0x{j_target:08X} (original PC0)")

# ── Read tree and trampoline from EXE ──
# Use on-disc addresses for reading from EXE file
tramp_file_off = tramp_ram_on_disc - load_addr + 0x800
tramp_target = (dst_addr + tree_size + 3) & ~3  # relocated location

print(f"\nTree on disc:     RAM 0x{src_addr:08X} (file 0x{tree_file_off:X})")
print(f"Trampoline disc:  RAM 0x{tramp_ram_on_disc:08X} (file 0x{tramp_file_off:X})")
print(f"Trampoline dest:  RAM 0x{tramp_target:08X}")

# Read trampoline from disc
tramp_data = exe[tramp_file_off:tramp_file_off + 40]
print(f"\nTrampoline instructions (40 bytes, 10 instructions):")
for i in range(10):
    w = struct.unpack_from('<I', tramp_data, i*4)[0]
    valid = is_valid_instruction(w)
    print(f"  [{i}] 0x{w:08X}  {decode_mips(w):30s}  {'VALID' if valid else 'INVALID!!!'}")

# ── Simulate the copy: what should be at 0x801005C8 after copy? ──
print(f"\n=== Simulating copy routine ===")
# The copy routine copies payload_size bytes from src_addr to dst_addr
# After copy, trampoline is at dst_addr + tree_size = tramp_target
simulated_ram = bytearray(payload_size)
src_data = exe[tree_file_off:tree_file_off + payload_size]
simulated_ram[:len(src_data)] = src_data

print(f"After copy, trampoline at 0x{tramp_target:08X}:")
tramp_offset = tramp_target - dst_addr
for i in range(10):
    w = struct.unpack_from('<I', simulated_ram, tramp_offset + i*4)[0]
    valid = is_valid_instruction(w)
    print(f"  [{i}] 0x{w:08X}  {decode_mips(w):30s}  {'VALID' if valid else 'INVALID!!!'}")

# ── Check CD-ROM intercept ──
print(f"\n=== CD-ROM intercept ===")
# Search for j 0x801005C8 in EXE
j_target_val = (tramp_target >> 2) & 0x3FFFFFF
j_insn = (0x02 << 26) | j_target_val
print(f"Expected j instruction: 0x{j_insn:08X} (j 0x{tramp_target:08X})")

found = []
for off in range(0x800, len(exe) - 3, 4):
    w = struct.unpack_from('<I', exe, off)[0]
    if w == j_insn:
        ram = load_addr + off - 0x800
        found.append((off, ram))
        print(f"  FOUND at file 0x{off:X} (RAM 0x{ram:08X})")

if not found:
    print("  NOT FOUND!")

# ── Check BSS clear range ──
print(f"\n=== BSS clear analysis ===")
bss_start = 0x800BC668
bss_end = 0x800F4980
print(f"BSS clear: 0x{bss_start:08X} - 0x{bss_end:08X}")
print(f"Tree dest (0x{dst_addr:08X}) in BSS range? {bss_start <= dst_addr < bss_end}")
print(f"Tramp dest (0x{tramp_target:08X}) in BSS range? {bss_start <= tramp_target < bss_end}")

# ── Check memfill (EXE header BSS) ──
print(f"\n=== EXE header memfill ===")
print(f"memfill_start: 0x{memfill_start:08X}")
print(f"memfill_size: {memfill_size}")
if memfill_size > 0:
    memfill_end = memfill_start + memfill_size
    print(f"memfill range: 0x{memfill_start:08X} - 0x{memfill_end:08X}")
    print(f"Tree dest in memfill range? {memfill_start <= dst_addr < memfill_end}")
    print(f"Tramp dest in memfill range? {memfill_start <= tramp_target < memfill_end}")

# ── Check if copy routine is within loaded range ──
load_end = load_addr + file_size
print(f"\n=== Load range check ===")
print(f"Load range: 0x{load_addr:08X} - 0x{load_end:08X}")
print(f"Copy routine (0x{copy_ram:08X}) in range? {load_addr <= copy_ram < load_end}")
print(f"Copy routine end (0x{copy_ram + 52:08X}) in range? {load_addr <= copy_ram + 52 <= load_end}")
print(f"Tree on disc (0x{src_addr:08X}) in range? {load_addr <= src_addr < load_end}")
print(f"Trampoline on disc (0x{tramp_ram_on_disc:08X}) in range? {load_addr <= tramp_ram_on_disc < load_end}")

# ── Run CyberGrime with breakpoints ──
print(f"\n=== Running CyberGrime with breakpoints ===")
print(f"Breakpoints: 0x800BCCF0 (copy entry), 0x800BCD1C (copy exit j), 0x801005C8 (trampoline)")

cmd = [
    RUNNER,
    DISC,
    'v33_copy_trace',
    '5000000',  # 5M instructions
    TELEMETRY,
    '0',  # no wallclock limit
    '--triage', TRIAGE,
    '--bp', '0x800BCCF0',
    '--bp', '0x800BCD1C',
    '--bp', '0x801005C8',
]

print(f"Command: {' '.join(cmd)}")
print()

try:
    proc = subprocess.run(cmd, capture_output=True, text=True, timeout=120)
    print(f"Exit code: {proc.returncode}")
    if proc.stderr:
        print(f"stderr: {proc.stderr[:500]}")
    if proc.stdout:
        print(f"stdout (last 2000 chars): ...{proc.stdout[-2000:]}")
except subprocess.TimeoutExpired as e:
    print(f"TIMEOUT after 120s")
    if e.stdout:
        print(f"stdout (last 2000 chars): ...{e.stdout[-2000:]}")

# ── Parse telemetry ──
if os.path.exists(TELEMETRY):
    with open(TELEMETRY, 'r', encoding='utf-8', errors='replace') as f:
        tel = json.load(f)
    print(f"\n=== Telemetry ===")
    print(f"Status: {tel.get('Pass_Status', 'UNKNOWN')}")
    print(f"Instructions: {tel.get('Instructions_Executed', 0)}")
    print(f"VBlanks: {tel.get('VBlank_Count', 0)}")
    print(f"Last PC: {tel.get('Last_Known_PC', '0x00000000')}")
    print(f"Crashed: {tel.get('Crashed', False)}")
    print(f"Frozen: {tel.get('Frozen', False)}")
    if tel.get('Crashed'):
        print(f"Crash reason: {tel.get('Crash_Reason', '')}")
    if tel.get('Register_Dump'):
        print(f"Registers: {json.dumps(tel['Register_Dump'], indent=2)}")
else:
    print(f"\nNo telemetry file found at {TELEMETRY}")

# ── Parse triage log ──
if os.path.exists(TRIAGE):
    with open(TRIAGE, 'r', errors='replace') as f:
        triage = f.read()
    print(f"\n=== Triage Log (last 3000 chars) ===")
    print(triage[-3000:])
else:
    print(f"\nNo triage log found at {TRIAGE}")

print("\n=== Done ===")
