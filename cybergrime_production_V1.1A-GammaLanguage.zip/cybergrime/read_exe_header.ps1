$b = [System.IO.File]::ReadAllBytes('..\dq4_exe.bin')
$pc = [BitConverter]::ToUInt32($b, 0x10)
$load = [BitConverter]::ToUInt32($b, 0x18)
$size = [BitConverter]::ToUInt32($b, 0x1C)
$sp = [BitConverter]::ToUInt32($b, 0x30)
$gp = [BitConverter]::ToUInt32($b, 0x34)
Write-Host "PC=0x$($pc.ToString('X8')) Load=0x$($load.ToString('X8')) Size=0x$($size.ToString('X8')) SP=0x$($sp.ToString('X8')) GP=0x$($gp.ToString('X8'))"
