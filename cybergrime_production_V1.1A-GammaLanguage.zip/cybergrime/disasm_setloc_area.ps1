$exePath = 'c:\LuxAura\VoidWalkers_Project\DQLOSTTRANSLATION\translation\SLUSP012.06'
$bytes = [System.IO.File]::ReadAllBytes($exePath)
$loadAddr = 0x80017F00

$rn = @('zero','at','v0','v1','a0','a1','a2','a3','t0','t1','t2','t3','t4','t5','t6','t7','s0','s1','s2','s3','s4','s5','s6','s7','t8','t9','k0','k1','gp','sp','fp','ra')

function D($ramAddr, $count) {
    $fileOff = $ramAddr - $loadAddr + 0x800
    for ($j = 0; $j -lt $count; $j++) {
        $off = $fileOff + $j * 4
        if ($off -lt 0 -or $off + 3 -ge $bytes.Length) { Write-Host "  [oor]"; continue }
        $val = [BitConverter]::ToUInt32($bytes, $off)
        $ram = $loadAddr + $off - 0x800
        $op = $val -shr 26
        $imm = $val -band 0xFFFF
        $immS = if ($imm -ge 0x8000) { $imm - 0x10000 } else { $imm }
        $rs = ($val -shr 21) -band 0x1F; $rt = ($val -shr 16) -band 0x1F; $rd = ($val -shr 11) -band 0x1F
        $funct = $val -band 0x3F
        $rsn=$rn[$rs]; $rtn=$rn[$rt]; $rdn=$rn[$rd]
        $d = ''
        if ($val -eq 0) { $d = 'nop' }
        elseif ($op -eq 0x09) { $d = "addiu $rtn,$rsn,$immS" }
        elseif ($op -eq 0x0F) { $d = "lui $rtn,0x$($imm.ToString('X4'))" }
        elseif ($op -eq 0x0D) { $d = "ori $rtn,$rsn,0x$($imm.ToString('X4'))" }
        elseif ($op -eq 0x0C) { $d = "andi $rtn,$rsn,0x$($imm.ToString('X4'))" }
        elseif ($op -eq 0x23) { $d = "lw $rtn,0x$($imm.ToString('X4'))($rsn)" }
        elseif ($op -eq 0x21) { $d = "lh $rtn,0x$($imm.ToString('X4'))($rsn)" }
        elseif ($op -eq 0x25) { $d = "lhu $rtn,0x$($imm.ToString('X4'))($rsn)" }
        elseif ($op -eq 0x24) { $d = "lbu $rtn,0x$($imm.ToString('X4'))($rsn)" }
        elseif ($op -eq 0x20) { $d = "lb $rtn,0x$($imm.ToString('X4'))($rsn)" }
        elseif ($op -eq 0x28) { $d = "sb $rtn,0x$($imm.ToString('X4'))($rsn)" }
        elseif ($op -eq 0x29) { $d = "sh $rtn,0x$($imm.ToString('X4'))($rsn)" }
        elseif ($op -eq 0x2B) { $d = "sw $rtn,0x$($imm.ToString('X4'))($rsn)" }
        elseif ($op -eq 0x03) { $t2=($val -band 0x3FFFFFF)-shl 2; $d="jal 0x$($t2.ToString('X8'))" }
        elseif ($op -eq 0x02) { $t2=($val -band 0x3FFFFFF)-shl 2; $d="j 0x$($t2.ToString('X8'))" }
        elseif ($op -eq 0x04) { $d="beq $rsn,$rtn,+0x$($immS.ToString('X'))" }
        elseif ($op -eq 0x05) { $d="bne $rsn,$rtn,+0x$($immS.ToString('X'))" }
        elseif ($op -eq 0x00 -and $funct -eq 0x08) { $d="jr $rsn" }
        elseif ($op -eq 0x00 -and $funct -eq 0x21) { $d="addu $rdn,$rsn,$rtn" }
        elseif ($op -eq 0x00 -and $funct -eq 0x25) { $d="or $rdn,$rsn,$rtn" }
        elseif ($op -eq 0x00 -and $funct -eq 0x02) { $sh=($val -shr 6)-band 0x1F; $d="srl $rdn,$rtn,$sh" }
        elseif ($op -eq 0x00 -and $funct -eq 0x00) { $sh=($val -shr 6)-band 0x1F; $d="sll $rdn,$rtn,$sh" }
        elseif ($op -eq 0x00 -and $funct -eq 0x09) { $d="jalr $rdn,$rsn" }
        elseif ($op -eq 0x00 -and $funct -eq 0x23) { $d="subu $rdn,$rsn,$rtn" }
        elseif ($op -eq 0x00 -and $funct -eq 0x24) { $d="and $rdn,$rsn,$rtn" }
        else { $d="op=0x$($op.ToString('X2')) f=0x$($funct.ToString('X2'))" }
        Write-Host ("  0x{0:X8}: 0x{1:X8}  {2}" -f $ram, $val, $d)
    }
}

# Disassemble around 0x800A0730 (where the page fault occurred)
Write-Host "=== Code at 0x800A0700 (near page fault at 0x800A0730) ==="
D 0x800A0700 50

# Also look at what calls the Setloc. The Setloc happens after Setmode 0xA0.
# Let me find the Setmode trampoline and its callers
# Setmode = B0 func 5? Let me check the trampoline at 0x800A2170 (li t1, 0x0E = 14)
# Actually 0x0E = 14. B0-14 might be Setmode.
# But looking at the trampolines, 0x800A20F8 has t1=7, 0x800A2108 has t1=8, etc.
# These are sequential B0 function numbers.
# Let me find what calls 0x800A2168 (li t2,0xB0; jr t2; li t1,0x0E = Setmode)
Write-Host ""
Write-Host "=== Callers of Setmode trampoline at 0x800A2168 ==="
$setmodeTarget = 0x0A2168 -shr 2  # = 0x2885A
for ($i = 0x800; $i -lt $bytes.Length - 3; $i += 4) {
    $insn = [BitConverter]::ToUInt32($bytes, $i)
    $op = $insn -shr 26
    if (($op -eq 2 -or $op -eq 3) -and (($insn -band 0x3FFFFFF) -eq $setmodeTarget)) {
        $ram = $loadAddr + $i - 0x800
        $type = if ($op -eq 3) { 'jal' } else { 'j' }
        Write-Host ("  $type at RAM 0x{0:X8}" -f $ram)
        # Show 10 instructions before
        for ($k = -10; $k -le 1; $k++) {
            $off2 = $i + $k * 4
            if ($off2 -lt 0x800 -or $off2 + 3 -ge $bytes.Length) { continue }
            $val2 = [BitConverter]::ToUInt32($bytes, $off2)
            $ram2 = $loadAddr + $off2 - 0x800
            $op2 = $val2 -shr 26
            $imm2 = $val2 -band 0xFFFF
            $immS2 = if ($imm2 -ge 0x8000) { $imm2 - 0x10000 } else { $imm2 }
            $rs2 = ($val2 -shr 21) -band 0x1F; $rt2 = ($val2 -shr 16) -band 0x1F
            $rsn2=$rn[$rs2]; $rtn2=$rn[$rt2]
            $d2 = ''
            if ($val2 -eq 0) { $d2 = 'nop' }
            elseif ($op2 -eq 0x09) { $d2 = "addiu $rtn2,$rsn2,$immS2" }
            elseif ($op2 -eq 0x0F) { $d2 = "lui $rtn2,0x$($imm2.ToString('X4'))" }
            elseif ($op2 -eq 0x0D) { $d2 = "ori $rtn2,$rsn2,0x$($imm2.ToString('X4'))" }
            elseif ($op2 -eq 0x23) { $d2 = "lw $rtn2,0x$($imm2.ToString('X4'))($rsn2)" }
            elseif ($op2 -eq 0x24) { $d2 = "lbu $rtn2,0x$($imm2.ToString('X4'))($rsn2)" }
            elseif ($op2 -eq 0x28) { $d2 = "sb $rtn2,0x$($imm2.ToString('X4'))($rsn2)" }
            elseif ($op2 -eq 0x03) { $t2=($val2 -band 0x3FFFFFF)-shl 2; $d2="jal 0x$($t2.ToString('X8'))" }
            elseif ($op2 -eq 0x02) { $t2=($val2 -band 0x3FFFFFF)-shl 2; $d2="j 0x$($t2.ToString('X8'))" }
            else { $d2="op=0x$($op2.ToString('X2'))" }
            $m = if ($k -eq 0) { ' <<<' } else { '' }
            Write-Host ("    0x{0:X8}: 0x{1:X8}  {2}{3}" -f $ram2, $val2, $d2, $m)
        }
    }
}
