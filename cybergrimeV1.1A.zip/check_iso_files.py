#!/usr/bin/env python3
"""Check ISO directory of phaseC disc for HBD file names"""
import struct

def read_sector_raw(disc, lba):
    """Read raw 2352-byte sector"""
    return disc[lba * 2352: (lba + 1) * 2352]

def read_sector_data(disc, lba):
    """Read 2048-byte data sector"""
    return disc[lba * 2352 + 24: lba * 2352 + 24 + 2048]

def parse_iso_root(disc_path):
    with open(disc_path, 'rb') as f:
        disc = f.read()
    
    # PVD is at sector 16 (ISO 9660)
    pvd = read_sector_data(disc, 16)
    if pvd[0] != 1 or pvd[1:6] != b'CD001':
        print(f"  Not a valid ISO 9660 PVD: {pvd[0:6].hex()}")
        return
    
    # Root directory record at offset 156 (34 bytes)
    root_dr = pvd[156:156+34]
    root_lba = struct.unpack_from('<I', root_dr, 2)[0]
    root_size = struct.unpack_from('<I', root_dr, 10)[0]
    
    print(f"  Root directory: LBA={root_lba}, size={root_size}")
    
    # Read root directory
    root_data = bytearray()
    for i in range((root_size + 2047) // 2048):
        root_data.extend(read_sector_data(disc, root_lba + i))
    
    # Parse directory records
    pos = 0
    while pos < len(root_data):
        length = root_data[pos]
        if length == 0:
            # Pad to next sector boundary
            sector_pos = pos % 2048
            pos += 2048 - sector_pos
            if pos >= len(root_data):
                break
            continue
        
        dr = root_data[pos:pos+length]
        if len(dr) < 33:
            pos += length
            continue
        
        lba = struct.unpack_from('<I', dr, 2)[0]
        size = struct.unpack_from('<I', dr, 10)[0]
        flags = dr[25]
        name_len = dr[32]
        name = dr[33:33+name_len].decode('ascii', errors='replace')
        
        # Filter out . and .. entries
        if name not in ['\x00', '\x01']:
            print(f"    {name:40s} LBA={lba:<8d} size={size:<10d} flags=0x{flags:02X}")
        
        pos += length

print("=== PhaseC disc (dq4_phaseC_build1.bin) ===")
parse_iso_root(r'c:\LuxAura\VoidWalkers_Project\DQLOSTTRANSLATION\dq4_phaseC_build1.bin')

print("\n=== DW7 disc (DW7D1.bin) ===")
parse_iso_root(r'c:\LuxAura\VoidWalkers_Project\DQLOSTTRANSLATION\DW7D1\DW7D1.bin')

# Also check: what does the Frankenstein EXE have at the disc1/disc2 name locations?
# And check if there's a file named HBD1PS1D.Q41 on the phaseC disc
print("\n=== Checking for Q41 file on phaseC disc ===")
with open(r'c:\LuxAura\VoidWalkers_Project\DQLOSTTRANSLATION\dq4_phaseC_build1.bin', 'rb') as f:
    disc = f.read()

# Search for "HBD1PS1D.Q41" in the disc
target = b'HBD1PS1D.Q41'
pos = disc.find(target)
if pos >= 0:
    lba = pos // 2352
    print(f"  Found 'HBD1PS1D.Q41' at byte offset {pos} (sector ~{lba})")
else:
    print(f"  'HBD1PS1D.Q41' NOT FOUND on disc")

# Search for "HBD1PS1D.W71" in the disc
target = b'HBD1PS1D.W71'
pos = disc.find(target)
if pos >= 0:
    lba = pos // 2352
    print(f"  Found 'HBD1PS1D.W71' at byte offset {pos} (sector ~{lba})")
else:
    print(f"  'HBD1PS1D.W71' NOT FOUND on disc")

# Search for lowercase versions
for name in [b'hbd1ps1d.q41', b'hbd1ps1d.w71', b'HBD1PS1D.Q41', b'HBD1PS1D.W71']:
    pos = disc.find(name)
    if pos >= 0:
        print(f"  Found '{name.decode()}' at byte offset {pos}")
