#!/usr/bin/env python3
"""
F-2: Thread Blob Verification Script
Compares thread_code_blob.bin against DuckStation memory dump at 0x800D9E80-0x800DA680.

Usage:
  python verify_thread_blob.py <disc_bin> [blob_path]

If DuckStation is not available, performs a static analysis:
  1. Reads thread_code_blob.bin
  2. Extracts the MISS-1 boot stub from the disc (sector-aware)
  3. Verifies the stub copies the blob correctly (D2 fix check)
  4. Checks blob for valid MIPS instruction density
"""
import sys
import os
import struct

def read_blob(path):
    with open(path, 'rb') as f:
        return f.read()

def extract_exe_sector_aware(bin_path, start_lba=24, nbytes=700000):
    out = bytearray()
    with open(bin_path, 'rb') as f:
        lba = start_lba
        while len(out) < nbytes:
            f.seek(lba * 2352 + 24)
            chunk = f.read(2048)
            if len(chunk) < 2048:
                break
            out.extend(chunk)
            lba += 1
    return bytes(out[:nbytes])

def ram_to_offset(ram):
    return ram - 0x80017F00 + 0x800

def decode_mips_opcode(word):
    op = (word >> 26) & 0x3F
    if op == 0:
        func = word & 0x3F
        names = {0x20:'add', 0x21:'addu', 0x22:'sub', 0x23:'subu',
                 0x24:'and', 0x25:'or', 0x26:'xor', 0x27:'nor',
                 0x2A:'slt', 0x2B:'sltu', 0x00:'sll', 0x02:'srl',
                 0x03:'sra', 0x04:'sllv', 0x06:'srlv', 0x07:'srav',
                 0x08:'jr', 0x09:'jalr', 0x0C:'syscall', 0x0D:'break'}
        return f"{names.get(func, f'special_{func:02X}')} (op=0, func=0x{func:02X})"
    elif op == 0x01:
        rt = (word >> 16) & 0x1F
        return f"regimm_{rt}"
    elif op == 0x02:
        return f"j 0x{(word & 0x3FFFFFF) << 2:08X}"
    elif op == 0x03:
        return f"jal 0x{(word & 0x3FFFFFF) << 2:08X}"
    elif op == 0x04:
        return f"beq (rt={((word>>16)&0x1F)}, rs={((word>>21)&0x1F)})"
    elif op == 0x05:
        return f"bne (rt={((word>>16)&0x1F)}, rs={((word>>21)&0x1F)})"
    elif op == 0x06:
        return f"blez"
    elif op == 0x07:
        return f"bgtz"
    elif op == 0x08:
        return f"addi"
    elif op == 0x09:
        return f"addiu (rt={((word>>16)&0x1F)}, rs={((word>>21)&0x1F)}, imm={word & 0xFFFF})"
    elif op == 0x0A:
        return f"slti"
    elif op == 0x0B:
        return f"sltiu"
    elif op == 0x0C:
        return f"andi"
    elif op == 0x0D:
        return f"ori"
    elif op == 0x0E:
        return f"xori"
    elif op == 0x0F:
        return f"lui (rt={((word>>16)&0x1F)}, imm=0x{word & 0xFFFF:04X})"
    elif op == 0x20:
        return f"lb"
    elif op == 0x21:
        return f"lh"
    elif op == 0x23:
        return f"lw"
    elif op == 0x24:
        return f"lbu"
    elif op == 0x25:
        return f"lhu"
    elif op == 0x28:
        return f"sb"
    elif op == 0x29:
        return f"sh"
    elif op == 0x2B:
        return f"sw"
    return f"op=0x{op:02X}"

def analyze_blob(blob):
    print(f"\n=== Thread Blob Analysis ===")
    print(f"  Size: {len(blob)} bytes ({len(blob)//4} words)")
    print(f"  SHA-256: ", end="")
    
    import hashlib
    print(hashlib.sha256(blob).hexdigest())
    
    # Check MIPS instruction density
    valid_ops = set(range(0x20)) | {0x23, 0x24, 0x25, 0x28, 0x29, 0x2B}
    valid_count = 0
    nop_count = 0
    zero_words = 0
    
    for i in range(0, len(blob), 4):
        if i + 4 > len(blob):
            break
        word = struct.unpack('<I', blob[i:i+4])[0]
        if word == 0:
            nop_count += 1
            zero_words += 1
            continue
        op = (word >> 26) & 0x3F
        if op == 0:
            func = word & 0x3F
            if func in (0x00, 0x08, 0x09, 0x20, 0x21, 0x24, 0x25, 0x27):
                valid_count += 1
        elif op in valid_ops or op in (0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08, 0x09, 0x0A, 0x0B, 0x0C, 0x0D, 0x0E, 0x0F):
            valid_count += 1
    
    total_words = len(blob) // 4
    print(f"  Total words: {total_words}")
    print(f"  NOP/zero: {nop_count} ({nop_count*100//total_words}%)")
    print(f"  Valid MIPS: {valid_count} ({valid_count*100//total_words}%)")
    print(f"  Non-zero non-MIPS: {total_words - valid_count - nop_count} ({(total_words - valid_count - nop_count)*100//total_words}%)")
    
    # Check for common red flags
    jr_zero = 0
    for i in range(0, len(blob), 4):
        if i + 4 > len(blob):
            break
        word = struct.unpack('<I', blob[i:i+4])[0]
        if word == 0x03E00008:  # jr $ra
            pass
        if word == 0x00000008:  # jr $zero (crash)
            jr_zero += 1
    
    if jr_zero > 0:
        print(f"  ⚠ WARNING: {jr_zero} 'jr $zero' instructions found (crash hazard)")
    
    # First 16 instructions
    print(f"\n  First 16 instructions:")
    for i in range(0, min(64, len(blob)), 4):
        word = struct.unpack('<I', blob[i:i+4])[0]
        print(f"    [{i//4:2d}] 0x{word:08X}  {decode_mips_opcode(word)}")
    
    return valid_count, nop_count, total_words

def verify_miss1_stub(exe, blob):
    """Verify the MISS-1 boot copy stub in the EXE"""
    print(f"\n=== MISS-1 Boot Stub Verification ===")
    
    # PC0 is at 0x800BDF00, stub starts at file offset = ram_to_offset(0x800BDF00)
    stub_ram = 0x800BDF00
    stub_off = ram_to_offset(stub_ram)
    
    if stub_off + 52 > len(exe):
        print(f"  ERROR: Stub offset 0x{stub_off:X} beyond EXE size {len(exe)}")
        return False
    
    stub = []
    for i in range(13):
        word = struct.unpack('<I', exe[stub_off + i*4 : stub_off + i*4 + 4])[0]
        stub.append(word)
        print(f"  stub[{i:2d}] 0x{word:08X}  {decode_mips_opcode(word)}")
    
    # Verify D2 fix: stub[7] should be ADDIU (op=0x09), stub[8] should be SW (op=0x2B)
    op7 = (stub[7] >> 26) & 0x3F
    op8 = (stub[8] >> 26) & 0x3F
    
    print(f"\n  D2 check: stub[7] opcode = 0x{op7:02X} (expect 0x09 = ADDIU)")
    print(f"  D2 check: stub[8] opcode = 0x{op8:02X} (expect 0x2B = SW)")
    
    if op7 == 0x09 and op8 == 0x2B:
        print("  D2 fix: CONFIRMED (load-delay slot filled)")
    else:
        print("  D2 fix: NOT PRESENT (load-delay violation)")
        return False
    
    # Verify stub copies from blob RAM to 0x800D9E80
    # stub[0-1]: lui/addiu t0 = src (blob RAM addr)
    # stub[2-3]: lui/addiu t1 = 0x800D9E80 (dst)
    # stub[4-5]: lui/addiu t2 = 0x800DA680 (end)
    # LUI immediate is bits 15-0; ADDIU immediate is bits 15-0 (sign-extended)
    src_hi = stub[0] & 0xFFFF
    src_lo = stub[1] & 0xFFFF
    if src_lo >= 0x8000:
        src_lo -= 0x10000
    src_addr = (src_hi << 16) + src_lo

    dst_hi = stub[2] & 0xFFFF
    dst_lo = stub[3] & 0xFFFF
    if dst_lo >= 0x8000:
        dst_lo -= 0x10000
    dst_addr = (dst_hi << 16) + dst_lo

    end_hi = stub[4] & 0xFFFF
    end_lo = stub[5] & 0xFFFF
    if end_lo >= 0x8000:
        end_lo -= 0x10000
    end_addr = (end_hi << 16) + end_lo
    
    copy_size = end_addr - dst_addr
    print(f"\n  Source (blob RAM):  0x{src_addr:08X}")
    print(f"  Dest (thread RAM):  0x{dst_addr:08X}")
    print(f"  End:                0x{end_addr:08X}")
    print(f"  Copy size:          {copy_size} bytes ({copy_size//4} words)")
    
    if copy_size != len(blob):
        print(f"  ⚠ WARNING: Stub copy size ({copy_size}) != blob size ({len(blob)})")
    else:
        print(f"  Copy size matches blob size: {copy_size} bytes")
    
    # Verify jump target
    if (stub[11] >> 26) & 0x3F == 0x02:
        jump_target = (stub[11] & 0x3FFFFFF) << 2
        print(f"  Jump target (original PC0): 0x{jump_target:08X}")
    
    return True

def main():
    if len(sys.argv) < 2:
        print("Usage: python verify_thread_blob.py <disc_bin> [blob_path]")
        print("  disc_bin  - Path to Frankenstein disc .bin file")
        print("  blob_path - Path to thread_code_blob.bin (default: cybergrime/thread_code_blob.bin)")
        sys.exit(1)
    
    disc_path = sys.argv[1]
    blob_path = sys.argv[2] if len(sys.argv) > 2 else os.path.join(
        os.path.dirname(os.path.abspath(__file__)), 'thread_code_blob.bin')
    
    if not os.path.exists(disc_path):
        print(f"ERROR: Disc not found: {disc_path}")
        sys.exit(1)
    
    if not os.path.exists(blob_path):
        print(f"ERROR: Thread blob not found: {blob_path}")
        sys.exit(1)
    
    print(f"Disc:  {disc_path}")
    print(f"Blob:  {blob_path}")
    
    # 1. Read and analyze the blob
    blob = read_blob(blob_path)
    valid, nops, total = analyze_blob(blob)
    
    # 2. Extract EXE from disc (sector-aware)
    print(f"\n=== EXE Extraction (sector-aware) ===")
    exe = extract_exe_sector_aware(disc_path)
    print(f"  Extracted {len(exe)} bytes from LBA 24")
    
    # 3. Verify MISS-1 stub
    stub_ok = verify_miss1_stub(exe, blob)
    
    # 4. Summary
    print(f"\n=== F-2 Verification Summary ===")
    print(f"  Blob size:          {len(blob)} bytes")
    print(f"  MIPS density:       {valid*100//total}% ({valid}/{total} words)")
    print(f"  NOP/zero:           {nops*100//total}% ({nops}/{total} words)")
    print(f"  D2 stub fix:        {'CONFIRMED' if stub_ok else 'MISSING'}")
    
    # Verdict
    if not stub_ok:
        print("\n  VERDICT: FAIL — D2 stub fix not present in disc")
        sys.exit(1)
    
    if valid * 100 // total < 30:
        print(f"\n  VERDICT: WARNING — Low MIPS density ({valid*100//total}%), blob may not be valid code")
        print("  This is the F-2 concern: the blob at PC0 may be data, not code.")
        print("  RECOMMENDED: Build once without MISS-1 to measure its contribution.")
    else:
        print(f"\n  VERDICT: PASS — Blob has reasonable MIPS density and D2 stub is correct")
        print("  NOTE: Static analysis cannot prove runtime correctness.")
        print("  To fully verify: dump 0x800D9E80-0x800DA680 in DuckStation and compare byte-for-byte.")
    
    print("\n  DuckStation memory dump command:")
    print("    In DuckStation debug console:")
    print("    dump 0x800D9E80 0x800DA680 thread_dump.bin")
    print("  Then compare:")
    print(f"    python -c \"a=open('thread_dump.bin','rb').read(); b=open('{blob_path}','rb').read(); print('MATCH' if a==b else 'MISMATCH')\"")

if __name__ == '__main__':
    main()
