#!/usr/bin/env python3
"""Verify v34 copy routine has the NOP between lw and sw."""
import struct

DISC = r'c:\LuxAura\VoidWalkers_Project\DQLOSTTRANSLATION\dq4_frankenstein_v34.bin'
EXE_LBA = 24
SECTOR_SIZE = 2352
USER_OFFSET = 24
USER_SIZE = 2048
EXE_SIZE = 677888

exe = bytearray()
sectors_needed = (EXE_SIZE + USER_SIZE - 1) // USER_SIZE
with open(DISC, 'rb') as f:
    for i in range(sectors_needed):
        f.seek((EXE_LBA + i) * SECTOR_SIZE + USER_OFFSET)
        exe.extend(f.read(USER_SIZE))
exe = bytes(exe[:EXE_SIZE])

# Parse header
pc0 = struct.unpack_from('<I', exe, 0x10)[0]
load_addr = struct.unpack_from('<I', exe, 0x18)[0]
file_size = struct.unpack_from('<I', exe, 0x1C)[0]
print(f"PC0: 0x{pc0:08X}, load: 0x{load_addr:08X}, size: 0x{file_size:X}")

# Copy routine at file offset 0xA55F0 (RAM 0x800BCCF0)
copy_off = 0xA55F0
print(f"\nCopy routine (14 instructions):")
for i in range(14):
    w = struct.unpack_from('<I', exe, copy_off + i*4)[0]
    ram = 0x800BCCF0 + i*4
    print(f"  0x{ram:08X}: 0x{w:08X}")

# Verify the NOP is at index 6 (between lw at 5 and sw at 7)
lw = struct.unpack_from('<I', exe, copy_off + 5*4)[0]
nop = struct.unpack_from('<I', exe, copy_off + 6*4)[0]
sw = struct.unpack_from('<I', exe, copy_off + 7*4)[0]
print(f"\nlw (idx 5): 0x{lw:08X} (expect 0x8D0B0000)")
print(f"nop (idx 6): 0x{nop:08X} (expect 0x00000000)")
print(f"sw (idx 7): 0x{sw:08X} (expect 0xAD2B0000)")

# Verify bne branch offset
bne = struct.unpack_from('<I', exe, copy_off + 10*4)[0]
bne_offset = bne & 0xFFFF
if bne_offset >= 0x8000:
    bne_offset -= 0x10000
print(f"\nbne (idx 10): 0x{bne:08X}, offset={bne_offset} (expect -4)")
# bne at idx 10, target = idx 10 + 1 + offset = 11 + (-4) = 7 (sw)
print(f"  Branch target: idx {10 + 1 + bne_offset} (expect 7 = sw)")

# Verify jump target
j_insn = struct.unpack_from('<I', exe, copy_off + 12*4)[0]
j_target = (j_insn & 0x3FFFFFF) << 2
j_target |= 0x80000000
print(f"\nj (idx 12): 0x{j_insn:08X} -> 0x{j_target:08X} (expect 0x8008E284)")

# Verify trampoline is still correct
tramp_off = 0xA55C8
print(f"\nTrampoline (10 instructions):")
for i in range(10):
    w = struct.unpack_from('<I', exe, tramp_off + i*4)[0]
    print(f"  [{i}] 0x{w:08X}")

# Verify CD-ROM intercept
j_tramp = (0x02 << 26) | ((0x801005C8 >> 2) & 0x3FFFFFF)
print(f"\nCD-ROM intercept: looking for 0x{j_tramp:08X}")
for off in range(0x800, len(exe) - 3, 4):
    w = struct.unpack_from('<I', exe, off)[0]
    if w == j_tramp:
        ram = load_addr + off - 0x800
        print(f"  FOUND at file 0x{off:X} (RAM 0x{ram:08X})")
        break

print("\n✓ All checks passed!" if nop == 0 and lw == 0x8D0B0000 and sw == 0xAD2B0000 else "\n✗ CHECK FAILED!")
