#!/usr/bin/env python3
"""Check the disc-check patch at 0x800506CC and the VBlank handler setup."""
import struct

def read_sector(disc, lba):
    return disc[lba * 2352 + 24: lba * 2352 + 24 + 2048]

def read_exe_from_disc(disc_path, exe_lba, exe_size):
    with open(disc_path, 'rb') as f:
        disc = f.read()
    exe = bytearray()
    sectors = (exe_size + 2047) // 2048
    for i in range(sectors):
        exe.extend(read_sector(disc, exe_lba + i))
    return bytes(exe[:exe_size])

DISC = r'c:\LuxAura\VoidWalkers_Project\DQLOSTTRANSLATION\dq4_phaseC_build1.bin'
exe = read_exe_from_disc(DISC, 24, 960948)
DW7_DISC = r'c:\LuxAura\VoidWalkers_Project\DQLOSTTRANSLATION\DW7D1\DW7D1.bin'
dw7_exe = read_exe_from_disc(DW7_DISC, 24, 675840)

LOAD_ADDR = 0x80017F00
EXE_HEADER = 0x800

REG = ['zero','at','v0','v1','a0','a1','a2','a3','t0','t1','t2','t3','t4','t5','t6','t7','s0','s1','s2','s3','s4','s5','s6','s7','t8','t9','k0','k1','gp','sp','fp','ra']

def disasm(word, pc):
    op = (word >> 26) & 0x3f
    rs = (word >> 21) & 0x1f
    rt = (word >> 16) & 0x1f
    rd = (word >> 11) & 0x1f
    shamt = (word >> 6) & 0x1f
    funct = word & 0x3f
    imm = word & 0xffff
    simm = imm if imm < 0x8000 else imm - 0x10000
    target = (word & 0x3ffffff) << 2 | (pc & 0xf0000000)
    if word == 0: return 'nop'
    if op == 0:
        if funct == 0x20: return f'add {REG[rd]},{REG[rs]},{REG[rt]}'
        if funct == 0x21: return f'addu {REG[rd]},{REG[rs]},{REG[rt]}'
        if funct == 0x23: return f'subu {REG[rd]},{REG[rs]},{REG[rt]}'
        if funct == 0x24: return f'and {REG[rd]},{REG[rs]},{REG[rt]}'
        if funct == 0x25: return f'or {REG[rd]},{REG[rs]},{REG[rt]}'
        if funct == 0x26: return f'xor {REG[rd]},{REG[rs]},{REG[rt]}'
        if funct == 0x27: return f'nor {REG[rd]},{REG[rs]},{REG[rt]}'
        if funct == 0x08: return f'jr {REG[rs]}'
        if funct == 0x09: return f'jalr {REG[rd]},{REG[rs]}'
        if funct == 0x00: return f'sll {REG[rd]},{REG[rt]},{shamt}'
        if funct == 0x02: return f'srl {REG[rd]},{REG[rt]},{shamt}'
        if funct == 0x03: return f'sra {REG[rd]},{REG[rt]},{shamt}'
        if funct == 0x2a: return f'slt {REG[rd]},{REG[rs]},{REG[rt]}'
        if funct == 0x2b: return f'sltu {REG[rd]},{REG[rs]},{REG[rt]}'
        if funct == 0x10: return f'mfhi {REG[rd]}'
        if funct == 0x12: return f'mflo {REG[rd]}'
        if funct == 0x18: return f'mult {REG[rs]},{REG[rt]}'
        if funct == 0x19: return f'multu {REG[rs]},{REG[rt]}'
        if funct == 0x1a: return f'div {REG[rs]},{REG[rt]}'
        if funct == 0x1b: return f'divu {REG[rs]},{REG[rt]}'
        return f'.special 0x{funct:02x}'
    if op == 0x01:
        if rt == 0: return f'bltz {REG[rs]},0x{pc + 4 + simm*4:08X}'
        if rt == 1: return f'bgez {REG[rs]},0x{pc + 4 + simm*4:08X}'
        return f'.regimm 0x{rt:02x}'
    if op == 0x02: return f'j 0x{target:08X}'
    if op == 0x03: return f'jal 0x{target:08X}'
    if op == 0x04: return f'beq {REG[rs]},{REG[rt]},0x{pc + 4 + simm*4:08X}'
    if op == 0x05: return f'bne {REG[rs]},{REG[rt]},0x{pc + 4 + simm*4:08X}'
    if op == 0x06: return f'blez {REG[rs]},0x{pc + 4 + simm*4:08X}'
    if op == 0x07: return f'bgtz {REG[rs]},0x{pc + 4 + simm*4:08X}'
    if op == 0x08: return f'addi {REG[rt]},{REG[rs]},{simm}'
    if op == 0x09: return f'addiu {REG[rt]},{REG[rs]},{simm}'
    if op == 0x0a: return f'slti {REG[rt]},{REG[rs]},{simm}'
    if op == 0x0b: return f'sltiu {REG[rt]},{REG[rs]},{simm}'
    if op == 0x0c: return f'andi {REG[rt]},{REG[rs]},0x{imm:04X}'
    if op == 0x0d: return f'ori {REG[rt]},{REG[rs]},0x{imm:04X}'
    if op == 0x0e: return f'xori {REG[rt]},{REG[rs]},0x{imm:04X}'
    if op == 0x0f: return f'lui {REG[rt]},0x{imm:04X}'
    if op == 0x20: return f'lb {REG[rt]},{simm}({REG[rs]})'
    if op == 0x21: return f'lh {REG[rt]},{simm}({REG[rs]})'
    if op == 0x23: return f'lw {REG[rt]},{simm}({REG[rs]})'
    if op == 0x24: return f'lbu {REG[rt]},{simm}({REG[rs]})'
    if op == 0x25: return f'lhu {REG[rt]},{simm}({REG[rs]})'
    if op == 0x28: return f'sb {REG[rt]},{simm}({REG[rs]})'
    if op == 0x29: return f'sh {REG[rt]},{simm}({REG[rs]})'
    if op == 0x2b: return f'sw {REG[rt]},{simm}({REG[rs]})'
    return f'.unk 0x{word:08X}'

def ram_to_file(ram):
    return ram - LOAD_ADDR + EXE_HEADER

def disasm_both(frank_exe, dw7_exe, start_ram, count, label=""):
    print(f"\n=== {label}: 0x{start_ram:08X} ({count} instructions) ===")
    for i in range(count):
        ram = start_ram + i * 4
        off = ram_to_file(ram)
        fw = struct.unpack_from('<I', frank_exe, off)[0] if off < len(frank_exe) - 4 else 0
        dw = struct.unpack_from('<I', dw7_exe, off)[0] if off < len(dw7_exe) - 4 else 0
        fd = disasm(fw, ram)
        dd = disasm(dw, ram)
        marker = " *PATCHED*" if fw != dw and off < len(dw7_exe) - 4 else ""
        print(f"  0x{ram:08X}: FRANK=0x{fw:08X} {fd}{marker}")
        if fw != dw and off < len(dw7_exe) - 4:
            print(f"           DW7  =0x{dw:08X} {dd}")

# 1. Check the disc-check patch at 0x800506CC more carefully
# The patch replaced the function entry with jr ra; nop; nop
# This means the function at 0x800506CC now just returns immediately
# Let's see what the DW7 original looks like
disasm_both(exe, dw7_exe, 0x800506C0, 30, "DISC-CHECK AREA (0x800506C0)")

# 2. Check the VBlank handler setup
# The VBlank counter at 0x800B63D8 is written at 0x80096EDC and 0x80096F3C
# Let's look at the VBlank handler
disasm_both(exe, dw7_exe, 0x80096EB0, 40, "VBLANK HANDLER AREA")

# 3. Check what the init calls before the stall
# 0x8004F354: jal 0x8008E2B8 (jr ra; nop - does nothing?)
# 0x8004F360: jal 0x800A21E8 (some init)
# 0x8004F368: jal 0x800967F8 (VBlank wait - this is the first VBlank wait!)
print("\n=== FIRST VBLANK WAIT (0x800967F8) ===")
disasm_both(exe, dw7_exe, 0x800967F8, 20, "VBLANK WAIT FUNC (0x800967F8)")

# 4. Check 0x800A21E8 - this is called right before the first VBlank wait
disasm_both(exe, dw7_exe, 0x800A21E8, 30, "INIT BEFORE VBLANK (0x800A21E8)")

# 5. Check 0x8008E2B8 - called first in init
disasm_both(exe, dw7_exe, 0x8008E2B8, 10, "FIRST INIT CALL (0x8008E2B8)")

# 6. Check the syscall at 0x8008B9C0 (a0=16 = SetInterruptMask?)
disasm_both(exe, dw7_exe, 0x8008B9B0, 20, "SYSCALL AREA (a0=16)")

# 7. Check 0x800965E8 - called after first VBlank wait
disasm_both(exe, dw7_exe, 0x800965E8, 30, "POST-VBLANK INIT (0x800965E8)")

# 8. Check the CD-ROM init function
# Look for calls to CD-ROM init in the init chain
# 0x8009BD9C is called at 0x8004F378
disasm_both(exe, dw7_exe, 0x8009BD9C, 40, "CD-ROM INIT? (0x8009BD9C)")

# 9. Check 0x80051000 - called at 0x8004F380
disasm_both(exe, dw7_exe, 0x80051000, 30, "INIT CALL 0x80051000")
