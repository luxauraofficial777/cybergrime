#!/usr/bin/env python3
"""Quick diagnostic: dump all committed memory regions in DuckStation process."""
import ctypes
import ctypes.wintypes as wt
import struct
import sys
import time
import subprocess

kernel32 = ctypes.WinDLL('kernel32', use_last_error=True)

MEM_COMMIT = 0x1000
PROCESS_ALL_ACCESS = 0x1F0FFF
PAGE_READWRITE = 0x04
PAGE_EXECUTE_READWRITE = 0x40
PAGE_EXECUTE_READ = 0x20
PAGE_READONLY = 0x02
PAGE_WRITECOPY = 0x08

class MEMORY_BASIC_INFORMATION(ctypes.Structure):
    _fields_ = [
        ('BaseAddress', wt.LPVOID),
        ('AllocationBase', wt.LPVOID),
        ('AllocationProtect', wt.DWORD),
        ('__alignment1', wt.DWORD),
        ('RegionSize', ctypes.c_size_t),
        ('State', wt.DWORD),
        ('Protect', wt.DWORD),
        ('Type', wt.DWORD),
        ('__alignment2', wt.DWORD),
    ]

kernel32.OpenProcess.restype = wt.HANDLE
kernel32.OpenProcess.argtypes = [wt.DWORD, wt.BOOL, wt.DWORD]
kernel32.CloseHandle.argtypes = [wt.HANDLE]
kernel32.ReadProcessMemory.restype = wt.BOOL
kernel32.ReadProcessMemory.argtypes = [
    wt.HANDLE, wt.LPVOID, wt.LPVOID, ctypes.c_size_t,
    ctypes.POINTER(ctypes.c_size_t)
]
kernel32.VirtualQueryEx.restype = ctypes.c_size_t
kernel32.VirtualQueryEx.argtypes = [
    wt.HANDLE, wt.LPVOID, ctypes.POINTER(MEMORY_BASIC_INFORMATION),
    ctypes.c_size_t
]

prot_names = {
    0x01: "NOACCESS", 0x02: "READONLY", 0x04: "READWRITE",
    0x08: "WRITECOPY", 0x10: "EXECUTE", 0x20: "EXECUTE_READ",
    0x40: "EXECUTE_READWRITE", 0x80: "EXECUTE_WRITECOPY",
}

def main():
    exe = sys.argv[1] if len(sys.argv) > 1 else "duckstation/duckstation-qt-x64-ReleaseLTCG.exe"
    cue = sys.argv[2] if len(sys.argv) > 2 else "dq4_frankenstein_v38a.cue"
    
    proc = subprocess.Popen([exe, "-nogui", "-fastboot", cue],
                            stdout=subprocess.DEVNULL,
                            stderr=subprocess.DEVNULL)
    pid = proc.pid
    print(f"PID: {pid}")
    
    time.sleep(8)  # Let it boot
    
    handle = kernel32.OpenProcess(PROCESS_ALL_ACCESS, False, pid)
    if not handle:
        print(f"OpenProcess failed: {kernel32.GetLastError()}")
        proc.kill()
        return
    
    addr = 0
    mbi = MEMORY_BASIC_INFORMATION()
    regions = []
    
    while addr < 0x7FFFFFFFFFFF:
        size = kernel32.VirtualQueryEx(handle, ctypes.c_void_p(addr),
                                        ctypes.byref(mbi), ctypes.sizeof(mbi))
        if size == 0:
            break
        
        if mbi.State == MEM_COMMIT:
            prot = prot_names.get(mbi.Protect, f"0x{mbi.Protect:02X}")
            rsize = mbi.RegionSize
            regions.append((mbi.BaseAddress if mbi.BaseAddress else 0,
                           rsize, prot, mbi.Protect))
        
        addr += mbi.RegionSize if mbi.RegionSize > 0 else 0x1000
    
    print(f"\nTotal committed regions: {len(regions)}")
    print(f"\nRegions >= 64KB (searchable for PSX RAM):")
    print(f"{'Base':>20} {'Size':>12} {'Protection':>20}")
    print("-" * 56)
    
    for base, rsize, prot, raw_prot in regions:
        if rsize >= 0x10000:
            print(f"0x{base:016X} {rsize:#12x} {prot:>20}")
    
    # Now search for PS-X EXE in all regions >= 64KB
    EXE_SIG = b'PS-X EXE'
    print(f"\nSearching for 'PS-X EXE' signature...")
    
    for base, rsize, prot, raw_prot in regions:
        if rsize < 0x10000:
            continue
        if raw_prot not in (PAGE_READWRITE, PAGE_EXECUTE_READWRITE,
                            PAGE_EXECUTE_READ, PAGE_READONLY, PAGE_WRITECOPY):
            continue
        
        search_size = min(rsize, 0x1000000)
        chunk_size = 0x10000
        for offset in range(0, search_size - 8, chunk_size - 0x200):
            read_size = min(chunk_size, search_size - offset)
            buf = (ctypes.c_ubyte * read_size)()
            bytesRead = ctypes.c_size_t(0)
            ok = kernel32.ReadProcessMemory(handle, ctypes.c_void_p(base + offset),
                                            buf, read_size, ctypes.byref(bytesRead))
            if not ok or bytesRead.value != read_size:
                continue
            
            data = bytes(buf[:read_size])
            pos = data.find(EXE_SIG)
            if pos >= 0:
                exe_addr = base + offset + pos
                # Read header
                hdr_buf = (ctypes.c_ubyte * 0x80)()
                ok2 = kernel32.ReadProcessMemory(handle, ctypes.c_void_p(exe_addr),
                                                  hdr_buf, 0x80, ctypes.byref(bytesRead))
                if ok2 and bytesRead.value == 0x80:
                    hdr = bytes(hdr_buf[:0x80])
                    pc_val = struct.unpack_from('<I', hdr, 0x10)[0]
                    sp_val = struct.unpack_from('<I', hdr, 0x20)[0]
                    print(f"  Found at 0x{exe_addr:016X} (region 0x{base:016X} {prot})")
                    print(f"    PC=0x{pc_val:08X} SP=0x{sp_val:08X}")
                    
                    # Check if this looks like real PSX RAM
                    ram_base = exe_addr - 0x17F00
                    print(f"    Ram base would be: 0x{ram_base:016X}")
                    
                    # Try reading at 0x100000 offset
                    mid_buf = (ctypes.c_ubyte * 32)()
                    ok3 = kernel32.ReadProcessMemory(handle, ctypes.c_void_p(ram_base + 0x100000),
                                                      mid_buf, 32, ctypes.byref(bytesRead))
                    if ok3 and bytesRead.value == 32:
                        mid = bytes(mid_buf[:32])
                        utf16 = sum(1 for i in range(0, 31, 2) if mid[i+1] == 0 and 0x20 <= mid[i] <= 0x7E)
                        print(f"    Data at +0x100000: {mid[:16].hex()} (UTF-16 pairs: {utf16})")
                    else:
                        print(f"    Cannot read at +0x100000 — NOT real 2MB RAM")
    
    # Also search for BSS clear pattern
    BSS_PATTERN = struct.pack('<II', 0x24634980, 0xAC400000)
    BSS_PATTERN_PATCHED = struct.pack('<II', 0x2462CCC8, 0xAC400000)
    print(f"\nSearching for BSS clear pattern (original 0x24634980)...")
    
    for base, rsize, prot, raw_prot in regions:
        if rsize < 0x10000:
            continue
        if raw_prot not in (PAGE_READWRITE, PAGE_EXECUTE_READWRITE,
                            PAGE_EXECUTE_READ, PAGE_READONLY, PAGE_WRITECOPY):
            continue
        
        search_size = min(rsize, 0x1000000)
        chunk_size = 0x10000
        for offset in range(0, search_size - 8, chunk_size - 0x200):
            read_size = min(chunk_size, search_size - offset)
            buf = (ctypes.c_ubyte * read_size)()
            bytesRead = ctypes.c_size_t(0)
            ok = kernel32.ReadProcessMemory(handle, ctypes.c_void_p(base + offset),
                                            buf, read_size, ctypes.byref(bytesRead))
            if not ok or bytesRead.value != read_size:
                continue
            
            data = bytes(buf[:read_size])
            pos = data.find(BSS_PATTERN)
            if pos >= 0:
                addr_found = base + offset + pos
                ram_base = addr_found - 0x8E290
                print(f"  Found ORIGINAL BSS pattern at 0x{addr_found:016X} "
                      f"(region 0x{base:016X} {prot})")
                print(f"    Ram base would be: 0x{ram_base:016X}")
                
            pos2 = data.find(BSS_PATTERN_PATCHED)
            if pos2 >= 0:
                addr_found = base + offset + pos2
                ram_base = addr_found - 0x8E290
                print(f"  Found PATCHED BSS pattern at 0x{addr_found:016X} "
                      f"(region 0x{base:016X} {prot})")
                print(f"    Ram base would be: 0x{ram_base:016X}")
    
    kernel32.CloseHandle(handle)
    proc.kill()
    proc.wait()

if __name__ == '__main__':
    main()
