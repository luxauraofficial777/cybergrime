import struct

exe_path = "../translation/SLUSP012.06"
with open(exe_path, "rb") as f:
    data = f.read()

print(f"EXE size: {len(data)} bytes (0x{len(data):X})")
print()

# PSX EXE has 0x800 byte header, then code starts at file offset 0x800 = RAM 0x80017F00
# So RAM = file_offset - 0x800 + 0x80017F00
# Or: file_offset = RAM - 0x80017F00 + 0x800

def file_to_ram(foff):
    return foff - 0x800 + 0x80017F00

def ram_to_file(ram):
    return ram - 0x80017F00 + 0x800

def decode_mips(insn):
    op = (insn >> 26) & 0x3F
    rs = (insn >> 21) & 0x1F
    rt = (insn >> 16) & 0x1F
    rd = (insn >> 11) & 0x1F
    sh = (insn >> 6) & 0x1F
    fn = insn & 0x3F
    imm = insn & 0xFFFF
    simm = imm if imm < 0x8000 else imm - 0x10000
    target = insn & 0x3FFFFFF
    
    regs = ["zero","at","v0","v1","a0","a1","a2","a3",
            "t0","t1","t2","t3","t4","t5","t6","t7",
            "s0","s1","s2","s3","s4","s5","s6","s7",
            "t8","t9","k0","k1","gp","sp","fp","ra"]
    
    if insn == 0:
        return "nop"
    if op == 0x0F:
        return f"lui ${regs[rt]},0x{imm:04X}"
    if op == 0x09:
        return f"addiu ${regs[rt]},${regs[rs]},0x{imm:04X} ({simm})"
    if op == 0x08:
        return f"addi ${regs[rt]},${regs[rs]},0x{imm:04X} ({simm})"
    if op == 0x23:
        return f"lw ${regs[rt]},0x{imm:04X}(${regs[rs]})"
    if op == 0x2B:
        return f"sw ${regs[rt]},0x{imm:04X}(${regs[rs]})"
    if op == 0x0C:
        return f"andi ${regs[rt]},${regs[rs]},0x{imm:04X}"
    if op == 0x0D:
        return f"ori ${regs[rt]},${regs[rs]},0x{imm:04X}"
    if op == 0x00:
        if fn == 0x21:
            return f"addu ${regs[rd]},${regs[rs]},${regs[rt]}"
        if fn == 0x25:
            return f"or ${regs[rd]},${regs[rs]},${regs[rt]}"
        if fn == 0x08:
            return f"jr ${regs[rs]}"
        if fn == 0x00:
            return f"sll ${regs[rd]},${regs[rt]},{sh}"
        if fn == 0x02:
            return f"srl ${regs[rd]},${regs[rt]},{sh}"
        if fn == 0x03:
            return f"sra ${regs[rd]},${regs[rt]},{sh}"
        if fn == 0x2A:
            return f"slt ${regs[rd]},${regs[rs]},${regs[rt]}"
        if fn == 0x2B:
            return f"sltu ${regs[rd]},${regs[rs]},${regs[rt]}"
        if fn == 0x24:
            return f"and ${regs[rd]},${regs[rs]},${regs[rt]}"
        if fn == 0x26:
            return f"xor ${regs[rd]},${regs[rs]},${regs[rt]}"
        if fn == 0x27:
            return f"nor ${regs[rd]},${regs[rs]},${regs[rt]}"
        if fn == 0x23:
            return f"subu ${regs[rd]},${regs[rs]},${regs[rt]}"
        return f"special fn=0x{fn:02X}"
    if op == 0x04:
        return f"beq ${regs[rs]},${regs[rt]},+{simm*4+4:#x}"
    if op == 0x05:
        return f"bne ${regs[rs]},${regs[rt]},+{simm*4+4:#x}"
    if op == 0x06:
        return f"blez ${regs[rs]},+{simm*4+4:#x}"
    if op == 0x07:
        return f"bgtz ${regs[rs]},+{simm*4+4:#x}"
    if op == 0x01:
        return f"regimm rt={rt} +{simm*4+4:#x}"
    if op == 0x02:
        return f"j 0x{(target<<2):08X}"
    if op == 0x03:
        return f"jal 0x{(target<<2):08X}"
    if op == 0x0A:
        return f"slti ${regs[rt]},${regs[rs]},0x{imm:04X} ({simm})"
    if op == 0x0B:
        return f"sltiu ${regs[rt]},${regs[rs]},0x{imm:04X} ({simm})"
    if op == 0x24:
        return f"lbu ${regs[rt]},0x{imm:04X}(${regs[rs]})"
    if op == 0x20:
        return f"lb ${regs[rt]},0x{imm:04X}(${regs[rs]})"
    if op == 0x28:
        return f"sb ${regs[rt]},0x{imm:04X}(${regs[rs]})"
    if op == 0x29:
        return f"sh ${regs[rt]},0x{imm:04X}(${regs[rs]})"
    if op == 0x22:
        return f"lwl ${regs[rt]},0x{imm:04X}(${regs[rs]})"
    if op == 0x26:
        return f"lwr ${regs[rt]},0x{imm:04X}(${regs[rs]})"
    if op == 0x2A:
        return f"swl ${regs[rt]},0x{imm:04X}(${regs[rs]})"
    if op == 0x2E:
        return f"swr ${regs[rt]},0x{imm:04X}(${regs[rs]})"
    return f"op=0x{op:02X} raw=0x{insn:08X}"

def dump_at(foff, label, count=4):
    ram = file_to_ram(foff)
    print(f"--- {label} ---")
    for i in range(count):
        off = foff + i*4
        if off+4 > len(data):
            print(f"  0x{off:06X} (RAM 0x{ram+i*4:08X}): <BEYOND EOF>")
            continue
        insn = struct.unpack_from("<I", data, off)[0]
        print(f"  0x{off:06X} (RAM 0x{ram+i*4:08X}): 0x{insn:08X}  {decode_mips(insn)}")
    print()

# Dump at all hardcoded offsets
dump_at(0x4805C-4, "Site 1 (tree ptr 1) - lui+addiu", 4)
dump_at(0x480A4-4, "Site 2 (tree ptr 2) - lui+addiu", 4)
dump_at(0x4A224-4, "Site 3 (root ID) - lui+addiu", 4)
dump_at(0x1EEA8, "Offset_b mask - andi", 2)

# Tree hook location
dump_at(0x48028, "Tree hook location (0x8005F728)", 4)

# Also search for the expected patterns in the EXE
print("\n=== SIGNATURE SCAN ===\n")

# Search for lui $v0,0x800F (0x3C02800F) followed by addiu $v0,$v0,0xF1C8 (0x2442F1C8)
# This is the original DW7 tree pointer pattern
pattern1 = struct.pack("<II", 0x3C02800F, 0x2442F1C8)
print("Searching for lui $v0,0x800F + addiu $v0,$v0,0xF1C8 (original tree ptr)...")
pos = 0
while True:
    pos = data.find(pattern1, pos)
    if pos == -1:
        break
    ram = file_to_ram(pos)
    print(f"  Found at file 0x{pos:06X} (RAM 0x{ram:08X})")
    pos += 4

# Search for any lui $v0,0x800F
pattern2 = struct.pack("<I", 0x3C02800F)
print("\nSearching for lui $v0,0x800F...")
pos = 0
count = 0
while True:
    pos = data.find(pattern2, pos)
    if pos == -1:
        break
    ram = file_to_ram(pos)
    next_insn = struct.unpack_from("<I", data, pos+4)[0] if pos+8 <= len(data) else 0
    print(f"  Found at file 0x{pos:06X} (RAM 0x{ram:08X}): next=0x{next_insn:08X} {decode_mips(next_insn)}")
    pos += 4
    count += 1
    if count > 20:
        print("  ... (truncated)")
        break

# Search for andi $v0,$v0,0xFFFE (0x3042FFFE)
pattern3 = struct.pack("<I", 0x3042FFFE)
print("\nSearching for andi $v0,$v0,0xFFFE (offset_b mask)...")
pos = 0
while True:
    pos = data.find(pattern3, pos)
    if pos == -1:
        break
    ram = file_to_ram(pos)
    print(f"  Found at file 0x{pos:06X} (RAM 0x{ram:08X})")
    pos += 4

# Search for lui $v1,0x800F (0x3C03800F) - might be tree ptr with $v1
pattern4 = struct.pack("<I", 0x3C03800F)
print("\nSearching for lui $v1,0x800F...")
pos = 0
count = 0
while True:
    pos = data.find(pattern4, pos)
    if pos == -1:
        break
    ram = file_to_ram(pos)
    next_insn = struct.unpack_from("<I", data, pos+4)[0] if pos+8 <= len(data) else 0
    print(f"  Found at file 0x{pos:06X} (RAM 0x{ram:08X}): next=0x{next_insn:08X} {decode_mips(next_insn)}")
    pos += 4
    count += 1
    if count > 20:
        print("  ... (truncated)")
        break

# Search for lw $s1,12($s4) = 0x8E91000C (tree hook expected original)
pattern5 = struct.pack("<I", 0x8E91000C)
print("\nSearching for lw $s1,12($s4) (tree hook expected)...")
pos = 0
while True:
    pos = data.find(pattern5, pos)
    if pos == -1:
        break
    ram = file_to_ram(pos)
    print(f"  Found at file 0x{pos:06X} (RAM 0x{ram:08X})")
    pos += 4

# Search for sw $a0,-4($t0) = 0xAD04FFEC (tree hook actual)
pattern6 = struct.pack("<I", 0xAD04FFEC)
print("\nSearching for sw $a0,-4($t0) (what's actually at tree hook offset)...")
pos = 0
count = 0
while True:
    pos = data.find(pattern6, pos)
    if pos == -1:
        break
    ram = file_to_ram(pos)
    print(f"  Found at file 0x{pos:06X} (RAM 0x{ram:08X})")
    pos += 4
    count += 1
    if count > 10:
        break

# Also check if this is a pre-patched EXE by looking for our own patches
# Search for lui $at,0x800C (0x3C01800C) which is our tree ptr runtime patch
pattern7 = struct.pack("<I", 0x3C01800C)
print("\nSearching for lui $at,0x800C (our runtime tree ptr patch)...")
pos = 0
count = 0
while True:
    pos = data.find(pattern7, pos)
    if pos == -1:
        break
    ram = file_to_ram(pos)
    next_insn = struct.unpack_from("<I", data, pos+4)[0] if pos+8 <= len(data) else 0
    print(f"  Found at file 0x{pos:06X} (RAM 0x{ram:08X}): next=0x{next_insn:08X} {decode_mips(next_insn)}")
    pos += 4
    count += 1
    if count > 20:
        print("  ... (truncated)")
        break
