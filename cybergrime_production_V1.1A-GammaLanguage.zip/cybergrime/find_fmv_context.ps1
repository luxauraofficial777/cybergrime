$exePath = 'c:\LuxAura\VoidWalkers_Project\DQLOSTTRANSLATION\translation\SLUSP012.06'
$bytes = [System.IO.File]::ReadAllBytes($exePath)
$loadAddr = 0x80017F00

# Show context around 0x92936 — 64 bytes before and after
$center = 0x92936
Write-Host "=== Context around BCD MSF 32:34:71 at file 0x92936 ==="
for ($i = $center - 64; $i -le $center + 64; $i += 16) {
    $ram = $loadAddr + $i - 0x800
    $hex = ($bytes[$i..([Math]::Min($i+15, $bytes.Length-1))] | ForEach-Object { $_.ToString('X2') }) -join ' '
    $ascii = ($bytes[$i..([Math]::Min($i+15, $bytes.Length-1))] | ForEach-Object { if ($_ -ge 0x20 -and $_ -lt 0x7F) { [char]$_ } else { '.' } }) -join ''
    $marker = if ($i -le $center -and $center -lt $i + 16) { ' <---' } else { '' }
    Write-Host ("  0x{0:X4} (RAM 0x{1:X8}): {2}  {3}{4}" -f $i, $ram, $hex, $ascii, $marker)
}

# Also search for ALL BCD MSF patterns (3 bytes: MM SS FF in BCD)
# Look for patterns where first byte is 0x00-0x50 (minutes), second is 0x00-0x59 (seconds), third is 0x00-0x74 (frames)
Write-Host ""
Write-Host "=== All plausible BCD MSF entries near 0x92936 (±256 bytes) ==="
$searchStart = $center - 256
$searchEnd = $center + 256
for ($i = $searchStart; $i -lt $searchEnd; $i += 1) {
    $b0 = $bytes[$i]
    $b1 = $bytes[$i+1]
    $b2 = $bytes[$i+2]
    # Check BCD validity: minutes 00-50, seconds 00-59, frames 00-74
    if (($b0 -ge 0x00 -and $b0 -le 0x50) -and
        ($b1 -ge 0x00 -and $b1 -le 0x59) -and
        ($b2 -ge 0x00 -and $b2 -le 0x74)) {
        # Check BCD digits
        $m0 = ($b0 -shr 4) -band 0xF
        $m1 = $b0 -band 0xF
        $s0 = ($b1 -shr 4) -band 0xF
        $s1 = $b1 -band 0xF
        $f0 = ($b2 -shr 4) -band 0xF
        $f1 = $b2 -band 0xF
        if ($m0 -le 9 -and $m1 -le 9 -and $s0 -le 5 -and $s1 -le 9 -and $f0 -le 7 -and $f1 -le 9) {
            $ram = $loadAddr + $i - 0x800
            $m = [int]"$m0$m1"
            $s = [int]"$s0$s1"
            $f = [int]"$f0$f1"
            $lba = ($m * 60 + $s) * 75 + $f - 150
            if ($lba -gt 100 -and $lba -lt 200000) {
                Write-Host ("  file 0x{0:X} (RAM 0x{1:X8}): BCD {2:X2} {3:X2} {4:X2} = MSF {5}:{6}:{7} = LBA {8}" -f $i, $ram, $b0, $b1, $b2, $m, $s, $f, $lba)
            }
        }
    }
}
