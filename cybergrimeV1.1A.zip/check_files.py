import os
paths = [
    '../DW7D1/DW7D1.bin',
    '../translation/SLUSP012.06',
    '../translation/SLUSP012.06_disc_extract.bin',
    '../translation/SLUSP012.06_PATCHED.bin',
    '../translation/SLUSP012.06_FINAL.bin',
    '../translation/SLUSP012.06_HYBRID.bin',
    '../dq4_heart_v17.bin',
    '../Dragon Quest IV - Michibikareshi Mono Tachi (Japan).bin',
    '../frozen/dw7_hybrid_tree.bin',
    '../dw7_hybrid_tree.bin',
    '../translation/folder_mapping.json',
    '../edcre/edcre-v1.1.0-windows-x86_64-static/edcre.exe',
]
for p in paths:
    if os.path.exists(p):
        sz = os.path.getsize(p)
        print(f"  {p}: EXISTS ({sz//1024}KB)")
    else:
        print(f"  {p}: MISSING")
