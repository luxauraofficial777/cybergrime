#!/usr/bin/env python3
"""Disassemble the real allocator at 0x80098EA0 and heap init at 0x8007A330."""
import struct

EXE_PATH = r"..\translation\SLUSP012.06"
LOAD_ADDR = 0x80017F00
EXE_HDR_SIZE = 0x800

def ram_to_file(ram_addr):
    return ram_addr - LOAD_ADDR + EXE_HDR_SIZE

def file_to_ram(file_off):
    return file_off + LOAD_ADDR - EXE_HDR_SIZE

REG = ["$zero","$at","$v0","$v1","$a0","$a1","$a2","$a3",
       "$t0","$t1","$t2","$t3","$t4","$t5","$t6","$t7",
       "$s0","$s1","$s2","$s3","$s4","$s5","$s6","$s7",
       "$t8","$t9","$k0","$k1","$gp","$sp","$fp","$ra"]

def sx16(v): return v - 0x10000 if v & 0x8000 else v

def disasm(word, pc):
    op=(word>>26)&0x3F; rs=(word>>21)&0x1F; rt=(word>>16)&0x1F
    rd=(word>>11)&0x1F; sa=(word>>6)&0x1F; fn=word&0x3F
    imm=word&0xFFFF; simm=sx16(imm); tgt=word&0x3FFFFFF
    if op==0:
        if word==0: return "nop"
        if fn==0x20: return f"add {REG[rd]},{REG[rs]},{REG[rt]}"
        if fn==0x21: return f"addu {REG[rd]},{REG[rs]},{REG[rt]}"
        if fn==0x23: return f"subu {REG[rd]},{REG[rs]},{REG[rt]}"
        if fn==0x24: return f"and {REG[rd]},{REG[rs]},{REG[rt]}"
        if fn==0x25: return f"or {REG[rd]},{REG[rs]},{REG[rt]}"
        if fn==0x27: return f"nor {REG[rd]},{REG[rs]},{REG[rt]}"
        if fn==0x2A: return f"slt {REG[rd]},{REG[rs]},{REG[rt]}"
        if fn==0x2B: return f"sltu {REG[rd]},{REG[rs]},{REG[rt]}"
        if fn==0x00: return f"sll {REG[rd]},{REG[rt]},{sa}"
        if fn==0x02: return f"srl {REG[rd]},{REG[rt]},{sa}"
        if fn==0x03: return f"sra {REG[rd]},{REG[rt]},{sa}"
        if fn==0x04: return f"sllv {REG[rd]},{REG[rt]},{REG[rs]}"
        if fn==0x06: return f"srlv {REG[rd]},{REG[rt]},{REG[rs]}"
        if fn==0x07: return f"srav {REG[rd]},{REG[rt]},{REG[rs]}"
        if fn==0x08: return f"jr {REG[rs]}"
        if fn==0x09: return f"jalr {REG[rd]},{REG[rs]}"
        if fn==0x10: return f"mfhi {REG[rd]}"
        if fn==0x12: return f"mflo {REG[rd]}"
        if fn==0x18: return f"mult {REG[rs]},{REG[rt]}"
        if fn==0x19: return f"multu {REG[rs]},{REG[rt]}"
        if fn==0x1A: return f"div {REG[rs]},{REG[rt]}"
        if fn==0x1B: return f"divu {REG[rs]},{REG[rt]}"
        return f".special 0x{fn:02x}"
    if op==0x01:
        if rt==0: return f"bltz {REG[rs]},0x{pc+4+simm*4:08X}"
        if rt==1: return f"bgez {REG[rs]},0x{pc+4+simm*4:08X}"
        return f".regimm 0x{rt:02x}"
    if op==0x02: return f"j 0x{(pc&0xF0000000)|(tgt<<2):08X}"
    if op==0x03: return f"jal 0x{(pc&0xF0000000)|(tgt<<2):08X}"
    if op==0x04: return f"beq {REG[rs]},{REG[rt]},0x{pc+4+simm*4:08X}"
    if op==0x05: return f"bne {REG[rs]},{REG[rt]},0x{pc+4+simm*4:08X}"
    if op==0x06: return f"blez {REG[rs]},0x{pc+4+simm*4:08X}"
    if op==0x07: return f"bgtz {REG[rs]},0x{pc+4+simm*4:08X}"
    if op==0x08: return f"addi {REG[rt]},{REG[rs]},{simm}"
    if op==0x09: return f"addiu {REG[rt]},{REG[rs]},{simm}"
    if op==0x0A: return f"slti {REG[rt]},{REG[rs]},{simm}"
    if op==0x0B: return f"sltiu {REG[rt]},{REG[rs]},{simm}"
    if op==0x0C: return f"andi {REG[rt]},{REG[rs]},0x{imm:04X}"
    if op==0x0D: return f"ori {REG[rt]},{REG[rs]},0x{imm:04X}"
    if op==0x0E: return f"xori {REG[rt]},{REG[rs]},0x{imm:04X}"
    if op==0x0F: return f"lui {REG[rt]},0x{imm:04X}"
    if op==0x20: return f"lb {REG[rt]},{simm}({REG[rs]})"
    if op==0x21: return f"lh {REG[rt]},{simm}({REG[rs]})"
    if op==0x23: return f"lw {REG[rt]},{simm}({REG[rs]})"
    if op==0x24: return f"lbu {REG[rt]},{simm}({REG[rs]})"
    if op==0x25: return f"lhu {REG[rt]},{simm}({REG[rs]})"
    if op==0x28: return f"sb {REG[rt]},{simm}({REG[rs]})"
    if op==0x29: return f"sh {REG[rt]},{simm}({REG[rs]})"
    if op==0x2B: return f"sw {REG[rt]},{simm}({REG[rs]})"
    return f".word 0x{word:08X}"

def main():
    with open(EXE_PATH,"rb") as f: data=f.read()
    print(f"EXE: {len(data)} bytes")

    # Allocator at 0x80098EA0
    start=0x80098EA0
    fo=ram_to_file(start)
    print(f"\n=== ALLOCATOR 0x{start:08X} ===")
    for i in range(120):
        o=fo+i*4
        if o+4>len(data): break
        w=struct.unpack_from("<I",data,o)[0]
        pc=start+i*4
        print(f"  0x{pc:08X}: {w:08X}  {disasm(w,pc)}")

    # Heap init at 0x8007A330 (just before descriptor init)
    print(f"\n=== HEAP INIT 0x8007A320 ===")
    start2=0x8007A320
    fo2=ram_to_file(start2)
    for i in range(20):
        o=fo2+i*4
        if o+4>len(data): break
        w=struct.unpack_from("<I",data,o)[0]
        pc=start2+i*4
        print(f"  0x{pc:08X}: {w:08X}  {disasm(w,pc)}")

    # Find all references to 0x800D9A28 (heap bump pointer)
    print(f"\n=== References to 0x800D9A28 (heap base) ===")
    for o in range(EXE_HDR_SIZE, len(data)-4, 4):
        w=struct.unpack_from("<I",data,o)[0]
        op=(w>>26)&0x3F
        if op==0x0F:  # lui
            imm=w&0xFFFF
            if imm==0x800D:
                rt=(w>>16)&0x1F
                # Check next few instructions for sw/lw with 0x9A28
                for j in range(1,8):
                    no=o+j*4
                    if no+4>len(data): break
                    nw=struct.unpack_from("<I",data,no)[0]
                    nimm=nw&0xFFFF
                    if nimm==0x9A28 or (nimm>=0x9A00 and nimm<=0x9A50):
                        nrs=(nw>>21)&0x1F
                        nrt=(nw>>16)&0x1F
                        if nrs==rt or nrt==rt:
                            ram=file_to_ram(no)
                            print(f"  0x{ram:08X}: {nw:08X}  {disasm(nw,ram)}")

    # Search for 0x80190000 references (heap base value)
    print(f"\n=== All lui 0x8019 references ===")
    for o in range(EXE_HDR_SIZE, len(data)-4, 4):
        w=struct.unpack_from("<I",data,o)[0]
        op=(w>>26)&0x3F
        if op==0x0F and (w&0xFFFF)==0x8019:
            rt=(w>>16)&0x1F
            ram=file_to_ram(o)
            print(f"  0x{ram:08X}: lui {REG[rt]}, 0x8019")
            for j in range(1,4):
                no=o+j*4
                if no+4>len(data): break
                nw=struct.unpack_from("<I",data,no)[0]
                nram=file_to_ram(no)
                print(f"    0x{nram:08X}: {nw:08X}  {disasm(nw,nram)}")

if __name__=="__main__":
    main()
