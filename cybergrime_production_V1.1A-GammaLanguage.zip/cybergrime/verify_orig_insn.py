#!/usr/bin/env python3
"""Verify original instructions at the new intercept point 0x80098608 (file offset 0x80F08)."""
import struct
from capstone import Cs, CS_ARCH_MIPS, CS_MODE_MIPS32, CS_MODE_LITTLE_ENDIAN

EXE_PATH = r"c:\LuxAura\VoidWalkers_Project\DQLOSTTRANSLATION\translation\SLUSP012.06"

with open(EXE_PATH, "rb") as f:
    data = f.read()

# File offset for 0x80098608 = (0x80098608 - 0x80017F00) + 0x800 = 0x80F08
offset = 0x80F08
insn0 = struct.unpack("<I", data[offset:offset+4])[0]
insn1 = struct.unpack("<I", data[offset+4:offset+8])[0]

print(f"Original instruction at 0x80098608 (file 0x{offset:X}): 0x{insn0:08X}")
print(f"Original instruction at 0x8009860C (file 0x{offset+4:X}): 0x{insn1:08X}")

md = Cs(CS_ARCH_MIPS, CS_MODE_MIPS32 | CS_MODE_LITTLE_ENDIAN)
for d in md.disasm(struct.pack("<II", insn0, insn1), 0x80098608):
    print(f"  0x{d.address:08X}: {d.mnemonic} {d.op_str}")

# Expected: sb $zero, ($v0) = 0xA0400000, addiu $v0, $v1, 0x100 = 0x24620100
print(f"\nExpected: 0xA0400000 (sb $zero, ($v0)) — got 0x{insn0:08X} — {'MATCH' if insn0 == 0xA0400000 else 'MISMATCH'}")
print(f"Expected: 0x24620100 (addiu $v0, $v1, 0x100) — got 0x{insn1:08X} — {'MATCH' if insn1 == 0x24620100 else 'MISMATCH'}")
