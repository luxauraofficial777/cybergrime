#!/usr/bin/env python3
"""Disassemble main init at 0x8004F344 and trace boot flow."""
import struct

exe_path = r'C:\LuxAura\VoidWalkers_Project\DQLOSTTRANSLATION\translation\SLUSP012.06_clean.bin'
LOAD_ADDR = 0x80017F00

with open(exe_path, 'rb') as f:
    exe = f.read()

def rd32(off):
    return struct.unpack_from('<I', exe, off)[0]

def ram_to_off(ram):
    return ram - LOAD_ADDR + 0x800

def decode(word, addr):
    op = (word >> 26) & 0x3F
    rs = (word >> 21) & 0x1F
    rt = (word >> 16) & 0x1F
    imm = word & 0xFFFF
    target = word & 0x3FFFFFF
    rd = (word >> 11) & 0x1F
    funct = word & 0x3F
    shamt = (word >> 6) & 0x1F
    regs = ['zero','at','v0','v1','a0','a1','a2','a3',
            't0','t1','t2','t3','t4','t5','t6','t7',
            's0','s1','s2','s3','s4','s5','s6','s7',
            't8','t9','k0','k1','gp','sp','fp','ra']
    simm = struct.unpack('h', struct.pack('H', imm))[0]
    
    if word == 0: return 'nop'
    if op == 0:
        if funct == 0x08: return f'jr {regs[rs]}'
        if funct == 0x09: return f'jalr {regs[rd]}, {regs[rs]}'
        if funct == 0x21: return f'addu {regs[rd]}, {regs[rs]}, {regs[rt]}'
        if funct == 0x23: return f'subu {regs[rd]}, {regs[rs]}, {regs[rt]}'
        if funct == 0x24: return f'and {regs[rd]}, {regs[rs]}, {regs[rt]}'
        if funct == 0x25: return f'or {regs[rd]}, {regs[rs]}, {regs[rt]}'
        if funct == 0x2A: return f'slt {regs[rd]}, {regs[rs]}, {regs[rt]}'
        if funct == 0x2B: return f'sltu {regs[rd]}, {regs[rs]}, {regs[rt]}'
        if funct == 0x00: return f'sll {regs[rd]}, {regs[rt]}, {shamt}'
        if funct == 0x03: return f'sra {regs[rd]}, {regs[rt]}, {shamt}'
        if funct == 0x02: return f'srl {regs[rd]}, {regs[rt]}, {shamt}'
        if funct == 0x04: return f'sllv {regs[rd]}, {regs[rt]}, {regs[rs]}'
        if funct == 0x06: return f'srlv {regs[rd]}, {regs[rt]}, {regs[rs]}'
        if funct == 0x07: return f'srav {regs[rd]}, {regs[rt]}, {regs[rs]}'
        if funct == 0x10: return f'mfhi {regs[rd]}'
        if funct == 0x12: return f'mflo {regs[rd]}'
        if funct == 0x18: return f'mult {regs[rs]}, {regs[rt]}'
        if funct == 0x19: return f'multu {regs[rs]}, {regs[rt]}'
        if funct == 0x1A: return f'div {regs[rs]}, {regs[rt]}'
        if funct == 0x1B: return f'divu {regs[rs]}, {regs[rt]}'
        if funct == 0x0C: return f'syscall'
        if funct == 0x0D: return f'break'
        return f'.word 0x{word:08X}'
    if op == 0x01:
        if rt == 0: return f'bltz {regs[rs]}, 0x{addr + 4 + (simm << 2):08X}'
        if rt == 1: return f'bgez {regs[rs]}, 0x{addr + 4 + (simm << 2):08X}'
        return f'regimm rt={rt} {regs[rs]}, 0x{addr + 4 + (simm << 2):08X}'
    if op == 0x02: return f'j 0x{(addr & 0xF0000000) | (target << 2):08X}'
    if op == 0x03: return f'jal 0x{(addr & 0xF0000000) | (target << 2):08X}'
    if op == 0x04: return f'beq {regs[rs]}, {regs[rt]}, 0x{addr + 4 + (simm << 2):08X}'
    if op == 0x05: return f'bne {regs[rs]}, {regs[rt]}, 0x{addr + 4 + (simm << 2):08X}'
    if op == 0x06: return f'blez {regs[rs]}, 0x{addr + 4 + (simm << 2):08X}'
    if op == 0x07: return f'bgtz {regs[rs]}, 0x{addr + 4 + (simm << 2):08X}'
    if op == 0x08: return f'addi {regs[rt]}, {regs[rs]}, {simm}'
    if op == 0x09: return f'addiu {regs[rt]}, {regs[rs]}, {simm}'
    if op == 0x0A: return f'slti {regs[rt]}, {regs[rs]}, {simm}'
    if op == 0x0B: return f'sltiu {regs[rt]}, {regs[rs]}, {simm}'
    if op == 0x0C: return f'andi {regs[rt]}, {regs[rs]}, 0x{imm:04X}'
    if op == 0x0D: return f'ori {regs[rt]}, {regs[rs]}, 0x{imm:04X}'
    if op == 0x0E: return f'xori {regs[rt]}, {regs[rs]}, 0x{imm:04X}'
    if op == 0x0F: return f'lui {regs[rt]}, 0x{imm:04X}'
    if op == 0x20: return f'lb {regs[rt]}, {simm}({regs[rs]})'
    if op == 0x21: return f'lh {regs[rt]}, {simm}({regs[rs]})'
    if op == 0x23: return f'lw {regs[rt]}, {simm}({regs[rs]})'
    if op == 0x24: return f'lbu {regs[rt]}, {simm}({regs[rs]})'
    if op == 0x25: return f'lhu {regs[rt]}, {simm}({regs[rs]})'
    if op == 0x28: return f'sb {regs[rt]}, {simm}({regs[rs]})'
    if op == 0x29: return f'sh {regs[rt]}, {simm}({regs[rs]})'
    if op == 0x2B: return f'sw {regs[rt]}, {simm}({regs[rs]})'
    if op == 0x10: return f'mfc0 {regs[rt]}, {rd}'
    return f'.word 0x{word:08X} (op={op:02X})'

# Check clean EXE header
text_size = rd32(0x1C)
print(f"Clean EXE: file size={len(exe)}, text_size=0x{text_size:X} ({text_size})")
print(f"  Load addr: 0x{rd32(0x18):08X}")
print(f"  PC0: 0x{rd32(0x10):08X}")
print(f"  Text covers RAM: 0x{LOAD_ADDR:08X} - 0x{LOAD_ADDR + text_size:08X}")
print(f"  Thread entry 0x800D9E80 is {'INSIDE' if 0x800D9E80 < LOAD_ADDR + text_size else 'BEYOND'} text")

# Disassemble main init at 0x8004F344
print(f"\n=== Main Init (RAM 0x8004F344) ===")
init_off = ram_to_off(0x8004F344)
for i in range(80):
    off = init_off + i * 4
    if off + 4 > len(exe): break
    word = rd32(off)
    ram = LOAD_ADDR + off - 0x800
    d = decode(word, ram)
    print(f"  0x{ram:08X}: 0x{word:08X}  {d}")
    # Stop at first jr ra + nop (function return)
    if d.startswith('jr ra') and i > 10:
        # Check if next is nop
        next_off = off + 4
        if next_off + 4 <= len(exe):
            next_word = rd32(next_off)
            if next_word == 0:
                break
