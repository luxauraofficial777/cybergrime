# Search DQ4 EXE for key function patterns
$b = [System.IO.File]::ReadAllBytes('..\dq4_exe.bin')
$load = 0x80017F00
$textStart = 0x800  # offset in file where text section starts (after 0x800 header)

# Search for JAL targets (0x0Cxxxxxx) to find call sites
# Decompression at 0x80073670 -> offset in EXE = 0x80073670 - 0x80017F00 = 0x5B770
$decompOffset = 0x80073670 - 0x80017F00 + 0x800
Write-Host "Decompression function file offset: 0x$($decompOffset.ToString('X8'))"

# Search for GPU DMA trigger (GP1 write 0x04000002 -> VRAM transfer)
# Also search for text-related BIOS calls (A:0x49 GPU_cw)
# Search for SW to 0x1F801810 (GPU DMA base)
$gpuDmaPattern = [byte[]]@(0x10, 0x18, 0x80, 0x1F)  # 0x1F801810 in LE
$matches = @()
for ($i = 0x800; $i -lt $b.Length - 4; $i += 4) {
    $val = [BitConverter]::ToUInt32($b, $i)
    # Look for lui $v0, 0x1F80 (0x3C021F80) followed by sw to 0x1810
    if ($val -eq 0x3C021F80) {
        $addr = $load + $i - 0x800
        # Check next few instructions for 0x1810 offset
        for ($j = 1; $j -le 4; $j++) {
            if ($i + $j * 4 -ge $b.Length) { break }
            $next = [BitConverter]::ToUInt32($b, $i + $j * 4)
            # sw $v0, 0x1810($v0) = 0xAC420810? No... sw $xx, 0x1810($v0) = 0xACxx1810
            if (($next -band 0xFFFF0000) -eq 0xAC020000 -and (($next -band 0x0000FFFF) -eq 0x00001810 -or ($next -band 0x0000FFFF) -eq 0x00000810)) {
                $matches += "GPU DMA write at 0x$($addr.ToString('X8')) (instr +$j)"
            }
            # Also check for addiu $v0, $v0, 0x1810 (0x24421810)
            if ($next -eq 0x24421810) {
                $matches += "GPU DMA setup at 0x$($addr.ToString('X8')) (addiu 0x1810)"
            }
        }
    }
}
Write-Host "GPU DMA references found: $($matches.Count)"
foreach ($m in $matches) { Write-Host "  $m" }

# Search for CD-ROM sector read patterns (lw from 0x1F801803)
# Search for text string references - look for lui/addiu pairs loading 0x800B/0x800C addresses
# These are common in text pointer setup
Write-Host ""
Write-Host "=== Searching for text render patterns ==="
# Look for GPU_cw (A:0x49) call sites: addiu $t1, $zero, 0x49 (0x24090049)
$gpuCwSites = @()
for ($i = 0x800; $i -lt $b.Length - 4; $i += 4) {
    $val = [BitConverter]::ToUInt32($b, $i)
    if ($val -eq 0x24090049) {
        $addr = $load + $i - 0x800
        $gpuCwSites += "0x$($addr.ToString('X8'))"
    }
}
Write-Host "GPU_cw (A:0x49) call sites: $($gpuCwSites.Count)"
foreach ($s in $gpuCwSites) { Write-Host "  $s" }

# Search for the Huffman decompression JAL call sites
# JAL 0x80073670 = 0x0C01CDA8 + delay slot? Actually JAL encoding: 0x0C000000 | (target >> 2)
# 0x80073670 >> 2 = 0x2001CDA8... wait, JAL = 0x0C | (target[27:2])
# target = 0x80073670, target >> 2 = 0x2001CDA8... that's 28 bits
# JAL encoding: 0x0C000000 | ((target >> 2) & 0x3FFFFFF) = 0x0C01CDA8
$jalTarget = 0x0C01CDA8
$jalSites = @()
for ($i = 0x800; $i -lt $b.Length - 4; $i += 4) {
    $val = [BitConverter]::ToUInt32($b, $i)
    if ($val -eq $jalTarget) {
        $addr = $load + $i - 0x800
        $jalSites += "0x$($addr.ToString('X8'))"
    }
}
Write-Host ""
Write-Host "JAL 0x80073670 (Huffman decompression) call sites: $($jalSites.Count)"
foreach ($s in $jalSites) { Write-Host "  $s" }

# Also search for the text cache buffer address 0x80120000
# lui $xx, 0x8012 = 0x3Cxx8012
$cacheRefs = @()
for ($i = 0x800; $i -lt $b.Length - 4; $i += 4) {
    $val = [BitConverter]::ToUInt32($b, $i)
    if (($val -band 0xFFFF0000) -eq 0x3C008012 -or ($val -band 0xFFFF0000) -eq 0x3C018012 -or 
        ($val -band 0xFFFF0000) -eq 0x3C028012 -or ($val -band 0xFFFF0000) -eq 0x3C038012 -or
        ($val -band 0xFFFF0000) -eq 0x3C048012 -or ($val -band 0xFFFF0000) -eq 0x3C058012 -or
        ($val -band 0xFFFF0000) -eq 0x3C068012 -or ($val -band 0xFFFF0000) -eq 0x3C078012 -or
        ($val -band 0xFFFF0000) -eq 0x3C088012 -or ($val -band 0xFFFF0000) -eq 0x3C098012 -or
        ($val -band 0xFFFF0000) -eq 0x3C0A8012 -or ($val -band 0xFFFF0000) -eq 0x3C0B8012 -or
        ($val -band 0xFFFF0000) -eq 0x3C0C8012 -or ($val -band 0xFFFF0000) -eq 0x3C0D8012 -or
        ($val -band 0xFFFF0000) -eq 0x3C0E8012 -or ($val -band 0xFFFF0000) -eq 0x3C0F8012 -or
        ($val -band 0xFFFF0000) -eq 0x3C108012 -or ($val -band 0xFFFF0000) -eq 0x3C118012 -or
        ($val -band 0xFFFF0000) -eq 0x3C128012 -or ($val -band 0xFFFF0000) -eq 0x3C138012 -or
        ($val -band 0xFFFF0000) -eq 0x3C148012 -or ($val -band 0xFFFF0000) -eq 0x3C158012 -or
        ($val -band 0xFFFF0000) -eq 0x3C168012 -or ($val -band 0xFFFF0000) -eq 0x3C178012 -or
        ($val -band 0xFFFF0000) -eq 0x3C188012 -or ($val -band 0xFFFF0000) -eq 0x3C198012 -or
        ($val -band 0xFFFF0000) -eq 0x3C1A8012 -or ($val -band 0xFFFF0000) -eq 0x3C1B8012 -or
        ($val -band 0xFFFF0000) -eq 0x3C1C8012 -or ($val -band 0xFFFF0000) -eq 0x3C1D8012 -or
        ($val -band 0xFFFF0000) -eq 0x3C1E8012 -or ($val -band 0xFFFF0000) -eq 0x3C1F8012) {
        $addr = $load + $i - 0x800
        $cacheRefs += "0x$($addr.ToString('X8')) (raw=0x$($val.ToString('X8')))"
    }
}
Write-Host ""
Write-Host "References to 0x8012xxxx (text cache): $($cacheRefs.Count)"
foreach ($s in $cacheRefs) { Write-Host "  $s" }
