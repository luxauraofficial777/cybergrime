#!/usr/bin/env python3
"""
patch_controller.py — Automated Patch Loop Controller

Ties together the live analysis sidecar, runtime comparator, and patch injector
into a fully automated patch-validation loop. The controller:

1. State Capture: Pauses emulator at copy routine (0x800BC700) or Huffman entry
2. Simulation & Validation: Calculates correct offsets against current memory map
3. Instruction Injection: Writes corrected addresses via InstrumentationBus
4. Resumption: Emulator resumes from patched state — instant feedback

This turns the emulator into a dynamic debugging environment where "guesswork"
is mathematically resolved by the simulation layer before the final code path
is ever committed.

Usage:
  python patch_controller.py \
    --pipe \\\\.\pipe\\cybergrime_live \
    --constraints cybergrime/constraint_map.json \
    --golden cybergrime/golden_state.json \
    --mode auto \
    --output patch_loop_log.json

  python patch_controller.py --pipe \\\\.\pipe\\cybergrime_live --mode tree_fix
  python patch_controller.py --pipe \\\\.\pipe\\cybergrime_live --mode lba_fix
  python patch_controller.py --pipe \\\\.\pipe\\cybergrime_live --mode full
"""

import argparse
import json
import os
import sys
import time
from typing import Dict, List, Optional, Any

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from patch_injector import PatchInjector
from runtime_comparator import RuntimeComparator
from ghidra_bridge import GhidraBridge


# ── Known Addresses (from constraint map / reverse engineering) ──────────────

COPY_ROUTINE_PC = 0x800BC700
ORIGINAL_PC0 = 0x8008E284
HUFFMAN_DECOMP_PRIMARY = 0x80073670
HUFFMAN_DECOMP_SECONDARY = 0x80084BF0
BSS_CLEAR_START = 0x800BC668
BSS_CLEAR_END = 0x800F4980
THREAD_ENTRY = 0x800D9E80
TREE_ORIGINAL_RAM = 0x800EF1C8
SAFE_HIGH_RAM = 0x80100000
TREE_OPTION_B_RAM = 0x800F4980

# EXE load address for RAM→EXE offset conversion
EXE_LOAD_ADDR = 0x80017F00
EXE_HEADER_OFF = 0x800  # File offset of EXE header in disc sector

# LBA constants
ORIGINAL_HBD_LBA = 354
FRANKENSTEIN_HBD_LBA = 355
LBA_DELTA = 1


class PatchController:
    """Automated patch loop controller.

    Monitors emulator state via instrumentation bus, detects when specific
    breakpoints are hit, calculates correct values, injects patches, and
    resumes execution — all without rebuilding the ROM.
    """

    def __init__(self, pipe_name: str, constraint_map: dict,
                 golden_state: dict, output_path: str = "patch_loop_log.json"):
        self.pipe_name = pipe_name
        self.constraints = constraint_map
        self.golden = golden_state
        self.output_path = output_path
        self.injector = PatchInjector(pipe_name)
        self.comparator = RuntimeComparator(constraint_map, golden_state)
        self.ghidra = GhidraBridge()

        self.patch_log: List[dict] = []
        self.events_processed = 0
        self.start_time = time.time()
        self.running = False

        # State machine
        self.current_phase = "idle"
        self.breakpoints_set = set()
        self.tree_addr = int(golden_state.get('tree_placement', {}).get('addr', '0x80100000'), 16)
        self.tree_size = constraint_map.get('huffman_tree', {}).get('hybrid_tree_size', 1480)

        # Patch tracking
        self.patches_applied = 0
        self.rollbacks_performed = 0
        self.validation_results: List[dict] = []

    def setup_breakpoints(self):
        """Set breakpoints at critical addresses for the patch loop."""
        critical_pcs = [
            COPY_ROUTINE_PC,           # Copy routine entry
            ORIGINAL_PC0,              # BSS clear entry (after copy)
            HUFFMAN_DECOMP_PRIMARY,    # Huffman decompression entry
            HUFFMAN_DECOMP_SECONDARY,  # Secondary decompression
            THREAD_ENTRY,              # Thread entry (BSS zeroed check)
        ]

        for pc in critical_pcs:
            self.injector.set_breakpoint(pc, f"patch_loop_monitor_{hex(pc)}")
            self.breakpoints_set.add(pc)
            print(f"[CTRL] Breakpoint set at {hex(pc)}")

    def run(self, mode: str = "auto"):
        """Main control loop.

        Modes:
          auto    — Monitor and patch automatically at each breakpoint
          tree_fix — Only fix Huffman tree pointer mismatches
          lba_fix  — Only fix LBA pointer drift
          full    — Run all patches: tree + LBA + thread entry + BSS
          monitor — Only monitor, don't inject any patches
        """
        self.running = True
        print(f"[CTRL] Patch Controller started (mode={mode})")
        print(f"[CTRL] Pipe: {self.pipe_name}")
        print(f"[CTRL] Tree target: {hex(self.tree_addr)} ({self.tree_size} bytes)")
        print(f"[CTRL] Output: {self.output_path}")

        # Set breakpoints
        if mode != "monitor":
            self.setup_breakpoints()

        # Connect to pipe and process events
        pipe_handle = self._connect_pipe()
        if pipe_handle is None:
            print("[CTRL] ERROR: Cannot connect to pipe")
            return

        print(f"[CTRL] Connected to emulator")

        buf = b""
        try:
            while self.running:
                data = self._read_pipe(pipe_handle)
                if data is None:
                    print("[CTRL] Pipe disconnected, waiting for reconnect...")
                    pipe_handle = self._connect_pipe()
                    if pipe_handle is None:
                        time.sleep(1)
                        continue
                    continue

                if data:
                    buf += data
                    while b'\n' in buf:
                        line, buf = buf.split(b'\n', 1)
                        if line.strip():
                            self._process_event(line.decode('utf-8', errors='replace'), mode)
                else:
                    time.sleep(0.001)

        except KeyboardInterrupt:
            print("\n[CTRL] Interrupted by user")
        finally:
            self._close_pipe(pipe_handle)
            self._write_log()

    def _process_event(self, line: str, mode: str):
        """Process a single event from the emulator."""
        try:
            event = json.loads(line)
        except json.JSONDecodeError:
            return

        self.events_processed += 1
        etype = event.get('type', '')

        # Pass to comparator for divergence detection
        divergence = self.comparator.handle_event(event)

        if divergence:
            self._log_divergence(divergence)

        # Handle breakpoint hits
        if etype == 'bp_hit':
            self._handle_breakpoint(event, mode)

        # Periodic status
        if self.events_processed % 5000 == 0:
            report = self.comparator.get_report()
            print(f"[CTRL] Events: {self.events_processed} | "
                  f"Patches: {self.patches_applied} | "
                  f"Divergences: {report['total_divergences']}")

    def _handle_breakpoint(self, event: dict, mode: str):
        """Handle a breakpoint hit — the core of the patch loop."""
        pc = int(event['pc'], 16)
        instr = event.get('instr', 0)
        regs = event.get('regs', {})

        print(f"\n{'='*70}")
        print(f"[CTRL] BREAKPOINT at {hex(pc)} (instr #{instr})")
        print(f"{'='*70}")

        # Print key registers
        for name in ['v0', 'v1', 'a0', 'a1', 'a2', 'a3', 't0', 't1', 't2', 'ra', 'sp', 'gp']:
            if name in regs:
                print(f"  ${name:<4} = {regs[name]}")

        # Route to specific handler
        if pc == COPY_ROUTINE_PC:
            self._at_copy_routine(event, mode)
        elif pc == ORIGINAL_PC0:
            self._at_bss_clear(event, mode)
        elif pc == HUFFMAN_DECOMP_PRIMARY or pc == HUFFMAN_DECOMP_SECONDARY:
            self._at_huffman_decompress(event, mode, pc)
        elif pc == THREAD_ENTRY:
            self._at_thread_entry(event, mode)
        else:
            print(f"  [CTRL] Unknown breakpoint PC — no action")

        print()

    # ── Phase 1: Copy Routine Entry ─────────────────────────────────────

    def _at_copy_routine(self, event: dict, mode: str):
        """At 0x800BC700 — copy routine entry. Verify src/dst registers."""
        regs = event.get('regs', {})
        instr = event.get('instr', 0)

        t0 = int(regs.get('t0', '0x0'), 16)  # Source (tree in EXE)
        t1 = int(regs.get('t1', '0x0'), 16)  # Destination (high RAM)
        t2 = int(regs.get('t2', '0x0'), 16)  # End marker

        print(f"  [COPY] src=$t0={hex(t0)}, dst=$t1={hex(t1)}, end=$t2={hex(t2)}")

        expected_dst = self.tree_addr
        expected_src = 0x800BC738  # Tree data starts after 56-byte copy routine
        expected_end = expected_src + self.tree_size

        issues = []

        if t1 != expected_dst:
            issues.append({
                'reg': 't1',
                'expected': hex(expected_dst),
                'actual': hex(t1),
                'fix': f"WRITE_REG $t1 = {hex(expected_dst)}"
            })

        if t0 != expected_src:
            issues.append({
                'reg': 't0',
                'expected': hex(expected_src),
                'actual': hex(t0),
                'fix': f"WRITE_REG $t0 = {hex(expected_src)}"
            })

        if t2 != expected_end:
            issues.append({
                'reg': 't2',
                'expected': hex(expected_end),
                'actual': hex(t2),
                'fix': f"WRITE_REG $t2 = {hex(expected_end)}"
            })

        if not issues:
            print(f"  [COPY] ✓ All registers correct — copy will succeed")
            self.validation_results.append({
                'pc': hex(COPY_ROUTINE_PC), 'instr': instr,
                'status': 'PASS', 'detail': 'Copy routine registers correct'
            })
            return

        # Apply fixes
        if mode in ('auto', 'full', 'tree_fix'):
            for issue in issues:
                reg_idx = self._reg_name_to_idx(issue['reg'])
                expected_val = int(issue['expected'], 16)
                print(f"  [COPY] ⚠ {issue['reg']} mismatch: expected {issue['expected']}, "
                      f"actual {issue['actual']}")
                print(f"  [COPY] → Injecting: {issue['fix']}")

                self.injector.write_reg(reg_idx, expected_val,
                                        f"copy_routine_fix_{issue['reg']}")
                self.patches_applied += 1
                self.patch_log.append({
                    'phase': 'copy_routine',
                    'instr': instr,
                    'type': 'WRITE_REG',
                    'reg': issue['reg'],
                    'expected': issue['expected'],
                    'actual': issue['actual'],
                    'description': issue['fix']
                })

            print(f"  [COPY] Patches applied: {len(issues)}")
        else:
            print(f"  [COPY] Monitor mode — {len(issues)} issues detected, no patches applied")

        self.validation_results.append({
            'pc': hex(COPY_ROUTINE_PC), 'instr': instr,
            'status': 'PATCHED' if issues else 'PASS',
            'issues': issues
        })

    # ── Phase 2: BSS Clear Entry ────────────────────────────────────────

    def _at_bss_clear(self, event: dict, mode: str):
        """At 0x8008E284 — BSS clear entry. Verify tree was copied."""
        regs = event.get('regs', {})
        instr = event.get('instr', 0)

        v0 = int(regs.get('v0', '0x0'), 16)  # BSS clear start
        v1 = int(regs.get('v1', '0x0'), 16)  # BSS clear end (if set)

        print(f"  [BSS] $v0={hex(v0)} (BSS start), $v1={hex(v1)} (BSS end)")

        # Check if tree was successfully copied
        # Request a memory dump at the tree destination
        if mode in ('auto', 'full', 'tree_fix'):
            print(f"  [BSS] Requesting tree verification dump at {hex(self.tree_addr)}")
            self.injector.dump_region(self.tree_addr, min(self.tree_size, 64),
                                      "verify_tree_copied")
            self.patches_applied += 1
            self.patch_log.append({
                'phase': 'bss_clear',
                'instr': instr,
                'type': 'DUMP_REGION',
                'addr': hex(self.tree_addr),
                'description': 'Verify tree was copied before BSS clear'
            })

        # If tree is at 0x800BC700 (mode 3), check BSS narrow
        if self.tree_addr == 0x800BC700 and mode in ('auto', 'full'):
            # BSS should be narrowed to 0x800BCCC8
            # Check if $v1 (BSS end) is correct
            expected_bss_end = 0x800BCCC8
            if v1 != 0 and v1 != expected_bss_end:
                print(f"  [BSS] ⚠ BSS end mismatch: expected {hex(expected_bss_end)}, "
                      f"actual {hex(v1)}")
                # Can't easily patch BSS end at this point — it's set by lui/addiu
                # which already executed. Log for ROM-level fix.
                self.patch_log.append({
                    'phase': 'bss_clear',
                    'instr': instr,
                    'type': 'DIAGNOSTIC',
                    'detail': f'BSS end not narrowed: v1={hex(v1)}, expected {hex(expected_bss_end)}'
                })

        self.validation_results.append({
            'pc': hex(ORIGINAL_PC0), 'instr': instr,
            'status': 'VERIFIED',
            'bss_start': hex(v0), 'bss_end': hex(v1)
        })

    # ── Phase 3: Huffman Decompression Entry ────────────────────────────

    def _at_huffman_decompress(self, event: dict, mode: str, pc: int):
        """At 0x80073670 / 0x80084BF0 — Huffman decompression entry."""
        regs = event.get('regs', {})
        instr = event.get('instr', 0)

        a0 = int(regs.get('a0', '0x0'), 16)  # Source (encoded text)
        a1 = int(regs.get('a1', '0x0'), 16)  # Destination (decoded output)
        a2 = int(regs.get('a2', '0x0'), 16)  # Tree pointer
        a3 = int(regs.get('a3', '0x0'), 16)  # Tree size (sometimes)

        func_name = "primary" if pc == HUFFMAN_DECOMP_PRIMARY else "secondary"
        print(f"  [HUFFMAN/{func_name}] $a0={hex(a0)} (src), $a1={hex(a1)} (dst), "
              f"$a2={hex(a2)} (tree), $a3={hex(a3)}")

        # Check tree pointer
        expected_tree = self.tree_addr
        if a2 != expected_tree:
            print(f"  [HUFFMAN/{func_name}] ⚠ Tree pointer mismatch!")
            print(f"    Expected: {hex(expected_tree)}")
            print(f"    Actual:   {hex(a2)}")

            if a2 == TREE_ORIGINAL_RAM:
                print(f"    → Tree still points to original DW7 location {hex(TREE_ORIGINAL_RAM)}")
                print(f"    → This address is in BSS range and may be zeroed")

            if mode in ('auto', 'full', 'tree_fix'):
                # Inject corrected tree pointer
                print(f"  [HUFFMAN/{func_name}] → Injecting: $a2 = {hex(expected_tree)}")
                self.injector.write_reg(6, expected_tree,  # $a2 = register index 6
                                        f"huffman_tree_fix_{func_name}")
                self.patches_applied += 1
                self.patch_log.append({
                    'phase': f'huffman_{func_name}',
                    'instr': instr,
                    'type': 'WRITE_REG',
                    'reg': 'a2',
                    'expected': hex(expected_tree),
                    'actual': hex(a2),
                    'description': f'Fix tree pointer for {func_name} decompression'
                })
                print(f"  [HUFFMAN/{func_name}] ✓ Tree pointer patched")
            else:
                print(f"  [HUFFMAN/{func_name}] Monitor mode — no patch applied")
        else:
            print(f"  [HUFFMAN/{func_name}] ✓ Tree pointer correct ({hex(a2)})")

        # Also request a tree data dump to verify content
        if mode in ('auto', 'full'):
            self.injector.dump_region(a2, 16, f"tree_data_check_{func_name}")

        self.validation_results.append({
            'pc': hex(pc), 'instr': instr,
            'status': 'PATCHED' if a2 != expected_tree else 'PASS',
            'tree_ptr': hex(a2), 'expected_tree': hex(expected_tree),
            'src': hex(a0), 'dst': hex(a1)
        })

    # ── Phase 4: Thread Entry Check ─────────────────────────────────────

    def _at_thread_entry(self, event: dict, mode: str):
        """At 0x800D9E80 — thread entry. Check if it was zeroed by BSS."""
        regs = event.get('regs', {})
        instr = event.get('instr', 0)

        print(f"  [THREAD] PC at thread entry {hex(THREAD_ENTRY)} (instr #{instr})")

        # Request dump to check if thread entry has valid code
        if mode in ('auto', 'full'):
            self.injector.dump_region(THREAD_ENTRY, 32, "thread_entry_check")
            self.patch_log.append({
                'phase': 'thread_entry',
                'instr': instr,
                'type': 'DUMP_REGION',
                'addr': hex(THREAD_ENTRY),
                'description': 'Check if thread entry was zeroed by BSS clear'
            })

        self.validation_results.append({
            'pc': hex(THREAD_ENTRY), 'instr': instr,
            'status': 'CHECKING'
        })

    # ── LBA Fix Logic ───────────────────────────────────────────────────

    def _calculate_lba_fixes(self, current_lba: int) -> List[dict]:
        """Calculate LBA pointer corrections needed."""
        fixes = []
        expected_lba = FRANKENSTEIN_HBD_LBA

        if current_lba == ORIGINAL_HBD_LBA:
            fixes.append({
                'type': 'LBA_DELTA',
                'old_lba': ORIGINAL_HBD_LBA,
                'new_lba': expected_lba,
                'delta': LBA_DELTA,
                'description': f'LBA not patched: {ORIGINAL_HBD_LBA}→{expected_lba}'
            })

        return fixes

    # ── Utility ─────────────────────────────────────────────────────────

    def _reg_name_to_idx(self, name: str) -> int:
        """Convert register name to index."""
        reg_map = {
            'zero': 0, 'at': 1,
            'v0': 2, 'v1': 3,
            'a0': 4, 'a1': 5, 'a2': 6, 'a3': 7,
            't0': 8, 't1': 9, 't2': 10, 't3': 11,
            't4': 12, 't5': 13, 't6': 14, 't7': 15,
            's0': 16, 's1': 17, 's2': 18, 's3': 19,
            's4': 20, 's5': 21, 's6': 22, 's7': 23,
            't8': 24, 't9': 25,
            'k0': 26, 'k1': 27,
            'gp': 28, 'sp': 29, 'fp': 30, 'ra': 31,
        }
        return reg_map.get(name, 0)

    def _log_divergence(self, div: dict):
        """Log a divergence detected by the comparator."""
        severity = div.get('severity', 'WARN')
        icon = "✗" if severity == 'FATAL' else "⚠"
        print(f"\n  {icon} DIVERGENCE #{div['id']} [{severity}] "
              f"at instr {div['instr_count']}, PC={div['pc']}")
        print(f"    Type:     {div['type']}")
        print(f"    Expected: {div['expected']}")
        print(f"    Actual:   {div['actual']}")
        print(f"    Detail:   {div['detail']}")

    def _connect_pipe(self):
        """Connect to the Windows named pipe."""
        try:
            import win32file
            import pywintypes
            try:
                handle = win32file.CreateFile(
                    self.pipe_name,
                    win32file.GENERIC_READ | win32file.GENERIC_WRITE,
                    0, None, win32file.OPEN_EXISTING, 0, None
                )
                return handle
            except pywintypes.error as e:
                if e.winerror == 231:
                    import win32pipe
                    win32pipe.WaitNamedPipe(self.pipe_name, 5000)
                    try:
                        return win32file.CreateFile(
                            self.pipe_name,
                            win32file.GENERIC_READ | win32file.GENERIC_WRITE,
                            0, None, win32file.OPEN_EXISTING, 0, None
                        )
                    except pywintypes.error:
                        return None
                return None
        except ImportError:
            pass

        import ctypes
        kernel32 = ctypes.windll.kernel32
        GENERIC_READ = 0x80000000
        GENERIC_WRITE = 0x40000000
        OPEN_EXISTING = 3
        INVALID_HANDLE_VALUE = ctypes.c_void_p(-1).value

        for _ in range(50):
            handle = kernel32.CreateFileW(
                self.pipe_name, GENERIC_READ | GENERIC_WRITE,
                0, None, OPEN_EXISTING, 0, None
            )
            if handle != INVALID_HANDLE_VALUE:
                return handle
            time.sleep(0.1)
        return None

    def _read_pipe(self, handle):
        """Read data from the pipe."""
        try:
            import win32file
            import pywintypes
            try:
                err, data = win32file.ReadFile(handle, 65536)
                if err == 0:
                    return data
                return b""
            except pywintypes.error as e:
                if e.winerror == 232:
                    return b""
                return None
        except ImportError:
            pass

        import ctypes
        kernel32 = ctypes.windll.kernel32
        buf = ctypes.create_string_buffer(65536)
        bytes_read = ctypes.c_ulong(0)
        ok = kernel32.ReadFile(handle, buf, 65536,
                               ctypes.byref(bytes_read), None)
        if ok:
            return buf.raw[:bytes_read.value]
        err = kernel32.GetLastError()
        if err == 232:
            return b""
        return None

    def _close_pipe(self, handle):
        if handle is None:
            return
        try:
            import win32file
            win32file.CloseHandle(handle)
        except (ImportError, Exception):
            import ctypes
            ctypes.windll.kernel32.CloseHandle(handle)

    def _write_log(self):
        """Write the final patch loop log."""
        report = self.comparator.get_report()
        log = {
            'session': {
                'events_processed': self.events_processed,
                'duration_seconds': time.time() - self.start_time,
                'patches_applied': self.patches_applied,
                'rollbacks_performed': self.rollbacks_performed,
                'pipe': self.pipe_name,
            },
            'divergence_report': report,
            'patch_log': self.patch_log,
            'validation_results': self.validation_results,
            'breakpoints_set': [hex(bp) for bp in sorted(self.breakpoints_set)],
        }

        with open(self.output_path, 'w') as f:
            json.dump(log, f, indent=2)

        print(f"\n{'='*70}")
        print(f"  PATCH LOOP LOG — {self.output_path}")
        print(f"{'='*70}")
        print(f"  Events processed:    {self.events_processed}")
        print(f"  Patches applied:     {self.patches_applied}")
        print(f"  Rollbacks:           {self.rollbacks_performed}")
        print(f"  Divergences:         {report['total_divergences']}")
        print(f"  Fatal divergences:   {report['fatal_count']}")
        print(f"  Validations:         {len(self.validation_results)}")
        for v in self.validation_results:
            status_icon = "✓" if v['status'] == 'PASS' else "⚠" if v['status'] == 'PATCHED' else "✗"
            print(f"    {status_icon} {v['pc']} instr={v['instr']} — {v['status']}")
        print(f"{'='*70}")


def load_json(path: str, default=None) -> dict:
    if path and os.path.exists(path):
        with open(path) as f:
            return json.load(f)
    return default if default is not None else {}


def main():
    parser = argparse.ArgumentParser(
        description="Patch Controller — Automated Patch Loop for CyberGrime"
    )
    parser.add_argument("--pipe", default=r"\\.\pipe\cybergrime_live",
                        help="Named pipe path")
    parser.add_argument("--constraints", default="cybergrime/constraint_map.json",
                        help="Constraint map JSON")
    parser.add_argument("--golden", default="cybergrime/golden_state.json",
                        help="Golden state JSON")
    parser.add_argument("--mode", default="auto",
                        choices=["auto", "tree_fix", "lba_fix", "full", "monitor"],
                        help="Patch mode: auto, tree_fix, lba_fix, full, or monitor")
    parser.add_argument("--output", default="patch_loop_log.json",
                        help="Output log path")
    args = parser.parse_args()

    constraints = load_json(args.constraints)
    if not constraints:
        print(f"ERROR: Constraint map not found: {args.constraints}")
        sys.exit(1)

    golden = load_json(args.golden, default={
        "tree_placement": {"mode": "Option A", "addr": "0x80100000"}
    })

    controller = PatchController(
        pipe_name=args.pipe,
        constraint_map=constraints,
        golden_state=golden,
        output_path=args.output,
    )

    controller.run(mode=args.mode)


if __name__ == "__main__":
    main()
