"""
Golden Mile Phase 8 — Boot test script for v108c.
Run with: python boot_test_v108c.py
Uses SCPH-1001 BIOS (NOT FRANKENSTEIN.BIOS).
"""
import subprocess, time, os, threading, struct

DS_EXE = r'c:\LuxAura\VoidWalkers_Project\DQLOSTTRANSLATION\duckstation\duckstation-qt-x64-ReleaseLTCG.exe'
CUE    = r'c:\LuxAura\VoidWalkers_Project\DQLOSTTRANSLATION\build_staging\dq4_frankenstein_v108c.cue'
LOG    = r'c:\LuxAura\VoidWalkers_Project\DQLOSTTRANSLATION\build_staging\v108c_boot.log'
PORTABLE = r'c:\LuxAura\VoidWalkers_Project\DQLOSTTRANSLATION\duckstation'

env = os.environ.copy()
env["SDL_RAWINPUT"] = "0"

print(f"Launching DuckStation for v108c boot test...")
proc = subprocess.Popen(
    [DS_EXE, "-earlyconsole", "-fastboot", "-noshadercache", CUE],
    env=env,
    stdout=subprocess.PIPE,
    stderr=subprocess.STDOUT,
    creationflags=subprocess.CREATE_NEW_PROCESS_GROUP,
    cwd=PORTABLE
)
print(f"  PID: {proc.pid}")

lines = []
def reader():
    with open(LOG, 'w', encoding='utf-8', errors='replace') as f:
        while True:
            line = proc.stdout.readline()
            if not line:
                if proc.poll() is not None:
                    break
                time.sleep(0.01)
                continue
            text = line.decode('utf-8', errors='replace').rstrip('\n\r')
            f.write(text + '\n')
            f.flush()
            lines.append(text)

t = threading.Thread(target=reader, daemon=True)
t.start()

WAIT = 45
print(f"Waiting {WAIT} seconds...")
time.sleep(WAIT)

if proc.poll() is not None:
    print(f"DuckStation exited: code={proc.returncode}")
else:
    print("Killing DuckStation...")
    proc.terminate()
    try:
        proc.wait(timeout=5)
    except:
        proc.kill()
        proc.wait()

t.join(timeout=5)

print(f"\n=== Log Analysis ({len(lines)} lines) ===")
for line in lines:
    low = line.lower()
    for kw in ['bios', 'boot path', 'executable', 'ram size', 'memory window',
               'datasector', 'cannot fast boot', 'incompatible', 'fps',
               'cdrom', 'sector', 'xa', 'hbd', 'vblank', 'error', 'warning']:
        if kw in low:
            print(f"  {line}")
            break

ds_count = sum(1 for l in lines if 'DataSector' in l)
print(f"\nDataSector reads: {ds_count}")

ds_lines = [l for l in lines if 'DataSector' in l]
if ds_lines:
    print(f"First 10:")
    for l in ds_lines[:10]:
        print(f"  {l}")
    print(f"Last 10:")
    for l in ds_lines[-10:]:
        print(f"  {l}")

fps_lines = [l for l in lines if 'FPS' in l]
if fps_lines:
    print(f"\nFPS lines (first 5, last 5):")
    for l in fps_lines[:5]:
        print(f"  {l}")
    if len(fps_lines) > 5:
        for l in fps_lines[-5:]:
            print(f"  {l}")

print(f"\nLast 20 log lines:")
for l in lines[-20:]:
    print(f"  {l}")

# Golden Mile CP assessment
print(f"\n=== GOLDEN MILE CP ASSESSMENT ===")
print(f"CP1 (BIOS boot):          {'PASS' if len(lines) > 10 else 'FAIL'} — {len(lines)} log lines")
print(f"CP2 (EXE loaded):         {'PASS' if any('Executable' in l or 'PS-X' in l for l in lines) else 'UNKNOWN'}")
print(f"CP3 (CD-ROM reads):       {'PASS' if ds_count > 0 else 'FAIL'} — {ds_count} DataSector reads")
print(f"CP4 (HBD first sector):   {'PASS' if ds_count > 10 else 'UNKNOWN'} — need >10 reads")
print(f"CP5 (HBD decompression):  UNKNOWN — requires runtime trace")
print(f"CP6 (Title screen):       UNKNOWN — requires visual inspection")
print(f"CP7 (Game playable):      UNKNOWN — requires interaction")
print(f"CP8 (English text):       UNKNOWN — requires visual inspection")
print(f"CP9 (Battle):             UNKNOWN — requires interaction")
