# PSX Reference Integration Manifest

## Overview

Three reference repositories have been cloned under `study/` and integrated
into the CyberGrime PSX emulator via `psx_reference_integrations.h`.

## Repositories

| Repo | Path | License | Language |
|------|------|---------|----------|
| PSoXide | `study/PSoXide/` | GPL-2.0-or-later | Rust |
| PSn00bSDK | `study/PSn00bSDK/` | MPL-2.0 | C/Assembly |
| PSn00b-Debugger | `study/PSn00b-Debugger/` | GPL-3.0 | C++/Assembly |

## Integration: PSoXide (emulator-core)

### Source Files Audited

| File | Lines | Purpose |
|------|-------|---------|
| `emu/crates/emulator-core/src/lib.rs` | 52 | Module declarations: bus, cdrom, cpu, dma, gpu, hle_bios, irq, mdec, pad, scheduler, sio, spu, timers |
| `emu/crates/emulator-core/src/hle_bios.rs` | 334 | HLE BIOS syscall dispatch (A/B/C tables) |
| `emu/crates/emulator-core/src/cdrom.rs` | 2376 | Full CD-ROM controller: FIFOs, IRQs, commands, sector streaming, XA audio |
| `emu/crates/emulator-core/src/cpu.rs` | 80+ | MIPS R3000A CPU: instruction decode, GTE timing, execution errors |

### Integration Points

#### CD-ROM Controller (`cdrom.rs`)
- **Status/IRQ bits**: `status_bit` constants (ERROR, MOTOR_ON, SEEK, etc.) mapped to `cdrom_constants::STAT_*` in `psx_reference_integrations.h`
- **IRQ types**: `IrqType` enum (None, DataReady, Complete, Acknowledge, DataEnd, Error) mapped to `cdrom_constants::IRQ_*`
- **Command set**: All CdlCommand values (Nop, Setloc, ReadN, ReadS, SeekL, Pause, etc.) mapped to `cdrom_constants::Cdl*`
- **Timing**: `CD_READ_TIME` (33868 cycles), double/single speed cadence, initial vs steady-state sector delays
- **SetLoc logic**: BCD→LBA conversion, `setloc_pending` latch, >16 sector jump resets `seek_done`
- **ReadN/ReadS**: `cmd_read()` chains first DataReady off ACK, `load_next_sector()` fills data FIFO, `schedule_sector_event_at()` chains next sector
- **SeekL/SeekP**: Short 0x800-cycle path if `seek_done`, long `SEEK_SECOND_RESPONSE_CYCLES` otherwise
- **Pause**: Short ~7000-cycle follow-up if motor already on (standby), longer if from stopped state
- **Data FIFO**: 2048-byte user data, drained by MMIO reads at `0x1F801802` or DMA channel 3
- **Lid state machine**: Shell-open detection, motor spin-up sequencing

#### HLE BIOS (`hle_bios.rs`)
- **Dispatch function**: `dispatch(cpu_pc, bus, args, t1_func_num, ra)` — matches our `handle_bios_call()` pattern
- **A-table functions**: memset, putchar, puts, printf, FlushCache, InitPad, StartPad
- **B-table functions**: DeliverEvent, OpenEvent, WaitEvent, TestEvent, EnableEvent, OpenTh, CloseTh, ChangeTh
- **C-table functions**: SysEnqIntRP, SysDeqIntRP, InstallExceptionHandlers, SysInitMemory
- **Return mechanism**: Sets `$ra` and returns `Hle` enum indicating whether to jump or continue

#### CPU (`cpu.rs`)
- **GTE latencies**: `LZCR_RESULT_LATENCY`, `MAC0_RESULT_LATENCY` — cycle-accurate GTE timing
- **Instruction coverage**: Full MIPS R3000A ISA with parity vs PCSX-Redux
- **ExecutionError**: Unimplemented opcode detection

### CyberGrime Files Affected
- `psx_emulator_core.cpp`: BIOS handlers (OpenTh, ChangeTh, DeliverEvent), CD-ROM command processing
- `psx_reference_integrations.h`: All CD-ROM constants, BIOS syscall enums

---

## Integration: PSn00bSDK (libpsn00b)

### Source Files Audited

| File | Lines | Purpose |
|------|-------|---------|
| `libpsn00b/psxapi/stubs.json` | 507 | Complete BIOS syscall table: A/B/C tables with function IDs and names |
| `libpsn00b/psxapi/sys.s` | 359 | Assembly stubs for all B/C-table functions (li $t2, 0xB0; jr $t2; li $t1, N) |
| `libpsn00b/psxapi/_syscalls.s` | 3099 | Low-level syscall wrappers |
| `libpsn00b/psxcd/common.c` | 444 | CD-ROM IRQ handler, command dispatch, CdInit, CdControlF, CdSync |
| `libpsn00b/psxcd/cdread.c` | 4199 | High-level CD-ROM read API (CdRead, CdReadSync) |
| `libpsn00b/psxcd/isofs.c` | 18439 | ISO9660 filesystem parser |
| `libpsn00b/include/psxapi.h` | 332 | BIOS API header: TCB, PCB, DCB, FCB structs, event descriptors |
| `libpsn00b/include/psxcd.h` | 54195 | CD-ROM API header: CdlCommand, CdlLOC, CdlSTAT, callback types |

### Integration Points

#### BIOS Syscall Table (`stubs.json` + `sys.s`)
- **Complete A/B/C table mapping**: Every function ID → name → table → source file
- **Stub pattern**: `li $t2, 0xA0/0xB0/0xC0; jr $t2; li $t1, func_id` — confirms our emulator's BIOS dispatch mechanism
- **Mapped to**: `bios_syscalls::A_table`, `B_table`, `C_table` enums in `psx_reference_integrations.h`
- **Name lookup**: `A_name()`, `B_name()`, `C_name()` functions for diagnostic output

#### Thread Control Block (`psxapi.h`)
- **TCB structure**: 37 regs (r0-r31, hi, lo, cop0r14, cop0r12, cop0r13) + 9 reserved ints
- **Register order**: zero, at, v0, v1, a0-a3, t0-t9, s0-s7, k0, k1, gp, sp, fp, ra, cop0r14, hi, lo, cop0r12, cop0r13
- **Mapped to**: `psx_threads::TCB_REG_COUNT`, `TCB_RESERVED`, `TCB_SIZE`, `TcbReg` enum

#### Event Descriptors (`psxapi.h`)
- **DescHW** = 0xF0000000, **DescRC** = 0xF2000000, **DescSW** = 0xF4000000
- **HwVBLANK** = 0xF0000001, **HwCdRom** = 0xF0000003, **HwGPU** = 0xF0000002
- **Mapped to**: `psx_events` namespace constants
- **Used in**: CyberGrime's `deliver_event()` calls (e.g., `deliver_event(0xF2000002, 0x02)` for CD-ROM root counter)

#### CD-ROM Command Flags (`common.c`)
- **Command metadata**: `_command_flags[]` array with PARAM_N, STATUS, C_STATUS, BLOCKING, OPTIONAL, SETLOC flags
- **IRQ handler**: `_cd_irq_handler()` — reads IRQ type from reg 3, acknowledges, fetches result FIFO, dispatches callbacks
- **CdInit sequence**: EnterCriticalSection → InterruptCallback → BUS_CD_CFG=0x00020943 → DMA priority → ack IRQs → enable IRQs → CdNop → CdInit → CdDemute
- **CdControlF**: Validates params via flags, sends Setloc first for SETLOC commands, writes params to FIFO, writes command to reg 1

### CyberGrime Files Affected
- `psx_emulator_core.cpp`: BIOS handler function IDs, event descriptor values, TCB layout
- `psx_reference_integrations.h`: All BIOS syscall enums, event constants, TCB layout

---

## Integration: PSn00b-Debugger

### Source Files Audited

| File | Lines | Purpose |
|------|-------|---------|
| `monitor/protocol.txt` | 190 | Serial protocol: commands (ping, getregs, getmem, setword, etc.), events, errors |
| `monitor/monitor.asm` | 100+ | MIPS assembly for debug monitor: exception vectors, register offsets, command dispatch |
| `widgets/mips_disassembler.h` | 17 | Disassembler API: mips_Decode, mips_GetJumpAddr, mips_GetNextPc |
| `widgets/mips_disassembler.cpp` | 663 | Full MIPS R3000A disassembler: all opcodes, GTE cop2, cop0 register names |
| `src/disassembler.cpp` | 230 | Disassembler UI: jump-to-target, bookmarks, run-to-cursor, source line mapping |

### Integration Points

#### MIPS Disassembler (`mips_disassembler.cpp`)
- **Opcode extraction macros**: OPCODE1, OPCODE2, OPREGS, OPREGT, OPREGD, OPIMM5, OPIMM16, OPIMM20, OPIMM25, OPIMM26
- **Register name table**: r0, at, v0, v1, a0-a3, t0-t9, s0-s7, k0, k1, gp, sp, fp, ra
- **COP0 register nicknames**: SR, CAUSE, EPC, PRID, BadVaddr, BPC, BDA, DCIC, etc.
- **COP2 data register nicknames**: VXY0, VZ0, RGBC, OTZ, IR0-IR3, SXY0-SXYP, SZ0-SZ3, RGB0-RGB2, MAC0-MAC3, LZCS, LZCR
- **COP2 control register nicknames**: RT11-RT33, TRX/TRY/TRZ, LR1-LB3, RFC/GFC/BFC, OFX/OFY/H, DQA/DQB, ZSF3/ZSF4, FLAG
- **Full instruction decode**: All R-type (SPECIAL), I-type, J-type, REGIMM, COP0, COP2, GTE commands
- **Jump target resolution**: `mips_GetJumpAddr()` for follow-jump UI navigation
- **Mapped to**: `mips_disasm` namespace in `psx_reference_integrations.h` with `decode()`, `disasm_str()`, `jump_target()`

#### Debug Protocol (`protocol.txt`)
- **Commands**: CMD_ping (0xD0), CMD_pause (0xD2), CMD_resume (0xD3), CMD_step (0xD4), CMD_getregs (0xD5), CMD_getmem (0xD6), CMD_setword (0xD9), CMD_databreak (0xDA), CMD_runto (0xDB)
- **Events**: EV_start (0xC0), EV_pause (0xC1), EV_except (0xC2), EV_break (0xC4)
- **Errors**: ERR_ok (0xE0), ERR_invalid (0xE1), ERR_nocont (0xE2)
- **Register block**: 40 × 4-byte words (33 CPU + 6 COP0 + 1 opcode)
- **Mapped to**: `debug_protocol` namespace in `psx_reference_integrations.h`

#### Monitor Assembly (`monitor.asm`)
- **Exception vector layout**: Entry points at 0x80000080 (common exception), 0x80000040 (IRQ)
- **Register save/restore**: Full context save to stack, COP0 EPC/CAUSE/SR access
- **Command dispatch**: Jump table based on command byte from serial
- **Reference for**: CyberGrime's exception handling and debug breakpoint injection

### CyberGrime Files Affected
- `psx_reference_integrations.h`: `mips_disasm` namespace (standalone disassembler), `debug_protocol` namespace (protocol constants)
- Future: Can be used in diagnostic logging, debugger UI, and breakpoint management

---

## Integration Artifact

### `psx_reference_integrations.h`

**Location**: `cybergrime/psx_reference_integrations.h`

**Contents**:
1. `bios_syscalls` — A/B/C table enums with name lookup functions
2. `psx_events` — Event descriptor constants (HwVBLANK, HwCdRom, RCntCNT*, etc.)
3. `cdrom_constants` — CD-ROM status bits, IRQ types, commands, timing, FIFO depths
4. `psx_threads` — TCB layout constants and register indices
5. `mips_disasm` — Standalone MIPS R3000A disassembler with decode() and disasm_str()
6. `debug_protocol` — Serial debug protocol command/event/error constants

**Usage**: `#include "psx_reference_integrations.h"` in any CyberGrime source file.

---

## Cross-Reference Summary

| CyberGrime Component | Reference Source | Integration Type |
|---------------------|-----------------|-----------------|
| BIOS handler dispatch | PSoXide `hle_bios.rs` | Reference for dispatch pattern |
| BIOS function IDs | PSn00bSDK `stubs.json` | Complete enum mapping |
| BIOS function names | PSn00bSDK `stubs.json` | Name lookup for diagnostics |
| Event descriptors | PSn00bSDK `psxapi.h` | Constant definitions |
| TCB layout | PSn00bSDK `psxapi.h` | Register index mapping |
| CD-ROM status bits | PSoXide `cdrom.rs` | Status bit constants |
| CD-ROM IRQ types | PSoXide `cdrom.rs` | IRQ enum mapping |
| CD-ROM commands | PSn00bSDK `psxcd.h` | Command enum |
| CD-ROM timing | PSoXide `cdrom.rs` | Cycle constants |
| CD-ROM IRQ handler | PSn00bSDK `common.c` | Reference for handler logic |
| CD-ROM command flags | PSn00bSDK `common.c` | Command metadata table |
| MIPS disassembly | PSn00b-Debugger `mips_disassembler.cpp` | Standalone decoder |
| GTE register names | PSn00b-Debugger `mips_disassembler.cpp` | Cop2 nicknames |
| COP0 register names | PSn00b-Debugger `mips_disassembler.cpp` | Cop0 nicknames |
| Debug protocol | PSn00b-Debugger `protocol.txt` | Command/event/error enums |
| Exception handling | PSn00b-Debugger `monitor.asm` | Reference for vector layout |
| CPU instruction decode | PSoXide `cpu.rs` | Reference for ISA coverage |
| GTE timing | PSoXide `cpu.rs` | Latency constants |

---

## License Compliance

- **PSoXide** (GPL-2.0-or-later): Referenced for architecture and constants. No Rust code compiled into CyberGrime.
- **PSn00bSDK** (MPL-2.0): Referenced for BIOS API definitions and CD-ROM command metadata. No SDK code compiled into CyberGrime.
- **PSn00b-Debugger** (GPL-3.0): Disassembler logic adapted to C++ in `psx_reference_integrations.h`. Debug protocol constants reproduced.

All integrations are header-only reference constants and a standalone disassembler function. No binary linking or compilation of reference repo source occurs.

---

## GammaLanguage v1.1C Integration

### Overview

CyberGrime integrates with GammaLanguage v1.1C to enable MIPS assembly directives, CP0 register mapping, and PSXMatrix DMA dispatch through the Rust FFI zero-copy bridge.

### Integration: CyberGrime CP0 → GammaLanguage

| CyberGrime Component | GammaLanguage v1.1C Feature | Details |
|----------------------|----------------------------|---------|
| MIPS R3000A CP0 registers | `CP0_REG_MAP` opcode (0xA3) | Maps Status, Cause, EPC, BadVAddr, Count, Compare, EntryHi, Index into `CyberGrimeCP0Map` struct (32 bytes) |
| DMA controller (CH1/CH2) | `PSX_DMA_DISPATCH` opcode (0xA4) | Dispatches DMA channels via `PSXHwRegMap` (40 bytes) with HW interrupt triggering |
| GPU GP0/GP1 | `PSXHwRegMap` struct | Zero-copy access to GPU command/status registers via Rust FFI |
| I_STAT / I_MASK | `PSXHwRegMap` struct | Interrupt status and mask registers mapped for FFI bridge |
| Hardware interrupts | `RUST_FFI_CALL` → PEAK-4 | HW interrupt dispatch via function pointer table |
| Memory alignment | `@ALIGN_BOUND(BOUND=16)` | Ensures alignment parity between MIPS and Rust `repr(C)` types |
| Zero-copy memory | `&RUST_OFFSET` sigil | Loads PSX hw register offsets with READ_ONLY/VOLATILE/DMA_MAPPED flags |

### Rust FFI Bridge

The Rust FFI crate (`gamma_ffi.rs`) provides `repr(C)` parity types for all CyberGrime CP0 and PSXMatrix hardware register maps, enabling zero-copy memory access from Gamma's speculative buffer directly into PSX hardware register space.

### What's New

- **v1.1C:** Added `CyberGrimeCP0Map`, `PSXHwRegMap`, `RustFFIExport`, `RustFFIDispatchTable` types
- **v1.1C:** Added `CP0_REG_MAP` (0xA3) and `PSX_DMA_DISPATCH` (0xA4) opcodes
- **v1.1C:** CyberGrime CP0 state can be mapped into Gamma `RegisterBank.CP0Map` for speculative execution
- **v1.1C:** PSX DMA channels dispatchable via `RUST_FFI_CALL` → PEAK-4 HW interrupt dispatch
