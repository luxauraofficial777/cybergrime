#!/usr/bin/env python3
"""Run v33 in CyberGrime without breakpoints, then dump memory at 0x80100000
to verify the copy routine executed and the trampoline is present."""
import struct
import json
import os
import subprocess

DISC = r'c:\LuxAura\VoidWalkers_Project\DQLOSTTRANSLATION\dq4_frankenstein_v33.bin'
RUNNER = r'c:\LuxAura\VoidWalkers_Project\DQLOSTTRANSLATION\cybergrime\psx_agent_runner.exe'
TELEMETRY = r'c:\LuxAura\VoidWalkers_Project\DQLOSTTRANSLATION\cybergrime\telemetry\telemetry_v33_nobp.json'
TRIAGE = r'c:\LuxAura\VoidWalkers_Project\DQLOSTTRANSLATION\cybergrime\emulator_triage_v33_nobp.log'

# Run with 50M instructions, no breakpoints
cmd = [
    RUNNER,
    DISC,
    'v33_nobp',
    '50000000',
    TELEMETRY,
    '0',
    '--triage', TRIAGE,
    '--verbose',
]

print(f"Running CyberGrime: 50M instructions, no breakpoints")
print(f"Command: {' '.join(cmd[:6])} ...")
print()

try:
    proc = subprocess.run(cmd, capture_output=True, text=True, timeout=300)
    print(f"Exit code: {proc.returncode}")
    if proc.stderr:
        print(f"stderr: {proc.stderr[:500]}")
except subprocess.TimeoutExpired as e:
    print(f"TIMEOUT after 300s")
    if e.stdout:
        print(f"stdout (last 1000): ...{e.stdout[-1000:]}")

# Parse telemetry
if os.path.exists(TELEMETRY):
    with open(TELEMETRY, 'r', encoding='utf-8', errors='replace') as f:
        tel = json.load(f)
    print(f"\n=== Telemetry ===")
    print(f"Status: {tel.get('Pass_Status', 'UNKNOWN')}")
    print(f"Instructions: {tel.get('Instructions_Executed', 0)}")
    print(f"VBlanks: {tel.get('VBlank_Count', 0)}")
    print(f"Last PC: 0x{tel.get('Last_Known_PC', 0):08X}")
    print(f"Crashed: {tel.get('Crashed', False)}")
    print(f"Frozen: {tel.get('Frozen', False)}")
    if tel.get('Crashed'):
        print(f"Crash reason: {tel.get('Crash_Reason', '')}")
    
    # Check register dump
    regs = tel.get('Register_Dump', {})
    if regs:
        print(f"\nRegisters:")
        for k in ['PC', 'sp', 'gp', 'ra', 'v0', 'v1', 'a0', 'a1']:
            if k in regs:
                print(f"  {k}: {regs[k]}")
    
    # Check memory dump - see if it includes 0x80100000
    mem = tel.get('Memory_Dump', {})
    if mem:
        print(f"\nMemory dump: base={mem.get('base_addr')}, length={mem.get('length')}")
        hex_data = mem.get('hex', '')
        if hex_data:
            base = int(mem.get('base_addr', '0'), 16)
            print(f"  Base address: 0x{base:08X}")
            # Check if any of the trampoline bytes are in this dump
            # Trampoline at 0x801005C8 should be: 24010008 12210003 00000000 ...
            tramp_bytes = "08000124"  # LE of 0x24010008
            if tramp_bytes in hex_data:
                print(f"  TRAMPOLINE BYTES FOUND in memory dump!")
            else:
                print(f"  Trampoline bytes NOT in this dump range")
    
    # Check TTY tail for boot messages
    tty = tel.get('TTY_Tail', '')
    print(f"\nTTY Tail (last 2000 chars):")
    print(tty[-2000:])
    
    # Check BIOS calls
    bios_calls = tel.get('BIOS_Call_Log', [])
    print(f"\nBIOS calls: {len(bios_calls)}")
    if bios_calls:
        for call in bios_calls[-10:]:
            print(f"  {call}")
    
    # Check HW state
    hw = tel.get('HW_State', {})
    print(f"\nHW State:")
    for k, v in hw.items():
        print(f"  {k}: {v}")
else:
    print(f"\nNo telemetry file found at {TELEMETRY}")

# Check triage log
if os.path.exists(TRIAGE):
    with open(TRIAGE, 'r', errors='replace') as f:
        triage = f.read()
    print(f"\n=== Triage Log (last 2000 chars) ===")
    print(triage[-2000:])
else:
    print(f"\nNo triage log found at {TRIAGE}")
