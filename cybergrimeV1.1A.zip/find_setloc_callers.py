#!/usr/bin/env python3
"""
Find all callers of the B0(07) Setloc BIOS stub.
The stub is at 0x800A28F8 (addiu $t2, $zero, 0xB0; jr $t2; addiu $t1, $zero, 7)
Search for jal 0x800A28F8 = 0x0C028A3E
Also search for jal to nearby addresses (0x800A28FC, 0x800A2900)
"""
import struct

disc_path = r"C:\LuxAura\VoidWalkers_Project\DQLOSTTRANSLATION\build_staging\dq4_gold.bin"
SECTOR_SIZE = 2352
USER_SIZE = 2048
EXE_LBA = 24
HEADER = 24
LOAD_ADDR = 0x80017F00

with open(disc_path, "rb") as f:
    disc = f.read()

def read_exe_from_disc(disc, start_lba, exe_size):
    exe = bytearray()
    sectors_needed = (exe_size + USER_SIZE - 1) // USER_SIZE
    for i in range(sectors_needed):
        sec_start = (start_lba + i) * SECTOR_SIZE + HEADER
        chunk = disc[sec_start:sec_start + USER_SIZE]
        exe.extend(chunk)
    return bytes(exe[:exe_size])

exe = read_exe_from_disc(disc, EXE_LBA, 677888)
print(f"EXE: {len(exe)} bytes")

# B0(07) Setloc stub at 0x800A28F8
# jal encodes target = (addr & 0x0FFFFFFF) >> 2
# 0x800A28F8: target field = (0x00A28F8) >> 2 = 0x028A3E
# jal instruction = 0x0C000000 | 0x028A3E = 0x0C028A3E

stub_addr = 0x800A28F8
jal_target = (stub_addr & 0x0FFFFFFF) >> 2
jal_insn = 0x0C000000 | jal_target

print(f"Stub address: 0x{stub_addr:08X}")
print(f"jal instruction: 0x{jal_insn:08X}")

# Search for jal to the stub
pat = struct.pack("<I", jal_insn)
idx = 0
callers = []
while True:
    idx = exe.find(pat, idx)
    if idx == -1: break
    ram = idx + LOAD_ADDR
    callers.append(ram)
    idx += 1

print(f"\nFound {len(callers)} direct callers of B0(07) Setloc stub:")
for c in callers:
    print(f"  0x{c:08X}")

# Also search for jal to 0x800A28FC and 0x800A2900 (other entry points)
for alt_addr in [0x800A28FC, 0x800A2900]:
    alt_target = (alt_addr & 0x0FFFFFFF) >> 2
    alt_insn = 0x0C000000 | alt_target
    alt_pat = struct.pack("<I", alt_insn)
    idx = 0
    alt_callers = []
    while True:
        idx = exe.find(alt_pat, idx)
        if idx == -1: break
        alt_callers.append(idx + LOAD_ADDR)
        idx += 1
    if alt_callers:
        print(f"\nAlso found {len(alt_callers)} callers of 0x{alt_addr:08X}:")
        for c in alt_callers:
            print(f"  0x{c:08X}")

# For each caller, disassemble surrounding context (16 instructions before, 16 after)
REGS = ["$zero","$at","$v0","$v1","$a0","$a1","$a2","$a3",
        "$t0","$t1","$t2","$t3","$t4","$t5","$t6","$t7",
        "$s0","$s1","$s2","$s3","$s4","$s5","$s6","$s7",
        "$t8","$t9","$k0","$k1","$gp","$sp","$fp","$ra"]

def decode_mips(word, addr):
    op = (word >> 26) & 0x3F
    rs = (word >> 21) & 0x1F
    rt = (word >> 16) & 0x1F
    rd = (word >> 11) & 0x1F
    shamt = (word >> 6) & 0x1F
    funct = word & 0x3F
    imm = word & 0xFFFF
    simm = imm if imm < 0x8000 else imm - 0x10000
    target = word & 0x3FFFFFF
    if op == 0:
        if funct == 0x20: return f"add {REGS[rd]}, {REGS[rs]}, {REGS[rt]}"
        if funct == 0x21: return f"addu {REGS[rd]}, {REGS[rs]}, {REGS[rt]}"
        if funct == 0x23: return f"subu {REGS[rd]}, {REGS[rs]}, {REGS[rt]}"
        if funct == 0x24: return f"and {REGS[rd]}, {REGS[rs]}, {REGS[rt]}"
        if funct == 0x25: return f"or {REGS[rd]}, {REGS[rs]}, {REGS[rt]}"
        if funct == 0x26: return f"xor {REGS[rd]}, {REGS[rs]}, {REGS[rt]}"
        if funct == 0x27: return f"nor {REGS[rd]}, {REGS[rs]}, {REGS[rt]}"
        if funct == 0x2A: return f"slt {REGS[rd]}, {REGS[rs]}, {REGS[rt]}"
        if funct == 0x2B: return f"sltu {REGS[rd]}, {REGS[rs]}, {REGS[rt]}"
        if funct == 0x00: return f"sll {REGS[rd]}, {REGS[rt]}, {shamt}"
        if funct == 0x03: return f"sra {REGS[rd]}, {REGS[rt]}, {shamt}"
        if funct == 0x07: return f"srav {REGS[rd]}, {REGS[rt]}, {REGS[rs]}"
        if funct == 0x04: return f"sllv {REGS[rd]}, {REGS[rt]}, {REGS[rs]}"
        if funct == 0x06: return f"srlv {REGS[rd]}, {REGS[rt]}, {REGS[rs]}"
        if funct == 0x08: return f"jr {REGS[rs]}"
        if funct == 0x09: return f"jalr {REGS[rd]}, {REGS[rs]}"
        if funct == 0x0C: return f"syscall"
        if funct == 0x10: return f"mfhi {REGS[rd]}"
        if funct == 0x12: return f"mflo {REGS[rd]}"
        if funct == 0x18: return f"mult {REGS[rs]}, {REGS[rt]}"
        if funct == 0x19: return f"multu {REGS[rs]}, {REGS[rt]}"
        if funct == 0x1A: return f"div {REGS[rs]}, {REGS[rt]}"
        if funct == 0x1B: return f"divu {REGS[rs]}, {REGS[rt]}"
        return f".word 0x{word:08X}"
    if op == 0x01:
        if rt == 0x00: return f"bltz {REGS[rs]}, 0x{(addr + 4 + simm*4):08X}"
        if rt == 0x01: return f"bgez {REGS[rs]}, 0x{(addr + 4 + simm*4):08X}"
        return f".word 0x{word:08X}"
    if op == 0x02: return f"j 0x{(target << 2):08X}"
    if op == 0x03: return f"jal 0x{(target << 2):08X}"
    if op == 0x04: return f"beq {REGS[rs]}, {REGS[rt]}, 0x{(addr + 4 + simm*4):08X}"
    if op == 0x05: return f"bne {REGS[rs]}, {REGS[rt]}, 0x{(addr + 4 + simm*4):08X}"
    if op == 0x06: return f"blez {REGS[rs]}, 0x{(addr + 4 + simm*4):08X}"
    if op == 0x07: return f"bgtz {REGS[rs]}, 0x{(addr + 4 + simm*4):08X}"
    if op == 0x08: return f"addi {REGS[rt]}, {REGS[rs]}, {simm}"
    if op == 0x09: return f"addiu {REGS[rt]}, {REGS[rs]}, {simm}"
    if op == 0x0A: return f"slti {REGS[rt]}, {REGS[rs]}, {simm}"
    if op == 0x0B: return f"sltiu {REGS[rt]}, {REGS[rs]}, {simm}"
    if op == 0x0C: return f"andi {REGS[rt]}, {REGS[rs]}, 0x{imm:04X}"
    if op == 0x0D: return f"ori {REGS[rt]}, {REGS[rs]}, 0x{imm:04X}"
    if op == 0x0E: return f"xori {REGS[rt]}, {REGS[rs]}, 0x{imm:04X}"
    if op == 0x0F: return f"lui {REGS[rt]}, 0x{imm:04X}"
    if op == 0x20: return f"lb {REGS[rt]}, {simm}({REGS[rs]})"
    if op == 0x21: return f"lh {REGS[rt]}, {simm}({REGS[rs]})"
    if op == 0x23: return f"lw {REGS[rt]}, {simm}({REGS[rs]})"
    if op == 0x24: return f"lbu {REGS[rt]}, {simm}({REGS[rs]})"
    if op == 0x25: return f"lhu {REGS[rt]}, {simm}({REGS[rs]})"
    if op == 0x28: return f"sb {REGS[rt]}, {simm}({REGS[rs]})"
    if op == 0x29: return f"sh {REGS[rt]}, {simm}({REGS[rs]})"
    if op == 0x2B: return f"sw {REGS[rt]}, {simm}({REGS[rs]})"
    return f".word 0x{word:08X}"

# Disassemble around each caller
for caller_ram in callers:
    caller_off = caller_ram - LOAD_ADDR
    start = max(0, caller_off - 64)  # 16 instructions before
    end = min(len(exe), caller_off + 68)  # 17 instructions after
    
    print(f"\n=== Context around jal Setloc at 0x{caller_ram:08X} ===")
    for i in range(start & ~3, end, 4):
        if i + 4 > len(exe): continue
        word = struct.unpack("<I", exe[i:i+4])[0]
        ram = i + LOAD_ADDR
        asm = decode_mips(word, ram)
        marker = " <-- jal Setloc" if ram == caller_ram else ""
        # Highlight BCD-related or address-loading instructions
        imm = word & 0xFFFF
        if (word >> 26) == 0x0F:  # lui
            marker += f" [lui 0x{imm:04X}]"
        elif (word >> 26) in (0x08, 0x09) and imm in (0x32, 0x34, 0x71, 0x23, 0x31, 0x08, 0xA0, 0x75, 0x4500):
            marker += f" [imm 0x{imm:04X}]"
        print(f"  0x{ram:08X}: {word:08X}  {asm}{marker}")
