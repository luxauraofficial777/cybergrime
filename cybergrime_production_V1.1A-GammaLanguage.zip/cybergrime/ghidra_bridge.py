#!/usr/bin/env python3
"""
ghidra_bridge.py — Bridge between live emulator PC and Ghidra decompiled output.

Uses a pre-exported function map (dw7_function_map.json) for fast lookup.
Optionally queries Ghidra headless for decompiled C of specific functions.
"""

import json
import os
import subprocess
from typing import Optional, Dict, Any


class GhidraBridge:
    """Bridge between live emulator PC and Ghidra decompiled output."""

    def __init__(self, function_map_path: str = "",
                 ghidra_project_path: str = "",
                 ghidra_headless_path: str = ""):
        self.project = ghidra_project_path
        self.headless = ghidra_headless_path
        self._cache: Dict[int, dict] = {}  # function entry → decompiled info
        self._function_map: list = []
        self._sorted_functions: list = []

        if function_map_path and os.path.exists(function_map_path):
            self.load_function_map(function_map_path)

    def load_function_map(self, path: str):
        """Load pre-exported function boundary map from Ghidra."""
        with open(path) as f:
            data = json.load(f)
        if isinstance(data, list):
            self._function_map = data
        elif isinstance(data, dict) and 'functions' in data:
            self._function_map = data['functions']
        else:
            self._function_map = []

        # Sort by entry address for binary search
        self._sorted_functions = sorted(
            self._function_map,
            key=lambda f: int(f.get('entry', '0x0'), 16)
        )
        print(f"[GHIDRA] Loaded {len(self._function_map)} functions from {path}")

    def query_pc(self, ram_addr: int) -> Optional[Dict[str, Any]]:
        """Given a RAM address, return the containing function's info."""
        func = self._find_function(ram_addr)
        if not func:
            return None

        entry = int(func['entry'], 16)

        # Check cache
        if entry in self._cache:
            result = self._cache[entry].copy()
            result['offset_in_function'] = ram_addr - entry
            return result

        result = {
            'function_name': func.get('name', f"FUN_{entry:08X}"),
            'entry': func['entry'],
            'end': func.get('end', '0x00000000'),
            'decompiled': func.get('decompiled', '// Not available'),
            'offset_in_function': ram_addr - entry,
        }
        self._cache[entry] = result
        return result

    def _find_function(self, ram_addr: int) -> Optional[dict]:
        """Binary search the function map for containing function."""
        if not self._sorted_functions:
            return None

        lo, hi = 0, len(self._sorted_functions) - 1
        while lo <= hi:
            mid = (lo + hi) // 2
            func = self._sorted_functions[mid]
            entry = int(func.get('entry', '0x0'), 16)
            end = int(func.get('end', '0x0'), 16)

            if entry <= ram_addr < end:
                return func
            elif ram_addr < entry:
                hi = mid - 1
            else:
                lo = mid + 1
        return None

    def format_context(self, ram_addr: int, regs: dict = None,
                       mem_dump: dict = None) -> str:
        """Format a human-readable context display for a breakpoint hit."""
        info = self.query_pc(ram_addr)
        if not info:
            return f"No function found at {hex(ram_addr)}"

        lines = []
        lines.append("┌─ BREAKPOINT CONTEXT " + "─" * 50)
        lines.append(f"│ PC: {hex(ram_addr)}  Offset in function: +{info['offset_in_function']}")
        lines.append(f"│ Function: {info['function_name']} ({info['entry']} - {info['end']})")
        lines.append("│")

        if info.get('decompiled', '// Not available') != '// Not available':
            lines.append("│ Decompiled C:")
            for line in info['decompiled'].split('\n'):
                lines.append(f"│   {line}")
            lines.append("│")

        if regs:
            lines.append("│ Registers:")
            for name in ['v0', 'v1', 'a0', 'a1', 'a2', 'a3',
                         't0', 't1', 't2', 't3', 'ra', 'sp', 'gp']:
                if name in regs:
                    lines.append(f"│   ${name:<4} = {regs[name]}")
            lines.append("│")

        if mem_dump:
            lines.append("│ Memory:")
            for addr, val in list(mem_dump.items())[:8]:
                lines.append(f"│   {addr} = {val}")
            lines.append("│")

        lines.append("└" + "─" * 70)
        return '\n'.join(lines)


def generate_default_function_map() -> list:
    """Generate a default function map from known reverse engineering data."""
    return [
        {"entry": "0x80017F00", "end": "0x80018000", "name": "_start",
         "description": "EXE entry / boot stub"},
        {"entry": "0x80041CE8", "end": "0x80041E00", "name": "huffman_decompress_inline",
         "description": "DQ4 inline Huffman decompression (4 copies in menu render)"},
        {"entry": "0x80073670", "end": "0x800738A0", "name": "huffman_decompress_primary",
         "description": "Primary Huffman decompression (9 JAL call sites)"},
        {"entry": "0x80084BF0", "end": "0x80084D00", "name": "huffman_decompress_secondary",
         "description": "Secondary Huffman decompression (3 JAL call sites)"},
        {"entry": "0x800562C0", "end": "0x80056400", "name": "hbd_subblock_parser",
         "description": "HBD sub-block type/count parser"},
        {"entry": "0x8008E284", "end": "0x8008E300", "name": "bss_clear_entry",
         "description": "Original PC0 — BSS clear entry point"},
        {"entry": "0x80098898", "end": "0x80098900", "name": "cdrom_cmd_handler",
         "description": "CD-ROM command handler"},
        {"entry": "0x80098670", "end": "0x800986A0", "name": "cdrom_after_branch",
         "description": "Post-disc-check continuation"},
        {"entry": "0x8009F790", "end": "0x8009F900", "name": "gpu_display_setup",
         "description": "GPU display init (6 callers)"},
        {"entry": "0x8009F828", "end": "0x8009F840", "name": "gpu_cw_call_site",
         "description": "GP0 command dispatch (sole JAL site)"},
        {"entry": "0x800A5DA0", "end": "0x800A5E00", "name": "gpu_cw_trampoline",
         "description": "BIOS A:0x49 wrapper for GPU_cw"},
        {"entry": "0x800D9E80", "end": "0x800DA000", "name": "cdrom_thread_entry",
         "description": "CD-ROM thread entry (zeroed by BSS — ROOT CAUSE)"},
        {"entry": "0x800BC700", "end": "0x800BC740", "name": "copy_routine_injected",
         "description": "Copy routine (injected, Options A/B)"},
    ]
