#!/usr/bin/env python3
"""Find how the LBA/descriptor table is accessed - broader search."""
import struct

exe_path = r'..\translation\SLUSP012.06_disc_extract.bin'
with open(exe_path, 'rb') as f:
    data = f.read()

LOAD_ADDR = 0x80017F00

def f2r(off):
    return LOAD_ADDR + off - 0x800

def r2f(ram):
    return ram - LOAD_ADDR + 0x800

def disasm(insn):
    op = (insn >> 26) & 0x3F
    rs = (insn >> 21) & 0x1F
    rt = (insn >> 16) & 0x1F
    rd = (insn >> 11) & 0x1F
    shamt = (insn >> 6) & 0x1F
    funct = insn & 0x3F
    imm = insn & 0xFFFF
    simm = imm if imm < 0x8000 else imm - 0x10000
    target = insn & 0x3FFFFFF
    R = ['zero','at','v0','v1','a0','a1','a2','a3','t0','t1','t2','t3','t4','t5','t6','t7','s0','s1','s2','s3','s4','s5','s6','s7','t8','t9','k0','k1','gp','sp','fp','ra']
    if op==0:
        if funct==0x08: return f"jr ${R[rs]}"
        if funct==0x09: return f"jalr ${R[rd]},${R[rs]}"
        if funct==0x21: return f"addu ${R[rd]},${R[rs]},${R[rt]}"
        if funct==0x23: return f"subu ${R[rd]},${R[rs]},${R[rt]}"
        if funct==0x24: return f"and ${R[rd]},${R[rs]},${R[rt]}"
        if funct==0x25: return f"or ${R[rd]},${R[rs]},${R[rt]}"
        if funct==0x2A: return f"slt ${R[rd]},${R[rs]},${R[rt]}"
        if funct==0x00: return "nop" if insn==0 else f"sll ${R[rd]},${R[rt]},{shamt}"
        if funct==0x03: return f"sra ${R[rd]},${R[rt]},{shamt}"
        if funct==0x0C: return "syscall"
        if funct==0x2B: return f"sltu ${R[rd]},${R[rs]},${R[rt]}"
        if funct==0x04: return f"sllv ${R[rd]},${R[rt]},${R[rs]}"
        if funct==0x06: return f"srlv ${R[rd]},${R[rt]},${R[rs]}"
        if funct==0x07: return f"srav ${R[rd]},${R[rt]},${R[rs]}"
        if funct==0x26: return f"nor ${R[rd]},${R[rs]},${R[rt]}"
        if funct==0x22: return f"add ${R[rd]},${R[rs]},${R[rt]}"
        if funct==0x2C: return f"slt ${R[rd]},${R[rs]},${R[rt]}"
        return f".word 0x{insn:08X}"
    if op==0x01:
        if rt==0: return f"bltz ${R[rs]},+{simm*4+4}"
        if rt==1: return f"bgez ${R[rs]},+{simm*4+4}"
        return f".word 0x{insn:08X}"
    if op==0x02: return f"j 0x{(target<<2):08X}"
    if op==0x03: return f"jal 0x{(target<<2):08X}"
    if op==0x04: return f"beq ${R[rs]},${R[rt]},+{simm*4+4}"
    if op==0x05: return f"bne ${R[rs]},${R[rt]},+{simm*4+4}"
    if op==0x06: return f"blez ${R[rs]},+{simm*4+4}"
    if op==0x07: return f"bgtz ${R[rs]},+{simm*4+4}"
    if op==0x08: return f"addi ${R[rt]},${R[rs]},{simm}"
    if op==0x09: return f"addiu ${R[rt]},${R[rs]},{simm}"
    if op==0x0A: return f"slti ${R[rt]},${R[rs]},{simm}"
    if op==0x0B: return f"sltiu ${R[rt]},${R[rs]},{simm}"
    if op==0x0C: return f"andi ${R[rt]},${R[rs]},0x{imm:04X}"
    if op==0x0D: return f"ori ${R[rt]},${R[rs]},0x{imm:04X}"
    if op==0x0E: return f"xori ${R[rt]},${R[rs]},0x{imm:04X}"
    if op==0x0F: return f"lui ${R[rt]},0x{imm:04X}"
    if op==0x20: return f"lb ${R[rt]},{simm}(${R[rs]})"
    if op==0x21: return f"lh ${R[rt]},{simm}(${R[rs]})"
    if op==0x23: return f"lw ${R[rt]},{simm}(${R[rs]})"
    if op==0x24: return f"lbu ${R[rt]},{simm}(${R[rs]})"
    if op==0x25: return f"lhu ${R[rt]},{simm}(${R[rs]})"
    if op==0x28: return f"sb ${R[rt]},{simm}(${R[rs]})"
    if op==0x29: return f"sh ${R[rt]},{simm}(${R[rs]})"
    if op==0x2B: return f"sw ${R[rt]},{simm}(${R[rs]})"
    return f".word 0x{insn:08X}"

# 1. Search for ANY lui + addiu/ori that constructs address in 0x8001B000-0x8001C000
print('=== All references to 0x8001B000-0x8001C000 ===')
hits = []
for i in range(0x800, len(data) - 8, 4):
    insn = struct.unpack('<I', data[i:i+4])[0]
    op = (insn >> 26) & 0x3F
    if op == 0x0F:  # lui
        imm = insn & 0xFFFF
        reg = (insn >> 16) & 0x1F
        # Check next 6 instructions for addiu/ori with matching low bits
        for j in range(1, 8):
            if i + j*4 + 4 > len(data):
                break
            next_insn = struct.unpack('<I', data[i+j*4:i+j*4+4])[0]
            next_op = (next_insn >> 26) & 0x3F
            if next_op == 0x09:  # addiu
                next_imm = next_insn & 0xFFFF
                next_simm = next_imm if next_imm < 0x8000 else next_imm - 0x10000
                addr = ((imm << 16) + next_simm) & 0xFFFFFFFF
                if 0x8001B000 <= addr <= 0x8001C000:
                    ram = f2r(i)
                    hits.append((ram, addr, reg))
                    print(f'\n  lui ${reg},0x{imm:04X} + addiu 0x{next_imm:04X} = 0x{addr:08X} at 0x{ram:08X}')
                    for k in range(0, 20):
                        off2 = i + k*4
                        if off2 + 4 <= len(data):
                            insn2 = struct.unpack('<I', data[off2:off2+4])[0]
                            r2 = f2r(off2)
                            print(f'    0x{r2:08X}: 0x{insn2:08X}  {disasm(insn2)}')
                    break
            elif next_op == 0x0D:  # ori
                next_imm = next_insn & 0xFFFF
                addr = (imm << 16) | next_imm
                if 0x8001B000 <= addr <= 0x8001C000:
                    ram = f2r(i)
                    hits.append((ram, addr, reg))
                    print(f'\n  lui ${reg},0x{imm:04X} + ori 0x{next_imm:04X} = 0x{addr:08X} at 0x{ram:08X}')
                    for k in range(0, 20):
                        off2 = i + k*4
                        if off2 + 4 <= len(data):
                            insn2 = struct.unpack('<I', data[off2:off2+4])[0]
                            r2 = f2r(off2)
                            print(f'    0x{r2:08X}: 0x{insn2:08X}  {disasm(insn2)}')
                    break

if not hits:
    print('  NONE FOUND')

# 2. The table might be accessed via a register loaded from another location.
# Let's search for the table base stored as a word anywhere in the EXE data
print('\n=== Search for 0x8001B800 as a stored word ===')
target_vals = [0x8001B800, 0x8001B804, 0x8001B900, 0x8001B980]
for tv in target_vals:
    tb = struct.pack('<I', tv)
    pos = 0x800
    while True:
        idx = data.find(tb, pos)
        if idx == -1:
            break
        ram = f2r(idx)
        print(f'  0x{tv:08X} at file 0x{idx:X} (RAM 0x{ram:08X})')
        pos = idx + 1

# 3. Maybe the table is accessed relative to the EXE start.
# The EXE loads at 0x80017F00. Table at 0x8001B800 = load_addr + 0x3900
# Search for addiu $reg, $reg, 0x3900 or similar
print('\n=== Search for offset 0x3900 (table relative to load addr) ===')
for i in range(0x800, len(data) - 4, 4):
    insn = struct.unpack('<I', data[i:i+4])[0]
    if (insn >> 26) == 0x09:  # addiu
        imm = insn & 0xFFFF
        if imm == 0x3900:
            ram = f2r(i)
            print(f'  addiu with 0x3900 at 0x{ram:08X}: {disasm(insn)}')

# 4. Maybe it's accessed via a register that was loaded from a pointer chain.
# Let's look for the "cdrom file" string more carefully.
# The string "cdrom file = %d" is at 0x80028F87.
# Let's check if it's referenced via a pointer table
print('\n=== Pointer table search for string at 0x80028F87 ===')
str_addr = 0x80028F87
str_bytes = struct.pack('<I', str_addr)
pos = 0x800
while True:
    idx = data.find(str_bytes, pos)
    if idx == -1:
        break
    ram = f2r(idx)
    print(f'  Pointer to string at file 0x{idx:X} (RAM 0x{ram:08X})')
    # Show context
    for k in range(-8, 12, 4):
        off2 = idx + k
        if 0x800 <= off2 and off2 + 4 <= len(data):
            val = struct.unpack('<I', data[off2:off2+4])[0]
            r2 = f2r(off2)
            print(f'    0x{r2:08X}: 0x{val:08X}')
    pos = idx + 1

# 5. Let's look at the function at 0x80098608 (CDROM dispatch) more carefully
# This is where we patch the CD-ROM command intercept. It might show how HBD is read.
print('\n=== CD-ROM dispatch function at 0x80098608 ===')
start_off = r2f(0x80098600)
for i in range(0, 80, 4):
    off = start_off + i
    if off + 4 <= len(data):
        insn = struct.unpack('<I', data[off:off+4])[0]
        ram = f2r(off)
        print(f'  0x{ram:08X}: 0x{insn:08X}  {disasm(insn)}')

# 6. Look at the CD-ROM init function area (0x80097xxx)
print('\n=== CD-ROM init area 0x80097000-0x80097100 ===')
start_off = r2f(0x80097000)
for i in range(0, 64, 4):
    off = start_off + i
    if off + 4 <= len(data):
        insn = struct.unpack('<I', data[off:off+4])[0]
        ram = f2r(off)
        print(f'  0x{ram:08X}: 0x{insn:08X}  {disasm(insn)}')

print('\n=== Done ===')
