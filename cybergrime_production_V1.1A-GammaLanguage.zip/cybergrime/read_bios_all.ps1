$j = Get-Content telemetry_dma3_55m.json -Raw | ConvertFrom-Json
Write-Host "=== All BIOS Calls (last 64) ==="
foreach ($e in $j.BIOS_Call_Log) {
    $fn = '{0:X2}' -f [int]$e.fn
    Write-Host ("  #{0} {1}:0x{2} ra=0x{3} a0=0x{4} a1=0x{5} a2=0x{6} a3=0x{7}" -f $e.instr, $e.table, $fn, $e.ra, $e.a0, $e.a1, $e.a2, $e.a3)
}
Write-Host ""
Write-Host "=== Unique BIOS calls ==="
$calls = @{}
foreach ($e in $j.BIOS_Call_Log) {
    $fn = '{0:X2}' -f [int]$e.fn
    $key = "$($e.table):0x$fn"
    if (-not $calls.ContainsKey($key)) {
        $calls[$key] = 0
    }
    $calls[$key]++
}
foreach ($k in ($calls.Keys | Sort-Object)) {
    Write-Host "  $k : $($calls[$k]) calls"
}
