#!/usr/bin/env python3
"""Map STR/FMV files on DW7 and DQ4 discs, and check what's on the Frankenstein disc."""
import struct

def parse_iso_dir(disc, dir_lba, dir_size, depth=0, max_depth=3):
    """Parse ISO 9660 directory records recursively."""
    entries = []
    remaining = dir_size
    sector_idx = 0
    while remaining > 0:
        offset = dir_lba * 2352 + 24 + sector_idx * 2352
        if offset + 2048 > len(disc):
            break
        chunk = disc[offset : offset + 2048]
        pos = 0
        while pos < len(chunk) and chunk[pos] != 0:
            rec_len = chunk[pos]
            if rec_len == 0:
                break
            lba = struct.unpack_from('<I', chunk, pos + 2)[0]
            size = struct.unpack_from('<I', chunk, pos + 10)[0]
            flags = chunk[pos + 25]
            name_len = chunk[pos + 32]
            name = chunk[pos + 33 : pos + 33 + name_len]
            name_str = name.decode('ascii', errors='replace')
            if name_str not in ('.', '..'):
                entries.append((name_str, lba, size, flags, depth))
                if (flags & 0x02) and depth < max_depth:
                    sub = parse_iso_dir(disc, lba, size, depth + 1, max_depth)
                    entries.extend(sub)
            pos += rec_len
        remaining -= 2048
        sector_idx += 1
    return entries

def get_pvd(disc):
    """Get primary volume descriptor from LBA 16."""
    offset = 16 * 2352 + 24
    pvd = disc[offset : offset + 2048]
    if pvd[1:6] == b'CD001':
        root_rec = pvd[156:156+34]
        root_lba = struct.unpack_from('<I', root_rec, 2)[0]
        root_size = struct.unpack_from('<I', root_rec, 10)[0]
        return root_lba, root_size
    return None, None

discs = [
    ('DW7 original', r'C:\LuxAura\VoidWalkers_Project\DQLOSTTRANSLATION\DW7D1\DW7D1.bin'),
    ('DQ4 original', r'C:\LuxAura\VoidWalkers_Project\DQLOSTTRANSLATION\Dragon Quest IV - Michibikareshi Mono Tachi (Japan).bin'),
    ('Frankenstein', r'C:\LuxAura\VoidWalkers_Project\DQLOSTTRANSLATION\dq4_frankenstein_v100_ds.bin'),
]

for disc_name, disc_path in discs:
    print(f"\n{'='*60}")
    print(f"  {disc_name}")
    print(f"{'='*60}")
    with open(disc_path, 'rb') as f:
        disc = f.read()
    print(f"  Size: {len(disc)} bytes ({len(disc)/1024/1024:.1f} MB)")
    
    root_lba, root_size = get_pvd(disc)
    if root_lba is None:
        print("  No ISO 9660 PVD found!")
        continue
    
    print(f"  Root dir: LBA={root_lba}, size={root_size}")
    entries = parse_iso_dir(disc, root_lba, root_size)
    
    # Show all files, highlight STR/FMV
    str_files = []
    all_files = []
    for name, lba, size, flags, depth in entries:
        is_dir = flags & 0x02
        indent = "  " * (depth + 1)
        clean_name = name.split(';')[0]
        ext = clean_name.split('.')[-1].upper() if '.' in clean_name else ''
        ftype = "DIR " if is_dir else "FILE"
        size_str = f"{size/1024/1024:.2f}MB" if size > 1048576 else f"{size/1024:.0f}KB"
        
        if not is_dir:
            all_files.append((name, lba, size))
        
        if ext in ('STR', 'BS', 'XA', 'PAC') or 'FMV' in clean_name.upper() or 'MOVIE' in clean_name.upper():
            marker = " <--- STR/FMV"
            str_files.append((name, lba, size, ext))
        else:
            marker = ""
        
        print(f"  {indent}{ftype} {name:30s} LBA={lba:6d} size={size:10d} ({size_str}){marker}")
    
    print(f"\n  Total files: {len(all_files)}")
    print(f"  STR/FMV files: {len(str_files)}")
    for name, lba, size, ext in str_files:
        print(f"    {name:30s} LBA={lba:6d} size={size:10d} ({size/1024/1024:.2f}MB) ext={ext}")

# Now compare: what LBA ranges do DW7 STR files occupy vs what's on Frankenstein at those LBAs?
print(f"\n{'='*60}")
print(f"  COMPARISON: DW7 STR LBA ranges vs Frankenstein disc")
print(f"{'='*60}")

with open(r'C:\LuxAura\VoidWalkers_Project\DQLOSTTRANSLATION\DW7D1\DW7D1.bin', 'rb') as f:
    dw7 = f.read()
with open(r'C:\LuxAura\VoidWalkers_Project\DQLOSTTRANSLATION\dq4_frankenstein_v100_ds.bin', 'rb') as f:
    frank = f.read()
with open(r'C:\LuxAura\VoidWalkers_Project\DQLOSTTRANSLATION\Dragon Quest IV - Michibikareshi Mono Tachi (Japan).bin', 'rb') as f:
    dq4 = f.read()

dw7_root_lba, dw7_root_size = get_pvd(dw7)
dw7_entries = parse_iso_dir(dw7, dw7_root_lba, dw7_root_size)

for name, lba, size, flags, depth in dw7_entries:
    if flags & 0x02:
        continue
    clean_name = name.split(';')[0]
    ext = clean_name.split('.')[-1].upper() if '.' in clean_name else ''
    if ext in ('STR', 'BS', 'XA') or 'FMV' in clean_name.upper():
        num_sectors = (size + 2047) // 2048
        end_lba = lba + num_sectors
        print(f"\n  {name}: LBA {lba}-{end_lba} ({num_sectors} sectors, {size/1024/1024:.2f}MB)")
        
        # Check first sector on DW7
        dw7_off = lba * 2352 + 24
        dw7_data = dw7[dw7_off:dw7_off+32]
        print(f"    DW7  first 32 bytes: {dw7_data.hex()}")
        
        # Check same LBA on Frankenstein
        frank_off = lba * 2352 + 24
        if frank_off + 32 <= len(frank):
            frank_data = frank[frank_off:frank_off+32]
            print(f"    Frank first 32 bytes: {frank_data.hex()}")
            match = dw7_data == frank_data
            print(f"    Match: {'YES' if match else 'NO (DIFFERENT DATA)'}")
        else:
            print(f"    Frank: beyond disc size")
        
        # Check if DQ4 has any STR files
        dq4_off = lba * 2352 + 24
        if dq4_off + 32 <= len(dq4):
            dq4_data = dq4[dq4_off:dq4_off+32]
            print(f"    DQ4  first 32 bytes: {dq4_data.hex()}")
        else:
            print(f"    DQ4:  beyond disc size")
