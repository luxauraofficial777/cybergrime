// ============================================================
// frankenstein_driver.cpp
//
// Native C++ Binary Re-authoring Injection Framework
//
// Treats PSX EXEs as fully programmable bootloaders.
// The EXE is a driver. The HBD is the payload. We control both.
//
// Cross-referenced with VectorDB findings:
// - HBD_TYPE_TRAMPOLINE_DIAGNOSTIC: Divergence at 0x800562E4
// - HBD_PROCESSING_BLUEPRINT: 3 transformations (A/B/C)
// - DISC_CHECK_BYPASS_PROGRESS: Surgical patches for 0x800E3D90, 0x800506CC
// - FULL_STACK_DIAGNOSTIC: BIOS vector corruption at 0x800E2000
// - DUAL_FORK_ROADMAP: Block header reader at 0x80042A04
// ============================================================

#include "frankenstein_driver.h"
#include "psx_binary_ops.h"
#include <algorithm>
#include <cstring>
#include <cstdio>
#include <fstream>
#include <sstream>
#include <cmath>

// ============================================================
// Utility functions
// ============================================================

static std::vector<uint8_t> read_file(const char* path) {
    std::ifstream f(path, std::ios::binary);
    if (!f) return {};
    f.seekg(0, std::ios::end);
    size_t sz = (size_t)f.tellg();
    f.seekg(0);
    std::vector<uint8_t> data(sz);
    f.read((char*)data.data(), sz);
    return data;
}

static bool write_file(const char* path, const uint8_t* data, size_t sz) {
    std::ofstream f(path, std::ios::binary);
    if (!f) return false;
    f.write((const char*)data, sz);
    return f.good();
}

static uint32_t rd32(const uint8_t* p) {
    return (uint32_t)p[0] | ((uint32_t)p[1]<<8) | ((uint32_t)p[2]<<16) | ((uint32_t)p[3]<<24);
}

static void wr32(uint8_t* p, uint32_t v) {
    p[0]=v&0xFF; p[1]=(v>>8)&0xFF; p[2]=(v>>16)&0xFF; p[3]=(v>>24)&0xFF;
}

static uint16_t rd16(const uint8_t* p) {
    return (uint16_t)p[0] | ((uint16_t)p[1]<<8);
}

static void wr16(uint8_t* p, uint16_t v) {
    p[0]=v&0xFF; p[1]=(v>>8)&0xFF;
}

// ============================================================
// FunctionExtractor
// ============================================================

bool FunctionExtractor::load(const uint8_t* exe_data, uint32_t exe_size) {
    if (exe_size < 0x800) return false;
    data.assign(exe_data, exe_data + exe_size);

    // Parse PS-X EXE header
    if (std::memcmp(data.data(), "PS-X EXE", 8) != 0) return false;

    std::memcpy(&pc0_val, data.data() + 0x10, 4);
    std::memcpy(&load_addr, data.data() + 0x18, 4);
    std::memcpy(&text_sz, data.data() + 0x1C, 4);

    return true;
}

uint32_t FunctionExtractor::find_func_end(uint32_t start_offset, uint32_t max_size) {
    // Scan for jr $ra (0x03E00008) followed by nop (0x00000000)
    for (uint32_t i = start_offset; i + 8 <= data.size() && i < start_offset + max_size; i += 4) {
        uint32_t insn = rd32(&data[i]);
        if (insn == 0x03E00008) {  // jr $ra
            // Check if next instruction is nop or addiu sp restore
            if (i + 4 < data.size()) {
                uint32_t next = rd32(&data[i + 4]);
                if (next == 0x00000000 || (next & 0xFFFF0000) == 0x23BD0000) {
                    // jr $ra + nop or jr $ra + addiu sp,sp,X
                    return i + 8;  // Include both instructions
                }
            }
        }
    }
    return start_offset + max_size;  // Fallback: return max_size
}

FunctionExtractor::ExtractedFunc FunctionExtractor::extract_by_ram(uint32_t ram_addr, uint32_t max_size) {
    ExtractedFunc func;
    func.ram_addr = ram_addr;
    func.file_offset = ram_addr - load_addr + 0x800;
    func.name = "func_" + std::to_string(ram_addr);

    if (func.file_offset >= data.size()) {
        func.size = 0;
        return func;
    }

    func.size = find_func_end(func.file_offset, max_size) - func.file_offset;
    func.code.assign(data.data() + func.file_offset, data.data() + func.file_offset + func.size);

    return func;
}

FunctionExtractor::ExtractedFunc FunctionExtractor::extract_by_offset(uint32_t file_offset, uint32_t size) {
    ExtractedFunc func;
    func.file_offset = file_offset;
    func.ram_addr = load_addr + file_offset - 0x800;
    func.size = size;
    func.name = "func_off_" + std::to_string(file_offset);

    if (file_offset + size > data.size()) {
        func.size = std::min(size, (uint32_t)(data.size() - file_offset));
    }

    func.code.assign(data.data() + file_offset, data.data() + file_offset + func.size);
    return func;
}

std::vector<FunctionExtractor::ExtractedFunc> FunctionExtractor::extract_range(uint32_t start_ram, uint32_t end_ram) {
    std::vector<ExtractedFunc> funcs;
    uint32_t current = start_ram;

    while (current < end_ram) {
        ExtractedFunc func = extract_by_ram(current, end_ram - current);
        if (func.size == 0) break;
        funcs.push_back(func);
        current = func.ram_addr + func.size;
    }

    return funcs;
}

// ============================================================
// PayloadRemapper
// ============================================================

std::vector<PayloadRemapper::RemapEntry> PayloadRemapper::compute_layout(
    const RemapConfig& cfg,
    const std::vector<FolderMapping>& folder_map)
{
    std::vector<RemapEntry> entries;

    uint32_t exe_sectors = (cfg.exe_size + 2047) / 2048;
    uint32_t hbd_start = cfg.hbd_lba;
    uint32_t dq4_offset = cfg.dq4_hbd_source_lba;

    // Map each DQ4 HBD sector to its position on the hybrid disc
    uint32_t hbd_sectors = (cfg.hbd_size + 2047) / 2048;
    for (uint32_t i = 0; i < hbd_sectors; i++) {
        RemapEntry e;
        e.dq4_sector = dq4_offset + i;
        e.new_disc_sector = hbd_start + i;
        e.dw7_sector = 0;  // No DW7 equivalent for DQ4 HBD data
        e.size = 2048;
        entries.push_back(e);
    }

    return entries;
}

PayloadRemapper::PointerTables PayloadRemapper::build_pointer_tables(
    const std::vector<RemapEntry>& entries,
    const std::vector<FolderMapping>& folder_map,
    int32_t lba_delta)
{
    PointerTables tables;
    tables.abs_matched = 0;
    tables.abs_delta = 0;
    tables.rel_matched = 0;

    // ABS table: 6000 entries × 8 bytes (LBA + size pairs)
    tables.abs_table.resize(6000 * 8, 0);
    tables.rel_table.resize(6000 * 8, 0);

    // Populate from folder mappings
    for (uint32_t i = 0; i < folder_map.size() && i < 6000; i++) {
        uint32_t abs_off = i * 8;
        uint32_t old_lba = folder_map[i].dq4_sector;
        uint32_t new_lba = (uint32_t)((int32_t)old_lba + lba_delta);

        wr32(&tables.abs_table[abs_off], new_lba);
        wr32(&tables.abs_table[abs_off + 4], 2048);  // Standard sector size

        if (old_lba != 0) {
            tables.abs_matched++;
        } else {
            tables.abs_delta++;
        }
    }

    return tables;
}

bool PayloadRemapper::validate_layout(
    const RemapConfig& cfg,
    const std::vector<RemapEntry>& entries,
    std::string& error_msg)
{
    // Check HBD doesn't overlap EXE
    uint32_t exe_sectors = (cfg.exe_size + 2047) / 2048;
    uint32_t exe_end = cfg.exe_lba + exe_sectors;

    if (cfg.hbd_lba < exe_end) {
        char buf[256];
        snprintf(buf, sizeof(buf), "HBD LBA %u overlaps EXE end at sector %u",
                 cfg.hbd_lba, exe_end);
        error_msg = buf;
        return false;
    }

    // Check HBD fits on disc
    if (!entries.empty()) {
        uint32_t last_sector = entries.back().new_disc_sector;
        uint32_t disc_sectors = 330000;  // Standard PSX disc
        if (last_sector >= disc_sectors) {
            char buf[256];
            snprintf(buf, sizeof(buf), "HBD extends to sector %u, disc max is %u",
                     last_sector, disc_sectors);
            error_msg = buf;
            return false;
        }
    }

    // Check FMV preservation if requested
    if (cfg.preserve_dw7_fmv && cfg.dw7_fmv_lba > 0) {
        // Ensure FMV sectors aren't overwritten by HBD
        if (!entries.empty()) {
            uint32_t hbd_end = entries.back().new_disc_sector;
            if (hbd_end >= cfg.dw7_fmv_lba) {
                char buf[256];
                snprintf(buf, sizeof(buf), "HBD end sector %u overlaps FMV at %u",
                         hbd_end, cfg.dw7_fmv_lba);
                error_msg = buf;
                return false;
            }
        }
    }

    return true;
}

// ============================================================
// DriverCodegen
// ============================================================

std::vector<uint8_t> DriverCodegen::gen_disc_check_bypass() {
    // li $v0, 1; jr $ra; nop
    // 3 instructions = 12 bytes
    uint32_t code[] = {
        0x24020001,  // addiu $v0, $zero, 1
        0x03E00008,  // jr $ra
        0x00000000,  // nop
    };
    return std::vector<uint8_t>((uint8_t*)code, (uint8_t*)code + sizeof(code));
}

std::vector<uint8_t> DriverCodegen::gen_cdrom_lie_layer(uint32_t install_ram) {
    // CD-ROM lie layer: intercepts Getstat/GetLocP/GetLocL calls
    // and returns fabricated disc identity (always disc 1, SLUS-01206)
    //
    // This is a more sophisticated approach than the simple disc_check bypass.
    // It intercepts the CD-ROM dispatch at 0x80098898 and:
    // - For Getstat (cmd 0x0A): returns status = spinning, disc present
    // - For GetLocP (cmd 0x0E): returns fabricated position
    // - For GetLocL (cmd 0x0D): returns fabricated location
    // - For everything else: passes through to original handler

    MipsEmitter em;

    // Prologue: save registers
    em.prologue(32);
    em.emit(MipsInstr::sw(S0, 8, SP));
    em.emit(MipsInstr::sw(S1, 12, SP));
    em.emit(MipsInstr::sw(S2, 16, SP));
    em.emit(MipsInstr::sw(T0, 20, SP));

    // Load CD-ROM command register to check what command was issued
    // CD-ROM reg base = 0x1F801800
    em.emit(MipsInstr::li32(T0, 0x1F801800));
    em.emit(MipsInstr::lbu(T1, 0x03, T0));  // Read command register

    // Check for Getstat (0x0A)
    em.emit(MipsInstr::addiu(T2, R0, 0x0A));
    em.emit_branch(MipsInstr::BEQ, T1, T2, "getstat");
    em.emit(MipsInstr::nop());

    // Check for GetLocP (0x0E)
    em.emit(MipsInstr::addiu(T2, R0, 0x0E));
    em.emit_branch(MipsInstr::BEQ, T1, T2, "getlocp");
    em.emit(MipsInstr::nop());

    // Check for GetLocL (0x0D)
    em.emit(MipsInstr::addiu(T2, R0, 0x0D));
    em.emit_branch(MipsInstr::BEQ, T1, T2, "getlocl");
    em.emit(MipsInstr::nop());

    // Not a lie-target command — pass through to original CD-ROM dispatch
    em.emit(MipsInstr::lw(S0, 8, SP));
    em.emit(MipsInstr::lw(S1, 12, SP));
    em.emit(MipsInstr::lw(S2, 16, SP));
    em.emit(MipsInstr::lw(T0, 20, SP));
    em.epilogue(32);

    // Jump to original CD-ROM dispatch (0x80098898)
    em.emit(MipsInstr::j(KnownAddresses::DW7::CDROM_DISPATCH));
    em.emit(MipsInstr::nop());

    // getstat: return spinning + disc present
    em.label("getstat");
    // Status byte: bit 0 = error, bit 1 = spindle motor on, bit 4 = data, bit 5 = audio
    // Return 0x12 = spindle on + data track (disc present, spinning)
    em.emit(MipsInstr::li32(V0, 0x12));
    em.emit(MipsInstr::lw(S0, 8, SP));
    em.emit(MipsInstr::lw(S1, 12, SP));
    em.emit(MipsInstr::lw(S2, 16, SP));
    em.emit(MipsInstr::lw(T0, 20, SP));
    em.epilogue(32);

    // getlocp: return fabricated position (track 1, index 1, sector 0)
    em.label("getlocp");
    // 8 bytes: track, index, track MSF, sector MSF
    // Return: track=1, index=1, 00:02:00, 00:00:01
    em.emit(MipsInstr::li32(V0, 0x01010100));  // Simplified
    em.emit(MipsInstr::lw(S0, 8, SP));
    em.emit(MipsInstr::lw(S1, 12, SP));
    em.emit(MipsInstr::lw(S2, 16, SP));
    em.emit(MipsInstr::lw(T0, 20, SP));
    em.epilogue(32);

    // getlocl: return fabricated location
    em.label("getlocl");
    em.emit(MipsInstr::li32(V0, 0x00010100));  // Simplified
    em.emit(MipsInstr::lw(S0, 8, SP));
    em.emit(MipsInstr::lw(S1, 12, SP));
    em.emit(MipsInstr::lw(S2, 16, SP));
    em.emit(MipsInstr::lw(T0, 20, SP));
    em.epilogue(32);

    em.finalize(install_ram);
    return std::vector<uint8_t>(em.data(), em.data() + em.size());
}

std::vector<uint8_t> DriverCodegen::gen_bss_clear(uint32_t bss_start, uint32_t bss_end) {
    // BSS clear routine: zero memory from bss_start to bss_end in 4-byte steps
    //
    // lui $t0, hi(bss_start)
    // addiu $t0, $t0, lo(bss_start)
    // lui $t1, hi(bss_end)
    // addiu $t1, $t1, lo(bss_end)
    // loop:
    //   sw $zero, 0($t0)
    //   addiu $t0, $t0, 4
    //   sltu $t2, $t0, $t1
    //   bne $t2, $zero, loop
    //   nop
    //   jr $ra
    //   nop

    MipsEmitter em;

    em.emit(MipsInstr::la(T0, bss_start));
    em.emit(MipsInstr::la(T1, bss_end));

    em.label("loop");
    em.emit(MipsInstr::sw(R0, 0, T0));
    em.emit(MipsInstr::addiu(T0, T0, 4));
    em.emit(MipsInstr::sltu(T2, T0, T1));
    em.emit_branch(MipsInstr::BNE, T2, R0, "loop");
    em.emit(MipsInstr::nop());

    em.emit(MipsInstr::jr(RA));
    em.emit(MipsInstr::nop());

    em.finalize(0);  // Position-independent
    return std::vector<uint8_t>(em.data(), em.data() + em.size());
}

std::vector<uint8_t> DriverCodegen::gen_hbd_mount(uint32_t hbd_lba, uint32_t hbd_ram,
                                                    uint32_t hbd_sectors) {
    // HBD mount routine: calls CD-ROM BIOS to read HBD sectors into RAM
    //
    // This is a simplified version — the actual DW7 HBD mount at 0x8002EC2C
    // is much more complex (folder parsing, file table construction, etc.)
    // For the "driver" approach, we extract the DW7's HBD mount function
    // and call it with our parameters.

    MipsEmitter em;

    // Set up arguments for CD-ROM read
    // a0 = LBA, a1 = dest RAM, a2 = sector count
    em.emit(MipsInstr::li32(A0, hbd_lba));
    em.emit(MipsInstr::li32(A1, hbd_ram));
    em.emit(MipsInstr::li32(A2, hbd_sectors));

    // Call DW7's existing CD-ROM read function
    // The DW7 CD-ROM wrapper is at 0x80097814
    em.emit_jal(KnownAddresses::DW7::CDROM_WRAPPER);
    em.emit(MipsInstr::nop());

    // Return
    em.emit(MipsInstr::jr(RA));
    em.emit(MipsInstr::nop());

    em.finalize(0);
    return std::vector<uint8_t>(em.data(), em.data() + em.size());
}

std::vector<uint8_t> DriverCodegen::gen_block_type_trampoline(
    uint32_t install_ram,
    uint32_t original_dispatch_ram,
    const std::vector<BlockTypeHandler>& handlers)
{
    // Block type dispatch trampoline
    //
    // This is the "Fork Delta" approach from the strategic document:
    // Instead of re-encoding DQ4 blocks to DW7 format, we patch the
    // DW7 block header reader to dispatch DQ4 types to native handlers.
    //
    // The existing implementation in psx_binary_ops.cpp patches 0x800562E4
    // with a JAL to 0x80101000. This codegen generates the trampoline body.
    //
    // The trampoline checks $s3 (lower 16 bits of sub-block header word):
    // - If it matches a DQ4 type (32, 39, 40, 42, 46): swap type/count
    //   (s3 = upper16 = real count, v1 = 0 = tree root)
    // - Otherwise: restore original behavior (sh $v1, 1336($v0))

    MipsEmitter em;

    // Type dispatch: check $s3 for DQ4 types
    for (auto& h : handlers) {
        if (h.mode == BlockTypeHandler::SKIP) continue;

        em.emit(MipsInstr::addiu(T2, R0, h.type_id));
        em.emit_branch(MipsInstr::BEQ, S3, T2, "dq4_handler");
        em.emit(MipsInstr::nop());
    }

    // .not_dq4: re-execute original delay slot (sh $v1, 1336($v0))
    em.emit(MipsInstr::sh(V1, 1336, V0));  // 0xA4430538
    em.emit_branch(MipsInstr::BEQ, S3, R0, "skip");
    em.emit(MipsInstr::nop());
    em.emit(MipsInstr::jr(RA));
    em.emit(MipsInstr::nop());

    // .skip: j 0x80056320 (original skip target)
    em.label("skip");
    em.emit(MipsInstr::j(original_dispatch_ram + 0x3C));  // 0x80056320
    em.emit(MipsInstr::nop());

    // .dq4_handler: swap type/count
    em.label("dq4_handler");
    em.emit(MipsInstr::addu(S3, V1, R0));     // s3 = upper16 = real count
    em.emit(MipsInstr::or_(V1, R0, R0));      // v1 = 0 (tree root)
    em.emit(MipsInstr::sh(R0, 1336, V0));     // store 0 to 0x800E0538
    em.emit(MipsInstr::jr(RA));
    em.emit(MipsInstr::nop());

    em.finalize(install_ram);
    return std::vector<uint8_t>(em.data(), em.data() + em.size());
}

std::vector<uint8_t> DriverCodegen::gen_fmv_skip() {
    // FMV skip stub: replaces FMV playback function with immediate return
    // Targets: 0x8008AEF4 (XA/STR playback core), 0x8008CAD0 (MDEC init)
    // li $v0, 0; jr $ra; nop
    uint32_t code[] = {
        0x24020000,  // addiu $v0, $zero, 0
        0x03E00008,  // jr $ra
        0x00000000,  // nop
    };
    return std::vector<uint8_t>((uint8_t*)code, (uint8_t*)code + sizeof(code));
}

std::vector<uint8_t> DriverCodegen::gen_thread_preserve(uint32_t thread_entry_ram,
                                                         uint32_t safe_ram,
                                                         uint32_t thread_entry_size)
{
    // Thread entry preservation stub
    //
    // The BSS clear at 0x800BC668-0x800F4980 would zero the thread entry
    // at 0x800D9E80. This stub copies it to safe RAM (0x80101000+)
    // before BSS clear, then restores it after.
    //
    // This is already implemented in psx_binary_ops.cpp as part of the
    // copy routine. This codegen provides a standalone version.

    MipsEmitter em;

    // Copy thread entry to safe RAM
    em.emit(MipsInstr::la(T0, thread_entry_ram));  // Source
    em.emit(MipsInstr::la(T1, safe_ram));           // Destination
    em.emit(MipsInstr::li32(T2, thread_entry_size)); // Count

    em.label("copy_loop");
    em.emit(MipsInstr::lw(T3, 0, T0));
    em.emit(MipsInstr::sw(T3, 0, T1));
    em.emit(MipsInstr::addiu(T0, T0, 4));
    em.emit(MipsInstr::addiu(T1, T1, 4));
    em.emit(MipsInstr::addiu(T2, T2, (uint16_t)(-4)));
    em.emit_branch(MipsInstr::BNE, T2, R0, "copy_loop");
    em.emit(MipsInstr::nop());

    em.emit(MipsInstr::jr(RA));
    em.emit(MipsInstr::nop());

    em.finalize(0);
    return std::vector<uint8_t>(em.data(), em.data() + em.size());
}

std::vector<uint8_t> DriverCodegen::gen_boot_sequence(const DriverSpec& spec,
                                                       uint32_t& out_entry_point) {
    // Generate a complete custom boot sequence
    //
    // This is the "play god" function — it generates the entire EXE body
    // from scratch, using extracted functions and custom MIPS code.
    //
    // Boot flow:
    // 1. BSS clear (custom, preserving hybrid tree region)
    // 2. Copy hybrid tree to safe RAM
    // 3. Copy thread entry to safe RAM
    // 4. Initialize CD-ROM (call DW7's cd_init, NOT the force-success stub)
    // 5. Mount HBD (call DW7's HBD mount with our LBA)
    // 6. Restore thread entry from safe RAM
    // 7. Disc check bypass (force disc number = 1)
    // 8. Jump to DW7's main event loop

    MipsEmitter em;
    uint32_t base_ram = spec.boot.load_address;

    // Phase 1: BSS clear (custom, skips hybrid tree region)
    // BSS clear from spec.boot.bss_start to spec.boot.bss_end
    // but skip 0x800BC668-0x800BC700 (hybrid tree location)

    // BSS clear part 1: bss_start to 0x800BC668 (before tree)
    em.emit(MipsInstr::la(T0, spec.boot.bss_start));
    em.emit(MipsInstr::la(T1, 0x800BC668));
    em.label("bss1");
    em.emit(MipsInstr::sw(R0, 0, T0));
    em.emit(MipsInstr::addiu(T0, T0, 4));
    em.emit(MipsInstr::sltu(T2, T0, T1));
    em.emit_branch(MipsInstr::BNE, T2, R0, "bss1");
    em.emit(MipsInstr::nop());

    // BSS clear part 2: 0x800BC700 to bss_end (after tree)
    em.emit(MipsInstr::la(T0, 0x800BC700));
    em.emit(MipsInstr::la(T1, spec.boot.bss_end));
    em.label("bss2");
    em.emit(MipsInstr::sw(R0, 0, T0));
    em.emit(MipsInstr::addiu(T0, T0, 4));
    em.emit(MipsInstr::sltu(T2, T0, T1));
    em.emit_branch(MipsInstr::BNE, T2, R0, "bss2");
    em.emit(MipsInstr::nop());

    // Phase 2: Force disc number = 1 (disc check bypass)
    // Store 1 at 0x800E3D90 (disc number variable)
    em.emit(MipsInstr::li32(T0, KnownAddresses::DW7::DISC_NUM_VAR));
    em.emit(MipsInstr::addiu(T1, R0, 1));
    em.emit(MipsInstr::sw(T1, 0, T0));

    // Phase 3: Call DW7's original BSS clear entry / PC0
    // This jumps to the DW7 entry point which handles CD-ROM init,
    // HBD mount, GPU init, and event loop setup.
    // The DW7 PC0 is at 0x8008E284.
    em.emit(MipsInstr::j(KnownAddresses::DW7::PC0));
    em.emit(MipsInstr::nop());

    em.finalize(base_ram);
    out_entry_point = base_ram;

    return std::vector<uint8_t>(em.data(), em.data() + em.size());
}

std::vector<uint8_t> DriverCodegen::gen_call_extracted(uint32_t func_ram,
                                                        uint32_t arg1,
                                                        uint32_t arg2,
                                                        uint32_t arg3,
                                                        uint32_t arg4)
{
    MipsEmitter em;

    // Set up arguments
    if (arg1) {
        auto li = MipsInstr::li32(A0, arg1);
        em.emit(li);
    }
    if (arg2) {
        auto li = MipsInstr::li32(A1, arg2);
        em.emit(li);
    }
    if (arg3) {
        auto li = MipsInstr::li32(A2, arg3);
        em.emit(li);
    }
    if (arg4) {
        auto li = MipsInstr::li32(A3, arg4);
        em.emit(li);
    }

    // Call the function
    em.emit_jal(func_ram);
    em.emit(MipsInstr::nop());

    // Return
    em.emit(MipsInstr::jr(RA));
    em.emit(MipsInstr::nop());

    em.finalize(0);
    return std::vector<uint8_t>(em.data(), em.data() + em.size());
}

// ============================================================
// ExeBuilder
// ============================================================

void ExeBuilder::add_component(ExeComponent::Type type, uint32_t target_ram,
                                const std::vector<uint8_t>& data,
                                const std::string& name) {
    ExeComponent comp;
    comp.type = type;
    comp.target_ram = target_ram;
    comp.data = data;
    comp.name = name;
    components.push_back(comp);
}

void ExeBuilder::set_dw7_base(const uint8_t* exe, uint32_t size) {
    dw7_base.assign(exe, exe + size);
    // Parse header for load address
    if (size >= 0x20 && std::memcmp(exe, "PS-X EXE", 8) == 0) {
        std::memcpy(&dw7_load_addr, exe + 0x18, 4);
    }
}

void ExeBuilder::set_dq4_source(const uint8_t* exe, uint32_t size) {
    dq4_source.assign(exe, exe + size);
    if (size >= 0x20 && std::memcmp(exe, "PS-X EXE", 8) == 0) {
        std::memcpy(&dq4_load_addr, exe + 0x18, 4);
    }
}

uint32_t ExeBuilder::total_component_size() const {
    uint32_t total = 0;
    for (auto& c : components) {
        total += (uint32_t)c.data.size();
    }
    return total;
}

std::vector<uint8_t> ExeBuilder::assemble(uint32_t load_addr) {
    // Sort components by target_ram
    std::vector<ExeComponent> sorted = components;
    std::sort(sorted.begin(), sorted.end(),
              [](const ExeComponent& a, const ExeComponent& b) {
                  return a.target_ram < b.target_ram;
              });

    // Calculate total size
    uint32_t max_ram = load_addr;
    for (auto& c : sorted) {
        uint32_t end = c.target_ram + (uint32_t)c.data.size();
        if (end > max_ram) max_ram = end;
    }

    uint32_t data_size = max_ram - load_addr;
    std::vector<uint8_t> result(data_size, 0);

    // Place each component
    for (auto& c : sorted) {
        uint32_t offset = c.target_ram - load_addr;
        if (offset + c.data.size() > result.size()) {
            result.resize(offset + c.data.size(), 0);
        }
        std::memcpy(result.data() + offset, c.data.data(), c.data.size());
    }

    return result;
}

std::vector<uint8_t> ExeBuilder::build(uint32_t load_addr, uint32_t entry_pc,
                                        uint32_t gp_val, uint32_t sp_val) {
    // Assemble all components
    std::vector<uint8_t> body = assemble(load_addr);

    // Build PS-X EXE header
    ExeBuilder::PsxExeHeader hdr;
    std::memset(&hdr, 0, sizeof(hdr));

    std::memcpy(hdr.magic, "PS-X EXE", 8);
    hdr.pc = entry_pc;
    hdr.gp = gp_val;
    hdr.addr = load_addr;
    hdr.t_size = (uint32_t)body.size();
    hdr.m_size = 0;  // No BSS fill (we handle BSS in custom boot)
    hdr.m_addr = 0;
    hdr.s_size = 0;
    hdr.s_addr = sp_val;  // Stack pointer

    // Combine header + body
    std::vector<uint8_t> exe(sizeof(hdr) + body.size());
    std::memcpy(exe.data(), &hdr, sizeof(hdr));
    std::memcpy(exe.data() + sizeof(hdr), body.data(), body.size());

    return exe;
}

bool ExeBuilder::validate(const std::vector<uint8_t>& exe, std::string& error) const {
    if (exe.size() < 0x800) {
        error = "EXE too small (< 2048 bytes)";
        return false;
    }

    if (std::memcmp(exe.data(), "PS-X EXE", 8) != 0) {
        error = "Invalid PS-X EXE magic";
        return false;
    }

    uint32_t pc, load_addr, text_size;
    std::memcpy(&pc, exe.data() + 0x10, 4);
    std::memcpy(&load_addr, exe.data() + 0x18, 4);
    std::memcpy(&text_size, exe.data() + 0x1C, 4);

    if (load_addr < 0x80010000 || load_addr > 0x80100000) {
        error = "Load address out of valid RAM range";
        return false;
    }

    if (pc < load_addr || pc >= load_addr + text_size) {
        error = "PC0 outside text segment";
        return false;
    }

    if (text_size > 0x800000) {  // 8MB max
        error = "Text size unreasonably large";
        return false;
    }

    if (0x800 + text_size > exe.size()) {
        error = "EXE file truncated (text_size > file data)";
        return false;
    }

    return true;
}

// ============================================================
// HbdProcessor
// ============================================================

bool HbdProcessor::load(const uint8_t* hbd_data, uint32_t hbd_size,
                        const uint8_t* hybrid_tree, uint32_t tree_size) {
    this->hbd_data.assign(hbd_data, hbd_data + hbd_size);
    this->hybrid_tree = hybrid_tree;
    this->tree_sz = tree_size;
    this->processed = false;
    return !this->hbd_data.empty();
}

HbdProcessor::ProcessResult HbdProcessor::process(uint32_t source_lba, uint32_t target_lba) {
    ProcessResult result = {};

    // Use the existing HbdReencoder from psx_binary_ops
    HbdReencoder reencoder;
    if (!reencoder.load(hbd_data.data(), (uint32_t)hbd_data.size(),
                        hybrid_tree, tree_sz)) {
        printf("  HbdProcessor: Failed to load HbdReencoder\n");
        result.success = false;
        return result;
    }

    printf("  HbdProcessor: Running full pipeline (A+B+C)...\n");
    printf("    Source LBA: %u, Target LBA: %u, Delta: %d\n",
           source_lba, target_lba, (int32_t)target_lba - (int32_t)source_lba);
    printf("    HBD size: %zu bytes, Hybrid tree: %u bytes\n",
           hbd_data.size(), tree_sz);

    auto r = reencoder.process_hbd(source_lba, target_lba);

    result.folders_parsed = r.folders_parsed;
    result.files_parsed = r.files_parsed;
    result.blocks_processed = r.blocks_processed;
    result.blocks_converted = r.blocks_converted;
    result.blocks_reencoded = r.blocks_reencoded;
    result.blocks_reencode_failed = r.blocks_reencode_failed;
    result.subblock_swaps = r.subblock_swaps;
    result.lba_patches = r.lba_patches;
    result.errors = r.errors;
    result.success = r.success == 1;

    // Replace our data with processed version
    hbd_data.assign(reencoder.raw(), reencoder.raw() + reencoder.size());
    processed = true;

    printf("  HbdProcessor: Complete — folders=%u files=%u blocks=%u converted=%u\n",
           result.folders_parsed, result.files_parsed,
           result.blocks_processed, result.blocks_converted);
    printf("    Re-encoded=%u failed=%u swaps=%u errors=%u\n",
           result.blocks_reencoded, result.blocks_reencode_failed,
           result.subblock_swaps, result.errors);

    return result;
}

HbdProcessor::ProcessResult HbdProcessor::process_phase1(uint32_t source_lba, uint32_t target_lba) {
    // Phase 1: Only sub-block field swap (B) + LBA relocation (C)
    // No Huffman re-encoding — safer, no size changes
    //
    // We still use HbdReencoder but with no hybrid tree, which
    // causes it to skip the re-encoding step (transformation A)
    // and only do field swaps + LBA relocation.

    ProcessResult result = {};

    // Load without hybrid tree to skip re-encoding
    HbdReencoder reencoder;
    if (!reencoder.load(hbd_data.data(), (uint32_t)hbd_data.size(),
                        nullptr, 0)) {
        printf("  HbdProcessor: Failed to load HbdReencoder (phase1)\n");
        result.success = false;
        return result;
    }

    printf("  HbdProcessor: Running Phase 1 (B+C only, no re-encoding)...\n");
    printf("    Source LBA: %u, Target LBA: %u\n", source_lba, target_lba);

    auto r = reencoder.process_hbd(source_lba, target_lba);

    result.folders_parsed = r.folders_parsed;
    result.files_parsed = r.files_parsed;
    result.blocks_processed = r.blocks_processed;
    result.blocks_converted = r.blocks_converted;
    result.blocks_reencoded = r.blocks_reencoded;
    result.blocks_reencode_failed = r.blocks_reencode_failed;
    result.subblock_swaps = r.subblock_swaps;
    result.lba_patches = r.lba_patches;
    result.errors = r.errors;
    result.success = r.success == 1;

    hbd_data.assign(reencoder.raw(), reencoder.raw() + reencoder.size());
    processed = true;

    printf("  HbdProcessor Phase 1: Complete — swaps=%u errors=%u\n",
           result.subblock_swaps, result.errors);

    return result;
}

bool HbdProcessor::validate(uint32_t source_lba) {
    if (!processed) {
        printf("  HbdProcessor: Cannot validate — HBD not processed yet\n");
        return false;
    }

    HbdReencoder reencoder;
    reencoder.load(hbd_data.data(), (uint32_t)hbd_data.size(), nullptr, 0);
    bool ok = reencoder.validate_processed(source_lba);

    if (ok) {
        printf("  HbdProcessor: Validation PASSED — no DQ4 types remain\n");
    } else {
        printf("  HbdProcessor: Validation FAILED — DQ4 types still present\n");
    }

    return ok;
}

const uint8_t* HbdProcessor::data() const {
    return hbd_data.data();
}

uint32_t HbdProcessor::size() const {
    return (uint32_t)hbd_data.size();
}

// ============================================================
// DiscAssembler
// ============================================================

bool DiscAssembler::extend_disc(const char* path, uint64_t needed_size) {
    std::ifstream chk(path, std::ios::binary | std::ios::ate);
    if (!chk.is_open()) return false;
    uint64_t cur = chk.tellg();
    chk.close();
    if (needed_size <= cur) return true;

    // Use the existing extend_disc_mode2 from psx_binary_ops
    int result = extend_disc_mode2(path, needed_size);
    return result == 0;
}

bool DiscAssembler::write_cue(const char* cue_path, const char* bin_name) {
    std::ofstream f(cue_path);
    if (!f) return false;

    f << "FILE \"" << bin_name << "\" BINARY\n";
    f << "  TRACK 1 MODE2/2352\n";
    f << "    INDEX 1 00:00:00\n";
    return f.good();
}

bool DiscAssembler::assemble(
    const char* base_disc_path,
    const char* output_bin_path,
    const char* output_cue_path,
    const uint8_t* exe_data, uint32_t exe_size,
    const uint8_t* hbd_data, uint32_t hbd_size,
    const DiscConfig& cfg,
    const char* edcre_path)
{
    printf("  DiscAssembler: Assembling disc...\n");

    // 1. Copy base disc to output
    printf("    Copying base disc: %s -> %s\n", base_disc_path, output_bin_path);
    {
        std::ifstream src(base_disc_path, std::ios::binary);
        if (!src.is_open()) {
            printf("    ERROR: Cannot open base disc: %s\n", base_disc_path);
            return false;
        }
        std::ofstream dst(output_bin_path, std::ios::binary);
        if (!dst.is_open()) {
            printf("    ERROR: Cannot create output: %s\n", output_bin_path);
            return false;
        }
        dst << src.rdbuf();
    }

    // 2. Extend disc if needed to fit HBD
    uint32_t hbd_sectors = (hbd_size + cfg.user_size - 1) / cfg.user_size;
    uint64_t needed_size = (uint64_t)(cfg.hbd_lba + hbd_sectors) * cfg.sector_size;
    {
        std::ifstream chk(output_bin_path, std::ios::binary | std::ios::ate);
        uint64_t cur = chk.tellg();
        chk.close();
        if (needed_size > cur) {
            printf("    Extending disc: %llu -> %llu bytes (%u HBD sectors)\n",
                   (unsigned long long)cur, (unsigned long long)needed_size, hbd_sectors);
            if (!extend_disc(output_bin_path, needed_size)) {
                printf("    ERROR: Failed to extend disc\n");
                return false;
            }
        }
    }

    // 3. Open ISO image for writing
    IsoImage iso;
    if (!iso.open(output_bin_path)) {
        printf("    ERROR: Cannot reopen output disc\n");
        return false;
    }

    // 4. Write EXE at exe_lba
    printf("    Writing EXE at sector %u (%u bytes)...\n", cfg.exe_lba, exe_size);
    uint32_t exe_sectors = (exe_size + cfg.user_size - 1) / cfg.user_size;
    for (uint32_t i = 0; i < exe_sectors; i++) {
        uint8_t sector_buf[2048];
        std::memset(sector_buf, 0, sizeof(sector_buf));
        uint32_t chunk = std::min((uint32_t)2048, exe_size - i * 2048);
        std::memcpy(sector_buf, exe_data + i * 2048, chunk);
        if (iso.write_sector(cfg.exe_lba + i, sector_buf) != 0) {
            printf("    ERROR: Failed writing EXE sector %u\n", i);
            iso.close();
            return false;
        }
    }

    // 5. Write HBD at hbd_lba
    printf("    Writing HBD at sector %u (%u bytes, %u sectors)...\n",
           cfg.hbd_lba, hbd_size, hbd_sectors);
    for (uint32_t i = 0; i < hbd_sectors; i++) {
        uint8_t sector_buf[2048];
        std::memset(sector_buf, 0, sizeof(sector_buf));
        uint32_t chunk = std::min((uint32_t)2048, hbd_size - i * 2048);
        std::memcpy(sector_buf, hbd_data + i * 2048, chunk);
        if (iso.write_sector(cfg.hbd_lba + i, sector_buf) != 0) {
            printf("    ERROR: Failed writing HBD sector %u\n", i);
            iso.close();
            return false;
        }
    }

    printf("    HBD spans sectors %u-%u\n", cfg.hbd_lba, cfg.hbd_lba + hbd_sectors - 1);

    // 6. Update ISO directory and PVD
    // The ISO 9660 Primary Volume Descriptor is at sector 16
    // Directory entries point to the EXE and HBD files
    printf("    Updating ISO directory + PVD...\n");

    // Update PVD volume space size
    {
        uint8_t pvd[2048];
        if (iso.read_sector(16, pvd) == 0) {
            uint32_t total_sectors = (uint32_t)(needed_size / cfg.sector_size);
            // Volume Space Size (LSB at offset 80, 8 bytes both-endian)
            std::memcpy(pvd + 80, &total_sectors, 4);
            std::memcpy(pvd + 84, &total_sectors, 4);
            // Update Volume Set Size (offset 120) and Volume Sequence Number (offset 124)
            uint16_t one = 1;
            std::memcpy(pvd + 120, &one, 2);
            std::memcpy(pvd + 122, &one, 2);
            // Update LBA of root directory record (offset 158, 34 bytes)
            // Root dir is typically at sector 18 (0x12) for PSX discs
            // Keep existing root directory — just update volume space
            iso.write_sector(16, pvd);
        }
    }

    // Update path table + directory entries for the EXE file size
    // The EXE file (SLUS_012.06) directory entry is in the root directory
    // at sector 18. We need to update the file size field.
    {
        uint8_t root_dir[2048];
        if (iso.read_sector(18, root_dir) == 0) {
            // Parse directory records to find the EXE entry
            uint32_t offset = 0;
            while (offset < 2048) {
                uint8_t rec_len = root_dir[offset];
                if (rec_len == 0) break;

                uint8_t flags = root_dir[offset + 25];
                // File name starts at offset + 33, length at offset + 32
                uint8_t name_len = root_dir[offset + 32];
                char name[32];
                std::memcpy(name, root_dir + offset + 33, std::min((int)name_len, 31));
                name[std::min((int)name_len, 31)] = 0;

                // Check if this is the EXE file (not a directory)
                if (!(flags & 0x02) && name_len > 0) {
                    // Update file size (offset + 10, 8 bytes both-endian)
                    uint32_t file_size = exe_size;
                    std::memcpy(root_dir + offset + 10, &file_size, 4);
                    std::memcpy(root_dir + offset + 14, &file_size, 4);
                    printf("      Updated directory entry: %s -> %u bytes\n", name, file_size);
                }

                offset += rec_len;
            }
            iso.write_sector(18, root_dir);
        }
    }

    iso.close();

    // 7. Write CUE sheet
    printf("    Writing CUE sheet: %s\n", output_cue_path);
    std::string bin_name = output_bin_path;
    size_t slash = bin_name.find_last_of("\\/");
    if (slash != std::string::npos) bin_name = bin_name.substr(slash + 1);
    write_cue(output_cue_path, bin_name.c_str());

    // 8. Run EDC/ECC regeneration
    if (edcre_path && *edcre_path) {
        printf("    Running EDC/ECC regeneration: %s\n", edcre_path);
        // Use system() to run edcre
        std::string cmd = std::string("\"") + edcre_path + "\" \"" + output_bin_path + "\"";
        int ec = std::system(cmd.c_str());
        printf("    EDC/ECC: %s\n", ec == 0 ? "SUCCESS" : "FAILED");
        if (ec != 0) {
            printf("    WARNING: EDC/ECC failed — disc may not validate in strict emulators\n");
        }
    }

    printf("  DiscAssembler: Complete\n");
    return true;
}

// ============================================================
// FrankensteinDriverBuilder
// ============================================================

bool FrankensteinDriverBuilder::validate_spec(const DriverSpec& spec, std::string& error) {
    if (!spec.dw7_exe || spec.dw7_exe_size == 0) {
        error = "No DW7 EXE provided";
        return false;
    }

    if (spec.boot.load_address == 0) {
        error = "No load address specified";
        return false;
    }

    if (spec.hbd.hbd_lba == 0) {
        error = "No HBD LBA specified";
        return false;
    }

    if (spec.hbd.tree_mode == HbdMountSpec::HYBRID_GLOBAL &&
        (!spec.hbd.hybrid_tree || spec.hbd.hybrid_tree_size == 0)) {
        error = "HYBRID_GLOBAL mode requires hybrid tree data";
        return false;
    }

    // Check for RAM conflicts
    if (spec.hbd.hybrid_tree_target_ram >= spec.boot.bss_start &&
        spec.hbd.hybrid_tree_target_ram < spec.boot.bss_end) {
        error = "Hybrid tree target RAM overlaps BSS clear range";
        return false;
    }

    return true;
}

DriverSpec FrankensteinDriverBuilder::default_frankenstein_spec() {
    DriverSpec spec;

    // Boot: DW7 bootloader with custom BSS clear
    spec.boot.load_address = KnownAddresses::DW7::LOAD_ADDR;
    spec.boot.entry_point = KnownAddresses::DW7::PC0;
    spec.boot.bss_start = KnownAddresses::DW7::BSS_CLEAR;
    spec.boot.bss_end = KnownAddresses::DW7::BSS_END;
    spec.boot.use_dw7_event_loop = true;
    spec.boot.event_loop_ram = KnownAddresses::DW7::EVENT_LOOP;

    // HBD: DQ4 HBD with per-block trees (no re-encoding)
    spec.hbd.hbd_lba = 355;
    spec.hbd.exe_lba = 24;
    spec.hbd.tree_mode = HbdMountSpec::DQ4_PER_BLOCK;

    // Block handlers: native DQ4 for types 32/46, re-encoded for others
    BlockTypeHandler h32;
    h32.type_id = BlockTypes::DQ4_SCRIPT_32;
    h32.mode = BlockTypeHandler::NATIVE_DQ4;
    h32.handler_name = "DQ4 script handler (native)";
    spec.hbd.block_handlers.push_back(h32);

    BlockTypeHandler h46;
    h46.type_id = BlockTypes::DQ4_MSG_46;
    h46.mode = BlockTypeHandler::NATIVE_DQ4;
    h46.handler_name = "DQ4 message handler (native)";
    spec.hbd.block_handlers.push_back(h46);

    // Disc check: full bypass (custom driver doesn't check discs)
    spec.disc_check.mode = DiscCheckSpec::FULL_BYPASS;

    // FMV: skip (avoid disc-swap trigger)
    spec.fmv_mode = DriverSpec::FMV_SKIP;

    spec.max_exe_size = 0x200000;  // 2MB max

    return spec;
}

DriverSpec FrankensteinDriverBuilder::default_dq4_native_spec() {
    DriverSpec spec;

    // Boot: DQ4 bootloader (natively understands DQ4 HBD)
    spec.boot.load_address = KnownAddresses::DQ4::LOAD_ADDR;
    spec.boot.entry_point = KnownAddresses::DQ4::PC0;
    spec.boot.bss_start = KnownAddresses::DQ4::BSS_CLEAR;
    spec.boot.bss_end = KnownAddresses::DQ4::BSS_END;
    spec.boot.use_dw7_event_loop = false;

    // HBD: DQ4 HBD natively (no re-encoding, no hybrid tree)
    spec.hbd.hbd_lba = KnownAddresses::DQ4::HBD_LBA;
    spec.hbd.exe_lba = 24;
    spec.hbd.tree_mode = HbdMountSpec::DQ4_PER_BLOCK;

    // No block handlers needed — DQ4 EXE handles all types natively
    spec.hbd.block_handlers.clear();

    // Disc check: DQ4 native (patched to accept our disc)
    spec.disc_check.mode = DiscCheckSpec::DQ4_NATIVE;

    // FMV: DQ4 native
    spec.fmv_mode = DriverSpec::FMV_DQ4_NATIVE;

    spec.max_exe_size = 0x200000;

    return spec;
}

DriverSpec FrankensteinDriverBuilder::default_cleanroom_spec() {
    DriverSpec spec;

    // Boot: Custom bootloader from extracted functions
    spec.boot.load_address = KnownAddresses::Safe::BOOT_CODE_RAM;
    spec.boot.entry_point = 0;  // Auto: first instruction
    spec.boot.bss_start = KnownAddresses::DW7::BSS_CLEAR;
    spec.boot.bss_end = KnownAddresses::DW7::BSS_END;
    spec.boot.use_dw7_event_loop = true;

    // HBD: Hybrid global tree (requires re-encoding)
    spec.hbd.hbd_lba = 355;
    spec.hbd.exe_lba = 24;
    spec.hbd.tree_mode = HbdMountSpec::HYBRID_GLOBAL;
    spec.hbd.hybrid_tree_target_ram = KnownAddresses::Safe::HIGH_RAM_START;

    // All block types re-encoded
    for (auto t : {BlockTypes::DQ4_TEXT_23, BlockTypes::DQ4_TEXT_24,
                   BlockTypes::DQ4_TEXT_25, BlockTypes::DQ4_TEXT_27,
                   BlockTypes::DQ4_SCRIPT_32, BlockTypes::DQ4_MSG_46}) {
        BlockTypeHandler h;
        h.type_id = t;
        h.mode = BlockTypeHandler::REENCODED;
        h.handler_name = "Re-encoded to DW7 format";
        spec.hbd.block_handlers.push_back(h);
    }

    // Disc check: full bypass
    spec.disc_check.mode = DiscCheckSpec::FULL_BYPASS;

    // FMV: skip
    spec.fmv_mode = DriverSpec::FMV_SKIP;

    spec.max_exe_size = 0x200000;

    return spec;
}

std::vector<uint8_t> FrankensteinDriverBuilder::build_exe(const DriverSpec& spec,
                                                           BuildResult* result) {
    if (result) {
        std::memset(result, 0, sizeof(BuildResult));
    }

    std::string error;
    if (!validate_spec(spec, error)) {
        if (result) {
            result->success = -1;
            result->validation_errors = error;
        }
        return {};
    }

    ExeBuilder builder;
    builder.set_dw7_base(spec.dw7_exe, spec.dw7_exe_size);
    if (spec.dq4_exe) {
        builder.set_dq4_source(spec.dq4_exe, spec.dq4_exe_size);
    }

    // Component 1: DW7 EXE base (the bootloader we're modifying)
    std::vector<uint8_t> dw7_body(spec.dw7_exe + 0x800, spec.dw7_exe + spec.dw7_exe_size);
    builder.add_component(ExeBuilder::ExeComponent::RAW_CODE, spec.boot.load_address,
                          dw7_body, "DW7 EXE base");

    // Component 2: Disc check bypass
    if (spec.disc_check.mode == DiscCheckSpec::FULL_BYPASS) {
        auto bypass = DriverCodegen::gen_disc_check_bypass();
        // Overwrite disc_check function at 0x80078FF4
        builder.add_component(ExeBuilder::ExeComponent::EMITTED_CODE,
                              KnownAddresses::DW7::DISC_CHECK,
                              bypass, "Disc check bypass (li v0,1; jr ra)");

        // Also neutralize disc change handler at 0x800506CC
        auto neutralize = DriverCodegen::gen_disc_check_bypass();
        builder.add_component(ExeBuilder::ExeComponent::EMITTED_CODE,
                              KnownAddresses::DW7::DISC_CHANGE,
                              neutralize, "Disc change handler neutralized");
    }

    // Component 3: Block type trampoline (if using DQ4_PER_BLOCK mode)
    if (spec.hbd.tree_mode == HbdMountSpec::DQ4_PER_BLOCK && !spec.hbd.block_handlers.empty()) {
        auto tramp = DriverCodegen::gen_block_type_trampoline(
            KnownAddresses::Safe::TRAMPOLINE_BASE,
            KnownAddresses::DW7::BLOCK_READER,
            spec.hbd.block_handlers);

        builder.add_component(ExeBuilder::ExeComponent::EMITTED_CODE,
                              KnownAddresses::Safe::TRAMPOLINE_BASE,
                              tramp, "DQ4 block type trampoline");

        // Patch the JAL at 0x800562E4 to call our trampoline
        // This is done as a raw code component at the DW7 EXE offset
        uint32_t patch_offset = KnownAddresses::DW7::BLOCK_READER - spec.boot.load_address + 0x800;
        // Actually, the divergence point is at 0x800562E4, not 0x80042A04
        // 0x800562E4 is in the tree loader, not the block reader
        // The JAL target is 0x80101000 (Safe::TRAMPOLINE_BASE)
        // JAL 0x80101000 = 0x0C040400
        // We handle this as a patch to the DW7 body, not a separate component
        // (The existing ExePatcher::patch_hbd_type_trampoline does this)
    }

    // Component 4: FMV skip (if requested)
    if (spec.fmv_mode == DriverSpec::FMV_SKIP) {
        auto fmv_skip = DriverCodegen::gen_fmv_skip();
        builder.add_component(ExeBuilder::ExeComponent::EMITTED_CODE,
                              KnownAddresses::DW7::POST_VERIFY,
                              fmv_skip, "FMV skip (return 0)");
    }

    // Component 5: Hybrid tree data (if using HYBRID_GLOBAL mode)
    if (spec.hbd.tree_mode == HbdMountSpec::HYBRID_GLOBAL && spec.hbd.hybrid_tree) {
        std::vector<uint8_t> tree(spec.hbd.hybrid_tree,
                                   spec.hbd.hybrid_tree + spec.hbd.hybrid_tree_size);
        builder.add_component(ExeBuilder::ExeComponent::DATA_PAYLOAD,
                              spec.hbd.hybrid_tree_target_ram,
                              tree, "Hybrid Huffman tree");
    }

    // Build the EXE
    uint32_t entry_pc = spec.boot.entry_point;
    if (entry_pc == 0) {
        entry_pc = spec.boot.load_address;  // First instruction
    }

    auto exe = builder.build(spec.boot.load_address, entry_pc);

    // Validate
    std::string val_error;
    bool valid = builder.validate(exe, val_error);

    if (result) {
        result->exe_size = (uint32_t)exe.size();
        result->exe_entry_pc = entry_pc;
        result->exe_components = (uint32_t)builder.total_component_size();
        result->exe_valid = valid;
        result->validation_errors = val_error;
        result->success = valid ? 1 : -1;
    }

    return exe;
}

FrankensteinDriverBuilder::BuildResult FrankensteinDriverBuilder::build(
    const DriverSpec& spec,
    const char* dw7_disc_path,
    const char* dq4_hbd_disc_path,
    const char* output_bin_path,
    const char* output_cue_path,
    const char* edcre_path)
{
    BuildResult result;
    std::memset(&result, 0, sizeof(result));

    printf("\n╔══════════════════════════════════════════════════════════╗\n");
    printf("║  Frankenstein Driver — Full Disc Build                   ║\n");
    printf("║  EXE as Programmable Bootloader + HBD Re-mapping         ║\n");
    printf("╚══════════════════════════════════════════════════════════╝\n\n");

    // ===== Phase 1: Load source data =====
    printf("=== Phase 1: Loading source data ===\n");

    // Load DW7 disc (contains EXE at sector 24)
    auto dw7_disc = read_file(dw7_disc_path);
    if (dw7_disc.empty()) {
        result.success = -1;
        result.validation_errors = "Failed to load DW7 disc";
        return result;
    }
    printf("  DW7 disc: %zu bytes\n", dw7_disc.size());

    // Extract DW7 EXE from disc (sector 24, 2048 bytes user data per sector)
    constexpr uint32_t DW7_EXE_LBA = 24;
    constexpr uint32_t DW7_EXE_SECTORS = 331;  // 677888 / 2048
    std::vector<uint8_t> dw7_exe_data;
    {
        IsoImage iso;
        if (!iso.open(dw7_disc_path)) {
            result.success = -1;
            result.validation_errors = "Cannot open DW7 disc as ISO";
            return result;
        }
        for (uint32_t i = 0; i < DW7_EXE_SECTORS; i++) {
            uint8_t buf[2048];
            if (iso.read_sector(DW7_EXE_LBA + i, buf) != 0) {
                printf("  WARNING: Failed reading DW7 EXE sector %u\n", i);
                break;
            }
            dw7_exe_data.insert(dw7_exe_data.end(), buf, buf + 2048);
        }
        iso.close();
    }
    printf("  DW7 EXE: %zu bytes (from sector %u)\n", dw7_exe_data.size(), DW7_EXE_LBA);

    // Load DQ4 HBD disc (contains DQ4 HBD at sector 362)
    auto dq4_disc = read_file(dq4_hbd_disc_path);
    if (dq4_disc.empty()) {
        result.success = -1;
        result.validation_errors = "Failed to load DQ4 HBD disc";
        return result;
    }
    printf("  DQ4 disc: %zu bytes\n", dq4_disc.size());

    // Extract DQ4 HBD from disc
    constexpr uint32_t DQ4_HBD_LBA = 362;
    constexpr uint32_t DQ4_HBD_SIZE = 319436800;  // ~305MB
    constexpr uint32_t DQ4_HBD_SECTORS = DQ4_HBD_SIZE / 2048;
    std::vector<uint8_t> dq4_hbd_data;
    {
        IsoImage iso;
        if (!iso.open(dq4_hbd_disc_path)) {
            result.success = -1;
            result.validation_errors = "Cannot open DQ4 disc as ISO";
            return result;
        }
        printf("  Extracting DQ4 HBD: %u sectors from LBA %u...\n", DQ4_HBD_SECTORS, DQ4_HBD_LBA);
        for (uint32_t i = 0; i < DQ4_HBD_SECTORS; i++) {
            uint8_t buf[2048];
            if (iso.read_sector(DQ4_HBD_LBA + i, buf) != 0) {
                printf("  WARNING: Failed reading DQ4 HBD sector %u\n", i);
                break;
            }
            dq4_hbd_data.insert(dq4_hbd_data.end(), buf, buf + 2048);
            if (i % 10000 == 0 && i > 0) {
                printf("    ...%u/%u sectors (%zu MB)\n", i, DQ4_HBD_SECTORS, dq4_hbd_data.size() / (1024*1024));
            }
        }
        iso.close();
    }
    printf("  DQ4 HBD: %zu bytes (%zu MB)\n", dq4_hbd_data.size(), dq4_hbd_data.size() / (1024*1024));

    // ===== Phase 2: Build custom EXE =====
    printf("\n=== Phase 2: Building custom EXE (the driver) ===\n");

    DriverSpec mut_spec = spec;
    mut_spec.dw7_exe = dw7_exe_data.data();
    mut_spec.dw7_exe_size = (uint32_t)dw7_exe_data.size();

    auto custom_exe = build_exe(mut_spec, &result);
    if (custom_exe.empty()) {
        result.success = -1;
        return result;
    }

    // Write custom EXE for inspection
    char exe_path[1024];
    snprintf(exe_path, sizeof(exe_path), "%s.exe", output_bin_path);
    write_file(exe_path, custom_exe.data(), custom_exe.size());
    printf("  Custom EXE written: %s (%u bytes)\n", exe_path, (uint32_t)custom_exe.size());

    // ===== Phase 3: Process DQ4 HBD (data-side transformation) =====
    printf("\n=== Phase 3: Processing DQ4 HBD (re-mapping payload) ===\n");

    HbdProcessor hbd_proc;

    // Load hybrid tree if in HYBRID_GLOBAL mode
    if (spec.hbd.tree_mode == HbdMountSpec::HYBRID_GLOBAL && spec.hbd.hybrid_tree) {
        hbd_proc.load(dq4_hbd_data.data(), (uint32_t)dq4_hbd_data.size(),
                      spec.hbd.hybrid_tree, spec.hbd.hybrid_tree_size);
    } else {
        hbd_proc.load(dq4_hbd_data.data(), (uint32_t)dq4_hbd_data.size());
    }

    // Determine source and target LBAs
    uint32_t source_lba = KnownAddresses::DQ4::HBD_LBA;  // 362
    uint32_t target_lba = spec.hbd.hbd_lba;               // 355

    // Run appropriate processing pipeline
    HbdProcessor::ProcessResult proc_result;
    if (spec.hbd.tree_mode == HbdMountSpec::HYBRID_GLOBAL) {
        printf("  Mode: HYBRID_GLOBAL (full re-encode A+B+C)\n");
        proc_result = hbd_proc.process(source_lba, target_lba);
    } else if (spec.hbd.tree_mode == HbdMountSpec::DQ4_PER_BLOCK) {
        printf("  Mode: DQ4_PER_BLOCK (field swap B + LBA relocation C only)\n");
        proc_result = hbd_proc.process_phase1(source_lba, target_lba);
    } else {
        printf("  Mode: DW7_NATIVE (no transformation)\n");
        proc_result.success = true;
        proc_result.subblock_swaps = 0;
    }

    // Validate processed HBD
    bool hbd_valid = false;
    if (proc_result.success) {
        hbd_valid = hbd_proc.validate(source_lba);
    }

    result.hbd_valid = hbd_valid;
    result.hbd_lba = target_lba;
    result.hbd_sectors = (hbd_proc.size() + 2047) / 2048;

    printf("  HBD processed: %u bytes -> %u bytes (%u sectors)\n",
           (uint32_t)dq4_hbd_data.size(), hbd_proc.size(), result.hbd_sectors);
    printf("  Validation: %s\n", hbd_valid ? "PASSED" : "FAILED");

    // ===== Phase 4: Assemble disc =====
    printf("\n=== Phase 4: Assembling hybrid disc ===\n");

    DiscAssembler::DiscConfig disc_cfg;
    disc_cfg.exe_lba = spec.hbd.exe_lba;    // 24
    disc_cfg.hbd_lba = spec.hbd.hbd_lba;    // 355
    disc_cfg.sector_size = 2352;
    disc_cfg.user_size = 2048;
    disc_cfg.data_offset = 24;
    disc_cfg.disc_id = spec.disc_check.disc_id;

    bool disc_ok = DiscAssembler::assemble(
        dw7_disc_path,           // Base disc (DW7)
        output_bin_path,         // Output .bin
        output_cue_path,         // Output .cue
        custom_exe.data(), (uint32_t)custom_exe.size(),
        hbd_proc.data(), hbd_proc.size(),
        disc_cfg,
        edcre_path);

    result.disc_valid = disc_ok;

    // Get final disc size
    {
        std::ifstream f(output_bin_path, std::ios::binary | std::ios::ate);
        result.disc_size = (uint32_t)f.tellg();
    }

    // ===== Summary =====
    result.success = (disc_ok && result.exe_valid) ? 1 : -1;

    printf("\n=== BUILD COMPLETE ===\n");
    printf("  EXE: %u bytes, PC0=0x%08X, valid=%s\n",
           result.exe_size, result.exe_entry_pc, result.exe_valid ? "YES" : "NO");
    printf("  HBD: %u bytes at LBA %u, valid=%s\n",
           hbd_proc.size(), result.hbd_lba, hbd_valid ? "YES" : "NO");
    printf("  Disc: %u bytes, valid=%s\n",
           result.disc_size, result.disc_valid ? "YES" : "NO");
    printf("  HBD stats: folders=%u files=%u blocks=%u swaps=%u reencoded=%u\n",
           proc_result.folders_parsed, proc_result.files_parsed,
           proc_result.blocks_processed, proc_result.subblock_swaps,
           proc_result.blocks_reencoded);
    printf("  Output: %s + %s\n", output_bin_path, output_cue_path);
    printf("  Strategy: ");
    if (spec.hbd.tree_mode == HbdMountSpec::HYBRID_GLOBAL)
        printf("HYBRID_GLOBAL (full re-encode)\n");
    else if (spec.hbd.tree_mode == HbdMountSpec::DQ4_PER_BLOCK)
        printf("DQ4_PER_BLOCK (field swap + LBA relocation)\n");
    else
        printf("DW7_NATIVE (no transformation)\n");

    if (!result.validation_errors.empty()) {
        printf("  Errors: %s\n", result.validation_errors.c_str());
    }

    return result;
}
