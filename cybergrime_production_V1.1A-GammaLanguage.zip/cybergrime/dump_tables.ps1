# Dump the data table around 0x92936 to understand its structure
# Also dump the CDROM register tables found at 0x800B4888, 0x800B6418
$exePath = 'c:\LuxAura\VoidWalkers_Project\DQLOSTTRANSLATION\translation\SLUSP012.06'
$bytes = [System.IO.File]::ReadAllBytes($exePath)
$loadAddr = 0x80017F00

function HexDump($startOff, $length, $title) {
    Write-Host "=== $title ==="
    for ($i = $startOff; $i -lt ($startOff + $length); $i += 16) {
        $ram = $loadAddr + $i - 0x800
        $hex = ''
        $ascii = ''
        for ($j = 0; $j -lt 16 -and ($i + $j) -lt ($startOff + $length); $j++) {
            $b = $bytes[$i + $j]
            $hex += '{0:X2} ' -f $b
            if ($b -ge 0x20 -and $b -lt 0x7F) { $ascii += [char]$b } else { $ascii += '.' }
        }
        Write-Host ("  0x{0:X5} R{1:X8}: {2} {3}" -f $i, $ram, $hex, $ascii)
    }
}

# Dump the data table at 0x92900 - 0x92A00 (256 bytes)
HexDump 0x92900 256 "Data table at 0x92900 (contains patched MSF at 0x92936)"

# Look at it as 16-bit LE values to find structure
Write-Host ""
Write-Host "=== 16-bit LE values at 0x92900 ==="
for ($i = 0x92900; $i -lt 0x929A0; $i += 2) {
    $val = [BitConverter]::ToUInt16($bytes, $i)
    $ram = $loadAddr + $i - 0x800
    Write-Host ("  0x{0:X5} R{1:X8}: 0x{2:X4} ({3})" -f $i, $ram, $val, $val) -NoNewline
    # Show 4 values per line
    if (($i - 0x92900) % 8 -eq 6) { Write-Host "" } else { Write-Host "  " -NoNewline }
}

# Dump the CDROM register table at 0xB4888 (file offset)
# RAM 0x800B4888 = file offset 0x800B4888 - 0x80017F00 + 0x800 = 0xB4888 - 0x17F00 + 0x800 = 0x9D188
# Wait, RAM = loadAddr + fileOff - 0x800
# fileOff = RAM - loadAddr + 0x800
# 0x800B4888 - 0x80017F00 + 0x800 = 0x9CF88
$cdromRegOff = 0x800B4888 - $loadAddr + 0x800
Write-Host ""
HexDump $cdromRegOff 64 "CDROM register table at RAM 0x800B4888"

# Also check 0x800B6418
$cdromRegOff2 = 0x800B6418 - $loadAddr + 0x800
Write-Host ""
HexDump $cdromRegOff2 64 "CDROM register table at RAM 0x800B6418"

# Check 0x8009A898 area (multiple 48CB1800 entries)
$cdromCodeOff = 0x8009A898 - $loadAddr + 0x800
Write-Host ""
HexDump $cdromCodeOff 128 "Code/data at RAM 0x8009A898"

# Check 0x8008AAEC (andi v0, v0, 0x1800 in FMV area)
$fmvAndiOff = 0x8008AAEC - $loadAddr + 0x800
Write-Host ""
HexDump $fmvAndiOff 32 "FMV area at RAM 0x8008AAEC"
