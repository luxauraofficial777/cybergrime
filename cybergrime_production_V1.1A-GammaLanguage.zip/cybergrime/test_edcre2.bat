@echo off
"..\edcre\edcre-v1.1.0-windows-x86_64-static\edcre.exe" "..\dq4_reverse_edc.cue"
echo EXITCODE:%errorlevel%
