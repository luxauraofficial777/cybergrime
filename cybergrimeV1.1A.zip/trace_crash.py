#!/usr/bin/env python3
"""Check crash address 0x800967DC and surrounding code"""
import struct

def read_sector(disc, lba):
    return disc[lba * 2352 + 24: lba * 2352 + 24 + 2048]

def read_exe_from_disc(disc_path, exe_lba, exe_size):
    with open(disc_path, 'rb') as f:
        disc = f.read()
    exe = bytearray()
    sectors = (exe_size + 2047) // 2048
    for i in range(sectors):
        exe.extend(read_sector(disc, exe_lba + i))
    return bytes(exe[:exe_size])

DISC = r'c:\LuxAura\VoidWalkers_Project\DQLOSTTRANSLATION\dq4_phaseC_build1.bin'
exe = read_exe_from_disc(DISC, 24, 960948)
DW7_DISC = r'c:\LuxAura\VoidWalkers_Project\DQLOSTTRANSLATION\DW7D1\DW7D1.bin'
dw7_exe = read_exe_from_disc(DW7_DISC, 24, 675840)

LOAD_ADDR = 0x80017F00
EXE_HEADER = 0x800

def ram_to_file(ram):
    return ram - LOAD_ADDR + EXE_HEADER

def read_word(data, ram):
    foff = ram_to_file(ram)
    if foff + 4 <= len(data):
        return struct.unpack_from('<I', data, foff)[0]
    return None

def disasm(word, pc):
    if word == 0: return "nop"
    op = (word >> 26) & 0x3F
    rs = (word >> 21) & 0x1F
    rt = (word >> 16) & 0x1F
    rd = (word >> 11) & 0x1F
    shamt = (word >> 6) & 0x1F
    funct = word & 0x3F
    imm = word & 0xFFFF
    s_imm = imm - 65536 if imm >= 32768 else imm
    target = word & 0x03FFFFFF
    regs = ['zero','at','v0','v1','a0','a1','a2','a3','t0','t1','t2','t3','t4','t5','t6','t7','s0','s1','s2','s3','s4','s5','s6','s7','t8','t9','k0','k1','gp','sp','fp','ra']
    if op == 0:
        if funct == 0x08: return f"jr {regs[rs]}"
        if funct == 0x09: return f"jalr {regs[rd]}, {regs[rs]}"
        if funct == 0x21: return f"addu {regs[rd]}, {regs[rs]}, {regs[rt]}"
        if funct == 0x23: return f"subu {regs[rd]}, {regs[rs]}, {regs[rt]}"
        if funct == 0x24: return f"and {regs[rd]}, {regs[rs]}, {regs[rt]}"
        if funct == 0x25: return f"or {regs[rd]}, {regs[rs]}, {regs[rt]}"
        if funct == 0x2A: return f"slt {regs[rd]}, {regs[rs]}, {regs[rt]}"
        if funct == 0x2B: return f"sltu {regs[rd]}, {regs[rs]}, {regs[rt]}"
        if funct == 0x00: return f"sll {regs[rd]}, {regs[rt]}, {shamt}" if rd != 0 else "nop"
        if funct == 0x02: return f"srl {regs[rd]}, {regs[rt]}, {shamt}"
        if funct == 0x03: return f"sra {regs[rd]}, {regs[rt]}, {shamt}"
        if funct == 0x0C: return f"syscall 0x{(word >> 6) & 0xFFFFF:05X}"
        if funct == 0x0D: return f"break 0x{(word >> 6) & 0xFFFFF:05X}"
        if funct == 0x10: return f"mfhi {regs[rd]}"
        if funct == 0x12: return f"mflo {regs[rd]}"
        if funct == 0x18: return f"mult {regs[rs]}, {regs[rt]}"
        if funct == 0x19: return f"multu {regs[rs]}, {regs[rt]}"
        if funct == 0x20: return f"add {regs[rd]}, {regs[rs]}, {regs[rt]}"
        return f"special 0x{funct:02X}"
    if op == 0x01:
        if rt == 0: return f"bltz {regs[rs]}, 0x{pc + 4 + (s_imm << 2):08X}"
        if rt == 1: return f"bgez {regs[rs]}, 0x{pc + 4 + (s_imm << 2):08X}"
        return f"regimm {rt}"
    if op == 0x02: return f"j 0x{(pc & 0xF0000000) | (target << 2):08X}"
    if op == 0x03: return f"jal 0x{(pc & 0xF0000000) | (target << 2):08X}"
    if op == 0x04: return f"beq {regs[rs]}, {regs[rt]}, 0x{pc + 4 + (s_imm << 2):08X}"
    if op == 0x05: return f"bne {regs[rs]}, {regs[rt]}, 0x{pc + 4 + (s_imm << 2):08X}"
    if op == 0x06: return f"blez {regs[rs]}, 0x{pc + 4 + (s_imm << 2):08X}"
    if op == 0x07: return f"bgtz {regs[rs]}, 0x{pc + 4 + (s_imm << 2):08X}"
    if op == 0x08: return f"addi {regs[rt]}, {regs[rs]}, {s_imm}"
    if op == 0x09: return f"addiu {regs[rt]}, {regs[rs]}, {s_imm}"
    if op == 0x0A: return f"slti {regs[rt]}, {regs[rs]}, {s_imm}"
    if op == 0x0B: return f"sltiu {regs[rt]}, {regs[rs]}, {s_imm}"
    if op == 0x0C: return f"andi {regs[rt]}, {regs[rs]}, 0x{imm:04X}"
    if op == 0x0D: return f"ori {regs[rt]}, {regs[rs]}, 0x{imm:04X}"
    if op == 0x0E: return f"xori {regs[rt]}, {regs[rs]}, 0x{imm:04X}"
    if op == 0x0F: return f"lui {regs[rt]}, 0x{imm:04X}"
    if op == 0x20: return f"lb {regs[rt]}, {s_imm}({regs[rs]})"
    if op == 0x21: return f"lh {regs[rt]}, {s_imm}({regs[rs]})"
    if op == 0x23: return f"lw {regs[rt]}, {s_imm}({regs[rs]})"
    if op == 0x24: return f"lbu {regs[rt]}, {s_imm}({regs[rs]})"
    if op == 0x25: return f"lhu {regs[rt]}, {s_imm}({regs[rs]})"
    if op == 0x28: return f"sb {regs[rt]}, {s_imm}({regs[rs]})"
    if op == 0x29: return f"sh {regs[rt]}, {s_imm}({regs[rs]})"
    if op == 0x2B: return f"sw {regs[rt]}, {s_imm}({regs[rs]})"
    if op == 0x10:
        if rs == 0: return f"mfc0 {regs[rt]}, ${rd}"
        if rs == 4: return f"mtc0 {regs[rt]}, ${rd}"
        if rs == 0x10 and funct == 0x18: return "eret"
        return f"cop0 rs={rs} rd=${rd}"
    return f"op=0x{op:02X}"

def show(data, start, count, label=""):
    if label: print(f"\n--- {label} ---")
    for i in range(count):
        ram = start + i * 4
        w = read_word(data, ram)
        if w is None:
            print(f"  0x{ram:08X}: <beyond EXE>")
            break
        d = disasm(w, ram)
        print(f"  0x{ram:08X}: 0x{w:08X}  {d}")

# Crash address 0x800967DC
print("=" * 70)
print("CRASH ADDRESS 0x800967DC (v34 crash site)")
print("=" * 70)
show(exe, 0x800967C0, 32, "Frank")
show(dw7_exe, 0x800967C0, 32, "DW7")

# Check the function containing 0x800967DC
# Look backwards for function prologue
print("\n" + "=" * 70)
print("FUNCTION START (scan backwards from 0x800967DC)")
print("=" * 70)
for addr in range(0x80096700, 0x800967E0, 4):
    w = read_word(exe, addr)
    if w is not None:
        d = disasm(w, addr)
        if 'addiu sp, sp,' in d or 'addiu $sp,' in d:
            print(f"  Function likely starts at 0x{addr:08X}: {d}")
            show(exe, addr, 40, "Frank function")
            show(dw7_exe, addr, 40, "DW7 function")
            break

# Check what the v22 log shows — the CD-ROM polling loop
# v22 last BIOS calls: B:0x17 $ra=0x80096C14, B:0x10 $ra=0x8008B078
print("\n" + "=" * 70)
print("v22 CD-ROM POLLING: 0x80096C00 (B:0x17 return)")
print("=" * 70)
show(exe, 0x80096BF0, 24, "Frank")
show(dw7_exe, 0x80096BF0, 24, "DW7")

print("\n" + "=" * 70)
print("v22 CD-ROM POLLING: 0x8008B060 (B:0x10 return)")
print("=" * 70)
show(exe, 0x8008B060, 24, "Frank")
show(dw7_exe, 0x8008B060, 24, "DW7")

# Check the disc-check patch locations to see if any are near the crash
print("\n" + "=" * 70)
print("DISC-CHECK PATCH LOCATIONS")
print("=" * 70)
dc_offsets = [0x6112C, 0x611D8, 0x613B8, 0x614A4, 0x614F8, 0x7308C, 0x61424, 0x61520, 0x61360]
for off in dc_offsets:
    ram = LOAD_ADDR + off
    w = read_word(exe, ram)
    w_dw7 = read_word(dw7_exe, ram)
    if w is not None:
        print(f"  0x{ram:08X}: Frank=0x{w:08X} ({disasm(w, ram)})  DW7=0x{w_dw7:08X} ({disasm(w_dw7, ram) if w_dw7 else '?'})")

# Check neutralize_disc_change_handler at 0x387CC
print("\n" + "=" * 70)
print("NEUTRALIZE_DISC_CHANGE_HANDLER (0x387CC)")
print("=" * 70)
ram = LOAD_ADDR + 0x387CC
show(exe, ram, 6, "Frank")
show(dw7_exe, ram, 6, "DW7")

# Check the HBD file access — what file is being read?
# The game reads HBD1PS1D.W71 — check the file name string
print("\n" + "=" * 70)
print("HBD FILE NAME STRINGS")
print("=" * 70)
for addr in [0x80026D00, 0x80026D10]:
    foff = ram_to_file(addr)
    if foff + 16 <= len(exe):
        s = exe[foff:foff+16]
        print(f"  0x{addr:08X}: {s.hex()} \"{s.decode('ascii', errors='replace')}\"")
    if foff + 16 <= len(dw7_exe):
        s = dw7_exe[foff:foff+16]
        print(f"  0x{addr:08X}: {s.hex()} \"{s.decode('ascii', errors='replace')}\" (DW7)")

# Check the HBD file size in the disc
print("\n" + "=" * 70)
print("HBD FILE INFO FROM VFS")
print("=" * 70)
print("  v22: HBD1PS1D.W71 LBA=355 size=319436800")
print("  v30: HBD1PS1D.W71 LBA=354 size=618563584")
print("  v34: HBD1PS1D.W71 LBA=355 size=319436800")
print("  v33: HBD1PS1D.W71 LBA=355 size=319436800")
print()
print("  DW7 original: HBD1PS1D.W71 LBA=? size=?")
# Check DW7 disc for HBD file
