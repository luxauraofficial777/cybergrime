// frankenstein_driver_test.cpp
//
// Test harness for the Frankenstein Driver Framework.
// Verifies that the driver codegen produces valid MIPS, that the
// FunctionExtractor correctly pulls functions from real EXEs,
// and that the ExeBuilder assembles a valid PS-X EXE.
//
// Build: g++ -std=c++17 -o frankenstein_driver_test.exe frankenstein_driver_test.cpp frankenstein_driver.cpp
// Run:   frankenstein_driver_test.exe

#include "frankenstein_driver.h"
#include <cstdio>
#include <cstring>

static int tests_passed = 0;
static int tests_failed = 0;

#define TEST(name, cond) do { \
    if (cond) { \
        printf("  [PASS] %s\n", name); \
        tests_passed++; \
    } else { \
        printf("  [FAIL] %s\n", name); \
        tests_failed++; \
    } \
} while(0)

static void test_mips_emitter() {
    printf("\n=== Test: MipsEmitter ===\n");

    MipsEmitter em;

    // Emit a simple function: li v0, 1; jr ra; nop
    em.emit(MipsInstr::addiu(V0, R0, 1));
    em.emit(MipsInstr::jr(RA));
    em.emit(MipsInstr::nop());

    TEST("Emitter produces 12 bytes", em.size() == 12);

    // Verify instruction encoding
    const uint8_t* d = em.data();
    uint32_t insn0 = d[0] | (d[1]<<8) | (d[2]<<16) | (d[3]<<24);
    uint32_t insn1 = d[4] | (d[5]<<8) | (d[6]<<16) | (d[7]<<24);
    uint32_t insn2 = d[8] | (d[9]<<8) | (d[10]<<16) | (d[11]<<24);

    TEST("li v0,1 encodes as 0x24020001", insn0 == 0x24020001);
    TEST("jr ra encodes as 0x03E00008", insn1 == 0x03E00008);
    TEST("nop encodes as 0x00000000", insn2 == 0x00000000);
}

static void test_mips_li32() {
    printf("\n=== Test: MipsInstr::li32 ===\n");

    // Small immediate (fits in 16 bits, no sign extension)
    auto li1 = MipsInstr::li32(V0, 0x1234);
    TEST("li32(0x1234) = 1 instruction", li1.size() == 1);

    // 32-bit value needing lui + addiu
    auto li2 = MipsInstr::li32(V0, 0x800E3D90);
    TEST("li32(0x800E3D90) = 2 instructions", li2.size() == 2);

    // Verify lui immediate
    uint32_t lui_word = li2[0].word;
    uint16_t lui_imm = lui_word & 0xFFFF;
    uint8_t lui_rt = (lui_word >> 16) & 0x1F;

    TEST("lui rt = V0 (2)", lui_rt == 2);

    // 0x800E3D90: hi = 0x800E, lo = 0x3D90
    // lo < 0x8000, so no sign-extension correction needed
    TEST("lui imm = 0x800E", lui_imm == 0x800E);

    // Verify addiu
    uint32_t addiu_word = li2[1].word;
    uint16_t addiu_imm = addiu_word & 0xFFFF;
    // 0x3D90 as uint16_t = 0x3D90 (positive, < 0x8000)
    TEST("addiu imm = 0x3D90", addiu_imm == 0x3D90);
}

static void test_disc_check_bypass() {
    printf("\n=== Test: DriverCodegen::gen_disc_check_bypass ===\n");

    auto code = DriverCodegen::gen_disc_check_bypass();
    TEST("Bypass code is 12 bytes (3 instructions)", code.size() == 12);

    // Verify: li v0, 1; jr ra; nop
    uint32_t insn0 = code[0] | (code[1]<<8) | (code[2]<<16) | (code[3]<<24);
    uint32_t insn1 = code[4] | (code[5]<<8) | (code[6]<<16) | (code[7]<<24);

    TEST("First instruction = li v0, 1 (0x24020001)", insn0 == 0x24020001);
    TEST("Second instruction = jr ra (0x03E00008)", insn1 == 0x03E00008);
}

static void test_bss_clear() {
    printf("\n=== Test: DriverCodegen::gen_bss_clear ===\n");

    auto code = DriverCodegen::gen_bss_clear(0x800BC700, 0x800F4980);
    TEST("BSS clear code > 20 bytes", code.size() > 20);
    TEST("BSS clear code < 100 bytes", code.size() < 100);

    // Verify it starts with lui (0x3C......)
    uint32_t first = code[0] | (code[1]<<8) | (code[2]<<16) | (code[3]<<24);
    TEST("First instruction is LUI (opcode 0x3C)", (first >> 26) == 0x0F);
}

static void test_block_type_trampoline() {
    printf("\n=== Test: DriverCodegen::gen_block_type_trampoline ===\n");

    std::vector<BlockTypeHandler> handlers = {
        {BlockTypes::DQ4_SCRIPT_32, BlockTypeHandler::NATIVE_DQ4, 0, "type32"},
        {BlockTypes::DQ4_MSG_46, BlockTypeHandler::NATIVE_DQ4, 0, "type46"},
        {BlockTypes::DQ4_SUB_39, BlockTypeHandler::CUSTOM_SHIM, 0, "type39"},
        {BlockTypes::DQ4_SUB_40, BlockTypeHandler::CUSTOM_SHIM, 0, "type40"},
        {BlockTypes::DQ4_SUB_42, BlockTypeHandler::CUSTOM_SHIM, 0, "type42"},
    };

    auto code = DriverCodegen::gen_block_type_trampoline(
        KnownAddresses::Safe::TRAMPOLINE_BASE,
        KnownAddresses::DW7::BLOCK_READER,
        handlers);

    TEST("Trampoline code > 50 bytes", code.size() > 50);
    TEST("Trampoline code < 200 bytes", code.size() < 200);

    // Verify it contains addiu $t2, $zero, 32 (0x240A0020)
    bool found_32 = false;
    bool found_46 = false;
    for (size_t i = 0; i + 4 <= code.size(); i += 4) {
        uint32_t insn = code[i] | (code[i+1]<<8) | (code[i+2]<<16) | (code[i+3]<<24);
        if (insn == 0x240A0020) found_32 = true;  // addiu $t2, $zero, 32
        if (insn == 0x240A002E) found_46 = true;  // addiu $t2, $zero, 46
    }
    TEST("Trampoline checks type 32", found_32);
    TEST("Trampoline checks type 46", found_46);
}

static void test_fmv_skip() {
    printf("\n=== Test: DriverCodegen::gen_fmv_skip ===\n");

    auto code = DriverCodegen::gen_fmv_skip();
    TEST("FMV skip is 12 bytes", code.size() == 12);

    uint32_t insn0 = code[0] | (code[1]<<8) | (code[2]<<16) | (code[3]<<24);
    TEST("FMV skip returns 0 (0x24020000)", insn0 == 0x24020000);
}

static void test_function_extractor() {
    printf("\n=== Test: FunctionExtractor ===\n");

    // Create a minimal PS-X EXE for testing
    std::vector<uint8_t> fake_exe(0x1000, 0);

    // Header
    std::memcpy(fake_exe.data(), "PS-X EXE", 8);
    uint32_t pc0 = 0x80018000;
    uint32_t load_addr = 0x80017F00;
    uint32_t text_size = 0x800;
    std::memcpy(fake_exe.data() + 0x10, &pc0, 4);
    std::memcpy(fake_exe.data() + 0x18, &load_addr, 4);
    std::memcpy(fake_exe.data() + 0x1C, &text_size, 4);

    // Put a simple function at offset 0x800 (RAM 0x80017F00)
    // addiu sp, sp, -16; sw ra, 12(sp); li v0, 42; lw ra, 12(sp);
    // addiu sp, sp, 16; jr ra; nop
    uint32_t func[] = {
        0x27BDFFF0,  // addiu sp, sp, -16
        0xAFBF000C,  // sw ra, 12(sp)
        0x2402002A,  // addiu v0, zero, 42
        0x8FBF000C,  // lw ra, 12(sp)
        0x27BD0010,  // addiu sp, sp, 16
        0x03E00008,  // jr ra
        0x00000000,  // nop
    };
    std::memcpy(fake_exe.data() + 0x800, func, sizeof(func));

    FunctionExtractor extractor;
    TEST("Extractor loads fake EXE", extractor.load(fake_exe.data(), (uint32_t)fake_exe.size()));
    TEST("Extractor gets load_addr", extractor.load_address() == 0x80017F00);
    TEST("Extractor gets PC0", extractor.pc0() == 0x80018000);

    // Extract function at RAM 0x80017F00
    auto extracted = extractor.extract_by_ram(0x80017F00, 256);
    TEST("Extracted function has code", extracted.code.size() > 0);
    TEST("Extracted function size = 28 bytes (7 instructions)", extracted.size == 28);
    TEST("Extracted file_offset = 0x800", extracted.file_offset == 0x800);
}

static void test_exe_builder() {
    printf("\n=== Test: ExeBuilder ===\n");

    ExeBuilder builder;

    // Add a simple code component
    std::vector<uint8_t> code = {
        0x01, 0x00, 0x02, 0x24,  // li v0, 1
        0x08, 0x00, 0xE0, 0x03,  // jr ra
        0x00, 0x00, 0x00, 0x00,  // nop
    };
    builder.add_component(ExeBuilder::ExeComponent::RAW_CODE, 0x80017F00, code, "test_code");

    // Add a data component at higher address
    std::vector<uint8_t> data(16, 0xAA);
    builder.add_component(ExeBuilder::ExeComponent::DATA_PAYLOAD, 0x80018000, data, "test_data");

    TEST("Builder has 2 components", builder.total_component_size() == 28);

    // Build EXE
    auto exe = builder.build(0x80017F00, 0x80017F00);

    TEST("Built EXE > 0x800 bytes", exe.size() > 0x800);
    TEST("EXE has PS-X magic", std::memcmp(exe.data(), "PS-X EXE", 8) == 0);

    // Validate
    std::string error;
    bool valid = builder.validate(exe, error);
    TEST("Built EXE validates", valid);

    if (!valid) {
        printf("    Validation error: %s\n", error.c_str());
    }

    // Check PC0 in header
    uint32_t pc0;
    std::memcpy(&pc0, exe.data() + 0x10, 4);
    TEST("PC0 = 0x80017F00", pc0 == 0x80017F00);

    // Check load address in header
    uint32_t la;
    std::memcpy(&la, exe.data() + 0x18, 4);
    TEST("Load address = 0x80017F00", la == 0x80017F00);
}

static void test_default_specs() {
    printf("\n=== Test: Default Driver Specs ===\n");

    auto frank_spec = FrankensteinDriverBuilder::default_frankenstein_spec();
    TEST("Frankenstein spec load_addr = 0x80017F00",
         frank_spec.boot.load_address == KnownAddresses::DW7::LOAD_ADDR);
    TEST("Frankenstein spec HBD LBA = 355",
         frank_spec.hbd.hbd_lba == 355);
    TEST("Frankenstein spec has block handlers",
         !frank_spec.hbd.block_handlers.empty());
    TEST("Frankenstein spec disc check = FULL_BYPASS",
         frank_spec.disc_check.mode == DiscCheckSpec::FULL_BYPASS);
    TEST("Frankenstein spec FMV = SKIP",
         frank_spec.fmv_mode == DriverSpec::FMV_SKIP);

    auto dq4_spec = FrankensteinDriverBuilder::default_dq4_native_spec();
    TEST("DQ4 native spec load_addr = 0x80017F00",
         dq4_spec.boot.load_address == KnownAddresses::DQ4::LOAD_ADDR);
    TEST("DQ4 native spec tree_mode = DQ4_PER_BLOCK",
         dq4_spec.hbd.tree_mode == HbdMountSpec::DQ4_PER_BLOCK);
    TEST("DQ4 native spec no block handlers",
         dq4_spec.hbd.block_handlers.empty());

    auto clean_spec = FrankensteinDriverBuilder::default_cleanroom_spec();
    TEST("Cleanroom spec tree_mode = HYBRID_GLOBAL",
         clean_spec.hbd.tree_mode == HbdMountSpec::HYBRID_GLOBAL);
    TEST("Cleanroom spec has block handlers",
         !clean_spec.hbd.block_handlers.empty());
}

static void test_block_type_registry() {
    printf("\n=== Test: Block Type Registry ===\n");

    TEST("DQ4 type 32 → DW7 type 40",
         BlockTypes::dq4_to_dw7(BlockTypes::DQ4_SCRIPT_32) == BlockTypes::DW7_TEXT_40);
    TEST("DQ4 type 46 → DW7 type 42",
         BlockTypes::dq4_to_dw7(BlockTypes::DQ4_MSG_46) == BlockTypes::DW7_TEXT_42);
    TEST("Type 32 needs re-encoding", BlockTypes::needs_reencode(32));
    TEST("Type 46 needs re-encoding", BlockTypes::needs_reencode(46));
    TEST("Type 23 needs re-encoding", BlockTypes::needs_reencode(23));
    TEST("Type 19 does NOT need re-encoding", !BlockTypes::needs_reencode(19));

    TEST("Type 32 recommended strategy = NATIVE_DQ4",
         BlockTypes::recommended_strategy(32) == BlockTypeHandler::NATIVE_DQ4);
    TEST("Type 46 recommended strategy = NATIVE_DQ4",
         BlockTypes::recommended_strategy(46) == BlockTypeHandler::NATIVE_DQ4);
}

static void test_known_addresses() {
    printf("\n=== Test: Known Addresses ===\n");

    // Verify addresses match the documented values from VectorDB cross-reference
    TEST("DW7 HBD mount = 0x8002EC2C",
         KnownAddresses::DW7::HBD_MOUNT == 0x8002EC2C);
    TEST("DW7 block reader = 0x80042A04",
         KnownAddresses::DW7::BLOCK_READER == 0x80042A04);
    TEST("DW7 Huffman decompressor = 0x80073670",
         KnownAddresses::DW7::HUFFMAN == 0x80073670);
    TEST("DW7 disc number var = 0x800E3D90",
         KnownAddresses::DW7::DISC_NUM_VAR == 0x800E3D90);
    TEST("DW7 disc change handler = 0x800506CC",
         KnownAddresses::DW7::DISC_CHANGE == 0x800506CC);
    TEST("DW7 BSS clear start = 0x800BC668",
         KnownAddresses::DW7::BSS_CLEAR == 0x800BC668);
    TEST("DW7 BSS clear end = 0x800F4980",
         KnownAddresses::DW7::BSS_END == 0x800F4980);
    TEST("DW7 thread entry = 0x800D9E80",
         KnownAddresses::DW7::THREAD_ENTRY == 0x800D9E80);
    TEST("DW7 FMV LBA = 146621",
         KnownAddresses::DW7::FMV_LBA == 146621);

    TEST("Safe high RAM = 0x80100000",
         KnownAddresses::Safe::HIGH_RAM_START == 0x80100000);
    TEST("Safe trampoline base = 0x80101000",
         KnownAddresses::Safe::TRAMPOLINE_BASE == 0x80101000);
}

static void test_payload_remapper() {
    printf("\n=== Test: PayloadRemapper ===\n");

    PayloadRemapper::RemapConfig cfg;
    cfg.exe_lba = 24;
    cfg.exe_size = 677888;
    cfg.hbd_lba = 355;
    cfg.hbd_size = 319436800;
    cfg.dq4_hbd_source_lba = 362;
    cfg.dw7_fmv_lba = 0;  // No FMV preservation for DQ4 HBD (it's larger)
    cfg.preserve_dw7_fmv = false;

    std::vector<FolderMapping> folder_map;

    auto entries = PayloadRemapper::compute_layout(cfg, folder_map);
    TEST("Remap entries non-empty", !entries.empty());

    // Validate layout
    std::string error;
    bool valid = PayloadRemapper::validate_layout(cfg, entries, error);
    TEST("Layout validates", valid);

    if (!valid) {
        printf("    Error: %s\n", error.c_str());
    }

    // Check first entry
    TEST("First entry DQ4 sector = 362", entries[0].dq4_sector == 362);
    TEST("First entry disc sector = 355", entries[0].new_disc_sector == 355);
}

static void test_hbd_processor() {
    printf("\n=== Test: HbdProcessor ===\n");

    // Create a minimal fake HBD: sector 0 (header) + sector 1 (folder with 1 file)
    std::vector<uint8_t> fake_hbd(2 * 2048, 0);

    // Sector 0: binary header (all zeros is fine for test)
    // Sector 1: folder header
    uint8_t* folder = fake_hbd.data() + 2048;
    uint32_t file_count = 1;
    uint32_t sector_count = 1;
    uint32_t folder_size = 2048;
    std::memcpy(folder + 0, &file_count, 4);
    std::memcpy(folder + 4, &sector_count, 4);
    std::memcpy(folder + 8, &folder_size, 4);

    // File entry at offset 16: size(4) + size_unc(4) + pad(4) + flags(2) + type_id(2)
    // Use type_id = 32 (DQ4_SCRIPT_32) to test field swap
    uint32_t file_size = 64;  // Small file
    uint32_t file_size_unc = 64;
    uint16_t flags = 5;       // In DQ4, this is the count
    uint16_t type_id = 32;    // DQ4 type
    std::memcpy(folder + 16, &file_size, 4);
    std::memcpy(folder + 20, &file_size_unc, 4);
    std::memcpy(folder + 28, &flags, 2);
    std::memcpy(folder + 30, &type_id, 2);

    // File content at offset 32: simple block header (24 bytes)
    // end_marker=64, block_id=1, hts=24, tree_end=0, text_end=0, unk=0
    uint32_t hdr[6] = {64, 1, 24, 0, 0, 0};
    std::memcpy(folder + 32, hdr, 24);
    // Rest is zero (text data + padding)

    HbdProcessor proc;
    TEST("HbdProcessor loads", proc.load(fake_hbd.data(), (uint32_t)fake_hbd.size()));
    TEST("HbdProcessor size = 4096", proc.size() == 4096);

    // Process Phase 1 (field swap only, no re-encoding)
    auto result = proc.process_phase1(362, 355);
    TEST("HbdProcessor phase1 completes", result.success || result.errors > 0);
    TEST("HbdProcessor phase1 parsed folders", result.folders_parsed > 0 || result.errors > 0);

    // After processing, check if type_id was swapped
    // The field swap converts: flags(count)→type_id, type_id(type)→flags
    // So type_id=32, flags=5 becomes: type_id=5, flags=32
    // Wait — the swap is: count=flags, flags=0, type_id=count
    // So: type_id becomes 5 (the old flags), flags becomes 0
    uint16_t new_type_id, new_flags;
    std::memcpy(&new_flags, folder + 28, 2);
    std::memcpy(&new_type_id, folder + 30, 2);

    // After phase1 processing, the data is in proc.data(), not in fake_hbd anymore
    const uint8_t* processed = proc.data();
    if (processed && proc.size() >= 2048 + 32) {
        std::memcpy(&new_flags, processed + 2048 + 28, 2);
        std::memcpy(&new_type_id, processed + 2048 + 30, 2);
        // After swap: old flags(5) → type_id, old type_id(32) → discarded, flags=0
        // Actually the swap is: count=flags(5), flags=0, type_id=count(5)
        TEST("After swap: type_id = 5 (was 32)", new_type_id == 5);
        TEST("After swap: flags = 0", new_flags == 0);
    } else {
        TEST("Processed data accessible", false);
    }
}

static void test_disc_assembler_cue() {
    printf("\n=== Test: DiscAssembler::write_cue ===\n");

    // Write a CUE sheet to a temp file
    const char* cue_path = "test_frankenstein.cue";
    bool ok = DiscAssembler::write_cue(cue_path, "test_frankenstein.bin");
    TEST("CUE sheet written", ok);

    // Verify content
    FILE* f = fopen(cue_path, "r");
    TEST("CUE file readable", f != nullptr);
    if (f) {
        char line[256];
        fgets(line, sizeof(line), f);
        TEST("CUE first line contains FILE", strstr(line, "FILE") != nullptr);
        TEST("CUE first line contains bin name", strstr(line, "test_frankenstein.bin") != nullptr);
        fgets(line, sizeof(line), f);
        TEST("CUE second line contains TRACK", strstr(line, "TRACK") != nullptr);
        TEST("CUE second line contains MODE2", strstr(line, "MODE2") != nullptr);
        fgets(line, sizeof(line), f);
        TEST("CUE third line contains INDEX", strstr(line, "INDEX") != nullptr);
        fclose(f);
        remove(cue_path);
    }
}

static void test_disc_assembler_config() {
    printf("\n=== Test: DiscAssembler::DiscConfig ===\n");

    DiscAssembler::DiscConfig cfg;
    cfg.exe_lba = 24;
    cfg.hbd_lba = 355;
    cfg.sector_size = 2352;
    cfg.user_size = 2048;
    cfg.data_offset = 24;
    cfg.disc_id = "SLUS_012.06";

    TEST("DiscConfig exe_lba = 24", cfg.exe_lba == 24);
    TEST("DiscConfig hbd_lba = 355", cfg.hbd_lba == 355);
    TEST("DiscConfig sector_size = 2352", cfg.sector_size == 2352);
    TEST("DiscConfig user_size = 2048", cfg.user_size == 2048);
}

int main() {
    printf("╔══════════════════════════════════════════════════════════╗\n");
    printf("║  Frankenstein Driver Framework — Test Suite              ║\n");
    printf("║  EXEs as Programmable Bootloaders                        ║\n");
    printf("╚══════════════════════════════════════════════════════════╝\n");

    test_mips_emitter();
    test_mips_li32();
    test_disc_check_bypass();
    test_bss_clear();
    test_block_type_trampoline();
    test_fmv_skip();
    test_function_extractor();
    test_exe_builder();
    test_default_specs();
    test_block_type_registry();
    test_known_addresses();
    test_payload_remapper();
    test_hbd_processor();
    test_disc_assembler_cue();
    test_disc_assembler_config();

    printf("\n═══════════════════════════════════════════════════════════\n");
    printf("  Results: %d passed, %d failed\n", tests_passed, tests_failed);
    printf("═══════════════════════════════════════════════════════════\n");

    return tests_failed > 0 ? 1 : 0;
}
