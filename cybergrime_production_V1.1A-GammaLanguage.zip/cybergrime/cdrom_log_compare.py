#!/usr/bin/env python3
"""
cdrom_log_compare.py — Compare CyberGrime CD-ROM trace with DuckStation log.

Usage:
    python cdrom_log_compare.py --cybergrime telemetry.json --duckstation duckstation.log

CyberGrime JSON format (from agent_harness.cpp):
    {
      "CDROM_Trace": {
        "total_commands": N,
        "total_errors": N,
        "setloc_errors": N,
        "commands": [
          {"instr": N, "pc": "0x...", "ra": "0x...", "cmd": "Setloc", "cmd_byte": 2, "params": 3, "result": 0},
          ...
        ],
        "events": [
          {"instr": N, "event_id": N, "class": N, "spec": N, "flags": N, "action": "deliver", "test_result": -1},
          ...
        ]
      }
    }

DuckStation log format (from cdrom.cpp DEV_COLOR_LOG):
    [N] CDROM: Execute command Setloc (3 params, Intr)
    [N] CDROM: INT3 interrupt
    [N] CDROM: Setloc -- minute=XX second=XX frame=XX
"""

import argparse
import json
import re
import sys
from dataclasses import dataclass, field
from typing import List, Optional, Tuple


@dataclass
class CdCommand:
    source: str  # "cybergrime" or "duckstation"
    index: int  # sequence number within source
    instr_or_frame: int  # instruction count (CG) or frame number (DS)
    command_name: str
    command_byte: int
    param_count: int
    params: List[int] = field(default_factory=list)
    result: int = 0  # 0=success, nonzero=error
    pc: str = ""
    ra: str = ""
    interrupt: str = ""  # "INT1", "INT3", etc.


@dataclass
class ComparisonResult:
    total_cg_commands: int = 0
    total_ds_commands: int = 0
    matched: int = 0
    diverged: int = 0
    cg_only: int = 0
    ds_only: int = 0
    param_mismatches: int = 0
    missing_interrupts_cg: int = 0
    missing_interrupts_ds: int = 0
    error_mismatches: int = 0
    divergences: list = field(default_factory=list)


def parse_cybergrime(json_path: str) -> List[CdCommand]:
    """Parse CyberGrime telemetry JSON into CdCommand list."""
    with open(json_path, "r", encoding="utf-8") as f:
        data = json.load(f)

    trace = data.get("CDROM_Trace", {})
    commands = trace.get("commands", [])

    result = []
    for i, c in enumerate(commands):
        cmd = CdCommand(
            source="cybergrime",
            index=i,
            instr_or_frame=c.get("instr", 0),
            command_name=c.get("cmd", "Unknown"),
            command_byte=c.get("cmd_byte", 0),
            param_count=c.get("params", 0),
            result=c.get("result", 0),
            pc=c.get("pc", ""),
            ra=c.get("ra", ""),
        )
        result.append(cmd)

    # Also parse events for interrupt tracking
    events = trace.get("events", [])
    for e in events:
        if e.get("action") == "deliver":
            # Map event class to interrupt type
            cls = e.get("class", 0)
            if cls == 3:  # CD-ROM ready
                cmd = CdCommand(
                    source="cybergrime",
                    index=-1,
                    instr_or_frame=e.get("instr", 0),
                    command_name="INT3",
                    command_byte=0,
                    param_count=0,
                    interrupt="INT3",
                )
                result.append(cmd)

    # Sort by instruction count
    result.sort(key=lambda c: c.instr_or_frame)
    return result


# DuckStation log patterns
DS_CMD_PATTERN = re.compile(
    r"(?:\[\d+:\d+:\.\d+\]\s*)?CDROM:\s*Execute command\s+(\w+)\s*\((\d+)\s*param[s]?\)"
)
DS_INT_PATTERN = re.compile(
    r"(?:\[\d+:\d+:\.\d+\]\s*)?CDROM:\s*(INT\d+)\s*(?:interrupt|acknowledge)"
)
DS_SETLOC_PATTERN = re.compile(
    r"(?:\[\d+:\d+:\.\d+\]\s*)?CDROM:\s*Setloc\s+--\s+minute=(\d+)\s+second=(\d+)\s+frame=(\d+)"
)
DS_ERROR_PATTERN = re.compile(
    r"(?:\[\d+:\d+:\.\d+\]\s*)?CDROM:\s*Incorrect parameters for command\s+0x([0-9A-Fa-f]+)\s+\((\w+)\),\s+expecting\s+(\d+)-(\d+)\s+got\s+(\d+)"
)
DS_FRAME_PATTERN = re.compile(r"Frame\s+(\d+)")


def parse_duckstation(log_path: str) -> List[CdCommand]:
    """Parse DuckStation log into CdCommand list."""
    commands = []
    frame_num = 0
    seq = 0

    with open(log_path, "r", encoding="utf-8", errors="replace") as f:
        for line in f:
            # Track frame number
            frame_match = DS_FRAME_PATTERN.search(line)
            if frame_match:
                frame_num = int(frame_match.group(1))

            # Command execution
            cmd_match = DS_CMD_PATTERN.search(line)
            if cmd_match:
                name = cmd_match.group(1)
                param_count = int(cmd_match.group(2))
                cmd_byte = _name_to_byte(name)
                commands.append(CdCommand(
                    source="duckstation",
                    index=seq,
                    instr_or_frame=frame_num,
                    command_name=name,
                    command_byte=cmd_byte,
                    param_count=param_count,
                ))
                seq += 1
                continue

            # Interrupt delivery
            int_match = DS_INT_PATTERN.search(line)
            if int_match:
                int_type = int_match.group(1)
                commands.append(CdCommand(
                    source="duckstation",
                    index=seq,
                    instr_or_frame=frame_num,
                    command_name=int_type,
                    command_byte=0,
                    param_count=0,
                    interrupt=int_type,
                ))
                seq += 1
                continue

            # Setloc detail
            setloc_match = DS_SETLOC_PATTERN.search(line)
            if setloc_match and commands:
                # Attach params to last Setloc command
                for cmd in reversed(commands):
                    if cmd.command_name == "Setloc":
                        cmd.params = [
                            int(setloc_match.group(1)),
                            int(setloc_match.group(2)),
                            int(setloc_match.group(3)),
                        ]
                        break
                continue

            # Error
            error_match = DS_ERROR_PATTERN.search(line)
            if error_match:
                cmd_byte = int(error_match.group(1), 16)
                cmd_name = error_match.group(2)
                expected_min = int(error_match.group(3))
                expected_max = int(error_match.group(4))
                actual = int(error_match.group(5))
                commands.append(CdCommand(
                    source="duckstation",
                    index=seq,
                    instr_or_frame=frame_num,
                    command_name=f"ERROR:{cmd_name}",
                    command_byte=cmd_byte,
                    param_count=actual,
                    result=actual,
                ))
                seq += 1
                continue

    return commands


def _name_to_byte(name: str) -> int:
    """Convert command name to byte."""
    mapping = {
        "Getstat": 0x01, "Setloc": 0x02, "Play": 0x03, "Forward": 0x04,
        "Backward": 0x05, "ReadN": 0x06, "MotorOn": 0x07, "Stop": 0x08,
        "Pause": 0x09, "Init": 0x0A, "Mute": 0x0B, "Demute": 0x0C,
        "Setfilter": 0x0D, "Setmode": 0x0E, "Getparam": 0x0F,
        "GetlocL": 0x10, "GetlocP": 0x11, "Setsession": 0x12,
        "GetTN": 0x13, "GetTD": 0x14, "SeekL": 0x15, "SeekP": 0x16,
        "Test": 0x19, "GetID": 0x1A, "ReadS": 0x1B, "Reset": 0x1C,
        "ReadTOC": 0x1E,
    }
    return mapping.get(name, 0)


def compare_traces(cg_commands: List[CdCommand],
                   ds_commands: List[CdCommand]) -> ComparisonResult:
    """Compare two CD-ROM command traces."""
    result = ComparisonResult()
    result.total_cg_commands = len(cg_commands)
    result.total_ds_commands = len(ds_commands)

    # Filter to only actual commands (not interrupts) for sequence comparison
    cg_cmds = [c for c in cg_commands if not c.interrupt and c.command_byte != 0]
    ds_cmds = [c for c in ds_commands if not c.interrupt and c.command_byte != 0]

    # Align by sequence (both should follow same command order)
    max_len = max(len(cg_cmds), len(ds_cmds))

    for i in range(max_len):
        cg = cg_cmds[i] if i < len(cg_cmds) else None
        ds = ds_cmds[i] if i < len(ds_cmds) else None

        if cg is None:
            result.ds_only += 1
            result.divergences.append({
                "type": "ds_only",
                "seq": i,
                "detail": f"DuckStation has {ds.command_name} (0x{ds.command_byte:02X}) "
                          f"with {ds.param_count} params, CyberGrime has nothing",
            })
            continue

        if ds is None:
            result.cg_only += 1
            result.divergences.append({
                "type": "cg_only",
                "seq": i,
                "detail": f"CyberGrime has {cg.command_name} (0x{cg.command_byte:02X}) "
                          f"with {cg.param_count} params, DuckStation has nothing",
            })
            continue

        # Both exist — compare
        if cg.command_byte == ds.command_byte:
            result.matched += 1

            # Check param count
            if cg.param_count != ds.param_count:
                result.param_mismatches += 1
                result.divergences.append({
                    "type": "param_mismatch",
                    "seq": i,
                    "detail": f"{cg.command_name}: CG params={cg.param_count}, "
                              f"DS params={ds.param_count}",
                })

            # Check error status
            if (cg.result != 0) != (ds.result != 0):
                result.error_mismatches += 1
                result.divergences.append({
                    "type": "error_mismatch",
                    "seq": i,
                    "detail": f"{cg.command_name}: CG result={cg.result}, "
                              f"DS result={ds.result}",
                })
        else:
            result.diverged += 1
            result.divergences.append({
                "type": "command_mismatch",
                "seq": i,
                "detail": f"CG={cg.command_name} (0x{cg.command_byte:02X}) vs "
                          f"DS={ds.command_name} (0x{ds.command_byte:02X})",
            })

    # Compare interrupt delivery
    cg_ints = [c for c in cg_commands if c.interrupt]
    ds_ints = [c for c in ds_commands if c.interrupt]

    if len(cg_ints) < len(ds_ints):
        result.missing_interrupts_cg = len(ds_ints) - len(cg_ints)
        result.divergences.append({
            "type": "missing_interrupts",
            "seq": -1,
            "detail": f"CyberGrime delivered {len(cg_ints)} interrupts, "
                      f"DuckStation delivered {len(ds_ints)} — "
                      f"{result.missing_interrupts_cg} missing in CyberGrime",
        })
    elif len(ds_ints) < len(cg_ints):
        result.missing_interrupts_ds = len(cg_ints) - len(ds_ints)
        result.divergences.append({
            "type": "extra_interrupts",
            "seq": -1,
            "detail": f"CyberGrime delivered {len(cg_ints)} interrupts, "
                      f"DuckStation delivered {len(ds_ints)} — "
                      f"{result.missing_interrupts_ds} extra in CyberGrime",
        })

    return result


def print_report(result: ComparisonResult, verbose: bool = False):
    """Print comparison report."""
    print("=" * 70)
    print("CD-ROM Log Comparison: CyberGrime vs DuckStation")
    print("=" * 70)

    print(f"\nCyberGrime commands:    {result.total_cg_commands}")
    print(f"DuckStation commands:   {result.total_ds_commands}")
    print(f"\nMatched:                {result.matched}")
    print(f"Diverged:               {result.diverged}")
    print(f"CyberGrime-only:        {result.cg_only}")
    print(f"DuckStation-only:       {result.ds_only}")
    print(f"Param mismatches:       {result.param_mismatches}")
    print(f"Error mismatches:       {result.error_mismatches}")
    print(f"Missing INTs (CG):      {result.missing_interrupts_cg}")
    print(f"Missing INTs (DS):      {result.missing_interrupts_ds}")

    total = result.matched + result.diverged + result.cg_only + result.ds_only
    if total > 0:
        pct = (result.matched / total) * 100
        print(f"\nMatch rate: {pct:.1f}%")

    if result.divergences:
        print(f"\n{'─' * 70}")
        print(f"Divergences ({len(result.divergences)} total):")
        print(f"{'─' * 70}")

        # Show first 50 divergences unless verbose
        to_show = result.divergences if verbose else result.divergences[:50]
        for d in to_show:
            print(f"  [{d['type']}] seq={d['seq']}: {d['detail']}")

        if not verbose and len(result.divergences) > 50:
            print(f"  ... and {len(result.divergences) - 50} more (use --verbose)")
    else:
        print(f"\n{'─' * 70}")
        print("No divergences detected — traces match perfectly!")
        print(f"{'─' * 70}")

    print("=" * 70)


def main():
    parser = argparse.ArgumentParser(
        description="Compare CyberGrime CD-ROM trace with DuckStation log"
    )
    parser.add_argument("--cybergrime", required=True,
                        help="Path to CyberGrime telemetry JSON file")
    parser.add_argument("--duckstation", required=True,
                        help="Path to DuckStation log file")
    parser.add_argument("--verbose", action="store_true",
                        help="Show all divergences (default: first 50)")
    parser.add_argument("--json-output", default=None,
                        help="Write comparison result as JSON to this path")
    args = parser.parse_args()

    print(f"Parsing CyberGrime telemetry: {args.cybergrime}")
    cg_commands = parse_cybergrime(args.cybergrime)
    print(f"  Found {len(cg_commands)} CD-ROM entries")

    print(f"Parsing DuckStation log: {args.duckstation}")
    ds_commands = parse_duckstation(args.duckstation)
    print(f"  Found {len(ds_commands)} CD-ROM entries")

    result = compare_traces(cg_commands, ds_commands)
    print_report(result, verbose=args.verbose)

    if args.json_output:
        output = {
            "total_cg_commands": result.total_cg_commands,
            "total_ds_commands": result.total_ds_commands,
            "matched": result.matched,
            "diverged": result.diverged,
            "cg_only": result.cg_only,
            "ds_only": result.ds_only,
            "param_mismatches": result.param_mismatches,
            "error_mismatches": result.error_mismatches,
            "missing_interrupts_cg": result.missing_interrupts_cg,
            "missing_interrupts_ds": result.missing_interrupts_ds,
            "divergences": result.divergences,
        }
        with open(args.json_output, "w", encoding="utf-8") as f:
            json.dump(output, f, indent=2)
        print(f"\nJSON output written to: {args.json_output}")


if __name__ == "__main__":
    main()
