#!/usr/bin/env python3
"""
apply_bss_patch.py — Apply BSS narrow patch to disc image at build time.

Patches the EXE within the disc image to narrow the BSS clear range,
preserving the CD-ROM thread entry at 0x800D9E80.

Disc offset calculation:
  EXE is at LBA 24, each sector = 2352 bytes (24 header + 2048 data)
  EXE file offset 0x76B90 → disc offset 0x096198
"""

import struct
import shutil
import sys
import os
import hashlib

SECTOR_SIZE = 0x930       # 2352 bytes
SECTOR_DATA = 0x800       # 2048 bytes user data
SECTOR_HEADER = 24        # sync(12) + header(4) + subheader(8)
EXE_LBA = 24
# BSS clear loop: lui $v0,0x800C; addiu $v0,0xC668; lui $v1,0x800F; addiu $v1,imm; sw $zero,0($v0)
# Must patch BOTH lui $v1 AND addiu $v1 because 0xCCC8 is a SIGNED negative immediate.
#   lui 0x800F + addiu 0xCCC8 = 0x800ECCC8 (WRONG — still zeros thread entry)
#   lui 0x800C + addiu 0xCCC8 = 0x800BCCC8 (CORRECT — preserves thread entry)
LUI_EXE_OFFSET = 0x76B8C      # lui $v1, 0x800F → 0x800C
ADDIU_EXE_OFFSET = 0x76B90    # addiu $v1, 0x4980 → 0xCCC8
LUI_ORIGINAL = 0x3C03800F     # lui $v1, 0x800F
LUI_PATCHED = 0x3C03800C      # lui $v1, 0x800C
ADDIU_ORIGINAL = 0x24634980   # addiu $v1, $v1, 0x4980
ADDIU_PATCHED = 0x2462CCC8    # addiu $v1, $v1, 0xCCC8
# Legacy compat
EXE_FILE_OFFSET = 0x76B90
ORIGINAL_VALUE = 0x24634980
PATCHED_VALUE = 0x2462CCC8

def exe_to_disc_offset(exe_offset):
    sector_idx = exe_offset // SECTOR_DATA
    offset_in_sector = exe_offset % SECTOR_DATA
    return (EXE_LBA + sector_idx) * SECTOR_SIZE + SECTOR_HEADER + offset_in_sector

def crc32(data):
    import binascii
    return binascii.crc32(data) & 0xFFFFFFFF

def main():
    if len(sys.argv) < 2:
        print(f"Usage: {sys.argv[0]} <disc.bin> [--verify-only]")
        sys.exit(1)

    disc_path = sys.argv[1]
    verify_only = '--verify-only' in sys.argv

    addiu_disc = exe_to_disc_offset(ADDIU_EXE_OFFSET)
    lui_disc = exe_to_disc_offset(LUI_EXE_OFFSET)
    print(f"Disc: {disc_path}")
    print(f"\nLUI patch (lui $v1, BSS end upper):")
    print(f"  EXE offset:  0x{LUI_EXE_OFFSET:06X}")
    print(f"  Disc offset: 0x{lui_disc:06X}")
    print(f"  Original:    0x{LUI_ORIGINAL:08X} (lui $v1, 0x800F)")
    print(f"  Patched:     0x{LUI_PATCHED:08X} (lui $v1, 0x800C)")
    print(f"\nADDIU patch (addiu $v1, BSS end lower):")
    print(f"  EXE offset:  0x{ADDIU_EXE_OFFSET:06X}")
    print(f"  Disc offset: 0x{addiu_disc:06X}")
    print(f"  Original:    0x{ADDIU_ORIGINAL:08X} (addiu $v1, 0x4980)")
    print(f"  Patched:     0x{ADDIU_PATCHED:08X} (addiu $v1, 0xCCC8)")

    # Read current values
    with open(disc_path, 'rb') as f:
        f.seek(lui_disc)
        curr_lui = struct.unpack('<I', f.read(4))[0]
        f.seek(addiu_disc)
        curr_addiu = struct.unpack('<I', f.read(4))[0]

    print(f"\nCurrent state:")
    print(f"  LUI:   0x{curr_lui:08X} {'✓ patched' if curr_lui == LUI_PATCHED else '✗ needs patch' if curr_lui == LUI_ORIGINAL else '? unexpected'}")
    print(f"  ADDIU: 0x{curr_addiu:08X} {'✓ patched' if curr_addiu == ADDIU_PATCHED else '✗ needs patch' if curr_addiu == ADDIU_ORIGINAL else '? unexpected'}")

    # Verify BSS end calculation
    lui_imm = curr_lui & 0xFFFF
    addiu_imm = curr_addiu & 0xFFFF
    addiu_signed = addiu_imm - 0x10000 if addiu_imm >= 0x8000 else addiu_imm
    bss_end = ((lui_imm << 16) + addiu_signed) & 0xFFFFFFFF
    print(f"  BSS end: 0x{bss_end:08X} {'✓ CORRECT' if bss_end == 0x800BCCC8 else '✗ WRONG'}")
    print(f"  Thread entry 0x800D9E80 in range: {0x800BC668 <= 0x800D9E80 < bss_end}")

    if curr_lui == LUI_PATCHED and curr_addiu == ADDIU_PATCHED:
        print("\n✓ Both patches already applied — no action needed")
        return 0

    if verify_only:
        print("\nVerify-only mode — patches needed but not applying")
        sys.exit(1)

    # Backup
    backup_path = disc_path + '.bak'
    if not os.path.exists(backup_path):
        shutil.copy2(disc_path, backup_path)
        print(f"\nBackup: {backup_path}")

    # Apply patches
    with open(disc_path, 'r+b') as f:
        if curr_lui != LUI_PATCHED:
            f.seek(lui_disc)
            f.write(struct.pack('<I', LUI_PATCHED))
            print(f"  ✓ LUI patched: 0x{curr_lui:08X} → 0x{LUI_PATCHED:08X}")
        if curr_addiu != ADDIU_PATCHED:
            f.seek(addiu_disc)
            f.write(struct.pack('<I', ADDIU_PATCHED))
            print(f"  ✓ ADDIU patched: 0x{curr_addiu:08X} → 0x{ADDIU_PATCHED:08X}")

    # Verify
    with open(disc_path, 'rb') as f:
        f.seek(lui_disc)
        final_lui = struct.unpack('<I', f.read(4))[0]
        f.seek(addiu_disc)
        final_addiu = struct.unpack('<I', f.read(4))[0]

    lui_imm = final_lui & 0xFFFF
    addiu_imm = final_addiu & 0xFFFF
    addiu_signed = addiu_imm - 0x10000 if addiu_imm >= 0x8000 else addiu_imm
    bss_end = ((lui_imm << 16) + addiu_signed) & 0xFFFFFFFF

    print(f"\n=== FINAL VERIFICATION ===")
    print(f"  LUI:   0x{final_lui:08X} {'✓' if final_lui == LUI_PATCHED else '✗'}")
    print(f"  ADDIU: 0x{final_addiu:08X} {'✓' if final_addiu == ADDIU_PATCHED else '✗'}")
    print(f"  BSS end: 0x{bss_end:08X} {'✓ CORRECT' if bss_end == 0x800BCCC8 else '✗ WRONG'}")
    print(f"  Thread entry 0x800D9E80 in BSS range: {0x800BC668 <= 0x800D9E80 < bss_end}")
    if bss_end == 0x800BCCC8:
        print(f"\n✅ BSS narrow patch applied — HF-001 resolved (thread entry preserved)")
    else:
        print(f"\n✗ PATCH VERIFICATION FAILED — BSS end is 0x{bss_end:08X}")
        sys.exit(1)

    # Full disc checksum
    with open(disc_path, 'rb') as f:
        full_hash = hashlib.sha256()
        while True:
            chunk = f.read(65536)
            if not chunk:
                break
            full_hash.update(chunk)
    print(f"Full disc SHA-256: {full_hash.hexdigest()}")

    print("\n✅ BSS narrow patch applied — HF-001 resolved at build time")

if __name__ == '__main__':
    main()
