# CD-ROM Pipeline Gaps — Custom Emulator vs DuckStation Reference

## Overview
Our custom emulator (`psx_emulator_core.cpp` + `psx_test_station.h`) has a CD-ROM pipeline that is **partially functional** but has critical gaps preventing the game from progressing past CD-ROM init. The game sends `GetStat` and `GetLocP` commands but never issues `Setloc`/`ReadN`, indicating the handshake/status register flow is broken.

Reference implementation: `study/duckstation-src/src/core/cdrom.cpp`

---

## 1. Status Register (0x1F801800) — BIT LAYOUT IS WRONG

### DuckStation (CORRECT)
```
Bit 0-1: INDEX (current index register)
Bit 2:   ADPBUSY (ADPCM busy)
Bit 3:   PRMEMPTY (parameter FIFO empty)
Bit 4:   PRMWRDY (parameter FIFO ready/not full)
Bit 5:   RSLRRDY (response FIFO has data)
Bit 6:   DRQSTS (data FIFO ready for DMA read)
Bit 7:   BUSYSTS (command busy/pending)
```

### Our Emulator (WRONG)
```
Bit 0-1: INDEX (correct)
Bit 2:   (not set — ADPBUSY missing)
Bit 3:   DRQ (we use bit 3 for data ready — WRONG, should be PRMEMPTY)
Bit 4:   (not set — PRMWRDY missing)
Bit 5:   RSLRRDY (correct)
Bit 6:   PRMWRDY (we hardcode to 1 — WRONG bit position, should be bit 4)
Bit 7:   (not set — BUSYSTS missing)
```

### What Needs to Happen
- Bit 3 = `PRMEMPTY` (param FIFO empty, NOT data ready)
- Bit 4 = `PRMWRDY` (param FIFO not full)
- Bit 5 = `RSLRRDY` (response FIFO has data)
- Bit 6 = `DRQSTS` (data FIFO ready for DMA)
- Bit 7 = `BUSYSTS` (command is pending)
- `PRMEMPTY` should be set when `cdrom_param_pos == 0`
- `BUSYSTS` should be set when a command is being processed (between BeginCommand and EndCommand)
- `DRQSTS` should reflect whether the data buffer is ready for reading via DMA

### Impact
The game reads 0x1F801800 and checks specific bits to determine if the CD-ROM is ready to accept commands, has response data, or has data available. With the wrong bit layout, the game may:
- Think the param FIFO is full when it's empty (or vice versa)
- Miss response-ready signals
- Never see the data-ready bit, preventing it from issuing ReadN

---

## 2. Response FIFO vs Data FIFO — NOT SEPARATED

### DuckStation (CORRECT)
- **Offset 1 (0x1F801801)**: Always reads from the **response FIFO** (command responses like status byte, position data, etc.)
- **Offset 2 (0x1F801802)**: Always reads from the **data FIFO** (sector data, 2048 bytes per sector)
- These are **two separate FIFOs** with independent positions

### Our Emulator (WRONG)
- **0x1F801801**: Reads from `cdrom_data_fifo[]` (we call it "data FIFO" but use it for BOTH responses AND data)
- **0x1F801802**: Not handled as a separate data read port — it falls through to the generic handler
- We use `cdrom_data_fifo[16]` for command responses (GetStat, GetLocP, etc.) AND try to use it for sector data
- The actual sector data is in `cdrom_data_sector[2048]` but is only accessible via DMA, not via register reads

### What Needs to Happen
- `cdrom_response_fifo[16]` — separate FIFO for command responses (read via 0x1F801801)
- `cdrom_data_sector[2048]` — sector data buffer (read via 0x1F801802 or DMA ch3)
- `cdrom_response_pos` — read position in response FIFO
- `cdrom_data_sector_pos` — read position in data sector
- Reading 0x1F801801 pops from response FIFO, clears RSLRRDY when empty
- Reading 0x1F801802 pops from data sector buffer, clears DRQSTS when exhausted
- `request_register.BFRD` bit controls whether data reads are allowed (DuckStation checks this)

### Impact
The game may try to read command responses from 0x1F801801 and get wrong data because the FIFO is shared. Or it may try to read sector data from 0x1F801802 and get nothing because we don't handle that register.

---

## 3. Interrupt Flag Register (0x1F801803, index=1) — WRONG BITS

### DuckStation (CORRECT)
```
Bits 0-2: Interrupt code (INT1=1, INT2=2, INT3=3, INT4=4, INT5=5)
Bit 3-5: Unknown (always 1 in read, masked by ~INTERRUPT_REGISTER_MASK = 0xF8)
Bit 6:   Always 1 in read (or "active" flag)
Bit 7:   Always 1 in read
```
Reading returns `interrupt_flag_register | ~INTERRUPT_REGISTER_MASK` (i.e., upper bits are always 1).

### Our Emulator (WRONG)
```
Bits 0-2: IRQ code (correct)
Bit 6:   Interrupt active (we set this when cdrom_irq_code != 0)
Bit 7:   Parameter FIFO empty (we use this for PRMEMPTY — WRONG)
```
We don't set the upper bits to 1 on read. The game may mask/shift these bits differently.

### What Needs to Happen
- Reading 0x1F801803 index=1 should return `(cdrom_irq_code & 0x07) | 0xF8` (upper bits always 1)
- Bit 7 should NOT be parameter FIFO empty — that's in the status register (bit 3)
- Writing to 0x1F801803 index=1 with bits 0-2 set should ACK/clear those interrupt codes
- Bit 6 in the write value should clear the parameter FIFO

### Impact
The game reads this register to check the interrupt code. If the upper bits are wrong, it may misinterpret the interrupt type or think no interrupt is pending.

---

## 4. Command Processing — NO ASYNC ACK DELAY

### DuckStation (CORRECT)
1. Game writes command byte to 0x1F801801 (index=0)
2. `BeginCommand()` sets `BUSYSTS=1`, schedules command execution after a delay (80000 ticks for Init, ~2000-10000 for others)
3. After delay, `ExecuteCommand()` runs: pushes response to response FIFO, sets interrupt code
4. `EndCommand()` clears `BUSYSTS`, clears param FIFO
5. Game reads response from 0x1F801801, reads interrupt code from 0x1F801803
6. Game writes to 0x1F801803 to ACK the interrupt

### Our Emulator (WRONG)
1. Game writes command byte to 0x1F801801 (index=0)
2. We **immediately** process the command, set response data, set `cdrom_irq_code` and `cdrom_irq_delay=100`
3. After 100 instruction ticks, the IRQ fires
4. No `BUSYSTS` bit is ever set — the game never sees "command in progress"

### What Needs to Happen
- Add a `cdrom_command_pending` flag and `cdrom_command` variable
- When a command is written, set `BUSYSTS=1`, store the command, schedule execution after a delay
- After the delay, execute the command (push response, set interrupt)
- Clear `BUSYSTS` and param FIFO after execution
- The delay should be realistic (not just 100 instructions — DuckStation uses 2000-80000 ticks based on command)

### Impact
Without `BUSYSTS`, the game may try to send a new command while the previous one is still being processed, causing state corruption. Some games poll `BUSYSTS` before sending commands.

---

## 5. Setloc — BCD Validation Missing, No setloc_pending Flag

### DuckStation (CORRECT)
- Validates BCD format (nibbles 0-9, seconds < 0x60, frames < 0x75)
- Stores position in `setloc_position` and sets `setloc_pending = true`
- The actual seek happens when ReadN/ReadS/SeekL/SeekP is issued
- Returns ACK + secondary status via `SendACKAndStat()`

### Our Emulator (WRONG)
- No BCD validation
- Immediately converts BCD to LBA and stores in `cdrom_cur_lba`
- No `setloc_pending` flag — the LBA is set immediately
- Response is just `0x00` instead of the secondary status byte

### What Needs to Happen
- Validate BCD parameters
- Store the setloc position separately from the current read position
- Set a `setloc_pending` flag
- Apply the setloc position when ReadN/ReadS/SeekL/SeekP is issued (via a seek operation)
- Response byte should be the **secondary status register** (motor on, seeking, etc.), not just 0x00

### Impact
The game may send Setloc and then check the response to confirm the seek was accepted. If the response is wrong, it may abort the read sequence.

---

## 6. Secondary Status Register — NOT IMPLEMENTED

### DuckStation (CORRECT)
Has a `SecondaryStatusRegister` with:
```
Bit 0: error
Bit 1: motor_on
Bit 2: seek_error
Bit 3: shell_open
Bit 4: reading (currently reading data)
Bit 5: seeking
Bit 6: playing (playing CDDA)
Bit 7: focus (TOC read)
```
This is returned as the first byte of most command responses (GetStat, Setloc ACK, ReadN ACK, etc.)

### Our Emulator (WRONG)
- We return hardcoded `0x02` (motor on) for GetStat
- We return `0x00` for Setloc, ReadN, ReadS, Pause ACKs
- No `secondary_status` variable exists
- No tracking of seeking, reading, shell_open, focus states

### What Needs to Happen
- Add `cdrom_secondary_status` byte
- Set `motor_on` when CdInit succeeds
- Set `reading` when ReadN/ReadS is active
- Set `seeking` during seek operations
- Return `cdrom_secondary_status` as the first byte of all command responses

### Impact
The game checks the secondary status to determine if the CD-ROM is ready, if the motor is on, if it's currently reading, etc. Without accurate status, the game may think the drive isn't ready and never issue read commands.

---

## 7. Request Register (0x1F801802, index=0) — NOT PROPERLY HANDLED

### DuckStation (CORRECT)
```
Bit 0: SMEN (sound map enable)
Bit 1: BFWR (buffer write enable)
Bit 5: BFRD (buffer read enable — controls data FIFO reads via 0x1F801802 and DMA)
Bit 6: BFEMPT (buffer empty)
Bit 7: NODATA (no data available)
```
The `BFRD` bit must be set before the game can read sector data from 0x1F801802 or via DMA. When `BFRD` is cleared, the buffer position resets.

### Our Emulator (WRONG)
- Writing to 0x1F801802 index=0 is treated as parameter register (WRONG — that's index=0, offset=1 which maps to reg=0, which is the command register in DuckStation)
- Wait, actually in our code, 0x1F801802 index=0 IS the parameter register. But in DuckStation, the register mapping is: `reg = (index * 3) + (offset - 1)`, so:
  - index=0, offset=1 → reg=0 (command)
  - index=0, offset=2 → reg=1 (parameter)
  - index=0, offset=3 → reg=2 (request register)
  - index=1, offset=1 → reg=3 (sound map data)
  - index=1, offset=2 → reg=4 (interrupt enable)
  - index=1, offset=3 → reg=5 (interrupt flag)

### UNKNOWN
Our register mapping may be wrong. We treat:
- 0x1F801801 index=0: command register (matches DuckStation reg=0)
- 0x1F801802 index=0: parameter register (matches DuckStation reg=1)
- 0x1F801803 index=0: request register (matches DuckStation reg=2)
- 0x1F801803 index=1: interrupt flag (matches DuckStation reg=5)

This seems correct for the basic mapping. But we don't handle the `BFRD` bit in the request register at all. The game needs to set `BFRD` before reading data, and we need to check it before serving data.

---

## 8. DMA Channel 3 — No BFRD Check, No Proper Buffer Management

### DuckStation (CORRECT)
- DMA reads from the sector buffer only if `request_register.BFRD` is set
- Tracks `sector_buffers[]` with position and size
- DMA reads advance the buffer position
- When buffer is exhausted, `CheckForSectorBufferReadComplete()` fires

### Our Emulator (WRONG)
- DMA ch3 triggers and reads from `cdrom_data_sector` or falls back to direct `read_cd_sector()`
- No `BFRD` check
- No proper buffer position tracking for DMA reads
- The DMA can read even when no data is ready (fallback path)

### What Needs to Happen
- Only allow DMA read when `BFRD` is set and `cdrom_data_ready` is true
- Track read position properly
- When all data is consumed, clear `BFRD` and `DRQSTS`
- Fire an interrupt or event when the buffer is fully consumed

---

## 9. Interrupt Acknowledgment — Incomplete

### DuckStation (CORRECT)
- Writing to 0x1F801803 index=1 with bits 0-2 set clears those interrupt flags
- When interrupt flag register becomes 0, the IRQ line is deasserted
- If there's a pending async interrupt, it's delivered after ACK
- Bit 6 in the write value clears the parameter FIFO

### Our Emulator (PARTIALLY CORRECT)
- We clear `intc_stat &= ~0x04` and `cdrom_irq_code = 0` when writing to 0x1F801803 index=1
- We clear param FIFO on bit 7 (should be bit 6)
- No pending async interrupt delivery

### What Needs to Happen
- Bit 6 (not bit 7) should clear the parameter FIFO on write to interrupt flag register
- After clearing, check for pending async interrupts and deliver them
- Deassert the IRQ line when interrupt flag is 0

---

## 10. CD-ROM Event Delivery — Missing Event Class for Game's CdReady

### Current State
- `handle_exception` delivers CD-ROM interrupt to `0xF2000002` (BIOS internal) and `0xF0000009` (game's CdReady event)
- But the game opens its event with class `0xF0000009` and spec `0x20`
- The `deliver_event` function uses `compute_handle` to find the event handle

### UNKNOWN
- Is `compute_handle(0xF0000009, 0x20)` returning the correct handle?
- The game's event handle is `0x0509` — does `compute_handle` produce this?
- Is the event status being set to `EvStALREADY` correctly?
- Is `TestEvent` or `WaitEvent` consuming the event correctly?

---

## 11. Missing Commands

### Commands We Don't Handle
- `0x0D` (GetTD) — partially handled, response may be wrong
- `0x0E` (Setmode) — handled but response is wrong (should return secondary status)
- `0x10` (GetID) — we return a hardcoded SCEI ID, but the response format may be wrong (should be 8 bytes + INT2)
- `0x15` (SeekL) — NOT implemented
- `0x16` (SeekP) — NOT implemented
- `0x19` (Test) — NOT implemented (various subcommands for region, version, etc.)
- `0x1A` (GetID) — second response not implemented
- `0x1B` (ReadS) — implemented but may need seek-then-read flow
- `0x1C` (Reset) — NOT implemented
- `0x1D` (GetQ) — partially handled
- `0x1E` (Init) — NOT implemented as a CD-ROM command (only as BIOS call)
- `0x1F` (GetQ) — NOT implemented

### Impact
The game may issue Test commands to check the CD-ROM version/region before proceeding. Missing SeekL/SeekP prevents proper seek operations before reading.

---

## 12. Seek Operation — NOT Implemented

### DuckStation (CORRECT)
- Setloc sets a pending position
- ReadN/ReadS triggers a seek to the setloc position
- Seek takes time (several thousand ticks)
- After seek completes, reading begins
- `secondary_status.seeking` is set during seek

### Our Emulator (WRONG)
- Setloc immediately sets `cdrom_cur_lba`
- ReadN immediately starts reading from `cdrom_cur_lba`
- No seek delay or seek state
- No `setloc_pending` flag

### What Needs to Happen
- Setloc stores position in `setloc_minute/second/frame` and sets `setloc_pending = true`
- ReadN/ReadS checks `setloc_pending` and begins a seek operation
- During seek, `secondary_status.seeking = 1`
- After seek delay, `cdrom_cur_lba` is updated and reading begins

---

## 13. No ADPCM/XA Audio Handling

### UNKNOWN
- The game may use XA-ADPCM audio streaming from CD-ROM
- We have no XA decoder or audio FIFO
- For a JRPG, XA audio may be used for voice clips or background music
- This may not block game progression but will cause missing audio

---

## 14. Timing — Sector Delivery Rate

### DuckStation (CORRECT)
- Single speed: 75 sectors/second = ~4,500,000 ticks/sector (at 33.8MHz)
- Double speed: 150 sectors/second = ~2,250,000 ticks/sector
- Uses actual system clock ticks, not instruction counts

### Our Emulator (WRONG)
- `cdrom_sector_delay_max = 20000` instructions per sector
- At ~400K instructions per VBlank (60Hz), this gives ~12 sectors per VBlank
- Real PSX at 1x: 75 sectors/sec = 1.25 sectors per VBlank
- Our sector delivery is ~10x too fast

### What Needs to Happen
- Use actual system clock ticks, not instruction counts
- Or calibrate: 1 VBlank = 1/60 sec, 1x = 75 sectors/sec, so 1.25 sectors per VBlank
- At 400K instr/VBlank, that's ~320K instructions per sector at 1x
- At 2x: ~160K instructions per sector

### Impact
Too-fast sector delivery may cause the game to process data before it's ready, or miss timing-dependent events.

---

## 15. Game's CD-ROM Polling Loop — Unknown Conditions

### UNKNOWN
The game's polling loop at ~0x80096788-0x80096790 (from telemetry):
```
0x80096788: lw $v0, 0x10($sp)    # Load counter from stack
0x80096790: addiu $v0, $v0, -1   # Decrement counter
0x800967E0: bne $v0, $zero, ...  # Loop if counter != 0
```
The counter starts at 0x787F (30847) and decrements. This appears to be a timeout loop.

### Questions for Gemini
- What is the game checking in this loop? Is it polling a memory-mapped CD-ROM status, or a BIOS event flag?
- What happens when the counter reaches 0? Does it retry, error out, or proceed?
- Is this loop waiting for the CD-ROM loading thread to complete, or for a specific CD-ROM interrupt?
- What memory address is it reading to check CD-ROM status (if any)?

---

## 16. BIOS CdInit (B:0x5B / A:0x60) — Event Setup

### Current State
- Opens event class `0xF2000002` spec `0x02` (BIOS internal CD-ROM event)
- Enables `intc_mask |= 0x04` and `cp0_status |= 0x400`
- Sets `cdrom_int_enable = 0x1F`

### UNKNOWN
- Does the game also open its own event (class `0xF0000009`, spec `0x20`) separately, or does CdInit do it?
- The game's event handle is `0x0509` — is this from `OpenEvent(0xF0000009, 0x20, ...)` or from `compute_handle`?
- Should CdInit also open the game's CdReady event?
- What is the relationship between the BIOS internal event and the game's event?

---

## 17. Thread Bootstrap — Chicken-and-Egg Problem

### Current State
- Game calls `OpenTh` with entry=0x800D9E80 (in HBD data zone, beyond EXE load range)
- Thread entry is zero-filled because HBD data hasn't been loaded yet
- HBD data can only be loaded by the CD-ROM loading thread (chicken-and-egg)
- Workaround: "Bubblegum" stub at 0x800D9E80 that sets CD-ready flags and calls ChangeTh(0)

### UNKNOWN
- What HBD sector(s) contain the thread code at 0x800D9E80?
- How does the game map HBD sectors to RAM addresses?
- Is the pointer table at EXE offset 0x4184 used for this mapping?
- The pointer table entries all point to 0x8012xxxx, NOT 0x800D9E80 — so how does 0x800D9E80 get populated?
- Is there a second-stage loader in the EXE that loads thread code from HBD?
- What BIOS calls does the thread make (CdRead, CdReadSync, etc.)?

---

## 18. Memory Card / Save Functionality

### Current State
- B-table has 10 memory card functions implemented (HLE stubs)
- `_card_info`, `_card_load`, `_card_auto`, `_card_read`, `_card_write`, etc.
- No actual memory card file or persistence

### UNKNOWN
- Does the game attempt to format or check memory cards during boot?
- Does the game require a memory card to be present to proceed past the title screen?
- What memory card protocol does the game use (BIOS calls vs direct register access)?
- Do we need actual memory card storage for the game to save?

---

## 19. GPU / Display — Can We See the Game?

### Current State
- GPU commands are HLE'd (GPU_cw, GPU_cwb, GPU_sendPackets, GPU_sync, etc.)
- No actual framebuffer rendering or display output
- No VRAM emulation
- Game uses BIOS GPU functions, not direct register access

### UNKNOWN
- Can we add a basic framebuffer dump to verify the game is rendering?
- Does the game require GPU ready/done signals to proceed?
- Is the GPU status register (0x1F801814) properly emulated?
- Does the game check GPU DMA completion before proceeding?

---

## Summary: Critical Path to "Playable"

### Must Fix (Game Won't Progress Without These)
1. **Status register bit layout** (Section 1) — game can't read CD-ROM status correctly
2. **Separate response/data FIFOs** (Section 2) — game can't read command responses or sector data
3. **Secondary status register** (Section 6) — game can't determine drive state
4. **Setloc + seek flow** (Sections 5, 12) — game can't position the read head
5. **Interrupt flag register bits** (Section 3) — game can't properly ACK interrupts
6. **Command async delay + BUSYSTS** (Section 4) — game may spam commands

### Should Fix (May Cause Issues)
7. **Request register BFRD handling** (Section 7) — data reads need proper gating
8. **DMA ch3 BFRD check** (Section 8) — DMA needs to respect buffer state
9. **Interrupt acknowledgment** (Section 9) — proper ACK flow
10. **Sector delivery timing** (Section 14) — too fast may cause sync issues
11. **Missing commands** (Section 11) — Test, SeekL, SeekP, Init may be needed

### Nice to Have (For Full Playability)
12. **Memory card persistence** (Section 18) — for saving
13. **GPU framebuffer output** (Section 19) — for visual verification
14. **XA-ADPCM audio** (Section 13) — for audio

### Need External Help (Gemini)
15. **Game polling loop analysis** (Section 15) — what is the game waiting for?
16. **BIOS event relationship** (Section 16) — how do BIOS and game events interact?
17. **Thread bootstrap mapping** (Section 17) — how does HBD data get loaded?
