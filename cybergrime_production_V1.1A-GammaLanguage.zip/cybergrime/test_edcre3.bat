@echo off
del "..\dq4_reverse_test.bin" "..\dq4_reverse_test.cue" 2>nul
"..\edcre\edcre-v1.1.0-windows-x86_64-static\edcre.exe" "..\dq4_reverse_test.cue"
echo EXITCODE:%errorlevel%
