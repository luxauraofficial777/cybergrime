#!/usr/bin/env python3
"""Find STR/FMV sector ranges on DW7 disc by scanning submode bytes."""
import struct

DW7_PATH = r"C:\LuxAura\VoidWalkers_Project\DQLOSTTRANSLATION\DW7D1\DW7D1.bin"
FRANK_PATH = r"C:\LuxAura\VoidWalkers_Project\DQLOSTTRANSLATION\dq4_frankenstein_v100_ds.bin"

with open(DW7_PATH, 'rb') as f:
    dw7 = f.read()

dw7_sectors = len(dw7) // 2352
print(f"DW7 disc: {dw7_sectors} sectors ({len(dw7)/1024/1024:.1f} MB)")

# Scan all sectors for STR (REAL-TIME) submode flag (bit 6 = 0x40)
# STR sectors have submode with 0x40 set
str_ranges = []
in_str = False
start_lba = 0

for lba in range(dw7_sectors):
    off = lba * 2352 + 24
    if off + 20 > len(dw7):
        break
    submode = dw7[off + 18]
    is_str = bool(submode & 0x40)  # REAL-TIME flag
    
    if is_str and not in_str:
        in_str = True
        start_lba = lba
    elif not is_str and in_str:
        in_str = False
        end_lba = lba - 1
        count = end_lba - start_lba + 1
        str_ranges.append((start_lba, end_lba, count))
        if count >= 10:  # Only report significant ranges
            print(f"  STR range: LBA {start_lba}-{end_lba} ({count} sectors, {count*2352/1024/1024:.2f} MB)")

if in_str:
    end_lba = dw7_sectors - 1
    count = end_lba - start_lba + 1
    str_ranges.append((start_lba, end_lba, count))
    print(f"  STR range: LBA {start_lba}-{end_lba} ({count} sectors, {count*2352/1024/1024:.2f} MB)")

print(f"\nTotal STR ranges: {len(str_ranges)}")
print(f"\nSignificant STR ranges (>= 10 sectors):")
for start, end, count in str_ranges:
    if count >= 10:
        # Check what's at the start and end
        off_start = start * 2352 + 24
        off_end = end * 2352 + 24
        data_start = dw7[off_start:off_start+16]
        data_end = dw7[off_end:off_end+16]
        print(f"  LBA {start:6d}-{end:6d} ({count:6d} sectors, {count*2352/1024/1024:.2f} MB)")
        print(f"    Start data: {data_start.hex()}")
        print(f"    End data:   {data_end.hex()}")

# Now check: which of these ranges overlap with the Frankenstein HBD (LBA 356+)?
print(f"\n{'='*60}")
print(f"  Overlap with Frankenstein disc")
print(f"{'='*60}")
with open(FRANK_PATH, 'rb') as f:
    frank = f.read()

frank_sectors = len(frank) // 2352
print(f"Frankenstein: {frank_sectors} sectors ({len(frank)/1024/1024:.1f} MB)")
print(f"Frank HBD: LBA 356 - {frank_sectors}")

for start, end, count in str_ranges:
    if count < 10:
        continue
    # Check if this range is within the Frankenstein disc
    if end < frank_sectors:
        # Check first sector on Frankenstein
        frank_off = start * 2352 + 24
        frank_data = frank[frank_off:frank_off+16]
        dw7_data = dw7[start * 2352 + 24 : start * 2352 + 24 + 16]
        match = "MATCH" if frank_data == dw7_data else "DIFF (needs copy)"
        print(f"  LBA {start:6d}-{end:6d} ({count:6d} sectors): {match}")
    else:
        print(f"  LBA {start:6d}-{end:6d} ({count:6d} sectors): BEYOND Frank disc")
