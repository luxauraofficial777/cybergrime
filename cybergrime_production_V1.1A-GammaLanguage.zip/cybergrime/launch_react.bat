@echo off
REM ============================================================================
REM launch_react.bat — Launch emulator + ReAct debugger concurrently
REM ============================================================================
REM Starts the emulator with --live-instrument and immediately launches
REM the Python ReAct debugger sidecar. The debugger sets breakpoints
REM via the named pipe (SET_BREAKPOINT commands) so they're active
REM before the BSS clear loop executes.
REM
REM Usage:
REM   launch_react.bat <disc.bin> [max_instrs] [mode]
REM ============================================================================

setlocal

set DISC=%~1
if "%DISC%"=="" set DISC=..\dq4_frankenstein_v40a.bin
set MAX_INSTRS=%~2
if "%MAX_INSTRS%"=="" set MAX_INSTRS=5000000
set MODE=%~3
if "%MODE%"=="" set MODE=auto

set BASE_DIR=C:\LuxAura\VoidWalkers_Project\DQLOSTTRANSLATION
set CG_DIR=%BASE_DIR%\cybergrime

echo ============================================
echo  ReAct Debugger Launch
echo  Disc: %DISC%
echo  Max Instrs: %MAX_INSTRS%
echo  Mode: %MODE%
echo ============================================
echo.

REM ── Start emulator in background with instrumentation bus ───────────────
echo [1/2] Starting emulator with --live-instrument...
start "CyberGrime Emulator" /D "%CG_DIR%" ^
    cmd /c "psx_agent_runner.exe %DISC% react_live %MAX_INSTRS% telemetry_react_live.json 0 --live-instrument 10000"

REM ── Wait briefly for pipe to be created ──────────────────────────────────
timeout /t 2 /nobreak >nul

REM ── Start ReAct debugger (foreground) ────────────────────────────────────
echo [2/2] Starting ReAct debugger...
python "%CG_DIR%\react_debugger.py" ^
    --pipe \\.\pipe\cybergrime_live ^
    --constraints "%CG_DIR%\constraint_map.json" ^
    --golden "%CG_DIR%\golden_state.json" ^
    --max-attempts 5 ^
    --output "%BASE_DIR%\react_debug_log.json"

echo.
echo ReAct debugger exited. Check react_debug_log.json for results.
echo Emulator may still be running — close its window manually.

endlocal
