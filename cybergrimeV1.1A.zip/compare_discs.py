#!/usr/bin/env python3
"""Compare DQ4 Native, DW7 Native, and DQ4 Frankenstein discs.
Extracts EXE headers, disassembles key code sections, and compares HBD layouts.
"""
import struct
import sys
import os
from pathlib import Path

# Capstone for MIPS disassembly
from capstone import Cs, CS_ARCH_MIPS, CS_MODE_MIPS32, CS_MODE_LITTLE_ENDIAN

# ─── Disc Images ───
DISCS = {
    "DQ4_JP": r"c:\LuxAura\VoidWalkers_Project\DQLOSTTRANSLATION\Dragon Quest IV - Michibikareshi Mono Tachi (Japan).bin",
    "DW7_US": r"c:\LuxAura\VoidWalkers_Project\DQLOSTTRANSLATION\DW7D1\DW7D1.bin",
    "DQ4_Frank_v41": r"c:\LuxAura\VoidWalkers_Project\DQLOSTTRANSLATION\dq4_frankenstein_v41.bin",
    "DQ4_Frank_v100": r"c:\LuxAura\VoidWalkers_Project\DQLOSTTRANSLATION\dq4_frankenstein_v100.bin",
}

# Key addresses to disassemble (RAM addresses)
KEY_ADDRS = {
    "main_loop_0x80072394": 0x80072394,
    "vsync_wait_0x80099F40": 0x80099F40,
    "cd_init_caller_0x80095380": 0x80095380,
    "thread_create_0x80072058": 0x80072058,
    "hook_entry_0x8009A1AC": 0x8009A1AC,
    "vblank_handler_0x8009A3CC": 0x8009A3CC,
    "cdready_check_0x8009A108": 0x8009A108,
    "wait_event_0x800976D8": 0x800976D8,
}

def read_sector_raw(data, lba, sector_size=2352):
    """Read a raw sector from disc data."""
    offset = lba * sector_size
    if offset + sector_size > len(data):
        return None
    return data[offset:offset + sector_size]

def extract_sector_data(raw_sector):
    """Extract 2048-byte data payload from a raw 2352-byte sector."""
    # Mode 2 Form 1: sync(12) + header(4) + subheader(8) + data(2048) + edc(4) + ecc(276)
    # Mode 1: sync(12) + header(4) + data(2048) + edc(4) + ecc(276)
    # Data starts at offset 16 for Mode 1, offset 24 for Mode 2 Form 1
    if len(raw_sector) < 24:
        return None
    mode = raw_sector[0x0F]  # Mode byte at offset 15 (after 12-byte sync + 3-byte addr)
    if mode == 1:
        return raw_sector[16:16+2048]
    elif mode == 2:
        # Check subheader for Form 1 vs Form 2
        submode = raw_sector[19]  # subheader byte 3
        if submode & 0x20:  # Form 2
            return raw_sector[24:24+2328]
        else:  # Form 1
            return raw_sector[24:24+2048]
    else:
        return raw_sector[16:16+2048]

def find_system_cnf(data, sector_size=2352):
    """Find SYSTEM.CNF by scanning the ISO9660 directory."""
    # PVD is at LBA 16
    pvd_sector = read_sector_raw(data, 16, sector_size)
    if not pvd_sector:
        return None
    pvd_data = extract_sector_data(pvd_sector)
    if not pvd_data or pvd_data[0:1] != b'\x01':
        return None
    
    # Root directory record is at offset 156 in PVD
    root_dr = pvd_data[156:156+34]
    root_lba = struct.unpack_from('<I', root_dr, 2)[0]
    root_size = struct.unpack_from('<I', root_dr, 10)[0]
    
    # Read root directory
    sectors_needed = (root_size + 2047) // 2048
    dir_data = b''
    for i in range(sectors_needed):
        s = read_sector_raw(data, root_lba + i, sector_size)
        if s:
            dir_data += extract_sector_data(s)
    
    # Parse directory records
    offset = 0
    files = []
    while offset < len(dir_data):
        rec_len = dir_data[offset]
        if rec_len == 0:
            # Padding to sector boundary
            offset = (offset // 2048 + 1) * 2048
            if offset >= len(dir_data):
                break
            continue
        if offset + rec_len > len(dir_data):
            break
        
        lba = struct.unpack_from('<I', dir_data, offset + 2)[0]
        size = struct.unpack_from('<I', dir_data, offset + 10)[0]
        name_len = dir_data[offset + 32]
        name = dir_data[offset + 33:offset + 33 + name_len]
        files.append((name.decode('ascii', errors='replace'), lba, size))
        offset += rec_len
    
    return files

def read_file_from_cd(data, lba, size, sector_size=2352):
    """Read a file from CD given its LBA and size."""
    sectors = (size + 2047) // 2048
    result = b''
    for i in range(sectors):
        s = read_sector_raw(data, lba + i, sector_size)
        if s:
            d = extract_sector_data(s)
            if d:
                result += d
    return result[:size]

def parse_exe_header(data):
    """Parse PS-X EXE header."""
    if len(data) < 0x800:
        return None
    magic = data[0:8]
    if magic != b'PS-X EXE':
        return None
    pc0 = struct.unpack_from('<I', data, 0x10)[0]
    gp0 = struct.unpack_from('<I', data, 0x14)[0]
    t_addr = struct.unpack_from('<I', data, 0x18)[0]
    t_size = struct.unpack_from('<I', data, 0x1C)[0]
    s_addr = struct.unpack_from('<I', data, 0x20)[0]
    s_size = struct.unpack_from('<I', data, 0x24)[0]
    s_addr2 = struct.unpack_from('<I', data, 0x30)[0]
    s_size2 = struct.unpack_from('<I', data, 0x34)[0]
    return {
        'magic': magic,
        'pc0': pc0,
        'gp0': gp0,
        't_addr': t_addr,
        't_size': t_size,
        's_addr': s_addr,
        's_size': s_size,
        's_addr2': s_addr2,
        's_size2': s_size2,
    }

def find_boot_exe(data, sector_size=2352):
    """Find and read the boot EXE from SYSTEM.CNF."""
    files = find_system_cnf(data, sector_size)
    if not files:
        return None, None, None
    
    # Find SYSTEM.CNF
    cnf = None
    for name, lba, size in files:
        if name.upper().startswith('SYSTEM.CNF'):
            cnf = (lba, size)
            break
    
    if not cnf:
        return None, None, None
    
    cnf_data = read_file_from_cd(data, cnf[0], cnf[1], sector_size)
    if not cnf_data:
        return None, None, None
    
    # Parse BOOT= line
    boot_path = None
    for line in cnf_data.decode('ascii', errors='replace').split('\n'):
        if line.startswith('BOOT'):
            eq = line.find('=')
            if eq >= 0:
                boot_path = line[eq+1:].strip().lstrip(' \\')
                boot_path = boot_path.split('\r')[0]
                break
    
    if not boot_path:
        return None, None, None
    
    # Find the EXE file in directory
    boot_name = boot_path.replace('\\', '/').split('/')[-1]
    exe_lba = None
    exe_size = None
    for name, lba, size in files:
        if name.upper().startswith(boot_name.upper()):
            exe_lba = lba
            exe_size = size
            break
    
    if not exe_lba:
        return None, None, None
    
    exe_data = read_file_from_cd(data, exe_lba, exe_size, sector_size)
    return exe_data, boot_name, exe_lba

def disassemble_at(exe_data, exe_header, ram_addr, count=40):
    """Disassemble instructions at a RAM address from the EXE."""
    t_addr = exe_header['t_addr']
    code_offset = 0x800  # EXE header size
    
    # Calculate offset within EXE data
    file_offset = ram_addr - t_addr + code_offset
    if file_offset < 0 or file_offset + count * 4 > len(exe_data):
        return f"  (address 0x{ram_addr:08X} outside EXE range)\n"
    
    code_bytes = exe_data[file_offset:file_offset + count * 4]
    
    md = Cs(CS_ARCH_MIPS, CS_MODE_MIPS32 | CS_MODE_LITTLE_ENDIAN)
    md.detail = True
    
    lines = []
    for insn in md.disasm(code_bytes, ram_addr):
        lines.append(f"  0x{insn.address:08X}: {insn.mnemonic:8s} {insn.op_str}")
    
    return '\n'.join(lines) + '\n'

def scan_hbd_in_exe(exe_data, exe_header):
    """Scan EXE for potential HBD pointer tables or load patterns."""
    t_addr = exe_header['t_addr']
    t_size = exe_header['t_size']
    code_start = 0x800
    
    results = []
    
    # Look for pairs of (small_sector, 0x801xxxxx) that could be HBD load table
    for i in range(0, min(t_size, len(exe_data) - code_start - 8), 4):
        s = struct.unpack_from('<I', exe_data, code_start + i)[0]
        a = struct.unpack_from('<I', exe_data, code_start + i + 4)[0]
        if 0 < s < 200000 and 0x80100000 <= a < 0x80200000:
            ram_addr = t_addr + i
            results.append((i, ram_addr, s, a))
            if len(results) >= 10:
                break
    
    # Also look for CD-ROM register accesses (0x1F801800-0x1F801803)
    cdrom_refs = []
    for i in range(0, min(t_size, len(exe_data) - code_start - 4), 4):
        word = struct.unpack_from('<I', exe_data, code_start + i)[0]
        # lui with 0x1F80 = sw/lw base for hardware regs
        if (word >> 16) == 0x3C1F or (word >> 16) == 0x3C1A:  # lui $k0/$k1, 0x1F80
            ram_addr = t_addr + i
            cdrom_refs.append((i, ram_addr, word))
            if len(cdrom_refs) >= 5:
                break
    
    return results, cdrom_refs

def find_hbd_file(data, sector_size=2352):
    """Find HBD file in the ISO directory."""
    files = find_system_cnf(data, sector_size)
    if not files:
        return None, None
    
    for name, lba, size in files:
        if 'HBD' in name.upper():
            return (name, lba, size)
    return None, None

def compare_discs():
    """Main comparison function."""
    output = []
    output.append("=" * 80)
    output.append("DISC COMPARISON: DQ4 Native vs DW7 Native vs DQ4 Frankenstein")
    output.append("=" * 80)
    
    all_info = {}
    
    for name, path in DISCS.items():
        if not os.path.exists(path):
            output.append(f"\n{'='*60}")
            output.append(f"[{name}] FILE NOT FOUND: {path}")
            continue
        
        output.append(f"\n{'='*60}")
        output.append(f"[{name}] {path}")
        output.append(f"  File size: {os.path.getsize(path) / (1024*1024):.1f} MB")
        
        # Read first 50MB to find directory and EXE
        with open(path, 'rb') as f:
            # Read enough to find PVD, directory, and EXE
            data = f.read(100 * 1024 * 1024)  # 100MB should be enough
        
        # Determine sector size
        sector_size = 2352
        if len(data) > 12:
            sync = data[0:12]
            if sync == b'\x00\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\x00':
                sector_size = 2352
            else:
                sector_size = 2048
        
        output.append(f"  Sector size: {sector_size}")
        
        # Find boot EXE
        exe_data, exe_name, exe_lba = find_boot_exe(data, sector_size)
        if not exe_data:
            output.append(f"  ERROR: Could not find boot EXE")
            continue
        
        hdr = parse_exe_header(exe_data)
        if not hdr:
            output.append(f"  ERROR: Invalid EXE header")
            continue
        
        output.append(f"  Boot EXE: {exe_name} (LBA {exe_lba})")
        output.append(f"  EXE Header:")
        output.append(f"    PC0    = 0x{hdr['pc0']:08X}")
        output.append(f"    GP0    = 0x{hdr['gp0']:08X}")
        output.append(f"    t_addr = 0x{hdr['t_addr']:08X}")
        output.append(f"    t_size = 0x{hdr['t_size']:08X} ({hdr['t_size']} bytes)")
        output.append(f"    s_addr = 0x{hdr['s_addr']:08X}")
        output.append(f"    s_size = 0x{hdr['s_size']:08X}")
        output.append(f"    s_addr2= 0x{hdr['s_addr2']:08X}")
        output.append(f"    s_size2= 0x{hdr['s_size2']:08X}")
        output.append(f"    EXE end= 0x{hdr['t_addr'] + hdr['t_size']:08X}")
        
        # Find HBD file
        hbd_info = find_hbd_file(data, sector_size)
        if hbd_info:
            hbd_name, hbd_lba, hbd_size = hbd_info
            output.append(f"  HBD file: {hbd_name} (LBA {hbd_lba}, {hbd_size} bytes)")
        else:
            output.append(f"  HBD file: NOT FOUND")
            hbd_lba = None
        
        # List all files in directory
        files = find_system_cnf(data, sector_size)
        if files:
            output.append(f"  Directory listing:")
            for fname, flba, fsize in files:
                if not fname.startswith('\x00'):
                    output.append(f"    {fname:30s} LBA={flba:6d} size={fsize:10d}")
        
        # Scan for HBD pointer table patterns
        ptr_results, cdrom_refs = scan_hbd_in_exe(exe_data, hdr)
        output.append(f"  HBD pointer table candidates: {len(ptr_results)}")
        for i, (off, ram, sector, addr) in enumerate(ptr_results[:5]):
            output.append(f"    [{i}] EXE off=0x{off:04X} RAM=0x{ram:08X} sector={sector} -> 0x{addr:08X}")
        
        output.append(f"  CD-ROM register refs: {len(cdrom_refs)}")
        for i, (off, ram, word) in enumerate(cdrom_refs[:3]):
            output.append(f"    [{i}] EXE off=0x{off:04X} RAM=0x{ram:08X} word=0x{word:08X}")
        
        # Disassemble key addresses
        output.append(f"\n  --- Key Code Disassembly ---")
        for label, addr in KEY_ADDRS.items():
            output.append(f"\n  [{label}] (0x{addr:08X}):")
            disasm = disassemble_at(exe_data, hdr, addr, count=30)
            output.append(disasm)
        
        all_info[name] = {
            'header': hdr,
            'exe_data': exe_data,
            'hbd_lba': hbd_lba,
            'exe_name': exe_name,
        }
    
    # ─── Comparison Summary ───
    output.append(f"\n{'='*60}")
    output.append("COMPARISON SUMMARY")
    output.append(f"{'='*60}")
    
    if len(all_info) >= 2:
        names = list(all_info.keys())
        output.append(f"\n  EXE Load Address Comparison:")
        for name in names:
            hdr = all_info[name]['header']
            output.append(f"    {name:20s}: t_addr=0x{hdr['t_addr']:08X} t_size=0x{hdr['t_size']:08X} end=0x{hdr['t_addr']+hdr['t_size']:08X} pc0=0x{hdr['pc0']:08X}")
        
        output.append(f"\n  BSS/Data Section Comparison:")
        for name in names:
            hdr = all_info[name]['header']
            output.append(f"    {name:20s}: s_addr=0x{hdr['s_addr']:08X} s_size=0x{hdr['s_size']:08X} s_addr2=0x{hdr['s_addr2']:08X} s_size2=0x{hdr['s_size2']:08X}")
        
        # Compare code at key addresses
        output.append(f"\n  Code Comparison at Key Addresses:")
        for label, addr in KEY_ADDRS.items():
            output.append(f"\n  [{label}] (0x{addr:08X}):")
            for name in names:
                info = all_info[name]
                output.append(f"    --- {name} ---")
                disasm = disassemble_at(info['exe_data'], info['header'], addr, count=15)
                output.append(disasm)
    
    result = '\n'.join(output)
    print(result)
    
    # Save to file
    out_path = r"c:\LuxAura\VoidWalkers_Project\DQLOSTTRANSLATION\study\disc_comparison.txt"
    os.makedirs(os.path.dirname(out_path), exist_ok=True)
    with open(out_path, 'w', encoding='utf-8') as f:
        f.write(result)
    print(f"\nSaved to {out_path}")

if __name__ == '__main__':
    compare_discs()
