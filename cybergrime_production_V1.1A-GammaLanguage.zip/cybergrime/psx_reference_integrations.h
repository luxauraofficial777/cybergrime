/*
 * psx_reference_integrations.h
 *
 * Integration bridge between the cybergrime PSX emulator and three
 * reference repositories cloned under study/:
 *
 *   1. study/PSoXide/         — Rust PS1 emulator (GPL-2.0-or-later)
 *   2. study/PSn00bSDK/       — Open PS1 SDK (MPL-2.0)
 *   3. study/PSn00b-Debugger/ — Hardware debugger (GPL-3.0)
 *
 * This header provides:
 *   - A standalone MIPS R3000A disassembler (adapted from PSn00b-Debugger)
 *   - BIOS syscall table constants (from PSn00bSDK libpsn00b/psxapi)
 *   - CD-ROM command/timing constants (from PSoXide emu/crates/emulator-core)
 *   - Thread/TCB structure layout (from PSn00bSDK psxapi.h)
 *
 * Usage: #include "psx_reference_integrations.h" in debug/diagnostic code.
 */

#pragma once

#include <cstdint>
#include <cstdio>
#include <cstring>

// ===========================================================================
// 1. BIOS Syscall Table Constants (from PSn00bSDK libpsn00b/psxapi/stubs.json)
// ===========================================================================

namespace bios_syscalls {

// A-table (entry point 0xA0)
enum A_table : uint8_t {
    A_open        = 0x00,
    A_lseek       = 0x01,
    A_read        = 0x02,
    A_write       = 0x03,
    A_close       = 0x04,
    A_ioctl       = 0x05,
    A_isatty      = 0x07,
    A_getc        = 0x08,
    A_putc        = 0x09,
    A_b_setjmp    = 0x13,
    A_b_longjmp   = 0x14,
    A_b_InitHeap  = 0x39,
    A_getchar     = 0x3B,
    A_putchar     = 0x3C,
    A_puts        = 0x3E,
    A_printf      = 0x3F,
    A_Exec        = 0x43,
    A_FlushCache  = 0x44,
    A_LoadExec    = 0x51,
    A_bu_init     = 0x70,
    A_96_init     = 0x71,
    A_96_remove   = 0x72,
    A_SetConf     = 0x9C,
    A_GetConf     = 0x9D,
    A_SetMem      = 0x9F,
    A_boot        = 0xA0,
    A_GetSystemInfo = 0xB4,
};

// B-table (entry point 0xB0)
enum B_table : uint8_t {
    B_alloc_kernel_memory = 0x00,
    B_free_kernel_memory  = 0x01,
    B_SetRCnt    = 0x02,
    B_GetRCnt    = 0x03,
    B_StartRCnt  = 0x04,
    B_StopRCnt   = 0x05,
    B_ResetRCnt  = 0x06,
    B_DeliverEvent = 0x07,
    B_OpenEvent  = 0x08,
    B_CloseEvent = 0x09,
    B_WaitEvent  = 0x0A,
    B_TestEvent  = 0x0B,
    B_EnableEvent = 0x0C,
    B_DisableEvent = 0x0D,
    B_OpenTh     = 0x0E,
    B_CloseTh    = 0x0F,
    B_ChangeTh   = 0x10,
    B_InitPAD    = 0x12,
    B_StartPAD   = 0x13,
    B_StopPAD    = 0x14,
    B_ReturnFromException = 0x17,
    B_ResetEntryInt = 0x18,
    B_HookEntryInt  = 0x19,
    B_UnDeliverEvent = 0x20,
    B_cd         = 0x40,
    B_firstfile  = 0x42,
    B_nextfile   = 0x43,
    B_GetC0Table = 0x56,
    B_GetB0Table = 0x57,
    B_ChangeClearPAD = 0x5B,
};

// C-table (entry point 0xC0)
enum C_table : uint8_t {
    C_SysEnqIntRP  = 0x02,
    C_SysDeqIntRP  = 0x03,
    C_InstallExceptionHandlers = 0x07,
    C_SysInitMemory = 0x08,
    C_ChangeClearRCnt = 0x0A,
};

inline const char* A_name(uint8_t func) {
    switch (func) {
        case A_open:       return "open";
        case A_lseek:      return "lseek";
        case A_read:       return "read";
        case A_write:      return "write";
        case A_close:      return "close";
        case A_ioctl:      return "ioctl";
        case A_isatty:     return "isatty";
        case A_getc:       return "getc";
        case A_putc:       return "putc";
        case A_b_setjmp:   return "b_setjmp";
        case A_b_longjmp:  return "b_longjmp";
        case A_b_InitHeap: return "b_InitHeap";
        case A_getchar:    return "getchar";
        case A_putchar:    return "putchar";
        case A_puts:       return "puts";
        case A_printf:     return "printf";
        case A_Exec:       return "Exec";
        case A_FlushCache: return "FlushCache";
        case A_LoadExec:   return "LoadExec";
        case A_bu_init:    return "_bu_init";
        case A_96_init:    return "_96_init";
        case A_96_remove:  return "_96_remove";
        case A_SetConf:    return "SetConf";
        case A_GetConf:    return "GetConf";
        case A_SetMem:     return "SetMem";
        case A_boot:       return "_boot";
        case A_GetSystemInfo: return "GetSystemInfo";
        default:           return "A_unknown";
    }
}

inline const char* B_name(uint8_t func) {
    switch (func) {
        case B_alloc_kernel_memory: return "alloc_kernel_memory";
        case B_free_kernel_memory:  return "free_kernel_memory";
        case B_SetRCnt:    return "SetRCnt";
        case B_GetRCnt:    return "GetRCnt";
        case B_StartRCnt:  return "StartRCnt";
        case B_StopRCnt:   return "StopRCnt";
        case B_ResetRCnt:  return "ResetRCnt";
        case B_DeliverEvent: return "DeliverEvent";
        case B_OpenEvent:  return "OpenEvent";
        case B_CloseEvent: return "CloseEvent";
        case B_WaitEvent:  return "WaitEvent";
        case B_TestEvent:  return "TestEvent";
        case B_EnableEvent: return "EnableEvent";
        case B_DisableEvent: return "DisableEvent";
        case B_OpenTh:     return "OpenTh";
        case B_CloseTh:    return "CloseTh";
        case B_ChangeTh:   return "ChangeTh";
        case B_InitPAD:    return "InitPAD";
        case B_StartPAD:   return "StartPAD";
        case B_StopPAD:    return "StopPAD";
        case B_ReturnFromException: return "ReturnFromException";
        case B_ResetEntryInt: return "ResetEntryInt";
        case B_HookEntryInt:  return "HookEntryInt";
        case B_UnDeliverEvent: return "UnDeliverEvent";
        case B_cd:         return "cd";
        case B_firstfile:  return "firstfile";
        case B_nextfile:   return "nextfile";
        case B_GetC0Table: return "GetC0Table";
        case B_GetB0Table: return "GetB0Table";
        case B_ChangeClearPAD: return "ChangeClearPAD";
        default:           return "B_unknown";
    }
}

inline const char* C_name(uint8_t func) {
    switch (func) {
        case C_SysEnqIntRP:  return "SysEnqIntRP";
        case C_SysDeqIntRP:  return "SysDeqIntRP";
        case C_InstallExceptionHandlers: return "InstallExceptionHandlers";
        case C_SysInitMemory: return "SysInitMemory";
        case C_ChangeClearRCnt: return "ChangeClearRCnt";
        default:             return "C_unknown";
    }
}

} // namespace bios_syscalls

// ===========================================================================
// 2. Event Descriptor Constants (from PSn00bSDK psxapi.h)
// ===========================================================================

namespace psx_events {
    constexpr uint32_t DescHW   = 0xF0000000;
    constexpr uint32_t DescEV   = 0xF1000000;
    constexpr uint32_t DescRC   = 0xF2000000;
    constexpr uint32_t DescUEV  = 0xF3000000;
    constexpr uint32_t DescSW   = 0xF4000000;
    constexpr uint32_t DescTH   = 0xFF000000;

    constexpr uint32_t HwVBLANK = DescHW | 0x01;
    constexpr uint32_t HwGPU    = DescHW | 0x02;
    constexpr uint32_t HwCdRom  = DescHW | 0x03;
    constexpr uint32_t HwDMAC   = DescHW | 0x04;
    constexpr uint32_t HwRTC0   = DescHW | 0x05;
    constexpr uint32_t HwRTC1   = DescHW | 0x06;
    constexpr uint32_t HwRTC2   = DescHW | 0x07;
    constexpr uint32_t HwCNTL   = DescHW | 0x08;
    constexpr uint32_t HwSPU    = DescHW | 0x09;
    constexpr uint32_t HwSIO    = DescHW | 0x0B;

    constexpr uint32_t RCntCNT0 = DescRC | 0x00;
    constexpr uint32_t RCntCNT1 = DescRC | 0x01;
    constexpr uint32_t RCntCNT2 = DescRC | 0x02;
    constexpr uint32_t RCntCNT3 = DescRC | 0x03;
}

// ===========================================================================
// 3. CD-ROM Constants (from PSoXide cdrom.rs + PSn00bSDK psxcd.h)
// ===========================================================================

namespace cdrom_constants {
    // CD-ROM MMIO base
    constexpr uint32_t BASE = 0x1F801800;
    constexpr uint32_t END  = 0x1F801804;

    // Status byte bits (PSoXide cdrom.rs::status_bit)
    constexpr uint8_t INDEX_MASK           = 0b00000011;
    constexpr uint8_t ADPCM_BUSY           = 1 << 2;
    constexpr uint8_t PARAM_FIFO_EMPTY     = 1 << 3;
    constexpr uint8_t PARAM_FIFO_NOT_FULL  = 1 << 4;
    constexpr uint8_t RESPONSE_FIFO_NOT_EMPTY = 1 << 5;
    constexpr uint8_t DATA_FIFO_NOT_EMPTY  = 1 << 6;
    constexpr uint8_t TRANSMISSION_BUSY    = 1 << 7;

    // IRQ types (PSoXide cdrom.rs::IrqType)
    enum IrqType : uint8_t {
        IRQ_None       = 0,
        IRQ_DataReady  = 1,
        IRQ_Complete   = 2,
        IRQ_Acknowledge = 3,
        IRQ_DataEnd    = 4,
        IRQ_Error      = 5,
    };

    // Drive status bits (PSoXide cdrom.rs::drive_status_bit)
    constexpr uint8_t STAT_ERROR      = 1 << 0;
    constexpr uint8_t STAT_MOTOR_ON   = 1 << 1;
    constexpr uint8_t STAT_SEEK_ERROR = 1 << 2;  // 0x04
    constexpr uint8_t STAT_ID_ERROR   = 1 << 3;
    constexpr uint8_t STAT_SHELL_OPEN = 1 << 4;
    constexpr uint8_t STAT_READING    = 1 << 5;
    constexpr uint8_t STAT_SEEKING    = 1 << 6;
    constexpr uint8_t STAT_PLAYING    = 1 << 7;

    // CD-ROM commands (PSn00bSDK psxcd.h::CdlCommand)
    enum CdlCommand : uint8_t {
        CdlNop       = 0x00,
        CdlSetloc    = 0x01,
        CdlPlay      = 0x02,
        CdlForward   = 0x03,
        CdlBackward  = 0x04,
        CdlReadN     = 0x06,
        CdlStandby   = 0x07,
        CdlStop      = 0x08,
        CdlPause     = 0x09,
        CdlInit      = 0x0A,
        CdlMute      = 0x0B,
        CdlDemute    = 0x0C,
        CdlSetfilter = 0x0D,
        CdlSetmode   = 0x0E,
        CdlGetparam  = 0x0F,
        CdlGetlocL   = 0x10,
        CdlGetlocP   = 0x11,
        CdlSetsession = 0x12,
        CdlGetTN     = 0x13,
        CdlGetTD     = 0x14,
        CdlSeekL     = 0x15,
        CdlSeekP     = 0x16,
        CdlTest      = 0x19,
        CdlGetID     = 0x1A,
        CdlReadS     = 0x1B,
        CdlReset     = 0x1C,
        CdlGetQ      = 0x1D,
        CdlReadTOC   = 0x1E,
    };

    // Timing constants (PSoXide cdrom.rs::timing — transcribed from PCSX-Redux)
    // PSX clock = 33,868,800 Hz. CD frames = 75/sec.
    // CD_READ_TIME = 33,868,800 / 75 = 451,584 cycles per sector at 1x speed.
    // At 2x speed, steady-state sectors arrive every CD_READ_TIME/2 = 225,792 cycles.
    // The first sector after ReadN/ReadS uses CD_READ_TIME (2x) or CD_READ_TIME*2 (1x).
    constexpr uint64_t CD_READ_TIME = 451584;
    constexpr uint64_t CD_READ_TIME_DOUBLE = CD_READ_TIME / 2;   // 225,792 — steady-state 2x
    constexpr uint64_t CD_READ_TIME_SINGLE = CD_READ_TIME;       // 451,584 — 1x

    // Command response delays (PSoXide cdrom/timing.rs)
    constexpr uint64_t FIRST_RESPONSE_CYCLES = 0x800;            // 2048 — universal ACK delay
    constexpr uint64_t IRQ_RESCHEDULE_CYCLES = 0x100;            // 256 — reschedule when IRQ pending
    constexpr uint64_t GETID_SECOND_RESPONSE_CYCLES = 20480;
    constexpr uint64_t RESET_SECOND_RESPONSE_CYCLES = 4100000;
    constexpr uint64_t SEEK_SECOND_RESPONSE_CYCLES = CD_READ_TIME * 4; // ~1,806,336
    constexpr uint64_t PAUSE_COMPLETE_CYCLES_STANDBY = 7000;
    constexpr uint64_t PAUSE_COMPLETE_CYCLES_ACTIVE = 1000000;

    // FIFO depths
    constexpr int PARAM_FIFO_DEPTH    = 16;
    constexpr int RESPONSE_FIFO_DEPTH = 16;
    constexpr int SECTOR_DATA_SIZE    = 2048;
    constexpr int SECTOR_RAW_SIZE     = 2352;

    // DMA channel for CD-ROM
    constexpr int DMA_CD = 3;
}

// ===========================================================================
// 4. Thread Control Block Layout (from PSn00bSDK psxapi.h TCB)
// ===========================================================================

namespace psx_threads {
    // TCB register layout matches PSn00bSDK psxapi.h struct _TCB
    // 37 regs (r0-r31 + hi + lo + cop0r14 + cop0r12 + cop0r13) + 9 reserved
    constexpr int TCB_REG_COUNT = 37;
    constexpr int TCB_RESERVED  = 9;
    constexpr int TCB_SIZE      = (TCB_REG_COUNT + TCB_RESERVED) * 4 + 8; // status + mode + regs + reserved

    // Register indices within TCB.reg[37]
    enum TcbReg : int {
        REG_zero = 0,  REG_at = 1,
        REG_v0 = 2,    REG_v1 = 3,
        REG_a0 = 4,    REG_a1 = 5,  REG_a2 = 6,  REG_a3 = 7,
        REG_t0 = 8,    REG_t1 = 9,  REG_t2 = 10, REG_t3 = 11,
        REG_t4 = 12,   REG_t5 = 13, REG_t6 = 14, REG_t7 = 15,
        REG_s0 = 16,   REG_s1 = 17, REG_s2 = 18, REG_s3 = 19,
        REG_s4 = 20,   REG_s5 = 21, REG_s6 = 22, REG_s7 = 23,
        REG_t8 = 24,   REG_t9 = 25, REG_k0 = 26, REG_k1 = 27,
        REG_gp = 28,   REG_sp = 29, REG_fp = 30, REG_ra = 31,
        REG_cop0r14 = 32,  // EPC
        REG_hi = 33,   REG_lo = 34,
        REG_cop0r12 = 35,  // Status
        REG_cop0r13 = 36,  // Cause
    };
}

// ===========================================================================
// 5. MIPS R3000A Disassembler (adapted from PSn00b-Debugger mips_disassembler)
// ===========================================================================

namespace mips_disasm {

// Register name table (from PSn00b-Debugger widgets/mips_disassembler.cpp)
static const char* reg_names[] = {
    "r0","at","v0","v1",
    "a0","a1","a2","a3",
    "t0","t1","t2","t3",
    "t4","t5","t6","t7",
    "s0","s1","s2","s3",
    "s4","s5","s6","s7",
    "t8","t9","k0","k1",
    "gp","sp","fp","ra"
};

// Instruction field extractors
inline uint32_t opcode1(uint32_t op)  { return (op >> 26) & 0x3F; }
inline uint32_t opcode2(uint32_t op)  { return op & 0x3F; }
inline uint32_t reg_s(uint32_t op)    { return (op >> 21) & 0x1F; }
inline uint32_t reg_t(uint32_t op)    { return (op >> 16) & 0x1F; }
inline uint32_t reg_d(uint32_t op)    { return (op >> 11) & 0x1F; }
inline uint32_t imm5(uint32_t op)     { return (op >> 6) & 0x1F; }
inline uint32_t imm16(uint32_t op)    { return op & 0xFFFF; }
inline uint32_t imm20(uint32_t op)    { return (op >> 6) & 0x1FFFFF; }
inline uint32_t imm26(uint32_t op)    { return op & 0x3FFFFFF; }
inline int32_t  simm16(uint32_t op)   { return (int32_t)(int16_t)(op & 0xFFFF); }
inline uint32_t target26(uint32_t op, uint32_t pc) {
    return ((pc + 4) & 0xF0000000) | (imm26(op) << 2);
}

// Get jump target address for a branch/jump instruction
inline uint32_t jump_target(uint32_t op, uint32_t pc) {
    uint32_t op1 = opcode1(op);
    switch (op1) {
        case 0x00: { // SPECIAL
            uint32_t op2 = opcode2(op);
            if (op2 == 0x08 || op2 == 0x09) { // jr, jalr
                return 0; // register indirect — caller must read $rs/$rd
            }
            return pc + 8; // not a jump
        }
        case 0x01: { // REGIMM
            uint32_t rt = reg_t(op);
            if (rt == 0x00 || rt == 0x01 || rt == 0x10 || rt == 0x11) {
                return pc + 4 + (simm16(op) << 2);
            }
            return pc + 8;
        }
        case 0x02: case 0x03: // j, jal
            return target26(op, pc);
        case 0x04: case 0x05: case 0x06: case 0x07: // beq, bne, blez, bgtz
            return pc + 4 + (simm16(op) << 2);
        default:
            return pc + 8;
    }
}

// Decode a single MIPS instruction into a human-readable string
inline void decode(uint32_t op, uint32_t addr, char* output, int max_len) {
    uint32_t op1 = opcode1(op);
    uint32_t op2 = opcode2(op);
    uint32_t rs = reg_s(op);
    uint32_t rt = reg_t(op);
    uint32_t rd = reg_d(op);
    int32_t  simm = simm16(op);
    uint32_t uimm = imm16(op);

    auto p = [&](const char* fmt, ...) {
        va_list ap;
        va_start(ap, fmt);
        vsnprintf(output, max_len, fmt, ap);
        va_end(ap);
    };

    switch (op1) {
        case 0x00: // SPECIAL
            switch (op2) {
                case 0x00: p("sll     %s,%s,%d", reg_names[rd], reg_names[rt], imm5(op)); break;
                case 0x02: p("srl     %s,%s,%d", reg_names[rd], reg_names[rt], imm5(op)); break;
                case 0x03: p("sra     %s,%s,%d", reg_names[rd], reg_names[rt], imm5(op)); break;
                case 0x04: p("sllv    %s,%s,%s", reg_names[rd], reg_names[rt], reg_names[rs]); break;
                case 0x06: p("srlv    %s,%s,%s", reg_names[rd], reg_names[rt], reg_names[rs]); break;
                case 0x07: p("srav    %s,%s,%s", reg_names[rd], reg_names[rt], reg_names[rs]); break;
                case 0x08: p("jr      %s", reg_names[rs]); break;
                case 0x09: p("jalr    %s,%s", reg_names[rd], reg_names[rs]); break;
                case 0x0C: p("syscall "); break;
                case 0x0D: p("break   "); break;
                case 0x10: p("mfhi    %s", reg_names[rd]); break;
                case 0x11: p("mthi    %s", reg_names[rs]); break;
                case 0x12: p("mflo    %s", reg_names[rd]); break;
                case 0x13: p("mtlo    %s", reg_names[rs]); break;
                case 0x18: p("mult    %s,%s", reg_names[rs], reg_names[rt]); break;
                case 0x19: p("multu   %s,%s", reg_names[rs], reg_names[rt]); break;
                case 0x1A: p("div     %s,%s", reg_names[rs], reg_names[rt]); break;
                case 0x1B: p("divu    %s,%s", reg_names[rs], reg_names[rt]); break;
                case 0x20: p("add     %s,%s,%s", reg_names[rd], reg_names[rs], reg_names[rt]); break;
                case 0x21: p("addu    %s,%s,%s", reg_names[rd], reg_names[rs], reg_names[rt]); break;
                case 0x22: p("sub     %s,%s,%s", reg_names[rd], reg_names[rs], reg_names[rt]); break;
                case 0x23: p("subu    %s,%s,%s", reg_names[rd], reg_names[rs], reg_names[rt]); break;
                case 0x24: p("and     %s,%s,%s", reg_names[rd], reg_names[rs], reg_names[rt]); break;
                case 0x25: p("or      %s,%s,%s", reg_names[rd], reg_names[rs], reg_names[rt]); break;
                case 0x26: p("xor     %s,%s,%s", reg_names[rd], reg_names[rs], reg_names[rt]); break;
                case 0x27: p("nor     %s,%s,%s", reg_names[rd], reg_names[rs], reg_names[rt]); break;
                case 0x2A: p("slt     %s,%s,%s", reg_names[rd], reg_names[rs], reg_names[rt]); break;
                case 0x2B: p("sltu    %s,%s,%s", reg_names[rd], reg_names[rs], reg_names[rt]); break;
                default:   p("special 0x%02x", op2); break;
            }
            break;

        case 0x01: // REGIMM
            switch (rt) {
                case 0x00: p("bltz    %s,0x%08X", reg_names[rs], addr + 4 + (simm << 2)); break;
                case 0x01: p("bgez    %s,0x%08X", reg_names[rs], addr + 4 + (simm << 2)); break;
                case 0x10: p("bltzal  %s,0x%08X", reg_names[rs], addr + 4 + (simm << 2)); break;
                case 0x11: p("bgezal  %s,0x%08X", reg_names[rs], addr + 4 + (simm << 2)); break;
                default:   p("regimm  0x%02x", rt); break;
            }
            break;

        case 0x02: p("j       0x%08X", target26(op, addr)); break;
        case 0x03: p("jal     0x%08X", target26(op, addr)); break;
        case 0x04: p("beq     %s,%s,0x%08X", reg_names[rs], reg_names[rt], addr + 4 + (simm << 2)); break;
        case 0x05: p("bne     %s,%s,0x%08X", reg_names[rs], reg_names[rt], addr + 4 + (simm << 2)); break;
        case 0x06: p("blez    %s,0x%08X", reg_names[rs], addr + 4 + (simm << 2)); break;
        case 0x07: p("bgtz    %s,0x%08X", reg_names[rs], addr + 4 + (simm << 2)); break;
        case 0x08: p("addi    %s,%s,%d", reg_names[rt], reg_names[rs], simm); break;
        case 0x09: p("addiu   %s,%s,%d", reg_names[rt], reg_names[rs], simm); break;
        case 0x0A: p("slti    %s,%s,%d", reg_names[rt], reg_names[rs], simm); break;
        case 0x0B: p("sltiu   %s,%s,%d", reg_names[rt], reg_names[rs], simm); break;
        case 0x0C: p("andi    %s,%s,0x%04X", reg_names[rt], reg_names[rs], uimm); break;
        case 0x0D: p("ori     %s,%s,0x%04X", reg_names[rt], reg_names[rs], uimm); break;
        case 0x0E: p("xori    %s,%s,0x%04X", reg_names[rt], reg_names[rs], uimm); break;
        case 0x0F: p("lui     %s,0x%04X", reg_names[rt], uimm); break;
        case 0x10: p("mfc0    %s,r%d", reg_names[rt], rd); break;
        case 0x12: p("mtc0    %s,r%d", reg_names[rt], rd); break;
        case 0x20: p("lb      %s,%d(%s)", reg_names[rt], simm, reg_names[rs]); break;
        case 0x21: p("lh      %s,%d(%s)", reg_names[rt], simm, reg_names[rs]); break;
        case 0x23: p("lw      %s,%d(%s)", reg_names[rt], simm, reg_names[rs]); break;
        case 0x24: p("lbu     %s,%d(%s)", reg_names[rt], simm, reg_names[rs]); break;
        case 0x25: p("lhu     %s,%d(%s)", reg_names[rt], simm, reg_names[rs]); break;
        case 0x28: p("sb      %s,%d(%s)", reg_names[rt], simm, reg_names[rs]); break;
        case 0x29: p("sh      %s,%d(%s)", reg_names[rt], simm, reg_names[rs]); break;
        case 0x2B: p("sw      %s,%d(%s)", reg_names[rt], simm, reg_names[rs]); break;

        // GTE (cop2) — from PSn00b-Debugger
        case 0x32: p("lwc2    r%d,%d(%s)", rd, simm, reg_names[rs]); break;
        case 0x3A: p("swc2    r%d,%d(%s)", rd, simm, reg_names[rs]); break;
        case 0x36: { // LWC2 alternate encoding
            p("lwc2alt r%d,%d(%s)", rd, simm, reg_names[rs]); break;
        }

        default:
            // Check for COP2 commands (GTE)
            if (op1 == 0x12 && (op & 0x3F) == 0x00) {
                p("mfc2    %s,r%d", reg_names[rt], rd);
            } else if (op1 == 0x16 && (op & 0x3F) == 0x00) {
                p("mtc2    %s,r%d", reg_names[rt], rd);
            } else if (op1 == 0x16 && (op & 0x3F) == 0x02) {
                p("cfc2    %s,r%d", reg_names[rt], rd);
            } else if (op1 == 0x16 && (op & 0x3F) == 0x06) {
                p("ctc2    %s,r%d", reg_names[rt], rd);
            } else if (op1 == 0x16 && (op & 0x3F) == 0x01) {
                // GTE command
                uint32_t cmd = (op >> 20) & 0x1FF;
                uint32_t sf  = (op >> 19) & 1;
                p("gte_cmd  0x%03X%sf", cmd, sf ? "" : "(sf=0)");
            } else {
                p(".word   0x%08X", op);
            }
            break;
    }
}

// Decode and return as a C++ string (convenience wrapper)
#include <string>
inline std::string disasm_str(uint32_t op, uint32_t addr) {
    char buf[128];
    decode(op, addr, buf, sizeof(buf));
    return std::string(buf);
}

} // namespace mips_disasm

// ===========================================================================
// 6. Debug Monitor Protocol Constants (from PSn00b-Debugger monitor/protocol.txt)
// ===========================================================================

namespace debug_protocol {
    // Commands (PC -> console)
    enum Cmd : uint8_t {
        CMD_ping      = 0xD0,
        CMD_info      = 0xD1,
        CMD_pause     = 0xD2,
        CMD_resume    = 0xD3,
        CMD_step      = 0xD4,
        CMD_getregs   = 0xD5,
        CMD_getmem    = 0xD6,
        CMD_getword   = 0xD7,
        CMD_setreg    = 0xD8,
        CMD_setword   = 0xD9,
        CMD_databreak = 0xDA,
        CMD_runto     = 0xDB,
        CMD_linestep  = 0xDC,
        CMD_readgte   = 0xDD,
        CMD_reboot    = 0xDF,
    };

    // Events (console -> PC)
    enum Ev : uint8_t {
        EV_start    = 0xC0,
        EV_pause    = 0xC1,
        EV_except   = 0xC2,
        EV_dbgfail  = 0xC3,
        EV_break    = 0xC4,
    };

    // Errors
    enum Err : uint8_t {
        ERR_ok      = 0xE0,
        ERR_invalid = 0xE1,
        ERR_nocont  = 0xE2,
    };

    // Register block size: 40 x 4-byte words (33 CPU + 6 COP0 + 1 opcode)
    constexpr int REG_BLOCK_WORDS = 40;
    constexpr int REG_BLOCK_BYTES = REG_BLOCK_WORDS * 4;
}
