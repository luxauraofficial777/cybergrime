#!/usr/bin/env python3
"""
Verify DW7 EXE size fits in sectors 24-353 (330 sectors = 675,840 bytes)
and find DQ4 STR/FMV sector ranges with submode analysis.
"""
import struct
import os

DW7_DISC = r"C:\LuxAura\VoidWalkers_Project\DQLOSTTRANSLATION\DW7D1\DW7D1.bin"
DQ4_DISC = r"C:\LuxAura\VoidWalkers_Project\DQLOSTTRANSLATION\Dragon Quest IV - Michibikareshi Mono Tachi (Japan).bin"
SECTOR_SIZE = 2352
USER_OFFSET = 24
USER_SIZE = 2048

def read_exe_header(disc_path, exe_lba=24):
    with open(disc_path, 'rb') as f:
        f.seek(exe_lba * SECTOR_SIZE + USER_OFFSET)
        header = f.read(USER_SIZE)
        if header[:8] != b'PS-X EXE':
            return None
        text_size = struct.unpack_from('<I', header, 0x1C)[0]
        load_addr = struct.unpack_from('<I', header, 0x10)[0]
        pc0 = struct.unpack_from('<I', header, 0x10)[0]
        return {
            'text_size': text_size,
            'load_addr': load_addr,
            'pc0': pc0,
            'total_exe': text_size + 0x800,  # header + text
            'sectors_needed': (text_size + 0x800 + USER_SIZE - 1) // USER_SIZE,
        }

def get_disc_size_sectors(disc_path):
    sz = os.path.getsize(disc_path)
    return sz, sz // SECTOR_SIZE

def find_str_ranges(disc_path, max_sectors=None):
    """Find STR/FMV sectors by checking submode byte for REALTIME/AUDIO-VIDEO flags."""
    sz = os.path.getsize(disc_path)
    total_sectors = sz // SECTOR_SIZE
    if max_sectors:
        total_sectors = min(total_sectors, max_sectors)
    
    ranges = []
    in_str = False
    start_lba = 0
    
    with open(disc_path, 'rb') as f:
        for lba in range(total_sectors):
            f.seek(lba * SECTOR_SIZE + 12)  # Submode byte at offset 12 in sector header
            # Actually, for MODE2 sectors, submode is at offset 12 in the raw sector
            # But the exact position depends on the sector format
            # Let's read the whole sector header (12 bytes sync + 3 bytes MSF + 1 mode + 8 subheader)
            raw = f.read(16)
            if len(raw) < 16:
                break
            
            # MODE2 Form1/Form2: bytes 0-11 = sync, 12-14 = MSF, 15 = mode
            # Then subheader at bytes 16-19 (Form1) or 16-19 (Form2)
            f.seek(lba * SECTOR_SIZE)
            sector_header = f.read(24)
            if len(sector_header) < 24:
                break
            
            mode = sector_header[15]
            if mode != 2:
                if in_str:
                    ranges.append((start_lba, lba - 1, lba - start_lba))
                    in_str = False
                continue
            
            # Subheader bytes at offset 16-19
            submode = sector_header[16]
            # Submode flags:
            # bit 0: End of File
            # bit 1: Real Time
            # bit 2: Form2
            # bit 3: Trigger
            # bit 4: Data
            # bit 5: Audio
            # bit 6: Video
            # bit 7: Audio-Video (STR)
            
            is_realtime = bool(submode & 0x02)
            is_video = bool(submode & 0x40)
            is_av = bool(submode & 0x80)  # Audio-Video interleaved (STR)
            is_data = bool(submode & 0x10)
            
            is_str = is_realtime and (is_video or is_av)
            
            if is_str and not in_str:
                in_str = True
                start_lba = lba
            elif not is_str and in_str:
                ranges.append((start_lba, lba - 1, lba - start_lba))
                in_str = False
    
    if in_str:
        ranges.append((start_lba, total_sectors - 1, total_sectors - start_lba))
    
    return ranges

def lba_to_bcd_msf(lba):
    m = lba // (75 * 60)
    s = (lba // 75) % 60
    f = lba % 75
    return (to_bcd(m), to_bcd(s), to_bcd(f))

def to_bcd(val):
    return ((val // 10) << 4) | (val % 10)

def main():
    print("=" * 70)
    print("  DW7 EXE Size Verification & DQ4 STR Range Analysis")
    print("=" * 70)
    
    # 1. DW7 EXE size
    print("\n[1] DW7 EXE Size Analysis")
    dw7_info = read_exe_header(DW7_DISC, 24)
    if dw7_info:
        print(f"    Text size: 0x{dw7_info['text_size']:X} ({dw7_info['text_size']:,} bytes)")
        print(f"    Total EXE (header+text): {dw7_info['total_exe']:,} bytes")
        print(f"    Sectors needed: {dw7_info['sectors_needed']}")
        print(f"    LBA range: 24 to {24 + dw7_info['sectors_needed'] - 1}")
        available = (354 - 24) * USER_SIZE
        print(f"    Available space (LBA 24-353): {available:,} bytes ({354-24} sectors)")
        print(f"    Fits at LBA 354? {'YES' if dw7_info['total_exe'] <= available else 'NO'}")
        print(f"    Slack: {available - dw7_info['total_exe']:,} bytes")
    
    # 2. DQ4 EXE size (for comparison)
    print("\n[2] DQ4 EXE Size (for comparison)")
    dq4_info = read_exe_header(DQ4_DISC, 24)
    if dq4_info:
        print(f"    Text size: 0x{dq4_info['text_size']:X} ({dq4_info['text_size']:,} bytes)")
        print(f"    Total EXE: {dq4_info['total_exe']:,} bytes")
        print(f"    Sectors needed: {dq4_info['sectors_needed']}")
        print(f"    LBA range: 24 to {24 + dq4_info['sectors_needed'] - 1}")
    
    # 3. Disc sizes
    print("\n[3] Disc Sizes")
    dw7_sz, dw7_sectors = get_disc_size_sectors(DW7_DISC)
    dq4_sz, dq4_sectors = get_disc_size_sectors(DQ4_DISC)
    print(f"    DW7: {dw7_sz:,} bytes ({dw7_sz/1024/1024:.1f} MB, {dw7_sectors:,} sectors)")
    print(f"    DQ4: {dq4_sz:,} bytes ({dq4_sz/1024/1024:.1f} MB, {dq4_sectors:,} sectors)")
    
    # 4. DQ4 HBD range
    print("\n[4] DQ4 HBD Range")
    hbd_start = 362
    hbd_size = 319436800
    hbd_sectors = hbd_size // USER_SIZE
    hbd_end = hbd_start + hbd_sectors - 1
    print(f"    Native: LBA {hbd_start} to {hbd_end} ({hbd_sectors} sectors, {hbd_size/1024/1024:.1f} MB)")
    print(f"    If moved to LBA 354: LBA 354 to {354 + hbd_sectors - 1} (delta: -8 sectors)")
    print(f"    DQ4 disc has {dq4_sectors:,} sectors total")
    print(f"    Space after HBD (at 354): {dq4_sectors - (354 + hbd_sectors):,} sectors")
    
    # 5. Find STR ranges on DQ4 disc
    print("\n[5] DQ4 STR/FMV Sector Ranges (submode scan)")
    print("    Scanning disc for REALTIME|VIDEO submode sectors...")
    str_ranges = find_str_ranges(DQ4_DISC, max_sectors=dq4_sectors)
    
    total_str_sectors = sum(r[2] for r in str_ranges)
    print(f"    Found {len(str_ranges)} STR ranges, total {total_str_sectors} sectors ({total_str_sectors * USER_SIZE / 1024 / 1024:.1f} MB)")
    
    print(f"\n    {'#':>3s}  {'Start':>7s}  {'End':>7s}  {'Sectors':>7s}  {'Size':>8s}  {'BCD MSF':>10s}  {'LBA':>7s}")
    print(f"    {'-'*3}  {'-'*7}  {'-'*7}  {'-'*7}  {'-'*8}  {'-'*10}  {'-'*7}")
    for i, (start, end, count) in enumerate(str_ranges):
        size_mb = count * USER_SIZE / 1024 / 1024
        bcd_m, bcd_s, bcd_f = lba_to_bcd_msf(start)
        bcd_str = f"{bcd_m:02X}:{bcd_s:02X}:{bcd_f:02X}"
        print(f"    {i:3d}  {start:7d}  {end:7d}  {count:7d}  {size_mb:7.1f}MB  {bcd_str:>10s}  {start:7d}")
    
    # 6. Identify the first STR range (likely intro FMV)
    if str_ranges:
        first = str_ranges[0]
        print(f"\n[6] First STR range (likely intro FMV):")
        print(f"    LBA {first[0]} to {first[1]} ({first[2]} sectors, {first[2]*USER_SIZE/1024/1024:.1f} MB)")
        bcd_m, bcd_s, bcd_f = lba_to_bcd_msf(first[0])
        print(f"    BCD MSF: {bcd_m:02X}:{bcd_s:02X}:{bcd_f:02X}")
        print(f"    BCD bytes: 0x{bcd_m:02X}, 0x{bcd_s:02X}, 0x{bcd_f:02X}")
        print(f"    This is the target for FMV BCD patch (replacing 32:34:71)")
    
    # 7. DW7 FMV range (for comparison)
    print(f"\n[7] DW7 FMV seek target:")
    dw7_fmv_lba = 146621
    bcd_m, bcd_s, bcd_f = lba_to_bcd_msf(dw7_fmv_lba)
    print(f"    LBA {dw7_fmv_lba}, BCD MSF: {bcd_m:02X}:{bcd_s:02X}:{bcd_f:02X}")
    print(f"    BCD bytes: 0x{bcd_m:02X}, 0x{bcd_s:02X}, 0x{bcd_f:02X}")
    
    # 8. Check if LBA 105840 (our current patch target) is actually a STR sector
    print(f"\n[8] Verify current FMV patch target (LBA 105840):")
    target_lba = 105840
    in_str_range = False
    for start, end, count in str_ranges:
        if start <= target_lba <= end:
            in_str_range = True
            print(f"    LBA {target_lba} IS within STR range {start}-{end}")
            break
    if not in_str_range:
        print(f"    LBA {target_lba} is NOT within any STR range!")
        print(f"    *** CURRENT FMV BCD PATCH TARGET IS WRONG ***")
    
    # 9. Summary
    print(f"\n{'='*70}")
    print(f"  SUMMARY")
    print(f"{'='*70}")
    print(f"  DW7 EXE: {dw7_info['total_exe']:,} bytes, needs {dw7_info['sectors_needed']} sectors")
    print(f"  Available (LBA 24-353): {available:,} bytes ({354-24} sectors)")
    print(f"  EXE fits before LBA 354? {'YES' if dw7_info['total_exe'] <= available else 'NO'}")
    print(f"  HBD at LBA 354: NO EXE-SIDE LBA PATCHING NEEDED (DW7 expects 354)")
    print(f"  HBD internal delta: -8 (362→354)")
    print(f"  STR ranges found: {len(str_ranges)}, total {total_str_sectors} sectors")
    if str_ranges:
        first = str_ranges[0]
        bcd_m, bcd_s, bcd_f = lba_to_bcd_msf(first[0])
        print(f"  First STR (intro FMV): LBA {first[0]}, BCD {bcd_m:02X}:{bcd_s:02X}:{bcd_f:02X}")
        print(f"  FMV BCD patch should be: 0x{bcd_m:02X}, 0x{bcd_s:02X}, 0x{bcd_f:02X}")

if __name__ == '__main__':
    main()
