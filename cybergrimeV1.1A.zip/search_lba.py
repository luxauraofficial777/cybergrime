#!/usr/bin/env python3
"""Search for LBA 146621 in various encodings in the DW7 EXE."""
import struct

exe_path = r"C:\LuxAura\VoidWalkers_Project\DQLOSTTRANSLATION\translation\SLUSP012.06_clean.bin"
with open(exe_path, "rb") as f:
    exe = f.read()

print(f"EXE: {len(exe)} bytes")
LOAD_ADDR = 0x80017F00

# Search for 146621 = 0x23C5D in various forms
targets = {
    "LE32 146621": struct.pack("<I", 146621),
    "BE32 146621": struct.pack(">I", 146621),
    "LE16 146621 (low)": struct.pack("<H", 146621 & 0xFFFF),
    "LE16 146621 (high)": struct.pack("<H", 146621 >> 16),
    "LBA 146620 (0-indexed LE32)": struct.pack("<I", 146620),
    "LBA 146622 LE32": struct.pack("<I", 146622),
}

for name, pat in targets.items():
    idx = 0
    matches = []
    while True:
        idx = exe.find(pat, idx)
        if idx == -1:
            break
        matches.append(idx)
        idx += 1
    if matches:
        print(f"\n{name}: {len(matches)} matches")
        for m in matches[:20]:
            # Show surrounding context (8 bytes before and after)
            ctx_start = max(0, m - 8)
            ctx_end = min(len(exe), m + len(pat) + 8)
            ctx = exe[ctx_start:ctx_end].hex()
            ram = m + LOAD_ADDR
            print(f"  0x{m:06X} (RAM 0x{ram:08X}) ctx: {ctx}")
    else:
        print(f"\n{name}: 0 matches")

# Also search for the BCD components separately
# BCD 32 = 0x32, BCD 34 = 0x34, BCD 71 = 0x71
# These might be stored as separate immediates in MIPS instructions
# addiu $reg, $reg, 0x0032  => 0x32 as immediate
# Search for 0x32 0x34 0x71 with gaps
print("\n--- Searching for BCD components with small gaps ---")
for gap in range(1, 8):
    count = 0
    for i in range(len(exe) - 2 - gap):
        if exe[i] == 0x32 and exe[i+1+gap] == 0x34 and exe[i+2+gap*2] == 0x71:
            if count < 5:
                ram = i + LOAD_ADDR
                print(f"  gap={gap}: 0x{i:06X} (RAM 0x{ram:08X})")
            count += 1
    if count > 0:
        print(f"  gap={gap}: {count} total")
