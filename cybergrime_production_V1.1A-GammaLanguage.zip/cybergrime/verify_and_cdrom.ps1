# 1. Fix the verification: EXE file offset maps directly to disc sectors
#    (no subtraction of 0x800 header)
# 2. Search for CDROM command register access (0x1F801800-0x1F801803)

$binPath = 'c:\LuxAura\VoidWalkers_Project\DQLOSTTRANSLATION\cybergrime\dq4_reverse_v97_fmv.bin'
$exePath = 'c:\LuxAura\VoidWalkers_Project\DQLOSTTRANSLATION\translation\SLUSP012.06'

# === 1. Correct verification ===
$fs = [System.IO.File]::OpenRead($binPath)
$exeLBA = 24
$exeFileOff = 0x92936

# Direct mapping: EXE byte N -> disc sector (exeLBA + N/2048), offset (N%2048)
$sectorInExe = [Math]::Floor($exeFileOff / 2048)
$offsetInSector = $exeFileOff % 2048
$discLBA = $exeLBA + $sectorInExe
$rawOffset = $discLBA * 2352 + 24 + $offsetInSector

Write-Host "=== Corrected verification ==="
Write-Host "EXE file offset: 0x$($exeFileOff.ToString('X'))"
Write-Host "Sector within EXE: $sectorInExe"
Write-Host "Offset in sector: $offsetInSector (0x$($offsetInSector.ToString('X')))"
Write-Host "Disc LBA: $discLBA"
Write-Host "Raw BIN offset: $rawOffset"

$fs.Seek($rawOffset, 'Begin') | Out-Null
$buf = New-Object byte[] 16
$fs.Read($buf, 0, 16) | Out-Null
$hex = ''
for ($i = 0; $i -lt 16; $i++) { $hex += '{0:X2} ' -f $buf[$i] }
Write-Host "Bytes at EXE 0x92936 in disc: $hex"

if ($buf[0] -eq 0x23 -and $buf[1] -eq 0x31 -and $buf[2] -eq 0x15) {
    Write-Host "  PATCHED correctly to 23 31 15 (DQ4 FMV)"
} elseif ($buf[0] -eq 0x32 -and $buf[1] -eq 0x34 -and $buf[2] -eq 0x71) {
    Write-Host "  UNPATCHED: still 32 34 71 (DW7 FMV)"
} else {
    Write-Host "  Different data: not either expected pattern"
}

$fs.Close()

# === 2. Search for CDROM command register access ===
$bytes = [System.IO.File]::ReadAllBytes($exePath)
$loadAddr = 0x80017F00
$rn = @('zero','at','v0','v1','a0','a1','a2','a3','t0','t1','t2','t3','t4','t5','t6','t7','s0','s1','s2','s3','s4','s5','s6','s7','t8','t9','k0','k1','gp','sp','fp','ra')

# Search for lui 0x1F80 followed by addiu/ori with 0x1800-0x1803
Write-Host ""
Write-Host "=== CDROM command register access (0x1F801800-0x1F801803) ==="
for ($i = 0x800; $i -lt $bytes.Length - 7; $i += 4) {
    $insn = [BitConverter]::ToUInt32($bytes, $i)
    if (($insn -shr 26) -eq 0x0F -and ($insn -band 0xFFFF) -eq 0x1F80) {
        $rt = ($insn -shr 16) -band 0x1F
        $rtn = $rn[$rt]
        # Check next few instructions for 0x1800-0x1803
        for ($j = 1; $j -le 4; $j++) {
            if ($i + $j * 4 + 3 -ge $bytes.Length) { break }
            $next = [BitConverter]::ToUInt32($bytes, $i + $j * 4)
            $nextImm = $next -band 0xFFFF
            if ($nextImm -ge 0x1800 -and $nextImm -le 0x1803) {
                $ram = $loadAddr + $i - 0x800
                $nextRam = $loadAddr + $i + $j * 4 - 0x800
                $nextOp = $next -shr 26
                $nextRt = ($next -shr 16) -band 0x1F
                $nextRs = ($next -shr 21) -band 0x1F
                $d = ''
                if ($nextOp -eq 0x09) { $d = "addiu $($rn[$nextRt]),$($rn[$nextRs]),0x$($nextImm.ToString('X4'))" }
                elseif ($nextOp -eq 0x0D) { $d = "ori $($rn[$nextRt]),$($rn[$nextRs]),0x$($nextImm.ToString('X4'))" }
                elseif ($nextOp -eq 0x23) { $d = "lw $($rn[$nextRt]),0x$($nextImm.ToString('X4'))($($rn[$nextRs]))" }
                elseif ($nextOp -eq 0x24) { $d = "lbu $($rn[$nextRt]),0x$($nextImm.ToString('X4'))($($rn[$nextRs]))" }
                elseif ($nextOp -eq 0x28) { $d = "sb $($rn[$nextRt]),0x$($nextImm.ToString('X4'))($($rn[$nextRs]))" }
                elseif ($nextOp -eq 0x2B) { $d = "sw $($rn[$nextRt]),0x$($nextImm.ToString('X4'))($($rn[$nextRs]))" }
                else { $d = "op=0x$($nextOp.ToString('X2')) imm=0x$($nextImm.ToString('X4'))" }
                Write-Host ("  RAM 0x{0:X8}: lui {1},0x1F80 -> 0x{2:X8}: {3}" -f $ram, $rtn, $nextRam, $d)
            }
        }
    }
}

# Also search for any instruction with immediate 0x1800-0x1803
Write-Host ""
Write-Host "=== All instructions with immediate 0x1800-0x1803 ==="
for ($i = 0x800; $i -lt $bytes.Length - 3; $i += 4) {
    $insn = [BitConverter]::ToUInt32($bytes, $i)
    $imm = $insn -band 0xFFFF
    if ($imm -ge 0x1800 -and $imm -le 0x1803) {
        $ram = $loadAddr + $i - 0x800
        $op = $insn -shr 26
        $rs = ($insn -shr 21) -band 0x1F; $rt = ($insn -shr 16) -band 0x1F
        $d = "op=0x$($op.ToString('X2')) imm=0x$($imm.ToString('X4'))"
        if ($op -eq 0x09) { $d = "addiu $($rn[$rt]),$($rn[$rs]),0x$($imm.ToString('X4'))" }
        elseif ($op -eq 0x28) { $d = "sb $($rn[$rt]),0x$($imm.ToString('X4'))($($rn[$rs]))" }
        elseif ($op -eq 0x24) { $d = "lbu $($rn[$rt]),0x$($imm.ToString('X4'))($($rn[$rs]))" }
        elseif ($op -eq 0x23) { $d = "lw $($rn[$rt]),0x$($imm.ToString('X4'))($($rn[$rs]))" }
        elseif ($op -eq 0x2B) { $d = "sw $($rn[$rt]),0x$($imm.ToString('X4'))($($rn[$rs]))" }
        # Check prev for lui 0x1F80
        $prev = [BitConverter]::ToUInt32($bytes, $i - 4)
        $prevInfo = ''
        if (($prev -shr 26) -eq 0x0F -and ($prev -band 0xFFFF) -eq 0x1F80) { $prevInfo = ' [after lui 0x1F80]' }
        Write-Host ("  RAM 0x{0:X8}: 0x{1:X8}  {2}{3}" -f $ram, $insn, $d, $prevInfo)
    }
}
