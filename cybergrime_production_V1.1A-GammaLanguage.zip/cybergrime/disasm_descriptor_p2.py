#!/usr/bin/env python3
"""
P0 Phase 2: Find callers of 0x8007A340, trace $s2 setup before crash,
and search for actual descriptor base address computation.
"""
import struct

EXE_PATH = r"..\translation\SLUSP012.06"
LOAD_ADDR = 0x80017F00
EXE_HDR_SIZE = 0x800

def ram_to_file(ram_addr):
    return ram_addr - LOAD_ADDR + EXE_HDR_SIZE

def file_to_ram(file_off):
    return file_off + LOAD_ADDR - EXE_HDR_SIZE

def read_exe(path):
    with open(path, "rb") as f:
        return f.read()

REG_NAMES = ["$zero","$at","$v0","$v1","$a0","$a1","$a2","$a3",
             "$t0","$t1","$t2","$t3","$t4","$t5","$t6","$t7",
             "$s0","$s1","$s2","$s3","$s4","$s5","$s6","$s7",
             "$t8","$t9","$k0","$k1","$gp","$sp","$fp","$ra"]

def sign_extend16(v):
    return v - 0x10000 if v & 0x8000 else v

def disasm_one(word, pc):
    op = (word >> 26) & 0x3F
    rs = (word >> 21) & 0x1F
    rt = (word >> 16) & 0x1F
    rd = (word >> 11) & 0x1F
    shamt = (word >> 6) & 0x1F
    funct = word & 0x3F
    imm = word & 0xFFFF
    simm = sign_extend16(imm)
    target = word & 0x3FFFFFF

    if op == 0x00:
        if funct == 0x20: return f"add {REG_NAMES[rd]}, {REG_NAMES[rs]}, {REG_NAMES[rt]}"
        if funct == 0x21: return f"addu {REG_NAMES[rd]}, {REG_NAMES[rs]}, {REG_NAMES[rt]}"
        if funct == 0x22: return f"sub {REG_NAMES[rd]}, {REG_NAMES[rs]}, {REG_NAMES[rt]}"
        if funct == 0x23: return f"subu {REG_NAMES[rd]}, {REG_NAMES[rs]}, {REG_NAMES[rt]}"
        if funct == 0x24: return f"and {REG_NAMES[rd]}, {REG_NAMES[rs]}, {REG_NAMES[rt]}"
        if funct == 0x25: return f"or  {REG_NAMES[rd]}, {REG_NAMES[rs]}, {REG_NAMES[rt]}"
        if funct == 0x26: return f"xor {REG_NAMES[rd]}, {REG_NAMES[rs]}, {REG_NAMES[rt]}"
        if funct == 0x27: return f"nor {REG_NAMES[rd]}, {REG_NAMES[rs]}, {REG_NAMES[rt]}"
        if funct == 0x2A: return f"slt {REG_NAMES[rd]}, {REG_NAMES[rs]}, {REG_NAMES[rt]}"
        if funct == 0x2B: return f"sltu {REG_NAMES[rd]}, {REG_NAMES[rs]}, {REG_NAMES[rt]}"
        if funct == 0x00:
            if word == 0: return "nop"
            return f"sll {REG_NAMES[rd]}, {REG_NAMES[rt]}, {shamt}"
        if funct == 0x02: return f"srl {REG_NAMES[rd]}, {REG_NAMES[rt]}, {shamt}"
        if funct == 0x03: return f"sra {REG_NAMES[rd]}, {REG_NAMES[rt]}, {shamt}"
        if funct == 0x04: return f"sllv {REG_NAMES[rd]}, {REG_NAMES[rt]}, {REG_NAMES[rs]}"
        if funct == 0x06: return f"srlv {REG_NAMES[rd]}, {REG_NAMES[rt]}, {REG_NAMES[rs]}"
        if funct == 0x07: return f"srav {REG_NAMES[rd]}, {REG_NAMES[rt]}, {REG_NAMES[rs]}"
        if funct == 0x08: return f"jr {REG_NAMES[rs]}"
        if funct == 0x09: return f"jalr {REG_NAMES[rd]}, {REG_NAMES[rs]}"
        if funct == 0x0C: return f"syscall"
        if funct == 0x10: return f"mfhi {REG_NAMES[rd]}"
        if funct == 0x12: return f"mflo {REG_NAMES[rd]}"
        if funct == 0x11: return f"mthi {REG_NAMES[rs]}"
        if funct == 0x13: return f"mtlo {REG_NAMES[rs]}"
        if funct == 0x18: return f"mult {REG_NAMES[rs]}, {REG_NAMES[rt]}"
        if funct == 0x19: return f"multu {REG_NAMES[rs]}, {REG_NAMES[rt]}"
        if funct == 0x1A: return f"div {REG_NAMES[rs]}, {REG_NAMES[rt]}"
        if funct == 0x1B: return f"divu {REG_NAMES[rs]}, {REG_NAMES[rt]}"
        return f".special 0x{funct:02x}"
    if op == 0x01:
        if rt == 0x00: return f"bltz {REG_NAMES[rs]}, 0x{pc + 4 + simm*4:08X}"
        if rt == 0x01: return f"bgez {REG_NAMES[rs]}, 0x{pc + 4 + simm*4:08X}"
        return f".regimm 0x{rt:02x}"
    if op == 0x02: return f"j 0x{(pc & 0xF0000000) | (target << 2):08X}"
    if op == 0x03: return f"jal 0x{(pc & 0xF0000000) | (target << 2):08X}"
    if op == 0x04: return f"beq {REG_NAMES[rs]}, {REG_NAMES[rt]}, 0x{pc + 4 + simm*4:08X}"
    if op == 0x05: return f"bne {REG_NAMES[rs]}, {REG_NAMES[rt]}, 0x{pc + 4 + simm*4:08X}"
    if op == 0x06: return f"blez {REG_NAMES[rs]}, 0x{pc + 4 + simm*4:08X}"
    if op == 0x07: return f"bgtz {REG_NAMES[rs]}, 0x{pc + 4 + simm*4:08X}"
    if op == 0x08: return f"addi {REG_NAMES[rt]}, {REG_NAMES[rs]}, {simm}"
    if op == 0x09: return f"addiu {REG_NAMES[rt]}, {REG_NAMES[rs]}, {simm}"
    if op == 0x0A: return f"slti {REG_NAMES[rt]}, {REG_NAMES[rs]}, {simm}"
    if op == 0x0B: return f"sltiu {REG_NAMES[rt]}, {REG_NAMES[rs]}, {simm}"
    if op == 0x0C: return f"andi {REG_NAMES[rt]}, {REG_NAMES[rs]}, 0x{imm:04X}"
    if op == 0x0D: return f"ori {REG_NAMES[rt]}, {REG_NAMES[rs]}, 0x{imm:04X}"
    if op == 0x0E: return f"xori {REG_NAMES[rt]}, {REG_NAMES[rs]}, 0x{imm:04X}"
    if op == 0x0F: return f"lui {REG_NAMES[rt]}, 0x{imm:04X}"
    if op == 0x20: return f"lb {REG_NAMES[rt]}, {simm}({REG_NAMES[rs]})"
    if op == 0x21: return f"lh {REG_NAMES[rt]}, {simm}({REG_NAMES[rs]})"
    if op == 0x23: return f"lw {REG_NAMES[rt]}, {simm}({REG_NAMES[rs]})"
    if op == 0x24: return f"lbu {REG_NAMES[rt]}, {simm}({REG_NAMES[rs]})"
    if op == 0x25: return f"lhu {REG_NAMES[rt]}, {simm}({REG_NAMES[rs]})"
    if op == 0x28: return f"sb {REG_NAMES[rt]}, {simm}({REG_NAMES[rs]})"
    if op == 0x29: return f"sh {REG_NAMES[rt]}, {simm}({REG_NAMES[rs]})"
    if op == 0x2B: return f"sw {REG_NAMES[rt]}, {simm}({REG_NAMES[rs]})"
    return f".word 0x{word:08X}"

def disasm_range(data, start_ram, count, label=""):
    start_file = ram_to_file(start_ram)
    print(f"\n{'='*80}")
    print(f"  {label}: RAM 0x{start_ram:08X}")
    print(f"{'='*80}")
    for i in range(count):
        off = start_file + i * 4
        if off + 4 > len(data):
            print(f"  0x{start_ram + i*4:08X}:  <out of range>")
            continue
        word = struct.unpack_from("<I", data, off)[0]
        pc = start_ram + i * 4
        asm = disasm_one(word, pc)
        print(f"  0x{pc:08X}: {word:08X}  {asm}")

def find_callers(data, target_ram):
    """Find jal instructions targeting the given address."""
    target_field = (target_ram >> 2) & 0x3FFFFFF
    callers = []
    for off in range(EXE_HDR_SIZE, len(data) - 4, 4):
        word = struct.unpack_from("<I", data, off)[0]
        op = (word >> 26) & 0x3F
        if op != 0x03:  # jal
            continue
        t = word & 0x3FFFFFF
        if t == target_field:
            callers.append(file_to_ram(off))
    return callers

def find_function_start(data, addr, max_back=200):
    """Walk backwards to find the function start (addiu $sp, $sp, -N or first instruction after jr)."""
    start_file = ram_to_file(addr)
    for i in range(max_back):
        off = start_file - (i + 1) * 4
        if off < EXE_HDR_SIZE:
            break
        word = struct.unpack_from("<I", data, off)[0]
        # Look for jr $ra followed by addiu $sp (function boundary)
        if (word & 0xFFFF) == 0x03E0 and ((word >> 26) == 0):  # jr $ra
            # Next instruction should be addiu $sp, $sp, N (function prologue of next function)
            next_off = off + 4
            if next_off + 4 <= len(data):
                next_word = struct.unpack_from("<I", data, next_off)[0]
                next_op = (next_word >> 26) & 0x3F
                if next_op == 0x09 and ((next_word >> 21) & 0x1F) == 29 and ((next_word >> 16) & 0x1F) == 29:
                    return file_to_ram(next_off)
    return addr - 100  # fallback

def find_lui_addiu_to(data, target_ram):
    """Find lui+addiu pairs that compute target_ram.
    Handles both positive and negative lo16 offsets."""
    target_hi_pos = (target_ram >> 16) & 0xFFFF
    target_lo = target_ram & 0xFFFF
    target_lo_signed = sign_extend16(target_lo)
    
    # With lui hi: addr = (hi << 16) + sign_extend(lo)
    # If lo has bit 15 set, sign_extend(lo) is negative, so we need hi+1
    if target_lo & 0x8000:
        # Need lui hi+1, addiu lo (negative)
        hi_needed = (target_hi_pos + 1) & 0xFFFF
        lo_needed = target_lo  # will be sign-extended to negative
    else:
        hi_needed = target_hi_pos
        lo_needed = target_lo
    
    results = []
    for off in range(EXE_HDR_SIZE, len(data) - 8, 4):
        word = struct.unpack_from("<I", data, off)[0]
        op = (word >> 26) & 0x3F
        if op != 0x0F:  # lui
            continue
        rt = (word >> 16) & 0x1F
        imm = word & 0xFFFF
        if imm != hi_needed:
            continue
        # Look for addiu rt, rt, lo in next few instructions
        for i in range(1, 8):
            next_off = off + i * 4
            if next_off + 4 > len(data):
                break
            next_word = struct.unpack_from("<I", data, next_off)[0]
            next_op = (next_word >> 26) & 0x3F
            if next_op == 0x09:  # addiu
                next_rt = (next_word >> 16) & 0x1F
                next_rs = (next_word >> 21) & 0x1F
                next_imm = next_word & 0xFFFF
                if next_rt == rt and next_rs == rt and next_imm == lo_needed:
                    results.append({
                        'lui_ram': file_to_ram(off),
                        'addiu_ram': file_to_ram(next_off),
                        'reg': REG_NAMES[rt],
                        'computed': target_ram,
                    })
                    break
    return results

def find_lui_sw_to(data, target_ram):
    """Find lui + sw patterns targeting target_ram.
    Handles both positive and negative lo16."""
    target_hi_pos = (target_ram >> 16) & 0xFFFF
    target_lo = target_ram & 0xFFFF
    target_lo_signed = sign_extend16(target_lo)
    
    if target_lo & 0x8000:
        hi_needed = (target_hi_pos + 1) & 0xFFFF
        lo_needed = target_lo  # sign-extended to negative
    else:
        hi_needed = target_hi_pos
        lo_needed = target_lo
    
    results = []
    for off in range(EXE_HDR_SIZE, len(data) - 4, 4):
        word = struct.unpack_from("<I", data, off)[0]
        op = (word >> 26) & 0x3F
        if op == 0x0F:  # lui
            rt = (word >> 16) & 0x1F
            imm = word & 0xFFFF
            if imm != hi_needed:
                continue
            # Look for sw with this register as base
            for i in range(1, 16):
                next_off = off + i * 4
                if next_off + 4 > len(data):
                    break
                next_word = struct.unpack_from("<I", data, next_off)[0]
                next_op = (next_word >> 26) & 0x3F
                if next_op == 0x2B:  # sw
                    next_rs = (next_word >> 21) & 0x1F
                    next_imm = next_word & 0xFFFF
                    if next_rs == rt and next_imm == lo_needed:
                        results.append({
                            'lui_ram': file_to_ram(off),
                            'sw_ram': file_to_ram(next_off),
                            'reg': REG_NAMES[rt],
                            'val_reg': REG_NAMES[(next_word >> 16) & 0x1F],
                        })
                        break
                if next_op == 0x0F:  # another lui - register might be overwritten
                    break
    return results

def find_lui_lw_from(data, target_ram):
    """Find lui + lw patterns loading from target_ram."""
    target_hi_pos = (target_ram >> 16) & 0xFFFF
    target_lo = target_ram & 0xFFFF
    
    if target_lo & 0x8000:
        hi_needed = (target_hi_pos + 1) & 0xFFFF
        lo_needed = target_lo
    else:
        hi_needed = target_hi_pos
        lo_needed = target_lo
    
    results = []
    for off in range(EXE_HDR_SIZE, len(data) - 4, 4):
        word = struct.unpack_from("<I", data, off)[0]
        op = (word >> 26) & 0x3F
        if op == 0x0F:  # lui
            rt = (word >> 16) & 0x1F
            imm = word & 0xFFFF
            if imm != hi_needed:
                continue
            for i in range(1, 16):
                next_off = off + i * 4
                if next_off + 4 > len(data):
                    break
                next_word = struct.unpack_from("<I", data, next_off)[0]
                next_op = (next_word >> 26) & 0x3F
                if next_op == 0x23:  # lw
                    next_rs = (next_word >> 21) & 0x1F
                    next_imm = next_word & 0xFFFF
                    if next_rs == rt and next_imm == lo_needed:
                        results.append({
                            'lui_ram': file_to_ram(off),
                            'lw_ram': file_to_ram(next_off),
                            'reg': REG_NAMES[rt],
                            'dest_reg': REG_NAMES[(next_word >> 16) & 0x1F],
                        })
                        break
                if next_op == 0x0F:
                    break
    return results

def main():
    data = read_exe(EXE_PATH)
    print(f"EXE: {len(data)} bytes, load 0x{LOAD_ADDR:08X}")
    print(f"Text: 0x{file_to_ram(EXE_HDR_SIZE):08X} - 0x{file_to_ram(len(data)):08X}")

    # 1. Find callers of descriptor init 0x8007A340
    print(f"\n{'='*80}")
    print(f"  CALLERS of descriptor init 0x8007A340")
    print(f"{'='*80}")
    callers = find_callers(data, 0x8007A340)
    for c in callers:
        print(f"  0x{c:08X}: jal 0x8007A340")
        # Disassemble context around the call
        disasm_range(data, c - 32, 24, f"Caller context at 0x{c:08X}")

    # 2. Find the function containing the crash (0x800761DC)
    # Trace backwards to find where $s2 is set
    crash_func_start = find_function_start(data, 0x800761DC, max_back=300)
    print(f"\n{'='*80}")
    print(f"  CRASH FUNCTION start: 0x{crash_func_start:08X}")
    print(f"{'='*80}")
    disasm_range(data, crash_func_start, 120, f"Crash function from 0x{crash_func_start:08X}")

    # 3. Search for lui+addiu computing 0x800D9A70 (correct MIPS encoding)
    # 0x800D9A70: lo=0x9A70 (bit 15 set), so need lui 0x800E + addiu -0x6590
    for target in [0x800D9A28, 0x800D9A38, 0x800D9A40, 0x800D9A48, 
                   0x800D9A50, 0x800D9A68, 0x800D9A70]:
        print(f"\n{'='*80}")
        print(f"  lui+addiu pairs computing 0x{target:08X}")
        print(f"{'='*80}")
        pairs = find_lui_addiu_to(data, target)
        if pairs:
            for p in pairs:
                print(f"  0x{p['lui_ram']:08X}: lui {p['reg']}, ... -> 0x{p['computed']:08X}")
                print(f"  0x{p['addiu_ram']:08X}: addiu {p['reg']}, {p['reg']}, ...")
        else:
            print(f"  None found")

    # 4. Search for lui+sw to 0x800D9A70
    print(f"\n{'='*80}")
    print(f"  lui+sw patterns writing to 0x800D9A70")
    print(f"{'='*80}")
    sw_hits = find_lui_sw_to(data, 0x800D9A70)
    if sw_hits:
        for h in sw_hits:
            print(f"  lui at 0x{h['lui_ram']:08X} + sw at 0x{h['sw_ram']:08X}: sw {h['val_reg']}, ...({h['reg']})")
            disasm_range(data, h['lui_ram'] - 16, 40, f"Context: sw to 0x800D9A70")
    else:
        print("  None found")

    # 5. Search for lui+lw from 0x800D9A70 (reading the descriptor base)
    print(f"\n{'='*80}")
    print(f"  lui+lw patterns reading from 0x800D9A70")
    print(f"{'='*80}")
    lw_hits = find_lui_lw_from(data, 0x800D9A70)
    if lw_hits:
        for h in lw_hits:
            print(f"  lui at 0x{h['lui_ram']:08X} + lw at 0x{h['lw_ram']:08X}: lw {h['dest_reg']}, ...({h['reg']})")
            disasm_range(data, h['lui_ram'] - 16, 40, f"Context: lw from 0x800D9A70")
    else:
        print("  None found")

    # 6. Also search for all references to 0x800D9A68 (descriptor struct B base)
    print(f"\n{'='*80}")
    print(f"  lui+lw/sw patterns for 0x800D9A68 (descriptor struct B)")
    print(f"{'='*80}")
    sw_hits_b = find_lui_sw_to(data, 0x800D9A68)
    lw_hits_b = find_lui_lw_from(data, 0x800D9A68)
    for h in sw_hits_b:
        print(f"  SW: lui at 0x{h['lui_ram']:08X} + sw at 0x{h['sw_ram']:08X}: sw {h['val_reg']}, ...({h['reg']})")
    for h in lw_hits_b:
        print(f"  LW: lui at 0x{h['lui_ram']:08X} + lw at 0x{h['lw_ram']:08X}: lw {h['dest_reg']}, ...({h['reg']})")
    
    # 7. Search for lui 0x800E + addiu with negative offset in 0x9A00 range
    # This catches any access to 0x800D9Axx region
    print(f"\n{'='*80}")
    print(f"  All lui 0x800E + addiu/lw/sw with offset 0x9A00-0x9AFF (0x800D9Axx region)")
    print(f"{'='*80}")
    for off in range(EXE_HDR_SIZE, len(data) - 4, 4):
        word = struct.unpack_from("<I", data, off)[0]
        op = (word >> 26) & 0x3F
        if op != 0x0F:
            continue
        rt = (word >> 16) & 0x1F
        imm = word & 0xFFFF
        if imm != 0x800E:
            continue
        # Found lui $rt, 0x800E — look for nearby lw/sw/addiu with 0x9Axx offset
        for i in range(1, 12):
            next_off = off + i * 4
            if next_off + 4 > len(data):
                break
            next_word = struct.unpack_from("<I", data, next_off)[0]
            next_op = (next_word >> 26) & 0x3F
            next_imm = next_word & 0xFFFF
            # Check if offset is in 0x9A00-0x9B00 range (sign-extended to negative -> 0x800D9Axx)
            if next_imm >= 0x9A00 and next_imm <= 0x9BFF:
                next_rs = (next_word >> 21) & 0x1F
                if next_rs == rt or ((next_word >> 16) & 0x1F) == rt:
                    ram = file_to_ram(next_off)
                    computed = 0x800E0000 + sign_extend16(next_imm)
                    asm = disasm_one(next_word, ram)
                    print(f"  0x{ram:08X}: {next_word:08X}  {asm}  => addr 0x{computed:08X}")
            if next_op == 0x0F:  # another lui
                break

if __name__ == "__main__":
    main()
