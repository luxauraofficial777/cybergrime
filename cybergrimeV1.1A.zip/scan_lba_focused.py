#!/usr/bin/env python3
"""Focused scan: find real HBD LBA references, not power-of-2 false positives."""
import struct

exe_path = r'..\translation\SLUSP012.06_disc_extract.bin'
with open(exe_path, 'rb') as f:
    data = f.read()

LOAD_ADDR = 0x80017F00
HBD_LBA_DW7 = 354
HBD_LBA_FRANK = 356
LBA_DELTA = HBD_LBA_FRANK - HBD_LBA_DW7  # +146

def f2r(off):
    return LOAD_ADDR + off - 0x800

# Filter: exclude powers of 2 and common non-LBA values
POWERS_OF_2 = set(1 << i for i in range(32))
# Also exclude values that are obviously not LBAs (multiples of large powers of 2)
def is_likely_lba(val):
    if val in POWERS_OF_2:
        return False
    if val > 0 and (val & (val - 1)) == 0:  # power of 2
        return False
    # Exclude common non-LBA patterns
    if val % 65536 == 0:  # 0x10000 multiples
        return False
    if val % 131072 == 0:  # 0x20000 multiples
        return False
    if val % 262144 == 0:  # 0x40000 multiples
        return False
    if val % 196608 == 0:  # 0x30000 multiples
        return False
    # Exclude values that are clearly bit patterns (0x10001, 0x20001, etc.)
    if val in (65537, 131073, 196609, 262145, 65544, 131080, 131081, 131082, 131083, 131084, 131085, 131086, 131090, 131091, 131093):
        return False
    # Exclude values that look like bit flags (low bits set in high bytes)
    if val > 0x10000 and (val & 0xFFFF) in (0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 0x10, 0x20, 0x40, 0x80):
        return False
    return True

# 1. Focus on the known LBA table region 0x8001B700-0x8001BB00
print('=== LBA table at 0x8001B700-0x8001BB00 (filtered) ===')
start = 0x8001B700 - LOAD_ADDR + 0x800
hbd_entries = []
exe_entries = []
other_entries = []
for i in range(0, 0x400, 4):
    off = start + i
    if off + 4 <= len(data):
        val = struct.unpack('<I', data[off:off+4])[0]
        ram = f2r(off)
        if 354 <= val <= 301794 and is_likely_lba(val):
            new_val = val + LBA_DELTA
            hbd_entries.append((off, ram, val, new_val))
            print(f'  HBD: 0x{ram:08X}: LBA {val:>6} -> {new_val:>6}')
        elif 24 <= val <= 353:
            exe_entries.append((off, ram, val))
        elif 0x80100000 <= val <= 0x801F0000:
            pass  # pointer, skip
        elif val > 0 and val < 0x10000 and is_likely_lba(val) and val not in range(24, 354):
            other_entries.append((off, ram, val))

print(f'\n  HBD LBA entries needing patch: {len(hbd_entries)}')
print(f'  EXE LBA entries (no patch): {len(exe_entries)}')
print(f'  Other small values: {len(other_entries)}')

# 2. Show EXE LBA entries for context
print(f'\n=== EXE LBA entries (24-353, no patch needed) ===')
for off, ram, val in exe_entries:
    print(f'  0x{ram:08X}: LBA {val}')

# 3. Search the ENTIRE EXE for 32-bit values that match known HBD LBAs
# from the table (354-360, 542, 3061, 3071, 3163, 3166, 3182-3186, 3639, 3779, 3780)
known_hbd_lbas = set()
for off, ram, val, new_val in hbd_entries:
    known_hbd_lbas.add(val)

print(f'\n=== Known HBD LBAs from table: {sorted(known_hbd_lbas)} ===')

# Search entire EXE for these values
print(f'\n=== All occurrences of known HBD LBAs in entire EXE ===')
all_refs = []
for i in range(0x800, len(data) - 4, 4):
    val = struct.unpack('<I', data[i:i+4])[0]
    if val in known_hbd_lbas:
        ram = f2r(i)
        all_refs.append((i, ram, val))
        print(f'  0x{ram:08X} (file 0x{i:X}): LBA {val} -> {val + LBA_DELTA}')

print(f'\nTotal references to known HBD LBAs: {len(all_refs)}')

# 4. Also search for the "sequential sector table" mentioned in previous sessions
# Previous session found values 350-370 in order at some offset
print('\n=== Search for sequential LBA values 350-370 ===')
for start_val in [350, 351, 352]:
    start_bytes = struct.pack('<I', start_val)
    pos = 0x800
    while True:
        idx = data.find(start_bytes, pos)
        if idx == -1:
            break
        # Check if next few words are sequential
        seq = []
        for k in range(10):
            if idx + k*4 + 4 <= len(data):
                v = struct.unpack('<I', data[idx+k*4:idx+k*4+4])[0]
                seq.append(v)
        # Check if sequential
        is_seq = all(seq[k] == start_val + k for k in range(len(seq)))
        if is_seq and len(seq) >= 3:
            ram = f2r(idx)
            print(f'  Sequential table at file 0x{idx:X} (RAM 0x{ram:08X}): {seq}')
        pos = idx + 1

# 5. Check 16-bit sequential values too
print('\n=== Search for 16-bit sequential LBA values 350-370 ===')
for start_val in [350, 351, 352]:
    start_bytes = struct.pack('<H', start_val)
    pos = 0x800
    while True:
        idx = data.find(start_bytes, pos)
        if idx == -1:
            break
        # Check if next few halfwords are sequential
        seq = []
        for k in range(10):
            if idx + k*2 + 2 <= len(data):
                v = struct.unpack('<H', data[idx+k*2:idx+k*2+2])[0]
                seq.append(v)
        is_seq = all(seq[k] == start_val + k for k in range(len(seq)))
        if is_seq and len(seq) >= 5:
            ram = f2r(idx)
            print(f'  16-bit sequential table at file 0x{idx:X} (RAM 0x{ram:08X}): {seq}')
        pos = idx + 1

print('\n=== Done ===')
