#!/usr/bin/env python3
"""Inspect ISO 9660 directory on the Phase C build disc — fixed offsets."""
import struct

SECTOR_SIZE = 2352
USER_OFFSET = 24
USER_SIZE = 2048

def read_sector(f, lba):
    f.seek(lba * SECTOR_SIZE + USER_OFFSET)
    return f.read(USER_SIZE)

def parse_dir_record(data, offset, indent=0):
    results = []
    pos = offset
    while pos < len(data):
        length = data[pos]
        if length == 0:
            break
        if pos + length > len(data):
            break
        
        lba_le = struct.unpack_from('<I', data, pos + 2)[0]
        lba_be = struct.unpack_from('>I', data, pos + 6)[0]
        size_le = struct.unpack_from('<I', data, pos + 10)[0]
        size_be = struct.unpack_from('>I', data, pos + 14)[0]
        flags = data[pos + 25]
        name_len = data[pos + 32]
        name = data[pos + 33:pos + 33 + name_len]
        
        is_dir = bool(flags & 0x02)
        name_str = name.decode('ascii', errors='replace').strip()
        lba_ok = "OK" if lba_le == lba_be else "MISMATCH"
        sz_ok = "OK" if size_le == size_be else "MISMATCH"
        
        results.append({
            'offset': pos, 'length': length, 'lba': lba_le, 'size': size_le,
            'flags': flags, 'is_dir': is_dir, 'name': name_str,
        })
        
        prefix = "  " * indent
        ftype = "DIR " if is_dir else "FILE"
        print(f"{prefix}[{pos:4d}] {ftype} LBA={lba_le:6d}(be={lba_be}) size={size_le:10d}(be={size_be}) {lba_ok}/{sz_ok} flags=0x{flags:02X} name='{name_str}'")
        pos += length
    return results

disc_path = r'C:\LuxAura\VoidWalkers_Project\DQLOSTTRANSLATION\dq4_phaseC_build1.bin'

with open(disc_path, 'rb') as f:
    pvd = read_sector(f, 16)
    print("=== PVD (LBA 16) ===")
    print(f"  Volume ID: {pvd[40:72].decode('ascii', errors='replace').strip()}")
    root_lba = struct.unpack_from('<I', pvd, 158)[0]
    root_size = struct.unpack_from('<I', pvd, 166)[0]
    pt_lba = struct.unpack_from('<I', pvd, 140)[0]
    pt_size = struct.unpack_from('<I', pvd, 132)[0]
    print(f"  Root dir LBA: {root_lba}, size: {root_size}")
    print(f"  Path table LBA: {pt_lba}, size: {pt_size}")
    
    cnf = read_sector(f, 23)
    cnf_text = cnf.decode('ascii', errors='replace').split('\x00')[0]
    print(f"\n=== SYSTEM.CNF ===\n{cnf_text}")
    
    print(f"\n=== Root Directory (LBA {root_lba}) ===")
    root_dir = read_sector(f, root_lba)
    entries = parse_dir_record(root_dir, 0, 0)
    
    # Path table
    print(f"\n=== Path Table (LBA {pt_lba}) ===")
    pt = read_sector(f, pt_lba)
    pos = 0
    while pos < len(pt) and pos < pt_size:
        pt_len = pt[pos]
        if pt_len == 0: break
        pt_ext_lba = struct.unpack_from('<I', pt, pos + 2)[0]
        pt_parent = struct.unpack_from('<H', pt, pos + 6)[0]
        pt_name_len = pt[pos + 8]
        pt_name = pt[pos + 9:pos + 9 + pt_name_len].decode('ascii', errors='replace')
        print(f"  [{pos:4d}] LBA={pt_ext_lba:6d} parent={pt_parent} name='{pt_name}'")
        pos += pt_len + 8 + pt_name_len + (pt_name_len % 2)
    
    # Sectors 166-173 (what game reads after boot)
    print(f"\n=== Sectors 166-173 (game reads after boot) ===")
    for lba in [166, 168, 172, 173]:
        sec = read_sector(f, lba)
        print(f"  LBA {lba}: first 64 bytes: {sec[:64].hex()}")
        if sec[0] > 0 and sec[0] < 255:
            rec_len = sec[0]
            name_len = sec[32] if len(sec) > 32 else 0
            if 0 < name_len < 20:
                name = sec[33:33+name_len].decode('ascii', errors='replace')
                lba_val = struct.unpack_from('<I', sec, 2)[0]
                size_val = struct.unpack_from('<I', sec, 10)[0]
                print(f"    -> Dir record? rec_len={rec_len} name='{name}' LBA={lba_val} size={size_val}")
    
    # Sector 500
    print(f"\n=== Sector 500 (HBD start) ===")
    sec500 = read_sector(f, 500)
    print(f"  First 32 bytes: {sec500[:32].hex()}")
    
    # EXE at sector 24
    print(f"\n=== EXE at sector 24 ===")
    exe = read_sector(f, 24)
    print(f"  Magic: {exe[:8]}")
    pc0 = struct.unpack_from('<I', exe, 0x10)[0]
    text_size = struct.unpack_from('<I', exe, 0x1C)[0]
    print(f"  PC0: 0x{pc0:08X}, Text size: {text_size} ({text_size/1024:.1f}KB)")
    
    # Check HBD string and FMV NOPs in EXE
    exe_full = bytearray()
    for s in range(24, 500):
        exe_full.extend(read_sector(f, s))
    
    hbd_str = b'hbd1ps1d.q41'
    pos = exe_full.find(hbd_str)
    if pos >= 0:
        print(f"  HBD string 'hbd1ps1d.q41' found at EXE offset 0x{pos:X}")
    else:
        hbd_str2 = b'hbd1ps1d.w71'
        pos2 = exe_full.find(hbd_str2)
        if pos2 >= 0:
            print(f"  WARNING: HBD string still 'hbd1ps1d.w71' at EXE offset 0x{pos2:X}")
        else:
            print(f"  WARNING: No HBD string found in EXE!")
    
    for site_off in [0x26760, 0x2684C]:
        if site_off + 4 <= len(exe_full):
            val = struct.unpack_from('<I', exe_full, site_off)[0]
            print(f"  FMV seek site 0x{site_off:X}: 0x{val:08X} ({'NOP' if val == 0 else 'NOT NOPED'})")
