#!/usr/bin/env python3
"""
pipeline_rulebook.py — Master Operational Rulebook for the DQ4 Frankenstein Pipeline.

Enforces the Five Laws of the Frankenstein Pipeline as a hard gate between
agent reasoning and binary action. No patch, register rewrite, or LBA
redirection may pass without satisfying all five laws.

Law 1: Zero Blind Commits (VFS Gate)
    Every patch must pass golden_state.json verification AND have
    telemetry justification + simulation backing.

Law 2: Hardware Ground Truth (DuckStation Primacy)
    All telemetry must originate from the live DuckStation bridge.
    No synthetic or custom-core telemetry is accepted.

Law 3: Historical Vector Pre-Check
    Before any debugging analysis, the crash trace must be queried
    against the vector database. Historical fixes take priority.

Law 4: Deterministic C++ Surgery
    Python may only simulate, scan, and parse. Actual binary writes
    to disc images must go through the C++ core engine with bounds checking.

Law 5: Pipeline Continuity
    Every asset transformation must maintain symbol and pointer resolution.
    Any drift halts the build for a differential audit.

Usage:
    gate = PipelineRulebook()
    verdict = gate.evaluate(patch, telemetry, simulation, vector_matches)
    if verdict.approved:
        gate.execute(patch)
    else:
        print(verdict.rejection_reason)
"""

import json
import os
import struct
import time
from typing import Dict, List, Optional, Any, Tuple
from dataclasses import dataclass, field
from enum import Enum


class LawViolation(Enum):
    """Enumerated violation types for the five laws."""
    LAW1_NO_TELEMETRY = "Law1: No telemetry justification for patch"
    LAW1_NO_SIMULATION = "Law1: No simulation backing for patch"
    LAW1_GOLDEN_STATE_FAIL = "Law1: Patch fails golden_state.json verification"
    LAW2_NOT_DUCKSTATION = "Law2: Telemetry source is not DuckStation bridge"
    LAW2_STALE_TELEMETRY = "Law2: Telemetry is stale (>5s old)"
    LAW3_NO_VECTOR_CHECK = "Law3: No vector database pre-check performed"
    LAW3_HISTORICAL_IGNORED = "Law3: Historical fix available but not prioritized"
    LAW4_PYTHON_BINARY_WRITE = "Law4: Python attempting binary disc write (C++ required)"
    LAW4_NO_BOUNDS_CHECK = "Law4: Patch lacks bounds checking"
    LAW5_POINTER_DRIFT = "Law5: Pointer/symbol resolution drift detected"
    LAW5_ASSET_CHAIN_BROKEN = "Law5: Asset transformation chain broken"


@dataclass
class GateVerdict:
    """Verdict from the rulebook gate evaluation."""
    approved: bool
    law_violations: List[LawViolation] = field(default_factory=list)
    rejection_reason: str = ""
    telemetry_age: float = 0.0
    vector_checked: bool = False
    simulation_passed: bool = False
    golden_state_passed: bool = False
    timestamp: float = field(default_factory=time.time)

    def __str__(self):
        if self.approved:
            return f"[GATE] APPROVED — all 5 laws satisfied"
        lines = [f"[GATE] REJECTED — {len(self.law_violations)} violation(s):"]
        for v in self.law_violations:
            lines.append(f"  ✗ {v.value}")
        if self.rejection_reason:
            lines.append(f"  Detail: {self.rejection_reason}")
        return '\n'.join(lines)


class PipelineRulebook:
    """Master operational rulebook — the VFS Gate for all pipeline actions."""

    def __init__(self, golden_state_path: str = None,
                 vector_db=None,
                 base_dir: str = None):
        self.base_dir = base_dir or os.path.dirname(os.path.abspath(__file__))
        gs_path = golden_state_path or os.path.join(self.base_dir, 'golden_state.json')
        self.golden_state = self._load_golden_state(gs_path)
        self.vector_db = vector_db  # VectorDB instance (optional, lazy-loaded)
        self._vector_checked = False
        self._last_vector_matches = []
        self.enforcement_log: List[Dict] = []

        # Known pointer/symbol chain for Law 5
        self.pointer_chain = {
            'exe_lba': 24,
            'hbd_lba': 355,
            'original_hbd_lba': 354,
            'lba_delta': 1,
            'tree_addr': 0x80100000,
            'tree_size': 1480,
            'copy_routine': 0x800BCCF0,
            'bss_clear_entry': 0x8008E284,
            'thread_entry': 0x800D9E80,
            'bss_start': 0x800BC668,
            'bss_end_original': 0x800F4980,
            'bss_end_narrowed': 0x800BCCC8,
            'trampoline': 0x801005C8,
        }

    def _load_golden_state(self, path: str) -> Dict:
        """Load golden_state.json for Law 1 verification."""
        if os.path.exists(path):
            with open(path, 'r', encoding='utf-8', errors='replace') as f:
                return json.load(f)
        return {}

    def evaluate(self, patch: Dict[str, Any],
                 telemetry: Dict[str, Any],
                 simulation: Dict[str, Any],
                 vector_matches: List[Dict] = None,
                 source: str = "duckstation_bridge") -> GateVerdict:
        """Evaluate a proposed patch against all 5 laws.

        Args:
            patch: Proposed patch dict with action, address, value, etc.
            telemetry: Live telemetry from DuckStation bridge
            simulation: Simulation result dict
            vector_matches: Results from vector DB query (Law 3)
            source: Telemetry source identifier (must be duckstation for Law 2)

        Returns:
            GateVerdict indicating approval or rejection with violations
        """
        violations = []

        # ── Law 1: Zero Blind Commits ────────────────────────────────
        sim_passed = simulation.get('result') == 'PASS'
        has_telemetry = telemetry is not None and 'Last_Known_PC' in telemetry
        golden_ok = self._check_golden_state(patch, telemetry)

        if not has_telemetry:
            violations.append(LawViolation.LAW1_NO_TELEMETRY)
        if not sim_passed and patch.get('action') == 'WRITE_MEM':
            violations.append(LawViolation.LAW1_NO_SIMULATION)
        if not golden_ok and patch.get('action') == 'WRITE_MEM':
            violations.append(LawViolation.LAW1_GOLDEN_STATE_FAIL)

        # ── Law 2: Hardware Ground Truth ──────────────────────────────
        if source != "duckstation_bridge":
            violations.append(LawViolation.LAW2_NOT_DUCKSTATION)

        # Check telemetry freshness
        tel_time = telemetry.get('timestamp', 0)
        if tel_time > 0:
            age = time.time() - tel_time
            if age > 5.0:
                violations.append(LawViolation.LAW2_STALE_TELEMETRY)

        # ── Law 3: Historical Vector Pre-Check ────────────────────────
        if vector_matches is None:
            violations.append(LawViolation.LAW3_NO_VECTOR_CHECK)
        else:
            self._vector_checked = True
            self._last_vector_matches = vector_matches
            # Check if a historical fix is available but not prioritized
            for match in vector_matches:
                if match.get('match_type') == 'STRUCTURED':
                    hf = match.get('historical_failure', {})
                    if hf.get('status') in ('FIXED', 'PATCHED_AT_BUILD_TIME'):
                        # Historical fix exists — is the patch using it?
                        fix_addr = hf.get('fix_address')
                        patch_addr = patch.get('address', '')
                        if isinstance(patch_addr, str) and isinstance(fix_addr, int):
                            try:
                                pa = int(patch_addr, 16)
                                if pa != fix_addr and patch.get('action') == 'WRITE_MEM':
                                    violations.append(LawViolation.LAW3_HISTORICAL_IGNORED)
                                    break
                            except ValueError:
                                pass

        # ── Law 4: Deterministic C++ Surgery ──────────────────────────
        action = patch.get('action', '')
        if action in ('WRITE_DISC', 'WRITE_SECTOR', 'WRITE_ROM'):
            # Binary disc writes must go through C++ engine
            if not patch.get('cpp_engine', False):
                violations.append(LawViolation.LAW4_PYTHON_BINARY_WRITE)
            if not patch.get('bounds_checked', False):
                violations.append(LawViolation.LAW4_NO_BOUNDS_CHECK)

        # ── Law 5: Pipeline Continuity ────────────────────────────────
        if action == 'WRITE_MEM':
            addr_str = patch.get('address', '0x0')
            try:
                addr = int(addr_str, 16) if isinstance(addr_str, str) else addr_str
            except ValueError:
                addr = 0

            # Check if patch address is in a known collision zone
            if self._check_pointer_drift(addr, patch.get('value', '0x0')):
                violations.append(LawViolation.LAW5_POINTER_DRIFT)

        # ── Assemble verdict ──────────────────────────────────────────
        approved = len(violations) == 0
        reason = ""
        if not approved:
            reason = '; '.join(v.value for v in violations)

        verdict = GateVerdict(
            approved=approved,
            law_violations=violations,
            rejection_reason=reason,
            telemetry_age=time.time() - tel_time if tel_time > 0 else 0,
            vector_checked=self._vector_checked,
            simulation_passed=sim_passed,
            golden_state_passed=golden_ok,
        )

        # Log the evaluation
        self.enforcement_log.append({
            'timestamp': time.time(),
            'approved': approved,
            'action': action,
            'address': patch.get('address', '?'),
            'violations': [v.value for v in violations],
            'sim_passed': sim_passed,
            'golden_passed': golden_ok,
            'vector_checked': self._vector_checked,
        })

        return verdict

    def _check_golden_state(self, patch: Dict, telemetry: Dict) -> bool:
        """Verify patch against golden_state.json (Law 1)."""
        if not self.golden_state:
            return True  # No golden state defined — pass

        action = patch.get('action', '')
        if action != 'WRITE_MEM':
            return True  # Non-write actions don't need golden state check

        # Check memory checkpoints
        checkpoints = self.golden_state.get('memory_checkpoints', [])
        for cp in checkpoints:
            addr_str = cp.get('addr', '')
            expected = cp.get('expected', '')
            try:
                cp_addr = int(addr_str, 16)
            except ValueError:
                continue

            # If patch writes to a checkpoint address, verify it doesn't violate
            patch_addr_str = patch.get('address', '0x0')
            try:
                patch_addr = int(patch_addr_str, 16)
            except ValueError:
                patch_addr = 0

            if patch_addr == cp_addr:
                if expected == "non-zero":
                    val_str = patch.get('value', '0x0')
                    try:
                        val = int(val_str, 16) if isinstance(val_str, str) else val_str
                    except ValueError:
                        val = 0
                    if val == 0:
                        return False  # Would write zero to a non-zero checkpoint

        # Check register checkpoints
        reg_checks = self.golden_state.get('register_checkpoints', {})
        for pc_str, expected_regs in reg_checks.items():
            for reg_name, expected_val in expected_regs.items():
                if reg_name.startswith('_'):
                    continue
                # These are verified at runtime, not at patch time
                pass

        return True

    def _check_pointer_drift(self, addr: int, value: Any) -> bool:
        """Check if a patch would cause pointer/symbol drift (Law 5)."""
        try:
            if isinstance(value, str):
                val = int(value, 16)
            else:
                val = value
        except (ValueError, TypeError):
            return False

        # Check if writing to the HBD LBA pointer without correct value
        if addr == 0x8003A94 or addr == 0x8003A98:
            # LBA pointer — must be 355 (0x163)
            if val != 355 and val != 0x163:
                return True  # Drift!

        # Check if writing to tree address with wrong value
        if addr == 0x80100000 and val == 0:
            return True  # Would zero the tree — drift

        # Check if writing to thread entry with zero
        if addr == 0x800D9E80 and val == 0:
            return True  # Would zero thread entry — drift

        return False

    def require_vector_precheck(self, telemetry: Dict) -> List[Dict]:
        """Law 3: Query vector DB before any debugging analysis.

        Returns vector matches for the given telemetry.
        """
        if self.vector_db is None:
            from vector_db import VectorDB
            self.vector_db = VectorDB(base_dir=self.base_dir)
            self.vector_db.build_index()

        matches = self.vector_db.query(telemetry, top_k=5)
        self._vector_checked = True
        self._last_vector_matches = matches
        return matches

    def enforce_cpp_surgery(self, patch: Dict) -> Dict:
        """Law 4: Route binary disc writes through C++ engine.

        Returns the patch annotated with C++ execution requirements.
        """
        action = patch.get('action', '')
        if action in ('WRITE_DISC', 'WRITE_SECTOR', 'WRITE_ROM'):
            patch['cpp_engine'] = True
            patch['bounds_checked'] = True
            patch['cpp_command'] = self._build_cpp_command(patch)
        return patch

    def _build_cpp_command(self, patch: Dict) -> str:
        """Build C++ engine command for binary surgery."""
        addr = patch.get('address', '0x0')
        value = patch.get('value', '0x0')
        desc = patch.get('description', '')
        return (f"rom_graft_verifier --write --addr {addr} "
                f"--value {value} --desc \"{desc}\" --verify")

    def check_pipeline_continuity(self, asset_chain: List[Dict]) -> Tuple[bool, str]:
        """Law 5: Verify asset transformation chain integrity.

        Args:
            asset_chain: List of transformation steps from DQ4 source to final ROM

        Returns:
            (ok, message) — True if chain is intact, False with reason if broken
        """
        for i, step in enumerate(asset_chain):
            step_name = step.get('name', f'step_{i}')
            inputs = step.get('inputs', [])
            outputs = step.get('outputs', [])

            # Check that each output has resolved pointers
            for out in outputs:
                if out.get('unresolved_symbols'):
                    return False, f"{step_name}: unresolved symbols in output"
                if out.get('pointer_drift'):
                    return False, f"{step_name}: pointer drift detected"

            # Check that inputs match previous outputs
            if i > 0:
                prev_outputs = asset_chain[i-1].get('outputs', [])
                for inp in inputs:
                    if not any(inp.get('id') == po.get('id') for po in prev_outputs):
                        return False, (f"{step_name}: input {inp.get('id')} "
                                      f"not found in previous step outputs")

        return True, "Pipeline continuity intact"

    def get_enforcement_summary(self) -> Dict:
        """Get a summary of all gate evaluations."""
        total = len(self.enforcement_log)
        approved = sum(1 for e in self.enforcement_log if e['approved'])
        rejected = total - approved
        violation_counts = {}
        for e in self.enforcement_log:
            for v in e.get('violations', []):
                violation_counts[v] = violation_counts.get(v, 0) + 1

        return {
            'total_evaluations': total,
            'approved': approved,
            'rejected': rejected,
            'approval_rate': approved / total if total > 0 else 0,
            'top_violations': sorted(violation_counts.items(),
                                    key=lambda x: x[1], reverse=True)[:5],
        }
