# Fast: search EXE for jal/j to 0x800A20F8
# 0x800A20F8 >> 2 = 0x02883E
# jal = 0x0C02883E, j = 0x0802883E
$exePath = 'c:\LuxAura\VoidWalkers_Project\DQLOSTTRANSLATION\translation\SLUSP012.06'
$bytes = [System.IO.File]::ReadAllBytes($exePath)
$loadAddr = 0x80017F00

$target = 0x02883E
$results = @()
for ($i = 0x800; $i -lt $bytes.Length - 3; $i += 4) {
    $insn = [BitConverter]::ToUInt32($bytes, $i)
    $op = $insn -shr 26
    if (($op -eq 2 -or $op -eq 3) -and (($insn -band 0x3FFFFFF) -eq $target)) {
        $ram = $loadAddr + $i - 0x800
        $type = if ($op -eq 3) { 'jal' } else { 'j' }
        $results += [PSCustomObject]@{RAM=$ram; File=$i; Type=$type}
    }
}
Write-Host "Found $($results.Count) callers of Setloc (0x800A20F8)"
foreach ($r in $results) {
    # Show 6 instructions before
    Write-Host ""
    Write-Host "--- $($r.Type) at RAM 0x$($r.RAM.ToString('X8')) ---"
    for ($k = -6; $k -le 1; $k++) {
        $off = $r.File + $k * 4
        if ($off -lt 0x800 -or $off + 3 -ge $bytes.Length) { continue }
        $val = [BitConverter]::ToUInt32($bytes, $off)
        $ram2 = $loadAddr + $off - 0x800
        $op = $val -shr 26
        $imm = $val -band 0xFFFF
        if ($imm -ge 0x8000) { $immS = $imm - 0x10000 } else { $immS = $imm }
        $rs = ($val -shr 21) -band 0x1F
        $rt = ($val -shr 16) -band 0x1F
        $rn = @('zero','at','v0','v1','a0','a1','a2','a3','t0','t1','t2','t3','t4','t5','t6','t7','s0','s1','s2','s3','s4','s5','s6','s7','t8','t9','k0','k1','gp','sp','fp','ra')
        $rsn=$rn[$rs]; $rtn=$rn[$rt]
        $d = ''
        if ($val -eq 0) { $d = 'nop' }
        elseif ($op -eq 0x09) { $d = "addiu $rtn,$rsn,$immS" }
        elseif ($op -eq 0x0F) { $d = "lui $rtn,0x$($imm.ToString('X4'))" }
        elseif ($op -eq 0x0D) { $d = "ori $rtn,$rsn,0x$($imm.ToString('X4'))" }
        elseif ($op -eq 0x23) { $d = "lw $rtn,0x$($imm.ToString('X4'))($rsn)" }
        elseif ($op -eq 0x21) { $d = "lh $rtn,0x$($imm.ToString('X4'))($rsn)" }
        elseif ($op -eq 0x24) { $d = "lbu $rtn,0x$($imm.ToString('X4'))($rsn)" }
        elseif ($op -eq 0x20) { $d = "lb $rtn,0x$($imm.ToString('X4'))($rsn)" }
        elseif ($op -eq 0x28) { $d = "sb $rtn,0x$($imm.ToString('X4'))($rsn)" }
        elseif ($op -eq 0x2B) { $d = "sw $rtn,0x$($imm.ToString('X4'))($rsn)" }
        elseif ($op -eq 0x03) { $t2=($val -band 0x3FFFFFF)-shl 2; $d="jal 0x$($t2.ToString('X8'))" }
        elseif ($op -eq 0x02) { $t2=($val -band 0x3FFFFFF)-shl 2; $d="j 0x$($t2.ToString('X8'))" }
        elseif ($op -eq 0x00 -and ($val -band 0x3F) -eq 0x08) { $d="jr $rsn" }
        elseif ($op -eq 0x00 -and ($val -band 0x3F) -eq 0x21) { $rd=($val -shr 11)-band 0x1F; $d="addu $($rn[$rd]),$rsn,$rtn" }
        else { $d="op=0x$($op.ToString('X2'))" }
        $m = if ($k -eq 0) { ' <<<' } else { '' }
        Write-Host ("  0x{0:X8}: 0x{1:X8}  {2}{3}" -f $ram2, $val, $d, $m)
    }
}
