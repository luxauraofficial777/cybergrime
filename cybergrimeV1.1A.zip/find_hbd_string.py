#!/usr/bin/env python3
"""Search DW7 EXE for HBD filename string and trace how HBD is located on disc."""
import struct

exe_path = r'..\translation\SLUSP012.06_disc_extract.bin'
with open(exe_path, 'rb') as f:
    data = f.read()

print(f'EXE size: {len(data)} bytes')
LOAD_ADDR = 0x80017F00

def file_to_ram(off):
    return LOAD_ADDR + off - 0x800

# 1. Search for HBD1PS1D.W71 string
print('\n=== HBD1PS1D string search ===')
target = b'HBD1PS1D'
pos = 0
hits = []
while True:
    idx = data.find(target, pos)
    if idx == -1:
        break
    s = data[idx:idx+32]
    null_pos = s.find(b'\x00')
    if null_pos >= 0:
        s = s[:null_pos]
    ram = file_to_ram(idx)
    print(f'  Found at file 0x{idx:X} (RAM 0x{ram:08X}): "{s.decode("ascii", errors="replace")}"')
    hits.append(idx)
    pos = idx + 1
print(f'Total hits: {len(hits)}')

# 2. Search for any string containing "HBD"
print('\n=== Broad HBD string search ===')
target2 = b'HBD'
pos = 0x800
hbd_hits = []
while True:
    idx = data.find(target2, pos)
    if idx == -1:
        break
    context = data[idx:idx+20]
    if all(32 <= b < 127 or b == 0 for b in context[:8]):
        s = data[idx:idx+32]
        null_pos = s.find(b'\x00')
        if null_pos >= 0:
            s = s[:null_pos]
        ram = file_to_ram(idx)
        hbd_hits.append((idx, ram, s.decode("ascii", errors="replace")))
    pos = idx + 1
print(f'HBD string-like hits: {len(hbd_hits)}')
for off, ram, s in hbd_hits[:15]:
    print(f'  file 0x{off:X} (RAM 0x{ram:08X}): "{s}"')

# 3. Search for xrefs to the HBD string location (if found)
if hits:
    print('\n=== Xrefs to HBD string ===')
    for hit_off in hits:
        hit_ram = file_to_ram(hit_off)
        # Search for lui/addiu pairs that construct this address
        hi16 = (hit_ram >> 16) & 0xFFFF
        lo16 = hit_ram & 0xFFFF
        # Handle sign extension
        if lo16 >= 0x8000:
            hi16_adj = (hi16 + 1) & 0xFFFF
        else:
            hi16_adj = hi16

        print(f'\n  Target: file 0x{hit_off:X} RAM 0x{hit_ram:08X}')
        print(f'  Looking for lui {hi16_adj:04X} + addiu {lo16:04X}')

        # Search for lui with this immediate
        lui_val = 0x3C000000 | (hi16_adj & 0xFFFF)  # lui $0, hi16 (any reg)
        for i in range(0x800, len(data) - 4, 4):
            insn = struct.unpack('<I', data[i:i+4])[0]
            if (insn & 0xFFFF0000) == (lui_val & 0xFFE00000) and ((insn >> 16) & 0x1F) != 0:
                # Check if next instruction is addiu with lo16
                if i + 8 <= len(data):
                    next_insn = struct.unpack('<I', data[i+4:i+8])[0]
                    if (next_insn >> 26) == 0x09 and (next_insn & 0xFFFF) == lo16:
                        reg = (insn >> 16) & 0x1F
                        ram = file_to_ram(i)
                        print(f'    lui ${reg}, 0x{hi16_adj:04X} at file 0x{i:X} (RAM 0x{ram:08X})')
                        ram2 = file_to_ram(i+4)
                        print(f'    addiu ${reg}, ${reg}, 0x{lo16:04X} at file 0x{i+4:X} (RAM 0x{ram2:08X})')

# 4. Search for CdReadFile / open / searchfile BIOS calls
# A0:44 = open, A0:54 = firstfile, A0:55 = nextfile, A0:4C = CdReadFile
# These are JAL to 0x000A0xxxx region (BIOS A0 table)
print('\n=== BIOS file call search ===')
# Look for JAL to A0 table entries (0xA0 + function*4 for the A0 handler)
# In PSX, A0 functions are at 0xA0 + n*4 in the call table
# But the actual JAL target for A0 functions is 0x000001xx range
# Actually, PSX BIOS A0 calls go through 0xA0 table at address 0xA0
# The JAL encoding: 0x0Cxxxxxx where xxxxxx = target/4

# Search for the string "SLUS" or "HBD" in the first 0x1000 bytes (header area)
print('\n=== SYSTEM.CNF and boot strings ===')
for s in [b'SLUS', b'SYSTEM', b'BPSX', b'PS-X', b'HBD1', b'cdrom', b'CDROM']:
    idx = data.find(s, 0x800)
    if idx != -1:
        context = data[idx:idx+32]
        null_pos = context.find(b'\x00')
        if null_pos >= 0:
            context = context[:null_pos]
        ram = file_to_ram(idx)
        print(f'  "{context.decode("ascii", errors="replace")}" at file 0x{idx:X} (RAM 0x{ram:08X})')

# 5. Search for LBA 354 (0x162) as a 32-bit or 16-bit value
print('\n=== LBA 354 (0x162) search ===')
lba_val = 354
for i in range(0x800, len(data) - 3, 4):
    val32 = struct.unpack('<I', data[i:i+4])[0]
    if val32 == lba_val:
        ram = file_to_ram(i)
        # Check surrounding context
        print(f'  32-bit 0x162 at file 0x{i:X} (RAM 0x{ram:08X})')
        # Show surrounding instructions
        for j in range(-8, 12, 4):
            if 0x800 <= i+j and i+j+4 <= len(data):
                insn = struct.unpack('<I', data[i+j:i+j+4])[0]
                r = file_to_ram(i+j)
                print(f'    0x{r:08X}: 0x{insn:08X}')

# 6. Search for MSF encoding of LBA 354
# LBA 354 = MSF: 354/75 = 4.72 -> min=0, sec=4, frame=54 -> BCD: 0x00, 0x04, 0x36
# Actually: 354 = 4*75 + 54, so M=0, S=4, F=54 -> BCD: 0x00, 0x04, 0x36
print('\n=== MSF BCD for LBA 354 search ===')
msf_pattern = bytes([0x00, 0x04, 0x36])
pos = 0x800
while True:
    idx = data.find(msf_pattern, pos)
    if idx == -1:
        break
    ram = file_to_ram(idx)
    print(f'  MSF 00:04:36 at file 0x{idx:X} (RAM 0x{ram:08X})')
    pos = idx + 1

# 7. Search for ISO directory-related strings
print('\n=== ISO/CD-related strings ===')
for s in [b'cdrom:', b'CDROM:', b'cdrom\\', b'\\HBD', b'/HBD', b'.W71', b'.W7', b'.Q41']:
    pos = 0x800
    while True:
        idx = data.find(s, pos)
        if idx == -1:
            break
        context = data[max(0, idx-16):idx+32]
        ram = file_to_ram(idx)
        # Try to get full string
        full = data[idx:idx+32]
        null_pos = full.find(b'\x00')
        if null_pos >= 0:
            full = full[:null_pos]
        print(f'  "{full.decode("ascii", errors="replace")}" at file 0x{idx:X} (RAM 0x{ram:08X})')
        pos = idx + 1

print('\n=== Done ===')
