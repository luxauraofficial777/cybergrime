#!/usr/bin/env python3
"""Trace bootstrap 0x8004F344 in detail"""
import struct

def read_sector(disc, lba):
    return disc[lba * 2352 + 24: lba * 2352 + 24 + 2048]

def read_exe_from_disc(disc_path, exe_lba, exe_size):
    with open(disc_path, 'rb') as f:
        disc = f.read()
    exe = bytearray()
    sectors = (exe_size + 2047) // 2048
    for i in range(sectors):
        exe.extend(read_sector(disc, exe_lba + i))
    return bytes(exe[:exe_size])

DISC = r'c:\LuxAura\VoidWalkers_Project\DQLOSTTRANSLATION\dq4_phaseC_build1.bin'
exe = read_exe_from_disc(DISC, 24, 960948)
DW7_DISC = r'c:\LuxAura\VoidWalkers_Project\DQLOSTTRANSLATION\DW7D1\DW7D1.bin'
dw7_exe = read_exe_from_disc(DW7_DISC, 24, 675840)

LOAD_ADDR = 0x80017F00
EXE_HEADER = 0x800

def ram_to_file(ram):
    return ram - LOAD_ADDR + EXE_HEADER

def read_word(data, ram):
    foff = ram_to_file(ram)
    if foff + 4 <= len(data):
        return struct.unpack_from('<I', data, foff)[0]
    return None

def disasm(word, pc):
    if word == 0: return "nop"
    op = (word >> 26) & 0x3F
    rs = (word >> 21) & 0x1F
    rt = (word >> 16) & 0x1F
    rd = (word >> 11) & 0x1F
    shamt = (word >> 6) & 0x1F
    funct = word & 0x3F
    imm = word & 0xFFFF
    s_imm = imm - 65536 if imm >= 32768 else imm
    target = word & 0x03FFFFFF
    regs = ['zero','at','v0','v1','a0','a1','a2','a3','t0','t1','t2','t3','t4','t5','t6','t7','s0','s1','s2','s3','s4','s5','s6','s7','t8','t9','k0','k1','gp','sp','fp','ra']
    if op == 0:
        if funct == 0x08: return f"jr {regs[rs]}"
        if funct == 0x09: return f"jalr {regs[rd]}, {regs[rs]}"
        if funct == 0x20: return f"add {regs[rd]}, {regs[rs]}, {regs[rt]}"
        if funct == 0x21: return f"addu {regs[rd]}, {regs[rs]}, {regs[rt]}"
        if funct == 0x23: return f"subu {regs[rd]}, {regs[rs]}, {regs[rt]}"
        if funct == 0x24: return f"and {regs[rd]}, {regs[rs]}, {regs[rt]}"
        if funct == 0x25: return f"or {regs[rd]}, {regs[rs]}, {regs[rt]}"
        if funct == 0x2A: return f"slt {regs[rd]}, {regs[rs]}, {regs[rt]}"
        if funct == 0x2B: return f"sltu {regs[rd]}, {regs[rs]}, {regs[rt]}"
        if funct == 0x00: return f"sll {regs[rd]}, {regs[rt]}, {shamt}" if rd != 0 else "nop"
        if funct == 0x02: return f"srl {regs[rd]}, {regs[rt]}, {shamt}"
        if funct == 0x03: return f"sra {regs[rd]}, {regs[rt]}, {shamt}"
        if funct == 0x0C: return f"syscall 0x{(word >> 6) & 0xFFFFF:05X}"
        if funct == 0x10: return f"mfhi {regs[rd]}"
        if funct == 0x12: return f"mflo {regs[rd]}"
        if funct == 0x18: return f"mult {regs[rs]}, {regs[rt]}"
        if funct == 0x19: return f"multu {regs[rs]}, {regs[rt]}"
        if funct == 0x1A: return f"div {regs[rs]}, {regs[rt]}"
        if funct == 0x1B: return f"divu {regs[rs]}, {regs[rt]}"
        return f"special 0x{funct:02X}"
    if op == 0x01:
        if rt == 0: return f"bltz {regs[rs]}, 0x{pc + 4 + (s_imm << 2):08X}"
        if rt == 1: return f"bgez {regs[rs]}, 0x{pc + 4 + (s_imm << 2):08X}"
        return f"regimm {rt}"
    if op == 0x02: return f"j 0x{(pc & 0xF0000000) | (target << 2):08X}"
    if op == 0x03: return f"jal 0x{(pc & 0xF0000000) | (target << 2):08X}"
    if op == 0x04: return f"beq {regs[rs]}, {regs[rt]}, 0x{pc + 4 + (s_imm << 2):08X}"
    if op == 0x05: return f"bne {regs[rs]}, {regs[rt]}, 0x{pc + 4 + (s_imm << 2):08X}"
    if op == 0x06: return f"blez {regs[rs]}, 0x{pc + 4 + (s_imm << 2):08X}"
    if op == 0x07: return f"bgtz {regs[rs]}, 0x{pc + 4 + (s_imm << 2):08X}"
    if op == 0x08: return f"addi {regs[rt]}, {regs[rs]}, {s_imm}"
    if op == 0x09: return f"addiu {regs[rt]}, {regs[rs]}, {s_imm}"
    if op == 0x0A: return f"slti {regs[rt]}, {regs[rs]}, {s_imm}"
    if op == 0x0B: return f"sltiu {regs[rt]}, {regs[rs]}, {s_imm}"
    if op == 0x0C: return f"andi {regs[rt]}, {regs[rs]}, 0x{imm:04X}"
    if op == 0x0D: return f"ori {regs[rt]}, {regs[rs]}, 0x{imm:04X}"
    if op == 0x0E: return f"xori {regs[rt]}, {regs[rs]}, 0x{imm:04X}"
    if op == 0x0F: return f"lui {regs[rt]}, 0x{imm:04X}"
    if op == 0x20: return f"lb {regs[rt]}, {s_imm}({regs[rs]})"
    if op == 0x21: return f"lh {regs[rt]}, {s_imm}({regs[rs]})"
    if op == 0x23: return f"lw {regs[rt]}, {s_imm}({regs[rs]})"
    if op == 0x24: return f"lbu {regs[rt]}, {s_imm}({regs[rs]})"
    if op == 0x25: return f"lhu {regs[rt]}, {s_imm}({regs[rs]})"
    if op == 0x28: return f"sb {regs[rt]}, {s_imm}({regs[rs]})"
    if op == 0x29: return f"sh {regs[rt]}, {s_imm}({regs[rs]})"
    if op == 0x2B: return f"sw {regs[rt]}, {s_imm}({regs[rs]})"
    if op == 0x10:
        if rs == 0: return f"mfc0 {regs[rt]}, ${rd}"
        if rs == 4: return f"mtc0 {regs[rt]}, ${rd}"
        if rs == 0x10 and funct == 0x18: return "eret"
        return f"cop0 rs={rs} rd=${rd}"
    if op == 0x12:
        if rs == 0: return f"mfc2 {regs[rt]}, ${rd}"
        if rs == 2: return f"cfc2 {regs[rt]}, ${rd}"
        if rs == 4: return f"mtc2 {regs[rt]}, ${rd}"
        if rs == 6: return f"ctc2 {regs[rt]}, ${rd}"
        if rs == 0x10: return f"cop2 0x{word & 0x7FF:03X}"
        return f"cop2 rs={rs}"
    return f"op=0x{op:02X}"

def show(data, start, count, label=""):
    if label: print(f"\n--- {label} ---")
    for i in range(count):
        ram = start + i * 4
        w = read_word(data, ram)
        if w is None:
            print(f"  0x{ram:08X}: <beyond EXE>")
            break
        d = disasm(w, ram)
        print(f"  0x{ram:08X}: 0x{w:08X}  {d}")

# Bootstrap at 0x8004F344 — trace the full function
print("=" * 70)
print("BOOTSTRAP 0x8004F344 (Frank — first 80 instructions)")
print("=" * 70)
show(exe, 0x8004F344, 80, "Frank")

print("\n" + "=" * 70)
print("BOOTSTRAP 0x8004F344 (DW7 — first 80 instructions)")
print("=" * 70)
show(dw7_exe, 0x8004F344, 80, "DW7")

# Check the BSS clear exit / redirect at 0x8008E2B0
print("\n" + "=" * 70)
print("BSS CLEAR EXIT (0x8008E2A0-0x8008E2C0)")
print("=" * 70)
show(exe, 0x8008E2A0, 8, "Frank")
show(dw7_exe, 0x8008E2A0, 8, "DW7")

# Check what's at 0x8008E284 (PC0 entry) leading up to the redirect
print("\n" + "=" * 70)
print("PC0 ENTRY (0x8008E284)")
print("=" * 70)
show(exe, 0x8008E284, 16, "Frank")
show(dw7_exe, 0x8008E284, 16, "DW7")

# Check the CD-ROM polling code at 0x80098BD4
print("\n" + "=" * 70)
print("CD-ROM POLLING (0x80098BA0-0x80098C00)")
print("=" * 70)
show(exe, 0x80098BA0, 24, "Frank")
show(dw7_exe, 0x80098BA0, 24, "DW7")

# Check 0x800980C8 (where CD-ROM status is read)
print("\n" + "=" * 70)
print("CD-ROM STATUS READ (0x800980C0)")
print("=" * 70)
show(exe, 0x800980C0, 16, "Frank")
show(dw7_exe, 0x800980C0, 16, "DW7")

# Check 0x80098664 (CD-ROM command write)
print("\n" + "=" * 70)
print("CD-ROM CMD WRITE (0x80098660)")
print("=" * 70)
show(exe, 0x80098660, 16, "Frank")
show(dw7_exe, 0x80098660, 16, "DW7")
