import struct, os

dw7_disc = r"c:\LuxAura\VoidWalkers_Project\DQLOSTTRANSLATION\DW7D1\DW7D1.bin"
sector_size = 2352
data_offset = 24
user_size = 2048

with open(dw7_disc, 'rb') as f:
    # PVD
    f.seek(16 * sector_size + data_offset)
    pvd = f.read(user_size)
    print(f"DW7 Volume ID: {pvd[40:72].decode('ascii', errors='replace').strip()}")
    
    # Root dir at offset 156
    root_rec = pvd[156:156+34]
    root_lba = struct.unpack_from('<I', root_rec, 2)[0]
    root_size = struct.unpack_from('<I', root_rec, 10)[0]
    print(f"Root directory: LBA={root_lba}, size={root_size}")
    
    f.seek(root_lba * sector_size + data_offset)
    dir_data = f.read(root_size)
    
    pos = 0
    while pos < len(dir_data):
        rec_len = dir_data[pos]
        if rec_len == 0:
            break
        if pos + 33 <= len(dir_data):
            file_lba = struct.unpack_from('<I', dir_data, pos + 2)[0]
            file_size_val = struct.unpack_from('<I', dir_data, pos + 10)[0]
            flags = dir_data[pos + 25]
            name_len = dir_data[pos + 32]
            name = dir_data[pos + 33:pos + 33 + name_len]
            ftype = "DIR " if flags & 0x02 else "FILE"
            name_str = name.decode('ascii', errors='replace').rstrip('\x00')
            if ';' in name_str:
                name_str = name_str.split(';')[0]
            print(f"  {ftype} '{name_str}': LBA={file_lba}, size={file_size_val}")
        pos += rec_len
    
    # SYSTEM.CNF
    f.seek(23 * sector_size + data_offset)
    cnf = f.read(user_size)
    cnf_text = cnf.decode('ascii', errors='replace')
    null_pos = cnf_text.find('\x00')
    if null_pos > 0:
        cnf_text = cnf_text[:null_pos]
    print(f"\nDW7 SYSTEM.CNF:\n{cnf_text}")
    
    # EXE header at sector 24
    f.seek(24 * sector_size + data_offset)
    exe_hdr = f.read(64)
    print(f"\nDW7 EXE header:")
    print(f"  Magic: {exe_hdr[:8]}")
    if exe_hdr[:4] == b'PS-X':
        load_addr = struct.unpack_from('<I', exe_hdr, 0x10)[0]
        text_size = struct.unpack_from('<I', exe_hdr, 0x1C)[0]
        pc0 = struct.unpack_from('<I', exe_hdr, 0x14)[0]
        print(f"  load_addr=0x{load_addr:08X}, text_size=0x{text_size:08X} ({text_size}), pc0=0x{pc0:08X}")
    
    # HBD at sector 354
    f.seek(354 * sector_size + data_offset)
    hbd_hdr = f.read(24)
    end, bid, hts, te, xe, unk = struct.unpack_from('<6I', hbd_hdr, 0)
    print(f"\nDW7 HBD (sector 354): end={end} bid={bid} hts={hts} tree_end={te} text_end={xe}")

# DQ4 EXE header comparison
dq4_disc = r"c:\LuxAura\VoidWalkers_Project\DQLOSTTRANSLATION\Dragon Quest IV - Michibikareshi Mono Tachi (Japan).bin"
with open(dq4_disc, 'rb') as f:
    f.seek(24 * sector_size + data_offset)
    exe_hdr = f.read(64)
    print(f"\nDQ4 EXE header:")
    print(f"  Magic: {exe_hdr[:8]}")
    if exe_hdr[:4] == b'PS-X':
        load_addr = struct.unpack_from('<I', exe_hdr, 0x10)[0]
        text_size = struct.unpack_from('<I', exe_hdr, 0x1C)[0]
        pc0 = struct.unpack_from('<I', exe_hdr, 0x14)[0]
        print(f"  load_addr=0x{load_addr:08X}, text_size=0x{text_size:08X} ({text_size}), pc0=0x{pc0:08X}")

print("\n=== COMPARISON TABLE ===")
print(f"{'Property':<25} {'DQ4':<30} {'DW7':<30}")
print(f"{'Volume ID':<25} {'DRAGONQUEST4_1':<30} {'DRAGONWARRIOR7_1':<30}")
print(f"{'EXE name':<25} {'SLPM_869.16':<30} {'SLUSP012.06':<30}")
print(f"{'EXE LBA':<25} {'24':<30} {'24':<30}")
print(f"{'HBD LBA':<25} {'362':<30} {'354':<30}")
print(f"{'HBD name':<25} {'HBD1PS1D.Q41':<30} {'HBD1PS1D.W71':<30}")
print(f"{'SYSTEM.CNF BOOT':<25} {'SLPM_869.16':<30} {'SLUSP012.06':<30}")
print(f"{'EXE load_addr':<25} {'0x800918F4':<30} {'0x80017F00':<30}")
print(f"{'EXE text_size':<25} {'690176':<30} {'673792':<30}")
print(f"{'EXE pc0':<25} {'0x00000000*':<30} {'0x8008E284':<30}")
print(f"{'EXE size on disc':<25} {'692224':<30} {'675840':<30}")
print(f"{'HBD size':<25} {'319436800':<30} {'618563584':<30}")
print(f"{'Disc sectors':<25} {'156487':<30} {'~302537':<30}")
print(f"{'* pc0=0 means entry point at load_addr+0x10':<25}")
