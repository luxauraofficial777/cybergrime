# Search for direct jal 0xB0 (0x0C00002C) with li t1, 7 nearby
# Also search for jal 0xA0, jal 0xC0 patterns
$exePath = 'c:\LuxAura\VoidWalkers_Project\DQLOSTTRANSLATION\translation\SLUSP012.06'
$bytes = [System.IO.File]::ReadAllBytes($exePath)
$loadAddr = 0x80017F00

$rn = @('zero','at','v0','v1','a0','a1','a2','a3','t0','t1','t2','t3','t4','t5','t6','t7','s0','s1','s2','s3','s4','s5','s6','s7','t8','t9','k0','k1','gp','sp','fp','ra')

# Search for jal 0xB0 = 0x0C00002C
Write-Host "=== All jal 0xB0 (BIOS B0 dispatch) ==="
$count = 0
for ($i = 0x800; $i -lt $bytes.Length - 3; $i += 4) {
    $insn = [BitConverter]::ToUInt32($bytes, $i)
    if ($insn -eq 0x0C00002C) {
        $ram = $loadAddr + $i - 0x800
        # Look for li t1, N in the 8 instructions before
        $funcNum = -1
        $funcAt = ''
        for ($k = 1; $k -le 8; $k++) {
            $prev = [BitConverter]::ToUInt32($bytes, $i - $k * 4)
            if (($prev -band 0xFFFF0000) -eq 0x24090000) {
                $funcNum = $prev -band 0xFFFF
                $funcAt = "t1=$funcNum at -${k}"
                break
            }
        }
        # Also check the delay slot (next instruction)
        $next = [BitConverter]::ToUInt32($bytes, $i + 4)
        $delayInfo = ''
        if (($next -band 0xFFFF0000) -eq 0x24090000) {
            $delayFunc = $next -band 0xFFFF
            $delayInfo = " delay_slot:t1=$delayFunc"
        }
        Write-Host ("  RAM 0x{0:X8}: jal 0xB0  {1}{2}" -f $ram, $funcAt, $delayInfo)
        $count++
    }
}
Write-Host "Total: $count"

# Also search for j 0xB0 = 0x0800002C
Write-Host ""
Write-Host "=== All j 0xB0 ==="
$count = 0
for ($i = 0x800; $i -lt $bytes.Length - 3; $i += 4) {
    $insn = [BitConverter]::ToUInt32($bytes, $i)
    if ($insn -eq 0x0800002C) {
        $ram = $loadAddr + $i - 0x800
        # Check prev for li t1
        $prev = [BitConverter]::ToUInt32($bytes, $i - 4)
        $funcNum = -1
        if (($prev -band 0xFFFF0000) -eq 0x24090000) { $funcNum = $prev -band 0xFFFF }
        Write-Host ("  RAM 0x{0:X8}: j 0xB0  t1={1}" -f $ram, $funcNum)
        $count++
    }
}
Write-Host "Total: $count"

# Also search for jr to a register loaded with 0xB0
# li t2, 0xB0 = 0x240A00B0, then jr t2 = 0x01400008
Write-Host ""
Write-Host "=== li t2, 0xB0 followed by jr t2 ==="
for ($i = 0x800; $i -lt $bytes.Length - 7; $i += 4) {
    $insn1 = [BitConverter]::ToUInt32($bytes, $i)
    $insn2 = [BitConverter]::ToUInt32($bytes, $i + 4)
    if ($insn1 -eq 0x240A00B0 -and $insn2 -eq 0x01400008) {
        $ram = $loadAddr + $i - 0x800
        # Check delay slot (i+8) for li t1
        $delay = [BitConverter]::ToUInt32($bytes, $i + 8)
        $funcNum = -1
        if (($delay -band 0xFFFF0000) -eq 0x24090000) { $funcNum = $delay -band 0xFFFF }
        Write-Host ("  RAM 0x{0:X8}: li t2,0xB0; jr t2; li t1,{1}" -f $ram, $funcNum)
    }
}
