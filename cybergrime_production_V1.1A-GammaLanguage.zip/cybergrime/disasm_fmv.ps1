$exePath = 'c:\LuxAura\VoidWalkers_Project\DQLOSTTRANSLATION\translation\SLUSP012.06'
$bytes = [System.IO.File]::ReadAllBytes($exePath)
$loadAddr = 0x80017F00

function Disasm($ramAddr, $count) {
    $fileOff = $ramAddr - $loadAddr + 0x800
    Write-Host "--- Disasm at RAM 0x$($ramAddr.ToString('X8')) (file 0x$($fileOff.ToString('X'))) ---"
    for ($j = 0; $j -lt $count; $j++) {
        $off = $fileOff + $j * 4
        if ($off -lt 0 -or $off + 3 -ge $bytes.Length) { continue }
        $val = [BitConverter]::ToUInt32($bytes, $off)
        $ram = $loadAddr + $off - 0x800
        $opcode = ($val -shr 26) -band 0x3F
        $rs = ($val -shr 21) -band 0x1F
        $rt = ($val -shr 16) -band 0x1F
        $rd = ($val -shr 11) -band 0x1F
        $imm = $val -band 0xFFFF
        if ($imm -ge 0x8000) { $immSigned = $imm - 0x10000 } else { $immSigned = $imm }
        $target = ($val -band 0x3FFFFFF) -shl 2
        
        $regNames = @('zero','at','v0','v1','a0','a1','a2','a3','t0','t1','t2','t3','t4','t5','t6','t7','s0','s1','s2','s3','s4','s5','s6','s7','t8','t9','k0','k1','gp','sp','fp','ra')
        $rsn = $regNames[$rs]
        $rtn = $regNames[$rt]
        $rdn = $regNames[$rd]
        
        $desc = ''
        switch ($opcode) {
            0 { if ($val -ne 0) { $desc = "SLL/SRL/etc" } else { $desc = "nop" } }
            0x02 { $desc = "j 0x$($target.ToString('X8'))" }
            0x03 { $desc = "jal 0x$($target.ToString('X8'))" }
            0x04 { $desc = "beq $rsn,$rtn,0x$((($ram + 4 + ($immSigned * 4)).ToString('X8')))" }
            0x05 { $desc = "bne $rsn,$rtn,0x$((($ram + 4 + ($immSigned * 4)).ToString('X8')))" }
            0x08 { $desc = "addi $rtn,$rsn,$immSigned" }
            0x09 { $desc = "addiu $rtn,$rsn,$immSigned (0x$($imm.ToString('X4')))" }
            0x0A { $desc = "slti $rtn,$rsn,$immSigned" }
            0x0C { $desc = "andi $rtn,$rsn,0x$($imm.ToString('X4'))" }
            0x0D { $desc = "ori $rtn,$rsn,0x$($imm.ToString('X4'))" }
            0x0F { $desc = "lui $rtn,0x$($imm.ToString('X4'))" }
            0x20 { $desc = "lb $rtn,0x$($imm.ToString('X4'))($rsn)" }
            0x21 { $desc = "lh $rtn,0x$($imm.ToString('X4'))($rsn)" }
            0x23 { $desc = "lw $rtn,0x$($imm.ToString('X4'))($rsn)" }
            0x24 { $desc = "lbu $rtn,0x$($imm.ToString('X4'))($rsn)" }
            0x28 { $desc = "sb $rtn,0x$($imm.ToString('X4'))($rsn)" }
            0x29 { $desc = "sh $rtn,0x$($imm.ToString('X4'))($rsn)" }
            0x2B { $desc = "sw $rtn,0x$($imm.ToString('X4'))($rsn)" }
            default { $desc = "op=0x$($opcode.ToString('X2'))" }
        }
        Write-Host ("  0x{0:X8}: 0x{1:X8}  {2}" -f $ram, $val, $desc)
    }
}

# Look at the code around 0x8008A24C (li $a1, 0x32)
Write-Host "=== Code at 0x8008A24C (li $a1, 0x32) ==="
Disasm 0x8008A200 40

# Also look at 0x8003A0C4 (li $v1, 0x32; sb $v1, 0x304($v0))
Write-Host ""
Write-Host "=== Code at 0x8003A0C4 (li $v1, 0x32; sb $v1, 0x304) ==="
Disasm 0x8003A0A0 30

# And 0x80062B60 (li $v1, 0x32; andi $v0, $a1, 0xFC)
Write-Host ""
Write-Host "=== Code at 0x80062B60 ==="
Disasm 0x80062B40 20
