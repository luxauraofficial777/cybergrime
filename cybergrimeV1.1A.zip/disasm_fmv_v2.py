#!/usr/bin/env python3
"""Disassemble FMV playback function 0x8003DDC4 and NOP site context."""
import struct

EXE_PATH = r'c:\LuxAura\VoidWalkers_Project\DQLOSTTRANSLATION\translation\SLUSP012.06_clean.bin'
LOAD_ADDR = 0x80017F00
EXE_HEADER = 0x800

with open(EXE_PATH, 'rb') as f:
    data = f.read()

def ram_to_file(ram):
    return ram - LOAD_ADDR + EXE_HEADER

def read_word(fo):
    return struct.unpack_from('<I', data, fo)[0]

REG = ['zero','at','v0','v1','a0','a1','a2','a3','t0','t1','t2','t3','t4','t5','t6','t7','s0','s1','s2','s3','s4','s5','s6','s7','t8','t9','k0','k1','gp','sp','fp','ra']
def r(n):
    return '$' + REG[n] if n < 32 else '$' + str(n)

def dis(word, pc):
    op = (word >> 26) & 0x3f
    rs = (word >> 21) & 0x1f
    rt = (word >> 16) & 0x1f
    rd = (word >> 11) & 0x1f
    sh = (word >> 6) & 0x1f
    fn = word & 0x3f
    imm = word & 0xffff
    simm = imm if imm < 0x8000 else imm - 0x10000
    tgt = (word & 0x3ffffff) << 2 | (pc & 0xf0000000)
    if word == 0:
        return 'nop'
    if op == 0:
        if fn == 0x20: return 'add %s,%s,%s' % (r(rd), r(rs), r(rt))
        if fn == 0x21: return 'addu %s,%s,%s' % (r(rd), r(rs), r(rt))
        if fn == 0x22: return 'sub %s,%s,%s' % (r(rd), r(rs), r(rt))
        if fn == 0x23: return 'subu %s,%s,%s' % (r(rd), r(rs), r(rt))
        if fn == 0x24: return 'and %s,%s,%s' % (r(rd), r(rs), r(rt))
        if fn == 0x25: return 'or %s,%s,%s' % (r(rd), r(rs), r(rt))
        if fn == 0x26: return 'xor %s,%s,%s' % (r(rd), r(rs), r(rt))
        if fn == 0x27: return 'nor %s,%s,%s' % (r(rd), r(rs), r(rt))
        if fn == 0x2a: return 'slt %s,%s,%s' % (r(rd), r(rs), r(rt))
        if fn == 0x2b: return 'sltu %s,%s,%s' % (r(rd), r(rs), r(rt))
        if fn == 0x00: return 'sll %s,%s,%d' % (r(rd), r(rt), sh)
        if fn == 0x02: return 'srl %s,%s,%d' % (r(rd), r(rt), sh)
        if fn == 0x03: return 'sra %s,%s,%d' % (r(rd), r(rt), sh)
        if fn == 0x04: return 'sllv %s,%s,%s' % (r(rd), r(rt), r(rs))
        if fn == 0x06: return 'srlv %s,%s,%s' % (r(rd), r(rt), r(rs))
        if fn == 0x07: return 'srav %s,%s,%s' % (r(rd), r(rt), r(rs))
        if fn == 0x08: return 'jr %s' % r(rs)
        if fn == 0x09: return 'jalr %s,%s' % (r(rd), r(rs))
        if fn == 0x0c: return 'syscall'
        if fn == 0x10: return 'mfhi %s' % r(rd)
        if fn == 0x12: return 'mflo %s' % r(rd)
        if fn == 0x13: return 'mtlo %s' % r(rs)
        if fn == 0x11: return 'mthi %s' % r(rs)
        return '.sp 0x%02x' % fn
    if op == 1:
        cond = 'bltz' if rt == 0 else ('bgez' if rt == 1 else '.ri%d' % rt)
        return '%s %s,0x%08X' % (cond, r(rs), pc + 4 + simm * 4)
    if op == 2: return 'j 0x%08X' % tgt
    if op == 3: return 'jal 0x%08X' % tgt
    if op == 4: return 'beq %s,%s,0x%08X' % (r(rs), r(rt), pc + 4 + simm * 4)
    if op == 5: return 'bne %s,%s,0x%08X' % (r(rs), r(rt), pc + 4 + simm * 4)
    if op == 6: return 'blez %s,0x%08X' % (r(rs), pc + 4 + simm * 4)
    if op == 7: return 'bgtz %s,0x%08X' % (r(rs), pc + 4 + simm * 4)
    if op == 8: return 'addi %s,%s,%d' % (r(rt), r(rs), simm)
    if op == 9: return 'addiu %s,%s,%d' % (r(rt), r(rs), simm)
    if op == 0xa: return 'slti %s,%s,%d' % (r(rt), r(rs), simm)
    if op == 0xb: return 'sltiu %s,%s,%d' % (r(rt), r(rs), simm)
    if op == 0xc: return 'andi %s,%s,0x%04X' % (r(rt), r(rs), imm)
    if op == 0xd: return 'ori %s,%s,0x%04X' % (r(rt), r(rs), imm)
    if op == 0xe: return 'xori %s,%s,0x%04X' % (r(rt), r(rs), imm)
    if op == 0xf: return 'lui %s,0x%04X' % (r(rt), imm)
    if op == 0x20: return 'lb %s,%d(%s)' % (r(rt), simm, r(rs))
    if op == 0x21: return 'lh %s,%d(%s)' % (r(rt), simm, r(rs))
    if op == 0x23: return 'lw %s,%d(%s)' % (r(rt), simm, r(rs))
    if op == 0x24: return 'lbu %s,%d(%s)' % (r(rt), simm, r(rs))
    if op == 0x25: return 'lhu %s,%d(%s)' % (r(rt), simm, r(rs))
    if op == 0x28: return 'sb %s,%d(%s)' % (r(rt), simm, r(rs))
    if op == 0x29: return 'sh %s,%d(%s)' % (r(rt), simm, r(rs))
    if op == 0x2b: return 'sw %s,%d(%s)' % (r(rt), simm, r(rs))
    return '.unk 0x%08X' % word

# FMV playback function 0x8003DDC4 - 80 instructions
print('=' * 70)
print('FMV PLAYBACK FUNCTION: 0x8003DDC4')
print('=' * 70)
start = ram_to_file(0x8003DDC4)
for i in range(80):
    w = read_word(start + i * 4)
    pc = 0x8003DDC4 + i * 4
    marker = ''
    if pc == 0x8003DE60:
        marker = ' <<< NOP SITE 1 (was JAL 0x8004081C)'
    if pc == 0x8003DF4C:
        marker = ' <<< NOP SITE 2 (was JAL 0x8004081C)'
    print('  0x%08X: 0x%08X  %s%s' % (pc, w, dis(w, pc), marker))

# Now show context around each NOP site - 10 before, 15 after
for label, nop_ram in [('NOP SITE 1', 0x8003DE60), ('NOP SITE 2', 0x8003DF4C)]:
    print()
    print('=' * 70)
    print('%s at 0x%08X - 10 before, 15 after' % (label, nop_ram))
    print('=' * 70)
    ctx_start = nop_ram - 10 * 4
    fo = ram_to_file(ctx_start)
    for i in range(26):
        w = read_word(fo + i * 4)
        pc = ctx_start + i * 4
        marker = ''
        if pc == nop_ram:
            marker = ' <<< NOP (was JAL 0x8004081C)'
        line = '  0x%08X: 0x%08X  %s%s' % (pc, w, dis(w, pc), marker)
        print(line)
    
    # Check v0 usage in 10 instructions after NOP
    print('  --- $v0/$v1 check (10 after NOP) ---')
    after_fo = ram_to_file(nop_ram + 4)
    found_v0 = False
    for i in range(10):
        w = read_word(after_fo + i * 4)
        pc = nop_ram + 4 + i * 4
        d = dis(w, pc)
        if 'v0' in d or 'v1' in d:
            print('  *** 0x%08X: 0x%08X  %s' % (pc, w, d))
            found_v0 = True
    if not found_v0:
        print('  (no $v0/$v1 usage in 10 instructions after NOP)')

# Also check what the wrappers do with $v0 after JAL 0x8003DDC4
print()
print('=' * 70)
print('WRAPPER $v0 USAGE AFTER JAL 0x8003DDC4')
print('=' * 70)
wrappers = [
    (0x80041C30, 'idx=0 intro'),
    (0x80041C88, 'idx=1'),
    (0x80041CE0, 'idx=2'),
    (0x80041D38, 'idx=3'),
    (0x80041DFC, 'idx=4a'),
    (0x80041E78, 'idx=4b'),
]
for wram, desc in wrappers:
    print('\n--- 0x%08X (%s) ---' % (wram, desc))
    fo = ram_to_file(wram)
    for i in range(12):
        w = read_word(fo + i * 4)
        pc = wram + i * 4
        marker = ''
        if w == 0x0C00F771:
            marker = ' <<< JAL 0x8003DDC4'
        line = '  0x%08X: 0x%08X  %s%s' % (pc, w, dis(w, pc), marker)
        print(line)
