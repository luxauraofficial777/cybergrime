import struct
path = r"c:\LuxAura\VoidWalkers_Project\DQLOSTTRANSLATION\Dragon Quest IV - Michibikareshi Mono Tachi (Japan).bin"
with open(path, 'rb') as f:
    # Check first 16 bytes (sync pattern for MODE2 = 00 FF*11 00)
    d = f.read(16)
    print("First 16 bytes:", ' '.join(f'{b:02X}' for b in d))
    
    # Check at 2352 (MODE2 sector 1 start)
    f.seek(2352)
    d = f.read(16)
    print("At 2352:", ' '.join(f'{b:02X}' for b in d))
    
    # Check at 2048 (MODE1 sector 1 start)
    f.seek(2048)
    d = f.read(16)
    print("At 2048:", ' '.join(f'{b:02X}' for b in d))
    
    # Check sector 16 (PVD) at MODE2 offset
    f.seek(16 * 2352 + 24)
    d = f.read(8)
    print("PVD at 16*2352+24:", d)
    
    # Check sector 16 at MODE1 offset
    f.seek(16 * 2048)
    d = f.read(8)
    print("PVD at 16*2048:", d)
    
    # Check sector 362 at MODE2 offset  
    f.seek(362 * 2352 + 24)
    d = f.read(24)
    vals = struct.unpack('<6I', d)
    print("Sector 362 (MODE2):", vals)
    
    # Check sector 362 at MODE1 offset
    f.seek(362 * 2048)
    d = f.read(24)
    vals = struct.unpack('<6I', d)
    print("Sector 362 (MODE1):", vals)
    
    # Scan first 32KB of sector 362 (MODE2) for hts=24
    f.seek(362 * 2352 + 24)
    raw = f.read(32768)
    for i in range(0, len(raw) - 24, 4):
        end, bid, hts, te, xe, unk = struct.unpack_from('<6I', raw, i)
        if hts == 24 and 24 < end < 1048576 and te > 0 and xe > 0 and te < end and xe < end:
            print(f"  Found valid block at offset {i}: end={end} bid={bid} hts={hts} tree_end={te} text_end={xe}")
            break
    
    # Scan first 32KB of sector 362 (MODE1) for hts=24
    f.seek(362 * 2048)
    raw = f.read(32768)
    for i in range(0, len(raw) - 24, 4):
        end, bid, hts, te, xe, unk = struct.unpack_from('<6I', raw, i)
        if hts == 24 and 24 < end < 1048576 and te > 0 and xe > 0 and te < end and xe < end:
            print(f"  Found valid block (MODE1) at offset {i}: end={end} bid={bid} hts={hts} tree_end={te} text_end={xe}")
            break
