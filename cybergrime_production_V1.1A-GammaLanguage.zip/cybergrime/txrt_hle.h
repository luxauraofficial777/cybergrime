#pragma once

// ============================================================================
// TXRT HLE — Surgical Bypass: Pre-Decompression Interception
// ============================================================================
// STRATEGY: Kill the decompression call before it touches the Huffman tree.
//
// The DW7 Huffman decompressor at 0x80073670 reads the global tree at
// 0x800EF1C8. That tree is incompatible with DQ4 data. Instead of trying
// to fix the tree (proven impossible — Frankenstein Test A black screen),
// we intercept at the function ENTRY and skip the entire body.
//
// Flow:
//   1. Caller sets up $a0-$a3, $ra, then JALs to 0x80073670
//   2. Our HLE intercept fires at PC=0x80073670 (before any instruction runs)
//   3. We read the block ID from the caller's registers
//   4. We look up the pre-decoded 2-byte DW7ASCII leaf values in TXRT payload
//   5. We write them directly into the output buffer (bypassing decompression)
//   6. We set $v0 = output buffer ptr (common MIPS convention) and jump to $ra
//   7. The caller receives "decompressed" text — engine never touched the tree
//
// Dummy Header / Checksum:
//   No tree checksum validation exists in the decompressor — it just reads
//   tree nodes and decodes bits. By skipping the function entirely, the tree
//   is never accessed. The engine sees valid 2-byte char codes in the buffer
//   and proceeds normally. No dummy header needed.
//
// Callers don't check $v0 after return (verified from disassembly):
//   - 0x80072500: lui $v0, 0x00FF  (overwrites $v0 immediately)
//   - 0x800727B4: addiu $a0, $sp, 0x18  (ignores $v0)
//   - 0x80080B14: addiu $a1, $sp, 0x10  (ignores $v0)
//   So $v0 return value is irrelevant — we set it defensively anyway.
//
// Fallback: Post-decompression intercept at 0x80072500 (kept for diagnostic)
// ============================================================================

#include <cstdint>
#include <cstdio>
#include <cstring>
#include <vector>

// ── TXRT Payload Format ──────────────────────────────────────────────────────
#pragma pack(push, 1)
struct TxrtHeader {
    uint32_t magic;         // 0x54525845 ("TXRT" LE)
    uint32_t block_count;
    uint32_t payload_size;
    uint32_t flags;
};

struct TxrtBlockEntry {
    uint16_t block_id;
    uint16_t seq_count;
    uint32_t data_offset;
    uint32_t data_size;
};
#pragma pack(pop)

static const uint32_t TXRT_MAGIC = 0x54525845;

// ── Decompression Function Entry Points ──────────────────────────────────────
// Primary Huffman decompressor (516 bytes, 9 JAL call sites)
static const uint32_t DECOMP_FUNC_PRIMARY   = 0x80073670;
// Secondary decompressor (different code path, 3 JAL call sites)
static const uint32_t DECOMP_FUNC_SECONDARY = 0x80084BF0;
// Post-decompression return point (fallback intercept)
static const uint32_t DECOMP_RETURN_PC      = 0x80072500;

// ── Bypass Mode ──────────────────────────────────────────────────────────────
enum BypassMode {
    BYPASS_DISABLED = 0,       // No interception
    BYPASS_DIAGNOSTIC,         // Log registers, don't skip function
    BYPASS_PRE_DECOMP,         // Skip decompression, inject text at entry
    BYPASS_POST_DECOMP,        // Let decompression run, swap text after (fallback)
};

// ── HLE State ────────────────────────────────────────────────────────────────
struct TxrtHle {
    bool loaded;

    BypassMode mode;

    std::vector<uint8_t> payload;
    TxrtHeader header;
    std::vector<TxrtBlockEntry> blocks;

    // Block ID source — which register holds the block ID at function entry
    // 0=ra, 1=v0, 2=a0, 3=a1, 4=s0, 5=s1, 6=s2, 7=s3, 8=s4, 9=s5, 10=s6, 11=s7
    int block_id_reg;
    // Alternatively, read block ID from a fixed RAM address
    uint32_t block_id_ram_addr;  // 0 = disabled

    // Output buffer source — which register holds the output buffer pointer
    // Same encoding as block_id_reg
    int outbuf_reg;
    // Alternatively, output buffer is at a fixed RAM address
    uint32_t outbuf_ram_addr;    // 0 = disabled

    // Statistics
    uint16_t last_block_id;
    int bypass_count;       // Pre-decompression bypasses
    int swap_count;         // Post-decompression swaps
    int miss_count;         // Block ID not found in TXRT
    int passthrough_count;  // Decompression allowed to run (no TXRT match)
    int diag_count;         // Diagnostic dumps emitted

    // Track which decompression function was entered (for diagnostic)
    uint32_t last_func_entered;

    TxrtHle() : loaded(false), mode(BYPASS_DIAGNOSTIC),
                block_id_reg(3), block_id_ram_addr(0),
                outbuf_reg(2), outbuf_ram_addr(0),
                last_block_id(0), bypass_count(0), swap_count(0),
                miss_count(0), passthrough_count(0), diag_count(0),
                last_func_entered(0) {}
};

static TxrtHle g_txrt;

// ── Load TXRT payload from host file ─────────────────────────────────────────
static bool txrt_load(const char* path) {
    FILE* f = fopen(path, "rb");
    if (!f) {
        printf("[TXRT] Cannot open %s\n", path);
        return false;
    }
    fseek(f, 0, SEEK_END);
    long size = ftell(f);
    fseek(f, 0, SEEK_SET);

    g_txrt.payload.resize(size);
    fread(g_txrt.payload.data(), 1, size, f);
    fclose(f);

    if (size < 16) {
        printf("[TXRT] Payload too small (%ld bytes)\n", size);
        return false;
    }

    memcpy(&g_txrt.header, g_txrt.payload.data(), sizeof(TxrtHeader));

    if (g_txrt.header.magic != TXRT_MAGIC) {
        printf("[TXRT] Magic mismatch: 0x%08X != 0x%08X\n",
               g_txrt.header.magic, TXRT_MAGIC);
        return false;
    }

    uint32_t count = g_txrt.header.block_count;
    printf("[TXRT] Loaded: %u blocks, %u bytes\n", count, g_txrt.header.payload_size);

    if (16 + count * 12 > (uint32_t)size) {
        printf("[TXRT] Block table extends beyond payload!\n");
        return false;
    }

    g_txrt.blocks.resize(count);
    for (uint32_t i = 0; i < count; i++) {
        memcpy(&g_txrt.blocks[i],
               g_txrt.payload.data() + 16 + i * 12,
               sizeof(TxrtBlockEntry));
    }

    g_txrt.loaded = true;
    printf("[TXRT] Ready. First 5 blocks:\n");
    for (uint32_t i = 0; i < count && i < 5; i++) {
        printf("  [%u] id=0x%04X seqs=%u offset=%u size=%u\n",
               i, g_txrt.blocks[i].block_id, g_txrt.blocks[i].seq_count,
               g_txrt.blocks[i].data_offset, g_txrt.blocks[i].data_size);
    }
    return true;
}

// ── Find a block by ID ───────────────────────────────────────────────────────
static const TxrtBlockEntry* txrt_find_block(uint16_t block_id) {
    for (uint32_t i = 0; i < g_txrt.blocks.size(); i++) {
        if (g_txrt.blocks[i].block_id == block_id)
            return &g_txrt.blocks[i];
    }
    return nullptr;
}

// ── Read a register from the CPU by index ────────────────────────────────────
static uint32_t txrt_get_reg(MIPS_CPU& cpu, int reg_idx) {
    switch (reg_idx) {
        case 0:  return cpu.get_reg(31);  // ra
        case 1:  return cpu.get_reg(2);   // v0
        case 2:  return cpu.get_reg(4);   // a0
        case 3:  return cpu.get_reg(5);   // a1
        case 4:  return cpu.get_reg(16);  // s0
        case 5:  return cpu.get_reg(17);  // s1
        case 6:  return cpu.get_reg(18);  // s2
        case 7:  return cpu.get_reg(19);  // s3
        case 8:  return cpu.get_reg(20);  // s4
        case 9:  return cpu.get_reg(21);  // s5
        case 10: return cpu.get_reg(22);  // s6
        case 11: return cpu.get_reg(23);  // s7
        default: return 0;
    }
}

static const char* txrt_reg_name(int reg_idx) {
    switch (reg_idx) {
        case 0:  return "ra";
        case 1:  return "v0";
        case 2:  return "a0";
        case 3:  return "a1";
        case 4:  return "s0";
        case 5:  return "s1";
        case 6:  return "s2";
        case 7:  return "s3";
        case 8:  return "s4";
        case 9:  return "s5";
        case 10: return "s6";
        case 11: return "s7";
        default: return "??";
    }
}

// ── Diagnostic: dump all registers at decompression entry ────────────────────
static void txrt_diagnostic_dump(MIPS_CPU& cpu, uint64_t instr_count, uint32_t func_pc) {
    printf("[TXRT DIAG] instr #%llu PC=0x%08X %s\n", instr_count, func_pc,
           func_pc == DECOMP_FUNC_PRIMARY ? "(PRIMARY)" :
           func_pc == DECOMP_FUNC_SECONDARY ? "(SECONDARY)" : "(UNKNOWN)");
    printf("  v0=0x%08X v1=0x%08X\n", cpu.get_reg(2), cpu.get_reg(3));
    printf("  a0=0x%08X a1=0x%08X a2=0x%08X a3=0x%08X\n",
           cpu.get_reg(4), cpu.get_reg(5), cpu.get_reg(6), cpu.get_reg(7));
    printf("  s0=0x%08X s1=0x%08X s2=0x%08X s3=0x%08X\n",
           cpu.get_reg(16), cpu.get_reg(17), cpu.get_reg(18), cpu.get_reg(19));
    printf("  s4=0x%08X s5=0x%08X s6=0x%08X s7=0x%08X\n",
           cpu.get_reg(20), cpu.get_reg(21), cpu.get_reg(22), cpu.get_reg(23));
    printf("  sp=0x%08X ra=0x%08X (return-to)\n", cpu.get_reg(29), cpu.get_reg(31));

    // Dump first 32 bytes at each register that looks like a RAM pointer
    const char* reg_names[] = {"a0","a1","a2","a3","s0","s1","s2","s3","s4","s5","s6","s7"};
    int reg_nums[] = {4,5,6,7,16,17,18,19,20,21,22,23};
    for (int r = 0; r < 12; r++) {
        uint32_t addr = cpu.get_reg(reg_nums[r]);
        if (addr >= 0x80000000 && addr < 0x80200000 && g_mem) {
            printf("  [$%s=0x%08X] ", reg_names[r], addr);
            for (int i = 0; i < 32; i++) {
                printf("%02X", g_mem->read8(addr + i));
                if (i % 4 == 3) printf(" ");
            }
            printf("\n");
        }
    }

    // Dump stack
    uint32_t sp = cpu.get_reg(29);
    if (sp >= 0x80000000 && sp < 0x80200000 && g_mem) {
        for (int i = 0; i < 32; i += 4) {
            printf("  [sp+%02X] 0x%08X\n", i, g_mem->read32(sp + i));
        }
    }
}

// ── Surgical Bypass: intercept at decompression function ENTRY ───────────────
// Called from step() when PC == DECOMP_FUNC_PRIMARY or DECOMP_FUNC_SECONDARY.
// If active: skips the entire function body, injects text, returns to $ra.
// Returns true if the function was bypassed (PC was redirected to $ra).
static bool txrt_bypass_decompression_entry(MIPS_CPU& cpu, PSX_Memory& mem, uint32_t func_pc) {
    if (!g_txrt.loaded) return false;

    g_txrt.last_func_entered = func_pc;

    // Diagnostic mode: log registers to identify block ID + output buffer source
    if (g_txrt.mode == BYPASS_DIAGNOSTIC && g_txrt.diag_count < 20) {
        txrt_diagnostic_dump(cpu, cpu.instructions, func_pc);
        g_txrt.diag_count++;
        return false;  // Let the function run normally
    }

    if (g_txrt.mode != BYPASS_PRE_DECOMP) return false;

    // ── Identify block ID ────────────────────────────────────────────────────
    uint16_t block_id;
    if (g_txrt.block_id_ram_addr != 0) {
        block_id = (uint16_t)mem.read32(g_txrt.block_id_ram_addr);
    } else {
        block_id = (uint16_t)(txrt_get_reg(cpu, g_txrt.block_id_reg) & 0xFFFF);
    }
    g_txrt.last_block_id = block_id;

    // ── Look up block in TXRT payload ────────────────────────────────────────
    const TxrtBlockEntry* entry = txrt_find_block(block_id);
    if (!entry) {
        // Block not in TXRT — let original decompression run
        g_txrt.passthrough_count++;
        return false;
    }

    // ── Identify output buffer ───────────────────────────────────────────────
    uint32_t out_buf;
    if (g_txrt.outbuf_ram_addr != 0) {
        out_buf = g_txrt.outbuf_ram_addr;
    } else {
        out_buf = txrt_get_reg(cpu, g_txrt.outbuf_reg);
    }

    // Validate output buffer is in PSX RAM
    if (out_buf < 0x80000000 || out_buf >= 0x80200000) {
        // Try $a0 as fallback
        out_buf = cpu.get_reg(4);
        if (out_buf < 0x80000000 || out_buf >= 0x80200000) {
            printf("[TXRT] Block 0x%04X: can't find output buffer!\n", block_id);
            g_txrt.miss_count++;
            return false;
        }
    }

    // ── Validate TXRT data bounds ────────────────────────────────────────────
    uint32_t src_off = entry->data_offset;
    uint32_t src_size = entry->data_size;
    if (src_off + src_size > g_txrt.payload.size()) {
        printf("[TXRT] Block 0x%04X data extends beyond payload!\n", block_id);
        g_txrt.miss_count++;
        return false;
    }

    // ── Inject translated text directly into output buffer ───────────────────
    // This replaces the entire Huffman decompression with a raw byte copy.
    // The engine never touches the tree at 0x800EF1C8.
    const uint8_t* src = g_txrt.payload.data() + src_off;
    for (uint32_t i = 0; i < src_size; i++) {
        mem.write8(out_buf + i, src[i]);
    }

    // ── Set return value and skip function body ──────────────────────────────
    // Callers don't check $v0 (verified from disassembly), but set defensively.
    // $v0 = output buffer pointer (common convention for "return dst" functions)
    cpu.set_reg(2, out_buf);

    // Jump to $ra — skip the entire decompression function
    uint32_t return_addr = cpu.get_reg(31);
    cpu.pc = return_addr;
    cpu.next_pc = return_addr + 4;

    g_txrt.bypass_count++;
    if (g_txrt.bypass_count <= 20) {
        printf("[TXRT BYPASS] #%d: func=0x%08X block=0x%04X %u bytes -> buf 0x%08X (ret=0x%08X)\n",
               g_txrt.bypass_count, func_pc, block_id, src_size, out_buf, return_addr);
    }

    return true;  // PC was redirected — step() should return immediately
}

// ── Fallback: Post-decompression text swap ───────────────────────────────────
// Called from step() when PC == DECOMP_RETURN_PC (0x80072500).
// Lets the decompression run, then overwrites the output buffer.
static bool txrt_intercept_decompression_return(MIPS_CPU& cpu, PSX_Memory& mem) {
    if (!g_txrt.loaded) return false;
    if (g_txrt.mode != BYPASS_POST_DECOMP) return false;

    // Get block ID
    uint16_t block_id;
    if (g_txrt.block_id_ram_addr != 0) {
        block_id = (uint16_t)mem.read32(g_txrt.block_id_ram_addr);
    } else {
        block_id = (uint16_t)(txrt_get_reg(cpu, g_txrt.block_id_reg) & 0xFFFF);
    }
    g_txrt.last_block_id = block_id;

    const TxrtBlockEntry* entry = txrt_find_block(block_id);
    if (!entry) {
        g_txrt.miss_count++;
        return false;
    }

    // Output buffer: try $a0, then $v0
    uint32_t out_buf = cpu.get_reg(4);
    if (out_buf < 0x80000000 || out_buf >= 0x80200000) {
        out_buf = cpu.get_reg(2);
        if (out_buf < 0x80000000 || out_buf >= 0x80200000) {
            g_txrt.miss_count++;
            return false;
        }
    }

    uint32_t src_off = entry->data_offset;
    uint32_t src_size = entry->data_size;
    if (src_off + src_size > g_txrt.payload.size()) {
        g_txrt.miss_count++;
        return false;
    }

    const uint8_t* src = g_txrt.payload.data() + src_off;
    for (uint32_t i = 0; i < src_size; i++) {
        mem.write8(out_buf + i, src[i]);
    }

    g_txrt.swap_count++;
    if (g_txrt.swap_count <= 10) {
        printf("[TXRT SWAP] #%d: block 0x%04X, %u bytes -> buf 0x%08X\n",
               g_txrt.swap_count, block_id, src_size, out_buf);
    }

    return true;
}

// ── Configuration helpers ────────────────────────────────────────────────────
static void txrt_set_block_id_reg(const char* reg_name) {
    if      (!strcmp(reg_name, "ra")) g_txrt.block_id_reg = 0;
    else if (!strcmp(reg_name, "v0")) g_txrt.block_id_reg = 1;
    else if (!strcmp(reg_name, "a0")) g_txrt.block_id_reg = 2;
    else if (!strcmp(reg_name, "a1")) g_txrt.block_id_reg = 3;
    else if (!strcmp(reg_name, "s0")) g_txrt.block_id_reg = 4;
    else if (!strcmp(reg_name, "s1")) g_txrt.block_id_reg = 5;
    else if (!strcmp(reg_name, "s2")) g_txrt.block_id_reg = 6;
    else if (!strcmp(reg_name, "s3")) g_txrt.block_id_reg = 7;
    else if (!strcmp(reg_name, "s4")) g_txrt.block_id_reg = 8;
    else if (!strcmp(reg_name, "s5")) g_txrt.block_id_reg = 9;
    else if (!strcmp(reg_name, "s6")) g_txrt.block_id_reg = 10;
    else if (!strcmp(reg_name, "s7")) g_txrt.block_id_reg = 11;
    printf("[TXRT] Block ID source: $%s\n", txrt_reg_name(g_txrt.block_id_reg));
}

static void txrt_set_outbuf_reg(const char* reg_name) {
    if      (!strcmp(reg_name, "ra")) g_txrt.outbuf_reg = 0;
    else if (!strcmp(reg_name, "v0")) g_txrt.outbuf_reg = 1;
    else if (!strcmp(reg_name, "a0")) g_txrt.outbuf_reg = 2;
    else if (!strcmp(reg_name, "a1")) g_txrt.outbuf_reg = 3;
    else if (!strcmp(reg_name, "s0")) g_txrt.outbuf_reg = 4;
    else if (!strcmp(reg_name, "s1")) g_txrt.outbuf_reg = 5;
    else if (!strcmp(reg_name, "s2")) g_txrt.outbuf_reg = 6;
    else if (!strcmp(reg_name, "s3")) g_txrt.outbuf_reg = 7;
    else if (!strcmp(reg_name, "s4")) g_txrt.outbuf_reg = 8;
    else if (!strcmp(reg_name, "s5")) g_txrt.outbuf_reg = 9;
    else if (!strcmp(reg_name, "s6")) g_txrt.outbuf_reg = 10;
    else if (!strcmp(reg_name, "s7")) g_txrt.outbuf_reg = 11;
    printf("[TXRT] Output buffer source: $%s\n", txrt_reg_name(g_txrt.outbuf_reg));
}

static void txrt_set_mode(BypassMode mode) {
    g_txrt.mode = mode;
    const char* mode_str = "DISABLED";
    switch (mode) {
        case BYPASS_DIAGNOSTIC:   mode_str = "DIAGNOSTIC (log only)"; break;
        case BYPASS_PRE_DECOMP:   mode_str = "PRE-DECOMP (surgical bypass)"; break;
        case BYPASS_POST_DECOMP:  mode_str = "POST-DECOMP (fallback swap)"; break;
        default: break;
    }
    printf("[TXRT] Mode: %s\n", mode_str);
}

static void txrt_status() {
    const char* mode_str = "DISABLED";
    switch (g_txrt.mode) {
        case BYPASS_DIAGNOSTIC:   mode_str = "DIAGNOSTIC"; break;
        case BYPASS_PRE_DECOMP:   mode_str = "PRE-DECOMP"; break;
        case BYPASS_POST_DECOMP:  mode_str = "POST-DECOMP"; break;
        default: break;
    }
    printf("[TXRT] loaded=%d mode=%s bypasses=%d swaps=%d misses=%d passthrough=%d diag=%d last_id=0x%04X last_func=0x%08X\n",
           g_txrt.loaded, mode_str,
           g_txrt.bypass_count, g_txrt.swap_count, g_txrt.miss_count,
           g_txrt.passthrough_count, g_txrt.diag_count,
           g_txrt.last_block_id, g_txrt.last_func_entered);
}
