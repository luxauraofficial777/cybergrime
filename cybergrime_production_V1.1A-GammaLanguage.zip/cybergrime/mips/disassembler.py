"""Minimal MIPS I disassembler."""

from typing import List, Tuple

from .opcode import (
    reg_name,
    REG_NAMES,
    OPCODES,
    SPECIAL_FUNCS,
    REGIMM_FUNCS,
    OP_SPECIAL,
    OP_REGIMM,
)


def _sign16(value: int) -> int:
    v = value & 0xFFFF
    return v - 0x10000 if v & 0x8000 else v


REVERSE_SPECIAL = {v[1]: (k, v[0]) for k, v in SPECIAL_FUNCS.items()}
REVERSE_REGIMM = {v[1]: k for k, v in REGIMM_FUNCS.items()}


def disassemble_word(word: int, pc: int = 0) -> str:
    op = (word >> 26) & 0x3F
    rs = (word >> 21) & 0x1F
    rt = (word >> 16) & 0x1F
    rd = (word >> 11) & 0x1F
    sa = (word >> 6) & 0x1F
    fn = word & 0x3F
    imm = word & 0xFFFF

    if op == OP_SPECIAL:
        if word == 0:
            return "nop"
        if fn in REVERSE_SPECIAL:
            mnem, fmt = REVERSE_SPECIAL[fn]
            if fmt == "R":
                return f"{mnem} ${reg_name(rd)}, ${reg_name(rs)}, ${reg_name(rt)}"
            if fmt == "R_sa":
                return f"{mnem} ${reg_name(rd)}, ${reg_name(rt)}, {sa}"
            if fmt == "R_j":
                if mnem == "jr":
                    return f"{mnem} ${reg_name(rs)}"
                return f"{mnem} ${reg_name(rd)}, ${reg_name(rs)}"
            if fmt == "R_dst":
                return f"{mnem} ${reg_name(rd)}"
            if fmt == "R_src":
                return f"{mnem} ${reg_name(rs)}"
            if fmt == "R_mul":
                return f"{mnem} ${reg_name(rs)}, ${reg_name(rt)}"
        return f".word 0x{word:08X}  # SPECIAL fn=0x{fn:02X}"

    if op == OP_REGIMM:
        if rt in REVERSE_REGIMM:
            mnem = REVERSE_REGIMM[rt]
            target = pc + 4 + (_sign16(imm) * 4)
            return f"{mnem} ${reg_name(rs)}, 0x{target:08X}"
        return f".word 0x{word:08X}  # REGIMM rt=0x{rt:02X}"

    # Reverse lookup I/J opcodes by opcode number
    reverse_op = {v[1]: (k, v[0]) for k, v in OPCODES.items()}
    if op in reverse_op:
        mnem, fmt = reverse_op[op]
        if fmt == "J":
            target = ((word & 0x03FFFFFF) << 2) | (pc & 0xF0000000)
            return f"{mnem} 0x{target:08X}"
        if fmt == "B":
            target = pc + 4 + (_sign16(imm) * 4)
            return f"{mnem} ${reg_name(rs)}, ${reg_name(rt)}, 0x{target:08X}"
        if fmt == "Bz":
            target = pc + 4 + (_sign16(imm) * 4)
            return f"{mnem} ${reg_name(rs)}, 0x{target:08X}"
        if fmt in ("I", "Iu"):
            return f"{mnem} ${reg_name(rt)}, {_sign16(imm)}(${reg_name(rs)})"
        if fmt == "Lui":
            return f"{mnem} ${reg_name(rt)}, 0x{imm:04X}"

    return f".word 0x{word:08X}  # op=0x{op:02X}"


def disassemble(data: bytes, base_addr: int = 0) -> List[Tuple[int, str]]:
    """Disassemble a byte blob and return (addr, text) pairs."""
    result = []
    import struct
    count = len(data) // 4
    for i in range(count):
        word = struct.unpack_from("<I", data, i * 4)[0]
        addr = base_addr + i * 4
        result.append((addr, disassemble_word(word, addr)))
    return result


def disassemble_words(words: List[int], base_addr: int = 0) -> List[Tuple[int, str]]:
    return [(base_addr + i * 4, disassemble_word(w, base_addr + i * 4)) for i, w in enumerate(words)]


def format_disassembly(data: bytes, base_addr: int = 0) -> str:
    lines = []
    for addr, text in disassemble(data, base_addr):
        lines.append(f"0x{addr:08X}: 0x{int.from_bytes(data[addr-base_addr:addr-base_addr+4], 'little'):08X}  {text}")
    return "\n".join(lines)
