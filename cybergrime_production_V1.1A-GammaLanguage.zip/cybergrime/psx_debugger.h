#pragma once

// ============================================================================
// PSX CLI Debugger — Interactive debugging interface for the emulator
// Provides breakpoints, watchpoints, step, disasm, hex dump, backtrace,
// register view, memory inspection, and save/load state commands.
// Header-only, dependency-free.
// ============================================================================

#include <cstdint>
#include <cstdio>
#include <cstring>
#include <string>
#include <vector>
#include <unordered_map>
#include <functional>

class PSXDebugger {
public:
    struct Breakpoint {
        uint32_t addr;
        bool enabled;
        bool halt;          // true = halt execution, false = log only
        int hit_count;
        std::string label;
    };

    struct Watchpoint {
        uint32_t addr;
        uint32_t size;      // 1, 2, or 4 bytes
        bool enabled;
        uint32_t last_value;
        std::string label;
    };

    std::vector<Breakpoint> breakpoints;
    std::vector<Watchpoint> watchpoints;
    bool halted;
    bool single_step;
    bool trace_enabled;
    uint32_t trace_from_addr;
    FILE* trace_file;

    // Symbol table (addr → name)
    std::unordered_map<uint32_t, std::string> symbols;
    std::unordered_map<std::string, uint32_t> name_to_addr;

    PSXDebugger() : halted(false), single_step(false), trace_enabled(false),
                    trace_from_addr(0), trace_file(nullptr) {}

    // --- Breakpoints ---
    int add_breakpoint(uint32_t addr, bool halt = true, const char* label = "") {
        Breakpoint bp;
        bp.addr = addr;
        bp.enabled = true;
        bp.halt = halt;
        bp.hit_count = 0;
        bp.label = label ? label : "";
        breakpoints.push_back(bp);
        return (int)(breakpoints.size() - 1);
    }

    bool remove_breakpoint(int idx) {
        if (idx < 0 || idx >= (int)breakpoints.size()) return false;
        breakpoints.erase(breakpoints.begin() + idx);
        return true;
    }

    void clear_breakpoints() { breakpoints.clear(); }

    void enable_breakpoint(int idx) {
        if (idx >= 0 && idx < (int)breakpoints.size()) breakpoints[idx].enabled = true;
    }

    void disable_breakpoint(int idx) {
        if (idx >= 0 && idx < (int)breakpoints.size()) breakpoints[idx].enabled = false;
    }

    // Check breakpoints at current PC — returns true if should halt
    bool check_breakpoint(uint32_t pc) {
        for (auto& bp : breakpoints) {
            if (bp.enabled && bp.addr == pc) {
                bp.hit_count++;
                if (bp.halt) {
                    halted = true;
                    return true;
                }
            }
        }
        return false;
    }

    // --- Watchpoints ---
    int add_watchpoint(uint32_t addr, uint32_t size = 4, const char* label = "") {
        Watchpoint wp;
        wp.addr = addr;
        wp.size = size;
        wp.enabled = true;
        wp.last_value = 0;
        wp.label = label ? label : "";
        watchpoints.push_back(wp);
        return (int)(watchpoints.size() - 1);
    }

    bool remove_watchpoint(int idx) {
        if (idx < 0 || idx >= (int)watchpoints.size()) return false;
        watchpoints.erase(watchpoints.begin() + idx);
        return true;
    }

    // Check watchpoints — returns true if any changed
    bool check_watchpoints(const std::function<uint32_t(uint32_t, uint32_t)>& read_mem) {
        bool changed = false;
        for (auto& wp : watchpoints) {
            if (!wp.enabled) continue;
            uint32_t val = read_mem(wp.addr, wp.size);
            if (val != wp.last_value) {
                wp.last_value = val;
                changed = true;
            }
        }
        return changed;
    }

    // --- Symbols ---
    void load_symbols(const char* json_path);
    void add_symbol(uint32_t addr, const char* name) {
        symbols[addr] = name;
        name_to_addr[name] = addr;
    }

    const char* addr_to_name(uint32_t addr) {
        auto it = symbols.find(addr);
        return (it != symbols.end()) ? it->second.c_str() : nullptr;
    }

    uint32_t name_to_address(const char* name) {
        auto it = name_to_addr.find(name);
        return (it != name_to_addr.end()) ? it->second : 0;
    }

    // --- Commands ---
    void resume() { halted = false; single_step = false; }
    void step() { halted = false; single_step = true; }
    void step_over() { halted = false; single_step = true; } // Simplified

    // Print CPU state
    void print_regs(const uint32_t regs[32], uint32_t pc, uint32_t hi, uint32_t lo) {
        const char* reg_names[] = {
            "zero","at","v0","v1","a0","a1","a2","a3",
            "t0","t1","t2","t3","t4","t5","t6","t7",
            "s0","s1","s2","s3","s4","s5","s6","s7",
            "t8","t9","k0","k1","gp","sp","fp","ra"
        };
        printf("PC=0x%08X  HI=0x%08X  LO=0x%08X\n", pc, hi, lo);
        for (int i = 0; i < 32; i += 4) {
            for (int j = 0; j < 4; j++) {
                printf("%s=0x%08X  ", reg_names[i + j], regs[i + j]);
            }
            printf("\n");
        }
    }

    // Hex dump
    void hex_dump(uint32_t addr, const uint8_t* data, int size) {
        for (int i = 0; i < size; i += 16) {
            printf("0x%08X: ", addr + i);
            for (int j = 0; j < 16 && (i + j) < size; j++) {
                printf("%02X ", data[i + j]);
                if (j == 7) printf(" ");
            }
            printf(" |");
            for (int j = 0; j < 16 && (i + j) < size; j++) {
                char c = (char)data[i + j];
                printf("%c", (c >= 32 && c < 127) ? c : '.');
            }
            printf("|\n");
        }
    }

    // List breakpoints
    void list_breakpoints() {
        printf("Breakpoints (%zu):\n", breakpoints.size());
        for (size_t i = 0; i < breakpoints.size(); i++) {
            const auto& bp = breakpoints[i];
            const char* sym = addr_to_name(bp.addr);
            printf("  [%zu] 0x%08X %s %s hits=%d %s\n",
                   i, bp.addr, bp.enabled ? "EN" : "--",
                   bp.halt ? "HALT" : "LOG ",
                   bp.hit_count,
                   sym ? sym : (bp.label.empty() ? "" : bp.label.c_str()));
        }
    }

    // List watchpoints
    void list_watchpoints() {
        printf("Watchpoints (%zu):\n", watchpoints.size());
        for (size_t i = 0; i < watchpoints.size(); i++) {
            const auto& wp = watchpoints[i];
            printf("  [%zu] 0x%08X size=%d %s val=0x%08X %s\n",
                   i, wp.addr, wp.size,
                   wp.enabled ? "EN" : "--",
                   wp.last_value,
                   wp.label.empty() ? "" : wp.label.c_str());
        }
    }

    // Process a command string — returns true if should continue execution
    // info_cb: optional callback for hardware state dumps (cd, dma, gpu, gte, spu)
    bool process_command(const char* cmd,
                         const uint32_t regs[32], uint32_t pc, uint32_t hi, uint32_t lo,
                         const std::function<uint32_t(uint32_t, uint32_t)>& read_mem,
                         const std::function<void(uint32_t, uint32_t, uint32_t)>& write_mem,
                         const std::function<void(const char*)>& info_cb = nullptr,
                         const std::function<void(const char*)>& save_cb = nullptr,
                         const std::function<void(const char*)>& load_cb = nullptr,
                         const std::function<void(const char*)>& screenshot_cb = nullptr) {

        char buf[256];
        strncpy(buf, cmd, sizeof(buf) - 1);
        buf[sizeof(buf) - 1] = '\0';

        // Parse command
        char* tok = strtok(buf, " \t\n");
        if (!tok) return true;

        if (strcmp(tok, "continue") == 0 || strcmp(tok, "c") == 0) {
            resume();
            return false; // Continue execution
        } else if (strcmp(tok, "step") == 0 || strcmp(tok, "s") == 0) {
            step();
            return false;
        } else if (strcmp(tok, "regs") == 0 || strcmp(tok, "r") == 0) {
            print_regs(regs, pc, hi, lo);
            return true;
        } else if (strcmp(tok, "break") == 0 || strcmp(tok, "b") == 0) {
            char* arg = strtok(nullptr, " \t\n");
            if (arg) {
                uint32_t addr = (uint32_t)strtoul(arg, nullptr, 0);
                add_breakpoint(addr);
                printf("Breakpoint added at 0x%08X\n", addr);
            }
            return true;
        } else if (strcmp(tok, "watch") == 0 || strcmp(tok, "w") == 0) {
            char* arg = strtok(nullptr, " \t\n");
            if (arg) {
                uint32_t addr = (uint32_t)strtoul(arg, nullptr, 0);
                add_watchpoint(addr);
                printf("Watchpoint added at 0x%08X\n", addr);
            }
            return true;
        } else if (strcmp(tok, "list") == 0 || strcmp(tok, "l") == 0) {
            list_breakpoints();
            list_watchpoints();
            return true;
        } else if (strcmp(tok, "delete") == 0 || strcmp(tok, "d") == 0) {
            char* arg = strtok(nullptr, " \t\n");
            if (arg) {
                int idx = atoi(arg);
                remove_breakpoint(idx);
                printf("Breakpoint %d removed\n", idx);
            }
            return true;
        } else if (strcmp(tok, "x") == 0) {
            // Hex dump: x <addr> [size]
            char* addr_str = strtok(nullptr, " \t\n");
            char* size_str = strtok(nullptr, " \t\n");
            if (addr_str) {
                uint32_t addr = (uint32_t)strtoul(addr_str, nullptr, 0);
                int size = size_str ? atoi(size_str) : 64;
                std::vector<uint8_t> data(size);
                for (int i = 0; i < size; i++) {
                    data[i] = (uint8_t)read_mem(addr + i, 1);
                }
                hex_dump(addr, data.data(), size);
            }
            return true;
        } else if (strcmp(tok, "disasm") == 0) {
            // Disassemble at address
            char* arg = strtok(nullptr, " \t\n");
            uint32_t addr = arg ? (uint32_t)strtoul(arg, nullptr, 0) : pc;
            uint32_t instr = read_mem(addr, 4);
            printf("0x%08X: 0x%08X\n", addr, instr);
            return true;
        } else if (strcmp(tok, "si") == 0) {
            // Step into (same as step but also executes delay slot)
            step();
            return false;
        } else if (strcmp(tok, "pc") == 0) {
            printf("PC=0x%08X\n", pc);
            return true;
        } else if (strcmp(tok, "mm") == 0) {
            // Memory write: mm <addr> <val>
            char* addr_str = strtok(nullptr, " \t\n");
            char* val_str = strtok(nullptr, " \t\n");
            if (addr_str && val_str) {
                uint32_t addr = (uint32_t)strtoul(addr_str, nullptr, 0);
                uint32_t val = (uint32_t)strtoul(val_str, nullptr, 0);
                write_mem(addr, val, 4);
                printf("Wrote 0x%08X to 0x%08X\n", val, addr);
            }
            return true;
        } else if (strcmp(tok, "bt") == 0) {
            // Backtrace via $ra chain
            printf("Backtrace:\n");
            uint32_t ra = regs[31];
            uint32_t cur_pc = pc;
            for (int depth = 0; depth < 16 && ra >= 0x80000000 && ra < 0x80200000; depth++) {
                const char* sym = addr_to_name(cur_pc);
                printf("  #%d  0x%08X  %s\n", depth, cur_pc, sym ? sym : "");
                cur_pc = ra;
                // Read next ra from stack (simplified — just follow ra register)
                ra = read_mem(ra, 4);  // This is wrong but gives a rough trace
                if (ra == 0 || ra == cur_pc) break;
            }
            return true;
        } else if (strcmp(tok, "info") == 0) {
            char* arg = strtok(nullptr, " \t\n");
            if (info_cb && arg) {
                info_cb(arg);
            } else {
                printf("Usage: info <cd|dma|gpu|gte|spu|timers>\n");
            }
            return true;
        } else if (strcmp(tok, "log") == 0) {
            char* arg = strtok(nullptr, " \t\n");
            if (arg && strcmp(arg, "on") == 0) {
                trace_enabled = true;
                printf("Trace logging enabled\n");
            } else if (arg && strcmp(arg, "off") == 0) {
                trace_enabled = false;
                printf("Trace logging disabled\n");
            } else {
                printf("Trace: %s\n", trace_enabled ? "ON" : "OFF");
            }
            return true;
        } else if (strcmp(tok, "save") == 0) {
            char* arg = strtok(nullptr, " \t\n");
            if (arg && save_cb) {
                save_cb(arg);
            } else {
                printf("Usage: save <filename>\n");
            }
            return true;
        } else if (strcmp(tok, "load") == 0) {
            char* arg = strtok(nullptr, " \t\n");
            if (arg && load_cb) {
                load_cb(arg);
            } else {
                printf("Usage: load <filename>\n");
            }
            return true;
        } else if (strcmp(tok, "screenshot") == 0) {
            char* arg = strtok(nullptr, " \t\n");
            if (arg && screenshot_cb) {
                screenshot_cb(arg);
            } else {
                printf("Usage: screenshot <filename.bmp>\n");
            }
            return true;
        } else if (strcmp(tok, "help") == 0 || strcmp(tok, "h") == 0) {
            printf("Commands:\n");
            printf("  c/continue       - Resume execution\n");
            printf("  s/step            - Single step\n");
            printf("  si                - Step into delay slot\n");
            printf("  r/regs            - Show registers\n");
            printf("  pc                - Show current PC\n");
            printf("  b/break <addr>    - Add breakpoint\n");
            printf("  w/watch <addr>    - Add watchpoint\n");
            printf("  l/list            - List breakpoints/watchpoints\n");
            printf("  d/delete <idx>    - Delete breakpoint\n");
            printf("  x <addr> [size]   - Hex dump\n");
            printf("  mm <addr> <val>   - Memory write (32-bit)\n");
            printf("  disasm [addr]     - Disassemble instruction\n");
            printf("  bt                - Backtrace via $ra chain\n");
            printf("  info <cd|dma|gpu|gte|spu|timers> - Hardware state dump\n");
            printf("  log <on|off>      - Toggle trace logging\n");
            printf("  save <file>       - Save state\n");
            printf("  load <file>       - Load state\n");
            printf("  screenshot <file> - Dump framebuffer to BMP\n");
            printf("  h/help            - This help\n");
            return true;
        }

        printf("Unknown command: %s (try 'help')\n", tok);
        return true;
    }
};
