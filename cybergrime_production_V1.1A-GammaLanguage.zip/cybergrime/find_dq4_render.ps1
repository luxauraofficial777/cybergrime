# Search DQ4 EXE for actual text render / decompression patterns
$b = [System.IO.File]::ReadAllBytes('..\dq4_exe.bin')
$load = 0x80017F00

# Find all JAL targets to build a call graph
$jalTargets = @{}
for ($i = 0x800; $i -lt $b.Length - 4; $i += 4) {
    $val = [BitConverter]::ToUInt32($b, $i)
    if (($val -shr 26) -eq 0x03) {  # JAL opcode = 0x03
        $target = ($val -band 0x03FFFFFF) -shl 2
        $target = $target -bor 0x80000000  # PSX RAM
        $addr = $load + $i - 0x800
        if (-not $jalTargets.ContainsKey($target)) {
            $jalTargets[$target] = @()
        }
        $jalTargets[$target] += $addr
    }
}

# Find most-called functions (likely library/render functions)
Write-Host "=== Most-called functions (top 20) ==="
$sorted = $jalTargets.GetEnumerator() | Sort-Object { $_.Value.Count } -Descending | Select-Object -First 20
foreach ($entry in $sorted) {
    Write-Host "  0x$($entry.Key.ToString('X8')): $($entry.Value.Count) calls"
}

# Search for GPU register access patterns
# GP0 write: sw $xx, 0x1810($yy) where $yy = 0x1F801000 base
# GP1 write: sw $xx, 0x1814($yy)
Write-Host ""
Write-Host "=== GPU register access patterns ==="
$gpuSites = @()
for ($i = 0x800; $i -lt $b.Length - 4; $i += 4) {
    $val = [BitConverter]::ToUInt32($b, $i)
    # lui $xx, 0x1F80 = 0x3Cxx1F80
    if (($val -band 0xFFE0FFFF) -eq 0x3C001F80) {
        $reg = ($val -shr 16) -band 0x1F
        $addr = $load + $i - 0x800
        # Check next 8 instructions for sw to 0x1810 or 0x1814
        for ($j = 1; $j -le 8; $j++) {
            if ($i + $j * 4 -ge $b.Length) { break }
            $next = [BitConverter]::ToUInt32($b, $i + $j * 4)
            # sw $zz, 0x1810($reg) = 0xACzz1810 or sw $zz, 0x1814($reg)
            $offset = $next -band 0x0000FFFF
            if (($next -shr 26) -eq 0x2B -and ($offset -eq 0x1810 -or $offset -eq 0x1814 -or $offset -eq 0x0810 -or $offset -eq 0x0814)) {
                $gpNum = if ($offset -eq 0x1814) { 1 } else { 0 }
                $gpuSites += "0x$($addr.ToString('X8')) +$j -> GP$gpNum write (0x$($next.ToString('X8')))"
            }
        }
    }
}
Write-Host "GPU access sites: $($gpuSites.Count)"
foreach ($s in $gpuSites) { Write-Host "  $s" }

# Search for VRAM DMA transfer pattern (GP1 cmd 0x04 = VRAM transfer)
# Writing 0x04000002 to GP1 = start VRAM transfer from DRAM to VRAM
Write-Host ""
Write-Host "=== VRAM DMA patterns ==="
for ($i = 0x800; $i -lt $b.Length - 4; $i += 4) {
    $val = [BitConverter]::ToUInt32($b, $i)
    # addiu $xx, $zero, 0x0400 = 0x24xx0400 (GP1 VRAM DMA command upper)
    if (($val -band 0xFFFF0000) -eq 0x24000400) {
        $addr = $load + $i - 0x800
        Write-Host "  VRAM DMA cmd at 0x$($addr.ToString('X8')) (0x$($val.ToString('X8')))"
    }
}

# Search for font-related patterns
# DQ4 uses 16-bit font indices. Look for lhu (opcode 0x25) patterns near GPU writes
# Also search for the string table base address
# DQ4 text blocks are in HBD at sector 362+, accessed via CD-ROM reads
# The text pointer table should be in RAM after HBD load

# Search for CD-ROM read register access (0x1F801803)
Write-Host ""
Write-Host "=== CD-ROM register access ==="
for ($i = 0x800; $i -lt $b.Length - 4; $i += 4) {
    $val = [BitConverter]::ToUInt32($b, $i)
    # lui $xx, 0x1F80 followed by access to 0x1800-0x1803
    if (($val -band 0xFFE0FFFF) -eq 0x3C001F80) {
        $addr = $load + $i - 0x800
        for ($j = 1; $j -le 8; $j++) {
            if ($i + $j * 4 -ge $b.Length) { break }
            $next = [BitConverter]::ToUInt32($b, $i + $j * 4)
            $offset = $next -band 0x0000FFFF
            if (($next -shr 26) -eq 0x23 -and $offset -ge 0x1800 -and $offset -le 0x1803) {
                # sb to CD-ROM register
                Write-Host "  CD-ROM write at 0x$($addr.ToString('X8')) +$j (0x$($next.ToString('X8')))"
            }
            if (($next -shr 26) -eq 0x21 -and $offset -ge 0x1800 -and $offset -le 0x1803) {
                # lh from CD-ROM register
                Write-Host "  CD-ROM read at 0x$($addr.ToString('X8')) +$j (0x$($next.ToString('X8')))"
            }
        }
    }
}
