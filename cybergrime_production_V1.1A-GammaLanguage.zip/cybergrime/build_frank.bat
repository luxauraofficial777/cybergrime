@echo off
call "C:\Program Files (x86)\Microsoft Visual Studio\2022\BuildTools\VC\Auxiliary\Build\vcvars64.bat" >nul 2>&1
cl /std:c++17 /EHsc /O2 /Fe:frankenstein_build.exe frankenstein_build_main.cpp psx_binary_ops.cpp /I. /D_CRT_SECURE_NO_WARNINGS /link /SUBSYSTEM:CONSOLE
