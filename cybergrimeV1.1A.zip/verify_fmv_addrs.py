#!/usr/bin/env python3
"""Verify FMV playback function addresses in DW7 EXE and show current instructions."""
import struct
import sys

def main():
    exe_path = sys.argv[1] if len(sys.argv) > 1 else "dw7_exe_clean.bin"
    with open(exe_path, 'rb') as f:
        exe = f.read()

    load_addr = struct.unpack_from('<I', exe, 0x18)[0]
    print(f"EXE size: {len(exe)} bytes")
    print(f"EXE load addr: 0x{load_addr:08X}")

    # FMV playback function addresses to stub
    addrs = [0x8008AEF4, 0x8008CAD0]

    stub = struct.pack('<III', 0x24020000, 0x03E00008, 0x00000000)  # li $v0,0; jr $ra; nop

    for ram in addrs:
        off = ram - load_addr + 0x800
        if off + 12 > len(exe):
            print(f"  RAM 0x{ram:08X} -> offset 0x{off:06X} BEYOND EXE size {len(exe)}")
            continue
        current = exe[off:off+12]
        words = struct.unpack_from('<III', current, 0)
        print(f"\n  RAM 0x{ram:08X} -> file offset 0x{off:06X}")
        print(f"  Current instructions:")
        for i, w in enumerate(words):
            print(f"    [{i}] 0x{w:08X}")
        print(f"  Stub (li $v0,0; jr $ra; nop): {stub.hex()}")

if __name__ == '__main__':
    main()
