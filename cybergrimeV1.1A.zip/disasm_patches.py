#!/usr/bin/env python3
"""Disassemble the disc check bypass patch locations to understand what they do."""
import os, struct
from capstone import Cs, CS_ARCH_MIPS, CS_MODE_MIPS32, CS_MODE_LITTLE_ENDIAN

def read_exe_from_disc(disc_path, exe_lba=24, sector_size=2352, user_offset=24, user_size=2048):
    with open(disc_path, 'rb') as f:
        exe_sectors = 340
        f.seek(exe_lba * sector_size)
        raw = f.read(exe_sectors * sector_size)
    exe_data = bytearray()
    for i in range(exe_sectors):
        sector = raw[i * sector_size:(i + 1) * sector_size]
        if len(sector) < user_offset + user_size:
            break
        exe_data += sector[user_offset:user_offset + user_size]
    return bytes(exe_data)

def disasm_range(exe_data, load_addr, start_ram, end_ram):
    code_offset = 0x800
    file_start = start_ram - load_addr + code_offset
    file_end = end_ram - load_addr + code_offset
    if file_start < 0 or file_end > len(exe_data):
        return "  (outside EXE)\n"
    code = exe_data[file_start:file_end]
    md = Cs(CS_ARCH_MIPS, CS_MODE_MIPS32 | CS_MODE_LITTLE_ENDIAN)
    lines = []
    for insn in md.disasm(code, start_ram):
        lines.append(f"  0x{insn.address:08X}: {insn.mnemonic:8s} {insn.op_str}")
    return '\n'.join(lines) + '\n'

base = r"C:\LuxAura\VoidWalkers_Project\DQLOSTTRANSLATION"
disc = os.path.join(base, "dq4_frankenstein_v41.bin")
load_addr = 0x80017F00
exe = read_exe_from_disc(disc)

# Patch offsets from apply_disc_check_patches (offset + 0x800 in file)
# RAM = load_addr + offset + 0x800 - 0x800 = load_addr + offset
# Actually: file offset = patch.offset + 0x800, RAM = load_addr + patch.offset
# So RAM addr = 0x80017F00 + patch.offset

patches = {
    "exit1_success": 0x6112C,
    "exit2_success": 0x611D8,
    "exit3_success": 0x613B8,
    "cd_init": 0x60FA4,
    "nop_timeout": 0x614A4,
    "nop_error": 0x614F8,
    "neutralize_disc": 0x387CC,
    "redirect_trap": 0x7308C,
    "graft_a": 0x61424,
    "graft_b": 0x61520,
    "graft_c": 0x61360,
}

for name, offset in patches.items():
    ram_addr = load_addr + offset
    print(f"\n=== {name} at RAM 0x{ram_addr:08X} (offset 0x{offset:X}) ===")
    # Show context: 4 instructions before and 8 after
    start = ram_addr - 16
    end = ram_addr + 32
    print(disasm_range(exe, load_addr, start, end))
