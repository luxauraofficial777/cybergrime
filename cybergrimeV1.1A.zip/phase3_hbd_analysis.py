"""Phase 3: D3 objective gate — analyze translation map and HBD text injection."""
import struct, sys, os

PYTHON = r'C:\Users\XFO777\AppData\Local\hermes\hermes-agent\venv\Scripts\python.exe'

TXMP_PATH = r'c:\LuxAura\VoidWalkers_Project\DQLOSTTRANSLATION\cybergrime\translation_map.bin'
DQ4_DISC  = r'c:\LuxAura\VoidWalkers_Project\DQLOSTTRANSLATION\Dragon Quest IV - Michibikareshi Mono Tachi (Japan).bin'
V108_DISC = r'c:\LuxAura\VoidWalkers_Project\DQLOSTTRANSLATION\build_staging\dq4_frankenstein_v108.bin'
HBD_SECTOR_DQ4 = 362  # DQ4 HBD start
HBD_SECTOR_V108 = 362  # Same target

SECTOR = 2048

def read_sector(f, lba, mode2=True):
    if mode2:
        f.seek(lba * 2352 + 24)
    else:
        f.seek(lba * 2048)
    return f.read(2048)

def read_sectors(f, lba, count, mode2=True):
    data = bytearray()
    for i in range(count):
        data += read_sector(f, lba + i, mode2)
    return bytes(data)

print("=" * 70)
print("PHASE 3: D3 OBJECTIVE GATE — English Text in HBD?")
print("=" * 70)

# 1. Parse translation map
print("\n--- 1. Translation Map Analysis ---")
with open(TXMP_PATH, 'rb') as f:
    magic = f.read(4)
    assert magic == b'TXMP', f"Bad magic: {magic}"
    entry_count = struct.unpack('<I', f.read(4))[0]
    print(f"  Magic: TXMP")
    print(f"  Entry count: {entry_count}")

    entries = []
    total_encoded_bytes = 0
    for i in range(entry_count):
        text_id, seq_count = struct.unpack('<HH', f.read(4))
        seqs = []
        for s in range(seq_count):
            enc_len = struct.unpack('<I', f.read(4))[0]
            enc_data = f.read(enc_len)
            seqs.append(enc_data)
            total_encoded_bytes += enc_len
        entries.append((text_id, seq_count, sum(len(s) for s in seqs)))

    print(f"  Total encoded bytes: {total_encoded_bytes}")
    print(f"  Average bytes/entry: {total_encoded_bytes / max(entry_count, 1):.1f}")

    # Show first 10 entries
    print(f"\n  First 10 entries:")
    for i, (tid, sc, sz) in enumerate(entries[:10]):
        print(f"    [{i:4d}] text_id=0x{tid:04X} ({tid:5d}) seqs={sc} total_bytes={sz}")

    # Show last 5
    print(f"  Last 5 entries:")
    for i, (tid, sc, sz) in enumerate(entries[-5:]):
        idx = entry_count - 5 + i
        print(f"    [{idx:4d}] text_id=0x{tid:04X} ({tid:5d}) seqs={sc} total_bytes={sz}")

    # Check for ASCII content in encoded bytes
    f.seek(8)  # Skip header
    all_bytes = f.read()
    ascii_count = sum(1 for b in all_bytes if 0x20 <= b <= 0x7E)
    print(f"\n  ASCII printable bytes in map: {ascii_count} / {len(all_bytes)} ({100*ascii_count/max(len(all_bytes),1):.1f}%)")

# 2. Extract HBD from both discs and compare
print("\n--- 2. HBD Comparison: DQ4 source vs v108 build ---")

# Read first 128KB of HBD from each
HBD_READ_SECTORS = 64  # 128KB

with open(DQ4_DISC, 'rb') as f:
    dq4_hbd = read_sectors(f, HBD_SECTOR_DQ4, HBD_READ_SECTORS)

with open(V108_DISC, 'rb') as f:
    v108_hbd = read_sectors(f, HBD_SECTOR_V108, HBD_READ_SECTORS)

print(f"  DQ4 HBD: {len(dq4_hbd)} bytes from sector {HBD_SECTOR_DQ4}")
print(f"  V108 HBD: {len(v108_hbd)} bytes from sector {HBD_SECTOR_V108}")

# Count differing bytes
diff_count = sum(1 for i in range(min(len(dq4_hbd), len(v108_hbd))) if dq4_hbd[i] != v108_hbd[i])
print(f"  Differing bytes (first 128KB): {diff_count} ({100*diff_count/len(dq4_hbd):.2f}%)")

# Find differing regions
diff_regions = []
in_diff = False
start = 0
for i in range(min(len(dq4_hbd), len(v108_hbd))):
    if dq4_hbd[i] != v108_hbd[i]:
        if not in_diff:
            start = i
            in_diff = True
    else:
        if in_diff:
            diff_regions.append((start, i, i - start))
            in_diff = False
if in_diff:
    diff_regions.append((start, len(dq4_hbd), len(dq4_hbd) - start))

print(f"  Differing regions: {len(diff_regions)}")
if diff_regions:
    print(f"  First 10 regions:")
    for s, e, sz in diff_regions[:10]:
        print(f"    offset 0x{s:05X}-0x{e:05X} ({sz} bytes)")
    print(f"  Largest 5 regions:")
    for s, e, sz in sorted(diff_regions, key=lambda x: -x[2])[:5]:
        print(f"    offset 0x{s:05X}-0x{e:05X} ({sz} bytes)")

# 3. Check for English ASCII strings in v108 HBD
print("\n--- 3. English ASCII String Search in v108 HBD ---")
# Look for common English words
english_words = [b'Hero', b'Alchemist', b'Maribel', b'Kiefer', b'Gabriel', b'Battle',
                 b'Attack', b'Defend', b'Item', b'Magic', b'Run', b'You', b'The ',
                 b'is ', b'was ', b'the ', b'and ', b'for ', b'with ']
found_words = []
for word in english_words:
    pos = v108_hbd.find(word)
    if pos >= 0:
        found_words.append((word.decode(), pos))
        print(f"  FOUND: '{word.decode()}' at offset 0x{pos:05X}")

if not found_words:
    print("  No common English words found in first 128KB of v108 HBD")

# Search in larger range
print("\n  Searching first 1MB of v108 HBD...")
with open(V108_DISC, 'rb') as f:
    v108_hbd_large = read_sectors(f, HBD_SECTOR_V108, 512)  # 1MB

for word in english_words:
    pos = v108_hbd_large.find(word)
    if pos >= 0:
        print(f"  FOUND (1MB): '{word.decode()}' at offset 0x{pos:05X}")

# 4. Check how many HBD block IDs match translation map entries
print("\n--- 4. Block ID Matching ---")
# Parse first few HBD folders from DQ4 to extract block_ids
text_ids_in_map = set(tid for tid, _, _ in entries)

# Parse HBD structure from DQ4
with open(DQ4_DISC, 'rb') as f:
    # Read enough sectors to find several folders
    hbd_data = read_sectors(f, HBD_SECTOR_DQ4, 256)  # 512KB

block_ids_found = []
sector_idx = 1
total_sectors = len(hbd_data) // SECTOR

while sector_idx < total_sectors:
    sec = hbd_data[sector_idx * SECTOR:(sector_idx + 1) * SECTOR]
    file_count = struct.unpack_from('<I', sec, 0)[0]
    sector_count = struct.unpack_from('<I', sec, 4)[0]

    if sec[0] == 0x60 and sec[1] == 0x01 and sec[2] == 0x01 and sec[3] == 0x80:
        sector_idx += 1
        continue

    if file_count == 0 or file_count > 1000 or sector_count == 0 or sector_count > 1000:
        sector_idx += 1
        continue

    if 16 + file_count * 16 > SECTOR or sector_idx + sector_count > total_sectors:
        sector_idx += 1
        continue

    # Parse files in this folder
    folder_start = sector_idx * SECTOR
    for fi in range(file_count):
        fh_off = folder_start + 16 + fi * 16
        if fh_off + 16 > len(hbd_data):
            break
        size = struct.unpack_from('<I', hbd_data, fh_off)[0]
        content_offset = struct.unpack_from('<I', hbd_data, fh_off + 8)[0]
        # Actually content_offset is computed as running_offset, not from file header
        # Let me compute it properly
        # For now, just get block_id from the first few blocks

    # Try to extract block_ids from this folder
    content_start = 16 + file_count * 16
    running_offset = content_start
    for fi in range(file_count):
        fh_off = 16 + fi * 16
        if fh_off + 16 > SECTOR:
            break
        size = struct.unpack_from('<I', sec, fh_off)[0]
        # Block header at content_offset within folder
        block_off = folder_start + running_offset
        if block_off + 24 <= len(hbd_data):
            end, block_id, hts = struct.unpack_from('<III', hbd_data, block_off)
            if hts >= 24 and hts < 65536 and end > hts and end < 1048576:
                text_id = block_id & 0xFFFF
                in_map = text_id in text_ids_in_map
                block_ids_found.append((block_id, text_id, in_map))
                if len(block_ids_found) <= 20:
                    print(f"  block_id=0x{block_id:08X} text_id=0x{text_id:04X} in_map={in_map}")
        running_offset += size

    sector_idx += sector_count

print(f"\n  Total blocks found in DQ4 HBD (first 512KB): {len(block_ids_found)}")
matched = sum(1 for _, _, in_map in block_ids_found if in_map)
print(f"  Matched in translation map: {matched} / {len(block_ids_found)}")

# 5. Summary
print("\n" + "=" * 70)
print("PHASE 3 SUMMARY")
print("=" * 70)
print(f"  Translation map entries: {entry_count}")
print(f"  Total encoded bytes in map: {total_encoded_bytes}")
print(f"  HBD bytes compared (first 128KB): {len(dq4_hbd)}")
print(f"  HBD differing bytes: {diff_count} ({100*diff_count/len(dq4_hbd):.2f}%)")
print(f"  HBD differing regions: {len(diff_regions)}")
print(f"  English words found in v108 HBD: {len(found_words)}")
print(f"  Block IDs matched to translation map: {matched} / {len(block_ids_found)}")

if matched > 0 and total_encoded_bytes > 1000:
    print(f"\n  GATE: PARTIAL — translation map has entries and some block IDs match")
    print(f"  NOTE: Build log reported 'reencoded' count — check build output for details")
elif entry_count > 0 and matched == 0:
    print(f"\n  GATE: FAIL — translation map has {entry_count} entries but none match HBD block IDs")
    print(f"  ROOT CAUSE: text_id encoding mismatch (block_id & 0xFFFF vs map keys)")
else:
    print(f"\n  GATE: UNKNOWN — insufficient data")
