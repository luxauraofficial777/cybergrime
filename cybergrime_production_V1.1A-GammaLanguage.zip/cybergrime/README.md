# CyberGrime — PSX Emulator & Reverse-Engineering Toolkit

A from-scratch PlayStation (PSX) emulator built for reverse engineering and
automated testing of Dragon Quest IV (PSX) translation patches.

## Quick Start

### Build

```powershell
cd cybergrime
build_agent.bat           # release build
build_agent.bat debug     # debug build with extra logging
build_agent.bat clean     # clean + release build
```

Requires: MSVC 2022 Build Tools, Windows SDK 10.

### Run

```powershell
# Basic boot test (5M instructions, 60s timeout)
psx_agent_runner.exe disc.bin smoke_test telemetry.json 60000

# Full boot with timeline + screenshot
psx_agent_runner.exe disc.bin full_test telemetry.json 600000 55000000 --timeline timeline.json --screenshot title.bmp

# Load state and continue
psx_agent_runner.exe disc.bin resume_test telemetry.json 60000 --loadstate boot_state.bin

# Interactive debugger
psx_agent_runner.exe disc.bin debug_test telemetry.json 600000 --console

# GDB remote debugging
psx_agent_runner.exe disc.bin gdb_test telemetry.json 600000 --gdb 3333
# Then: gdb-multiarch -ex "target remote :3333"

# Lua automation
psx_agent_runner.exe disc.bin lua_test telemetry.json 600000 --lua bot.lua
```

### Regression Testing

```powershell
# Run all tests
python regression_runner.py

# Run a specific profile
python regression_runner.py quick_smoke

# Save a baseline
python baseline_manager.py save build_v21 telemetry_smoke.json

# Compare against baseline
python baseline_manager.py compare build_v21 telemetry_smoke.json

# Diff telemetry against baseline
python baseline_manager.py diff build_v21 telemetry_smoke.json
```

### ISO Toolkit

```powershell
python iso_toolkit.py list disc.bin
python iso_toolkit.py info disc.bin
python iso_toolkit.py extract disc.bin SLUS_012.06 exe.bin
python iso_toolkit.py diff disc_a.bin disc_b.bin
python iso_toolkit.py edc disc.bin
python iso_toolkit.py patch disc.bin patches.json out.bin
```

## CLI Flags

| Flag | Description |
|---|---|
| `--bp <addr>` | Add breakpoint (log only) |
| `--bp-halt <addr>` | Add breakpoint that halts execution |
| `--wp <addr>` | Add memory watchpoint |
| `--trace-from <addr>` | Start instruction trace from address |
| `--trace-to <file>` | Trace output file path |
| `--inject <json>` | RAM injection spec file |
| `--monitor <json>` | Buffer monitor spec file |
| `--symbols <json>` | Load symbol table for named addresses |
| `--console` | Enable interactive stdin console |
| `--savestate-out <file>` | Save emulator state to file on exit |
| `--loadstate <file>` | Load emulator state from file before boot |
| `--screenshot <file.bmp>` | Dump framebuffer to BMP on exit |
| `--timeline <file.json>` | Export event timeline as JSON |
| `--gdb [port]` | Start GDB remote stub (default port 3333) |
| `--rewind` | Enable rewind snapshot buffer |
| `--lua <file.lua>` | Load Lua automation script |
| `--psn00b-align` | Map watchpoints to BIOS vectors + GTE registers |
| `--huffman-trace` | Active trace on decompression + text cache buffer |
| `--rebuild-iso <xml>` | Generate ISO rebuild manifest from layout XML |

## Architecture

```
cybergrime/
├── psx_agent_runner.cpp    — Main entry point, CLI parsing, emulation loop
├── psx_emulator_core.cpp   — CPU step, memory, GPU, CD-ROM, DMA, timers
├── psx_test_station.h      — MIPS CPU, PSX Memory, hardware register defs
├── psx_gpu.h               — Polygon rasterizer and VRAM
├── psx_gte.h               — Geometry Transformation Engine
├── psx_spu.h               — Sound Processing Unit (ADPCM)
├── psx_mdec.h              — Motion DECoder (FMV)
├── psx_xa.h                — XA-ADPCM audio
├── psx_debugger.h          — Interactive CLI debugger
├── psx_savestate.h         — Save/load state serialization
├── psx_timeline.h          — Event timeline recorder
├── psx_rewind.h            — Rewind snapshot circular buffer
├── psx_gdb_stub.h          — GDB remote serial protocol stub
├── psx_lua.h               — Lua scripting engine bindings
├── agent_harness.h/.cpp    — TTY interception, VFS logging, telemetry
├── CybergrimeUI.h/.cpp     — UI rendering (VRAM viewer, heatmap, CRT effects)
├── orchestration_engine.h  — Blueprint-driven orchestration
├── txrt_hle.h              — HLE BIOS call interception
├── build_agent.bat         — Build script
├── test_definitions.json   — Test definitions and profiles
├── regression_runner.py    — Regression test runner
├── baseline_manager.py     — Telemetry baseline comparison
├── iso_toolkit.py          — ISO9660 manipulation tool
└── examples/               — Example scripts and configs
```

## Documentation

- [Architecture](docs/ARCHITECTURE.md) — Emulator, harness, and tooling design
- [Testing](docs/TESTING.md) — How to write and run tests
- [Tools](docs/TOOLS.md) — CLI reference for every tool
- [PSX Reference](docs/PSX_REFERENCE.md) — Memory map, BIOS calls, hardware registers

## GammaLanguage v1.1C Integration

CyberGrime integrates with GammaLanguage v1.1C for MIPS assembly directives, CP0 register mapping, and PSXMatrix DMA dispatch via the Rust FFI bridge.

### What's New in v1.1C

- **CP0 Register Mapping:** `CyberGrimeCP0Map` struct maps MIPS R3000A CP0 registers (Status, Cause, EPC, BadVAddr, Count, Compare, EntryHi, Index) into the Gamma `RegisterBank`
- **`CP0_REG_MAP` opcode (0xA3):** Maps CP0 state from CyberGrime MIPS assembly into Gamma register bank for speculative execution
- **`PSX_DMA_DISPATCH` opcode (0xA4):** Dispatches PSX DMA channels (CH1/CH2) via Rust FFI bridge with hardware interrupt triggering
- **`PSXHwRegMap` struct:** Maps PSX hardware registers — DMA_CH1/CH2 MADR/BCR/CHCR, GPU GP0/GP1, I_STAT/I_MASK
- **Rust FFI Zero-Copy:** `&RUST_OFFSET` sigil enables zero-copy memory access to PSX hardware register space
- **Alignment Bounds:** `@ALIGN_BOUND(BOUND=16)` ensures memory alignment parity between CyberGrime MIPS and Rust FFI exports
- **PEAK Subsystem Bridging:** `RUST_FFI_CALL` dispatches to PEAK-1..5 (bytecode export, QVec SIMD, speculative scope, HW interrupt, ring buffer)

### Integration Points

| CyberGrime Component | GammaLanguage v1.1C Feature |
|----------------------|----------------------------|
| MIPS R3000A CP0 registers | `CP0_REG_MAP` opcode → `CyberGrimeCP0Map` |
| DMA controller (CH1/CH2) | `PSX_DMA_DISPATCH` opcode → `PSXHwRegMap` |
| Hardware interrupt controller | `RUST_FFI_CALL` → PEAK-4 HW interrupt dispatch |
| GPU GP0/GP1 registers | `PSXHwRegMap` → Rust FFI zero-copy read/write |
| I_STAT / I_MASK registers | `PSXHwRegMap` → interrupt mask via FFI bridge |

## License

Internal project — not for public distribution.
