"""Verify v108 build: D1 XA stub + D2 MISS-1 load-delay fix."""
import struct, sys

def extract_exe(bin_path, start_lba=24, nbytes=700000):
    out = bytearray()
    with open(bin_path, 'rb') as f:
        lba = start_lba
        while len(out) < nbytes:
            f.seek(lba * 2352 + 24)
            out += f.read(2048)
            lba += 1
    return bytes(out[:nbytes])

def read32(data, off):
    return struct.unpack_from('<I', data, off)[0]

def ram_to_off(ram):
    return ram - 0x80017F00 + 0x800

bin_path = sys.argv[1] if len(sys.argv) > 1 else r'c:\LuxAura\VoidWalkers_Project\DQLOSTTRANSLATION\build_staging\dq4_frankenstein_v108.bin'

print(f"Extracting EXE from {bin_path}...")
exe = extract_exe(bin_path)
assert exe[0:8] == b'PS-X EXE', "Bad EXE magic!"

pc0 = read32(exe, 0x10)
load_addr = read32(exe, 0x18)
text_size = read32(exe, 0x1C)
print(f"PC0: 0x{pc0:08X}, Load: 0x{load_addr:08X}, TextSize: 0x{text_size:08X}")

# MISS-1 boot copy stub is at PC0 = 0x800BDF00
# stub_ram_addr = 0x800BDF00
# stub_file_off = 0x800BDF00 - 0x80017F00 + 0x800 = 0xA6600 + 0x800 = 0xA6E00
# Wait, let me compute: ram - load_addr + 0x800
stub_ram = pc0
stub_off = stub_ram - load_addr + 0x800
print(f"\nMISS-1 boot copy stub at RAM 0x{stub_ram:08X}, file offset 0x{stub_off:06X}")

# Read 13 instructions (52 bytes)
print("Boot copy stub instructions:")
for i in range(13):
    off = stub_off + i * 4
    val = read32(exe, off)
    print(f"  [{i:2d}] off=0x{off:06X} 0x{val:08X}")

# Verify D2 fix: instruction at stub[7] should be ADDIU (not SW)
# Expected layout after D2 fix:
# [0] lui $t0, src_hi
# [1] addiu $t0, $t0, src_lo
# [2] lui $t1, 0x800D
# [3] addiu $t1, $t1, 0x9E80
# [4] lui $t2, 0x800D
# [5] addiu $t2, $t2, 0xA680
# [6] lw $t3, 0($t0)      — opcode 0x8D??0000
# [7] addiu $t0, $t0, 4   — opcode 0x25080004  (D2 fix: was sw before)
# [8] sw $t3, 0($t1)      — opcode 0xAD6B0000
# [9] bne $t1, $t2, -4    — opcode 0x154A????
# [10] addiu $t1, $t1, 4  — opcode 0x25290004
# [11] j 0x8008E284       — opcode 0x080238A1
# [12] nop                — opcode 0x00000000

checks = [
    ("stub[6] lw $t3",    stub_off + 24, 0x8D6B0000, "lw $t3,0($t0) — opcode bits"),
    ("stub[7] addiu $t0", stub_off + 28, 0x25080004, "D2 FIX: addiu $t0,$t0,4 (delay slot fill)"),
    ("stub[8] sw $t3",    stub_off + 32, 0xAD6B0000, "sw $t3,0($t1) — now after delay slot"),
    ("stub[10] addiu $t1",stub_off + 40, 0x25290004, "delay slot: addiu $t1,$t1,4"),
    ("stub[11] j orig_pc0",stub_off + 44, 0x080238A1, "j 0x8008E284"),
    ("stub[12] nop",      stub_off + 48, 0x00000000, "nop"),
]

# For lw/sw, check opcode bits only (not exact match since reg encoding may vary)
passes = 0
fails = 0

for name, off, expected, note in checks:
    actual = read32(exe, off)
    if "lw" in name:
        ok = (actual >> 26) == 0x23  # LW opcode
    elif "sw" in name and "stub" in name:
        ok = (actual >> 26) == 0x2B  # SW opcode
    elif "addiu" in name.lower():
        ok = (actual >> 26) == 0x09  # ADDIU opcode
    elif "j " in name:
        ok = (actual >> 26) == 0x02  # J opcode
    elif "nop" in name:
        ok = actual == 0
    else:
        ok = actual == expected
    status = "PASS" if ok else "FAIL"
    if ok: passes += 1
    else: fails += 1
    print(f"  {status} {name:25s} got=0x{actual:08X} ({note})")

# Also verify D1 fix is still present
d1_off = ram_to_off(0x8008B334)
d1_val = read32(exe, d1_off)
d1_ok = d1_val == 0xAC222038
print(f"\n  {'PASS' if d1_ok else 'FAIL'} D1 XA stub sw_2038: 0x{d1_val:08X}")
if d1_ok: passes += 1
else: fails += 1

print(f"\nVERIFY: {'PASS' if fails == 0 else 'FAIL'} ({passes}/{passes+fails})")
sys.exit(0 if fails == 0 else 1)
