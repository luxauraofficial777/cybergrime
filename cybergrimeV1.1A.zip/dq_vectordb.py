#!/usr/bin/env python3
"""DQLOSTTRANSLATION VectorDB — SQLite FTS5 knowledge base.

Indexes all study documents, source code, decompilation outputs, and
session notes into a searchable knowledge base. Uses BM25 ranking via
SQLite FTS5 for cross-referencing findings across the entire project.

Usage:
    python dq_vectordb.py index          # Build/rebuild index
    python dq_vectordb.py query <text>   # Search the index
    python dq_vectordb.py status         # Show index statistics
    python dq_vectordb.py cross-ref      # Cross-reference key findings
"""

import os
import re
import sys
import json
import sqlite3
import hashlib
import time
from pathlib import Path

DB_PATH = os.path.join(os.path.dirname(__file__), "dq_vectordb.db")
PROJECT_ROOT = os.path.dirname(os.path.dirname(__file__))  # DQLOSTTRANSLATION

# Directories to index
INDEX_DIRS = [
    "study",
    "cybergrime",
    "translation-tools",
    "decompile",
    "_archive_scripts",
]

# File extensions to index
INDEX_EXTS = {".md", ".py", ".cpp", ".h", ".java", ".json", ".txt", ".c", ".js"}

# Directories to skip (noisy/irrelevant)
SKIP_DIRS = {
    "__pycache__", ".git", "node_modules", "target", "SDL2-2.30.3",
    "psxe", "starpsx", "PSX_MiSTer", "pctation", "ghidra_project",
    "c_synthesis_output", "build", "dist", ".gradle", "update_classes",
    "famicom", "dragon-hackst-4-src",
}

# Key findings to cross-reference
CROSS_REF_QUERIES = [
    ("HBD block types 32 46", "type 32 OR type 46 OR block_type OR reencode OR re-encode"),
    ("Disc check bypass", "disc_check OR disc_check OR \"insert disc\" OR \"wrong disc\" OR disc_bypass"),
    ("Huffman tree incompatibility", "huffman OR tree_end OR root_id OR per-block OR hybrid_tree"),
    ("BSS corruption", "BSS OR bss_clear OR bss_corrupt OR 0x800F2228"),
    ("CD-ROM stall loop", "cdrom OR cd_rom OR stall OR Getstat OR Setloc OR polling"),
    ("LBA pointer remapping", "LBA OR abs_table OR rel_table OR pointer OR sector OR folder_mapping"),
    ("Crash analysis", "crash OR PC=0x800761DC OR 0x800E23C4 OR jr_zero OR invalid_pointer"),
    ("MIPS patching", "MIPS OR patch OR lui OR addiu OR jal OR trampoline OR shim"),
    ("DQ4 native EXE", "DQ4 EXE OR dq4_exe OR native OR rc2 OR SLPM"),
    ("FMV playback", "FMV OR fmv OR STR OR XA OR MDEC OR 146621"),
    ("Thread entry preservation", "thread_entry OR 0x800D9E80 OR ChangeTh OR thread_fix"),
    ("Block header reader", "block_reader OR 0x80042A04 OR 0x800429F0 OR block_header"),
    ("Decompressor", "decompress OR 0x80073670 OR huffman_decode"),
    ("Boot sequence", "boot OR PC0 OR entry_point OR BSS_clear OR event_loop"),
]

SCHEMA = """
CREATE VIRTUAL TABLE documents USING fts5(
    file_path,
    file_name,
    directory,
    extension,
    content,
    chunk_index UNINDEXED,
    chunk_hash UNINDEXED,
    line_start UNINDEXED,
    line_end UNINDEXED,
    file_size UNINDEXED,
    indexed_at UNINDEXED,
    tokenize='porter unicode61'
);

CREATE TABLE IF NOT EXISTS index_meta (
    key TEXT PRIMARY KEY,
    value TEXT
);
"""

def chunk_text(text, max_chunk=4000, overlap=200):
    """Split text into overlapping chunks for better search granularity."""
    lines = text.split('\n')
    chunks = []
    current = []
    current_size = 0
    line_start = 0
    line_num = 0

    for line in lines:
        line_len = len(line) + 1
        if current_size + line_len > max_chunk and current:
            chunks.append({
                'content': '\n'.join(current),
                'line_start': line_start,
                'line_end': line_num - 1,
            })
            # Keep overlap
            overlap_lines = []
            overlap_size = 0
            for l in reversed(current):
                if overlap_size + len(l) > overlap:
                    break
                overlap_lines.insert(0, l)
                overlap_size += len(l) + 1
            current = overlap_lines
            current_size = overlap_size
            line_start = line_num - len(overlap_lines)
        current.append(line)
        current_size += line_len
        line_num += 1

    if current:
        chunks.append({
            'content': '\n'.join(current),
            'line_start': line_start,
            'line_end': line_num - 1,
        })

    return chunks


def should_index(path):
    """Check if a file should be indexed."""
    rel = os.path.relpath(path, PROJECT_ROOT)
    parts = rel.replace('\\', '/').split('/')

    for skip in SKIP_DIRS:
        if skip in parts:
            return False

    ext = os.path.splitext(path)[1].lower()
    if ext not in INDEX_EXTS:
        return False

    # Skip very large files (> 5MB)
    try:
        size = os.path.getsize(path)
        if size > 5_000_000:
            return False
    except OSError:
        return False

    return True


def collect_files():
    """Collect all files to index."""
    files = []
    for dir_name in INDEX_DIRS:
        dir_path = os.path.join(PROJECT_ROOT, dir_name)
        if not os.path.isdir(dir_path):
            continue
        for root, dirs, filenames in os.walk(dir_path):
            # Filter out skip dirs in-place
            dirs[:] = [d for d in dirs if d not in SKIP_DIRS]
            for fname in filenames:
                fpath = os.path.join(root, fname)
                if should_index(fpath):
                    files.append(fpath)
    return files


def build_index():
    """Build the FTS5 index from scratch."""
    if os.path.exists(DB_PATH):
        os.remove(DB_PATH)

    conn = sqlite3.connect(DB_PATH)
    conn.executescript(SCHEMA)

    files = collect_files()
    total_chunks = 0
    now = str(int(time.time()))

    for fpath in files:
        try:
            with open(fpath, 'r', encoding='utf-8', errors='replace') as f:
                content = f.read()
        except Exception:
            continue

        rel_path = os.path.relpath(fpath, PROJECT_ROOT).replace('\\', '/')
        file_name = os.path.basename(fpath)
        directory = os.path.dirname(rel_path)
        ext = os.path.splitext(fpath)[1].lower()
        file_size = len(content)

        chunks = chunk_text(content)
        for i, chunk in enumerate(chunks):
            chunk_hash = hashlib.md5(chunk['content'].encode('utf-8')).hexdigest()
            conn.execute(
                "INSERT INTO documents VALUES (?,?,?,?,?,?,?,?,?,?,?)",
                (rel_path, file_name, directory, ext, chunk['content'],
                 i, chunk_hash, chunk['line_start'], chunk['line_end'],
                 file_size, now)
            )
            total_chunks += 1

    conn.execute("INSERT OR REPLACE INTO index_meta VALUES ('total_files', ?)", (str(len(files)),))
    conn.execute("INSERT OR REPLACE INTO index_meta VALUES ('total_chunks', ?)", (str(total_chunks),))
    conn.execute("INSERT OR REPLACE INTO index_meta VALUES ('last_index', ?)", (now,))
    conn.commit()
    conn.close()

    return len(files), total_chunks


def query_db(query_text, limit=20):
    """Query the FTS5 index with BM25 ranking."""
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row

    # Use BM25 ranking
    sql = """
        SELECT file_path, file_name, directory, extension,
               chunk_index, line_start, line_end,
               snippet(documents, 4, '>>', '<<', '...', 30) as snippet,
               bm25(documents) as score
        FROM documents
        WHERE documents MATCH ?
        ORDER BY score
        LIMIT ?
    """

    try:
        results = conn.execute(sql, (query_text, limit)).fetchall()
    except sqlite3.OperationalError as e:
        print(f"Query error: {e}")
        results = []

    conn.close()
    return results


def show_status():
    """Show index statistics."""
    if not os.path.exists(DB_PATH):
        print("No index found. Run 'index' first.")
        return

    conn = sqlite3.connect(DB_PATH)
    meta = dict(conn.execute("SELECT key, value FROM index_meta").fetchall())

    count = conn.execute("SELECT COUNT(*) FROM documents").fetchone()[0]
    ext_dist = conn.execute("""
        SELECT extension, COUNT(*) as cnt
        FROM documents
        GROUP BY extension
        ORDER BY cnt DESC
    """).fetchall()

    dir_dist = conn.execute("""
        SELECT directory, COUNT(*) as cnt
        FROM documents
        GROUP BY directory
        ORDER BY cnt DESC
        LIMIT 20
    """).fetchall()

    conn.close()

    print(f"=== DQLOSTTRANSLATION VectorDB Status ===")
    print(f"Database: {DB_PATH}")
    print(f"Size: {os.path.getsize(DB_PATH):,} bytes")
    print(f"Files indexed: {meta.get('total_files', '?')}")
    print(f"Total chunks: {count}")
    print(f"Last indexed: {time.ctime(int(meta.get('last_index', 0)))}")
    print()
    print("By extension:")
    for ext, cnt in ext_dist:
        print(f"  {ext:8s} {cnt:6d} chunks")
    print()
    print("Top directories:")
    for d, cnt in dir_dist:
        print(f"  {d:40s} {cnt:6d} chunks")


def cross_reference():
    """Run pre-defined cross-reference queries and show results."""
    if not os.path.exists(DB_PATH):
        print("No index found. Run 'index' first.")
        return

    print("=" * 80)
    print("CROSS-REFERENCE ANALYSIS — DQLOSTTRANSLATION VectorDB")
    print("=" * 80)

    all_findings = {}

    for title, query in CROSS_REF_QUERIES:
        results = query_db(query, limit=10)
        print(f"\n{'─' * 80}")
        print(f"QUERY: {title}")
        print(f"FTS5:  {query}")
        print(f"{'─' * 80}")

        if not results:
            print("  (no results)")
            continue

        seen_files = set()
        for r in results:
            if r['file_path'] in seen_files:
                continue
            seen_files.add(r['file_path'])
            score = r['score']
            snippet = r['snippet'].replace('\n', ' ').strip()
            if len(snippet) > 200:
                snippet = snippet[:200] + "..."
            print(f"  [{score:7.2f}] {r['file_path']}:{r['line_start']}-{r['line_end']}")
            print(f"          {snippet}")
            print()

        all_findings[title] = [r['file_path'] for r in results]

    # Find overlapping files across queries
    print(f"\n{'=' * 80}")
    print("CROSS-QUERY OVERLAP — Files appearing in multiple finding categories")
    print(f"{'=' * 80}")

    file_queries = {}
    for title, files in all_findings.items():
        for f in files:
            if f not in file_queries:
                file_queries[f] = []
            file_queries[f].append(title)

    overlaps = {f: q for f, q in file_queries.items() if len(q) > 1}
    for f, queries in sorted(overlaps.items(), key=lambda x: -len(x[1])):
        print(f"  {f}")
        for q in queries:
            print(f"    → {q}")
        print()


def main():
    if len(sys.argv) < 2:
        print("Usage: python dq_vectordb.py [index|query <text>|status|cross-ref]")
        sys.exit(1)

    cmd = sys.argv[1]

    if cmd == "index":
        print("Building DQLOSTTRANSLATION VectorDB...")
        t0 = time.time()
        files, chunks = build_index()
        elapsed = time.time() - t0
        print(f"Indexed {files} files, {chunks} chunks in {elapsed:.1f}s")
        print(f"Database: {DB_PATH} ({os.path.getsize(DB_PATH):,} bytes)")

    elif cmd == "query":
        if len(sys.argv) < 3:
            print("Usage: python dq_vectordb.py query <search text>")
            sys.exit(1)
        query = sys.argv[2]
        results = query_db(query, limit=30)
        print(f"Results for: {query}\n")
        for r in results:
            score = r['score']
            snippet = r['snippet'].replace('\n', ' ').strip()
            print(f"[{score:7.2f}] {r['file_path']}:{r['line_start']}-{r['line_end']}")
            print(f"  {snippet}")
            print()

    elif cmd == "status":
        show_status()

    elif cmd == "cross-ref":
        cross_reference()

    else:
        print(f"Unknown command: {cmd}")
        print("Usage: python dq_vectordb.py [index|query <text>|status|cross-ref]")
        sys.exit(1)


if __name__ == "__main__":
    main()
