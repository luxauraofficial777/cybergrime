#!/usr/bin/env python3
"""
Copy DW7 HBD sectors at the stall LBA range to the Frankenstein disc.
The DW7 EXE seeks to LBA ~146000+ and expects to find DW7 HBD data there.
The Frankenstein disc has DQ4 HBD data at those LBAs instead.
This script overwrites those sectors with the original DW7 data.
"""
import struct
import sys
import os

DW7_PATH = r"C:\LuxAura\VoidWalkers_Project\DQLOSTTRANSLATION\DW7D1\DW7D1.bin"
FRANK_PATH = r"C:\LuxAura\VoidWalkers_Project\DQLOSTTRANSLATION\dq4_reverse_a.bin"
OUTPUT_PATH = r"C:\LuxAura\VoidWalkers_Project\DQLOSTTRANSLATION\dq4_reverse_a_fmv.bin"
CUE_PATH = r"C:\LuxAura\VoidWalkers_Project\DQLOSTTRANSLATION\dq4_reverse_a_fmv.cue"

# The game seeks to LBA 146621 (BCD 32:34:71) to read HBD data.
# The Frankenstein disc has DQ4 HBD which is smaller (319MB vs 618MB).
# LBA 146621 is near the end of DQ4 HBD and contains all zeros.
# Copy just the sectors the game seeks to from DW7.
COPY_START = 146621
COPY_END = 146621

def main():
    print("Loading DW7 disc...")
    with open(DW7_PATH, 'rb') as f:
        dw7 = f.read()
    
    print("Loading Frankenstein disc...")
    with open(FRANK_PATH, 'rb') as f:
        frank = bytearray(f.read())
    
    dw7_sectors = len(dw7) // 2352
    frank_sectors = len(frank) // 2352
    
    print(f"DW7: {dw7_sectors} sectors, Frank: {frank_sectors} sectors")
    print(f"Copying LBA {COPY_START}-{COPY_END} from DW7 to Frankenstein...")
    
    sectors_copied = 0
    sectors_same = 0
    for lba in range(COPY_START, COPY_END + 1):
        if lba >= dw7_sectors or lba >= frank_sectors:
            print(f"  LBA {lba}: beyond disc boundary, stopping")
            break
        
        dw7_off = lba * 2352
        frank_off = lba * 2352
        
        # Check if already matching
        if frank[frank_off:frank_off+2352] == dw7[dw7_off:dw7_off+2352]:
            sectors_same += 1
            continue
        
        # Copy the full 2352-byte sector from DW7 to Frankenstein
        frank[frank_off:frank_off+2352] = dw7[dw7_off:dw7_off+2352]
        sectors_copied += 1
        
        if lba % 500 == 0:
            print(f"  LBA {lba}...")
    
    print(f"\nSectors copied: {sectors_copied}")
    print(f"Sectors already matching: {sectors_same}")
    
    # Write output
    print(f"\nWriting output to {OUTPUT_PATH}...")
    with open(OUTPUT_PATH, 'wb') as f:
        f.write(frank)
    
    # Copy CUE sheet
    import shutil
    cue_src = FRANK_PATH.replace('.bin', '.cue')
    if os.path.exists(cue_src):
        with open(cue_src, 'r') as f:
            cue_content = f.read()
        cue_content = cue_content.replace('dq4_reverse_a.bin', 'dq4_reverse_a_fmv.bin')
        with open(CUE_PATH, 'w') as f:
            f.write(cue_content)
        print(f"CUE sheet written to {CUE_PATH}")
    
    print(f"\nDone! Test with:")
    print(f"  duckstation-qt-x64-ReleaseLTCG.exe -batch -earlyconsole '{CUE_PATH}'")

if __name__ == '__main__':
    main()
