$j = Get-Content telemetry_dma3_55m.json -Raw | ConvertFrom-Json
Write-Host "=== DMA3 55M Run State ==="
Write-Host "Status: $($j.Pass_Status)"
Write-Host "Instructions: $($j.Instructions_Executed)"
Write-Host "VBlanks: $($j.VBlank_Count)"
Write-Host "Crashed: $($j.Crashed)"
Write-Host "PC: $($j.Register_Dump.PC)"
Write-Host ""
Write-Host "=== Hardware State ==="
Write-Host "CD-ROM Reading: $($j.HW_State.cdrom_reading)"
Write-Host "CD-ROM Sectors Read: $($j.HW_State.cdrom_sectors_read)"
Write-Host "PAD Started: $($j.HW_State.pad_started)"
Write-Host ""
Write-Host "=== Non-Routine BIOS Calls ==="
foreach ($e in $j.BIOS_Call_Log) {
    $fn = '{0:X2}' -f [int]$e.fn
    $key = "$($e.table):0x$fn"
    if ($key -notin @('B:0x17','B:0x35')) {
        Write-Host ("  #{0} {1} ra={2} a0={3} a1={4} a2={5} a3={6}" -f $e.instr, $key, $e.ra, $e.a0, $e.a1, $e.a2, $e.a3)
    }
}
Write-Host ""
$tty = $j.TTY_Tail
$lines = $tty -split "`n"
# Check for GPU timeout messages
$gpuTimeouts = $lines | Where-Object { $_ -match 'GPU timeout' }
Write-Host "GPU timeout messages: $($gpuTimeouts.Count)"
$gpuTimeouts | Select-Object -First 5 | ForEach-Object { Write-Host "  $_" }
Write-Host ""
# Check for CDROM activity
$cdromLines = $lines | Where-Object { $_ -match 'CDROM|sector|Setloc|ReadN|INT1|CdInit|cdrom' }
Write-Host "CD-ROM log lines: $($cdromLines.Count)"
$cdromLines | Select-Object -First 10 | ForEach-Object { Write-Host "  $_" }
Write-Host ""
# Check for PAD init
$padLines = $lines | Where-Object { $_ -match 'PAD|pad|INJECT.*PAD' }
Write-Host "PAD log lines: $($padLines.Count)"
$padLines | Select-Object -First 10 | ForEach-Object { Write-Host "  $_" }
Write-Host ""
# Check for DMA activity
$dmaLines = $lines | Where-Object { $_ -match 'DMA|GPU DMA|linked' }
Write-Host "DMA log lines: $($dmaLines.Count)"
$dmaLines | Select-Object -First 10 | ForEach-Object { Write-Host "  $_" }
Write-Host ""
# Check for MEMDUMP at 50M
$dumpLines = $lines | Where-Object { $_ -match 'MEMDUMP|END MEMDUMP|TIMEOUT|EVT_FLAG|DISP_FLAG|CD_INIT|CD_READY|FRAME_CNT|VBC|DISP_AREA|HOOK_ENTRY|THREAD_CTX|ev\[' }
Write-Host "=== 50M MEMDUMP ==="
$dumpLines | ForEach-Object { Write-Host "  $_" }
Write-Host ""
# Last STATUS lines
$statusLines = $lines | Where-Object { $_ -match 'STATUS' } | Select-Object -Last 5
Write-Host "Last STATUS lines:"
$statusLines | ForEach-Object { Write-Host "  $_" }
