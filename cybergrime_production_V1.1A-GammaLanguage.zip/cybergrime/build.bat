@echo off
call "C:\Program Files (x86)\Microsoft Visual Studio\2022\BuildTools\VC\Auxiliary\Build\vcvars64.bat" >nul 2>&1
cl /std:c++17 /EHsc /Fe:psx_agent_runner.exe psx_autoplayer.cpp psx_emulator_core.cpp psx_test_station.cpp agent_harness.cpp /I. /D_CRT_SECURE_NO_WARNINGS /link /SUBSYSTEM:CONSOLE
