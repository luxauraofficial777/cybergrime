#!/usr/bin/env python3
"""
Thorough DQ4 disc scan: find ALL non-data sectors and MPEG/STR headers
across the ENTIRE disc, not just the first 5000 sectors.
"""
import os
import struct

DQ4_DISC = r"C:\LuxAura\VoidWalkers_Project\DQLOSTTRANSLATION\Dragon Quest IV - Michibikareshi Mono Tachi (Japan).bin"
DW7_DISC = r"C:\LuxAura\VoidWalkers_Project\DQLOSTTRANSLATION\DW7D1\DW7D1.bin"
SECTOR_SIZE = 2352
USER_SIZE = 2048

def to_bcd(val):
    return ((val // 10) << 4) | (val % 10)

def lba_to_bcd_msf(lba):
    m = lba // (75 * 60)
    s = (lba // 75) % 60
    f = lba % 75
    return (to_bcd(m), to_bcd(s), to_bcd(f))

def scan_full_disc(disc_path):
    """Scan every sector for mode, submode, and user data headers."""
    sz = os.path.getsize(disc_path)
    total = sz // SECTOR_SIZE
    
    # Collect all unique (mode, submode) combinations
    submode_map = {}  # (mode, submode) -> count
    non_data_sectors = []  # Sectors with any AV/Video/Audio/RealTime flags
    mpeg_hits = []  # Sectors with MPEG pack header in user data
    str_frame_hits = []  # Sectors with STR frame header
    
    # Also track submode transitions for range detection
    prev_key = None
    range_start = 0
    submode_ranges = []  # (start, end, count, mode, submode)
    
    with open(disc_path, 'rb') as f:
        for lba in range(total):
            f.seek(lba * SECTOR_SIZE)
            raw = f.read(SECTOR_SIZE)
            if len(raw) < 24:
                break
            
            mode = raw[15]
            submode = 0
            if mode == 2:
                submode = raw[18]
            
            key = (mode, submode)
            submode_map[key] = submode_map.get(key, 0) + 1
            
            # Track ranges
            if key != prev_key:
                if prev_key is not None:
                    submode_ranges.append((range_start, lba - 1, lba - range_start, prev_key[0], prev_key[1]))
                prev_key = key
                range_start = lba
            
            # Check for AV/Video/Audio/RealTime flags
            has_av = bool(submode & 0x80)
            has_video = bool(submode & 0x40)
            has_audio = bool(submode & 0x20)
            has_rt = bool(submode & 0x02)
            
            if has_av or has_video or has_audio or has_rt:
                non_data_sectors.append((lba, mode, submode))
            
            # Check user data for MPEG pack header (0x000001BA)
            user_data = raw[24:28]
            if user_data == b'\x00\x00\x01\xBA':
                mpeg_hits.append(lba)
            
            # Check for STR system header (0x000001BF)
            if user_data == b'\x00\x00\x01\xBF':
                str_frame_hits.append(lba)
            
            # Check for PSX STR frame header: typically starts with
            # 0x00 0x00 0x01 0xBA (MPEG pack) or
            # version byte 0x80 followed by frame data
            # Also check for RISC STR format: little-endian 0x80000160
            
            # Check for common video signatures in first 16 bytes
            if lba < total:
                ud16 = raw[24:40]
                # BS/VBS header (H.261) - starts with 0x00000010 or similar
                # MDEC stream: starts with specific patterns
                # Let's also check for 0x80000160 (STR version header)
                if ud16[:4] == b'\x80\x00\x01\x60':
                    str_frame_hits.append(lba)
        
        if prev_key is not None:
            submode_ranges.append((range_start, total - 1, total - range_start, prev_key[0], prev_key[1]))
    
    return submode_map, non_data_sectors, mpeg_hits, str_frame_hits, submode_ranges, total

def main():
    for name, path in [("DQ4", DQ4_DISC), ("DW7", DW7_DISC)]:
        print(f"\n{'='*70}")
        print(f"  {name} Full Disc Scan")
        print(f"{'='*70}")
        
        sm_map, non_data, mpeg_hits, str_hits, sm_ranges, total = scan_full_disc(path)
        
        print(f"\n  Total sectors: {total:,}")
        
        print(f"\n  All (mode, submode) combinations:")
        for (mode, sm), count in sorted(sm_map.items()):
            flags = []
            if sm & 0x01: flags.append("EOF")
            if sm & 0x02: flags.append("RT")
            if sm & 0x04: flags.append("Form2")
            if sm & 0x08: flags.append("Trigger")
            if sm & 0x10: flags.append("Data")
            if sm & 0x20: flags.append("Audio")
            if sm & 0x40: flags.append("Video")
            if sm & 0x80: flags.append("AV")
            flag_str = "|".join(flags) if flags else "none"
            print(f"    Mode={mode} Submode=0x{sm:02X} ({flag_str}): {count:,} sectors")
        
        print(f"\n  Non-data sectors (AV/Video/Audio/RT flags): {len(non_data)}")
        if non_data:
            # Group into ranges
            ranges = []
            start = non_data[0][0]
            prev = start
            for i in range(1, len(non_data)):
                lba = non_data[i][0]
                if lba != prev + 1:
                    ranges.append((start, prev, non_data[i-1]))
                    start = lba
                prev = lba
            ranges.append((start, prev, non_data[-1]))
            
            print(f"  Grouped into {len(ranges)} ranges:")
            for s, e, sample in ranges[:30]:
                count = e - s + 1
                bcd_m, bcd_s, bcd_f = lba_to_bcd_msf(s)
                bcd_str = f"{bcd_m:02X}:{bcd_s:02X}:{bcd_f:02X}"
                flags = []
                sm = sample[2]
                if sm & 0x01: flags.append("EOF")
                if sm & 0x02: flags.append("RT")
                if sm & 0x04: flags.append("Form2")
                if sm & 0x08: flags.append("Trigger")
                if sm & 0x10: flags.append("Data")
                if sm & 0x20: flags.append("Audio")
                if sm & 0x40: flags.append("Video")
                if sm & 0x80: flags.append("AV")
                print(f"    LBA {s:7d}-{e:7d}  {count:5d} sectors  Submode=0x{sm:02X} ({'|'.join(flags)})  BCD {bcd_str}")
            
            if len(ranges) > 30:
                print(f"    ... and {len(ranges) - 30} more ranges")
        
        print(f"\n  MPEG pack headers (0x000001BA): {len(mpeg_hits)}")
        if mpeg_hits:
            for h in mpeg_hits[:20]:
                bcd_m, bcd_s, bcd_f = lba_to_bcd_msf(h)
                print(f"    LBA {h:7d}  BCD {bcd_m:02X}:{bcd_s:02X}:{bcd_f:02X}")
        
        print(f"\n  STR frame headers (0x80000160): {len(str_hits)}")
        if str_hits:
            for h in str_hits[:20]:
                bcd_m, bcd_s, bcd_f = lba_to_bcd_msf(h)
                print(f"    LBA {h:7d}  BCD {bcd_m:02X}:{bcd_s:02X}:{bcd_f:02X}")
        
        # Submode ranges (transitions)
        print(f"\n  Submode transition ranges (first 50):")
        for s, e, count, mode, sm in sm_ranges[:50]:
            if sm != 0x08:  # Only show non-default submodes
                flags = []
                if sm & 0x01: flags.append("EOF")
                if sm & 0x02: flags.append("RT")
                if sm & 0x04: flags.append("Form2")
                if sm & 0x08: flags.append("Trigger")
                if sm & 0x10: flags.append("Data")
                if sm & 0x20: flags.append("Audio")
                if sm & 0x40: flags.append("Video")
                if sm & 0x80: flags.append("AV")
                bcd_m, bcd_s, bcd_f = lba_to_bcd_msf(s)
                print(f"    LBA {s:7d}-{e:7d}  {count:5d} sectors  Mode={mode} Submode=0x{sm:02X} ({'|'.join(flags)})  BCD {bcd_m:02X}:{bcd_s:02X}:{bcd_f:02X}")
        
        # Also show ALL transitions for context
        print(f"\n  ALL submode transitions (showing first 30):")
        for s, e, count, mode, sm in sm_ranges[:30]:
            bcd_m, bcd_s, bcd_f = lba_to_bcd_msf(s)
            flags = []
            if sm & 0x01: flags.append("EOF")
            if sm & 0x02: flags.append("RT")
            if sm & 0x04: flags.append("Form2")
            if sm & 0x08: flags.append("Trigger")
            if sm & 0x10: flags.append("Data")
            if sm & 0x20: flags.append("Audio")
            if sm & 0x40: flags.append("Video")
            if sm & 0x80: flags.append("AV")
            flag_str = "|".join(flags) if flags else "none"
            print(f"    LBA {s:7d}-{e:7d}  {count:5d} sectors  Mode={mode} Sub=0x{sm:02X} ({flag_str})")
    
    # Now specifically look at what's around LBA 146621 on DW7
    print(f"\n{'='*70}")
    print(f"  DW7 disc around LBA 146621 (FMV seek target)")
    print(f"{'='*70}")
    with open(DW7_DISC, 'rb') as f:
        for lba in range(146615, 146630):
            f.seek(lba * SECTOR_SIZE)
            raw = f.read(SECTOR_SIZE)
            mode = raw[15]
            sm = raw[18] if mode == 2 else 0
            ud = raw[24:40]
            flags = []
            if sm & 0x01: flags.append("EOF")
            if sm & 0x02: flags.append("RT")
            if sm & 0x04: flags.append("Form2")
            if sm & 0x08: flags.append("Trigger")
            if sm & 0x10: flags.append("Data")
            if sm & 0x20: flags.append("Audio")
            if sm & 0x40: flags.append("Video")
            if sm & 0x80: flags.append("AV")
            flag_str = "|".join(flags) if flags else "none"
            print(f"  LBA {lba:7d}  Mode={mode} Sub=0x{sm:02X} ({flag_str})  Data: {ud.hex()}")
    
    # Check where DW7's STR data actually starts (first non-0x08 submode after HBD start)
    print(f"\n  DW7: First non-0x08 submode sectors after LBA 354:")
    with open(DW7_DISC, 'rb') as f:
        found = 0
        for lba in range(354, 302537):
            f.seek(lba * SECTOR_SIZE + 15)
            mode = f.read(1)[0]
            if mode == 2:
                f.seek(lba * SECTOR_SIZE + 18)
                sm = f.read(1)[0]
            else:
                sm = 0
            if sm != 0x08:
                bcd_m, bcd_s, bcd_f = lba_to_bcd_msf(lba)
                flags = []
                if sm & 0x01: flags.append("EOF")
                if sm & 0x02: flags.append("RT")
                if sm & 0x04: flags.append("Form2")
                if sm & 0x08: flags.append("Trigger")
                if sm & 0x10: flags.append("Data")
                if sm & 0x20: flags.append("Audio")
                if sm & 0x40: flags.append("Video")
                if sm & 0x80: flags.append("AV")
                print(f"    LBA {lba:7d}  Mode={mode} Sub=0x{sm:02X} ({'|'.join(flags)})  BCD {bcd_m:02X}:{bcd_s:02X}:{bcd_f:02X}")
                found += 1
                if found >= 50:
                    print(f"    ... (showing first 50 non-0x08 sectors)")
                    break

if __name__ == '__main__':
    main()
