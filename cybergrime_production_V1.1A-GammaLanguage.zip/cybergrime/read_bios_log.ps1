$j = Get-Content telemetry_bios_10m.json -Raw | ConvertFrom-Json
Write-Host "=== BIOS 10M Run State ==="
Write-Host "Status: $($j.Pass_Status)"
Write-Host "Instructions: $($j.Instructions_Executed)"
Write-Host "VBlanks: $($j.VBlank_Count)"
Write-Host "Crashed: $($j.Crashed)"
Write-Host ""
Write-Host "=== BIOS Call Log ($($j.BIOS_Call_Log.Count) entries) ==="
foreach ($e in $j.BIOS_Call_Log) {
    $tbl = $e.table
    $fn = '{0:X2}' -f [int]$e.fn
    Write-Host ("  #{0} {1}:0x{2} ra={3} a0={4} a1={5} a2={6} a3={7}" -f $e.instr, $tbl, $fn, $e.ra, $e.a0, $e.a1, $e.a2, $e.a3)
}
