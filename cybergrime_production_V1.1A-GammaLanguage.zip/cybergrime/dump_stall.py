import struct

disc = 'dq4_frankenstein_v38a.bin'
SECTOR_SIZE = 0x930
SECTOR_DATA = 0x800
SECTOR_HEADER = 24
EXE_LBA = 24

def ram_to_disc(ram_addr):
    exe_off = (ram_addr - 0x80017F00) + 0x800
    sector_idx = exe_off // SECTOR_DATA
    offset_in_sector = exe_off % SECTOR_DATA
    return (EXE_LBA + sector_idx) * SECTOR_SIZE + SECTOR_HEADER + offset_in_sector

with open(disc, 'rb') as f:
    # Dump code around stall PC 0x80048004
    for label, ram_addr, count in [
        ("Stall PC area", 0x80047FF0, 32),
        ("BSS clear entry", 0x8008E280, 8),
        ("Thread entry", 0x800D9E80, 8),
        ("Event flag poll (suspected)", 0x80098780, 16),
    ]:
        disc_off = ram_to_disc(ram_addr)
        f.seek(disc_off)
        data = f.read(count * 4)
        print(f"\n{label} (RAM 0x{ram_addr:08X}, disc 0x{disc_off:06X}):")
        for i in range(count):
            word = struct.unpack_from('<I', data, i*4)[0]
            print(f"  0x{ram_addr+i*4:08X}: 0x{word:08X}")
