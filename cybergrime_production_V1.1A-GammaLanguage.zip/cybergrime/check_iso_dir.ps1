# Read the ISO 9660 directory from the Frankenstein disc
# PVD is at LBA 16, root directory info is in the PVD
$binPath = 'c:\LuxAura\VoidWalkers_Project\DQLOSTTRANSLATION\cybergrime\dq4_reverse_v97_fmv.bin'
$fs = [System.IO.File]::OpenRead($binPath)

function ReadSectorUser($fs, $lba) {
    $fs.Seek($lba * 2352 + 24, 'Begin') | Out-Null
    $buf = New-Object byte[] 2048
    $fs.Read($buf, 0, 2048) | Out-Null
    return $buf
}

# Read PVD at LBA 16
$pvd = ReadSectorUser $fs 16
Write-Host "=== PVD at LBA 16 ==="
$volId = [System.Text.Encoding]::ASCII.GetString($pvd, 40, 32).TrimEnd()
Write-Host "Volume ID: $volId"
$volSpaceSize = [BitConverter]::ToUInt32($pvd, 80)
Write-Host "Volume Space Size: $volSpaceSize sectors"

# Root directory record is at offset 156 in PVD
$rootLen = $pvd[156]
Write-Host "Root dir record length: $rootLen"
$rootLBA = [BitConverter]::ToUInt32($pvd, 158)
$rootSize = [BitConverter]::ToUInt32($pvd, 166)
Write-Host "Root dir LBA: $rootLBA, Size: $rootSize"

# Read root directory
$rootDir = ReadSectorUser $fs $rootLBA
Write-Host ""
Write-Host "=== Root Directory Entries ==="
$offset = 0
while ($offset -lt $rootDir.Length - 1) {
    $recLen = $rootDir[$offset]
    if ($recLen -eq 0) { break }
    $extLBA = [BitConverter]::ToUInt32($rootDir, $offset + 2)
    $extSize = [BitConverter]::ToUInt32($rootDir, $offset + 10)
    $flags = $rootDir[$offset + 25]
    $nameLen = $rootDir[$offset + 32]
    $name = [System.Text.Encoding]::ASCII.GetString($rootDir, $offset + 33, $nameLen)
    $type = if ($flags -band 0x02) { 'DIR' } else { 'FILE' }
    Write-Host ("  {0} '{1}' LBA={2} Size={3} Flags=0x{4:X2}" -f $type, $name, $extLBA, $extSize, $flags)
    $offset += $recLen
}

# Also check: is there a file at LBA 146621?
# LBA 146621 in MSF: 146621 + 150 = 146771 frames
# 146771 / 75 = 1956.95 seconds = 32:36.95
# BCD MSF: 32:34:71 → LBA = (32*60 + 34)*75 + 71 - 150 = 146621
Write-Host ""
Write-Host "=== Checking LBA 146621 (DW7 FMV, MSF 32:34:71) ==="
Write-Host "This is in the HBD data range (LBA 354+)"
$hbdSectors = [Math]::Floor(618563584 / 2048)
Write-Host "HBD size: 618563584 bytes = $hbdSectors sectors"
Write-Host "HBD range: LBA 354 to $($354 + $hbdSectors - 1)"
Write-Host "LBA 146621 is within HBD range: $(146621 -ge 354 -and 146621 -lt (354 + $hbdSectors))"

# Check what's at LBA 146621 on the Frankenstein disc
$sector146621 = ReadSectorUser $fs 146621
Write-Host ""
Write-Host "=== Sector at LBA 146621 (first 32 bytes) ==="
$hex = ''
for ($i = 0; $i -lt 32; $i++) { $hex += '{0:X2} ' -f $sector146621[$i] }
Write-Host "  $hex"

# Also check LBA 105690 (DQ4 FMV, MSF 23:31:15)
$sector105690 = ReadSectorUser $fs 105690
Write-Host ""
Write-Host "=== Sector at LBA 105690 (DQ4 FMV, MSF 23:31:15) ==="
$hex = ''
for ($i = 0; $i -lt 32; $i++) { $hex += '{0:X2} ' -f $sector105690[$i] }
Write-Host "  $hex"

# Check if LBA 105690 is within HBD range
Write-Host "LBA 105690 is within HBD range: $(105690 -ge 354 -and 105690 -lt (354 + $hbdSectors))"

$fs.Close()
