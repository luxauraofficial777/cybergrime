# Orchestration Engine Blueprint
## DQ4 Frankenstein ROM — Dynamic MIPS Control Architecture

**Date:** July 12, 2026  
**Status:** Implementation in progress  
**Scope:** Two integrated refactors: (1) Vault-Cracker instruction orchestration, (2) Universal Vault-Architect dual-binary patching

---

## 0. Initialization Directive — Project Frankenstein (Vault-Cracker Phase)

**Operational Mandate:**
- **Primary Directive:** Bypass all native ROM-body bottlenecks, specifically the Huffman Tree validation and CD-ROM handshake stalls.
- **Architecture:** Treat the entire ROM and the DW7 EXE as a unified, fluid 32-bit hex address space.
- **Environment:** Operating under the Mandate of Sound Logic. Prioritize architectural stability and rapid MIPS instruction synthesis over legacy extraction methods.

**Core Technical Capabilities:**
- **Direct Memory Sovereignty:** Hook the Execute_MIPS pipeline at the instruction fetch stage. Monitor CPU register state ($a0-$a3) in real-time to identify the exact offset of hanging routines.
- **Universal Patching Engine:** Execute simultaneous hex-write operations across both binaries. Perform Delta-Patching by calculating relative offsets for DW7 instructions mapped to the DQ4 substrate.
- **Injection Protocols:** Treat `thread_code_blob.bin` as a volatile, live-mapped overlay at 0x800D9E80. If any validation routine fails, execute an immediate Vector Shift to bypass the trap and force jump-to-injected-code.

**Execution & Oversight:**
- **Telemetry:** Real-time stack trace and registry dump dashboard. Expose the logic-hang offset immediately upon detection.
- **Bulk-Optimization:** Bulk-search-and-replace across MIPS opcode signatures to rewrite logic flow instantly, bypassing the need for re-patching the physical file body.
- **Rollback Buffer:** State-journal of every hex modification for safe-fail recovery if the engine hits an illegal opcode.

**Goal State:** Fully initialized, stable, and ready for deployment by Tuesday deadline. This is an active MIPS re-engineering operation.

---

## 1. Problem Statement

The current emulator (`psx_agent_runner`) operates as a static execution pipeline:
- No instruction-level hooks — can't intercept or override execution at arbitrary PCs
- Crashes on illegal opcodes / unmapped addresses with no recovery
- No register monitoring at specific execution points (e.g., Huffman decompression)
- No audit trail for RAM modifications — can't roll back experimental patches
- No unified DQ4↔DW7 address mapping — can't cross-reference assets
- Thread injection is one-shot and blind — no verification loop

The Frankenstein ROM (DW7 EXE on DQ4 disc) has mismatched code regions that cause
crashes at addresses like 0x8012F424 (HBD data zone executing garbage). We need
real-time control to detect, bypass, and correct these issues.

---

## 2. Architecture Overview

```
┌─────────────────────────────────────────────────────────┐
│                   psx_agent_runner.exe                   │
│                                                          │
│  ┌──────────────┐   ┌──────────────────────────────────┐│
│  │  MIPS_CPU::  │──▶│    Orchestration Engine           ││
│  │   step()     │   │                                   ││
│  │              │   │  ┌─────────┐  ┌───────────────┐  ││
│  │  1. Fetch    │   │  │ Hook    │  │ PC Auto-      │  ││
│  │  2. Pre-hook │──▶│  │ Table   │  │ Corrector     │  ││
│  │  3. Execute  │   │  │ (32 max)│  │               │  ││
│  │  4. Post-hook│   │  └─────────┘  └───────────────┘  ││
│  │  5. Crash?   │──▶│  ┌─────────┐  ┌───────────────┐  ││
│  │  6. Telemetry│   │  │ Reg     │  │ Audit Log     │  ││
│  │              │   │  │ Watches │  │ + Rollback    │  ││
│  │              │   │  └─────────┘  └───────────────┘  ││
│  │              │   │  ┌─────────────────────────────┐  ││
│  │              │   │  │ Dual-Binary Address Map     │  ││
│  │              │   │  │ DQ4 ROM ↔ DW7 EXE           │  ││
│  │              │   │  │ Delta-Patch Calculator      │  ││
│  │              │   │  └─────────────────────────────┘  ││
│  └──────────────┘   └──────────────────────────────────┘│
│                                                          │
│  ┌──────────────────────────────────────────────────────┐│
│  │  Live Telemetry Dashboard (orchestration_telem.log)  ││
│  │  Periodic reg dumps, stack traces, hook hit logs     ││
│  └──────────────────────────────────────────────────────┘│
└─────────────────────────────────────────────────────────┘
```

---

## 3. Component Specifications

### 3.1 Hook Table (Instruction-Level Override)

**Purpose:** Intercept execution at specific PCs before/after instruction fetch.

**Data Structure:**
```cpp
struct HookEntry {
    uint32_t pc;              // Target PC (0 = unused slot)
    uint32_t flags;           // HF_ENABLED | HF_PRE_EXEC | HF_POST_EXEC | ...
    HookAction action;        // NONE, SKIP, REDIRECT, SET_REG, OVERRIDE_INSTR
    uint32_t redirect_pc;     // For REDIRECT
    uint32_t set_reg_num;     // For SET_REG
    uint32_t set_reg_val;     // For SET_REG
    uint32_t override_instr;  // For OVERRIDE_INSTR
    char label[32];           // Human-readable name
    int hit_count;
    int max_hits;             // 0 = unlimited
    void (*handler)(MIPS_CPU&, PSX_Memory&, HookEntry&);
};
```

**Capacity:** 64 hooks (fixed array, linear scan — fast enough for <64 entries)  
**Hook Actions:**
- `HOOK_NONE` — Log only, continue execution
- `HOOK_SKIP` — NOP this instruction (skip to next PC)
- `HOOK_REDIRECT` — Set PC to `redirect_pc` before/after execution
- `HOOK_SET_REG` — Set register `set_reg_num` to `set_reg_val`
- `HOOK_OVERRIDE_INSTR` — Replace fetched instruction word with `override_instr`
- `HOOK_CALL_HANDLER` — Call C++ callback for custom logic

**Integration Point:** `MIPS_CPU::step()`, after `cur_pc = pc;` and before instruction fetch:
```cpp
// PRE-EXEC hooks
for (int i = 0; i < g_orch.max_hooks; i++) {
    HookEntry& h = g_orch.hooks[i];
    if (!(h.flags & HF_ENABLED) || h.pc != cur_pc) continue;
    if (!(h.flags & HF_PRE_EXEC)) continue;
    // Execute hook action...
}
```

**Post-exec hooks** fire after instruction executes but before `return true`.

### 3.2 PC Auto-Corrector

**Purpose:** When the CPU hits an illegal opcode or unmapped address, auto-correct
to the nearest stable execution node instead of crashing.

**Strategy:**
1. On illegal opcode detection (unknown opcode in `step()`):
   - Check if `cur_pc` is in a known "danger zone" (HBD data region 0x800D0000-0x800F0000)
   - If so, search backward through trace ring for the last `jal`/`jalr` that called into this zone
   - Set PC to the return address (`$ra` of that call) + 4 (skip the call)
   - Log the correction to audit log
2. On unmapped PC (fails `pc_valid` check):
   - If PC > 0x80000000 and < 0x80200000, it's valid RAM — allow anyway
   - If PC is in 0x84000000+ range (like 0x840F8004), it's a corrupted jump target
   - Mask to valid range: `pc = pc & 0x1FFFFFF | 0x80000000`
   - If still invalid, use trace ring to find last valid PC and resume from there

**Config:**
```cpp
bool auto_correct_enabled = true;
uint32_t danger_zone_start = 0x800D0000;
uint32_t danger_zone_end   = 0x800F0000;
int max_corrections = 100;  // Stop after 100 corrections (infinite loop guard)
```

### 3.3 Register Watches

**Purpose:** Sample MIPS register state at specific PCs for debugging.

**Data Structure:**
```cpp
struct RegWatch {
    uint32_t pc;              // PC to sample at (0 = unused)
    uint32_t watch_mask;      // Bitmask: which regs to log (bit 4 = $a0, etc.)
    int max_samples;          // 0 = unlimited
    int sample_count;
    char label[32];
};
```

**Capacity:** 32 watches  
**Log Format:**
```
[REGWATCH] "Huffman entry" PC=0x80012340 instr #12345
  $a0=0x800D0000 $a1=0x00002000 $a2=0x00000000 $a3=0x00000001
  $v0=0x00000001 $v1=0x00000000 $ra=0x80012380 $sp=0x801FFF00
```

**Primary Use Cases:**
- Monitor $a0-$a3 at Huffman decompression entry points
- Monitor $ra at thread switch (ChangeTh) to trace call stack
- Monitor $v0 at CD-ROM BIOS calls to track return values

### 3.4 Audit Log with Rollback

**Purpose:** Every RAM modification by the orchestrator is logged with before/after
state, enabling instant rollback.

**Data Structure:**
```cpp
struct AuditEntry {
    uint64_t instr_count;     // When it happened
    uint32_t addr;            // RAM address modified
    uint32_t old_value;       // Original value (for rollback)
    uint32_t new_value;       // Written value
    int size;                 // 1, 2, or 4 bytes
    char reason[48];          // Why it was modified
    bool rolled_back;
};

static const int MAX_AUDIT = 4096;
AuditEntry audit_log[MAX_AUDIT];
int audit_count;
```

**API:**
- `audit_write(addr, old_val, new_val, size, reason)` — Log a modification
- `audit_rollback_last()` — Undo the most recent modification
- `audit_rollback_to(int index)` — Undo all modifications after `index`
- `audit_dump(const char* path)` — Write full audit log to file

**Integration:** The orchestrator calls `audit_write` before any `memcpy` or
direct RAM write. The existing thread injection code will also be wrapped.

### 3.5 Dual-Binary Address Map (DQ4 ↔ DW7)

**Purpose:** Map addresses between DQ4 ROM and DW7 EXE for cross-referencing.

**Data Structure:**
```cpp
struct AddressMapEntry {
    uint32_t dq4_addr;        // Address in DQ4 ROM space
    uint32_t dw7_addr;        // Corresponding address in DW7 EXE
    int size;                 // Size of mapped region
    char description[48];     // What's at this address
    bool is_code;             // Code vs data
};

static const int MAX_MAP_ENTRIES = 256;
AddressMapEntry addr_map[MAX_MAP_ENTRIES];
int map_count;
```

**Delta Calculation:**
```cpp
int32_t compute_delta(uint32_t dq4_addr, uint32_t dw7_addr) {
    return (int32_t)(dw7_addr - dq4_addr);
}

uint32_t translate_addr(uint32_t src_addr, bool from_dq4) {
    // Binary search through addr_map for matching entry
    // Return translated address, or 0 if not found
}
```

**Known Mappings (from prior analysis):**
| DQ4 Address | DW7 Address | Description |
|-------------|-------------|-------------|
| 0x80017F00  | 0x80017F00  | EXE load address (same) |
| 0x800BCF00  | 0x800BC700  | EXE end (differs by 0x800) |
| 0x800D9E80  | 0x800D9E80  | Thread entry (same, zero-filled) |
| 0x8012F3D0  | 0x8012F3D0  | HBD pointer table target |
| 0x1F801800  | 0x1F801800  | CD-ROM registers (hardware, same) |

**Delta-Patch Workflow:**
1. Agent identifies a DW7 instruction at address X
2. Look up X in address map → find DQ4 equivalent Y
3. If instruction has an absolute address operand, translate it too
4. Write translated instruction to DQ4 ROM at Y
5. Log to audit trail

### 3.6 Live Telemetry Dashboard

**Purpose:** Real-time visibility into CPU state for debugging.

**Output:** `orchestration_telem.log` (file, flushed every 1000 instructions)

**Modes:**
- **Periodic:** Every N instructions, dump PC + key registers
- **On-Hook:** When any hook fires, dump full register file
- **On-Crash:** Full trace ring dump + register file + stack pointer chain
- **On-CDROM:** When CD-ROM registers are accessed, log state

**Config:**
```cpp
bool telemetry_enabled = true;
int telemetry_interval = 100000;  // Dump every 100K instructions
FILE* telemetry_file;
```

**Format:**
```
[TELEM] instr #1234567 PC=0x80091EDC
  $a0=0xF2000002 $a1=0x00000002 $a2=0x00001000 $a3=0x8002FE54
  $v0=0x00000001 $v1=0x00000000 $ra=0x80096A1C $sp=0x801FFF00 $gp=0x800BC668
  SR=0x40000501 EPC=0x80091EDC Cause=0x00000100
  CD-ROM: status=0x02 int_flag=0x02 int_enable=0x1F sectors_read=0
```

---

## 4. Implementation Plan

### Phase 1: Core Engine (orchestration_engine.h)
**File:** `cybergrime/orchestration_engine.h` (new, header-only)

- Define `HookEntry`, `RegWatch`, `AuditEntry`, `AddressMapEntry` structs
- Define `OrchestrationEngine` class with all state
- Implement hook table add/remove/lookup
- Implement register watch add/sample
- Implement audit log write/rollback/dump
- Implement address map add/lookup/delta-calc
- Implement telemetry init/write/flush
- Implement PC auto-corrector logic
- Global `g_orch` instance

### Phase 2: Wire into step()
**File:** `cybergrime/psx_emulator_core.cpp` (modify)

- `#include "orchestration_engine.h"` at top
- In `MIPS_CPU::step()`:
  - After `cur_pc = pc;` → run pre-exec hooks
  - After instruction execution → run post-exec hooks
  - In crash paths → call `g_orch.auto_correct()` before giving up
  - At telemetry interval → call `g_orch.dump_telemetry()`
- In `handle_exception()`:
  - After event delivery → log to telemetry
- In `ChangeTh` handler:
  - Wrap thread injection with audit log
  - Add verification hook for injected code

### Phase 3: Thread Injection Verification
**File:** `cybergrime/psx_emulator_core.cpp` (modify)

- After injecting `thread_code_blob.bin`, add a post-exec hook at 0x800D9E80
- Hook checks first 4 bytes of injected code for valid MIPS prologue
- If invalid (not `addiu $sp` or `sw $ra` pattern):
  - Log warning to telemetry
  - Set a "bubblegum stub" — write a minimal MIPS stub that:
    1. Sets CD-ready flag at 0x800B91CC = 1
    2. Calls `ReturnFromException` (B:0x17)
    3. Returns to caller via `jr $ra`
  - This stub lets the game's main thread continue even without real thread code

### Phase 4: DW7 Reference Integration
**File:** `cybergrime/orchestration_engine.h` (extend)

- Load DW7 EXE into a separate buffer at startup
- Implement `bulk_search_replace(opcode_pattern, replacement, mask, start, end)`
- Implement `verify_against_dw7(dq4_addr, size)` — compare DQ4 RAM against DW7 EXE
- Pre-populate address map with known mappings from analysis scripts

### Phase 5: CLI Interface
**File:** `cybergrime/psx_agent_runner.cpp` (modify)

- New CLI flags:
  - `--orchestrate` — Enable orchestration engine
  - `--hook <pc>,<action>,<val>,<label>` — Add a hook at runtime
  - `--watch <pc>,<regmask>,<label>` — Add a register watch
  - `--auto-correct` — Enable PC auto-correction
  - `--telemetry <interval>` — Set telemetry dump interval
  - `--audit-log <path>` — Specify audit log output path
  - `--delta-map <json>` — Load DQ4↔DW7 address map from JSON

---

## 5. File Manifest

| File | Action | Description |
|------|--------|-------------|
| `orchestration_engine.h` | **NEW** | Header-only engine: hooks, watches, audit, address map, telemetry |
| `psx_emulator_core.cpp` | **MODIFY** | Wire hooks into `step()`, auto-correct in crash paths, audit in injection |
| `psx_agent_runner.cpp` | **MODIFY** | Add CLI flags, initialize engine, load address maps |
| `psx_test_station.h` | **MODIFY** | Add `extern OrchestrationEngine g_orch;` forward decl |

**Estimated lines of new code:** ~400 (header) + ~80 (modifications)  
**No new .cpp files** — header-only keeps build simple (single `cl` invocation)

---

## 6. Risk Assessment

| Risk | Mitigation |
|------|------------|
| Hook table scan slows step() | 64 entries max, linear scan = ~200ns. Negligible vs MIPS exec time. |
| Auto-correct masks real bugs | Max 100 corrections, logged to audit. Can be disabled. |
| Thread blob is garbage data | Phase 3 bubblegum stub provides fallback. |
| DW7 EXE loading uses too much RAM | DW7 EXE is ~660KB. Trivial. |
| Telemetry file grows unbounded | Capped at 50MB, rotated. |

---

## 7. Testing Plan

1. **Build** with orchestration enabled (`--orchestrate` flag)
2. **Run baseline DW7** with telemetry at 100K interval — verify no perf impact
3. **Add hook** at 0x8002FE54 (CD-ROM event handler) — verify it fires
4. **Add watch** at Huffman decompression entry — verify $a0-$a3 logged
5. **Enable auto-correct** — verify crash at 0x8012F424 is corrected, execution continues
6. **Test audit rollback** — inject thread blob, rollback, verify RAM restored
7. **Test delta-patch** — map a DW7 instruction to DQ4 space, verify translation
8. **Full 50M instruction run** with all features enabled

---

## 8. Success Criteria

- [ ] Hook table intercepts execution at arbitrary PCs
- [ ] PC auto-corrector prevents crashes on illegal opcodes in HBD zone
- [ ] Register watches log $a0-$a3 at Huffman entry points
- [ ] Audit log records all orchestrator RAM writes with rollback capability
- [ ] Telemetry dashboard shows real-time CPU state
- [ ] Thread injection has verification + bubblegum stub fallback
- [ ] DW7↔DQ4 address map translates at least 10 known mappings
- [ ] 50M instruction run completes without hard crash (auto-corrected or stable)

---

## 9. Refactoring Completion Status (Jul 2026)

### Completed Integrations

| Component | Status | Source | Details |
|-----------|--------|--------|---------|
| `psx_reference_integrations.h` | **DONE** | PSn00bSDK + PSoXide + PSn00b-Debugger | Header-only integration bridge with 6 namespaces |
| BIOS syscall name lookup | **DONE** | PSn00bSDK `stubs.json` | Replaced 720-line switch/case with `bios_syscalls::A_name/B_name/C_name()` |
| CD-ROM command mapping | **DONE** | PSoXide `cdrom.rs` | Fixed 6 wrong command numbers, added 9 missing commands |
| CD-ROM sector timing | **DONE** | PSoXide timing constants | Replaced hardcoded values with `cdrom_constants::CD_READ_TIME` (33868 cycles) |
| Post-exec hooks | **DONE** | Orchestration engine | Wired `g_orch.run_hooks(*this, *g_mem, false)` at end of `step()` |
| Trace ring disassembly | **DONE** | PSn00b-Debugger | Replaced inline `snprintf` desc with `mips_disasm::disasm_str()` |
| Pre-exec hooks | **DONE** (prior) | Orchestration engine | Already wired at top of `step()` |
| PC auto-corrector | **DONE** (prior) | Orchestration engine | Active for NULL jumps and unmapped branches |
| Register watches | **DONE** (prior) | Orchestration engine | `g_orch.sample_registers()` called per-step |
| Audit log + rollback | **DONE** (prior) | Orchestration engine | Full RAM snapshot/restore implemented |
| Dual-binary address map | **DONE** (prior) | Orchestration engine | DW7↔DQ4 translation table implemented |
| Telemetry | **DONE** (prior) | Orchestration engine | CPU state sampling at configurable intervals |

### CD-ROM Command Mapping Corrections

| Command | Old (Wrong) | Corrected (PSoXide) |
|---------|-------------|---------------------|
| MotorOn | missing | 0x07 |
| Mute | 0x0B=GetLocP | 0x0B=Mute |
| Demute | 0x0C=GetTN | 0x0C=Demute |
| Setfilter | 0x0D=GetTD | 0x0D=Setfilter |
| GetlocL | missing | 0x10 |
| GetlocP | 0x0B (wrong) | 0x11 |
| GetTN | 0x0C (wrong) | 0x13 |
| GetTD | 0x0D (wrong) | 0x14 |
| GetID | 0x11 (wrong) | 0x1A |
| GetQ | 0x13 (wrong) | 0x1D |
| Reset | 0x0A=Init | 0x0A=Reset |
| Init | 0x1C=Reset | 0x1C=Init |
| SeekL | missing | 0x15 |
| SeekP | missing | 0x16 |
| Setsession | missing | 0x12 |

### Files Modified

- `psx_emulator_core.cpp` — BIOS lookup, CD-ROM commands, timing, hooks, trace ring
- `psx_test_station.h` — New CD-ROM state fields (`cdrom_muted`, `cdrom_filter_file`, `cdrom_filter_channel`), timing constant
- `psx_reference_integrations.h` — Created (prior session) with all reference integration namespaces
- `INTEGRATION_MANIFEST.md` — Created (prior session) documenting cross-references
