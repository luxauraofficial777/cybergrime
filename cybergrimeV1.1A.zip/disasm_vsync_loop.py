#!/usr/bin/env python3
"""Disassemble the VSync wait loop and surrounding code to understand what the game does after HBD loading."""
import os
from capstone import Cs, CS_ARCH_MIPS, CS_MODE_MIPS32, CS_MODE_LITTLE_ENDIAN

def read_exe_from_disc(disc_path, exe_lba=24, sector_size=2352, user_offset=24, user_size=2048):
    with open(disc_path, 'rb') as f:
        exe_sectors = 340
        f.seek(exe_lba * sector_size)
        raw = f.read(exe_sectors * sector_size)
    exe_data = bytearray()
    for i in range(exe_sectors):
        sector = raw[i * sector_size:(i + 1) * sector_size]
        if len(sector) < user_offset + user_size:
            break
        exe_data += sector[user_offset:user_offset + user_size]
    return bytes(exe_data)

def disasm_range(exe_data, load_addr, start_ram, end_ram):
    code_offset = 0x800
    file_start = start_ram - load_addr + code_offset
    file_end = end_ram - load_addr + code_offset
    if file_start < 0 or file_end > len(exe_data):
        return "  (outside EXE)\n"
    code = exe_data[file_start:file_end]
    md = Cs(CS_ARCH_MIPS, CS_MODE_MIPS32 | CS_MODE_LITTLE_ENDIAN)
    lines = []
    for insn in md.disasm(code, start_ram):
        lines.append(f"  0x{insn.address:08X}: {insn.mnemonic:8s} {insn.op_str}")
    return '\n'.join(lines) + '\n'

base = r"C:\LuxAura\VoidWalkers_Project\DQLOSTTRANSLATION"
disc = os.path.join(base, "dq4_frankenstein_v41.bin")
load_addr = 0x80017F00
exe = read_exe_from_disc(disc)

# The CyberGrime STATUS logs show PC cycling around 0x800966F4-0x800967E4
# This is the VSync wait loop. Let's disassemble a wide range around it.
print("=== VSync wait loop area (0x800966C0 - 0x80096840) ===")
print(disasm_range(exe, load_addr, 0x800966C0, 0x80096840))

# Also check what function calls this loop
print("\n=== Function entry before VSync loop (0x80096600 - 0x800966C0) ===")
print(disasm_range(exe, load_addr, 0x80096600, 0x800966C0))

# Check GPU register access - look for 0x1F801810 references
# In MIPS, this would be lui $xx, 0x1F80 + addiu/lw/sw 0x1810($xx)
print("\n=== Looking for GPU register accesses (0x1F801810) ===")
md = Cs(CS_ARCH_MIPS, CS_MODE_MIPS32 | CS_MODE_LITTLE_ENDIAN)
code_offset = 0x800
for i in range(0, len(exe) - code_offset, 4):
    ram = load_addr + i - code_offset
    if ram < 0x80018000 or ram > 0x800C0000:
        continue
    word = int.from_bytes(exe[i:i+4], 'little')
    # Check for lui with 0x1F80
    if (word & 0xFFFF0000) == 0x3C011F80:  # lui $at, 0x1F80
        # Check next few instructions for 0x1810 offset
        for j in range(1, 4):
            if i + j*4 + 4 > len(exe):
                break
            w2 = int.from_bytes(exe[i+j*4:i+j*4+4], 'little')
            if (w2 & 0xFFFF) == 0x1810 or (w2 & 0xFFFF) == 0x1814:
                # Found GPU register access
                insns = list(md.disasm(exe[i:i+16], ram))
                for ins in insns:
                    print(f"  0x{ins.address:08X}: {ins.mnemonic:8s} {ins.op_str}")
                print()
                break

# Check display init flag area (0x800B5312)
print("\n=== Display init flag readers (0x8009694C area) ===")
print(disasm_range(exe, load_addr, 0x80096940, 0x80096960))

# Check what calls the VSync loop function
# The VSync loop is around 0x80096700. Let's look for jal to that area
print("\n=== Searching for calls to VSync loop function ===")
for i in range(0, len(exe) - code_offset, 4):
    ram = load_addr + i - code_offset
    if ram < 0x80018000 or ram > 0x800C0000:
        continue
    word = int.from_bytes(exe[i:i+4], 'little')
    # jal instruction: 0x0C000000 | (target >> 2)
    if (word & 0xFC000000) == 0x0C000000:
        target = (word & 0x03FFFFFF) << 2
        if 0x80096600 <= target <= 0x80096800:
            insns = list(md.disasm(exe[max(0,i-8):i+8], ram-8))
            for ins in insns:
                print(f"  0x{ins.address:08X}: {ins.mnemonic:8s} {ins.op_str}")
            print()
