#!/usr/bin/env python3
"""Check disc-check patch values - are they actually applied?"""
import struct

def read_sector(disc, lba):
    return disc[lba * 2352 + 24: lba * 2352 + 24 + 2048]

def read_exe_from_disc(disc_path, exe_lba, exe_size):
    with open(disc_path, 'rb') as f:
        disc = f.read()
    exe = bytearray()
    sectors = (exe_size + 2047) // 2048
    for i in range(sectors):
        exe.extend(read_sector(disc, exe_lba + i))
    return bytes(exe[:exe_size])

DISC = r'c:\LuxAura\VoidWalkers_Project\DQLOSTTRANSLATION\dq4_phaseC_build1.bin'
exe = read_exe_from_disc(DISC, 24, 960948)
DW7_DISC = r'c:\LuxAura\VoidWalkers_Project\DQLOSTTRANSLATION\DW7D1\DW7D1.bin'
dw7_exe = read_exe_from_disc(DW7_DISC, 24, 675840)

# The disc-check patches from the builder code:
# dc_offsets = {0x6112C, 0x611D8, 0x613B8, 0x614A4, 0x614F8, 0x7308C, 0x61424, 0x61520, 0x61360}
# dc_patches = {0x24020001, 0x24020001, 0x24020001, 0x00000000, 0x00000000, 0x08022BE9, 0x1000000B, 0x1000000B, 0x1000000A}
# But the output showed FRANK == DW7 at all these offsets!
# That means the patches were NOT applied!

print("=== DISC-CHECK PATCH VERIFICATION ===")
dc_offsets = [0x6112C, 0x611D8, 0x613B8, 0x614A4, 0x614F8, 0x7308C, 0x61424, 0x61520, 0x61360]
dc_patches = [0x24020001, 0x24020001, 0x24020001, 0x00000000, 0x00000000, 0x08022BE9, 0x1000000B, 0x1000000B, 0x1000000A]

for i, (off, expected) in enumerate(zip(dc_offsets, dc_patches)):
    actual = struct.unpack_from('<I', exe, off)[0]
    dw7_val = struct.unpack_from('<I', dw7_exe, off)[0]
    ram = off - 0x800 + 0x80017F00
    applied = "APPLIED" if actual == expected else "NOT APPLIED"
    same_as_dw7 = "SAME AS DW7" if actual == dw7_val else "DIFF FROM DW7"
    print(f"  [{i}] file=0x{off:X} ram=0x{ram:08X}: expected=0x{expected:08X} actual=0x{actual:08X} dw7=0x{dw7_val:08X} -> {applied} ({same_as_dw7})")

# Check the neutralize patch
neutralize_off = 0x387CC
neutralize_expected = bytes([0x08, 0x00, 0xE0, 0x03, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00])
actual_bytes = exe[neutralize_off:neutralize_off + 12]
dw7_bytes = dw7_exe[neutralize_off:neutralize_off + 12]
print(f"\n  Neutralize at 0x{neutralize_off:X}:")
print(f"    Expected: {neutralize_expected.hex()}")
print(f"    Actual:   {actual_bytes.hex()}")
print(f"    DW7:      {dw7_bytes.hex()}")
print(f"    Applied:  {'YES' if actual_bytes == neutralize_expected else 'NO'}")

# Check the FMV seek NOP sites
nop_sites = [0x26760, 0x2684C]  # file offsets for 0x8003DE60, 0x8003DF4C
print(f"\n=== FMV SEEK NOP SITES ===")
for off in nop_sites:
    actual = struct.unpack_from('<I', exe, off)[0]
    dw7_val = struct.unpack_from('<I', dw7_exe, off)[0]
    ram = off - 0x800 + 0x80017F00
    print(f"  file=0x{off:X} ram=0x{ram:08X}: actual=0x{actual:08X} dw7=0x{dw7_val:08X} -> {'NOPPED' if actual == 0 else 'NOT NOPPED'}")

# Check the HBD string patch
hbd_off = 0xF608  # where w71->q41 was applied
print(f"\n=== HBD STRING PATCH ===")
print(f"  At file offset 0x{hbd_off:X}:")
print(f"    Frank: {exe[hbd_off:hbd_off+12]}")
print(f"    DW7:   {dw7_exe[hbd_off:hbd_off+12]}")

# Check the LBA patch at 0x3A94
print(f"\n=== LBA PATCH ===")
lba_off = 0x3A94
frank_val = struct.unpack_from('<I', exe, lba_off)[0]
dw7_val = struct.unpack_from('<I', dw7_exe, lba_off)[0]
print(f"  At file offset 0x{lba_off:X}: Frank=0x{frank_val:08X} ({frank_val}) DW7=0x{dw7_val:08X} ({dw7_val})")

# Check the sequential sector table
print(f"\n=== SEQUENTIAL SECTOR TABLE (0xA39A8) ===")
for i in range(22):
    off = 0xA39A8 + i * 4
    frank_val = struct.unpack_from('<I', exe, off)[0]
    dw7_val = struct.unpack_from('<I', dw7_exe, off)[0]
    # Unpack as two 16-bit values
    frank_lo = frank_val & 0xFFFF
    frank_hi = (frank_val >> 16) & 0xFFFF
    dw7_lo = dw7_val & 0xFFFF
    dw7_hi = (dw7_val >> 16) & 0xFFFF
    delta = frank_val - dw7_val if frank_val != dw7_val else 0
    print(f"  [{i:2d}] Frank=0x{frank_val:08X} ({frank_lo},{frank_hi}) DW7=0x{dw7_val:08X} ({dw7_lo},{dw7_hi}) delta={delta}")

# Check the BSS clear values
print(f"\n=== BSS CLEAR ===")
bss_start_off = 0x76B88  # file offset for 0x8008E288
bss_end_off = 0x76B90    # file offset for 0x8008E290
frank_bss_start = struct.unpack_from('<I', exe, bss_start_off)[0]
dw7_bss_start = struct.unpack_from('<I', dw7_exe, bss_start_off)[0]
frank_bss_end = struct.unpack_from('<I', exe, bss_end_off)[0]
dw7_bss_end = struct.unpack_from('<I', dw7_exe, bss_end_off)[0]
print(f"  BSS start: Frank=0x{frank_bss_start:08X} DW7=0x{dw7_bss_start:08X}")
print(f"  BSS end:   Frank=0x{frank_bss_end:08X} DW7=0x{dw7_bss_end:08X}")
# Decode: lui v0, 0x800C; addiu v0, v0, -13112 = 0x800BCCC8
# lui v1, 0x800E; addiu v1, v1, -24960 = 0x800E9E80
frank_bss_start_addr = ((frank_bss_start >> 16) & 0xFFFF) << 16
frank_bss_start_addr |= (frank_bss_start & 0xFFFF) if (frank_bss_start & 0xFFFF) < 0x8000 else (frank_bss_start & 0xFFFF) - 0x10000
# Actually these are lui + addiu pairs, need to decode properly
# 0x8008E288: lui v0, 0x800C -> v0 = 0x800C0000
# 0x8008E28C: addiu v0, v0, -13112 -> v0 = 0x800C0000 + (-13112) = 0x800C0000 - 0x3338 = 0x800BCCC8
# But the instruction encoding has lui in one word and addiu in next
# Let me just check the addiu immediates
addiu_start = struct.unpack_from('<I', exe, bss_start_off + 4)[0]
addiu_end = struct.unpack_from('<I', exe, bss_end_off + 4)[0]
simm_start = addiu_start & 0xFFFF
simm_end = addiu_end & 0xFFFF
if simm_start >= 0x8000: simm_start -= 0x10000
if simm_end >= 0x8000: simm_end -= 0x10000
lui_start = (frank_bss_start >> 16) & 0xFFFF  # lui immediate
lui_end = (frank_bss_end >> 16) & 0xFFFF
bss_start_addr = (lui_start << 16) + simm_start
bss_end_addr = (lui_end << 16) + simm_end
print(f"  Decoded BSS clear: 0x{bss_start_addr:08X} to 0x{bss_end_addr:08X} ({bss_end_addr - bss_start_addr} bytes)")

# DW7 BSS
dw7_addiu_start = struct.unpack_from('<I', dw7_exe, bss_start_off + 4)[0]
dw7_addiu_end = struct.unpack_from('<I', dw7_exe, bss_end_off + 4)[0]
dw7_simm_start = dw7_addiu_start & 0xFFFF
dw7_simm_end = dw7_addiu_end & 0xFFFF
if dw7_simm_start >= 0x8000: dw7_simm_start -= 0x10000
if dw7_simm_end >= 0x8000: dw7_simm_end -= 0x10000
dw7_lui_start = (dw7_bss_start >> 16) & 0xFFFF
dw7_lui_end = (dw7_bss_end >> 16) & 0xFFFF
dw7_bss_start_addr = (dw7_lui_start << 16) + dw7_simm_start
dw7_bss_end_addr = (dw7_lui_end << 16) + dw7_simm_end
print(f"  DW7 BSS clear: 0x{dw7_bss_start_addr:08X} to 0x{dw7_bss_end_addr:08X} ({dw7_bss_end_addr - dw7_bss_start_addr} bytes)")
