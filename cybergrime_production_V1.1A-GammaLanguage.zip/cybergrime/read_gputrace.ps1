$j = Get-Content telemetry_gputrace_10m.json -Raw | ConvertFrom-Json
Write-Host "Instructions: $($j.Instructions_Executed)"
Write-Host "VBlanks: $($j.VBlank_Count)"
Write-Host "Crashed: $($j.Crashed)"
Write-Host "PC: $($j.Register_Dump.PC)"
$lines = $j.TTY_Tail -split "`n"
Write-Host "TTY lines: $($lines.Count)"
Write-Host "=== First 50 TTY lines ==="
$lines | Select-Object -First 50 | ForEach-Object { Write-Host "  $_" }
Write-Host ""
Write-Host "=== Last 30 TTY lines ==="
$lines | Select-Object -Last 30 | ForEach-Object { Write-Host "  $_" }
Write-Host ""
Write-Host "=== GPU/DMA lines ==="
$gpuLines = $lines | Where-Object { $_ -match 'GP0WR|GP1WR|DMA.*GPU|GPU timeout|GPURD' }
Write-Host "GPU/DMA lines: $($gpuLines.Count)"
$gpuLines | Select-Object -First 20 | ForEach-Object { Write-Host "  $_" }
Write-Host ""
Write-Host "=== BIOS Calls ==="
foreach ($e in $j.BIOS_Call_Log) {
    $fn = '{0:X2}' -f [int]$e.fn
    Write-Host ("  #{0} {1}:0x{2} ra=0x{3} a0=0x{4}" -f $e.instr, $e.table, $fn, $e.ra, $e.a0)
}
