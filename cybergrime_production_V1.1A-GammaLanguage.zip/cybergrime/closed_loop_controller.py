#!/usr/bin/env python3
"""
closed_loop_controller.py — The Circle of Truth closed-loop controller.

Binds DuckStation live telemetry → orchestrator analysis → memory injection →
verification into a single automated feedback loop.

Architecture:
  ┌─────────────────────────────────────────────────────────┐
  │                  CLOSED LOOP CONTROLLER                   │
  │                                                           │
  │  ┌─────────┐    telemetry    ┌────────────┐  patch_cmd   │
  │  │ DuckSta  │───PC/regs/mem──▶│ Orchestrator│───────────┐ │
  │  │ Bridge   │                 │ (Circle of  │            │ │
  │  │          │◀──inject────────│  Truth)     │            │ │
  │  └─────────┘    write_mem     └────────────┘            │ │
  │       │                                                 │ │
  │       │  stall? ◀─────────────verdict?──────────────────┘ │
  │       │  resolved?                                          │
  │       ▼                                                    │
  │  ┌─────────┐                                               │
  │  │ Verdict  │  3 clean cycles → BUILD READY                │
  │  └─────────┘                                               │
  └─────────────────────────────────────────────────────────┘

Usage:
  python closed_loop_controller.py --cue dq4_frankenstein_v38a.cue --max-iterations 10
  python closed_loop_controller.py --cue dq4_frankenstein_v40a.cue --max-iterations 20 --inject-bss-narrow
"""

import argparse
import json
import os
import sys
import time
import struct
from typing import Optional, Dict, List, Tuple

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from duckstation_bridge import DuckStationBridge, MIPS_REGS
from build_orchestrator import BuildOrchestrator, HISTORICAL_FAILURES, LAST_KNOWN_GOOD
from agent_bridge import AgentBridge
from pipeline_rulebook import PipelineRulebook, GateVerdict


# ── Constraint map and golden state for orchestrator ─────────────────────────

CONSTRAINT_MAP = {
    'bss_clear_start': 0x800BC668,
    'bss_clear_end_original': 0x800F4980,
    'bss_clear_end_narrowed': 0x800BCCC8,
    'thread_entry': 0x800D9E80,
    'tree_addr': 0x80100000,
    'tree_size': 1480,
    'copy_routine': 0x800BCCF0,
    'bss_clear_loop': 0x8008E294,
    'stall_pcs': [0x80098780, 0x8009885C, 0x80098840, 0x8009883C],
    'hbd_lba': 355,
    'exe_lba': 24,
}

GOLDEN_STATE = {
    'expected_boot_sequence': [
        {'pc': '0x800BCCF0', 'name': 'copy_routine_entry', 'max_instr': 1000},
        {'pc': '0x800BC700', 'name': 'tree_copy', 'max_instr': 5000},
        {'pc': '0x8008E284', 'name': 'bss_clear_entry', 'max_instr': 20000},
        {'pc': '0x8008E294', 'name': 'bss_clear_loop', 'max_instr': 160000},
        {'pc': '0x800D9E80', 'name': 'thread_entry', 'max_instr': 300000},
    ],
    'thread_entry_must_be_nonzero': True,
    'tree_must_be_nonzero': True,
    'no_stall_at_event_flag_poll': True,
    'clean_cycles_required': 3,
}


# ── Pre-verified runtime patches ─────────────────────────────────────────────

RUNTIME_PATCHES = {
    'bss_narrow': {
        'address': 0x8008E290,
        'value': 0x2462CCC8,
        'size': 4,
        'description': 'Narrow BSS clear end to 0x800BCCC8 (preserves thread entry)',
        'hf_id': 'HF-001',
        'timing': 'pre_bss_clear',  # Must be injected before BSS clear loop runs
    },
    'thread_entry_restore': {
        'address': 0x800D9E80,
        'value': None,  # Set dynamically from pre-BSS-clear read
        'size': 4,
        'description': 'Restore thread entry after BSS clear zeroed it',
        'hf_id': 'HF-001',
        'timing': 'post_bss_clear',  # Inject after BSS clear completes
    },
}


class ClosedLoopController:
    """Automated closed-loop: observe → analyze → inject → verify."""

    def __init__(self, cue_path: str, max_iterations: int = 10,
                 poll_interval: float = 0.02, output_log: str = "closed_loop.json"):
        self.cue_path = cue_path
        self.max_iterations = max_iterations
        self.poll_interval = poll_interval
        self.output_log = output_log

        self.bridge = DuckStationBridge()
        self.orchestrator = BuildOrchestrator(CONSTRAINT_MAP, GOLDEN_STATE,
                                               output_path=output_log)
        self.agent = AgentBridge()
        self.rulebook = PipelineRulebook(vector_db=self.agent.vdb)

        # State tracking
        self.iteration = 0
        self.clean_cycles = 0
        self.build_ready = False
        self.patches_applied: List[dict] = []
        self.log: List[dict] = []

        # Boot phase tracking
        self.boot_phases = [
            ('copy_routine', 0x800BCCF0, 1000),
            ('tree_copy', 0x800BC700, 5000),
            ('bss_clear_entry', 0x8008E284, 20000),
            ('bss_clear_loop', 0x8008E294, 160000),
            ('thread_entry', 0x800D9E80, 300000),
        ]
        self.current_phase = 0
        self.phase_hit: Dict[str, bool] = {}

        # Pre-BSS state capture
        self.pre_bss_thread_entry: Optional[int] = None
        self.bss_clear_seen = False
        self.bss_clear_done = False

        # Stall tracking
        self.stall_pc: Optional[int] = None
        self.stall_count = 0
        self.pc_history: List[int] = []
        self.max_pc_history = 256

        # Injection tracking
        self.pending_injections: List[dict] = []
        self.injected_patches: List[dict] = []

    def run(self):
        """Run the closed-loop controller."""
        print(f"\n{'='*60}")
        print(f"  CLOSED-LOOP CONTROLLER — Circle of Truth")
        print(f"  Disc: {self.cue_path}")
        print(f"  Max iterations: {self.max_iterations}")
        print(f"  Poll interval: {self.poll_interval}s")
        print(f"{'='*60}\n")

        # Launch DuckStation with retry
        ram_found = False
        for attempt in range(3):
            if attempt > 0:
                print(f"[CTRL] Retry {attempt+1}/3 — waiting 5s before relaunch...")
                time.sleep(5)
                # Clean up stale process
                try:
                    if self.bridge.process:
                        self.bridge.process.kill()
                        self.bridge.process.wait(timeout=5)
                except:
                    pass
                self.bridge = DuckStationBridge()

            self.bridge.launch(self.cue_path)

            try:
                if self.bridge.wait_for_ram(timeout=60):
                    ram_found = True
                    break
            except RuntimeError as e:
                print(f"[CTRL] DuckStation crashed: {e}")
                continue

        if not ram_found:
            print("[CTRL] FATAL: Could not find PSX RAM after 3 attempts")
            return

        # Wait for game to boot past BIOS
        print("[CTRL] Waiting 5s for BIOS init...")
        time.sleep(5)

        # Find CPU state
        self.bridge._find_cpu_state(timeout=15)

        if self.bridge.cpu_state_base is None:
            print("[CTRL] WARNING: CPU state not found — operating in memory-only mode")

        # Capture pre-BSS state
        self._capture_pre_bss_state()

        # Main loop
        for i in range(self.max_iterations):
            self.iteration = i
            print(f"\n[CTRL] ── Iteration {i+1}/{self.max_iterations} ──")

            result = self._run_iteration()

            if result == 'BUILD_READY':
                self.build_ready = True
                break
            elif result == 'FATAL':
                break

        # Final report
        self._final_report()
        self._write_log()
        self.bridge.close()

    def _capture_pre_bss_state(self):
        """Capture thread entry value before BSS clear runs."""
        print("[CTRL] Capturing pre-BSS state...")

        # Read thread entry before BSS clear
        val = self.bridge.read_u32(0x800D9E80)
        if val is not None and val != 0:
            self.pre_bss_thread_entry = val
            print(f"[CTRL]   Thread entry (pre-BSS): 0x{val:08X}")
        else:
            print(f"[CTRL]   Thread entry (pre-BSS): 0x{val or 0:08X} — will capture during boot")

        # Read BSS clear end instruction
        bss_end_instr = self.bridge.read_u32(0x8008E290)
        print(f"[CTRL]   BSS end instr @0x8008E290: 0x{bss_end_instr or 0:08X}")

    def _run_iteration(self) -> str:
        """Run one iteration of the closed loop."""
        # Reset per-iteration state
        self.stall_pc = None
        self.stall_count = 0
        self.pc_history.clear()
        self.current_phase = 0
        self.phase_hit.clear()
        self.bss_clear_seen = False
        self.bss_clear_done = False

        # Process any pending injections
        self._process_pending_injections()

        # Monitor for stall or boot completion
        monitor_duration = 30.0  # 30s per iteration
        start = time.time()
        sample_count = 0

        while time.time() - start < monitor_duration:
            if self.bridge.process and self.bridge.process.poll() is not None:
                print("[CTRL] DuckStation exited")
                return 'FATAL'

            pc = self.bridge.read_pc()
            if pc is not None:
                self._handle_pc(pc, sample_count)

                # Check for stall
                stall = self._detect_stall()
                if stall:
                    return self._handle_stall(stall)

                # Check for boot completion
                if self._check_boot_complete():
                    return self._handle_boot_success()

            # Process scheduled injections
            self._process_pending_injections()

            sample_count += 1
            time.sleep(self.poll_interval)

        # Timeout — no stall, no success
        print(f"[CTRL] Iteration timed out after {monitor_duration}s ({sample_count} samples)")
        return self._handle_timeout()

    def _handle_pc(self, pc: int, sample: int):
        """Handle a PC sample — track boot phases and BSS clear."""
        self.pc_history.append(pc)
        if len(self.pc_history) > self.max_pc_history:
            self.pc_history = self.pc_history[-self.max_pc_history:]

        # Track boot phases
        for name, phase_pc, max_instr in self.boot_phases:
            if pc == phase_pc and name not in self.phase_hit:
                self.phase_hit[name] = True
                regs = self.bridge.read_all_regs()
                print(f"[CTRL] Phase hit: {name} (PC=0x{pc:08X})")

                if name == 'bss_clear_entry':
                    self.bss_clear_seen = True
                    v1 = regs.get('v1', 0) if regs else 0
                    print(f"[CTRL]   BSS clear: $v1 (end) = 0x{v1:08X}")
                    if v1 > 0x800D9E80:
                        print(f"[CTRL]   ⚠ BSS end > thread entry — WILL ZERO IT!")
                        # Queue BSS narrow patch immediately
                        self._queue_bss_narrow_patch()

                elif name == 'bss_clear_loop':
                    if not self.bss_clear_done:
                        # Check if thread entry is already zeroed
                        te = self.bridge.read_u32(0x800D9E80)
                        if te == 0 and self.pre_bss_thread_entry is not None:
                            print(f"[CTRL]   Thread entry ZEROED — queueing restore injection")
                            self._queue_thread_entry_restore()

                elif name == 'thread_entry':
                    te = self.bridge.read_u32(0x800D9E80)
                    print(f"[CTRL]   Thread entry reached! Value: 0x{te:08X}"
                          f"{' ✓' if te != 0 else ' ⚠ ZEROED'}")

        # Periodic logging
        if sample % 500 == 0 and sample > 0:
            regs = self.bridge.read_all_regs()
            elapsed = time.time() - (start if 'start' in dir() else time.time())
            print(f"[CTRL] T+{sample*self.poll_interval:.1f}s PC=0x{pc:08X} "
                  f"phases={list(self.phase_hit.keys())}")

    def _queue_bss_narrow_patch(self):
        """Queue the BSS narrow patch to be injected immediately."""
        patch = RUNTIME_PATCHES['bss_narrow'].copy()
        patch['data'] = struct.pack('<I', patch['value'])
        patch['fire_time'] = time.time()
        self.pending_injections.append(patch)
        print(f"[CTRL] Queued BSS narrow patch: WRITE 0x{patch['address']:08X} = 0x{patch['value']:08X}")

    def _queue_thread_entry_restore(self):
        """Queue thread entry restore injection."""
        if self.pre_bss_thread_entry is None:
            # Read current value (might still be non-zero if we caught it early)
            val = self.bridge.read_u32(0x800D9E80)
            if val and val != 0:
                self.pre_bss_thread_entry = val
            else:
                print("[CTRL] WARNING: No pre-BSS thread entry value to restore")
                return

        patch = {
            'address': 0x800D9E80,
            'data': struct.pack('<I', self.pre_bss_thread_entry),
            'description': 'Restore thread entry after BSS clear',
            'fire_time': time.time(),
            'hf_id': 'HF-001',
        }
        self.pending_injections.append(patch)
        print(f"[CTRL] Queued thread entry restore: WRITE 0x800D9E80 = 0x{self.pre_bss_thread_entry:08X}")

    def _process_pending_injections(self):
        """Process all pending injections."""
        now = time.time()
        remaining = []
        for inj in self.pending_injections:
            if now >= inj.get('fire_time', 0):
                ok = self.bridge.write_mem(inj['address'], inj['data'])
                desc = inj.get('description', '')
                hf = inj.get('hf_id', '')
                print(f"[CTRL] INJECT: 0x{inj['address']:08X} ← "
                      f"{inj['data'].hex()} {'✓' if ok else '✗'} — {desc}")

                self.injected_patches.append({
                    'address': f'0x{inj["address"]:08X}',
                    'data': inj['data'].hex(),
                    'description': desc,
                    'hf_id': hf,
                    'success': ok,
                    'timestamp': now,
                })
            else:
                remaining.append(inj)
        self.pending_injections = remaining

    def _detect_stall(self) -> Optional[int]:
        """Detect stall loop — PC stuck in same range for too many samples."""
        if len(self.pc_history) < 128:
            return None

        recent = self.pc_history[-128:]
        unique = set(recent)
        if len(unique) <= 4:
            return max(recent, key=recent.count)
        return None

    def _handle_stall(self, stall_pc: int) -> str:
        """Handle a detected stall — run orchestrator + vector DB analysis."""
        print(f"\n[CTRL] ⚠ STALL DETECTED at PC=0x{stall_pc:08X}")

        # Gather telemetry for orchestrator
        regs = self.bridge.read_all_regs()
        telemetry = self._build_telemetry(stall_pc, regs)

        # ── Vector DB retrieval-augmented diagnosis ──
        print("[CTRL] Querying vector database for historical matches...")
        agent_result = self.agent.diagnose(telemetry)
        agent_report = self.agent.get_full_diagnostic_report(telemetry)
        print(agent_report)

        # Run orchestrator analysis (existing pipeline)
        print("[CTRL] Feeding telemetry to orchestrator...")
        result = self.orchestrator.analyze_telemetry(telemetry)

        # Check if orchestrator recommends a runtime patch
        patch = result.get('patch_instruction', {})
        action = patch.get('action', '')

        if action == 'WRITE_MEM':
            addr = int(patch.get('address', '0x0'), 16)
            value = int(patch.get('value', '0x0'), 16)
            size = patch.get('size', 4)

            print(f"[CTRL] Orchestrator recommends WRITE_MEM: "
                  f"0x{addr:08X} = 0x{value:08X}")
            print(f"[CTRL]   {patch.get('description', '')}")

            # ── VFS GATE: Evaluate against 5 Laws ──
            sim = result.get('simulated_verification', {})
            telemetry['timestamp'] = time.time()
            verdict = self.rulebook.evaluate(
                patch=patch,
                telemetry=telemetry,
                simulation=sim,
                vector_matches=agent_result.get('historical_basis') and
                               self.agent.vdb.query(telemetry, top_k=3) or [],
                source='duckstation_bridge',
            )
            print(f"[CTRL] {verdict}")

            if not verdict.approved:
                print(f"[CTRL] ⛔ PATCH REJECTED by rulebook gate — no injection")
                self._dump_critical_state(stall_pc)
                return 'CONTINUE'

            if sim.get('result') == 'PASS':
                print(f"[CTRL]   Simulation: PASS — injecting now")
                data = struct.pack('<I', value)[:size]
                print(f"[CTRL]   Injecting {len(data)} bytes: {data.hex()} at 0x{addr:08X}")
                ok = self.bridge.write_mem(addr, data)
                print(f"[CTRL]   write_mem result: {ok}")
                if ok:
                    self.injected_patches.append({
                        'address': f'0x{addr:08X}',
                        'data': data.hex(),
                        'description': patch.get('description', ''),
                        'hf_id': result.get('root_cause_analysis', {}).get('matched_historical', ''),
                        'success': True,
                        'timestamp': time.time(),
                    })
                    # Wait and check if stall resolves
                    print("[CTRL] Waiting 5s to see if stall resolves...")
                    time.sleep(5)
                    new_pc = self.bridge.read_pc()
                    if new_pc and new_pc != stall_pc:
                        print(f"[CTRL] ✓ PC moved: 0x{stall_pc:08X} → 0x{new_pc:08X}")
                        return 'CONTINUE'
                    else:
                        print(f"[CTRL] ✗ Stall persists — may need EXE-level patch")
                else:
                    print(f"[CTRL]   ✗ write_mem FAILED — address may be read-only or unmapped")
                    # Try direct write via _write_raw
                    host = self.bridge._psx_to_host(addr)
                    if host:
                        print(f"[CTRL]   Host address: 0x{host:016X}")
                        ok2 = self.bridge._write_raw(host, data)
                        print(f"[CTRL]   _write_raw result: {ok2}")
            else:
                print(f"[CTRL]   Simulation: {sim.get('result')} — patch withheld")

        elif action == 'DUMP_REGION':
            print(f"[CTRL] Orchestrator recommends DUMP_REGION at {patch.get('address')}")
            self._dump_critical_state(stall_pc)

        elif action == 'HOLD':
            print(f"[CTRL] Orchestrator says HOLD — simulation did not pass")

        # Dump stall state
        self._dump_critical_state(stall_pc)

        return 'CONTINUE'

    def _handle_boot_success(self) -> str:
        """Handle successful boot — increment clean cycle counter."""
        self.clean_cycles += 1
        print(f"\n[CTRL] ✓ BOOT SUCCESS — clean cycle {self.clean_cycles}/{GOLDEN_STATE['clean_cycles_required']}")

        # Verify golden state
        checks = self._verify_golden_state()
        all_pass = all(checks.values())
        if all_pass:
            print(f"[CTRL]   All golden state checks PASSED")
        else:
            failed = [k for k, v in checks.items() if not v]
            print(f"[CTRL]   Golden state failures: {failed}")
            self.clean_cycles = max(0, self.clean_cycles - 1)
            return 'CONTINUE'

        if self.clean_cycles >= GOLDEN_STATE['clean_cycles_required']:
            print(f"\n[CTRL] ═══ BUILD READY ═══")
            print(f"[CTRL]   {self.clean_cycles} clean cycles achieved!")
            return 'BUILD_READY'

        return 'CONTINUE'

    def _handle_timeout(self) -> str:
        """Handle iteration timeout."""
        pc = self.bridge.read_pc()
        if pc:
            print(f"[CTRL] Timeout at PC=0x{pc:08X}")
            self._dump_critical_state(pc)
        return 'CONTINUE'

    def _check_boot_complete(self) -> bool:
        """Check if the game has booted past all critical phases."""
        if 'thread_entry' in self.phase_hit:
            te = self.bridge.read_u32(0x800D9E80)
            if te and te != 0:
                return True
        return False

    def _build_telemetry(self, pc: int, regs: dict) -> dict:
        """Build telemetry dict in orchestrator's expected format."""
        # Normalize register format
        norm_regs = {}
        if regs:
            for k, v in regs.items():
                if isinstance(v, int):
                    norm_regs[k] = hex(v)
                else:
                    norm_regs[k] = v

        return {
            'Last_Known_PC': pc,
            'Instructions_Executed': len(self.pc_history) * 100,  # Approximate
            'Register_Dump': norm_regs,
            'Crashed': False,
            'Frozen': True,
            'Asset_Load_History': [],
            'Assert_Count': 0,
            'Assert_Fail_Count': 0,
            'source': 'duckstation_bridge',
            'stall_pc': hex(pc),
            'phases_hit': list(self.phase_hit.keys()),
            'patches_applied': len(self.injected_patches),
            # Critical memory state for orchestrator matching
            'thread_entry': self.bridge.read_u32(0x800D9E80) or 0,
            'bss_clear_end_instr': self.bridge.read_u32(0x8008E290) or 0,
            'tree_value': self.bridge.read_u32(0x80100000) or 0,
            # Instruction trace at stall PC for vector encoder
            'stall_instructions': self._read_stall_instructions(pc),
        }

    def _read_stall_instructions(self, pc: int, count: int = 8) -> List[int]:
        """Read MIPS instruction words at the stall PC for vector encoder."""
        instrs = []
        data = self.bridge.read_mem(pc, count * 4)
        if data:
            for i in range(0, min(len(data), count * 4), 4):
                if len(data) >= i + 4:
                    instrs.append(struct.unpack_from('<I', data, i)[0])
        return instrs

    def _dump_critical_state(self, pc: int):
        """Dump critical memory state for diagnosis."""
        print(f"\n[CTRL] === CRITICAL STATE DUMP ===")

        te = self.bridge.read_u32(0x800D9E80)
        te_str = f"0x{te or 0:08X}"
        print(f"  Thread entry (0x800D9E80): {te_str}"
              f"{' ⚠ ZEROED' if te == 0 else ''}")

        bss_end = self.bridge.read_u32(0x8008E290)
        print(f"  BSS end instr (0x8008E290): 0x{bss_end or 0:08X}")

        tree = self.bridge.read_u32(0x80100000)
        print(f"  Tree (0x80100000): 0x{tree or 0:08X}"
              f"{' ⚠ ZEROED' if tree == 0 else ''}")

        bss_mid = self.bridge.read_u32(0x800BC668)
        print(f"  BSS start (0x800BC668): 0x{bss_mid or 0:08X}")

        bss_orig_end = self.bridge.read_u32(0x800F4980)
        print(f"  BSS orig end (0x800F4980): 0x{bss_orig_end or 0:08X}")

        # Dump instructions at stall PC
        stall_data = self.bridge.read_mem(pc, 32)
        if stall_data:
            words = [struct.unpack_from('<I', stall_data, i)[0]
                     for i in range(0, min(len(stall_data), 32), 4)]
            print(f"  Instructions at stall PC:")
            for i, w in enumerate(words):
                print(f"    0x{pc + i*4:08X}: 0x{w:08X}")

        print(f"[CTRL] === END DUMP ===\n")

    def _verify_golden_state(self) -> Dict[str, bool]:
        """Verify golden state checks."""
        checks = {}

        te = self.bridge.read_u32(0x800D9E80)
        checks['thread_entry_nonzero'] = te is not None and te != 0

        tree = self.bridge.read_u32(0x80100000)
        checks['tree_nonzero'] = tree is not None and tree != 0

        checks['no_stall'] = self.stall_pc is None

        checks['all_phases_hit'] = all(
            name in self.phase_hit for name, _, _ in self.boot_phases
        )

        return checks

    def _final_report(self):
        """Print final report."""
        print(f"\n{'='*60}")
        print(f"  CLOSED-LOOP FINAL REPORT")
        print(f"{'='*60}")
        print(f"  Iterations: {self.iteration + 1}")
        print(f"  Clean cycles: {self.clean_cycles}/{GOLDEN_STATE['clean_cycles_required']}")
        print(f"  Build ready: {self.build_ready}")
        print(f"  Patches applied: {len(self.injected_patches)}")
        for p in self.injected_patches:
            print(f"    {p['address']} ← {p['data']} {'✓' if p['success'] else '✗'} — {p['description']}")
        print(f"  Phases hit: {list(self.phase_hit.keys())}")
        print(f"  Log: {self.output_log}")
        print(f"{'='*60}\n")

    def _write_log(self):
        """Write full session log."""
        output = {
            'session': {
                'cue': self.cue_path,
                'iterations': self.iteration + 1,
                'clean_cycles': self.clean_cycles,
                'build_ready': self.build_ready,
            },
            'patches_applied': self.injected_patches,
            'phases_hit': list(self.phase_hit.keys()),
            'orchestrator_log': self.orchestrator.orchestration_log,
        }
        with open(self.output_log, 'w') as f:
            json.dump(output, f, indent=2)


def main():
    parser = argparse.ArgumentParser(
        description="Closed-Loop Controller — DuckStation ↔ Orchestrator"
    )
    parser.add_argument("--cue", required=True, help="CUE file to launch")
    parser.add_argument("--max-iterations", type=int, default=10,
                        help="Maximum loop iterations")
    parser.add_argument("--poll", type=float, default=0.02,
                        help="Poll interval in seconds (default: 20ms)")
    parser.add_argument("--inject-bss-narrow", action="store_true",
                        help="Auto-inject BSS narrow patch before BSS clear runs")
    parser.add_argument("--output", default="closed_loop.json",
                        help="Output log file")
    args = parser.parse_args()

    ctrl = ClosedLoopController(
        cue_path=args.cue,
        max_iterations=args.max_iterations,
        poll_interval=args.poll,
        output_log=args.output,
    )

    if args.inject_bss_narrow:
        # Pre-queue the BSS narrow patch
        patch = RUNTIME_PATCHES['bss_narrow'].copy()
        patch['data'] = struct.pack('<I', patch['value'])
        patch['fire_time'] = 0  # Fire immediately
        ctrl.pending_injections.append(patch)
        print(f"[CTRL] Pre-queued BSS narrow patch")

    ctrl.run()


if __name__ == "__main__":
    main()
