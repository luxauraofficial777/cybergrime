#!/usr/bin/env python3
"""psx_ops.py — Python ctypes wrapper for psx_binary_ops C++ library.

Provides a clean Python API to the C++ binary surgery functions.
Python originals in frankenstein_builder.py are PRESERVED.
This is the preferred fast path when --use-cpp is active.
"""
import ctypes
import os
import struct
import sys

_LIB_PATH = os.path.join(os.path.dirname(__file__), 'psx_ops.dll')
_LIB = None

def _load_lib():
    global _LIB
    if _LIB is not None:
        return _LIB
    try:
        _LIB = ctypes.CDLL(_LIB_PATH)
        _setup_signatures()
    except OSError:
        _LIB = None
    return _LIB

def is_available():
    return _load_lib() is not None

def _setup_signatures():
    lib = _LIB
    # IsoImage
    lib.iso_open.argtypes = [ctypes.c_char_p]
    lib.iso_open.restype = ctypes.c_void_p
    lib.iso_close.argtypes = [ctypes.c_void_p]
    lib.iso_read_sector.argtypes = [ctypes.c_void_p, ctypes.c_uint32, ctypes.c_char_p]
    lib.iso_read_sector.restype = ctypes.c_int
    lib.iso_write_sector.argtypes = [ctypes.c_void_p, ctypes.c_uint32, ctypes.c_char_p]
    lib.iso_write_sector.restype = ctypes.c_int
    lib.iso_file_size.argtypes = [ctypes.c_void_p]
    lib.iso_file_size.restype = ctypes.c_uint32
    # ExePatcher
    lib.exe_load.argtypes = [ctypes.c_char_p, ctypes.c_uint32]
    lib.exe_load.restype = ctypes.c_void_p
    lib.exe_free.argtypes = [ctypes.c_void_p]
    lib.exe_read32.argtypes = [ctypes.c_void_p, ctypes.c_uint32]
    lib.exe_read32.restype = ctypes.c_uint32
    lib.exe_write32.argtypes = [ctypes.c_void_p, ctypes.c_uint32, ctypes.c_uint32]
    lib.exe_patch_lba.argtypes = [ctypes.c_void_p, ctypes.c_uint32, ctypes.c_uint32]
    lib.exe_patch_lba.restype = ctypes.c_uint32
    lib.exe_patch_seq_table.argtypes = [ctypes.c_void_p, ctypes.c_uint32, ctypes.c_uint32]
    lib.exe_patch_seq_table.restype = ctypes.c_uint32
    lib.exe_patch_tree_refs.argtypes = [ctypes.c_void_p, ctypes.c_uint16, ctypes.c_uint16,
                                         ctypes.c_uint16, ctypes.c_uint16]
    lib.exe_patch_tree_refs.restype = ctypes.c_uint32
    lib.exe_patch_disc_check.argtypes = [ctypes.c_void_p, ctypes.POINTER(ctypes.c_uint32),
                                          ctypes.POINTER(ctypes.c_uint32), ctypes.c_uint32]
    lib.exe_patch_disc_check.restype = ctypes.c_uint32
    lib.exe_append_reloc_payload.argtypes = [ctypes.c_void_p, ctypes.c_char_p, ctypes.c_uint32,
                                              ctypes.c_uint32, ctypes.c_uint32]
    lib.exe_patch_bss_clear_narrow.argtypes = [ctypes.c_void_p]
    lib.exe_patch_bss_clear_narrow.restype = ctypes.c_int
    lib.exe_append_reloc_payload_with_thread_fix.argtypes = [
        ctypes.c_void_p, ctypes.c_char_p, ctypes.c_uint32,
        ctypes.c_uint32, ctypes.c_uint32,
        ctypes.c_char_p, ctypes.c_uint32]
    lib.exe_raw.argtypes = [ctypes.c_void_p]
    lib.exe_raw.restype = ctypes.c_char_p
    lib.exe_size.argtypes = [ctypes.c_void_p]
    lib.exe_size.restype = ctypes.c_uint32
    lib.exe_pc0.argtypes = [ctypes.c_void_p]
    lib.exe_pc0.restype = ctypes.c_uint32
    # HbdReencoder
    lib.hbd_load.argtypes = [ctypes.c_char_p, ctypes.c_uint32, ctypes.c_char_p, ctypes.c_uint32]
    lib.hbd_load.restype = ctypes.c_void_p
    lib.hbd_free.argtypes = [ctypes.c_void_p]
    lib.hbd_handle_zero_tree.argtypes = [ctypes.c_void_p, ctypes.c_uint32]
    lib.hbd_handle_zero_tree.restype = ctypes.c_int
    lib.hbd_raw.argtypes = [ctypes.c_void_p]
    lib.hbd_raw.restype = ctypes.c_char_p
    lib.hbd_size.argtypes = [ctypes.c_void_p]
    lib.hbd_size.restype = ctypes.c_uint32
    # Utility
    lib.extend_disc_mode2.argtypes = [ctypes.c_char_p, ctypes.c_uint64]
    lib.extend_disc_mode2.restype = ctypes.c_int


class ExePatcher:
    """High-level wrapper around the C++ ExePatcher."""

    def __init__(self, exe_data: bytes):
        lib = _load_lib()
        if lib is None:
            raise RuntimeError("psx_ops.dll not found — falling back to Python")
        self._buf = ctypes.create_string_buffer(exe_data, len(exe_data))
        self._handle = lib.exe_load(self._buf, len(exe_data))
        if not self._handle:
            raise ValueError("Failed to load EXE data")

    def __del__(self):
        if getattr(self, '_handle', None):
            _LIB.exe_free(self._handle)

    def read32(self, ram_addr: int) -> int:
        return _LIB.exe_read32(self._handle, ram_addr)

    def write32(self, ram_addr: int, value: int):
        _LIB.exe_write32(self._handle, ram_addr, value)

    def patch_lba_references(self, old_lba: int, new_lba: int) -> int:
        return _LIB.exe_patch_lba(self._handle, old_lba, new_lba)

    def patch_sequential_sector_table(self, old_lba: int, new_lba: int) -> int:
        return _LIB.exe_patch_seq_table(self._handle, old_lba, new_lba)

    def patch_tree_references(self, old_lui: int, old_addiu: int,
                              new_lui: int, new_addiu: int) -> int:
        return _LIB.exe_patch_tree_refs(self._handle, old_lui, old_addiu,
                                        new_lui, new_addiu)

    def patch_disc_check(self, offsets, patches) -> int:
        n = len(offsets)
        off_arr = (ctypes.c_uint32 * n)(*offsets)
        patch_arr = (ctypes.c_uint32 * n)(*patches)
        return _LIB.exe_patch_disc_check(self._handle, off_arr, patch_arr, n)

    def append_reloc_payload(self, tree_data: bytes, tree_target_ram: int, original_pc0: int):
        lib = _LIB
        tree_buf = ctypes.create_string_buffer(tree_data, len(tree_data))
        lib.exe_append_reloc_payload(self._handle, tree_buf, len(tree_data),
                                     tree_target_ram, original_pc0)

    def patch_bss_clear_narrow(self) -> bool:
        """Option B: Narrow BSS clear to preserve thread entry at 0x800D9E80."""
        return bool(_LIB.exe_patch_bss_clear_narrow(self._handle))

    def append_reloc_payload_with_thread_fix(self, tree_data: bytes, tree_target_ram: int,
                                               original_pc0: int, thread_entry_data: bytes):
        """Option A: Extended copy routine with post-BSS thread entry injection."""
        tree_buf = ctypes.create_string_buffer(tree_data, len(tree_data))
        te_buf = ctypes.create_string_buffer(thread_entry_data, len(thread_entry_data))
        _LIB.exe_append_reloc_payload_with_thread_fix(
            self._handle, tree_buf, len(tree_data),
            tree_target_ram, original_pc0,
            te_buf, len(thread_entry_data))

    def get_data(self) -> bytes:
        size = _LIB.exe_size(self._handle)
        raw = _LIB.exe_raw(self._handle)
        return ctypes.string_at(raw, size)

    @property
    def pc0(self) -> int:
        return _LIB.exe_pc0(self._handle)

    @property
    def size(self) -> int:
        return _LIB.exe_size(self._handle)


class HbdReencoder:
    """High-level wrapper around the C++ HbdReencoder."""

    def __init__(self, hbd_data: bytes, tree_data: bytes):
        lib = _load_lib()
        if lib is None:
            raise RuntimeError("psx_ops.dll not found")
        self._buf = ctypes.create_string_buffer(hbd_data, len(hbd_data))
        self._tree = ctypes.create_string_buffer(tree_data, len(tree_data))
        self._handle = lib.hbd_load(self._buf, len(hbd_data), self._tree, len(tree_data))
        if not self._handle:
            raise ValueError("Failed to load HBD data")

    def __del__(self):
        if getattr(self, '_handle', None):
            _LIB.hbd_free(self._handle)

    def handle_zero_tree(self, offset: int) -> int:
        return _LIB.hbd_handle_zero_tree(self._handle, offset)

    def get_data(self) -> bytes:
        size = _LIB.hbd_size(self._handle)
        raw = _LIB.hbd_raw(self._handle)
        return ctypes.string_at(raw, size)

    @property
    def size(self) -> int:
        return _LIB.hbd_size(self._handle)


def extend_disc_mode2(path: str, new_size: int) -> int:
    lib = _load_lib()
    if lib is None:
        raise RuntimeError("psx_ops.dll not found")
    return lib.extend_disc_mode2(path.encode('utf-8'), new_size)


# ===== Disc-check patch tables (from frankenstein_builder.py) =====
# These are kept in Python for flexibility; C++ applies them via patch_disc_check()
DISC_CHECK_PATCHES = [
    {'offset': 0x6112C, 'patch': struct.pack('<I', 0x24020001), 'desc': 'exit1_success'},
    {'offset': 0x611D8, 'patch': struct.pack('<I', 0x24020001), 'desc': 'exit2_success'},
    {'offset': 0x613B8, 'patch': struct.pack('<I', 0x24020001), 'desc': 'exit3_success'},
    {'offset': 0x60FA4, 'patch': bytes.fromhex('010002240800E00300000000'), 'desc': 'cd_init'},
    {'offset': 0x614A4, 'patch': struct.pack('<I', 0x00000000), 'desc': 'nop_timeout'},
    {'offset': 0x614F8, 'patch': struct.pack('<I', 0x00000000), 'desc': 'nop_error'},
    {'offset': 0x387CC, 'patch': bytes.fromhex('0800E0030000000000000000'), 'desc': 'neutralize_disc'},
    {'offset': 0x7308C, 'patch': bytes.fromhex('e92b0208'), 'desc': 'redirect_trap'},
    {'offset': 0x61424, 'patch': bytes.fromhex('0b000010'), 'desc': 'graft_a'},
    {'offset': 0x61520, 'patch': bytes.fromhex('0b000010'), 'desc': 'graft_b'},
    {'offset': 0x61360, 'patch': bytes.fromhex('0a000010'), 'desc': 'graft_c'},
]

def get_disc_check_patches(surgical=False):
    """Return (offsets, patches) arrays for C++ patch_disc_check().
    Only 4-byte aligned patches are supported via the C API.
    Multi-word patches (cd_init, neutralize_disc) must be applied via Python fallback.
    """
    offsets = []
    patches = []
    for p in DISC_CHECK_PATCHES:
        if surgical and p['desc'] == 'cd_init':
            continue
        if len(p['patch']) == 4:
            offsets.append(p['offset'])
            patches.append(struct.unpack('<I', p['patch'])[0])
    return offsets, patches
