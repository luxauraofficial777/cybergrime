import struct, sys

def read_sector(f, lba, mode2=True):
    if mode2:
        f.seek(lba * 2352 + 24)
    else:
        f.seek(lba * 2048)
    return f.read(2048)

def parse_iso_dir(data, base=0):
    entries = []
    pos = 0
    while pos < len(data):
        rec_len = data[pos]
        if rec_len == 0:
            break
        ext_lba = struct.unpack_from('<I', data, pos + 2)[0]
        ext_size = struct.unpack_from('<I', data, pos + 10)[0]
        flags = data[pos + 25]
        name_len = data[pos + 32]
        name = data[pos + 33:pos + 33 + name_len]
        name_str = name.decode('ascii', errors='replace')
        entries.append((name_str, ext_lba, ext_size, flags))
        pos += rec_len
    return entries

discs = [
    ('Phase B', r'C:\LuxAura\VoidWalkers_Project\DQLOSTTRANSLATION\dq4_phaseB_final.bin'),
    ('Phase C', r'C:\LuxAura\VoidWalkers_Project\DQLOSTTRANSLATION\dq4_phaseC_build1.bin'),
    ('DQ4-JP', r'C:\LuxAura\VoidWalkers_Project\DQLOSTTRANSLATION\Dragon Quest IV - Michibikareshi Mono Tachi (Japan).bin'),
    ('DW7D1', r'C:\LuxAura\VoidWalkers_Project\DQLOSTTRANSLATION\DW7D1\DW7D1.bin'),
]

for label, path in discs:
    print(f'\n=== {label}: {path} ===')
    try:
        with open(path, 'rb') as f:
            # PVD at LBA 16, sector offset 24 for MODE2
            pvd = read_sector(f, 16)
            vol_id = pvd[40:72].decode('ascii', errors='replace').strip()
            root_lba = struct.unpack_from('<I', pvd, 158)[0]
            root_size = struct.unpack_from('<I', pvd, 166)[0]
            print(f'  Volume ID: {vol_id}')
            print(f'  Root Dir LBA: {root_lba}, Size: {root_size}')
            
            root_dir = read_sector(f, root_lba)
            entries = parse_iso_dir(root_dir)
            for name, lba, size, flags in entries:
                ftype = 'DIR' if flags & 0x02 else 'FILE'
                print(f'  {ftype}: {name!r} LBA={lba} Size={size}')
    except Exception as e:
        print(f'  ERROR: {e}')
