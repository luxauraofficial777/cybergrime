#!/usr/bin/env python3
"""Disassemble the full stall loop exit path to see what the game checks after copying from 0x800F2C70."""
import struct, os
from capstone import Cs, CS_ARCH_MIPS, CS_MODE_MIPS32, CS_MODE_LITTLE_ENDIAN

def read_exe_from_disc(disc_path, exe_lba=24, sector_size=2352, user_offset=24, user_size=2048):
    with open(disc_path, 'rb') as f:
        exe_sectors = 340
        f.seek(exe_lba * sector_size)
        raw = f.read(exe_sectors * sector_size)
    exe_data = bytearray()
    for i in range(exe_sectors):
        sector = raw[i * sector_size:(i + 1) * sector_size]
        if len(sector) < user_offset + user_size:
            break
        exe_data += sector[user_offset:user_offset + user_size]
    return bytes(exe_data)

def disasm_range(exe_data, load_addr, start_ram, end_ram):
    code_offset = 0x800
    file_start = start_ram - load_addr + code_offset
    file_end = end_ram - load_addr + code_offset
    if file_start < 0 or file_end > len(exe_data):
        return "  (outside EXE)\n"
    code = exe_data[file_start:file_end]
    md = Cs(CS_ARCH_MIPS, CS_MODE_MIPS32 | CS_MODE_LITTLE_ENDIAN)
    lines = []
    for insn in md.disasm(code, start_ram):
        lines.append(f"  0x{insn.address:08X}: {insn.mnemonic:8s} {insn.op_str}")
    return '\n'.join(lines) + '\n'

base = r"C:\LuxAura\VoidWalkers_Project\DQLOSTTRANSLATION"
disc = os.path.join(base, "dq4_frankenstein_v41.bin")
load_addr = 0x80017F00
exe = read_exe_from_disc(disc)

# Disassemble the full exit path after the copy loop
print("=== POST-COPY PATH (0x80098874-0x80098900) ===")
print(disasm_range(exe, load_addr, 0x80098874, 0x80098900))

# Also check the full function entry to see what s2 and s6 are set to
print("\n=== FUNCTION ENTRY (0x800986C8-0x80098720) ===")
print(disasm_range(exe, load_addr, 0x800986C8, 0x80098720))

# Check what's at 0x800F2C70 in the EXE (BIOS event table area)
off_2c70 = 0x800F2C70 - load_addr + 0x800
print(f"\n=== 0x800F2C70 EXE offset 0x{off_2c70:X} ===")
if 0 <= off_2c70 < len(exe):
    print(f"  Data: {exe[off_2c70:off_2c70+16].hex()}")
else:
    print(f"  Beyond EXE (BSS/uninitialized) — will be 0 at runtime")

# Also check the function called at 0x80098948 (called from 0x8009876C)
print("\n=== FUNCTION 0x80098948 (called from stall loop) ===")
print(disasm_range(exe, load_addr, 0x80098948, 0x800989C0))
