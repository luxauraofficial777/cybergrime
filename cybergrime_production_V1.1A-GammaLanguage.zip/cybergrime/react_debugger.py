#!/usr/bin/env python3
"""
react_debugger.py — ReAct Loop Debugger for Frankenstein ROM

Implements a structured reasoning framework:
  OBSERVE   — Parse telemetry from InstrumentationBus (PC, regs, memory)
  HYPOTHESIZE — Compare against golden_state.json, propose root cause + fix
  SIMULATE  — Run Python simulation to verify fix resolves conflict
  ACT       — Emit structured patch command (WRITE_MEM/WRITE_REG/SET_PC)
  AUDIT     — Self-audit for downstream LBA drift or new risk
  REFLECT   — If patch fails, critique previous hypothesis and retry

Output format (JSON blocks for programmatic parsing):

  {"phase":"OBSERVE","pc":"0x...","regs":{...},"mem":{...},"instr":N}
  {"phase":"HYPOTHESIZE","root_cause":"...","proposed_fix":{...}}
  {"phase":"SIMULATE","result":"PASS|FAIL","detail":"..."}
  {"phase":"ACT","action":"WRITE_MEM","address":"0x...","value":"0x...","description":"..."}
  {"phase":"AUDIT","risk":"NONE|LOW|HIGH","downstream":["..."]}
  {"phase":"REFLECT","previous_hypothesis":"...","critique":"...","new_hypothesis":"..."}

Usage:
  python react_debugger.py \
    --pipe \\\\.\pipe\\cybergrime_live \
    --constraints cybergrime/constraint_map.json \
    --golden cybergrime/golden_state.json \
    --max-attempts 5 \
    --output react_debug_log.json
"""

import argparse
import json
import os
import sys
import time
import traceback
from typing import Dict, List, Optional, Any, Tuple

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from runtime_comparator import RuntimeComparator
from patch_injector import PatchInjector
from ghidra_bridge import GhidraBridge


# ── Known Addresses ──────────────────────────────────────────────────────────

COPY_ROUTINE_PC = 0x800BC700
ORIGINAL_PC0 = 0x8008E284
HUFFMAN_PRIMARY = 0x80073670
HUFFMAN_SECONDARY = 0x80084BF0
BSS_CLEAR_START = 0x800BC668
BSS_CLEAR_END = 0x800F4980
THREAD_ENTRY = 0x800D9E80
TREE_ORIGINAL_RAM = 0x800EF1C8
SAFE_HIGH_RAM = 0x80100000
STALL_LOOP_PC = 0x8009885C
STALL_LOOP_PC2 = 0x80098780

EXE_LOAD_ADDR = 0x80017F00
ORIGINAL_HBD_LBA = 354
FRANKENSTEIN_HBD_LBA = 355

# BSS clear loop instruction at 0x8008E294 (sw $zero, 0($v0))
BSS_CLEAR_INSTR_PC = 0x8008E294


# ── Patch Record ─────────────────────────────────────────────────────────────

class PatchAction:
    """Structured patch action following deterministic output format."""
    def __init__(self, action: str, address: str, value: str,
                 size: int = 4, description: str = ""):
        self.action = action      # WRITE_MEM | WRITE_REG | SET_PC | ROLLBACK | DUMP_REGION
        self.address = address    # hex string
        self.value = value        # hex string
        self.size = size
        self.description = description

    def to_json(self) -> dict:
        return {
            'action': self.action,
            'address': self.address,
            'value': self.value,
            'size': self.size,
            'description': self.description,
        }

    def to_deterministic_string(self) -> str:
        return f"{self.action} | {self.address} | {self.value} | {self.description}"

    def apply(self, injector: PatchInjector) -> bool:
        if self.action == 'WRITE_MEM':
            return injector.write_mem(
                int(self.address, 16), int(self.value, 16),
                self.size, self.description)
        elif self.action == 'WRITE_REG':
            return injector.write_reg(
                int(self.address), int(self.value, 16),
                self.description)
        elif self.action == 'SET_PC':
            return injector.set_pc(
                int(self.address, 16), self.description)
        elif self.action == 'DUMP_REGION':
            return injector.dump_region(
                int(self.address, 16), self.size, self.description)
        elif self.action == 'ROLLBACK':
            return injector.rollback(self.description)
        return False


# ── Simulation Engine ────────────────────────────────────────────────────────

class SimulationEngine:
    """Python simulation of PSX memory state to verify patches before applying."""

    def __init__(self, constraint_map: dict, golden_state: dict):
        self.constraints = constraint_map
        self.golden = golden_state
        self.simulated_ram: Dict[int, uint32_t_like] = {}
        self.simulated_regs: Dict[str, int] = {}

    def load_state(self, regs: dict, mem_dumps: dict = None):
        """Load current emulator state into simulation."""
        for name, val in regs.items():
            self.simulated_regs[name] = int(val, 16) if isinstance(val, str) else val
        if mem_dumps:
            for addr, val in mem_dumps.items():
                self.simulated_ram[int(addr, 16) if isinstance(addr, str) else addr] = \
                    int(val, 16) if isinstance(val, str) else val

    def apply_patch(self, patch: PatchAction) -> bool:
        """Apply a patch to simulated state and check for conflicts."""
        if patch.action == 'WRITE_MEM':
            addr = int(patch.address, 16)
            val = int(patch.value, 16)
            self.simulated_ram[addr] = val

            # Check BSS range conflict
            bss = self.constraints.get('bss_clear', {})
            bss_start = int(bss.get('start', '0x800BC668'), 16)
            bss_end = int(bss.get('end', '0x800F4980'), 16)
            if bss_start <= addr < bss_end:
                # Check if this is the tree placement (allowed)
                tree_info = self.golden.get('tree_placement', {})
                tree_addr = int(tree_info.get('addr', '0x80100000'), 16)
                tree_size = self.constraints.get('huffman_tree', {}).get('hybrid_tree_size', 1480)
                if not (tree_addr <= addr < tree_addr + tree_size):
                    return False  # Conflict: writing to BSS range
            return True

        elif patch.action == 'WRITE_REG':
            reg_idx = int(patch.address)
            reg_names = ['zero','at','v0','v1','a0','a1','a2','a3',
                        't0','t1','t2','t3','t4','t5','t6','t7',
                        's0','s1','s2','s3','s4','s5','s6','s7',
                        't8','t9','k0','k1','gp','sp','fp','ra']
            if 0 <= reg_idx < 32:
                self.simulated_regs[reg_names[reg_idx]] = int(patch.value, 16)
            return True

        return True

    def verify_tree_pointer(self, reg_name: str = 'a2') -> Tuple[bool, str]:
        """Verify that a register points to the correct tree address."""
        tree_info = self.golden.get('tree_placement', {})
        expected_tree = int(tree_info.get('addr', '0x80100000'), 16)
        actual = self.simulated_regs.get(reg_name, 0)
        if actual == expected_tree:
            return True, f"${reg_name} correctly points to tree at {hex(expected_tree)}"
        return False, f"${reg_name}={hex(actual)} != expected tree {hex(expected_tree)}"

    def verify_bss_narrow(self) -> Tuple[bool, str]:
        """Verify BSS clear won't zero the tree or thread entry."""
        bss = self.constraints.get('bss_clear', {})
        bss_start = int(bss.get('start', '0x800BC668'), 16)
        bss_end = int(bss.get('end', '0x800F4980'), 16)

        tree_info = self.golden.get('tree_placement', {})
        tree_addr = int(tree_info.get('addr', '0x80100000'), 16)

        # Thread entry in BSS range?
        if bss_start <= THREAD_ENTRY < bss_end:
            return False, f"Thread entry {hex(THREAD_ENTRY)} is in BSS range — will be zeroed"

        # Tree in BSS range?
        tree_size = self.constraints.get('huffman_tree', {}).get('hybrid_tree_size', 1480)
        if bss_start <= tree_addr < bss_end:
            return False, f"Tree at {hex(tree_addr)} is in BSS range — will be zeroed"

        return True, f"BSS range [{hex(bss_start)}, {hex(bss_end)}) safe for tree and thread"

    def verify_lba(self, current_lba: int) -> Tuple[bool, str]:
        """Verify LBA is correctly patched."""
        if current_lba == FRANKENSTEIN_HBD_LBA:
            return True, f"LBA={current_lba} correctly patched to Frankenstein value"
        if current_lba == ORIGINAL_HBD_LBA:
            return False, f"LBA={current_lba} still at original DW7 value (expected {FRANKENSTEIN_HBD_LBA})"
        return False, f"LBA={current_lba} unexpected value"

    def check_downstream_risk(self, patch: PatchAction) -> Tuple[str, List[str]]:
        """Check if a patch introduces downstream risks."""
        risks = []

        if patch.action == 'WRITE_MEM':
            addr = int(patch.address, 16)

            # Check if writing to EXE code region
            if EXE_LOAD_ADDR <= addr < EXE_LOAD_ADDR + 0xA5000:
                risks.append(f"Writing to EXE code region at {hex(addr)} — may corrupt instructions")

            # Check if writing to hardware register region
            if 0x1F801000 <= addr < 0x1F802000:
                risks.append(f"Writing to hardware register at {hex(addr)} — may affect I/O state")

            # Check if writing to stack region
            sp = self.simulated_regs.get('sp', 0x801FFFF0)
            if abs(addr - sp) < 0x100:
                risks.append(f"Writing near stack pointer $sp={hex(sp)} — may corrupt stack")

        elif patch.action == 'WRITE_REG':
            reg_idx = int(patch.address)
            if reg_idx == 29:  # $sp
                risks.append("Modifying $sp — may cause stack corruption")
            elif reg_idx == 31:  # $ra
                risks.append("Modifying $ra — may cause return address corruption")
            elif reg_idx == 28:  # $gp
                risks.append("Modifying $gp — may cause global pointer drift")

        elif patch.action == 'SET_PC':
            addr = int(patch.address, 16)
            if addr < 0x80000000 or addr >= 0x80200000:
                risks.append(f"PC set to invalid range: {hex(addr)}")

        if not risks:
            return "NONE", []
        elif len(risks) == 1 and "code region" not in risks[0]:
            return "LOW", risks
        return "HIGH", risks


# ── ReAct Debugger ───────────────────────────────────────────────────────────

class ReActDebugger:
    """Main ReAct loop debugger.

    Follows the Observe → Hypothesize → Simulate → Act → Audit cycle.
    Uses Reflexion when patches fail: critiques previous hypothesis and retries.
    """

    def __init__(self, pipe_name: str, constraint_map: dict,
                 golden_state: dict, max_attempts: int = 5,
                 output_path: str = "react_debug_log.json"):
        self.pipe_name = pipe_name
        self.constraints = constraint_map
        self.golden = golden_state
        self.max_attempts = max_attempts
        self.output_path = output_path
        self.injector = PatchInjector(pipe_name)
        self.comparator = RuntimeComparator(constraint_map, golden_state)
        self.simulator = SimulationEngine(constraint_map, golden_state)
        self.ghidra = GhidraBridge()

        self.reasoning_log: List[dict] = []
        self.patch_history: List[dict] = []
        self.attempts: List[dict] = []
        self.current_attempt = 0
        self.events_processed = 0
        self.start_time = time.time()
        self.running = False

        # Failure tracking for Reflexion
        self.previous_hypotheses: List[dict] = []
        self.patch_failed = False

        # Known failure patterns
        self.failure_patterns = self._init_failure_patterns()

    def _init_failure_patterns(self) -> List[dict]:
        """Initialize known failure patterns and their fixes."""
        return [
            {
                'name': 'BSS_ZEROS_THREAD_ENTRY',
                'trigger': {
                    'pc': BSS_CLEAR_INSTR_PC,
                    'mem_addr_start': THREAD_ENTRY,
                    'mem_value': 0,
                },
                'root_cause': 'BSS clear loop at 0x8008E294 is zeroing thread entry at 0x800D9E80. '
                              'The BSS clear range [0x800BC668, 0x800F4980) includes the CD-ROM thread entry.',
                'fix': {
                    'action': 'WRITE_MEM',
                    'address': hex(0x800BC668 + 0x2C),  # BSS end register in EXE
                    'value': '0x800BCCC8',
                    'description': 'Narrow BSS clear end to 0x800BCCC8 to preserve thread entry',
                },
                'downstream_risk': 'LOW — narrowing BSS preserves thread entry without affecting other zeroed regions',
            },
            {
                'name': 'HUFFMAN_TREE_POINTER_MISMATCH',
                'trigger': {
                    'pc': HUFFMAN_PRIMARY,
                    'reg': 'a2',
                    'expected': int(self.golden.get('tree_placement', {}).get('addr', '0x80100000'), 16),
                },
                'root_cause': 'Huffman decompression called with tree pointer pointing to original DW7 location '
                              '0x800EF1C8 instead of relocated tree at {expected}. '
                              'The tree reference LUI/ADDIU pairs were not patched.',
                'fix': {
                    'action': 'WRITE_REG',
                    'address': '6',  # $a2
                    'value': hex(int(self.golden.get('tree_placement', {}).get('addr', '0x80100000'), 16)),
                    'description': 'Fix tree pointer $a2 to point to relocated tree',
                },
                'downstream_risk': 'NONE — register fix is local to this decompression call',
            },
            {
                'name': 'HUFFMAN_TREE_NOT_COPIED',
                'trigger': {
                    'pc': HUFFMAN_PRIMARY,
                    'reg': 'a2',
                    'actual': 0,
                },
                'root_cause': 'Tree pointer is NULL — copy routine at 0x800BC700 did not execute or failed. '
                              'Tree data was not copied to high RAM before decompression was called.',
                'fix': {
                    'action': 'WRITE_REG',
                    'address': '6',  # $a2
                    'value': hex(int(self.golden.get('tree_placement', {}).get('addr', '0x80100000'), 16)),
                    'description': 'Emergency tree pointer fix — copy routine may have been skipped',
                },
                'downstream_risk': 'HIGH — indicates copy routine failed; tree data may not be at expected address. '
                                   'Need to verify tree data is actually present at target address.',
            },
            {
                'name': 'STALL_LOOP_EVENT_FLAG',
                'trigger': {
                    'pc': STALL_LOOP_PC,
                    'min_visits': 100,
                },
                'root_cause': 'Game is stuck in event flag polling loop at 0x8009885C. '
                              'This happens when CD-ROM thread entry at 0x800D9E80 was zeroed by BSS clear, '
                              'preventing the CD loading thread from running and setting the event flag.',
                'fix': {
                    'action': 'WRITE_MEM',
                    'address': hex(THREAD_ENTRY),
                    'value': '0x00000000',  # Placeholder — need actual thread code
                    'description': 'Restore thread entry code at 0x800D9E80 (requires thread_code_blob.bin)',
                },
                'downstream_risk': 'HIGH — writing zero to thread entry will not fix the stall. '
                                   'Need actual thread code blob injection.',
            },
            {
                'name': 'LBA_NOT_PATCHED',
                'trigger': {
                    'vfs_lba': ORIGINAL_HBD_LBA,
                },
                'root_cause': f'CD-ROM is reading from original DW7 LBA {ORIGINAL_HBD_LBA} instead of '
                              f'Frankenstein LBA {FRANKENSTEIN_HBD_LBA}. LBA references in EXE not patched.',
                'fix': {
                    'action': 'WRITE_MEM',
                    'address': '0x800562E4',  # HBD type trampoline
                    'value': '0x08040400',  # JAL to trampoline
                    'description': 'Patch HBD type trampoline to redirect to DQ4 sub-block handler',
                },
                'downstream_risk': 'MEDIUM — LBA patch affects all CD-ROM reads; verify all folder pointers',
            },
        ]

    def run(self):
        """Main ReAct loop."""
        self.running = True
        print(f"[REACT] ReAct Debugger started (max_attempts={self.max_attempts})")
        print(f"[REACT] Pipe: {self.pipe_name}")
        print(f"[REACT] Output: {self.output_path}")

        # Set breakpoints at critical addresses
        self._set_breakpoints()

        # Connect to pipe
        pipe_handle = self._connect_pipe()
        if pipe_handle is None:
            print("[REACT] ERROR: Cannot connect to pipe")
            return

        print(f"[REACT] Connected to emulator")

        buf = b""
        try:
            while self.running:
                data = self._read_pipe(pipe_handle)
                if data is None:
                    print("[REACT] Pipe disconnected, waiting for reconnect...")
                    pipe_handle = self._connect_pipe()
                    if pipe_handle is None:
                        time.sleep(1)
                        continue
                    continue

                if data:
                    buf += data
                    while b'\n' in buf:
                        line, buf = buf.split(b'\n', 1)
                        if line.strip():
                            self._process_event(line.decode('utf-8', errors='replace'))
                else:
                    time.sleep(0.001)

        except KeyboardInterrupt:
            print("\n[REACT] Interrupted by user")
        finally:
            self._close_pipe(pipe_handle)
            self._write_log()

    def _set_breakpoints(self):
        """Set breakpoints at all critical addresses."""
        bps = [
            (COPY_ROUTINE_PC, "copy_routine_entry"),
            (ORIGINAL_PC0, "bss_clear_entry"),
            (BSS_CLEAR_INSTR_PC, "bss_clear_loop"),
            (HUFFMAN_PRIMARY, "huffman_decompress_primary"),
            (HUFFMAN_SECONDARY, "huffman_decompress_secondary"),
            (THREAD_ENTRY, "thread_entry"),
            (STALL_LOOP_PC, "stall_loop"),
        ]
        for addr, desc in bps:
            self.injector.set_breakpoint(addr, desc)
            print(f"[REACT] Breakpoint: {hex(addr)} ({desc})")

    def _process_event(self, line: str):
        """Process a single event through the ReAct loop."""
        try:
            event = json.loads(line)
        except json.JSONDecodeError:
            return

        self.events_processed += 1
        etype = event.get('type', '')

        # Pass to comparator
        divergence = self.comparator.handle_event(event)

        # Only trigger ReAct loop on breakpoints or divergences
        if etype == 'bp_hit':
            self._react_cycle(event, divergence)
        elif divergence and divergence.get('severity') == 'FATAL':
            self._react_cycle(event, divergence)

        # Periodic status
        if self.events_processed % 5000 == 0:
            print(f"[REACT] Events: {self.events_processed} | "
                  f"Attempts: {self.current_attempt} | "
                  f"Patches: {len(self.patch_history)}")

    def _react_cycle(self, event: dict, divergence: Optional[dict]):
        """Execute one full ReAct cycle: Observe → Hypothesize → Simulate → Act → Audit."""
        self.current_attempt += 1

        if self.current_attempt > self.max_attempts:
            print(f"[REACT] Max attempts ({self.max_attempts}) reached — stopping")
            self.running = False
            return

        # ── OBSERVE ─────────────────────────────────────────────────────
        observe = self._observe(event, divergence)
        self._log_phase("OBSERVE", observe)

        # ── HYPOTHESIZE ─────────────────────────────────────────────────
        hypothesis = self._hypothesize(observe)
        self._log_phase("HYPOTHESIZE", hypothesis)

        if hypothesis is None:
            print(f"[REACT] No matching failure pattern — monitoring only")
            return

        # ── SIMULATE ────────────────────────────────────────────────────
        simulation = self._simulate(hypothesis, observe)
        self._log_phase("SIMULATE", simulation)

        if simulation['result'] != 'PASS':
            print(f"[REACT] Simulation FAILED — not applying patch")
            # Try Reflexion
            if self.patch_failed:
                reflection = self._reflect(hypothesis, simulation)
                self._log_phase("REFLECT", reflection)
            return

        # ── ACT ─────────────────────────────────────────────────────────
        patch = PatchAction(
            action=hypothesis['fix']['action'],
            address=hypothesis['fix']['address'],
            value=hypothesis['fix']['value'],
            size=hypothesis['fix'].get('size', 4),
            description=hypothesis['fix']['description'],
        )

        act_result = self._act(patch)
        self._log_phase("ACT", act_result)

        # ── AUDIT ───────────────────────────────────────────────────────
        audit = self._audit(patch, hypothesis)
        self._log_phase("AUDIT", audit)

        # Record attempt
        attempt = {
            'attempt_num': self.current_attempt,
            'observe': observe,
            'hypothesis': hypothesis,
            'simulation': simulation,
            'act': act_result,
            'audit': audit,
        }
        self.attempts.append(attempt)

        # Track for Reflexion
        self.previous_hypotheses.append({
            'attempt': self.current_attempt,
            'root_cause': hypothesis['root_cause'],
            'fix': hypothesis['fix'],
        })

    def _observe(self, event: dict, divergence: Optional[dict]) -> dict:
        """OBSERVE: Parse telemetry and identify the failure point."""
        pc = int(event.get('pc', '0x0'), 16)
        instr = event.get('instr', 0)
        regs = event.get('regs', {})

        observe = {
            'pc': hex(pc),
            'instr': instr,
            'regs': regs,
            'divergence': divergence,
            'event_type': event.get('type', ''),
        }

        # Identify what we're looking at
        if pc == BSS_CLEAR_INSTR_PC:
            # BSS clear loop — check what's being zeroed
            v0 = int(regs.get('v0', '0x0'), 16)
            observe['context'] = 'BSS_CLEAR_LOOP'
            observe['bss_target'] = hex(v0)
            observe['is_thread_entry'] = (THREAD_ENTRY <= v0 < THREAD_ENTRY + 0x100)
            observe['is_tree_region'] = v0 == TREE_ORIGINAL_RAM

        elif pc == HUFFMAN_PRIMARY or pc == HUFFMAN_SECONDARY:
            a2 = int(regs.get('a2', '0x0'), 16)
            a0 = int(regs.get('a0', '0x0'), 16)
            a1 = int(regs.get('a1', '0x0'), 16)
            observe['context'] = 'HUFFMAN_DECOMPRESS'
            observe['tree_ptr'] = hex(a2)
            observe['src_ptr'] = hex(a0)
            observe['dst_ptr'] = hex(a1)
            observe['tree_is_null'] = (a2 == 0)
            observe['tree_is_original'] = (a2 == TREE_ORIGINAL_RAM)

        elif pc == STALL_LOOP_PC or pc == STALL_LOOP_PC2:
            observe['context'] = 'STALL_LOOP'
            observe['stall_count'] = self.events_processed

        elif pc == COPY_ROUTINE_PC:
            t0 = int(regs.get('t0', '0x0'), 16)
            t1 = int(regs.get('t1', '0x0'), 16)
            t2 = int(regs.get('t2', '0x0'), 16)
            observe['context'] = 'COPY_ROUTINE'
            observe['src'] = hex(t0)
            observe['dst'] = hex(t1)
            observe['end'] = hex(t2)

        elif pc == THREAD_ENTRY:
            observe['context'] = 'THREAD_ENTRY'
            # Check if thread entry has valid code
            observe['thread_entry_reached'] = True

        else:
            observe['context'] = 'UNKNOWN'

        # Print observation
        print(f"\n  [OBSERVE] PC={observe['pc']} instr=#{instr} context={observe['context']}")
        if observe['context'] == 'BSS_CLEAR_LOOP':
            target = observe.get('bss_target', '0x0')
            is_thread = observe.get('is_thread_entry', False)
            print(f"    BSS zeroing: {target} {'⚠ THREAD ENTRY!' if is_thread else ''}")
        elif observe['context'] == 'HUFFMAN_DECOMPRESS':
            print(f"    Tree: {observe.get('tree_ptr')} src: {observe.get('src_ptr')} dst: {observe.get('dst_ptr')}")
            if observe.get('tree_is_null'):
                print(f"    ⚠ Tree pointer is NULL!")
            elif observe.get('tree_is_original'):
                print(f"    ⚠ Tree points to original DW7 location (in BSS range!)")
        elif observe['context'] == 'STALL_LOOP':
            print(f"    ⚠ Stuck in event flag polling loop")

        return observe

    def _hypothesize(self, observe: dict) -> Optional[dict]:
        """HYPOTHESIZE: Match observed failure to known pattern and propose fix."""
        context = observe.get('context', 'UNKNOWN')
        pc = observe.get('pc', '0x0')

        # Match against failure patterns
        for pattern in self.failure_patterns:
            trigger = pattern['trigger']

            if context == 'BSS_CLEAR_LOOP' and pattern['name'] == 'BSS_ZEROS_THREAD_ENTRY':
                if observe.get('is_thread_entry'):
                    hypothesis = {
                        'pattern_name': pattern['name'],
                        'root_cause': pattern['root_cause'],
                        'fix': dict(pattern['fix']),
                        'confidence': 'HIGH',
                        'evidence': f"BSS loop zeroing {observe.get('bss_target')} which is thread entry",
                    }
                    print(f"  [HYPOTHESIZE] Pattern: {pattern['name']}")
                    print(f"    Root cause: {pattern['root_cause']}")
                    return hypothesis

            elif context == 'HUFFMAN_DECOMPRESS' and pattern['name'] == 'HUFFMAN_TREE_POINTER_MISMATCH':
                if observe.get('tree_is_original'):
                    expected = int(self.golden.get('tree_placement', {}).get('addr', '0x80100000'), 16)
                    fix = dict(pattern['fix'])
                    fix['value'] = hex(expected)
                    fix['description'] = f"Fix tree pointer $a2 from {observe.get('tree_ptr')} to {hex(expected)}"
                    hypothesis = {
                        'pattern_name': pattern['name'],
                        'root_cause': pattern['root_cause'].format(expected=hex(expected)),
                        'fix': fix,
                        'confidence': 'HIGH',
                        'evidence': f"$a2={observe.get('tree_ptr')} points to BSS-zeroed region",
                    }
                    print(f"  [HYPOTHESIZE] Pattern: {pattern['name']}")
                    print(f"    Root cause: {hypothesis['root_cause']}")
                    return hypothesis

            elif context == 'HUFFMAN_DECOMPRESS' and pattern['name'] == 'HUFFMAN_TREE_NOT_COPIED':
                if observe.get('tree_is_null'):
                    expected = int(self.golden.get('tree_placement', {}).get('addr', '0x80100000'), 16)
                    fix = dict(pattern['fix'])
                    fix['value'] = hex(expected)
                    hypothesis = {
                        'pattern_name': pattern['name'],
                        'root_cause': pattern['root_cause'],
                        'fix': fix,
                        'confidence': 'MEDIUM',
                        'evidence': f"$a2=0x00000000 (NULL) — tree not loaded",
                    }
                    print(f"  [HYPOTHESIZE] Pattern: {pattern['name']}")
                    print(f"    Root cause: {pattern['root_cause']}")
                    return hypothesis

            elif context == 'STALL_LOOP' and pattern['name'] == 'STALL_LOOP_EVENT_FLAG':
                hypothesis = {
                    'pattern_name': pattern['name'],
                    'root_cause': pattern['root_cause'],
                    'fix': dict(pattern['fix']),
                    'confidence': 'HIGH',
                    'evidence': f"PC stuck at {pc} — event flag polling",
                }
                print(f"  [HYPOTHESIZE] Pattern: {pattern['name']}")
                print(f"    Root cause: {pattern['root_cause']}")
                return hypothesis

        # No matching pattern
        print(f"  [HYPOTHESIZE] No matching failure pattern for context={context}")
        return None

    def _simulate(self, hypothesis: dict, observe: dict) -> dict:
        """SIMULATE: Verify the proposed fix in Python simulation."""
        fix = hypothesis['fix']
        patch = PatchAction(
            action=fix['action'],
            address=fix['address'],
            value=fix['value'],
            size=fix.get('size', 4),
            description=fix['description'],
        )

        # Load current state into simulator
        self.simulator.load_state(observe.get('regs', {}))

        # Apply patch to simulation
        sim_ok = self.simulator.apply_patch(patch)

        if not sim_ok:
            return {
                'result': 'FAIL',
                'detail': f'Patch conflicts with BSS range or memory constraints',
                'patch': patch.to_json(),
            }

        # Run verification checks based on pattern
        pattern_name = hypothesis['pattern_name']

        if pattern_name == 'HUFFMAN_TREE_POINTER_MISMATCH' or pattern_name == 'HUFFMAN_TREE_NOT_COPIED':
            ok, detail = self.simulator.verify_tree_pointer('a2')
            return {
                'result': 'PASS' if ok else 'FAIL',
                'detail': detail,
                'patch': patch.to_json(),
            }

        elif pattern_name == 'BSS_ZEROS_THREAD_ENTRY':
            ok, detail = self.simulator.verify_bss_narrow()
            return {
                'result': 'PASS' if ok else 'FAIL',
                'detail': detail,
                'patch': patch.to_json(),
            }

        elif pattern_name == 'STALL_LOOP_EVENT_FLAG':
            # Can't fully simulate thread code injection — mark as needs-verification
            return {
                'result': 'PASS',
                'detail': 'Thread entry fix requires actual code blob — simulation limited',
                'patch': patch.to_json(),
                'warning': 'Need to verify thread_code_blob.bin is available',
            }

        return {
            'result': 'PASS',
            'detail': 'No specific verification check — defaulting to PASS',
            'patch': patch.to_json(),
        }

    def _act(self, patch: PatchAction) -> dict:
        """ACT: Apply the patch via instrumentation bus."""
        print(f"  [ACT] {patch.to_deterministic_string()}")

        ok = patch.apply(self.injector)

        result = {
            'applied': ok,
            'patch': patch.to_json(),
            'deterministic': patch.to_deterministic_string(),
        }

        if ok:
            self.patch_history.append(patch.to_json())
            print(f"    ✓ Patch applied successfully")
        else:
            print(f"    ✗ Patch application FAILED")
            self.patch_failed = True

        return result

    def _audit(self, patch: PatchAction, hypothesis: dict) -> dict:
        """AUDIT: Self-audit for downstream risks."""
        risk_level, risks = self.simulator.check_downstream_risk(patch)

        audit = {
            'risk': risk_level,
            'downstream_risks': risks,
            'pattern_downstream': hypothesis.get('fix', {}).get('downstream_risk', 'Unknown'),
        }

        print(f"  [AUDIT] Risk: {risk_level}")
        for r in risks:
            print(f"    ⚠ {r}")
        if not risks:
            print(f"    ✓ No downstream risks detected")

        return audit

    def _reflect(self, previous_hypothesis: dict, simulation: dict) -> dict:
        """REFLECT: Critique previous hypothesis when patch fails."""
        prev = self.previous_hypotheses[-1] if self.previous_hypotheses else None

        reflection = {
            'previous_hypothesis': prev['root_cause'] if prev else 'None',
            'critique': 'Previous fix did not resolve the issue. The root cause may be deeper — '
                       'possibly the copy routine itself failed, or the BSS clear range is wider than expected.',
            'new_hypothesis': 'Need to request memory dump at tree target address to verify '
                             'whether tree data was actually copied. If tree is zero, the copy '
                             'routine at 0x800BC700 may not have executed.',
            'action_needed': 'DUMP_REGION at tree target address',
        }

        print(f"  [REFLECT] Previous: {reflection['previous_hypothesis']}")
        print(f"    Critique: {reflection['critique']}")
        print(f"    New direction: {reflection['new_hypothesis']}")

        # Request diagnostic dump
        tree_addr = int(self.golden.get('tree_placement', {}).get('addr', '0x80100000'), 16)
        dump_patch = PatchAction(
            action='DUMP_REGION',
            address=hex(tree_addr),
            value='0x0',
            size=64,
            description='Reflexion: verify tree data at target address',
        )
        dump_patch.apply(self.injector)

        return reflection

    def _log_phase(self, phase: str, data: dict):
        """Log a ReAct phase."""
        entry = {
            'phase': phase,
            'timestamp': time.time(),
            'attempt': self.current_attempt,
            'data': data,
        }
        self.reasoning_log.append(entry)

    def _connect_pipe(self):
        """Connect to Windows named pipe with retry loop."""
        # Try win32file first, then ctypes fallback
        for attempt in range(100):
            try:
                import win32file
                import pywintypes
                try:
                    return win32file.CreateFile(
                        self.pipe_name,
                        win32file.GENERIC_READ | win32file.GENERIC_WRITE,
                        0, None, win32file.OPEN_EXISTING, 0, None)
                except pywintypes.error as e:
                    if e.winerror == 231:  # ERROR_PIPE_BUSY
                        time.sleep(0.1)
                        continue
                    elif e.winerror == 2:  # ERROR_FILE_NOT_FOUND
                        time.sleep(0.1)
                        continue
                    else:
                        return None
            except ImportError:
                break

        # ctypes fallback with retry
        import ctypes
        kernel32 = ctypes.windll.kernel32
        GENERIC_READ = 0x80000000
        GENERIC_WRITE = 0x40000000
        OPEN_EXISTING = 3
        INVALID_HANDLE_VALUE = ctypes.c_void_p(-1).value

        for _ in range(100):
            handle = kernel32.CreateFileW(
                self.pipe_name, GENERIC_READ | GENERIC_WRITE,
                0, None, OPEN_EXISTING, 0, None)
            if handle != INVALID_HANDLE_VALUE:
                return handle
            time.sleep(0.1)
        return None

    def _read_pipe(self, handle):
        """Read from pipe."""
        try:
            import win32file
            import pywintypes
            try:
                err, data = win32file.ReadFile(handle, 65536)
                if err == 0:
                    return data
                return b""
            except pywintypes.error as e:
                if e.winerror == 232:
                    return b""
                return None
        except ImportError:
            pass

        import ctypes
        kernel32 = ctypes.windll.kernel32
        buf = ctypes.create_string_buffer(65536)
        bytes_read = ctypes.c_ulong(0)
        ok = kernel32.ReadFile(handle, buf, 65536,
                               ctypes.byref(bytes_read), None)
        if ok:
            return buf.raw[:bytes_read.value]
        if kernel32.GetLastError() == 232:
            return b""
        return None

    def _close_pipe(self, handle):
        if handle is None:
            return
        try:
            import win32file
            win32file.CloseHandle(handle)
        except (ImportError, Exception):
            import ctypes
            ctypes.windll.kernel32.CloseHandle(handle)

    def _write_log(self):
        """Write the full ReAct debugging log."""
        report = self.comparator.get_report()
        log = {
            'session': {
                'events_processed': self.events_processed,
                'duration_seconds': time.time() - self.start_time,
                'attempts': self.current_attempt,
                'patches_applied': len(self.patch_history),
                'pipe': self.pipe_name,
            },
            'reasoning_log': self.reasoning_log,
            'patch_history': self.patch_history,
            'attempts': self.attempts,
            'divergence_report': report,
            'previous_hypotheses': self.previous_hypotheses,
        }

        with open(self.output_path, 'w') as f:
            json.dump(log, f, indent=2)

        print(f"\n{'='*70}")
        print(f"  REACT DEBUG LOG — {self.output_path}")
        print(f"{'='*70}")
        print(f"  Events: {self.events_processed}")
        print(f"  Attempts: {self.current_attempt}")
        print(f"  Patches: {len(self.patch_history)}")
        print(f"  Divergences: {report['total_divergences']}")
        print(f"{'='*70}")

        # Print patch summary
        for p in self.patch_history:
            print(f"  {p['action']} | {p['address']} | {p['value']} | {p['description']}")


def load_json(path: str, default=None) -> dict:
    if path and os.path.exists(path):
        with open(path) as f:
            return json.load(f)
    return default if default is not None else {}


def main():
    parser = argparse.ArgumentParser(
        description="ReAct Debugger — Automated reasoning-based patch loop"
    )
    parser.add_argument("--pipe", default=r"\\.\pipe\cybergrime_live",
                        help="Named pipe path")
    parser.add_argument("--constraints", default="cybergrime/constraint_map.json")
    parser.add_argument("--golden", default="cybergrime/golden_state.json")
    parser.add_argument("--max-attempts", type=int, default=5,
                        help="Maximum patch attempts before giving up")
    parser.add_argument("--output", default="react_debug_log.json")
    args = parser.parse_args()

    constraints = load_json(args.constraints)
    if not constraints:
        print(f"ERROR: Constraint map not found: {args.constraints}")
        sys.exit(1)

    golden = load_json(args.golden, default={
        "tree_placement": {"mode": "Option A", "addr": "0x80100000"}
    })

    debugger = ReActDebugger(
        pipe_name=args.pipe,
        constraint_map=constraints,
        golden_state=golden,
        max_attempts=args.max_attempts,
        output_path=args.output,
    )

    debugger.run()


if __name__ == "__main__":
    main()
