# Verify the FMV patch in the built disc image
$binPath = 'c:\LuxAura\VoidWalkers_Project\DQLOSTTRANSLATION\cybergrime\dq4_reverse_v97_fmv.bin'
$fs = [System.IO.File]::OpenRead($binPath)

# EXE is at LBA 24, file offset 0x92936
# EXE header is 0x800 bytes, so code offset = 0x92936 - 0x800 = 0x92136
# Sector within EXE: 0x92136 / 2048 = 292 (0x124), remainder = 0x136 (310)
# Disc LBA: 24 + 292 = 316
# Raw offset: 316 * 2352 + 24 + 310

$exeLBA = 24
$exeFileOff = 0x92936
$codeOff = $exeFileOff - 0x800
$sectorInExe = [Math]::Floor($codeOff / 2048)
$offsetInSector = $codeOff % 2048
$discLBA = $exeLBA + $sectorInExe
$rawOffset = $discLBA * 2352 + 24 + $offsetInSector

Write-Host "EXE file offset: 0x$($exeFileOff.ToString('X'))"
Write-Host "Code offset: 0x$($codeOff.ToString('X'))"
Write-Host "Sector within EXE: $sectorInExe (0x$($sectorInExe.ToString('X')))"
Write-Host "Offset in sector: $offsetInSector (0x$($offsetInSector.ToString('X')))"
Write-Host "Disc LBA: $discLBA"
Write-Host "Raw BIN offset: $rawOffset (0x$($rawOffset.ToString('X')))"

# Read 16 bytes at that offset
$fs.Seek($rawOffset, 'Begin') | Out-Null
$buf = New-Object byte[] 16
$fs.Read($buf, 0, 16) | Out-Null

Write-Host ""
Write-Host "Bytes at EXE offset 0x92936 in disc image:"
$hex = ''
for ($i = 0; $i -lt 16; $i++) { $hex += '{0:X2} ' -f $buf[$i] }
Write-Host "  $hex"

if ($buf[0] -eq 0x23 -and $buf[1] -eq 0x31 -and $buf[2] -eq 0x15) {
    Write-Host "  PATCHED: 23 31 15 (DQ4 FMV MSF) - patch took effect!"
} elseif ($buf[0] -eq 0x32 -and $buf[1] -eq 0x34 -and $buf[2] -eq 0x71) {
    Write-Host "  UNPATCHED: 32 34 71 (DW7 FMV MSF) - patch did NOT take effect!"
} else {
    Write-Host "  UNKNOWN: bytes don't match either expected pattern"
}

# Also check the original EXE file
$exePath = 'c:\LuxAura\VoidWalkers_Project\DQLOSTTRANSLATION\translation\SLUSP012.06'
$exeBytes = [System.IO.File]::ReadAllBytes($exePath)
Write-Host ""
Write-Host "Bytes at EXE offset 0x92936 in original EXE file:"
$hex2 = ''
for ($i = 0; $i -lt 16; $i++) { $hex2 += '{0:X2} ' -f $exeBytes[$exeFileOff + $i] }
Write-Host "  $hex2"

# Let me also read a wider range to see the full context
Write-Host ""
Write-Host "=== Full hex dump of EXE offset 0x92920-0x92950 in disc image ==="
for ($off = 0x92920 - 0x800; $off -lt 0x92950 - 0x800; $off += 16) {
    $sectorInExe2 = [Math]::Floor($off / 2048)
    $offsetInSector2 = $off % 2048
    $discLBA2 = $exeLBA + $sectorInExe2
    $rawOffset2 = $discLBA2 * 2352 + 24 + $offsetInSector2
    $fs.Seek($rawOffset2, 'Begin') | Out-Null
    $line = New-Object byte[] 16
    $fs.Read($line, 0, 16) | Out-Null
    $hex3 = ''
    for ($i = 0; $i -lt 16; $i++) { $hex3 += '{0:X2} ' -f $line[$i] }
    $exeOff = $off + 0x800
    Write-Host ("  EXE 0x{0:X5}: {1}" -f $exeOff, $hex3)
}

$fs.Close()
