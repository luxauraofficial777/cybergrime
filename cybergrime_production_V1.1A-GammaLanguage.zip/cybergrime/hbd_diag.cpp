// HBD Format Diagnostic — dumps block headers from both DQ4 and DW7 HBDs
// Build: cl /EHsc /O2 hbd_diag.cpp /Fe:hbd_diag.exe
#include <cstdio>
#include <cstdint>
#include <cstring>
#include <vector>
#include <fstream>

#pragma pack(push,1)
struct BlockHeader{
    uint32_t end_marker;
    uint32_t block_id;
    uint32_t hts;
    uint32_t reserved;
    uint32_t tree_end;
    uint32_t text_end;
    uint32_t unknown;
};
#pragma pack(pop)

std::vector<uint8_t> read_file(const char* path){
    std::ifstream f(path,std::ios::binary|std::ios::ate);
    if(!f.is_open()){printf("ERROR: cannot open %s\n",path);return{};}
    auto sz=f.tellg();
    f.seekg(0);
    std::vector<uint8_t> buf(sz);
    f.read((char*)buf.data(),sz);
    return buf;
}

void dump_blocks(const char* label,const uint8_t* data,size_t size,int max_blocks){
    printf("\n=== %s ===\n",label);
    printf("  Total size: %zu bytes\n\n");
    
    uint32_t offset=0;
    int block_count=0;
    int blocks_with_tree=0;
    int blocks_without_tree=0;
    
    while(offset+28<=size && block_count<max_blocks){
        BlockHeader hdr;
        memcpy(&hdr,data+offset,28);
        
        if(hdr.end_marker<24 || offset+hdr.end_marker>size){
            printf("  [BLOCK %d] offset=0x%X — INVALID end_marker=0x%08X, stopping\n",
                block_count,offset,hdr.end_marker);
            break;
        }
        
        bool has_tree=(hdr.tree_end!=0 && hdr.text_end!=0);
        if(has_tree) blocks_with_tree++;
        else blocks_without_tree++;
        
        // Dump first 16 bytes of data area (after header)
        uint32_t data_start=hdr.hts;
        printf("  [BLOCK %3d] off=0x%06X end=0x%04X id=0x%04X hts=%4d treeEnd=0x%04X textEnd=0x%04X unk=0x%08X %s\n",
            block_count,offset,hdr.end_marker,hdr.block_id,hdr.hts,
            hdr.tree_end,hdr.text_end,hdr.unknown,
            has_tree?"PER-BLOCK-TREE":"GLOBAL-TREE");
        
        // Dump first 32 bytes of data area
        if(offset+data_start+32<=size){
            printf("    data[0..31]: ");
            for(int i=0;i<32 && offset+data_start+i<size;i++)
                printf("%02X ",data[offset+data_start+i]);
            printf("\n");
        }
        
        // For DW7 blocks with gap, dump gap content (bytes 28..hts)
        if(hdr.hts>28 && hdr.hts<2000){
            printf("    gap[28..%d]: ",hdr.hts);
            for(uint32_t i=28;i<hdr.hts && i<28+32 && offset+i<size;i++)
                printf("%02X ",data[offset+i]);
            if(hdr.hts>28+32) printf("...");
            printf("\n");
        }
        
        // Check for sub-block entries in data area
        // Look for 32-bit words where lower16 is 32,39,40,42,46 (DQ4 types)
        if(!has_tree){
            uint32_t scan_end=hdr.end_marker;
            if(scan_end>200) scan_end=200; // limit scan
            for(uint32_t i=data_start;i+4<=scan_end && offset+i+4<=size;i+=4){
                uint32_t word;
                memcpy(&word,data+offset+i,4);
                uint16_t lo=word&0xFFFF;
                uint16_t hi=(word>>16)&0xFFFF;
                if(lo==32||lo==39||lo==40||lo==42||lo==46){
                    printf("    ** DQ4-type word at data+0x%X: 0x%08X (lo=0x%04X hi=0x%04X) **\n",
                        i,word,lo,hi);
                }
            }
        }
        
        // Move to next block
        // Block total size = end + 8 (at_end + dp_count) + dp_count*8
        uint32_t next_off=offset+hdr.end_marker;
        if(offset+hdr.end_marker+8<=size){
            uint32_t at_end,dp_count;
            memcpy(&at_end,data+offset+hdr.end_marker,4);
            memcpy(&dp_count,data+offset+hdr.end_marker+4,4);
            if(dp_count<10000){
                next_off=offset+hdr.end_marker+8+dp_count*8;
            }
        }
        
        if(next_off<=offset) break;
        offset=next_off;
        block_count++;
    }
    
    printf("\n  Summary: %d blocks (%d with per-block tree, %d global tree)\n",
        block_count,blocks_with_tree,blocks_without_tree);
}

int main(int argc,char** argv){
    // DQ4 HBD: from dq4_heart_v17.bin, sector 362, 2352-byte sectors, data at offset 24
    // DW7 HBD: from DW7D1.bin, sector 354
    
    const char* dq4_disc="..\\dq4_heart_v17.bin";
    const char* dw7_disc="..\\DW7D1\\DW7D1.bin";
    
    // Read DQ4 HBD
    printf("Reading DQ4 HBD from %s...\n",dq4_disc);
    {
        std::ifstream f(dq4_disc,std::ios::binary|std::ios::ate);
        if(!f.is_open()){printf("ERROR: cannot open %s\n",dq4_disc);return 1;}
        auto sz=f.tellg();
        // Sector 362, 2352-byte sectors, user data at offset 24
        uint32_t hbd_start=362*2352+24;
        uint32_t hbd_size=319436800;
        if(hbd_start+hbd_size>(uint64_t)sz) hbd_size=(uint32_t)sz-hbd_start;
        f.seekg(hbd_start);
        std::vector<uint8_t> hbd(hbd_size);
        f.read((char*)hbd.data(),hbd_size);
        
        // Dump first 64 bytes raw
        printf("  First 64 bytes of HBD:\n  ");
        for(int i=0;i<64&&i<(int)hbd.size();i++){
            printf("%02X ",hbd[i]);
            if((i+1)%16==0)printf("\n  ");
        }
        printf("\n");
        
        // HBD has a 16-byte file header, then blocks start at offset 16
        // But let's also try offset 0 and 8 to be sure
        for(int skip=0;skip<=24;skip+=8){
            if(skip+28>hbd.size())continue;
            uint32_t end;
            memcpy(&end,hbd.data()+skip,4);
            printf("  skip=%d: end_marker=0x%08X\n",skip,end);
        }
        
        // Try starting at offset 16 (after HBD file header)
        dump_blocks("DQ4 HBD (offset 16)",hbd.data()+16,hbd.size()-16,50);
    }
    
    // Read DW7 HBD
    printf("\nReading DW7 HBD from %s...\n",dw7_disc);
    {
        std::ifstream f(dw7_disc,std::ios::binary|std::ios::ate);
        if(!f.is_open()){printf("ERROR: cannot open %s\n",dw7_disc);return 1;}
        auto sz=f.tellg();
        // Sector 354, 2352-byte sectors, user data at offset 24
        uint32_t hbd_start=354*2352+24;
        uint32_t hbd_size=618563584;
        if(hbd_start+hbd_size>(uint64_t)sz) hbd_size=(uint32_t)sz-hbd_start;
        f.seekg(hbd_start);
        std::vector<uint8_t> hbd(hbd_size);
        f.read((char*)hbd.data(),hbd_size);
        
        // Dump first 64 bytes raw
        printf("  First 64 bytes of HBD:\n  ");
        for(int i=0;i<64&&i<(int)hbd.size();i++){
            printf("%02X ",hbd[i]);
            if((i+1)%16==0)printf("\n  ");
        }
        printf("\n");
        
        for(int skip=0;skip<=24;skip+=8){
            if(skip+28>hbd.size())continue;
            uint32_t end;
            memcpy(&end,hbd.data()+skip,4);
            printf("  skip=%d: end_marker=0x%08X\n",skip,end);
        }
        
        dump_blocks("DW7 HBD (offset 16)",hbd.data()+16,hbd.size()-16,50);
    }
    
    return 0;
}
