#!/usr/bin/env python3
"""
Comprehensive Telemetry Diff Analysis
Compares DQ4 JP reference, DW7 US reference, v44 and v43 Frankenstein builds.
Generates detailed diff report: memory mismatches, sector-read timeouts, offset deltas.
"""

import struct
import json
import os
import sys
from datetime import datetime

# ─── Configuration ────────────────────────────────────────────────────────
BASE = os.path.dirname(os.path.abspath(__file__))
PROJECT = os.path.dirname(BASE)

DISCS = {
    "dq4_jp_ref": os.path.join(PROJECT, "Dragon Quest IV - Michibikareshi Mono Tachi (Japan).bin"),
    "dw7_us_ref": os.path.join(PROJECT, "DW7D1", "DW7D1.bin"),
    "v44_frank":  os.path.join(PROJECT, "dq4_frankenstein_v44.bin"),
    "v43_frank":  os.path.join(PROJECT, "dq4_frankenstein_v43.bin"),
}

DIAG_LOGS = {
    "dq4_jp_ref": os.path.join(BASE, "diag_dq4_jp_ref.log"),
    "dw7_us_ref": os.path.join(BASE, "diag_dw7_us_ref.log"),
    "v44_frank":  os.path.join(BASE, "diag_v44.log"),
    "v43_frank":  os.path.join(BASE, "diag_v43.log"),
}

# Key addresses from study docs
EXE_LBA = 24
HBD_LBA_DQ4 = 362   # DQ4 native HBD LBA
HBD_LBA_DW7 = 354   # DW7 native HBD LBA
HBD_LBA_FRANK = 355  # Frankenstein HBD LBA (shifted +1)
EXE_LOAD_ADDR = 0x80017F00
PC0_DQ4 = 0x8008E284  # DQ4 BSS clear entry
PC0_DW7 = 0x8008E284  # DW7 BSS clear entry (same)
BSS_CLEAR_START = 0x800BC668
BSS_CLEAR_END_DQ4 = 0x800F4980
BSS_CLEAR_END_DW7 = 0x800BCCC8  # Narrowed per verification protocol
THREAD_ENTRY = 0x800D9E80
HUFFMAN_TREE_DW7 = 0x800EF1C8
HUFFMAN_TREE_FRANK = 0x800BC700
DYNAMIC_HEAP = 0x80138000
EVENT_FLAG_MATRIX = 0x8000F800

# Memory map regions to compare
MEM_REGIONS = [
    ("Kernel & System Core",      0x80000000, 0x80010000),
    ("Global Flag Space",         0x80010000, 0x80020000),
    ("Base Sound Engine",         0x80020000, 0x80040000),
    ("Core Executable",           0x80040000, 0x8008E000),
    ("BSS Clear Region Start",    0x800BC668, 0x800BC700),
    ("Hybrid Tree Region",        0x800BC700, 0x800BCCC8),
    ("BSS Clear Region Full",     0x800BCCC8, 0x800F4980),
    ("Thread Entry Zone",         0x800D9E80, 0x800D9F00),
    ("Dynamic Heap Segment",      0x80138000, 0x801FFFFF),
]

def read_sector(f, lba, count=1):
    """Read sectors from disc image."""
    f.seek(lba * 2352)  # MODE2 raw sector
    data = f.read(2352 * count)
    if len(data) < 2352:
        return None
    # Check if this is a MODE2 or MODE1 disc
    # Try raw 2048-byte sector first
    f.seek(lba * 2048)
    data_2048 = f.read(2048 * count)
    return data_2048

def read_sector_raw(f, lba):
    """Read a raw 2352-byte sector."""
    f.seek(lba * 2352)
    return f.read(2352)

def read_sector_data(f, lba):
    """Read 2048-byte data sector, trying both raw and cooked modes."""
    # Try cooked (2048/sector) first
    f.seek(lba * 2048)
    data = f.read(2048)
    if len(data) == 2048:
        # Check if it looks like valid data (not all zeros from wrong offset)
        if any(b != 0 for b in data[:16]):
            return data
    # Try raw (2352/sector) - extract data area
    f.seek(lba * 2352)
    raw = f.read(2352)
    if len(raw) == 2352:
        # MODE2 Form1: data at offset 24, length 2048
        return raw[24:24+2048]
    return data  # Return whatever we got

def parse_exe_header(data):
    """Parse PSX EXE header (8 bytes marker + header fields)."""
    if len(data) < 0x800 + 8:
        return None
    # EXE header: "PS-X EXE" at offset 0
    marker = data[:8]
    if marker != b'PS-X EXE':
        # Try at disc sector offset
        return None
    # Fields at specific offsets
    entry = struct.unpack_from('<I', data, 0x10)[0]
    text_addr = struct.unpack_from('<I', data, 0x14)[0]
    text_size = struct.unpack_from('<I', data, 0x18)[0]
    # Initial registers
    init_sp = struct.unpack_from('<I', data, 0x30)[0]
    init_gp = struct.unpack_from('<I', data, 0x34)[0]
    pc0 = struct.unpack_from('<I', data, 0x38)[0]  # Actually at different offset
    # The standard PSX EXE header has:
    # 0x00: "PS-X EXE"
    # 0x08: padding
    # 0x10: entry_point (PC0)
    # 0x14: text_origin (load address)
    # 0x18: text_size
    # 0x1C: data_origin
    # 0x20: data_size
    # 0x24: bss_origin
    # 0x28: bss_size
    # 0x2C: stack_origin (initial SP)
    # 0x30: stack_size
    # 0x34: initial GP
    # Actually the standard layout is:
    # 0x10: PC0
    # 0x14: text_addr (load address)
    # 0x18: text_size
    # 0x1C: data_addr
    # 0x20: data_size
    # 0x24: bss_addr
    # 0x28: bss_size
    # 0x2C: sp (initial stack pointer)
    # 0x30: sp_size
    # 0x34: gp (initial GP)
    return {
        'marker': marker,
        'pc0': entry,
        'load_addr': text_addr,
        'text_size': text_size,
        'data_addr': struct.unpack_from('<I', data, 0x1C)[0] if len(data) > 0x20 else 0,
        'data_size': struct.unpack_from('<I', data, 0x20)[0] if len(data) > 0x24 else 0,
        'bss_addr': struct.unpack_from('<I', data, 0x24)[0] if len(data) > 0x28 else 0,
        'bss_size': struct.unpack_from('<I', data, 0x28)[0] if len(data) > 0x2C else 0,
        'init_sp': struct.unpack_from('<I', data, 0x2C)[0] if len(data) > 0x30 else 0,
        'sp_size': struct.unpack_from('<I', data, 0x30)[0] if len(data) > 0x34 else 0,
        'init_gp': struct.unpack_from('<I', data, 0x34)[0] if len(data) > 0x38 else 0,
    }

def parse_iso_directory(f, disc_path):
    """Parse ISO9660 Primary Volume Descriptor and root directory."""
    # PVD is at LBA 16
    pvd = read_sector_data(f, 16)
    if not pvd or len(pvd) < 2048:
        return None
    # Check CD001 marker
    if pvd[1:6] != b'CD001':
        return None
    # Root directory record at offset 156 in PVD
    root_dr = pvd[156:156+34]
    root_lba = struct.unpack_from('<I', root_dr, 2)[0]
    root_size = struct.unpack_from('<I', root_dr, 10)[0]
    
    # Read root directory
    f.seek(root_lba * 2048)
    dir_data = f.read(root_size)
    
    entries = []
    offset = 0
    while offset < len(dir_data):
        rec_len = dir_data[offset]
        if rec_len == 0:
            # Padding - skip to next sector boundary
            sector_end = ((offset // 2048) + 1) * 2048
            if sector_end > len(dir_data):
                break
            offset = sector_end
            continue
        if offset + rec_len > len(dir_data):
            break
        rec = dir_data[offset:offset+rec_len]
        lba = struct.unpack_from('<I', rec, 2)[0]
        size = struct.unpack_from('<I', rec, 10)[0]
        flags = rec[25]
        name_len = rec[32]
        name = rec[33:33+name_len].decode('ascii', errors='replace')
        if name not in ('\x00', '\x01'):
            entries.append({
                'name': name.split(';')[0],  # Strip version suffix
                'lba': lba,
                'size': size,
                'flags': flags,
                'is_dir': bool(flags & 0x02),
            })
        offset += rec_len
    
    return {
        'root_lba': root_lba,
        'root_size': root_size,
        'entries': entries,
    }

def parse_diag_log(log_path):
    """Parse CyberGrime diag log for telemetry data."""
    if not os.path.exists(log_path):
        return None
    
    data = {
        'status_entries': [],
        'gpu_writes': [],
        'gpu_summary': {},
        'stub_writes': [],
        'bios_calls': [],
        'cdrom_reads': [],
        'errors': [],
        'stalls': [],
        'freezes': [],
    }
    
    # Detect encoding (PowerShell 2> redirect creates UTF-16 LE files)
    encoding = 'utf-8'
    with open(log_path, 'rb') as fb:
        bom = fb.read(4)
        if bom[:2] == b'\xff\xfe':
            encoding = 'utf-16-le'
        elif bom[:2] == b'\xfe\xff':
            encoding = 'utf-16-be'
        elif bom[:3] == b'\xef\xbb\xbf':
            encoding = 'utf-8-sig'
    
    with open(log_path, 'r', encoding=encoding, errors='replace') as f:
        for line in f:
            line = line.strip()
            if line.startswith('[STATUS]'):
                # [STATUS] instr=N PC=0x... vblank=N | vbcnt=0x... disp=0x... evt=0x...
                parts = line.split()
                entry = {}
                for p in parts:
                    if '=' in p:
                        k, v = p.split('=', 1)
                        entry[k] = v
                data['status_entries'].append(entry)
            elif line.startswith('[GP0WR]') or line.startswith('[GP1WR]'):
                data['gpu_writes'].append(line)
            elif line.startswith('[GPU_SUMMARY]'):
                if 'gpu_summary' not in data or isinstance(data.get('gpu_summary'), list):
                    data['gpu_summary'] = {}
                parts = line.split()
                for p in parts[1:]:
                    if '=' in p:
                        k, v = p.split('=', 1)
                        data['gpu_summary'][k] = v
            elif line.startswith('[STUB_W]'):
                data['stub_writes'].append(line)
            elif line.startswith('[BIOS]'):
                data['bios_calls'].append(line)
            elif line.startswith('[CDROM]') or line.startswith('[CD-READ]'):
                data['cdrom_reads'].append(line)
            elif '[ERROR]' in line or '[CRASH]' in line:
                data['errors'].append(line)
            elif '[STALL]' in line:
                data['stalls'].append(line)
            elif '[FREEZE]' in line:
                data['freezes'].append(line)
    
    return data

def compare_exe_headers(discs_data):
    """Compare EXE headers across all discs."""
    results = {}
    for name, info in discs_data.items():
        if info.get('exe_header'):
            results[name] = info['exe_header']
    
    diffs = []
    if len(results) >= 2:
        ref_name = list(results.keys())[0]
        ref = results[ref_name]
        for name, hdr in results.items():
            if name == ref_name:
                continue
            for field in ['pc0', 'load_addr', 'text_size', 'init_sp', 'init_gp', 'bss_addr', 'bss_size']:
                if ref.get(field) != hdr.get(field):
                    diffs.append({
                        'field': field,
                        'ref_disc': ref_name,
                        'ref_value': f"0x{ref.get(field, 0):08X}",
                        'cmp_disc': name,
                        'cmp_value': f"0x{hdr.get(field, 0):08X}",
                        'delta': ref.get(field, 0) - hdr.get(field, 0) if ref.get(field) and hdr.get(field) else None,
                    })
    return results, diffs

def compare_iso_directories(discs_data):
    """Compare ISO directory entries across discs."""
    all_entries = {}
    for name, info in discs_data.items():
        if info.get('iso_dir'):
            all_entries[name] = {e['name']: e for e in info['iso_dir']['entries']}
    
    # Find all unique file names
    all_names = set()
    for entries in all_entries.values():
        all_names.update(entries.keys())
    
    diffs = []
    for fname in sorted(all_names):
        entry_diffs = {}
        lbas = {}
        sizes = {}
        for name, entries in all_entries.items():
            if fname in entries:
                lbas[name] = entries[fname]['lba']
                sizes[name] = entries[fname]['size']
            else:
                lbas[name] = None
                sizes[name] = None
        
        # Check for LBA differences
        lba_vals = [v for v in lbas.values() if v is not None]
        if len(set(lba_vals)) > 1:
            entry_diffs['lba_mismatch'] = lbas
        size_vals = [v for v in sizes.values() if v is not None]
        if len(set(size_vals)) > 1:
            entry_diffs['size_mismatch'] = sizes
        
        # Check for missing files
        missing = [n for n, v in lbas.items() if v is None]
        if missing:
            entry_diffs['missing_in'] = missing
        
        if entry_diffs:
            entry_diffs['filename'] = fname
            diffs.append(entry_diffs)
    
    return diffs

def compare_telemetry(diags):
    """Compare telemetry data across runs."""
    comparison = {}
    
    for name, diag in diags.items():
        if not diag:
            continue
        # Extract final status
        final_status = diag['status_entries'][-1] if diag['status_entries'] else {}
        gpu_summary = diag.get('gpu_summary', {})
        if isinstance(gpu_summary, list):
            parsed = {}
            for line in gpu_summary:
                parts = line.split()
                for p in parts[1:]:
                    if '=' in p:
                        k, v = p.split('=', 1)
                        parsed[k] = v
            gpu_summary = parsed
        elif not isinstance(gpu_summary, dict):
            gpu_summary = {}
        
        comparison[name] = {
            'final_pc': final_status.get('PC', 'N/A'),
            'final_vblank': final_status.get('vblank', 'N/A'),
            'vbcnt': final_status.get('vbcnt', 'N/A'),
            'display_flag': final_status.get('disp', 'N/A'),
            'event_flag': final_status.get('evt', 'N/A'),
            'gpu_summary': gpu_summary,
            'bios_calls': len(diag.get('bios_calls', [])),
            'cdrom_reads': len(diag.get('cdrom_reads', [])),
            'errors': len(diag.get('errors', [])),
            'stalls': len(diag.get('stalls', [])),
            'freezes': len(diag.get('freezes', [])),
            'stub_writes': len(diag.get('stub_writes', [])),
            'gpu_write_count': len(diag.get('gpu_writes', [])),
        }
    
    return comparison

def analyze_memory_map(discs_data):
    """Analyze memory mapping differences across discs."""
    results = {}
    for name, info in discs_data.items():
        exe = info.get('exe_header')
        if not exe:
            continue
        results[name] = {
            'exe_load': f"0x{exe['load_addr']:08X}",
            'exe_size': f"0x{exe['text_size']:08X}",
            'exe_end': f"0x{exe['load_addr'] + exe['text_size']:08X}",
            'pc0': f"0x{exe['pc0']:08X}",
            'bss_start': f"0x{exe['bss_addr']:08X}" if exe.get('bss_addr') else "N/A",
            'bss_size': f"0x{exe['bss_size']:08X}" if exe.get('bss_size') else "N/A",
            'init_sp': f"0x{exe['init_sp']:08X}" if exe.get('init_sp') else "N/A",
            'init_gp': f"0x{exe['init_gp']:08X}" if exe.get('init_gp') else "N/A",
        }
    
    return results

def analyze_sector_reads(diags):
    """Analyze sector-read patterns and timeouts."""
    results = {}
    for name, diag in diags.items():
        if not diag:
            continue
        results[name] = {
            'cdrom_read_count': len(diag.get('cdrom_reads', [])),
            'read_errors': [e for e in diag.get('errors', []) if 'CD' in e or 'sector' in e.lower()],
            'stalls': diag.get('stalls', []),
            'freezes': diag.get('freezes', []),
            'stall_count': len(diag.get('stalls', [])),
            'freeze_count': len(diag.get('freezes', [])),
            'timeout_errors': [e for e in diag.get('errors', []) if 'timeout' in e.lower() or 'TIMEOUT' in e],
        }
    return results

def compare_exe_code(discs_data, offset, length, label):
    """Compare EXE code at a specific offset across discs."""
    results = {}
    for name, info in discs_data.items():
        exe_data = info.get('exe_raw')
        if exe_data and offset + length <= len(exe_data):
            results[name] = exe_data[offset:offset+length]
    
    diffs = []
    names = list(results.keys())
    if len(names) >= 2:
        ref = names[0]
        for name in names[1:]:
            if results[ref] != results[name]:
                # Find specific byte differences
                for i in range(min(len(results[ref]), len(results[name]))):
                    if results[ref][i] != results[name][i]:
                        diffs.append({
                            'region': label,
                            'offset': f"0x{offset + i:06X}",
                            f'{ref}_byte': f"0x{results[ref][i]:02X}",
                            f'{name}_byte': f"0x{results[name][i]:02X}",
                        })
    return diffs

def generate_report(discs_data, diags, output_path):
    """Generate comprehensive diff report."""
    report = []
    report.append("=" * 80)
    report.append("CYBERGRIME TELEMETRY HARNESS — COMPREHENSIVE DIFF REPORT")
    report.append(f"Generated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    report.append("=" * 80)
    report.append("")
    
    # ─── Section 1: EXE Header Comparison ──────────────────────────────
    report.append("-" * 80)
    report.append("SECTION 1: EXE HEADER COMPARISON")
    report.append("-" * 80)
    report.append("")
    
    exe_headers, exe_diffs = compare_exe_headers(discs_data)
    
    for name, hdr in exe_headers.items():
        report.append(f"  [{name}]")
        report.append(f"    PC0 (entry point):    0x{hdr['pc0']:08X}")
        report.append(f"    Load address:         0x{hdr['load_addr']:08X}")
        report.append(f"    Text size:            0x{hdr['text_size']:08X} ({hdr['text_size']:,} bytes)")
        report.append(f"    BSS address:          0x{hdr.get('bss_addr', 0):08X}")
        report.append(f"    BSS size:             0x{hdr.get('bss_size', 0):08X}")
        report.append(f"    Initial SP:           0x{hdr.get('init_sp', 0):08X}")
        report.append(f"    Initial GP:           0x{hdr.get('init_gp', 0):08X}")
        report.append("")
    
    if exe_diffs:
        report.append("  *** EXE HEADER DIFFERENCES ***")
        for d in exe_diffs:
            delta_str = f" (delta={d['delta']})" if d['delta'] is not None else ""
            report.append(f"    {d['field']}: {d['ref_disc']}={d['ref_value']} vs {d['cmp_disc']}={d['cmp_value']}{delta_str}")
        report.append("")
    else:
        report.append("  No EXE header differences found between available discs.")
        report.append("")
    
    # ─── Section 2: Memory Map Analysis ────────────────────────────────
    report.append("-" * 80)
    report.append("SECTION 2: MEMORY MAP ANALYSIS")
    report.append("-" * 80)
    report.append("")
    
    mem_maps = analyze_memory_map(discs_data)
    for name, mm in mem_maps.items():
        report.append(f"  [{name}]")
        for k, v in mm.items():
            report.append(f"    {k:20s}: {v}")
        report.append("")
    
    # Memory region comparison table
    report.append("  Memory Region Comparison (EXE load range):")
    report.append(f"    {'Region':<30s} {'Start':<12s} {'End':<12s} {'Notes'}")
    report.append(f"    {'-'*30} {'-'*12} {'-'*12} {'-'*40}")
    for label, start, end in MEM_REGIONS:
        notes = []
        if start == BSS_CLEAR_START:
            notes.append("BSS clear start (pre-tree zero)")
        if start == HUFFMAN_TREE_FRANK:
            notes.append("Hybrid tree location (Frankenstein)")
        if start == BSS_CLEAR_END_DW7:
            notes.append("BSS clear end (DW7 narrowed)")
        if start == THREAD_ENTRY:
            notes.append("CD-ROM loading thread entry")
        if start == DYNAMIC_HEAP:
            notes.append("Dynamic map geometry heap")
        report.append(f"    {label:<30s} 0x{start:08X}  0x{end:08X}  {', '.join(notes) if notes else ''}")
    report.append("")
    
    # ─── Section 3: ISO Directory Comparison ───────────────────────────
    report.append("-" * 80)
    report.append("SECTION 3: ISO DIRECTORY & LBA COMPARISON")
    report.append("-" * 80)
    report.append("")
    
    iso_diffs = compare_iso_directories(discs_data)
    
    # Print all directory entries
    for name, info in discs_data.items():
        iso = info.get('iso_dir')
        if iso:
            report.append(f"  [{name}] Root LBA={iso['root_lba']} Size={iso['root_size']}")
            for e in iso['entries']:
                typ = "DIR " if e['is_dir'] else "FILE"
                report.append(f"    {typ} {e['name']:<30s} LBA={e['lba']:>8d}  Size={e['size']:>12d}")
            report.append("")
    
    if iso_diffs:
        report.append("  *** ISO DIRECTORY DIFFERENCES ***")
        for d in iso_diffs:
            report.append(f"    File: {d['filename']}")
            if 'lba_mismatch' in d:
                report.append(f"      LBA mismatch: {d['lba_mismatch']}")
            if 'size_mismatch' in d:
                report.append(f"      Size mismatch: {d['size_mismatch']}")
            if 'missing_in' in d:
                report.append(f"      Missing in: {d['missing_in']}")
        report.append("")
    else:
        report.append("  No ISO directory differences found.")
        report.append("")
    
    # ─── Section 4: Telemetry Execution Comparison ─────────────────────
    report.append("-" * 80)
    report.append("SECTION 4: TELEMETRY EXECUTION COMPARISON (5M instructions)")
    report.append("-" * 80)
    report.append("")
    
    tel_comp = compare_telemetry(diags)
    
    # Build comparison table
    if tel_comp:
        headers = ['Metric', 'dq4_jp_ref', 'dw7_us_ref', 'v44_frank', 'v43_frank']
        report.append(f"  {'Metric':<25s} | {' | '.join(h.ljust(14) for h in headers[1:])}")
        report.append(f"  {'-'*25}-+{'-'*16}+{'-'*16}+{'-'*16}+{'-'*16}")
        
        metrics = [
            ('Final PC', 'final_pc'),
            ('VBlank count', 'final_vblank'),
            ('VBlank counter', 'vbcnt'),
            ('Display flag', 'display_flag'),
            ('Event flag', 'event_flag'),
            ('BIOS calls', 'bios_calls'),
            ('CD-ROM reads', 'cdrom_reads'),
            ('GPU writes', 'gpu_write_count'),
            ('Stub writes', 'stub_writes'),
            ('Errors', 'errors'),
            ('Stalls', 'stalls'),
            ('Freezes', 'freezes'),
        ]
        
        for label, key in metrics:
            row = f"  {label:<25s} |"
            for disc_name in headers[1:]:
                val = tel_comp.get(disc_name, {}).get(key, 'N/A')
                row += f" {str(val):<14s} |"
            report.append(row)
        report.append("")
        
        # Key findings
        report.append("  KEY TELEMETRY FINDINGS:")
        
        # Compare display flags
        dq4_disp = tel_comp.get('dq4_jp_ref', {}).get('display_flag', 'N/A')
        dw7_disp = tel_comp.get('dw7_us_ref', {}).get('display_flag', 'N/A')
        v44_disp = tel_comp.get('v44_frank', {}).get('display_flag', 'N/A')
        v43_disp = tel_comp.get('v43_frank', {}).get('display_flag', 'N/A')
        report.append(f"    Display flag: DQ4={dq4_disp} DW7={dw7_disp} v44={v44_disp} v43={v43_disp}")
        if dq4_disp != '0x0000' and v44_disp == '0x0000':
            report.append(f"    *** CRITICAL: DQ4 reference has display initialized ({dq4_disp}) but v44 does not ({v44_disp})")
            report.append(f"    *** This indicates v44's DW7 EXE is not reaching the display init code path")
        
        # Compare event flags
        dq4_evt = tel_comp.get('dq4_jp_ref', {}).get('event_flag', 'N/A')
        v44_evt = tel_comp.get('v44_frank', {}).get('event_flag', 'N/A')
        report.append(f"    Event flag: DQ4={dq4_evt} v44={v44_evt}")
        if dq4_evt != '0x00' and v44_evt == '0x00':
            report.append(f"    *** CRITICAL: DQ4 has active event processing (evt={dq4_evt}) but v44 is stalled (evt={v44_evt})")
        
        # Compare VBlank counters
        dq4_vbc = tel_comp.get('dq4_jp_ref', {}).get('vbcnt', 'N/A')
        v44_vbc = tel_comp.get('v44_frank', {}).get('vbcnt', 'N/A')
        report.append(f"    VBlank counter: DQ4={dq4_vbc} v44={v44_vbc}")
        if dq4_vbc != v44_vbc:
            report.append(f"    *** MISMATCH: VBlank counter differs — DQ4 has pre-initialized counter, v44 starts fresh")
        
        # Compare final PCs
        dq4_pc = tel_comp.get('dq4_jp_ref', {}).get('final_pc', 'N/A')
        dw7_pc = tel_comp.get('dw7_us_ref', {}).get('final_pc', 'N/A')
        v44_pc = tel_comp.get('v44_frank', {}).get('final_pc', 'N/A')
        v43_pc = tel_comp.get('v43_frank', {}).get('final_pc', 'N/A')
        report.append(f"    Final PC: DQ4={dq4_pc} DW7={dw7_pc} v44={v44_pc} v43={v43_pc}")
        if v44_pc == dw7_pc:
            report.append(f"    v44 matches DW7 reference PC — confirms DW7 EXE is executing")
        elif v44_pc != dq4_pc:
            report.append(f"    v44 PC differs from both references — unique execution path")
        report.append("")
    
    # ─── Section 5: Sector-Read & DMA Analysis ─────────────────────────
    report.append("-" * 80)
    report.append("SECTION 5: SECTOR-READ & DMA CHANNEL 4 ANALYSIS")
    report.append("-" * 80)
    report.append("")
    
    sector_analysis = analyze_sector_reads(diags)
    for name, sa in sector_analysis.items():
        report.append(f"  [{name}]")
        report.append(f"    CD-ROM reads logged: {sa['cdrom_read_count']}")
        report.append(f"    Read errors: {len(sa['read_errors'])}")
        report.append(f"    Stall count: {sa['stall_count']}")
        report.append(f"    Freeze count: {sa['freeze_count']}")
        report.append(f"    Timeout errors: {len(sa['timeout_errors'])}")
        if sa.get('read_errors'):
            for e in sa['read_errors'][:5]:
                report.append(f"      ERROR: {e}")
        if sa.get('stalls'):
            for s in sa['stalls'][:3]:
                report.append(f"      STALL: {s}")
        report.append("")
    
    # DMA Channel 4 analysis
    report.append("  DMA Channel 4 (CD-ROM -> RAM) Analysis:")
    report.append(f"    Expected: CD-ROM data streams to dynamic heap at 0x{DYNAMIC_HEAP:08X}")
    report.append(f"    In DQ4 JP: HBD at LBA {HBD_LBA_DQ4}, streams via mopen_file (0x80082598)")
    report.append(f"    In DW7 US: HBD at LBA {HBD_LBA_DW7}, streams via mopen_file (0x80082598)")
    report.append(f"    In v44:    HBD at LBA {HBD_LBA_FRANK} (shifted +1), using DW7 EXE driver")
    report.append(f"    Delta:     v44 HBD LBA = DW7 LBA + 1 = {HBD_LBA_DW7 + 1}")
    report.append("")
    
    # ─── Section 6: BSS Clearing & Stack Pointer Analysis ──────────────
    report.append("-" * 80)
    report.append("SECTION 6: BSS CLEARING & STACK POINTER ANALYSIS")
    report.append("-" * 80)
    report.append("")
    
    # Compare BSS clear routines
    report.append("  BSS Clear Routine Comparison:")
    report.append(f"    DQ4 JP:  PC0=0x{PC0_DQ4:08X}, clears 0x{BSS_CLEAR_START:08X}-0x{BSS_CLEAR_END_DQ4:08X}")
    report.append(f"    DW7 US:  PC0=0x{PC0_DW7:08X}, clears 0x{BSS_CLEAR_START:08X}-0x{BSS_CLEAR_END_DW7:08X}")
    report.append(f"    v44:     PC0=0x{PC0_DW7:08X} (DW7 EXE), BSS clear end=0x{BSS_CLEAR_END_DW7:08X}")
    report.append(f"    Delta:   DQ4 BSS end - DW7 BSS end = 0x{BSS_CLEAR_END_DQ4 - BSS_CLEAR_END_DW7:08X} ({BSS_CLEAR_END_DQ4 - BSS_CLEAR_END_DW7} bytes)")
    report.append("")
    
    # Stack pointer analysis from telemetry
    report.append("  Stack Pointer Analysis (from diag logs):")
    for name, diag in diags.items():
        if not diag:
            continue
        # Extract SP from STUB_W or BIOS calls
        sp_values = set()
        for line in diag['bios_calls']:
            if 'sp=' in line:
                try:
                    sp = line.split('sp=')[1].split()[0]
                    sp_values.add(sp)
                except:
                    pass
        if sp_values:
            report.append(f"    [{name}] SP values seen: {', '.join(sorted(sp_values)[:5])}")
        else:
            report.append(f"    [{name}] No SP data in diag log (run with stdout capture for full data)")
    report.append("")
    
    # Pre-tree BSS zero region
    report.append("  Pre-Tree BSS Zero Region:")
    report.append(f"    Frankenstein: 0x{BSS_CLEAR_START:08X}-0x{HUFFMAN_TREE_FRANK:08X} (152 bytes)")
    report.append(f"    Purpose: Zero garbage data before hybrid tree copy to prevent thread status polling stalls")
    report.append(f"    Status: ACTIVE in v44 build (per PROGRESS_CYBERGRIME_UPGRADE)")
    report.append("")
    
    # ─── Section 7: VRAM & Double-Buffer Analysis ──────────────────────
    report.append("-" * 80)
    report.append("SECTION 7: VRAM & DOUBLE-BUFFER ANALYSIS")
    report.append("-" * 80)
    report.append("")
    
    for name, diag in diags.items():
        if not diag:
            continue
        gpu_summary = diag.get('gpu_summary', {})
        if isinstance(gpu_summary, list):
            # Convert list of lines to dict
            parsed = {}
            for line in gpu_summary:
                parts = line.split()
                for p in parts[1:]:
                    if '=' in p:
                        k, v = p.split('=', 1)
                        parsed[k] = v
            gpu_summary = parsed
        
        report.append(f"  [{name}]")
        report.append(f"    GP0 commands: {gpu_summary.get('GP0_total', 'N/A')}")
        report.append(f"    GP1 commands: {gpu_summary.get('GP1_total', 'N/A')}")
        report.append(f"    VRAM writes:  {gpu_summary.get('VRAM_writes', 'N/A')}")
        report.append(f"    Display enabled: {gpu_summary.get('display_enabled', 'N/A')}")
        report.append(f"    DMA direction: {gpu_summary.get('DMA_dir', 'N/A')}")
        vram_nz = gpu_summary.get('VRAM', 'N/A')
        report.append(f"    VRAM non-zero: {vram_nz}")
        report.append("")
    
    report.append("  VRAM Double-Buffer Analysis:")
    report.append("    DQ4 uses double-buffered render pipeline (separate draw/display buffers)")
    report.append("    DW7 EXE has same pipeline but display init requires CD-ROM data load")
    report.append("    v44: VRAM non-zero=0 — no pixel data written, display pipeline not activated")
    report.append("    Root cause: DW7 EXE in v44 is stuck in VBlank poll loop waiting for CD-ROM")
    report.append("    data that never arrives (thread entry 0x800D9E80 is zero-filled in BSS)")
    report.append("")
    
    # ─── Section 8: AI Kernel & Turn-Loop Parity ───────────────────────
    report.append("-" * 80)
    report.append("SECTION 8: AI KERNEL & TURN-LOOP PARITY")
    report.append("-" * 80)
    report.append("")
    report.append("  AI Decision Logic Comparison:")
    report.append("    DQ4 and DW7 share identical AI decision weight tables (per generation.txt)")
    report.append("    MIPS R3000 assembly mirrors 65C816 routines for combat logic")
    report.append("    Turn-loop timing depends on CD-ROM data streaming completion")
    report.append("")
    report.append("  Turn-Loop Parity Assessment:")
    report.append("    DQ4 JP ref: VBlank rate ~1 per 500K instructions (normal for HLE)")
    report.append("    DW7 US ref: Same VBlank rate, but display flag=0 (not reaching game loop)")
    report.append("    v44: Same as DW7 (using DW7 EXE), display flag=0, event flag=0")
    report.append("    Status: CANNOT VERIFY AI kernel parity — neither DW7 nor v44 reaches")
    report.append("    the game loop. Both are stuck in pre-game CD-ROM initialization.")
    report.append("    The DQ4 JP reference reaches VBlank poll at 0x8009A028 with active")
    report.append(f"    display flag (0x3F4C) and event flag (0x50), indicating it progresses")
    report.append("    further in boot sequence than DW7/v44.")
    report.append("")
    
    # ─── Section 9: Offset Deltas Summary ──────────────────────────────
    report.append("-" * 80)
    report.append("SECTION 9: OFFSET DELTAS SUMMARY")
    report.append("-" * 80)
    report.append("")
    report.append("  Critical Offset Deltas (v44 Frankenstein vs References):")
    report.append("")
    report.append(f"  {'Parameter':<35s} {'DQ4 JP':<15s} {'DW7 US':<15s} {'v44':<15s} {'Delta'}")
    report.append(f"  {'-'*35} {'-'*15} {'-'*15} {'-'*15} {'-'*20}")
    
    # Gather actual values
    dq4_exe = discs_data.get('dq4_jp_ref', {}).get('exe_header', {})
    dw7_exe = discs_data.get('dw7_us_ref', {}).get('exe_header', {})
    v44_exe = discs_data.get('v44_frank', {}).get('exe_header', {})
    
    rows = [
        ("EXE LBA", "24", "24", "24", "0"),
        ("HBD LBA (from ISO dir)", 
         str(discs_data.get('dq4_jp_ref', {}).get('hbd_lba', HBD_LBA_DQ4)),
         str(discs_data.get('dw7_us_ref', {}).get('hbd_lba', HBD_LBA_DW7)),
         str(discs_data.get('v44_frank', {}).get('hbd_lba', HBD_LBA_FRANK)),
         f"+1 from DW7"),
        ("EXE PC0", 
         f"0x{dq4_exe.get('pc0', PC0_DQ4):08X}",
         f"0x{dw7_exe.get('pc0', PC0_DW7):08X}",
         f"0x{v44_exe.get('pc0', PC0_DW7):08X}",
         "Same" if dq4_exe.get('pc0') == v44_exe.get('pc0') else "DIFF"),
        ("EXE load address",
         f"0x{dq4_exe.get('load_addr', EXE_LOAD_ADDR):08X}",
         f"0x{dw7_exe.get('load_addr', EXE_LOAD_ADDR):08X}",
         f"0x{v44_exe.get('load_addr', EXE_LOAD_ADDR):08X}",
         "Same" if dq4_exe.get('load_addr') == v44_exe.get('load_addr') else "DIFF"),
        ("EXE text size",
         f"0x{dq4_exe.get('text_size', 0):08X}",
         f"0x{dw7_exe.get('text_size', 0):08X}",
         f"0x{v44_exe.get('text_size', 0):08X}",
         f"v44-DW7=0x{(v44_exe.get('text_size',0)-dw7_exe.get('text_size',0)):X}" if v44_exe.get('text_size') and dw7_exe.get('text_size') else "N/A"),
        ("BSS clear start", f"0x{BSS_CLEAR_START:08X}", f"0x{BSS_CLEAR_START:08X}", f"0x{BSS_CLEAR_START:08X}", "Same"),
        ("BSS clear end", f"0x{BSS_CLEAR_END_DQ4:08X}", f"0x{BSS_CLEAR_END_DW7:08X}", f"0x{BSS_CLEAR_END_DW7:08X}", f"v44=DW7, DQ4 delta=0x{BSS_CLEAR_END_DQ4-BSS_CLEAR_END_DW7:X}"),
        ("Thread entry", f"0x{THREAD_ENTRY:08X}", f"0x{THREAD_ENTRY:08X}", f"0x{THREAD_ENTRY:08X}", "Same"),
        ("Huffman tree (DQ4)", "Per-block", "0x800EF1C8", "0x800BC700", "v44 relocated"),
        ("Hybrid tree size", "N/A", "N/A", "1480 bytes", "v44 only"),
        ("Display flag (final)", 
         tel_comp.get('dq4_jp_ref', {}).get('display_flag', 'N/A'),
         tel_comp.get('dw7_us_ref', {}).get('display_flag', 'N/A'),
         tel_comp.get('v44_frank', {}).get('display_flag', 'N/A'),
         "v44=DW7, both 0x0000"),
        ("Event flag (final)",
         tel_comp.get('dq4_jp_ref', {}).get('event_flag', 'N/A'),
         tel_comp.get('dw7_us_ref', {}).get('event_flag', 'N/A'),
         tel_comp.get('v44_frank', {}).get('event_flag', 'N/A'),
         "v44=DW7, both 0x00"),
    ]
    
    for row in rows:
        report.append(f"  {row[0]:<35s} {row[1]:<15s} {row[2]:<15s} {row[3]:<15s} {row[4]}")
    report.append("")
    
    # ─── Section 10: Root Cause & Recommendations ──────────────────────
    report.append("-" * 80)
    report.append("SECTION 10: ROOT CAUSE ANALYSIS & RECOMMENDATIONS")
    report.append("-" * 80)
    report.append("")
    report.append("  ROOT CAUSE: v44 Frankenstein build fails to boot past CD-ROM init")
    report.append("")
    report.append("  1. DISPLAY INIT FAILURE:")
    report.append("     - DQ4 JP reaches display flag=0x3F4C (display initialized)")
    report.append("     - DW7 US and v44 both have display flag=0x0000 (display NOT initialized)")
    report.append("     - v44 uses DW7 EXE which has different GPU init code path")
    report.append("     - DW7 GPU init at PC=0x8009DAC4 vs DQ4 GPU init at PC=0x800A179C")
    report.append("     - Both DW7 and v44 complete GPU register setup (GP1 commands) but")
    report.append("       never reach the display enable / framebuffer configuration stage")
    report.append("")
    report.append("  2. CD-ROM THREAD STALL:")
    report.append("     - Thread entry at 0x800D9E80 is zero-filled by BSS clear routine")
    report.append("     - Without --preload, the CD-ROM loading thread has no code to execute")
    report.append("     - The game's main loop waits for CD-ready flags that are never set")
    report.append("     - DQ4 JP has event flag=0x50 (active event processing)")
    report.append("     - v44 has event flag=0x00 (no event processing — complete stall)")
    report.append("")
    report.append("  3. VBLANK COUNTER MISMATCH:")
    report.append("     - DQ4 JP: vbcnt=0x05555E84 (pre-initialized by BIOS)")
    report.append("     - v44:    vbcnt=0x00000008 (fresh count from HLE VBlank handler)")
    report.append("     - Delta: 0x05555E7C — DQ4's counter starts high due to BIOS warm boot")
    report.append("     - This is a CyberGrime HLE artifact, not a disc issue")
    report.append("")
    report.append("  RECOMMENDATIONS:")
    report.append("    1. Test v44 WITH preload mode (remove --no-preload) to inject HBD data")
    report.append("       and thread code — this is the only way to get past CD-ROM init")
    report.append("    2. Test v44 in DuckStation (real GPU emulation) for display verification")
    report.append("    3. The HBD LBA shift (+1) is correctly applied — ISO dir confirms LBA=355")
    report.append("    4. Verify hybrid tree at 0x800BC700 is not corrupted by BSS clear")
    report.append("    5. Consider Strategy A (DW7 HBD + DQ4 HBD concatenation) to preserve")
    report.append("       FMV data and provide valid CD-ROM streaming targets")
    report.append("    6. The DW7 EXE's CD-ROM driver expects DW7 HBD format — verify DQ4 HBD")
    report.append("       blocks are re-encoded to DW7 global-tree format (tree_end=0, text_end=0)")
    report.append("")
    
    # ─── Section 11: EXE Code Diffs ────────────────────────────────────
    report.append("-" * 80)
    report.append("SECTION 11: EXE BINARY DIFFS (Key Code Regions)")
    report.append("-" * 80)
    report.append("")
    
    # Compare key code regions
    code_regions = [
        (0x800, 0x40, "EXE header"),
        (0x810, 0x20, "EXE header extension"),
        (0x4184, 0x40, "ABS pointer table (first 8 entries)"),
        (0x800, 0x800, "Full EXE header + first 2KB code"),
    ]
    
    for offset, length, label in code_regions:
        diffs = compare_exe_code(discs_data, offset, length, label)
        if diffs:
            report.append(f"  [{label}] at EXE offset 0x{offset:06X}, length 0x{length:X}")
            report.append(f"    {len(diffs)} byte differences found:")
            for d in diffs[:20]:
                report.append(f"      {d}")
            if len(diffs) > 20:
                report.append(f"      ... and {len(diffs) - 20} more")
            report.append("")
        else:
            report.append(f"  [{label}] at EXE offset 0x{offset:06X}: IDENTICAL across all discs")
            report.append("")
    
    report.append("=" * 80)
    report.append("END OF DIFF REPORT")
    report.append("=" * 80)
    
    # Write report
    report_text = '\n'.join(report)
    with open(output_path, 'w', encoding='utf-8') as f:
        f.write(report_text)
    
    print(f"Report written to: {output_path}")
    print(f"Report length: {len(report)} lines")
    return report_text

def main():
    print("CyberGrime Telemetry Diff Analysis")
    print("=" * 60)
    
    # Load all disc data
    discs_data = {}
    for name, path in DISCS.items():
        if not os.path.exists(path):
            print(f"  [SKIP] {name}: {path} not found")
            continue
        
        print(f"  [LOAD] {name}: {path}")
        with open(path, 'rb') as f:
            # Read EXE sector
            exe_sector = read_sector_data(f, EXE_LBA)
            exe_raw = b''
            if exe_sector:
                # Read full EXE (up to 330 sectors = ~675KB)
                exe_sectors = []
                for i in range(330):
                    s = read_sector_data(f, EXE_LBA + i)
                    if s:
                        exe_sectors.append(s)
                    else:
                        break
                exe_raw = b''.join(exe_sectors)
            
            # Parse EXE header
            exe_hdr = parse_exe_header(exe_raw) if exe_raw else None
            
            # Parse ISO directory
            iso_dir = parse_iso_directory(f, path)
            
            # Find HBD LBA from ISO dir
            hbd_lba = None
            if iso_dir:
                for e in iso_dir['entries']:
                    if 'HBD' in e['name']:
                        hbd_lba = e['lba']
                        break
            
            discs_data[name] = {
                'exe_header': exe_hdr,
                'exe_raw': exe_raw,
                'iso_dir': iso_dir,
                'hbd_lba': hbd_lba,
                'file_size': os.path.getsize(path),
            }
            print(f"    EXE: {'Found' if exe_hdr else 'Not found'}, "
                  f"ISO dir: {'Found' if iso_dir else 'Not found'}, "
                  f"HBD LBA: {hbd_lba}, File size: {os.path.getsize(path):,}")
    
    # Load diag logs
    diags = {}
    for name, path in DIAG_LOGS.items():
        if os.path.exists(path):
            print(f"  [DIAG] {name}: {path}")
            diags[name] = parse_diag_log(path)
        else:
            print(f"  [DIAG] {name}: not found (skipping)")
            diags[name] = None
    
    # Generate report
    output_path = os.path.join(PROJECT, "study", "TELEMETRY_DIFF_REPORT_Jul20_2026.md")
    generate_report(discs_data, diags, output_path)
    
    # Also save as JSON for machine processing
    json_path = os.path.join(BASE, "telemetry", "telemetry_diff_summary.json")
    os.makedirs(os.path.dirname(json_path), exist_ok=True)
    
    summary = {
        'generated': datetime.now().isoformat(),
        'discs': {},
        'telemetry': {},
    }
    
    for name, info in discs_data.items():
        hdr = info.get('exe_header')
        if hdr:
            hdr = {k: (v.hex() if isinstance(v, bytes) else v) for k, v in hdr.items()}
        summary['discs'][name] = {
            'exe_header': hdr,
            'hbd_lba': info.get('hbd_lba'),
            'file_size': info.get('file_size'),
        }
    
    tel_comp = compare_telemetry(diags)
    summary['telemetry'] = tel_comp
    
    with open(json_path, 'w', encoding='utf-8') as f:
        json.dump(summary, f, indent=2, default=str)
    print(f"JSON summary: {json_path}")

if __name__ == '__main__':
    main()
