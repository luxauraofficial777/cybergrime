# F-3: Build two discs for comparison -- with and without XA stub
$BASE = 'c:\LuxAura\VoidWalkers_Project\DQLOSTTRANSLATION'
$BUILDER = "$BASE\cybergrime\frankenstein_build.exe"

# Common args - use exact paths from rebuild_frank.bat
$commonArgs = @(
    '--reverse',
    "--dq4-hbd", "$BASE\Dragon Quest IV - Michibikareshi Mono Tachi (Japan).bin",
    "--dw7-exe", "$BASE\translation\SLUSP012.06_clean.bin",
    "--hybrid-tree", "$BASE\frozen\dw7_hybrid_tree.bin",
    "--edcre", "$BASE\edcre\edcre-v1.1.0-windows-x86_64-static\edcre.exe",
    "--hotfixes", "$BASE\cybergrime\hotfixes_empty.txt",
    '--reencode-hbd', '--skip-hash-check', '--duckstation',
    "--staging-dir", "$BASE\build_staging"
)

Write-Host "=== Building v109 (WITH XA stub) ===" -ForegroundColor Cyan
& $BUILDER @commonArgs "--output" "$BASE\build_staging\dq4_frankenstein_v109.bin" "--output-cue" "$BASE\build_staging\dq4_frankenstein_v109.cue" 2>&1 | Tee-Object -FilePath "$BASE\build_staging\v109_build.log"

# Copy v109 output before second build purges staging
if (Test-Path "$BASE\build_staging\dq4_frankenstein_v109.bin") {
    Copy-Item "$BASE\build_staging\dq4_frankenstein_v109.bin" "$BASE\build_staging\v109_backup.bin" -Force
    Copy-Item "$BASE\build_staging\dq4_frankenstein_v109.cue" "$BASE\build_staging\v109_backup.cue" -Force
    Write-Host "v109 backed up before second build" -ForegroundColor Green
} else {
    Write-Host "v109 build FAILED -- no output file" -ForegroundColor Red
}

Write-Host ""
Write-Host "=== Building v109-no-xa (WITHOUT XA stub - F-3 test) ===" -ForegroundColor Cyan
& $BUILDER @commonArgs "--no-xa-stub" "--output" "$BASE\build_staging\dq4_frankenstein_v109_no_xa.bin" "--output-cue" "$BASE\build_staging\dq4_frankenstein_v109_no_xa.cue" 2>&1 | Tee-Object -FilePath "$BASE\build_staging\v109_no_xa_build.log"

# Restore v109 from backup
if (Test-Path "$BASE\build_staging\v109_backup.bin") {
    Copy-Item "$BASE\build_staging\v109_backup.bin" "$BASE\build_staging\dq4_frankenstein_v109.bin" -Force
    Copy-Item "$BASE\build_staging\v109_backup.cue" "$BASE\build_staging\dq4_frankenstein_v109.cue" -Force
    Remove-Item "$BASE\build_staging\v109_backup.bin", "$BASE\build_staging\v109_backup.cue" -Force
    Write-Host "v109 restored from backup" -ForegroundColor Green
}

Write-Host ""
Write-Host "=== Computing SHA-256 hashes ===" -ForegroundColor Yellow
if (Test-Path "$BASE\build_staging\dq4_frankenstein_v109.bin") {
    $v109 = Get-FileHash "$BASE\build_staging\dq4_frankenstein_v109.bin" -Algorithm SHA256
    Write-Host "v109 (XA stub):       $($v109.Hash)"
} else {
    Write-Host "v109 (XA stub):       NOT FOUND" -ForegroundColor Red
}

if (Test-Path "$BASE\build_staging\dq4_frankenstein_v109_no_xa.bin") {
    $v109nox = Get-FileHash "$BASE\build_staging\dq4_frankenstein_v109_no_xa.bin" -Algorithm SHA256
    Write-Host "v109-no-xa (no stub): $($v109nox.Hash)"
} else {
    Write-Host "v109-no-xa (no stub): NOT FOUND" -ForegroundColor Red
}

Write-Host ""
Write-Host "=== Done. Test both discs with DuckStation + SCPH-1001 BIOS ===" -ForegroundColor Green
Write-Host "v109:       $BASE\build_staging\dq4_frankenstein_v109.cue"
Write-Host "v109-no-xa: $BASE\build_staging\dq4_frankenstein_v109_no_xa.cue"
