#!/usr/bin/env python3
"""
Patch DW7 EXE FMV seek BCD coordinates.
  Source: BCD 32:34:71 (LBA 146621) — DW7 intro FMV
  Target: BCD 23:31:15 (LBA 105840) — DQ4 HBD/stream offset

This patch redirects the DW7 engine's hardcoded CD-ROM Setloc call
from DW7's STR data (not present on DQ4 disc) to DQ4's equivalent
stream data within the HBD archive region.

Usage:
  python patch_fmv_bcd.py <input_exe.bin> <output_exe.bin>
"""
import struct
import sys
import hashlib

PATCH_OFFSET = 0x09291E  # File offset in DW7 EXE (RAM 0x801203A2)
SOURCE_BCD = bytes([0x32, 0x34, 0x71])  # BCD 32:34:71 = LBA 146621
TARGET_BCD = bytes([0x23, 0x31, 0x15])  # BCD 23:31:15 = LBA 105840

def main():
    if len(sys.argv) < 3:
        print(f"Usage: {sys.argv[0]} <input_exe.bin> <output_exe.bin>")
        sys.exit(1)
    
    inp = sys.argv[1]
    outp = sys.argv[2]
    
    with open(inp, 'rb') as f:
        exe = bytearray(f.read())
    
    print(f"Input EXE: {len(exe)} bytes")
    print(f"SHA-256: {hashlib.sha256(exe).hexdigest()}")
    
    # Verify source pattern at offset
    actual = bytes(exe[PATCH_OFFSET:PATCH_OFFSET+3])
    if actual != SOURCE_BCD:
        print(f"ERROR: Expected {SOURCE_BCD.hex()} at offset 0x{PATCH_OFFSET:06X}")
        print(f"       Found {actual.hex()} instead")
        sys.exit(1)
    
    print(f"Verified: {SOURCE_BCD.hex()} (BCD 32:34:71 = LBA 146621) at 0x{PATCH_OFFSET:06X}")
    
    # Apply patch
    exe[PATCH_OFFSET:PATCH_OFFSET+3] = TARGET_BCD
    
    # Verify
    patched = bytes(exe[PATCH_OFFSET:PATCH_OFFSET+3])
    print(f"Patched: {patched.hex()} (BCD 23:31:15 = LBA 105840)")
    
    with open(outp, 'wb') as f:
        f.write(exe)
    
    print(f"Output: {outp} ({len(exe)} bytes)")
    print(f"SHA-256: {hashlib.sha256(exe).hexdigest()}")
    print("DONE")

if __name__ == '__main__':
    main()
