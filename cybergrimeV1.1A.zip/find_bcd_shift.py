#!/usr/bin/env python3
"""Find where the BCD data table moved to in the disc EXE by searching for surrounding patterns."""

SECTOR_SIZE = 2352
HEADER = 24
EXE_LBA = 24

disc_path = r"C:\LuxAura\VoidWalkers_Project\DQLOSTTRANSLATION\build_staging\dq4_gold.bin"
clean_path = r"C:\LuxAura\VoidWalkers_Project\DQLOSTTRANSLATION\translation\SLUSP012.06_clean.bin"

with open(disc_path, "rb") as f:
    disc = f.read()
with open(clean_path, "rb") as f:
    clean = f.read()

exe_start = EXE_LBA * SECTOR_SIZE + HEADER
disc_exe = disc[exe_start:exe_start + 677888]

# The clean EXE has this data at 0x092936:
# c2 12 9e 52 02 19 2e 54 32 34 71 57 72 17 e8 58
# These look like BCD MSF entries in a table:
#   52 9e 12 c2 = BCD 52:9e:12 (unlikely - too large)
# Actually let me look at this differently - these might be 16-bit entries
# Let me look at the table structure more carefully

# Print a larger region from the clean EXE around 0x092936
print("=== Clean EXE data table around 0x092936 ===")
for i in range(0x092900, 0x0929A0, 16):
    hex_str = clean[i:i+16].hex()
    print(f"  0x{i:06X}: {hex_str}")

# The BCD values 32 34 71 are at offset 0x092936 in clean EXE
# In the disc EXE, the data is different because the EXE was modified
# Let's check if the BCD patch was applied BEFORE or AFTER other patches
# by looking at the build pipeline order

# Key: the BCD patch is at step 3j.5 in build_v39
# But trampoline patches (3a-3i) modify the EXE text section and append data
# The BCD at 0x092936 is in the DATA section (after text)
# If the text section grew, the data section would shift

# Let's find the text/data boundary
# PS-X EXE header: text_size at offset 0x1EC (4 bytes LE)
import struct
clean_text_size = struct.unpack("<I", clean[0x1EC:0x1F0])[0]
disc_text_size = struct.unpack("<I", disc_exe[0x1EC:0x1F0])[0]
print(f"\nClean EXE text_size: 0x{clean_text_size:X} ({clean_text_size})")
print(f"Disc EXE text_size:  0x{disc_text_size:X} ({disc_text_size})")
print(f"Difference: {disc_text_size - clean_text_size} bytes")

# The BCD at 0x092936 is at file offset = 0x800 + text_offset
# In clean: 0x092936 - 0x800 = 0x092136 into the text/data
# If text grew by N bytes, the data at 0x092136 would move to 0x092136 + N
shift = disc_text_size - clean_text_size
new_offset = 0x092936 + shift
print(f"\nExpected new offset if data shifted: 0x{new_offset:06X}")
if new_offset < len(disc_exe):
    print(f"  Bytes at new offset: {disc_exe[new_offset:new_offset+3].hex()}")
    print(f"  Context: {disc_exe[new_offset-8:new_offset+11].hex()}")

# Also try searching for the unique surrounding bytes from clean EXE
# but skip the BCD bytes themselves (which were patched)
# Search for: 02 19 2e 54 XX XX XX 57 72 17
search_pat = bytes([0x02, 0x19, 0x2e, 0x54])
idx = 0
print(f"\nSearching disc EXE for '02 19 2e 54' (bytes before BCD)...")
while True:
    idx = disc_exe.find(search_pat, idx)
    if idx == -1: break
    print(f"  Found at 0x{idx:06X} (RAM 0x{idx+0x80017F00:08X})")
    print(f"  Context: {disc_exe[idx:idx+16].hex()}")
    idx += 1

# Search for 57 72 17 (bytes after BCD)
search_pat2 = bytes([0x57, 0x72, 0x17])
idx = 0
print(f"\nSearching disc EXE for '57 72 17' (bytes after BCD)...")
count = 0
while True:
    idx = disc_exe.find(search_pat2, idx)
    if idx == -1: break
    if count < 10:
        print(f"  Found at 0x{idx:06X} (RAM 0x{idx+0x80017F00:08X})")
        print(f"  Context: {disc_exe[idx-8:idx+8].hex()}")
    count += 1
    idx += 1
print(f"  Total: {count}")
