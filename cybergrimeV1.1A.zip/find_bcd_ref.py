#!/usr/bin/env python3
"""
Find what code references the BCD data table.
The table is at file offset 0x092936 (RAM 0x800AA836 in clean EXE).
Search for:
1. lui+addiu pairs that compute 0x800AA836 or nearby addresses
2. lui+ori pairs that compute the same
3. Any address in the range 0x800AA800-0x800AAA0
Also look at the data table structure to understand its format.
"""
import struct

disc_path = r"C:\LuxAura\VoidWalkers_Project\DQLOSTTRANSLATION\build_staging\dq4_gold.bin"
clean_path = r"C:\LuxAura\VoidWalkers_Project\DQLOSTTRANSLATION\translation\SLUSP012.06_clean.bin"
SECTOR_SIZE = 2352
USER_SIZE = 2048
EXE_LBA = 24
HEADER = 24
LOAD_ADDR = 0x80017F00

with open(disc_path, "rb") as f:
    disc = f.read()
with open(clean_path, "rb") as f:
    clean = f.read()

def read_exe_from_disc(disc, start_lba, exe_size):
    exe = bytearray()
    sectors_needed = (exe_size + USER_SIZE - 1) // USER_SIZE
    for i in range(sectors_needed):
        sec_start = (start_lba + i) * SECTOR_SIZE + HEADER
        chunk = disc[sec_start:sec_start + USER_SIZE]
        exe.extend(chunk)
    return bytes(exe[:exe_size])

disc_exe = read_exe_from_disc(disc, EXE_LBA, 677888)

# The BCD table in clean EXE is at file offset 0x092936 = RAM 0x800AA836
# Let's look at the table structure more carefully
print("=== BCD data table in clean EXE (0x092900 - 0x0929A0) ===")
for i in range(0x092900, 0x0929A0, 16):
    hex_str = clean[i:i+16].hex()
    # Try to interpret as BCD MSF entries (3 bytes each)
    bcd_interpret = []
    for j in range(0, 16, 3):
        if i + j + 3 <= 0x0929A0:
            m, s, f = clean[i+j], clean[i+j+1], clean[i+j+2]
            if m < 0x80 and s < 0x80 and f < 0x80:
                lba = (m >> 4) * 10 * 4500 + (m & 0xF) * 4500 + (s >> 4) * 10 * 75 + (s & 0xF) * 75 + (f >> 4) * 10 + (f & 0xF) - 150
                bcd_interpret.append(f"BCD {m:02X}:{s:02X}:{f:02X} (LBA {lba})")
            else:
                bcd_interpret.append(f"  {m:02X} {s:02X} {f:02X}  ")
    print(f"  0x{i:06X}: {hex_str}  {' | '.join(bcd_interpret)}")

# Search for references to addresses near 0x800AA836
# lui $reg, 0x800A; addiu $reg, $reg, 0xA836
# or lui $reg, 0x800B; addiu $reg, $reg, 0xFFFF (-1 = 0x800AA835+1)
# Actually the address 0x800AA836:
# hi = 0x800A, lo = 0xA836
# But 0xA836 >= 0x8000, so sign extension: lui $reg, 0x800B; addiu $reg, $reg, -0x57CA
# Or: lui $reg, 0x800A; ori $reg, $reg, 0xA836

print("\n=== Searching for references to 0x800AA836 (BCD table address) ===")
target_addr = 0x800AA836
target_hi = (target_addr >> 16) & 0xFFFF  # 0x800A
target_lo = target_addr & 0xFFFF  # 0xA836
target_hi_se = target_hi + 1 if target_lo >= 0x8000 else target_hi  # 0x800B
target_lo_se = target_lo - 0x10000 if target_lo >= 0x8000 else target_lo  # -0x57CA = -22474

print(f"Target: 0x{target_addr:08X}")
print(f"  lui+ori: hi=0x{target_hi:04X} lo=0x{target_lo:04X}")
print(f"  lui+addiu: hi=0x{target_hi_se:04X} lo={target_lo_se}")

# Search for lui $reg, 0x800A followed by ori $reg, $reg, 0xA836
# or lui $reg, 0x800B followed by addiu $reg, $reg, -0x57CA
for i in range(0, len(disc_exe) - 8, 4):
    word1 = struct.unpack("<I", disc_exe[i:i+4])[0]
    word2 = struct.unpack("<I", disc_exe[i+4:i+8])[0]
    
    op1 = (word1 >> 26) & 0x3F
    op2 = (word2 >> 26) & 0x3F
    imm1 = word1 & 0xFFFF
    imm2 = word2 & 0xFFFF
    rt1 = (word1 >> 16) & 0x1F
    rt2 = (word2 >> 16) & 0x1F
    rs2 = (word2 >> 21) & 0x1F
    
    # lui+ori pattern
    if op1 == 0x0F and imm1 == target_hi and op2 == 0x0D and rt2 == rt1 and imm2 == target_lo:
        ram = i + LOAD_ADDR
        print(f"  lui+ori at 0x{ram:08X}: lui $r{rt1}, 0x{imm1:04X}; ori $r{rt2}, $r{rs2}, 0x{imm2:04X}")
    
    # lui+addiu pattern (with sign extension)
    if op1 == 0x0F and imm1 == target_hi_se and op2 == 0x09 and rt2 == rt1 and (imm2 & 0xFFFF) == (target_lo & 0xFFFF):
        ram = i + LOAD_ADDR
        print(f"  lui+addiu at 0x{ram:08X}: lui $r{rt1}, 0x{imm1:04X}; addiu $r{rt2}, $r{rs2}, {imm2 if imm2 < 0x8000 else imm2 - 0x10000}")

# Also search for references to nearby addresses (table might be referenced by base + offset)
# Search for lui $reg, 0x800A with ori/addiu in range 0xA800-0xAB00
print("\n=== Searching for references to 0x800A_A8xx range ===")
for i in range(0, len(disc_exe) - 8, 4):
    word1 = struct.unpack("<I", disc_exe[i:i+4])[0]
    word2 = struct.unpack("<I", disc_exe[i+4:i+8])[0]
    
    op1 = (word1 >> 26) & 0x3F
    op2 = (word2 >> 26) & 0x3F
    imm1 = word1 & 0xFFFF
    imm2 = word2 & 0xFFFF
    rt1 = (word1 >> 16) & 0x1F
    rt2 = (word2 >> 16) & 0x1F
    rs2 = (word2 >> 21) & 0x1F
    
    # lui $reg, 0x800A + ori $reg, $reg, 0xA8xx
    if op1 == 0x0F and imm1 == 0x800A and op2 == 0x0D and rt2 == rt1 and (imm2 & 0xFF00) == 0xA800:
        ram = i + LOAD_ADDR
        addr = (imm1 << 16) | imm2
        print(f"  0x{ram:08X}: lui $r{rt1}, 0x{imm1:04X}; ori $r{rt2}, $r{rs2}, 0x{imm2:04X} -> 0x{addr:08X}")
    
    # lui $reg, 0x800B + addiu $reg, $reg, -0x58xx..-0x57xx
    if op1 == 0x0F and imm1 == 0x800B and op2 == 0x09 and rt2 == rt1:
        simm2 = imm2 if imm2 < 0x8000 else imm2 - 0x10000
        addr = (imm1 << 16) + simm2
        if 0x800AA800 <= addr <= 0x800AAB00:
            ram = i + LOAD_ADDR
            print(f"  0x{ram:08X}: lui $r{rt1}, 0x{imm1:04X}; addiu $r{rt2}, $r{rs2}, {simm2} -> 0x{addr:08X}")

# Also check: the table might be at a different RAM address after the EXE is loaded
# The EXE load address is at offset 0x10 in the PS-X header
exe_load_addr = struct.unpack("<I", disc_exe[0x10:0x14])[0]
print(f"\nEXE load address (PC0): 0x{exe_load_addr:08X}")
print(f"EXE file offset 0x092936 maps to RAM 0x{0x092936 + LOAD_ADDR:08X}")

# But wait - the BCD table might be referenced relative to a base pointer
# Let's look at the table in the disc EXE to see if it's still there
print(f"\n=== BCD table in disc EXE at 0x092936 ===")
for i in range(0x092900, 0x0929A0, 16):
    hex_str = disc_exe[i:i+16].hex()
    print(f"  0x{i:06X}: {hex_str}")

# The table in the disc EXE should have 233108 instead of 323471
# Let's verify
print(f"\nDisc EXE at 0x092936: {disc_exe[0x092936:0x092939].hex()}")
print(f"Clean EXE at 0x092936: {clean[0x092936:0x092939].hex()}")
