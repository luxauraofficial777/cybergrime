#pragma once

// ============================================================================
// PSX GDB Remote Stub — GDB remote serial protocol over TCP
// Allows connecting gdb-multiarch or lldb to debug the emulated MIPS R3000A.
// Default port: 3333
// Header-only. On Windows, requires that WIN32_LEAN_AND_MEAN is defined
// before windows.h is included, or that winsock2.h is included first.
// ============================================================================

#ifdef _WIN32
// winsock2.h is included by agent_harness.h before windows.h
// If included standalone, include it here
#ifndef _WINSOCK2API_
#include <winsock2.h>
#include <ws2tcpip.h>
#endif
#pragma comment(lib, "ws2_32.lib")
#else
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <fcntl.h>
#endif

#include <cstdint>
#include <cstdio>
#include <cstring>
#include <string>
#include <functional>
#include <vector>

class PSXGdbStub {
public:
    int port;
    int server_fd;
    int client_fd;
    bool enabled;
    bool client_connected;
    bool debug_mode;

    // Callbacks for memory/register access
    std::function<uint32_t(uint32_t)> read_reg;
    std::function<void(uint32_t, uint32_t)> write_reg;
    std::function<std::vector<uint8_t>(uint32_t, uint32_t)> read_mem;
    std::function<void(uint32_t, const uint8_t*, uint32_t)> write_mem;
    std::function<uint32_t()> get_pc;
    std::function<void(uint32_t)> set_pc;
    std::function<void()> single_step;
    std::function<void()> continue_exec;
    std::function<void(uint32_t)> add_breakpoint;
    std::function<void(uint32_t)> remove_breakpoint;

    // GDB register indices for MIPS:
    // 0-31 = general regs, 32 = status, 33 = lo, 34 = hi,
    // 35 = badvaddr, 36 = cause, 37 = pc
    static constexpr int NUM_REGS = 38;

    PSXGdbStub() : port(3333), server_fd(-1), client_fd(-1),
                   enabled(false), client_connected(false), debug_mode(false) {
#ifdef _WIN32
        WSADATA wsa;
        WSAStartup(MAKEWORD(2, 2), &wsa);
#endif
    }

    ~PSXGdbStub() {
        stop();
#ifdef _WIN32
        WSACleanup();
#endif
    }

    bool start(int port_num = 3333) {
        port = port_num;
        server_fd = (int)socket(AF_INET, SOCK_STREAM, 0);
        if (server_fd < 0) return false;

        int opt = 1;
        setsockopt(server_fd, SOL_SOCKET, SO_REUSEADDR, (const char*)&opt, sizeof(opt));

        struct sockaddr_in addr;
        memset(&addr, 0, sizeof(addr));
        addr.sin_family = AF_INET;
        addr.sin_addr.s_addr = htonl(INADDR_ANY);
        addr.sin_port = htons(port);

        if (bind(server_fd, (struct sockaddr*)&addr, sizeof(addr)) < 0) {
            printf("[GDB] Failed to bind port %d\n", port);
            return false;
        }
        if (listen(server_fd, 1) < 0) {
            printf("[GDB] Listen failed\n");
            return false;
        }

        // Set non-blocking so we can poll for connections
#ifdef _WIN32
        u_long mode = 1;
        ioctlsocket(server_fd, FIONBIO, &mode);
#else
        fcntl(server_fd, F_SETFL, O_NONBLOCK);
#endif

        enabled = true;
        printf("[GDB] Listening on port %d (connect with: target remote :%d)\n", port, port);
        return true;
    }

    void stop() {
        if (client_fd >= 0) {
#ifdef _WIN32
            closesocket(client_fd);
#else
            close(client_fd);
#endif
            client_fd = -1;
            client_connected = false;
        }
        if (server_fd >= 0) {
#ifdef _WIN32
            closesocket(server_fd);
#else
            close(server_fd);
#endif
            server_fd = -1;
        }
        enabled = false;
    }

    // Poll for incoming connections (non-blocking)
    bool poll_connect() {
        if (!enabled || client_connected) return client_connected;

        struct sockaddr_in client_addr;
        int addr_len = sizeof(client_addr);
        int fd = (int)accept(server_fd, (struct sockaddr*)&client_addr, &addr_len);
        if (fd < 0) return false;  // No connection yet

        client_fd = fd;
        client_connected = true;
        printf("[GDB] Client connected\n");
        return true;
    }

    // Send a packet
    void send_packet(const char* data) {
        if (client_fd < 0) return;
        uint8_t checksum = 0;
        for (const char* p = data; *p; p++) checksum += (uint8_t)*p;
        char buf[4096];
        snprintf(buf, sizeof(buf), "$%s#%02X", data, checksum);
#ifdef _WIN32
        send(client_fd, buf, (int)strlen(buf), 0);
#else
        write(client_fd, buf, strlen(buf));
#endif
        if (debug_mode) printf("[GDB] TX: %s\n", buf);
    }

    // Send OK response
    void send_ok() { send_packet("OK"); }

    // Send error
    void send_error(int code) {
        char buf[16];
        snprintf(buf, sizeof(buf), "E%02X", code);
        send_packet(buf);
    }

    // Read a packet (non-blocking, returns true if a complete packet was read)
    bool recv_packet(std::string& out) {
        if (client_fd < 0) return false;

        char buf[4096];
#ifdef _WIN32
        int n = recv(client_fd, buf, sizeof(buf) - 1, 0);
#else
        int n = read(client_fd, buf, sizeof(buf) - 1);
#endif
        if (n <= 0) return false;
        buf[n] = '\0';

        if (debug_mode) printf("[GDB] RX: %s\n", buf);

        // Look for $...#checksum format
        const char* start = strchr(buf, '$');
        if (!start) return false;
        const char* end = strchr(start + 1, '#');
        if (!end) return false;

        out = std::string(start + 1, end - start - 1);

        // Send ACK
        char ack = '+';
#ifdef _WIN32
        send(client_fd, &ack, 1, 0);
#else
        write(client_fd, &ack, 1);
#endif

        return true;
    }

    // Handle a GDB command
    void handle_command(const std::string& cmd) {
        if (cmd.empty()) {
            send_packet("");
            return;
        }

        char cmd_char = cmd[0];

        switch (cmd_char) {
            case '?':  // Halt reason
                send_packet("S05");  // SIGTRAP
                break;

            case 'g': {  // Read all registers
                char buf[NUM_REGS * 8 + 1];
                buf[0] = '\0';
                for (int i = 0; i < NUM_REGS; i++) {
                    uint32_t val = 0;
                    if (read_reg) val = read_reg(i);
                    char reg[9];
                    snprintf(reg, sizeof(reg), "%02X%02X%02X%02X",
                            (val >> 24) & 0xFF, (val >> 16) & 0xFF,
                            (val >> 8) & 0xFF, val & 0xFF);
                    // GDB expects little-endian byte order
                    snprintf(reg, sizeof(reg), "%02X%02X%02X%02X",
                            val & 0xFF, (val >> 8) & 0xFF,
                            (val >> 16) & 0xFF, (val >> 24) & 0xFF);
                    strcat(buf, reg);
                }
                send_packet(buf);
                break;
            }

            case 'G': {  // Write all registers
                // Parse hex data after 'G'
                if (cmd.length() >= 1 + NUM_REGS * 8) {
                    for (int i = 0; i < NUM_REGS; i++) {
                        uint32_t val = 0;
                        for (int b = 0; b < 4; b++) {
                            uint8_t byte = hex_to_byte(cmd[1 + i * 8 + b * 2],
                                                       cmd[1 + i * 8 + b * 2 + 1]);
                            val |= (uint32_t)byte << (b * 8);
                        }
                        if (write_reg) write_reg(i, val);
                    }
                    send_ok();
                } else {
                    send_error(1);
                }
                break;
            }

            case 'p': {  // Read single register
                uint32_t reg_idx = (uint32_t)strtoul(cmd.c_str() + 1, nullptr, 16);
                uint32_t val = read_reg ? read_reg(reg_idx) : 0;
                char buf[9];
                snprintf(buf, sizeof(buf), "%02X%02X%02X%02X",
                        val & 0xFF, (val >> 8) & 0xFF,
                        (val >> 16) & 0xFF, (val >> 24) & 0xFF);
                send_packet(buf);
                break;
            }

            case 'P': {  // Write single register
                // P<reg>=<value>
                size_t eq = cmd.find('=');
                if (eq != std::string::npos) {
                    uint32_t reg_idx = (uint32_t)strtoul(cmd.c_str() + 1, nullptr, 16);
                    uint32_t val = 0;
                    for (int b = 0; b < 4 && eq + 1 + b * 2 + 1 < cmd.length(); b++) {
                        uint8_t byte = hex_to_byte(cmd[eq + 1 + b * 2],
                                                   cmd[eq + 1 + b * 2 + 1]);
                        val |= (uint32_t)byte << (b * 8);
                    }
                    if (write_reg) write_reg(reg_idx, val);
                    send_ok();
                } else {
                    send_error(1);
                }
                break;
            }

            case 'm': {  // Read memory: m<addr>,<length>
                size_t comma = cmd.find(',');
                if (comma != std::string::npos) {
                    uint32_t addr = (uint32_t)strtoul(cmd.c_str() + 1, nullptr, 16);
                    uint32_t len = (uint32_t)strtoul(cmd.c_str() + comma + 1, nullptr, 16);
                    std::vector<uint8_t> data;
                    if (read_mem) data = read_mem(addr, len);
                    char* buf = new char[data.size() * 2 + 1];
                    for (size_t i = 0; i < data.size(); i++) {
                        snprintf(buf + i * 2, 3, "%02X", data[i]);
                    }
                    buf[data.size() * 2] = '\0';
                    send_packet(buf);
                    delete[] buf;
                } else {
                    send_error(1);
                }
                break;
            }

            case 'M': {  // Write memory: M<addr>,<length>:<data>
                size_t comma = cmd.find(',');
                size_t colon = cmd.find(':');
                if (comma != std::string::npos && colon != std::string::npos) {
                    uint32_t addr = (uint32_t)strtoul(cmd.c_str() + 1, nullptr, 16);
                    uint32_t len = (uint32_t)strtoul(cmd.c_str() + comma + 1, nullptr, 16);
                    std::vector<uint8_t> data(len);
                    for (uint32_t i = 0; i < len; i++) {
                        data[i] = hex_to_byte(cmd[colon + 1 + i * 2],
                                              cmd[colon + 1 + i * 2 + 1]);
                    }
                    if (write_mem) write_mem(addr, data.data(), len);
                    send_ok();
                } else {
                    send_error(1);
                }
                break;
            }

            case 'Z': {  // Set breakpoint: Z<type>,<addr>,<kind>
                size_t comma1 = cmd.find(',');
                if (comma1 != std::string::npos) {
                    uint32_t addr = (uint32_t)strtoul(cmd.c_str() + comma1 + 1, nullptr, 16);
                    if (add_breakpoint) add_breakpoint(addr);
                    send_ok();
                }
                break;
            }

            case 'z': {  // Remove breakpoint: z<type>,<addr>,<kind>
                size_t comma1 = cmd.find(',');
                if (comma1 != std::string::npos) {
                    uint32_t addr = (uint32_t)strtoul(cmd.c_str() + comma1 + 1, nullptr, 16);
                    if (remove_breakpoint) remove_breakpoint(addr);
                    send_ok();
                }
                break;
            }

            case 's':  // Single step
                if (single_step) single_step();
                send_packet("S05");
                break;

            case 'c':  // Continue
                if (continue_exec) continue_exec();
                send_packet("S05");  // Will be sent when execution stops
                break;

            case 'H':  // Set thread (ignore)
                send_ok();
                break;

            case 'q':  // Query
                if (cmd.substr(0, 7) == "qSupported") {
                    send_packet("PacketSize=4096;qXfer:features:read+;QStartNoAckMode+");
                } else if (cmd.substr(0, 9) == "qAttached") {
                    send_packet("1");  // Attached to existing process
                } else if (cmd.substr(0, 6) == "qCpid") {
                    send_packet("QC1");
                } else if (cmd.substr(0, 5) == "qfThr" || cmd.substr(0, 5) == "qsThr") {
                    send_packet("l");  // No threads
                } else {
                    send_packet("");
                }
                break;

            case 'Q':  // Set
                if (cmd == "QStartNoAckMode") {
                    send_ok();
                } else {
                    send_packet("");
                }
                break;

            case 'v':  // Extended commands
                if (cmd.substr(0, 5) == "vCont") {
                    // vCont;s = step, vCont;c = continue
                    if (cmd.find('s') != std::string::npos) {
                        if (single_step) single_step();
                        send_packet("S05");
                    } else if (cmd.find('c') != std::string::npos) {
                        if (continue_exec) continue_exec();
                        send_packet("S05");
                    } else {
                        send_ok();
                    }
                } else if (cmd == "vMustReplyEmpty") {
                    send_packet("");
                } else {
                    send_packet("");
                }
                break;

            case 'T':  // Thread alive
                send_ok();
                break;

            case 'D':  // Detach
                send_ok();
                client_connected = false;
#ifdef _WIN32
                closesocket(client_fd);
#else
                close(client_fd);
#endif
                client_fd = -1;
                break;

            case 'k':  // Kill
                send_ok();
                break;

            default:
                send_packet("");
                break;
        }
    }

    // Poll for and handle commands (non-blocking)
    void poll() {
        if (!enabled) return;
        if (!client_connected) {
            poll_connect();
            return;
        }

        std::string cmd;
        while (recv_packet(cmd)) {
            handle_command(cmd);
        }
    }

private:
    static uint8_t hex_to_byte(char hi, char lo) {
        uint8_t result = 0;
        if (hi >= '0' && hi <= '9') result = (hi - '0') << 4;
        else if (hi >= 'a' && hi <= 'f') result = (hi - 'a' + 10) << 4;
        else if (hi >= 'A' && hi <= 'F') result = (hi - 'A' + 10) << 4;
        if (lo >= '0' && lo <= '9') result |= (lo - '0');
        else if (lo >= 'a' && lo <= 'f') result |= (lo - 'a' + 10);
        else if (lo >= 'A' && lo <= 'F') result |= (lo - 'A' + 10);
        return result;
    }
};
