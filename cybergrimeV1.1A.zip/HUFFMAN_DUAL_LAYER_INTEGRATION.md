# Dual-Layer Huffman Tree Compatibility — Integration Guide

## Overview

This document describes the dual-layer solution for establishing Huffman tree
compatibility between DQ4 (per-block trees) and DW7 (global tree) in the
Heartbeat Engine Frankenstein project.

## Architecture

```
┌─────────────────────────────────────────────────────────────┐
│                    BUILD TIME (Pre-Processing)               │
│                                                             │
│  reencode_pipeline.py                                       │
│  ┌─────────────────────────────────────────────────────┐   │
│  │  Layer 1: Static Re-encoding                         │   │
│  │  • Decode DQ4 text with per-block tree               │   │
│  │  • Re-encode with global hybrid tree                 │   │
│  │  • Strip tree, set hts=24, treeEnd=0, textEnd=0      │   │
│  │  • Output: DW7-compatible blocks (no shim needed)    │   │
│  │                                                      │   │
│  │  Layer 2: Runtime Flagging                           │   │
│  │  • Blocks that fail re-encoding → flagged            │   │
│  │  • textEnd = 0xFFFFFFFF marker in header             │   │
│  │  • Original tree preserved after text data           │   │
│  │  • Runtime shim handles these at execution time      │   │
│  └─────────────────────────────────────────────────────┘   │
│                                                             │
│  Output: re-encoded HBD + manifest.json                     │
└─────────────────────────────────────────────────────────────┘
                          │
                          ▼
┌─────────────────────────────────────────────────────────────┐
│                   EXE PATCH TIME (Build)                     │
│                                                             │
│  frankenstein_build.cpp / frankenstein_builder.py           │
│  ┌─────────────────────────────────────────────────────┐   │
│  │  1. Load DW7 EXE                                     │   │
│  │  2. Apply disc-check bypass patches                  │   │
│  │  3. Patch LBA references (354→355)                   │   │
│  │  4. Remap ABS/REL pointer tables                     │   │
│  │  5. Append hybrid tree at 0x800BC700                 │   │
│  │  6. Patch 24 MIPS LUI/ADDIU tree refs                │   │
│  │  7. Patch BSS clear (0x76B84/0x76B88)                │   │
│  │  8. Apply FMV BCD seek patch (skip family REMOVED)    │   │
│  │  9. INJECT runtime shim at 0x800B4C70                │   │
│  │ 10. PATCH header reader at 0x800429F0 → trampoline   │   │
│  │ 11. Assemble disc with re-encoded HBD                │   │
│  │ 12. Regenerate EDC/ECC                               │   │
│  └─────────────────────────────────────────────────────┘   │
└─────────────────────────────────────────────────────────────┘
                          │
                          ▼
┌─────────────────────────────────────────────────────────────┐
│                   RUNTIME (DuckStation/PSX)                  │
│                                                             │
│  Game boots → BSS clear → bootstrap → main init              │
│                                                             │
│  When block header reader is called (0x800429F0):           │
│  ┌─────────────────────────────────────────────────────┐   │
│  │  Trampoline redirects to huffman_shim_entry          │   │
│  │                                                      │   │
│  │  Shim checks block header:                           │   │
│  │    hts == 24 AND treeEnd == 0?                       │   │
│  │      → YES, textEnd == 0? → DW7 native (pass through)│   │
│  │      → YES, textEnd == 0xFFFFFFFF? → DQ4 shim block  │   │
│  │        → Extract tree from trailing data              │   │
│  │        → Copy to global buffer (0x800BC700)           │   │
│  │        → Convert DQ4 root_id +1 → DW7 convention     │   │
│  │        → Return to original code path                │   │
│  │    hts != 24?                                        │   │
│  │      → DW7 native (pass through)                     │   │
│  └─────────────────────────────────────────────────────┘   │
│                                                             │
│  Decompressor uses global tree (hybrid or per-block copy)   │
│  Text renders correctly                                     │
└─────────────────────────────────────────────────────────────┘
```

## File Inventory

| File | Purpose |
|------|---------|
| `cybergrime/huffman_compat_shim.asm` | MIPS R3000A assembly shim (hand-written) |
| `cybergrime/huffman_compat_hook.c` | C implementation (GCC/MIPS cross-compiler) |
| `cybergrime/reencode_pipeline.py` | Python pre-processing script (Layer 1 + 2) |

## Key Addresses

| Address | Description |
|---------|-------------|
| `0x80017F00` | EXE load address (RAM base) |
| `0x800429F0` | Block header reader (hook target) |
| `0x800429F0 + 0x800 = 0x431F0` | EXE file offset for hook patch |
| `0x80073670` | Huffman decompressor (516 bytes) |
| `0x800B4A68` | Bootstrap code cave (520 bytes used) |
| `0x800B4C70` | Shim code cave (537 bytes available) |
| `0x800BC700` | Hybrid tree location in RAM (appended to EXE, 1480 bytes) |
| `0x800EF1C8` | DW7 original global tree buffer (744 bytes, pre-patch) |
| `0x80100000` | Extended tree buffer (for oversized trees) |

## Block Header Format

```
Offset  Size  Field       DQ4 Value        DW7 Value
0x00    4     end         block end offset block end offset
0x04    4     block_id    block ID         block ID
0x08    4     hts         24 (no gap)      ~1390 (1366-byte gap)
0x0C    4     treeEnd     >0 (tree end)    0 (no per-block tree)
0x10    4     textEnd     >0 (text end)    0 (no boundary)
0x14    4     unk1        unknown          unknown
```

### Shim-Flagged Block Format (Layer 2)

```
Offset  Size  Field       Value
0x00    24    header      hts=24, treeEnd=0, textEnd=0xFFFFFFFF
0x18    N     text        re-encoded or original text
0x18+N  10    tree_meta   treeStart(4), treeMiddle(4), numNodes(2)
0x22+N  M     tree_bytes  original DQ4 per-block tree
```

## Tree Format (DQ4/DW7 Shared)

```
Node format: 2 bytes, little-endian
  Bit 15:    1 = branch node, 0 = leaf node
  Bits 0-14: branch: child index | leaf: character/control value

Dual-array layout:
  Array A: [0, offset_b)
  Array B: [offset_b, tree_len)
  offset_b = (tree_len + 2) / 2 - 2

Root node: at tree_len - 4
  DQ4: root_id = (value & 0x7FFF) + 1
  DW7: root_id = value & 0x7FFF

Bitstream: bits reversed per byte (LSB first), 0=left, 1=right
```

## Injection Procedure

### Step 1: Pre-Process HBD

```bash
python reencode_pipeline.py \
  --hbd HBD1PS1D.Q41 \
  --tree dw7_hybrid_tree.bin \
  --output HBD1PS1D.Q41.reencoded \
  --manifest reencode_manifest.json
```

Verify the manifest shows `blocks_shim_flagged > 0` only for edge cases.
Ideally, 95%+ of blocks should be in `blocks_reencoded`.

### Step 2: Compile C Shim (Optional — for verification)

```bash
mipsel-linux-gnu-gcc -c -mabi=32 -march=r3000 -O2 \
  -fno-pic -fno-builtin huffman_compat_hook.c -o huffman_compat_hook.o
mipsel-linux-gnu-objcopy -O binary huffman_compat_hook.o huffman_compat_hook.bin
```

Or assemble the MIPS version:
```bash
mipsel-linux-gnu-as -march=r3000 -o huffman_compat_shim.o huffman_compat_shim.asm
mipsel-linux-gnu-ld -Ttext 0x800B4C70 -o huffman_compat_shim.elf huffman_compat_shim.o
mipsel-linux-gnu-objcopy -O binary huffman_compat_shim.elf huffman_compat_shim.bin
```

### Step 3: Integrate into Frankenstein Builder

Add to `frankenstein_build.cpp` after the FMV/stall bypass step:

```cpp
// Step 9: Inject Huffman compatibility shim
{
    // Read original instruction at 0x800429F0 (EXE offset 0x431F0)
    uint32_t orig_instr = rd32(&exe[0x431F0]);

    // Load shim binary
    FILE *fp = fopen("huffman_compat_shim.bin", "rb");
    if (fp) {
        // Read shim code
        fseek(fp, 0, SEEK_END);
        long shim_size = ftell(fp);
        fseek(fp, 0, SEEK_SET);

        // Shim goes at EXE offset 0x9CD70 (RAM 0x800B4C70)
        uint32_t shim_off = 0x9CD70;
        if (shim_off + shim_size <= exe.size()) {
            fread(&exe[shim_off], 1, shim_size, fp);

            // Patch trampoline's original-instruction placeholder
            // with the actual instruction from 0x431F0
            // (offset within shim binary depends on layout)
            uint32_t tramp_orig_off = shim_off + /* trampoline_orig_instr_offset */;
            wr32(&exe[tramp_orig_off], orig_instr);

            // Patch 0x431F0: j 0x800B4C70 (trampoline entry)
            uint32_t jump_target = 0x800B4C70 >> 2;
            uint32_t j_instr = 0x08000000 | (jump_target & 0x03FFFFFF);
            wr32(&exe[0x431F0], j_instr);

            printf("  Huffman compat shim: injected %ld bytes at 0x%06X\n",
                   shim_size, shim_off);
        }
        fclose(fp);
    }
}
```

### Step 4: Build and Test

```bash
g++ -O2 -o frankenstein_build.exe frankenstein_build.cpp
.\frankenstein_build.exe dq4_frankenstein_cpp.bin
```

Test in DuckStation with logging. Verify:
- Zero invalid memory read/write errors
- FPS > 0 (rendering active)
- Text displays correctly (not garbled)
- No crashes during text-heavy scenes (dialogue, menus)

## Register Preservation

The shim follows the MIPS o32 ABI convention:

| Register | Usage | Preserved |
|----------|-------|-----------|
| $a0 | Block pointer (input) | Saved on stack |
| $ra | Return address | Saved on stack |
| $s0 | Block pointer (working) | Saved on stack |
| $s1 | Scratch (hts/treeEnd) | Saved on stack |
| $s2 | Tree size | Saved on stack |
| $v0 | Return code | Output |
| $v1 | Tree size (output) | Output |
| $at | Temporary | NOT preserved (per ABI) |
| $t0-$t3 | Temporaries | NOT preserved (per ABI) |
| $sp | Stack pointer | Adjusted and restored |

## Fallback Behavior

If the shim encounters an invalid block or tree:

1. **Invalid tree bytes** (odd size, < 4 bytes): Returns `SHIM_ERR_INVALID`,
   falls through to DW7 native behavior (uses global hybrid tree).
2. **Tree too large** (> 65536 bytes): Returns `SHIM_ERR_INVALID`,
   falls through to DW7 native behavior.
3. **Tree > 744 but <= 65536**: Copies to extended buffer at `0x80100000`,
   patches primary decompressor's LUI/ADDIU to point to extended buffer.
4. **Block not DQ4 format** (hts != 24 or treeEnd == 0): Returns `SHIM_OK`,
   passes through to original code unchanged.

## Safety Considerations

- The shim executes in the code cave at `0x800B4C70`, which is in the EXE's
  BSS region but after the BSS clear loop's end address (0x800BCCC8).
- The shim does not modify any game state except the global tree buffer.
- The trampoline preserves $a0 (block pointer) so the original header reader
  receives unchanged input after the shim returns.
- The original first instruction of the header reader is executed in the
  trampoline before jumping to the second instruction, ensuring no code
  is skipped.
- Interrupt safety: The shim is short (< 300 instructions) and does not
  disable interrupts. If a VBlank interrupt fires during shim execution,
  the saved registers on the stack ensure correct resumption.

## Current Build Status

The Frankenstein build currently uses **Approach C** (HBD re-encoding via
`psx_ops.dll`'s `hbd_process` function) which performs Layer 1 re-encoding
at build time. The C++ and Python builders now produce byte-identical EXEs
and the game boots with FPS=200 in DuckStation.

This dual-layer shim is designed as a **fallback safety net** for any blocks
that the build-time re-encoding cannot handle (e.g., dynamically loaded
overlays, edge-case block types with unusual tree structures). In the
current build, all blocks are successfully re-encoded at build time, so
the runtime shim would pass through all blocks without intervention.

The shim becomes critical if:
- New DQ4 text blocks are added that contain tree structures incompatible
  with the hybrid tree
- Dynamic HBD loading occurs at runtime (e.g., disc swapping)
- Block types are discovered that the build-time re-encoder doesn't handle
