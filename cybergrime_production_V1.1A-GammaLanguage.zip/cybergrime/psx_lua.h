#pragma once

// ============================================================================
// PSX Lua Scripting Interface — Phase 5.3
// Embeds Lua 5.4 for test automation, bots, and dynamic patches.
// Provides bindings for memory access, register manipulation,
// breakpoints, input injection, and event callbacks.
//
// Usage:
//   PSXLuaEngine lua;
//   lua.bind_memory(mem, cpu);
//   lua.load_script("bot.lua");
//   lua.call_on_vblank(cpu.instructions);
//
// If Lua headers are not available, the engine compiles as a no-op stub.
// ============================================================================

// Uncomment this when Lua 5.4 headers are available
// #define HAS_LUA

#ifdef HAS_LUA
extern "C" {
#include <lua.h>
#include <lauxlib.h>
#include <lualib.h>
}
#endif

#include <cstdint>
#include <cstdio>
#include <cstring>
#include <string>
#include <functional>
#include <vector>

class PSXLuaEngine {
public:
    bool initialized;
    bool script_loaded;
    std::string last_error;

    // Callbacks — set by the host application
    std::function<uint8_t(uint32_t)> read8;
    std::function<uint16_t(uint32_t)> read16;
    std::function<uint32_t(uint32_t)> read32;
    std::function<void(uint32_t, uint8_t)> write8;
    std::function<void(uint32_t, uint16_t)> write16;
    std::function<void(uint32_t, uint32_t)> write32;
    std::function<uint32_t()> get_pc;
    std::function<uint32_t(int)> get_reg;
    std::function<void(int, uint32_t)> set_reg;
    std::function<void(uint32_t)> add_breakpoint;
    std::function<void()> single_step;
    std::function<void()> press_button;
    std::function<void()> release_button;
    std::function<void(const char*)> log_fn;

#ifdef HAS_LUA
    lua_State* L;
#endif

    PSXLuaEngine() : initialized(false), script_loaded(false) {
#ifdef HAS_LUA
        L = luaL_newstate();
        if (L) {
            luaL_openlibs(L);
            register_bindings();
            initialized = true;
        }
#endif
    }

    ~PSXLuaEngine() {
#ifdef HAS_LUA
        if (L) lua_close(L);
#endif
    }

    bool is_available() const {
#ifdef HAS_LUA
        return initialized;
#else
        return false;
#endif
    }

    bool load_script(const char* path) {
#ifdef HAS_LUA
        if (!initialized) { last_error = "Lua not initialized"; return false; }
        if (luaL_dofile(L, path) != LUA_OK) {
            last_error = lua_tostring(L, -1);
            fprintf(stderr, "[LUA] Error loading %s: %s\n", path, last_error.c_str());
            lua_pop(L, 1);
            return false;
        }
        script_loaded = true;
        if (log_fn) log_fn("[LUA] Script loaded successfully");
        return true;
#else
        last_error = "Lua support not compiled in (define HAS_LUA)";
        fprintf(stderr, "[LUA] %s\n", last_error.c_str());
        return false;
#endif
    }

    // Execute a Lua string
    bool do_string(const char* code) {
#ifdef HAS_LUA
        if (!initialized) return false;
        if (luaL_dostring(L, code) != LUA_OK) {
            last_error = lua_tostring(L, -1);
            fprintf(stderr, "[LUA] Error: %s\n", last_error.c_str());
            lua_pop(L, 1);
            return false;
        }
        return true;
#else
        (void)code;
        return false;
#endif
    }

    // Call on_vblank callback if defined
    void call_on_vblank(uint64_t instr_count) {
#ifdef HAS_LUA
        if (!initialized || !script_loaded) return;
        lua_getglobal(L, "on_vblank");
        if (lua_isfunction(L, -1)) {
            lua_pushinteger(L, (lua_Integer)instr_count);
            if (lua_pcall(L, 1, 0, 0) != LUA_OK) {
                last_error = lua_tostring(L, -1);
                fprintf(stderr, "[LUA] on_vblank error: %s\n", last_error.c_str());
                lua_pop(L, 1);
            }
        } else {
            lua_pop(L, 1);
        }
#else
        (void)instr_count;
#endif
    }

    // Call on_pc callback if defined (called when PC matches a registered address)
    void call_on_pc(uint32_t pc, uint64_t instr_count) {
#ifdef HAS_LUA
        if (!initialized || !script_loaded) return;
        lua_getglobal(L, "on_pc");
        if (lua_isfunction(L, -1)) {
            lua_pushinteger(L, (lua_Integer)pc);
            lua_pushinteger(L, (lua_Integer)instr_count);
            if (lua_pcall(L, 2, 0, 0) != LUA_OK) {
                last_error = lua_tostring(L, -1);
                fprintf(stderr, "[LUA] on_pc error: %s\n", last_error.c_str());
                lua_pop(L, 1);
            }
        } else {
            lua_pop(L, 1);
        }
#else
        (void)pc; (void)instr_count;
#endif
    }

    // Call on_bios callback if defined
    void call_on_bios(char table, uint8_t fn, uint32_t a0, uint32_t a1) {
#ifdef HAS_LUA
        if (!initialized || !script_loaded) return;
        lua_getglobal(L, "on_bios");
        if (lua_isfunction(L, -1)) {
            lua_pushinteger(L, table);
            lua_pushinteger(L, fn);
            lua_pushinteger(L, a0);
            lua_pushinteger(L, a1);
            if (lua_pcall(L, 4, 0, 0) != LUA_OK) {
                last_error = lua_tostring(L, -1);
                fprintf(stderr, "[LUA] on_bios error: %s\n", last_error.c_str());
                lua_pop(L, 1);
            }
        } else {
            lua_pop(L, 1);
        }
#else
        (void)table; (void)fn; (void)a0; (void)a1;
#endif
    }

    // Inject raw bytes into RAM via Lua
    void inject_bytes(uint32_t addr, const uint8_t* data, uint32_t len) {
        if (write8) {
            for (uint32_t i = 0; i < len; i++)
                write8(addr + i, data[i]);
        }
    }

private:
#ifdef HAS_LUA
    static PSXLuaEngine* s_current;

    void register_bindings() {
        // read8(addr) -> number
        lua_register(L, "read8", [](lua_State* L) -> int {
            uint32_t addr = (uint32_t)luaL_checkinteger(L, 1);
            lua_pushinteger(L, s_current->read8 ? s_current->read8(addr) : 0);
            return 1;
        });

        // read16(addr) -> number
        lua_register(L, "read16", [](lua_State* L) -> int {
            uint32_t addr = (uint32_t)luaL_checkinteger(L, 1);
            lua_pushinteger(L, s_current->read16 ? s_current->read16(addr) : 0);
            return 1;
        });

        // read32(addr) -> number
        lua_register(L, "read32", [](lua_State* L) -> int {
            uint32_t addr = (uint32_t)luaL_checkinteger(L, 1);
            lua_pushinteger(L, s_current->read32 ? s_current->read32(addr) : 0);
            return 1;
        });

        // write8(addr, val)
        lua_register(L, "write8", [](lua_State* L) -> int {
            uint32_t addr = (uint32_t)luaL_checkinteger(L, 1);
            uint8_t val = (uint8_t)luaL_checkinteger(L, 2);
            if (s_current->write8) s_current->write8(addr, val);
            return 0;
        });

        // write16(addr, val)
        lua_register(L, "write16", [](lua_State* L) -> int {
            uint32_t addr = (uint32_t)luaL_checkinteger(L, 1);
            uint16_t val = (uint16_t)luaL_checkinteger(L, 2);
            if (s_current->write16) s_current->write16(addr, val);
            return 0;
        });

        // write32(addr, val)
        lua_register(L, "write32", [](lua_State* L) -> int {
            uint32_t addr = (uint32_t)luaL_checkinteger(L, 1);
            uint32_t val = (uint32_t)luaL_checkinteger(L, 2);
            if (s_current->write32) s_current->write32(addr, val);
            return 0;
        });

        // get_pc() -> number
        lua_register(L, "get_pc", [](lua_State* L) -> int {
            lua_pushinteger(L, s_current->get_pc ? s_current->get_pc() : 0);
            return 1;
        });

        // get_reg(idx) -> number
        lua_register(L, "get_reg", [](lua_State* L) -> int {
            int idx = (int)luaL_checkinteger(L, 1);
            lua_pushinteger(L, s_current->get_reg ? s_current->get_reg(idx) : 0);
            return 1;
        });

        // set_reg(idx, val)
        lua_register(L, "set_reg", [](lua_State* L) -> int {
            int idx = (int)luaL_checkinteger(L, 1);
            uint32_t val = (uint32_t)luaL_checkinteger(L, 2);
            if (s_current->set_reg) s_current->set_reg(idx, val);
            return 0;
        });

        // break_() — halt emulation
        lua_register(L, "break_", [](lua_State* L) -> int {
            if (s_current->add_breakpoint) s_current->add_breakpoint(s_current->get_pc());
            return 0;
        });

        // inject_bytes(addr, hex_string)
        lua_register(L, "inject_bytes", [](lua_State* L) -> int {
            uint32_t addr = (uint32_t)luaL_checkinteger(L, 1);
            const char* hex = luaL_checkstring(L, 2);
            std::vector<uint8_t> bytes;
            for (const char* p = hex; *p && *(p+1); p += 2) {
                bytes.push_back((uint8_t)strtol(p, nullptr, 16));
            }
            s_current->inject_bytes(addr, bytes.data(), (uint32_t)bytes.size());
            return 0;
        });

        // press_button()
        lua_register(L, "press_button", [](lua_State* L) -> int {
            if (s_current->press_button) s_current->press_button();
            return 0;
        });

        // release_button()
        lua_register(L, "release_button", [](lua_State* L) -> int {
            if (s_current->release_button) s_current->release_button();
            return 0;
        });

        // log(msg)
        lua_register(L, "log", [](lua_State* L) -> int {
            const char* msg = luaL_checkstring(L, 1);
            printf("[LUA] %s\n", msg);
            if (s_current->log_fn) s_current->log_fn(msg);
            return 0;
        });

        s_current = this;
    }
#endif
};

#ifdef HAS_LUA
PSXLuaEngine* PSXLuaEngine::s_current = nullptr;
#endif
