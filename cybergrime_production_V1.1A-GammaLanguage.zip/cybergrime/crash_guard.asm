# Defensive guard for the switch dispatch at 0x8004BDE0 in the DW7 EXE.
# The crash occurs when a function pointer loaded from the jump table
# points to unmapped memory (0x8C000000). This guard validates that the
# target is inside valid RAM before jumping.
#
# Hook location: 0x8004BDF8 (the 'jr $v0' instruction)
# On entry: $v0 contains the candidate jump target loaded from 0x800261B0+offset
# On exit: jump to $v0 if valid, otherwise jump to the function epilogue at 0x8004BDB8

    # Save $t0/$t1 on stack (we are inside a function, sp is valid)
    addiu $sp, $sp, -8
    sw    $t0, 0($sp)
    sw    $t1, 4($sp)

    # Validate target range: 0x80000000 <= $v0 < 0x80200000
    lui   $t0, 0x8000
    sltu  $t1, $v0, $t0          # t1 = (v0 < 0x80000000)
    bne   $t1, $zero, bad_target
    nop
    lui   $t0, 0x8020
    sltu  $t1, $v0, $t0          # t1 = (v0 < 0x80200000)
    beq   $t1, $zero, bad_target
    nop

    # Target is valid — restore temps and jump via $v0
    lw    $t0, 0($sp)
    lw    $t1, 4($sp)
    addiu $sp, $sp, 8
    jr    $v0
    nop

bad_target:
    # Log a marker (write 0xDEADBEEF to a scratch address that won't be noticed)
    lui   $v0, 0x800C
    addiu $v0, $v0, -0x4000
    sw    $v0, -4($v0)

    # Restore temps and return to function epilogue at 0x8004BDB8
    lw    $t0, 0($sp)
    lw    $t1, 4($sp)
    addiu $sp, $sp, 8
    lui   $v0, 0x8004
    ori   $v0, $v0, 0xBDB8
    jr    $v0
    nop
