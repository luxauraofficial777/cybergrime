# Search the entire BIN file for BCD 32 34 71
$binPath = 'c:\LuxAura\VoidWalkers_Project\DQLOSTTRANSLATION\cybergrime\dq4_reverse_v97_fmv.bin'
$bytes = [System.IO.File]::ReadAllBytes($binPath)

Write-Host "=== Searching entire BIN for BCD 32 34 71 ==="
$count = 0
for ($i = 0; $i -lt $bytes.Length - 3; $i++) {
    if ($bytes[$i] -eq 0x32 -and $bytes[$i+1] -eq 0x34 -and $bytes[$i+2] -eq 0x71) {
        $sector = [Math]::Floor($i / 2352)
        $offsetInSector = $i % 2352
        # Check if this is in the data area (offset 24-2071) of a Mode 2 sector
        $dataOffset = $offsetInSector - 24
        if ($dataOffset -ge 0 -and $dataOffset -lt 2048) {
            # Calculate EXE file offset if in EXE sectors (24 onwards)
            if ($sector -ge 24) {
                $exeFileOff = ($sector - 24) * 2048 + $dataOffset
                Write-Host ("  BIN 0x{0:X} Sector {1} DataOff {2} EXEOff 0x{3:X}" -f $i, $sector, $dataOffset, $exeFileOff)
            } else {
                Write-Host ("  BIN 0x{0:X} Sector {1} DataOff {2} (not EXE)" -f $i, $sector, $dataOffset)
            }
        } else {
            Write-Host ("  BIN 0x{0:X} Sector {1} RawOff {2} (header/ECC area)" -f $i, $sector, $offsetInSector)
        }
        $count++
    }
}
Write-Host "Total occurrences: $count"

# Also search for the value as a 32-bit integer: 0x71343200 or 0x00323471 etc
Write-Host ""
Write-Host "=== Search for 146621 (0x23C7D) as 32-bit LE in EXE data ==="
# Read EXE data from disc (sectors 24+)
$exeStart = 24 * 2352 + 24
$exeSize = 681984  # from build output
$exeBytes = New-Object byte[] $exeSize
# Actually let's just search the raw BIN for the 32-bit value
$target = [BitConverter]::GetBytes([uint32]146621)
Write-Host ("Searching for bytes: {0:X2} {1:X2} {2:X2} {3:X2}" -f $target[0], $target[1], $target[2], $target[3])
for ($i = 0; $i -lt $bytes.Length - 4; $i++) {
    if ($bytes[$i] -eq $target[0] -and $bytes[$i+1] -eq $target[1] -and $bytes[$i+2] -eq $target[2] -and $bytes[$i+3] -eq $target[3]) {
        $sector = [Math]::Floor($i / 2352)
        $offsetInSector = $i % 2352
        $dataOffset = $offsetInSector - 24
        if ($dataOffset -ge 0 -and $dataOffset -lt 2048 -and $sector -ge 24) {
            $exeFileOff = ($sector - 24) * 2048 + $dataOffset
            Write-Host ("  FOUND at BIN 0x{0:X} Sector {1} EXEOff 0x{2:X}" -f $i, $sector, $exeFileOff)
        }
    }
}
