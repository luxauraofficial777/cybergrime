#!/usr/bin/env python3
"""
agent_telemetry.py — Phase 11: Agent Telemetry Integration

Standardized parser that reads emulator crash telemetry JSON + triage logs
and produces a single condensed JSON object that Cascade/Windsurf can parse
in one pass to understand the full emulator state at crash/freeze time.

Usage:
  python agent_telemetry.py --telemetry telemetry_dw7.json
  python agent_telemetry.py --telemetry telemetry_dw7.json --triage emulator_triage_dw7.log
  python agent_telemetry.py --telemetry telemetry_dw7.json --triage emulator_triage_dw7.log --output parsed.json
"""

import argparse
import json
import os
import re
import sys
from typing import Dict, List, Any, Optional


# ── Telemetry JSON Parser ─────────────────────────────────────────────────────

def parse_telemetry(path: str) -> Dict[str, Any]:
    """Parse the emulator's telemetry JSON output."""
    if not os.path.exists(path):
        return {"error": f"Telemetry file not found: {path}"}

    with open(path, "r", encoding="utf-8", errors="replace") as f:
        raw = json.load(f)

    result = {
        "profile": raw.get("Profile_Name", "unknown"),
        "disc": raw.get("Disc_Path", "unknown"),
        "pass_status": raw.get("Pass_Status", "UNKNOWN"),
        "instructions_executed": raw.get("Instructions_Executed", 0),
        "vblank_count": raw.get("VBlank_Count", 0),
        "last_pc": raw.get("Last_Known_PC", "0x00000000"),
        "crashed": raw.get("Crashed", False),
        "frozen": raw.get("Frozen", False),
        "crash_reason": raw.get("Crash_Reason", ""),
        "wall_clock_ms": raw.get("Wall_Clock_MS", 0),
        "registers": {},
        "memory_snapshot": {},
        "asset_loads": [],
        "error_signatures": [],
        "tty_tail": "",
    }

    # Parse register dump
    reg_dump = raw.get("Register_Dump", {})
    for reg_name, reg_val in reg_dump.items():
        result["registers"][reg_name] = reg_val

    # Key registers for quick access
    result["key_registers"] = {
        "v0": reg_dump.get("$v0", "0x00000000"),
        "v1": reg_dump.get("$v1", "0x00000000"),
        "a0": reg_dump.get("$a0", "0x00000000"),
        "a1": reg_dump.get("$a1", "0x00000000"),
        "ra": reg_dump.get("$ra", "0x00000000"),
        "sp": reg_dump.get("$sp", "0x00000000"),
        "gp": reg_dump.get("$gp", "0x00000000"),
        "pc": result["last_pc"],
    }

    # Parse memory snapshot
    mem_snap = raw.get("Memory_Snapshot", {})
    for addr, val in mem_snap.items():
        result["memory_snapshot"][addr] = val

    # Parse asset load history (VFS)
    vfs = raw.get("Asset_Load_History", [])
    for entry in vfs:
        result["asset_loads"].append({
            "resource": entry.get("resource_id", "?"),
            "lba": entry.get("lba", 0),
            "size": entry.get("size", 0),
            "resolved": entry.get("resolved", False),
            "error": entry.get("error", None),
        })

    # Parse error signatures
    errors = raw.get("Error_Signature", [])
    for err in errors:
        result["error_signatures"].append({
            "type": err.get("type", "?"),
            "message": err.get("message", "?"),
            "pc": err.get("pc", "0x00000000"),
            "instr_count": err.get("instr_count", 0),
        })

    # TTY tail (last 8KB)
    result["tty_tail"] = raw.get("TTY_Tail", "")[-2000:]  # Trim to last 2KB

    return result


# ── Triage Log Parser ─────────────────────────────────────────────────────────

def parse_triage(path: str) -> Dict[str, Any]:
    """Parse the human-readable triage log file."""
    if not os.path.exists(path):
        return {"error": f"Triage log not found: {path}"}

    with open(path, "r", encoding="utf-8", errors="replace") as f:
        content = f.read()

    result = {
        "freeze_type": "UNKNOWN",
        "freeze_pc": "0x00000000",
        "freeze_instr": 0,
        "loop_body": [],
        "registers": {},
        "bios_calls": [],
        "vfs_accesses": [],
        "memory_snapshot": {},
        "console_tail": "",
    }

    # Parse freeze type
    m = re.search(r"FREEZE TYPE:\s*(\w+)", content)
    if m:
        result["freeze_type"] = m.group(1)

    # Parse freeze PC
    m = re.search(r"FREEZE PC:\s*(0x[0-9A-Fa-f]+)", content)
    if m:
        result["freeze_pc"] = m.group(1)

    # Parse freeze instruction count
    m = re.search(r"FREEZE INSTR:\s*(\d+)", content)
    if m:
        result["freeze_instr"] = int(m.group(1))

    # Parse loop body PCs
    loop_section = re.search(r"LOOP BODY.*?---\n(.*?)(?:\n---|\n===|\Z)", content, re.DOTALL)
    if loop_section:
        for line in loop_section.group(1).strip().split("\n"):
            m = re.match(r"\s*(?:0x)?([0-9A-Fa-f]+)", line)
            if m:
                result["loop_body"].append(f"0x{m.group(1).upper()}")

    # Parse register dump section
    reg_section = re.search(r"REGISTER DUMP.*?---\n(.*?)(?:\n---|\n===|\Z)", content, re.DOTALL)
    if reg_section:
        for line in reg_section.group(1).strip().split("\n"):
            m = re.match(r"\s*\$(\w+)\s*=\s*(0x[0-9A-Fa-f]+)", line)
            if m:
                result["registers"][f"${m.group(1)}"] = m.group(2)

    # Parse BIOS calls
    bios_section = re.search(r"BIOS CALLS.*?---\n(.*?)(?:\n---|\n===|\Z)", content, re.DOTALL)
    if bios_section:
        for line in bios_section.group(1).strip().split("\n"):
            m = re.match(r"\s*\[?([ABC]):(0x[0-9A-Fa-f]+)\]?.*?ra=(0x[0-9A-Fa-f]+)", line)
            if m:
                result["bios_calls"].append({
                    "table": m.group(1),
                    "function": m.group(2),
                    "ra": m.group(3),
                })

    # Parse VFS accesses
    vfs_section = re.search(r"VFS ACCESSES.*?---\n(.*?)(?:\n---|\n===|\Z)", content, re.DOTALL)
    if vfs_section:
        for line in vfs_section.group(1).strip().split("\n"):
            m = re.match(r"\s*(\S+)\s+lba=(\d+)\s+size=(\d+)\s+(resolved|FAILED)", line)
            if m:
                result["vfs_accesses"].append({
                    "resource": m.group(1),
                    "lba": int(m.group(2)),
                    "size": int(m.group(3)),
                    "resolved": m.group(4) == "resolved",
                })

    # Parse memory snapshot
    mem_section = re.search(r"MEMORY SNAPSHOT.*?---\n(.*?)(?:\n---|\n===|\Z)", content, re.DOTALL)
    if mem_section:
        for line in mem_section.group(1).strip().split("\n"):
            m = re.match(r"\s*(0x[0-9A-Fa-f]+)\s*=\s*(0x[0-9A-Fa-f]+)", line)
            if m:
                result["memory_snapshot"][m.group(1)] = m.group(2)

    # Parse console output tail
    console_section = re.search(r"CONSOLE OUTPUT TAIL.*?---\n(.*?)(?:\n===|\Z)", content, re.DOTALL)
    if console_section:
        result["console_tail"] = console_section.group(1).strip()[-2000:]

    return result


# ── Combined Analysis ─────────────────────────────────────────────────────────

def build_agent_brief(telemetry: Dict, triage: Optional[Dict] = None) -> Dict[str, Any]:
    """Build a condensed brief that Cascade can parse in a single pass."""
    brief = {
        "verdict": _determine_verdict(telemetry, triage),
        "profile": telemetry.get("profile", "unknown"),
        "pass_status": telemetry.get("pass_status", "UNKNOWN"),
        "instruction_count": telemetry.get("instructions_executed", 0),
        "vblank_count": telemetry.get("vblank_count", 0),
        "freeze_type": triage.get("freeze_type", "NONE") if triage else "NONE",
        "freeze_pc": triage.get("freeze_pc", telemetry.get("last_pc", "0x00000000")) if triage else telemetry.get("last_pc", "0x00000000"),
        "crash_reason": telemetry.get("crash_reason", ""),
        "key_registers": telemetry.get("key_registers", {}),
        "loop_body": triage.get("loop_body", []) if triage else [],
        "memory_snapshot": {},
        "bios_calls": [],
        "vfs_failures": [],
        "errors": telemetry.get("error_signatures", []),
        "diagnostic_hints": [],
    }

    # Merge memory snapshots
    brief["memory_snapshot"].update(telemetry.get("memory_snapshot", {}))
    if triage:
        brief["memory_snapshot"].update(triage.get("memory_snapshot", {}))

    # Merge BIOS calls
    if triage:
        brief["bios_calls"] = triage.get("bios_calls", [])

    # Extract VFS failures
    for load in telemetry.get("asset_loads", []):
        if not load.get("resolved", True):
            brief["vfs_failures"].append(load)

    # Generate diagnostic hints
    brief["diagnostic_hints"] = _generate_hints(brief)

    return brief


def _determine_verdict(telemetry: Dict, triage: Optional[Dict]) -> str:
    """Determine the overall verdict from telemetry + triage."""
    status = telemetry.get("pass_status", "UNKNOWN")
    if status == "COMPLETE":
        return "PASS"
    if status == "CRASH":
        return "CRASH"
    if status == "FREEZE":
        ft = triage.get("freeze_type", "UNKNOWN") if triage else "UNKNOWN"
        if ft == "TIGHT_LOOP":
            return "FREEZE_TIGHT_LOOP"
        elif ft == "VBLANK_STALL":
            return "FREEZE_VBLANK_STALL"
        elif ft == "PC_STUCK":
            return "FREEZE_PC_STUCK"
        return "FREEZE"
    if status == "TIMEOUT":
        return "TIMEOUT"
    if status == "BOOT_FAIL":
        return "BOOT_FAILURE"
    return "UNKNOWN"


def _generate_hints(brief: Dict) -> List[str]:
    """Generate diagnostic hints based on the telemetry brief."""
    hints = []
    ft = brief.get("freeze_type", "NONE")
    pc = brief.get("freeze_pc", "0x00000000")

    if ft == "TIGHT_LOOP":
        loop = brief.get("loop_body", [])
        hints.append(f"CPU caught in tight loop at {pc} with {len(loop)} unique PCs")
        if loop:
            hints.append(f"Loop body: {', '.join(loop[:8])}")
            hints.append("Consider NOP-ing branch instructions in the loop body or patching the loop exit condition")
    elif ft == "VBLANK_STALL":
        hints.append(f"VBlank stall at {pc} — no IRQ delivery for threshold period")
        hints.append("Check CP0 Status IM bits, I_STAT register, and VBlank IRQ handler at 0x80000080")
    elif ft == "PC_STUCK":
        hints.append(f"PC stuck at {pc} — possible infinite NOP slide or self-branch")
        hints.append("Check if this address contains a B instruction targeting itself")

    # Check VFS failures
    vfs_fails = brief.get("vfs_failures", [])
    if vfs_fails:
        hints.append(f"{len(vfs_fails)} VFS access failures detected")
        for vf in vfs_fails[:3]:
            hints.append(f"  Missing: {vf.get('resource', '?')} (LBA={vf.get('lba', 0)})")

    # Check memory snapshot for known patterns
    mem = brief.get("memory_snapshot", {})
    for addr, val in mem.items():
        if "B5312" in addr.upper() and val == "0x0000":
            hints.append("Display flag (0x800B5312) is 0 — display not initialized")
        if "B679C" in addr.upper() and val == "0x00":
            hints.append("Event flag (0x800B679C) is 0 — event system not ready")
        if "EF1C8" in addr.upper() and val == "0x00000000":
            hints.append("Huffman tree pointer (0x800EF1C8) is NULL — decompression will fail")

    # Check instruction count vs VBlank ratio
    ic = brief.get("instruction_count", 0)
    vc = brief.get("vblank_count", 0)
    if ic > 10000000 and vc < 10:
        hints.append(f"High instruction count ({ic}) but low VBlanks ({vc}) — possible IRQ delivery failure")

    return hints


# ── Output ─────────────────────────────────────────────────────────────────────

def print_brief(brief: Dict) -> None:
    """Print a human-readable summary of the agent brief."""
    print("=" * 70)
    print("AGENT TELEMETRY BRIEF — Phase 11")
    print("=" * 70)
    print(f"Verdict:        {brief['verdict']}")
    print(f"Profile:        {brief['profile']}")
    print(f"Pass Status:    {brief['pass_status']}")
    print(f"Instructions:   {brief['instruction_count']:,}")
    print(f"VBlanks:        {brief['vblank_count']}")
    print(f"Freeze Type:    {brief['freeze_type']}")
    print(f"Freeze PC:      {brief['freeze_pc']}")
    if brief.get("crash_reason"):
        print(f"Crash Reason:   {brief['crash_reason']}")
    print()

    print("KEY REGISTERS:")
    kr = brief.get("key_registers", {})
    for name in ["v0", "v1", "a0", "a1", "ra", "sp", "gp", "pc"]:
        if name in kr:
            print(f"  ${name:<4} = {kr[name]}")
    print()

    if brief.get("loop_body"):
        print(f"LOOP BODY ({len(brief['loop_body'])} PCs):")
        for pc in brief["loop_body"][:16]:
            print(f"  {pc}")
        print()

    if brief.get("memory_snapshot"):
        print("MEMORY SNAPSHOT:")
        for addr, val in brief["memory_snapshot"].items():
            print(f"  {addr} = {val}")
        print()

    if brief.get("bios_calls"):
        print(f"BIOS CALLS ({len(brief['bios_calls'])}):")
        for call in brief["bios_calls"][:10]:
            print(f"  {call['table']}:{call['function']} ra={call['ra']}")
        print()

    if brief.get("vfs_failures"):
        print(f"VFS FAILURES ({len(brief['vfs_failures'])}):")
        for vf in brief["vfs_failures"][:5]:
            print(f"  {vf['resource']} (LBA={vf['lba']})")
        print()

    if brief.get("errors"):
        print(f"ERRORS ({len(brief['errors'])}):")
        for err in brief["errors"][:5]:
            print(f"  [{err['type']}] {err['message']} at {err['pc']}")
        print()

    if brief.get("diagnostic_hints"):
        print("DIAGNOSTIC HINTS:")
        for hint in brief["diagnostic_hints"]:
            print(f"  → {hint}")
    print()
    print("=" * 70)


def main():
    parser = argparse.ArgumentParser(description="Phase 11: Agent Telemetry Integration")
    parser.add_argument("--telemetry", required=True, help="Path to telemetry JSON file")
    parser.add_argument("--triage", help="Path to triage log file (optional)")
    parser.add_argument("--output", "-o", help="Write parsed brief to JSON file")
    parser.add_argument("--summary", "-s", action="store_true", help="Print human-readable summary")
    args = parser.parse_args()

    telemetry = parse_telemetry(args.telemetry)
    triage = parse_triage(args.triage) if args.triage else None

    brief = build_agent_brief(telemetry, triage)

    if args.summary or not args.output:
        print_brief(brief)

    if args.output:
        with open(args.output, "w") as f:
            json.dump(brief, f, indent=2)
        print(f"Agent brief written to {args.output}")


if __name__ == "__main__":
    main()
