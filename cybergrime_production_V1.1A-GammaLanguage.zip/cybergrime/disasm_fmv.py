#!/usr/bin/env python3
"""
Disassemble DW7 EXE around CD-ROM dispatch and FMV setup functions using capstone.
Focus on:
  - CDROM_DISPATCH_RAM (0x80098664) — where Setloc commands are issued
  - FMV setup function (0x8008AB00) and callers (0x8008B41C, 0x8008B484)
  - BIOS B0 function 7 (Setloc) trampoline at 0x800A20F8
  - Search for instructions that load BCD MSF values (0x32, 0x34, 0x71)
    or LBA 146621 (0x23C7D)
"""

import struct
import sys
from capstone import Cs, CS_ARCH_MIPS, CS_MODE_MIPS32, CS_MODE_LITTLE_ENDIAN

EXE_PATH = r"c:\LuxAura\VoidWalkers_Project\DQLOSTTRANSLATION\translation\SLUSP012.06"
LOAD_ADDR = 0x80017F00
HEADER_SIZE = 0x800  # PS-X EXE header is 2048 bytes

def load_exe(path):
    with open(path, "rb") as f:
        data = f.read()
    return data

def ram_to_offset(ram_addr):
    return (ram_addr - LOAD_ADDR) + HEADER_SIZE

def offset_to_ram(file_off):
    return (file_off - HEADER_SIZE) + LOAD_ADDR

def disasm_range(data, start_ram, end_ram, label=""):
    md = Cs(CS_ARCH_MIPS, CS_MODE_MIPS32 | CS_MODE_LITTLE_ENDIAN)
    md.detail = True
    
    start_off = ram_to_offset(start_ram)
    end_off = ram_to_offset(end_ram)
    
    if start_off < 0 or end_off > len(data) or start_off >= end_off:
        print(f"  [!] Invalid range: {start_ram:#010x}-{end_ram:#010x}")
        return
    
    code = data[start_off:end_off]
    print(f"\n{'='*70}")
    print(f"  {label}: 0x{start_ram:08X} - 0x{end_ram:08X} ({end_ram-start_ram} bytes)")
    print(f"{'='*70}")
    
    for insn in md.disasm(code, start_ram):
        print(f"  0x{insn.address:08X}:  {insn.mnemonic:<8s} {insn.op_str}")

def search_immediates(data, target_values, label=""):
    """Search for MIPS instructions with specific immediate values."""
    md = Cs(CS_ARCH_MIPS, CS_MODE_MIPS32 | CS_MODE_LITTLE_ENDIAN)
    md.detail = True
    
    print(f"\n{'='*70}")
    print(f"  Searching for immediate values: {[hex(v) for v in target_values]}")
    print(f"{'='*70}")
    
    results = []
    # Scan code section (after header)
    for i in range(HEADER_SIZE, len(data) - 4, 4):
        word = struct.unpack("<I", data[i:i+4])[0]
        # Extract immediate (lower 16 bits) for I-type instructions
        imm = word & 0xFFFF
        # Sign-extend
        imm_se = imm - 0x10000 if imm & 0x8000 else imm
        
        for target in target_values:
            if imm == target or imm_se == target:
                ram = offset_to_ram(i)
                code = data[i:i+4]
                for insn in md.disasm(code, ram):
                    print(f"  0x{ram:08X}: {insn.mnemonic:<8s} {insn.op_str}  (imm=0x{imm:04X})")
                    results.append((ram, insn.mnemonic, insn.op_str, imm))
    return results

def search_lui_addiu_pairs(data, target_hi, target_lo, label=""):
    """Search for lui/addiu pairs that construct a specific 32-bit value."""
    print(f"\n{'='*70}")
    print(f"  Searching for lui+addiu pairs: hi=0x{target_hi:04X} lo=0x{target_lo:04X} -> 0x{(target_hi<<16)+target_lo:08X}")
    print(f"{'='*70}")
    
    results = []
    for i in range(HEADER_SIZE, len(data) - 8, 4):
        word1 = struct.unpack("<I", data[i:i+4])[0]
        word2 = struct.unpack("<I", data[i+4:i+8])[0]
        
        # Check if word1 is lui with immediate == target_hi
        op1 = (word1 >> 26) & 0x3F
        imm1 = word1 & 0xFFFF
        if op1 == 0x0F and imm1 == target_hi:  # lui opcode = 0x0F
            # Check if word2 is addiu with same register
            op2 = (word2 >> 26) & 0x3F
            rt1 = (word1 >> 16) & 0x1F
            rt2 = (word2 >> 16) & 0x1F
            rs2 = (word2 >> 21) & 0x1F
            imm2 = word2 & 0xFFFF
            if op2 == 0x09 and rs2 == rt1:  # addiu, same reg
                ram = offset_to_ram(i)
                val = (target_hi << 16) + imm2
                val_signed = val - 0x100000000 if val & 0x80000000 else val
                print(f"  0x{ram:08X}: lui  ${rt1}, 0x{target_hi:04X}  +  addiu ${rt2}, ${rs2}, 0x{imm2:04X}  -> 0x{val:08X}")
                results.append((ram, val))
    return results

def search_byte_pattern(data, pattern, label=""):
    """Search for a byte pattern in the EXE data."""
    print(f"\n{'='*70}")
    print(f"  Searching for byte pattern: {' '.join(f'{b:02X}' for b in pattern)}")
    print(f"{'='*70}")
    
    results = []
    for i in range(HEADER_SIZE, len(data) - len(pattern)):
        if data[i:i+len(pattern)] == bytes(pattern):
            ram = offset_to_ram(i)
            print(f"  Found at file offset 0x{i:X} (RAM 0x{ram:08X})")
            # Show surrounding context (16 bytes before and after)
            ctx_start = max(0, i - 16)
            ctx_end = min(len(data), i + len(pattern) + 16)
            ctx = data[ctx_start:ctx_end]
            hex_str = ' '.join(f'{b:02X}' for b in ctx)
            print(f"    Context: {hex_str}")
            results.append((i, ram))
    return results

def main():
    print("Loading DW7 EXE...")
    data = load_exe(EXE_PATH)
    print(f"  EXE size: {len(data)} bytes ({len(data)/1024:.1f} KB)")
    print(f"  Load address: 0x{LOAD_ADDR:08X}")
    print(f"  Header size: 0x{HEADER_SIZE:X}")
    
    # 1. Disassemble CD-ROM dispatch area
    disasm_range(data, 0x80098640, 0x800986C0, "CD-ROM dispatch area")
    
    # 2. Disassemble FMV setup function
    disasm_range(data, 0x8008AB00, 0x8008AC00, "FMV setup function")
    
    # 3. Disassemble FMV setup callers
    disasm_range(data, 0x8008B400, 0x8008B4A0, "FMV setup callers")
    
    # 4. Disassemble BIOS B0 function 7 trampoline (Setloc)
    disasm_range(data, 0x800A20E0, 0x800A2130, "BIOS B0 func 7 (Setloc) trampoline")
    
    # 5. Search for BCD MSF values as immediates
    search_immediates(data, [0x32, 0x34, 0x71, 0x23, 0x31, 0x15], "BCD MSF values")
    
    # 6. Search for LBA 146621 = 0x23C7D
    # lui 0x0002 + addiu 0x3C7D
    search_lui_addiu_pairs(data, 0x0002, 0x3C7D, "LBA 146621")
    # Also try lui 0x0003 + addiu (sign-extended) 0xC383 -> 0x23C7D? No, 0x30000-0x3C7D = not right
    # 146621 = 0x23C7D. lui $r, 0x0002 -> $r = 0x20000. addiu $r, $r, 0x3C7D -> 0x23C7D. Yes.
    
    # 7. Search for BCD byte pattern 32 34 71
    search_byte_pattern(data, [0x32, 0x34, 0x71], "BCD MSF 32:34:71")
    
    # 8. Search for BCD byte pattern 23 31 15 (DQ4 FMV)
    search_byte_pattern(data, [0x23, 0x31, 0x15], "BCD MSF 23:31:15")
    
    # 9. Disassemble around 0x80098898 (CDROM_DISPATCH from frankenstein_driver.h)
    disasm_range(data, 0x80098880, 0x800988F0, "CD-ROM command dispatch (0x80098898)")
    
    # 10. Search for lui/ori pairs loading 0x23C7D
    # ori opcode = 0x0D
    print(f"\n{'='*70}")
    print(f"  Searching for lui+ori pairs: 0x00023C7D")
    print(f"{'='*70}")
    for i in range(HEADER_SIZE, len(data) - 8, 4):
        word1 = struct.unpack("<I", data[i:i+4])[0]
        word2 = struct.unpack("<I", data[i+4:i+8])[0]
        op1 = (word1 >> 26) & 0x3F
        op2 = (word2 >> 26) & 0x3F
        if op1 == 0x0F:  # lui
            hi = word1 & 0xFFFF
            if op2 == 0x0D:  # ori
                lo = word2 & 0xFFFF
                val = (hi << 16) | lo
                if val == 0x23C7D:
                    ram = offset_to_ram(i)
                    print(f"  0x{ram:08X}: lui+ori -> 0x{val:08X} (LBA 146621)")
    
    # 11. Search for the value 146621 as a 32-bit little-endian or big-endian word
    print(f"\n{'='*70}")
    print(f"  Searching for 32-bit value 146621 (0x23C7D)")
    print(f"{'='*70}")
    target_le = struct.pack("<I", 146621)
    target_be = struct.pack(">I", 146621)
    for i in range(HEADER_SIZE, len(data) - 4):
        if data[i:i+4] == target_le:
            ram = offset_to_ram(i)
            print(f"  Found LE at file 0x{i:X} (RAM 0x{ram:08X})")
        if data[i:i+4] == target_be:
            ram = offset_to_ram(i)
            print(f"  Found BE at file 0x{i:X} (RAM 0x{ram:08X})")
    
    # 12. Search for 105690 (DQ4 FMV LBA) = 0x19CE2
    print(f"\n{'='*70}")
    print(f"  Searching for 32-bit value 105690 (0x19CE2) — DQ4 FMV LBA")
    print(f"{'='*70}")
    target_le = struct.pack("<I", 105690)
    target_be = struct.pack(">I", 105690)
    for i in range(HEADER_SIZE, len(data) - 4):
        if data[i:i+4] == target_le:
            ram = offset_to_ram(i)
            print(f"  Found LE at file 0x{i:X} (RAM 0x{ram:08X})")
        if data[i:i+4] == target_be:
            ram = offset_to_ram(i)
            print(f"  Found BE at file 0x{i:X} (RAM 0x{ram:08X})")

if __name__ == "__main__":
    main()
