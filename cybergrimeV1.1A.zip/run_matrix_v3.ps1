# PSX Matrix test with corrected FMV stubs (only 0x8008CAD0)
$base = "C:\LuxAura\VoidWalkers_Project\DQLOSTTRANSLATION"
$runner = "$base\cybergrime\psx_agent_runner.exe"
$disc = "$base\build_staging\dq4_reverse_a.bin"
$profile = "frank_fmv_v3"
$maxInstrs = 100000000
$jsonOut = "$base\cybergrime\telemetry_frank_fmv_v3.json"

Stop-Process -Name 'duckstation-qt-x64-ReleaseLTCG' -Force -ErrorAction SilentlyContinue
Stop-Process -Name 'psx_agent_runner' -Force -ErrorAction SilentlyContinue

Write-Output "=== PSX Matrix Test v3 (corrected stubs) ==="
Write-Output "Disc: $disc"
Write-Output "MaxInstrs: $maxInstrs"

$proc = Start-Process -FilePath $runner `
    -ArgumentList $disc, $profile, $maxInstrs, $jsonOut, 300000, "--vblank-pass" `
    -NoNewWindow -PassThru `
    -WorkingDirectory "$base\cybergrime" `
    -RedirectStandardOutput "matrix_v3_stdout.txt" `
    -RedirectStandardError "matrix_v3_stderr.txt"

Write-Output "Process started (PID: $($proc.Id))"
$proc | Wait-Process -Timeout 300 -ErrorAction SilentlyContinue

if (-not $proc.HasExited) {
    Write-Output "Process timed out, killing..."
    $proc | Stop-Process -Force
    Start-Sleep -Seconds 2
}

Write-Output "Exit code: $($proc.ExitCode)"

# Check telemetry
if (Test-Path $jsonOut) {
    Write-Output ""
    Write-Output "=== Telemetry JSON ==="
    $content = Get-Content $jsonOut -Raw
    Write-Output $content.Substring(0, [Math]::Min(3000, $content.Length))
} else {
    Write-Output "No telemetry JSON - checking diag log"
}

# Show key lines from diag log
Write-Output ""
Write-Output "=== Key diag lines ==="
$diag = Get-Content "$base\cybergrime\diag_traps.log" -ErrorAction SilentlyContinue
if ($diag) {
    $diag | Where-Object { $_ -match 'STATUS|VBPASS|FREEZE|CRASH|BOOT|CDROM|HBD|ERROR|ASSERT|FMV|VBlank.*exit|GPU_DIAG' } | Select-Object -First 30
    Write-Output "--- Last 15 lines ---"
    $diag | Select-Object -Last 15
}
