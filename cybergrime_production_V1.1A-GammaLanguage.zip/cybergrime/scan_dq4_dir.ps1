# Scan DQ4 disc ISO directory for file entries
$binPath = 'c:\LuxAura\VoidWalkers_Project\DQLOSTTRANSLATION\cybergrime\dq4_reverse_v97_nofmv.bin'
$fs = [System.IO.File]::OpenRead($binPath)
$buf = New-Object byte[] 2352

# Read PVD at LBA 16
$fs.Seek(16 * 2352 + 24, 'Begin') | Out-Null
$fs.Read($buf, 0, 2048) | Out-Null
$pvd = $buf[0..2047]

# Root directory record is at PVD offset 156 (34 bytes)
$rootLen = $pvd[158]
Write-Host "Root directory record length: $rootLen"

# Parse root directory LBA
$rootLBA = [BitConverter]::ToUInt32($pvd, 158 + 2)
$rootSize = [BitConverter]::ToUInt32($pvd, 158 + 10)
Write-Host "Root directory LBA: $rootLBA, Size: $rootSize bytes"

# Read root directory sector
$fs.Seek($rootLBA * 2352 + 24, 'Begin') | Out-Null
$dirBuf = New-Object byte[] 2048
$fs.Read($dirBuf, 0, 2048) | Out-Null

# Parse directory entries
$pos = 0
while ($pos -lt 2048) {
    $len = $dirBuf[$pos]
    if ($len -eq 0) { break }
    $extLBA = [BitConverter]::ToUInt32($dirBuf, $pos + 2)
    $extSize = [BitConverter]::ToUInt32($dirBuf, $pos + 10)
    $flags = $dirBuf[$pos + 25]
    $nameLen = $dirBuf[$pos + 32]
    $name = [System.Text.Encoding]::ASCII.GetString($dirBuf, $pos + 33, $nameLen)
    
    $type = if ($flags -band 0x02) { "DIR" } else { "FILE" }
    $sizeMB = [math]::Round($extSize / 1048576.0, 1)
    Write-Host ("  {0,-30} LBA={1,-8} Size={2,-12} ({3} MB) Flags=0x{4:X2}" -f $name, $extLBA, $extSize, $sizeMB, $flags)
    
    $pos += $len
}

# Also scan for STR/XA files by looking at sector submode bytes
Write-Host ""
Write-Host "=== Scanning for XA/STR (FMV) sectors ==="
# Check sectors around the DW7 FMV LBA (146621) on DQ4 disc
# and also scan for submode=0x44 (video) or submode=0x08 (data)
$fs.Seek(0, 'Begin') | Out-Null

# Check a few key LBAs
$checkLBAs = @(146621, 146622, 146623, 146624, 146625, 362, 363, 364, 365, 156336)
foreach ($lba in $checkLBAs) {
    $fs.Seek($lba * 2352, 'Begin') | Out-Null
    $fs.Read($buf, 0, 2352) | Out-Null
    $submode = $buf[16]
    $mode = $buf[15]
    $firstBytes = ($buf[24..27] | ForEach-Object { $_.ToString('X2') }) -join ' '
    Write-Host ("  LBA={0,-8} Mode=0x{1:X2} Submode=0x{2:X2} Data[0:3]={3}" -f $lba, $mode, $submode, $firstBytes)
}

$fs.Close()
