$binPath = 'c:\LuxAura\VoidWalkers_Project\DQLOSTTRANSLATION\cybergrime\dq4_reverse_v97_fmv.bin'
$fs = [System.IO.File]::OpenRead($binPath)
$buf = New-Object byte[] 4
# EXE is at sector 24, data starts at offset 24 in Mode 2 Form 1 sector
# File offset 0x92936 within the EXE
$exeFileOffset = 24 * 2352 + 24 + 0x92936
$fs.Seek($exeFileOffset, 'Begin') | Out-Null
$fs.Read($buf, 0, 3) | Out-Null
Write-Host ("Bytes at EXE offset 0x92936: {0:X2} {1:X2} {2:X2}" -f $buf[0], $buf[1], $buf[2])
if ($buf[0] -eq 0x23 -and $buf[1] -eq 0x31 -and $buf[2] -eq 0x15) {
    Write-Host "PATCH VERIFIED: BCD MSF is now 23:31:15 (DQ4 FMV location)"
} else {
    Write-Host "PATCH FAILED: Expected 23 31 15"
}
$fs.Close()
