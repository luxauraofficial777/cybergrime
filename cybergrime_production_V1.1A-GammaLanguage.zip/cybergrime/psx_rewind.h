#pragma once

// ============================================================================
// PSX Rewind System — Circular buffer of compact save states
// Maintains snapshots at regular intervals for time-rewind debugging.
// Stores CPU regs + minimal RAM diff (stack + modified pages) for efficiency.
// Header-only, dependency-free.
// ============================================================================

#include <cstdint>
#include <cstdio>
#include <cstring>
#include <vector>
#include <algorithm>
#include <functional>

class PSXRewind {
public:
    struct Snapshot {
        uint64_t  instr_count;
        uint32_t  pc;
        uint32_t  next_pc;
        uint32_t  hi, lo;
        uint32_t  cp0_status, cp0_cause, cp0_epc;
        uint32_t  regs[32];
        uint32_t  vblank_count;
        // Compact RAM snapshot: only stack region (0x801FF000-0x801FFFFF)
        // and key game state region (0x800B0000-0x800C0000)
        uint8_t   stack_snapshot[0x1000];   // 4KB stack
        uint8_t   game_state_snapshot[0x10000]; // 64KB game state region
    };

    std::vector<Snapshot> buffer;
    size_t head;
    size_t count;
    size_t capacity;
    uint32_t snapshot_interval;  // instructions between snapshots
    uint64_t last_snapshot_instr;
    bool enabled;

    PSXRewind() : head(0), count(0), capacity(600),
                  snapshot_interval(100000), last_snapshot_instr(0),
                  enabled(false) {
        buffer.resize(capacity);
    }

    void enable() { enabled = true; }
    void disable() { enabled = false; }
    void clear() { head = 0; count = 0; last_snapshot_instr = 0; }
    void set_capacity(size_t n) {
        capacity = n;
        buffer.resize(n);
        clear();
    }
    void set_interval(uint32_t instrs) { snapshot_interval = instrs; }

    // Check if it's time to take a snapshot
    bool should_snapshot(uint64_t current_instr) const {
        if (!enabled) return false;
        return (current_instr - last_snapshot_instr) >= snapshot_interval;
    }

    // Take a snapshot from CPU + memory
    // read_mem: function to read bytes from RAM
    void snapshot(uint64_t instr, uint32_t pc, uint32_t next_pc,
                  uint32_t hi, uint32_t lo,
                  uint32_t cp0_status, uint32_t cp0_cause, uint32_t cp0_epc,
                  const uint32_t regs[32], uint32_t vblank,
                  const std::function<void(uint32_t, uint8_t*, uint32_t)>& read_mem) {
        if (!enabled) return;

        Snapshot& s = buffer[head];
        s.instr_count = instr;
        s.pc = pc;
        s.next_pc = next_pc;
        s.hi = hi;
        s.lo = lo;
        s.cp0_status = cp0_status;
        s.cp0_cause = cp0_cause;
        s.cp0_epc = cp0_epc;
        s.vblank_count = vblank;
        memcpy(s.regs, regs, sizeof(s.regs));

        // Snapshot stack region (0x801FF000-0x801FFFFF)
        read_mem(0x801FF000, s.stack_snapshot, 0x1000);

        // Snapshot game state region (0x800B0000-0x800BFFFF)
        read_mem(0x800B0000, s.game_state_snapshot, 0x10000);

        head = (head + 1) % capacity;
        if (count < capacity) count++;
        last_snapshot_instr = instr;
    }

    // Get snapshot at rewind offset (0 = most recent, count-1 = oldest)
    const Snapshot* get_snapshot(size_t rewind_offset) const {
        if (rewind_offset >= count) return nullptr;
        size_t idx = (head + capacity - 1 - rewind_offset) % capacity;
        return &buffer[idx];
    }

    // Restore a snapshot to CPU + memory
    // write_mem: function to write bytes to RAM
    bool restore(size_t rewind_offset,
                 uint32_t& pc, uint32_t& next_pc,
                 uint32_t& hi, uint32_t& lo,
                 uint32_t& cp0_status, uint32_t& cp0_cause, uint32_t& cp0_epc,
                 uint32_t regs[32], uint64_t& instr, uint32_t& vblank,
                 const std::function<void(uint32_t, const uint8_t*, uint32_t)>& write_mem) const {
        const Snapshot* s = get_snapshot(rewind_offset);
        if (!s) return false;

        pc = s->pc;
        next_pc = s->next_pc;
        hi = s->hi;
        lo = s->lo;
        cp0_status = s->cp0_status;
        cp0_cause = s->cp0_cause;
        cp0_epc = s->cp0_epc;
        vblank = s->vblank_count;
        instr = s->instr_count;
        memcpy(regs, s->regs, sizeof(s->regs));

        // Restore stack
        write_mem(0x801FF000, s->stack_snapshot, 0x1000);
        // Restore game state
        write_mem(0x800B0000, s->game_state_snapshot, 0x10000);

        return true;
    }

    // Get number of available snapshots
    size_t available() const { return count; }

    // Get instruction range
    uint64_t oldest_instr() const {
        if (count == 0) return 0;
        const Snapshot* s = get_snapshot(count - 1);
        return s ? s->instr_count : 0;
    }

    uint64_t newest_instr() const {
        if (count == 0) return 0;
        const Snapshot* s = get_snapshot(0);
        return s ? s->instr_count : 0;
    }

    // Print status
    void print_status() const {
        printf("[REWIND] %zu/%zu snapshots, interval=%u instr\n",
               count, capacity, snapshot_interval);
        if (count > 0) {
            printf("  Range: instr %llu -> %llu (rewind %zu steps)\n",
                   (unsigned long long)oldest_instr(),
                   (unsigned long long)newest_instr(),
                   count - 1);
        }
    }
};
