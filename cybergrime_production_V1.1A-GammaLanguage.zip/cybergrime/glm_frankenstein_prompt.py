# cybergrime/glm_frankenstein_prompt.py
"""
Frankenstein Build Prompt Generator for GLM
Target: PSX DQ4 / DW7 Translation Layer 
Environment: DuckStation / C++ Surgery Engine Bridge
"""

PROMPT_SPEC = """
Act as an elite MIPS systems architect and low-level PlayStation 1 reverse-engineering specialist. 
We are building a production-ready, deterministic Frankenstein binary for the Dragon Quest IV localization on the Dragon Quest VII (DW7.EXE) engine framework.

### Current State & Constraints:
1. **BSS Clear Range:** Successfully narrowed from 0x800F4980 to 0x800BCCC8 to prevent wiping thread entries and Huffman trees[cite: 1, 3]. Build-time BSS patch applied at disc offset 0x096198 (`0x2462CCC8`)[cite: 3].
2. **HBD Block Headers:** Verified 24-byte layout (`end`, `block_id`, `hts`, `tree_end`, `text_end`, `unknown`)[cite: 1]. Per-block tree format requires re-encoding via `frankenstein_builder --tree-mode 3` for global DW7 parsing[cite: 1].
3. **Active Blocker (HF-005 / CD-ROM State Stall):** BSS narrow patch successfully preserves thread entry at `0x800D9E80`, but execution stalls at CD-ROM status/event flag polling loops (PC `0x80048004` / `0x800986F0`)[cite: 3, 5]. 
4. **Tooling & Verification:** 23/23 C++ ROM graft verifications pass[cite: 3]. Pipeline Rulebook Enforcer mandates zero blind commits and historical vector pre-checks[cite: 3].

### Your Task:
Write a high-precision, production-grade C++ patch routine or assembly injector that addresses the CD-ROM drive initialization / state-wait loop stall following the BSS clear phase. 

Provide:
1. Exact MIPS instruction sequence to intercept or bypass the CD-ROM status hang (addressing the hardware state mismatch between DQ4 sector layouts and DW7 engine expectations).
2. Integration code compatible with our C++ `InstrumentationBus` / surgical patcher framework (`cybergrime/psx_binary_ops.cpp`)[cite: 1, 7].
3. Verification assertions ensuring thread execution progresses past the polling loop into core game initialization without violating memory boundaries.
"""

if __name__ == "__main__":
    print(PROMPT_SPEC)
