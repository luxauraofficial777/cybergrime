#!/usr/bin/env python3
"""Copy DW7 STR/XA sectors to Frankenstein disc at the FMV seek LBA."""
import struct, sys, os, shutil

DW7_PATH = r"C:\LuxAura\VoidWalkers_Project\DQLOSTTRANSLATION\DW7D1\DW7D1.bin"
FRANK_PATH = sys.argv[1] if len(sys.argv) > 1 else r"C:\LuxAura\VoidWalkers_Project\DQLOSTTRANSLATION\build_staging\dq4_reverse_a.bin"
OUTPUT_PATH = sys.argv[2] if len(sys.argv) > 2 else r"C:\LuxAura\VoidWalkers_Project\DQLOSTTRANSLATION\build_staging\dq4_reverse_a_fmv.bin"

COPY_START = 146621
COPY_COUNT = 2000  # ~4.7MB of STR data — enough for Enix logo FMV

def main():
    print(f"Loading DW7 disc: {DW7_PATH}")
    with open(DW7_PATH, 'rb') as f:
        dw7 = f.read()
    
    print(f"Loading Frankenstein disc: {FRANK_PATH}")
    with open(FRANK_PATH, 'rb') as f:
        frank = bytearray(f.read())
    
    dw7_sectors = len(dw7) // 2352
    frank_sectors = len(frank) // 2352
    print(f"DW7: {dw7_sectors} sectors, Frank: {frank_sectors} sectors")
    
    copy_end = min(COPY_START + COPY_COUNT, dw7_sectors, frank_sectors)
    print(f"Copying LBA {COPY_START}-{copy_end-1} ({copy_end-COPY_START} sectors)...")
    
    copied = 0
    for lba in range(COPY_START, copy_end):
        dw7_off = lba * 2352
        frank_off = lba * 2352
        if frank[frank_off:frank_off+2352] != dw7[dw7_off:dw7_off+2352]:
            frank[frank_off:frank_off+2352] = dw7[dw7_off:dw7_off+2352]
            copied += 1
    
    print(f"Sectors copied: {copied}")
    
    # Also copy the RIFF/STR header sectors that may precede the FMV
    # Check for STR file start markers in DW7 around LBA 146600-146621
    str_start = None
    for lba in range(146600, 146621):
        off = lba * 2352
        submode = dw7[off + 15]  # subheader byte 3
        if submode == 0x02:  # STR video sector
            str_start = lba
            break
    if str_start and str_start < COPY_START:
        print(f"Found STR data starting at LBA {str_start}, copying from there...")
        for lba in range(str_start, COPY_START):
            if lba < frank_sectors:
                frank[lba*2352:lba*2352+2352] = dw7[lba*2352:lba*2352+2352]
                copied += 1
    
    print(f"Total sectors copied: {copied}")
    print(f"Writing output: {OUTPUT_PATH}")
    with open(OUTPUT_PATH, 'wb') as f:
        f.write(frank)
    
    # Write CUE
    cue_src = FRANK_PATH.replace('.bin', '.cue')
    cue_dst = OUTPUT_PATH.replace('.bin', '.cue')
    if os.path.exists(cue_src):
        with open(cue_src, 'r') as f:
            cue = f.read()
        cue = cue.replace(os.path.basename(FRANK_PATH), os.path.basename(OUTPUT_PATH))
        with open(cue_dst, 'w') as f:
            f.write(cue)
        print(f"CUE written: {cue_dst}")
    
    print(f"\nDone! Test with:")
    print(f"  duckstation-qt-x64-ReleaseLTCG.exe -batch -earlyconsole '{cue_dst}'")

if __name__ == '__main__':
    main()
