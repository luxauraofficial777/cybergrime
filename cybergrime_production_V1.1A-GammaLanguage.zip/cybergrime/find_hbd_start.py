import struct

path = r"c:\LuxAura\VoidWalkers_Project\DQLOSTTRANSLATION\Dragon Quest IV - Michibikareshi Mono Tachi (Japan).bin"
sector_size = 2352
data_offset = 24
user_size = 2048

with open(path, 'rb') as f:
    # Read ISO directory to find HBD file LBA
    # PVD at sector 16
    f.seek(16 * sector_size + data_offset)
    pvd = f.read(user_size)
    
    # Root directory record at PVD offset 158
    root_dir_rec = pvd[158:158+34]
    root_lba = struct.unpack_from('<I', root_dir_rec, 2)[0]
    root_size = struct.unpack_from('<I', root_dir_rec, 10)[0]
    print(f"Root directory: LBA={root_lba}, size={root_size}")
    
    # Read root directory
    f.seek(root_lba * sector_size + data_offset)
    dir_data = f.read(min(root_size, user_size * 4))
    
    # Parse directory records
    pos = 0
    while pos < len(dir_data):
        rec_len = dir_data[pos]
        if rec_len == 0:
            break
        if pos + 33 <= len(dir_data):
            file_lba = struct.unpack_from('<I', dir_data, pos + 2)[0]
            file_size_val = struct.unpack_from('<I', dir_data, pos + 10)[0]
            flags = dir_data[pos + 25]
            name_len = dir_data[pos + 32]
            name = dir_data[pos + 33:pos + 33 + name_len]
            # Filter out . and .. entries
            if name not in [b'\x00', b'\x01']:
                print(f"  File: name={name} LBA={file_lba} size={file_size_val} flags={flags:#x}")
        pos += rec_len
    
    # Now scan sectors 350-370 for hts=24 pattern
    print("\nScanning sectors 350-370 for hts=24:")
    for sec in range(350, 370):
        f.seek(sec * sector_size + data_offset)
        raw = f.read(user_size)
        # Check first 24 bytes as block header
        end, bid, hts, te, xe, unk = struct.unpack_from('<6I', raw, 0)
        if hts == 24 and 24 < end < 1048576:
            print(f"  Sector {sec}: VALID BLOCK end={end} bid={bid} hts={hts} tree_end={te} text_end={xe}")
        elif hts < 65536 and end < 1048576:
            print(f"  Sector {sec}: end={end} bid={bid} hts={hts} tree_end={te} text_end={xe}")
    
    # Also scan for the HBD header pattern across a wider range
    print("\nScanning sectors 150-400 for hts=24:")
    for sec in range(150, 400):
        f.seek(sec * sector_size + data_offset)
        raw = f.read(min(user_size * 4, 8192))
        for i in range(0, len(raw) - 24, 4):
            end, bid, hts, te, xe, unk = struct.unpack_from('<6I', raw, i)
            if hts == 24 and 24 < end < 1048576 and te > 0 and xe > 0 and te < end and xe < end:
                print(f"  Sector {sec}, offset {i}: VALID BLOCK end={end} bid={bid} hts={hts} tree_end={te} text_end={xe}")
                # Read tree metadata
                if i + xe + 10 <= len(raw):
                    ts, tm, tn = struct.unpack_from('<IIH', raw, i + xe)
                    print(f"    tree_start={ts} tree_middle={tm} tree_nodes={tn}")
                break
