#include "agent_harness.h"
#include "psx_test_station.h"
#include <commctrl.h>
#include <commdlg.h>

#pragma comment(lib, "comctl32.lib")
#pragma comment(lib, "comdlg32.lib")

// ============================================================================
// GLOBALS
// ============================================================================
static const char* APP_TITLE = "PSX TEST STATION — CyberGrime Debug";
static PSX_Memory mem;
static MIPS_CPU cpu;
static ULONG_PTR gdiplusToken;
static HWND g_hwnd = nullptr;
static HWND g_logList = nullptr;
static HWND g_regView = nullptr;
static HWND g_statusBar = nullptr;
static HWND g_btnRun = nullptr;
static HWND g_btnStep = nullptr;
static HWND g_btnLoad = nullptr;
static HWND g_btnReset = nullptr;
static char g_cdPath[512] = {0};

static bool g_running = false;
static bool g_loaded = false;
static int g_scrollPos = 0;
static int g_displayStart = 0;
static const int LINES_VISIBLE = 35;
static const int REG_LINES = 20;

// Deterministic glitch RNG for UI
static uint32_t cg_rng = 0xACE1u;
static uint32_t CG_Rand() {
    cg_rng ^= cg_rng << 13; cg_rng ^= cg_rng >> 17; cg_rng ^= cg_rng << 5;
    return cg_rng;
}
static float CG_RandF() { return (float)(CG_Rand() & 0xFFFF) / 65535.0f; }

static uint32_t cg_frame = 0;

// Flicker color modifier
static void CG_Flicker(uint32_t base, uint8_t& r, uint8_t& g, uint8_t& b, float intensity = 0.5f) {
    float t = (float)cg_frame;
    float flicker = 0.7f + 0.15f * sinf(t * 0.062f) + 0.08f * sinf(t * 0.189f);
    if (CG_RandF() < 0.02f * intensity) flicker *= 0.5f;
    flicker = fmaxf(0.3f, fminf(1.0f, flicker));
    r = (uint8_t)(CG::R(base) * flicker);
    g = (uint8_t)(CG::G(base) * flicker);
    b = (uint8_t)(CG::B(base) * flicker);
}

// ============================================================================
// UI RENDERING — CyberGrime Theme
// ============================================================================

static void DrawGrimeBackground(HDC hdc, int w, int h) {
    // Deep void background
    Gdiplus::Graphics gfx(hdc);
    Gdiplus::SolidBrush bg(Gdiplus::Color(CG::A(CG::VOID_BLACK), CG::R(CG::VOID_BLACK), CG::G(CG::VOID_BLACK), CG::B(CG::VOID_BLACK)));
    gfx.FillRectangle(&bg, 0, 0, w, h);

    // Subtle noise dots
    for (int i = 0; i < 200; i++) {
        int x = CG_Rand() % w;
        int y = CG_Rand() % h;
        uint8_t alpha = (uint8_t)(CG_Rand() % 30);
        Gdiplus::Color c(alpha, CG::R(CG::CYAN_DIM), CG::G(CG::CYAN_DIM), CG::B(CG::CYAN_DIM));
        Gdiplus::SolidBrush dot(c);
        gfx.FillRectangle(&dot, x, y, 1, 1);
    }
}

static void DrawScanlineOverlay(HDC hdc, int w, int h) {
    // Horizontal scanlines every 3 pixels
    for (int y = 0; y < h; y += 3) {
        Gdiplus::Color c(8, 0, 0, 0);
        Gdiplus::Graphics gfx(hdc);
        Gdiplus::SolidBrush line(c);
        gfx.FillRectangle(&line, 0, y, w, 1);
    }
}

static void DrawGrimePanel(HDC hdc, int x, int y, int w, int h, const char* title, bool active = false) {
    Gdiplus::Graphics gfx(hdc);
    
    // Panel background
    uint32_t bg_color = active ? CG::VOID_SURFACE : CG::VOID_DEEP;
    Gdiplus::SolidBrush panelBg(Gdiplus::Color(255, CG::R(bg_color), CG::G(bg_color), CG::B(bg_color)));
    gfx.FillRectangle(&panelBg, x, y, w, h);

    // Border — flickering cyan for active, dim for inactive
    uint8_t r, g, b;
    CG_Flicker(active ? CG::CYAN_GLOW : CG::CYAN_DIM, r, g, b, active ? 0.8f : 0.2f);
    Gdiplus::Pen border(Gdiplus::Color(255, r, g, b), 1);
    gfx.DrawRectangle(&border, x, y, w - 1, h - 1);

    // Title bar
    if (title) {
        Gdiplus::SolidBrush titleBg(Gdiplus::Color(255, CG::R(CG::VOID_ELEVATED), CG::G(CG::VOID_ELEVATED), CG::B(CG::VOID_ELEVATED)));
        gfx.FillRectangle(&titleBg, x, y, w, 20);
        gfx.DrawLine(&border, x, y + 20, x + w - 1, y + 20);

        // Title text with phosphor glow
        Gdiplus::FontFamily ff(L"Consolas");
        Gdiplus::Font font(&ff, 11, Gdiplus::FontStyleBold);
        Gdiplus::SolidBrush textClr(Gdiplus::Color(255, r, g, b));
        wchar_t wtitle[128];
        MultiByteToWideChar(CP_UTF8, 0, title, -1, wtitle, 128);
        Gdiplus::StringFormat sf;
        sf.SetAlignment(Gdiplus::StringAlignmentNear);
        sf.SetLineAlignment(Gdiplus::StringAlignmentCenter);
        gfx.DrawString(wtitle, -1, &font, Gdiplus::RectF(x + 6, y, (float)w - 12, 20), &sf, &textClr);
    }
}

static void DrawGlitchText(HDC hdc, int x, int y, const char* text, uint32_t color, int size = 12, bool glitch = false) {
    Gdiplus::Graphics gfx(hdc);
    Gdiplus::FontFamily ff(L"Consolas");
    Gdiplus::Font font(&ff, (float)size, Gdiplus::FontStyleRegular);

    uint8_t r, g, b;
    CG_Flicker(color, r, g, b, glitch ? 0.6f : 0.1f);

    // Phosphor glow — draw offset copy
    if (glitch) {
        Gdiplus::SolidBrush glow1(Gdiplus::Color(60, 255, 0, 0)); // red channel
        wchar_t wtext[256];
        MultiByteToWideChar(CP_UTF8, 0, text, -1, wtext, 256);
        gfx.DrawString(wtext, -1, &font, Gdiplus::PointF(x - 1, y), &glow1);
        Gdiplus::SolidBrush glow2(Gdiplus::Color(60, 0, 100, 255)); // blue channel
        gfx.DrawString(wtext, -1, &font, Gdiplus::PointF(x + 1, y), &glow2);
    }

    Gdiplus::SolidBrush textClr(Gdiplus::Color(255, r, g, b));
    wchar_t wtext[256];
    MultiByteToWideChar(CP_UTF8, 0, text, -1, wtext, 256);
    gfx.DrawString(wtext, -1, &font, Gdiplus::PointF((float)x, (float)y), &textClr);
}

// ============================================================================
// INSTRUCTION LOG RENDERING
// ============================================================================

// ============================================================================
// FRAMEBUFFER RENDERING — GPU Display
// ============================================================================

static void RenderFramebuffer(HDC hdc, int x, int y, int w, int h) {
    DrawGrimePanel(hdc, x, y, w, h, "GPU DISPLAY — PSX FRAMEBUFFER", true);

    int fbX = x + 4;
    int fbY = y + 24;
    int fbW = w - 8;
    int fbH = h - 28;

    // Render VRAM display area to framebuffer if dirty
    if (mem.fb_dirty) {
        mem.gpu_render_framebuffer();
    }

    // Create a DIB section from the framebuffer and stretch-blit it
    BITMAPINFO bmi = {0};
    bmi.bmiHeader.biSize = sizeof(BITMAPINFOHEADER);
    bmi.bmiHeader.biWidth = PSX_Memory::FB_W;
    bmi.bmiHeader.biHeight = -(LONG)PSX_Memory::FB_H;  // Top-down
    bmi.bmiHeader.biPlanes = 1;
    bmi.bmiHeader.biBitCount = 32;
    bmi.bmiHeader.biCompression = BI_RGB;

    HDC fbDC = CreateCompatibleDC(hdc);
    void* fbBits = nullptr;
    HBITMAP fbBmp = CreateDIBSection(hdc, &bmi, DIB_RGB_COLORS, &fbBits, nullptr, 0);
    if (fbBmp && fbBits) {
        memcpy(fbBits, mem.framebuffer, sizeof(mem.framebuffer));
        HBITMAP oldBmp = (HBITMAP)SelectObject(fbDC, fbBmp);

        // Set stretch mode for better quality
        SetStretchBltMode(hdc, COLORONCOLOR);

        // Calculate centered display maintaining aspect ratio
        int srcW = PSX_Memory::FB_W;
        int srcH = PSX_Memory::FB_H;
        float aspect = (float)srcW / (float)srcH;
        int dstW = fbW;
        int dstH = (int)(fbW / aspect);
        if (dstH > fbH) {
            dstH = fbH;
            dstW = (int)(fbH * aspect);
        }
        int dstX = fbX + (fbW - dstW) / 2;
        int dstY = fbY + (fbH - dstH) / 2;

        StretchBlt(hdc, dstX, dstY, dstW, dstH, fbDC, 0, 0, srcW, srcH, SRCCOPY);

        SelectObject(fbDC, oldBmp);
    }
    if (fbBmp) DeleteObject(fbBmp);
    if (fbDC) DeleteDC(fbDC);

    // Draw border around display area
    Gdiplus::Graphics gfx(hdc);
    Gdiplus::Pen border(Gdiplus::Color(255, CG::R(CG::CYAN_DIM), CG::G(CG::CYAN_DIM), CG::B(CG::CYAN_DIM)));
    gfx.DrawRectangle(&border, fbX, fbY, fbW - 1, fbH - 1);

    // Display info overlay
    char info[128];
    snprintf(info, 127, "Display: %s  VRAM: (%d,%d)  Res: %dx%d",
             mem.gpu_display_enabled ? "ON" : "OFF",
             mem.gpu_display_start_x, mem.gpu_display_start_y,
             mem.gpu_horiz_res, mem.gpu_vert_res);
    DrawGlitchText(hdc, fbX + 4, fbY + fbH - 14, info, CG::TEXT_MUTED, 9);
}

static void RenderLogPanel(HDC hdc, int x, int y, int w, int h) {
    DrawGrimePanel(hdc, x, y, w, h, "MIPS EXECUTION TRACE", true);

    int logY = y + 24;
    int lineH = 16;
    int maxLines = (h - 28) / lineH;

    int start = cpu.log_count - maxLines - g_scrollPos;
    if (start < 0) start = 0;
    int end = start + maxLines;
    if (end > cpu.log_count) end = cpu.log_count;

    for (int i = start; i < end; i++) {
        int ly = logY + (i - start) * lineH;
        if (ly >= y + h - 4) break;

        MIPS_CPU::LogEntry& e = cpu.log[i];

        // Color: branches in amber, memory ops in cyan, crashes in crimson
        uint32_t color = CG::TEXT_SECONDARY;
        if (strstr(e.desc, "jal") || strstr(e.desc, "jr ") || strstr(e.desc, "j 0x") ||
            strstr(e.desc, "beq") || strstr(e.desc, "bne") || strstr(e.desc, "bltz") ||
            strstr(e.desc, "bgez") || strstr(e.desc, "blez") || strstr(e.desc, "bgtz"))
            color = CG::AMBER;
        else if (strstr(e.desc, "lw") || strstr(e.desc, "sw") || strstr(e.desc, "lh") ||
                 strstr(e.desc, "sh") || strstr(e.desc, "lb") || strstr(e.desc, "sb") ||
                 strstr(e.desc, "lhu") || strstr(e.desc, "lbu"))
            color = CG::CYAN_GLOW;
        else if (strstr(e.desc, "UNKNOWN") || strstr(e.desc, "BREAK") || strstr(e.desc, "SYSCALL"))
            color = CG::CRIMSON;
        else if (strstr(e.desc, "lui") || strstr(e.desc, "addiu") || strstr(e.desc, "ori"))
            color = CG::PURPLE_GLOW;
        else if (strstr(e.desc, "BIOS"))
            color = CG::GREEN;

        char line[200];
        snprintf(line, 199, "[%7llu] 0x%08X: %s", e.instr_count, e.pc, e.desc);

        bool is_last = (i == end - 1);
        DrawGlitchText(hdc, x + 6, ly, line, color, 11, is_last && cg_frame % 30 < 3);
    }

    // Scroll indicator
    if (cpu.log_count > maxLines) {
        char scrollInfo[64];
        snprintf(scrollInfo, 63, "[%d/%d]", g_scrollPos, cpu.log_count - maxLines);
        DrawGlitchText(hdc, x + w - 80, y + 3, scrollInfo, CG::TEXT_MUTED, 10);
    }
}

// ============================================================================
// REGISTER VIEW RENDERING
// ============================================================================

static void RenderRegPanel(HDC hdc, int x, int y, int w, int h) {
    DrawGrimePanel(hdc, x, y, w, h, "CPU REGISTERS", true);

    int regY = y + 24;
    int lineH = 16;

    // PC and special registers
    char line[128];
    snprintf(line, 127, "PC  = 0x%08X", cpu.pc);
    DrawGlitchText(hdc, x + 6, regY, line, CG::CYAN_GLOW, 11, true);
    regY += lineH;

    snprintf(line, 127, "HI  = 0x%08X  LO = 0x%08X", cpu.hi, cpu.lo);
    DrawGlitchText(hdc, x + 6, regY, line, CG::TEXT_SECONDARY, 11);
    regY += lineH;

    snprintf(line, 127, "Instr: %llu", cpu.instructions);
    DrawGlitchText(hdc, x + 6, regY, line, CG::AMBER, 11);
    regY += lineH + 4;

    // GPR registers
    for (int i = 0; i < 32; i++) {
        if (regY >= y + h - 80) break;  // Leave room for HW state panel
        if (cpu.get_reg(i) != 0 || i == 29 || i == 31) {
            snprintf(line, 127, "%-4s = 0x%08X", cpu.rn(i), cpu.get_reg(i));
            uint32_t color = (i == 29) ? CG::GREEN : (cpu.get_reg(i) != 0 ? CG::TEXT_PRIMARY : CG::TEXT_MUTED);
            DrawGlitchText(hdc, x + 6, regY, line, color, 11);
        }
        regY += lineH;
    }

    // Hardware state panel
    regY = y + h - 76;
    DrawGrimePanel(hdc, x + 4, regY, w - 8, 36, "HW STATE", false);
    regY += 20;
    
    snprintf(line, 127, "VBlank: %u  Timer0: 0x%04X  Timer1: 0x%04X",
             mem.vblank_counter, mem.timer_count[0] & 0xFFFF, mem.timer_count[1] & 0xFFFF);
    DrawGlitchText(hdc, x + 8, regY, line, CG::GREEN, 10);
    regY += 14;
    
    snprintf(line, 127, "GPU: 0x%08X  I_STAT: 0x%08X  I_MASK: 0x%08X",
             mem.gpu_status, mem.intc_stat, mem.intc_mask);
    DrawGlitchText(hdc, x + 8, regY, line, CG::CYAN_DIM, 10);

    // Crash status
    if (cpu.crashed) {
        regY = y + h - 36;
        DrawGrimePanel(hdc, x + 4, regY, w - 8, 32, nullptr, false);
        snprintf(line, 127, "CRASHED: %s", cpu.crash_reason);
        DrawGlitchText(hdc, x + 8, regY + 4, line, CG::CRIMSON, 10, true);
    }
}

// ============================================================================
// STATUS BAR RENDERING
// ============================================================================

static void RenderStatusBar(HDC hdc, int x, int y, int w, int h) {
    Gdiplus::Graphics gfx(hdc);
    Gdiplus::SolidBrush bg(Gdiplus::Color(255, CG::R(CG::VOID_ELEVATED), CG::G(CG::VOID_ELEVATED), CG::B(CG::VOID_ELEVATED)));
    gfx.FillRectangle(&bg, x, y, w, h);

    Gdiplus::Pen border(Gdiplus::Color(255, CG::R(CG::CYAN_DIM), CG::G(CG::CYAN_DIM), CG::B(CG::CYAN_DIM)));
    gfx.DrawLine(&border, x, y, x + w, y);

    // Status dot
    uint32_t dot_color = cpu.crashed ? CG::CRIMSON : (g_running ? CG::GREEN : (g_loaded ? CG::AMBER : CG::TEXT_MUTED));
    uint8_t r, g, b;
    CG_Flicker(dot_color, r, g, b, 0.5f);
    Gdiplus::SolidBrush dot(Gdiplus::Color(255, r, g, b));
    gfx.FillRectangle(&dot, x + 8, y + 6, 6, 6);

    char status[256];
    const char* state = cpu.crashed ? "CRASHED" : (g_running ? "RUNNING" : (g_loaded ? "LOADED" : "NO DISC"));
    snprintf(status, 255, "  %s  |  Disc: %s  |  Instr: %llu  |  Pad: 0x%04X  |  WASD=dpad I=circle L=cross K=tri J=sqr Enter=start BS=select",
             state,
             g_loaded ? (strrchr(g_cdPath, '\\') ? strrchr(g_cdPath, '\\') + 1 : g_cdPath) : "none",
             cpu.instructions, mem.pad1_buttons);
    DrawGlitchText(hdc, x + 20, y + 4, status, CG::TEXT_SECONDARY, 11);
}

// ============================================================================
// BUTTON RENDERING
// ============================================================================

static void DrawCyberButton(HDC hdc, HWND btn, const char* label, bool hover = false) {
    RECT rc;
    GetWindowRect(btn, &rc);
    POINT origin = { rc.left, rc.top };
    ScreenToClient(g_hwnd, &origin);
    int w = rc.right - rc.left;
    int h = rc.bottom - rc.top;

    Gdiplus::Graphics gfx(hdc);
    uint32_t bg = hover ? CG::VOID_ELEVATED : CG::VOID_SURFACE;
    Gdiplus::SolidBrush brush(Gdiplus::Color(255, CG::R(bg), CG::G(bg), CG::B(bg)));
    gfx.FillRectangle(&brush, origin.x, origin.y, w, h);

    uint8_t r, g, b;
    CG_Flicker(hover ? CG::CYAN_GLOW : CG::CYAN_DIM, r, g, b, hover ? 0.6f : 0.2f);
    Gdiplus::Pen border(Gdiplus::Color(255, r, g, b));
    gfx.DrawRectangle(&border, origin.x, origin.y, w - 1, h - 1);

    Gdiplus::FontFamily ff(L"Consolas");
    Gdiplus::Font font(&ff, 10, Gdiplus::FontStyleBold);
    Gdiplus::SolidBrush textClr(Gdiplus::Color(255, r, g, b));
    wchar_t wlabel[64];
    MultiByteToWideChar(CP_UTF8, 0, label, -1, wlabel, 64);
    Gdiplus::StringFormat sf;
    sf.SetAlignment(Gdiplus::StringAlignmentCenter);
    sf.SetLineAlignment(Gdiplus::StringAlignmentCenter);
    gfx.DrawString(wlabel, -1, &font, Gdiplus::RectF((float)origin.x, (float)origin.y, (float)w, (float)h), &sf, &textClr);
}

// ============================================================================
// MAIN RENDER
// ============================================================================

static void Render(HDC hdc) {
    RECT rc;
    GetClientRect(g_hwnd, &rc);
    int w = rc.right - rc.left;
    int h = rc.bottom - rc.top;

    // Double buffer
    HDC memDC = CreateCompatibleDC(hdc);
    HBITMAP memBmp = CreateCompatibleBitmap(hdc, w, h);
    HBITMAP oldBmp = (HBITMAP)SelectObject(memDC, memBmp);

    DrawGrimeBackground(memDC, w, h);

    // Layout: top = button bar, left = framebuffer display, right = trace log + registers
    int margin = 8;
    int topPanelH = 40; // button bar
    int statusH = 24;
    int fbW = w * 2 / 5;  // Framebuffer takes 40% width
    int rightW = w - fbW - margin * 3;
    int logH = (h - topPanelH - statusH - margin * 3) * 2 / 3;
    int regH = (h - topPanelH - statusH - margin * 3) - logH - margin;

    // Button bar background
    DrawGrimePanel(memDC, margin, margin, w - margin * 2, topPanelH, nullptr, false);

    // Framebuffer panel (left)
    RenderFramebuffer(memDC, margin, topPanelH + margin * 2, fbW, h - topPanelH - statusH - margin * 3);

    // Trace log panel (right top)
    RenderLogPanel(memDC, fbW + margin * 2, topPanelH + margin * 2, rightW, logH);

    // Register panel (right bottom)
    RenderRegPanel(memDC, fbW + margin * 2, topPanelH + margin * 2 + logH + margin, rightW, regH);

    // Status bar
    RenderStatusBar(memDC, 0, h - statusH, w, statusH);

    // Scanline overlay
    DrawScanlineOverlay(memDC, w, h);

    // Blit to screen
    BitBlt(hdc, 0, 0, w, h, memDC, 0, 0, SRCCOPY);
    SelectObject(memDC, oldBmp);
    DeleteObject(memBmp);
    DeleteDC(memDC);

    cg_frame++;
}

// ============================================================================
// EMULATION THREAD
// ============================================================================

static DWORD WINAPI EmulationThread(LPVOID param) {
    g_running = true;
    cpu.crashed = false;
    cpu.hit_breakpoint = false;

    while (g_running && !cpu.crashed && !cpu.hit_breakpoint) {
        // Run in batches of 10000 instructions
        for (int i = 0; i < 10000 && g_running && !cpu.crashed && !cpu.hit_breakpoint; i++) {
            if (!cpu.step()) break;
        }
        // Flush log so we can read it while running
        if (cpu.log_file) fflush(cpu.log_file);
        // Yield to UI
        Sleep(0);
        InvalidateRect(g_hwnd, nullptr, FALSE);
    }

    g_running = false;
    if (cpu.crashed) {
        printf("[EMU] CRASHED at instr #%llu: %s\n", cpu.instructions, cpu.crash_reason);
    } else if (cpu.hit_breakpoint) {
        printf("[EMU] Hit breakpoint at instr #%llu PC=0x%08X\n", cpu.instructions, cpu.pc);
    } else {
        printf("[EMU] Stopped at instr #%llu PC=0x%08X\n", cpu.instructions, cpu.pc);
    }
    if (cpu.log_file) fflush(cpu.log_file);
    InvalidateRect(g_hwnd, nullptr, FALSE);
    return 0;
}

static void StartEmulation() {
    if (g_running) return;
    if (!g_loaded) return;
    HANDLE h = CreateThread(nullptr, 0, EmulationThread, nullptr, 0, nullptr);
    if (h) CloseHandle(h);
}

static void StepOnce() {
    if (g_running || !g_loaded) return;
    if (!cpu.step()) {
        InvalidateRect(g_hwnd, nullptr, FALSE);
    }
    InvalidateRect(g_hwnd, nullptr, FALSE);
}

// ============================================================================
// LOAD DISC
// ============================================================================

static void LoadDisc(const char* path) {
    printf("[LOAD] Opening disc: %s\n", path);
    strncpy(g_cdPath, path, 511);
    g_cdPath[511] = 0;

    if (!mem.load_cd(path)) {
        printf("[LOAD] FAILED to open disc image\n");
        MessageBoxA(g_hwnd, "Failed to open disc image", "Error", MB_ICONERROR);
        return;
    }
    printf("[LOAD] Disc opened OK\n");

    // Load EXE from LBA 24, 331 sectors
    uint32_t pc, dest, size;
    if (!mem.load_exe_from_cd(24, 331, pc, dest, size)) {
        printf("[LOAD] FAILED to load EXE from CD (LBA 24)\n");
        MessageBoxA(g_hwnd, "Failed to load EXE from disc", "Error", MB_ICONERROR);
        return;
    }
    printf("[LOAD] EXE loaded: PC=0x%08X dest=0x%08X size=0x%X\n", pc, dest, size);

    // Reset CPU and set initial state
    cpu.reset();
    cpu.read32 = cb_read32; cpu.read16 = cb_read16; cpu.read8 = cb_read8;
    cpu.write32 = cb_write32; cpu.write16 = cb_write16; cpu.write8 = cb_write8;
    cpu.mem_ctx = &mem;
    cpu.pc = pc;
    cpu.next_pc = pc + 4;
    cpu.set_reg(29, mem.exe_init_sp ? mem.exe_init_sp : 0x801FFF00); // $sp
    cpu.set_reg(31, 0x00000000); // $ra
    cpu.set_reg(28, mem.exe_init_gp ? mem.exe_init_gp : 0x800BC668); // $gp

    // Initialize HLE BIOS event system
    mem.init_events();
    mem.intc_mask = 0x01;  // Enable VBlank interrupt
    cpu.cp0_status = 0x40000101;  // IEc=1, IM bit 8=1, CU2

    // Open trace log file
    cpu.open_log("psx_trace.log");

    // Pre-set all flags the game polls during boot to skip CD-ROM init timeout
    // These are normally set by the BIOS CD-ROM interrupt handler after successful init
    uint32_t flag_off = mem.ram_offset(0x800B5310);
    mem.ram[flag_off] = 0x01;  // boot initialized
    
    uint32_t table1_off = mem.ram_offset(0x800B637C);
    mem.ram[table1_off]     = 0x3C;  // 0x80028A3C little-endian
    mem.ram[table1_off + 1] = 0x8A;
    mem.ram[table1_off + 2] = 0x02;
    mem.ram[table1_off + 3] = 0x80;

    // CD-ROM init done flags — game polls these in main loop
    mem.ram[mem.ram_offset(0x800B91CC)] = 0x01;  // CD init done
    mem.ram[mem.ram_offset(0x800B91CC)+1] = 0x01;
    mem.ram[mem.ram_offset(0x800B91CE)] = 0x01;  // CD ready
    mem.ram[mem.ram_offset(0x800B91CE)+1] = 0x01;
    mem.ram[mem.ram_offset(0x800B9164)] = 0x01;  // CD status flag
    
    // Event queue ready flag — game waits on this in main event loop
    mem.ram[mem.ram_offset(0x800B679C)] = 0x01;
    
    // Display initialized flag
    mem.ram[mem.ram_offset(0x800B5312)] = 0x01;
    mem.ram[mem.ram_offset(0x800B5312)+1] = 0x00;

    printf("[LOAD] Pre-init: boot flags, CD-ROM ready, event queue, display\n");

    g_loaded = true;
    g_mem = &mem;
    g_cpu = &cpu;

    printf("[LOAD] Disc loaded. Auto-starting emulation...\n");
    InvalidateRect(g_hwnd, nullptr, FALSE);
    
    // Auto-start emulation
    StartEmulation();
}

// ============================================================================
// WINDOW PROCEDURE
// ============================================================================

static LRESULT CALLBACK WndProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam) {
    switch (msg) {
    case WM_CREATE: {
        // Create buttons
        g_btnLoad = CreateWindowA("BUTTON", "LOAD DISC", WS_CHILD | WS_VISIBLE | BS_OWNERDRAW,
            12, 14, 100, 24, hwnd, (HMENU)1, nullptr, nullptr);
        g_btnRun = CreateWindowA("BUTTON", "RUN", WS_CHILD | WS_VISIBLE | BS_OWNERDRAW,
        120, 14, 60, 24, hwnd, (HMENU)2, nullptr, nullptr);
        g_btnStep = CreateWindowA("BUTTON", "STEP", WS_CHILD | WS_VISIBLE | BS_OWNERDRAW,
        188, 14, 60, 24, hwnd, (HMENU)3, nullptr, nullptr);
        g_btnReset = CreateWindowA("BUTTON", "RESET", WS_CHILD | WS_VISIBLE | BS_OWNERDRAW,
        256, 14, 60, 24, hwnd, (HMENU)4, nullptr, nullptr);
        return 0;
    }

    case WM_COMMAND: {
        switch (LOWORD(wParam)) {
        case 1: { // Load
            char filename[512] = {0};
            OPENFILENAMEA ofn = {0};
            ofn.lStructSize = sizeof(ofn);
            ofn.hwndOwner = hwnd;
            ofn.lpstrFilter = "PSX Disc Images (*.bin)\0*.bin\0All Files\0*.*\0";
            ofn.lpstrFile = filename;
            ofn.nMaxFile = 512;
            ofn.Flags = OFN_FILEMUSTEXIST | OFN_PATHMUSTEXIST;
            ofn.lpstrInitialDir = "C:\\LuxAura\\VoidWalkers_Project\\DQLOSTTRANSLATION";
            if (GetOpenFileNameA(&ofn)) {
                LoadDisc(filename);
            }
            return 0;
        }
        case 2: { // Run
            if (g_running) {
                g_running = false;
            } else {
                StartEmulation();
            }
            return 0;
        }
        case 3: { // Step
            StepOnce();
            return 0;
        }
        case 4: { // Reset
            g_running = false;
            if (g_loaded) {
                cpu.reset();
                cpu.read32 = cb_read32; cpu.read16 = cb_read16; cpu.read8 = cb_read8;
                cpu.write32 = cb_write32; cpu.write16 = cb_write16; cpu.write8 = cb_write8;
                cpu.mem_ctx = &mem;
                // Reload EXE
                uint32_t pc, dest, size;
                mem.load_exe_from_cd(24, 331, pc, dest, size);
                cpu.pc = pc;
                cpu.next_pc = pc + 4;
                cpu.set_reg(29, mem.exe_init_sp ? mem.exe_init_sp : 0x801FFF00);
                cpu.set_reg(31, 0x00000000);
                cpu.set_reg(28, mem.exe_init_gp ? mem.exe_init_gp : 0x800BC668);
                // Re-init HLE BIOS
                mem.init_events();
                mem.intc_mask = 0x01;
                cpu.cp0_status = 0x40000101;
                // Re-init boot flag and table[1]
                mem.ram[mem.ram_offset(0x800B5310)] = 0x01;
                uint32_t t1 = mem.ram_offset(0x800B637C);
                mem.ram[t1] = 0x3C; mem.ram[t1+1] = 0x8A; mem.ram[t1+2] = 0x02; mem.ram[t1+3] = 0x80;
                // Reset pad
                mem.pad1_buttons = 0xFFFF;
            }
            InvalidateRect(hwnd, nullptr, FALSE);
            return 0;
        }
        }
        return 0;
    }

    case WM_PAINT: {
        PAINTSTRUCT ps;
        HDC hdc = BeginPaint(hwnd, &ps);
        Render(hdc);
        EndPaint(hwnd, &ps);
        return 0;
    }

    case WM_DRAWITEM: {
        LPDRAWITEMSTRUCT dis = (LPDRAWITEMSTRUCT)lParam;
        const char* labels[] = { "LOAD DISC", "RUN", "STEP", "RESET" };
        int idx = dis->CtlID - 1;
        if (idx >= 0 && idx < 4) {
            bool hover = (dis->itemState & ODS_SELECTED) != 0;
            DrawCyberButton(dis->hDC, dis->hwndItem, labels[idx], hover);
        }
        return TRUE;
    }

    case WM_KEYDOWN: {
        // PSX Controller button bits (0 = pressed):
        // bit0=Select(0x0001), bit1=L3(0x0002), bit2=R3(0x0004), bit3=Start(0x0008)
        // bit4=Up(0x0010), bit5=Right(0x0020), bit6=Down(0x0040), bit7=Left(0x0080)
        // bit8=L2(0x0100), bit9=R2(0x0200), bit10=L1(0x0400), bit11=R1(0x0800)
        // bit12=Triangle(0x1000), bit13=Circle(0x2000), bit14=Cross(0x4000), bit15=Square(0x8000)
        switch (wParam) {
        case VK_F5: StartEmulation(); return 0;
        case VK_F10: StepOnce(); return 0;
        case VK_F1: { // Reset
            g_running = false;
            if (g_loaded) {
                cpu.reset();
                uint32_t pc, dest, size;
                mem.load_exe_from_cd(24, 331, pc, dest, size);
                cpu.pc = pc;
                cpu.next_pc = pc + 4;
                cpu.set_reg(29, mem.exe_init_sp ? mem.exe_init_sp : 0x801FFF00);
                cpu.set_reg(31, 0);
                cpu.set_reg(28, mem.exe_init_gp ? mem.exe_init_gp : 0x800BC668);
                mem.init_events();
                mem.intc_mask = 0x01;
                cpu.cp0_status = 0x40000101;
                mem.ram[mem.ram_offset(0x800B5310)] = 0x01;
                uint32_t t1 = mem.ram_offset(0x800B637C);
                mem.ram[t1] = 0x3C; mem.ram[t1+1] = 0x8A; mem.ram[t1+2] = 0x02; mem.ram[t1+3] = 0x80;
                mem.pad1_buttons = 0xFFFF;
            }
            InvalidateRect(hwnd, nullptr, FALSE);
            return 0;
        }
        case VK_PRIOR: // Page Up — scroll log up
            g_scrollPos = (g_scrollPos > 10) ? g_scrollPos - 10 : 0;
            InvalidateRect(hwnd, nullptr, FALSE);
            return 0;
        case VK_NEXT: // Page Down — scroll log down
            g_scrollPos += 10;
            InvalidateRect(hwnd, nullptr, FALSE);
            return 0;
        // PSX Controller mappings
        case 0x57: mem.pad1_buttons &= ~0x0010; return 0; // W = Up
        case 0x53: mem.pad1_buttons &= ~0x0040; return 0; // S = Down
        case 0x41: mem.pad1_buttons &= ~0x0080; return 0; // A = Left
        case 0x44: mem.pad1_buttons &= ~0x0020; return 0; // D = Right
        case 0x49: mem.pad1_buttons &= ~0x2000; return 0; // I = Circle
        case 0x4C: mem.pad1_buttons &= ~0x4000; return 0; // L = Cross
        case 0x4B: mem.pad1_buttons &= ~0x1000; return 0; // K = Triangle
        case 0x4A: mem.pad1_buttons &= ~0x8000; return 0; // J = Square
        case VK_RETURN: mem.pad1_buttons &= ~0x0008; return 0; // Enter = Start
        case VK_BACK: mem.pad1_buttons &= ~0x0001; return 0; // Backspace = Select
        case 0x51: mem.pad1_buttons &= ~0x0400; return 0; // Q = L1
        case 0x45: mem.pad1_buttons &= ~0x0800; return 0; // E = R1
        case 0x5A: mem.pad1_buttons &= ~0x0100; return 0; // Z = L2
        case 0x58: mem.pad1_buttons &= ~0x0200; return 0; // X = R2
        }
        return 0;
    }

    case WM_KEYUP: {
        switch (wParam) {
        case 0x57: mem.pad1_buttons |= 0x0010; return 0; // W = Up
        case 0x53: mem.pad1_buttons |= 0x0040; return 0; // S = Down
        case 0x41: mem.pad1_buttons |= 0x0080; return 0; // A = Left
        case 0x44: mem.pad1_buttons |= 0x0020; return 0; // D = Right
        case 0x49: mem.pad1_buttons |= 0x2000; return 0; // I = Circle
        case 0x4C: mem.pad1_buttons |= 0x4000; return 0; // L = Cross
        case 0x4B: mem.pad1_buttons |= 0x1000; return 0; // K = Triangle
        case 0x4A: mem.pad1_buttons |= 0x8000; return 0; // J = Square
        case VK_RETURN: mem.pad1_buttons |= 0x0008; return 0; // Enter = Start
        case VK_BACK: mem.pad1_buttons |= 0x0001; return 0; // Backspace = Select
        case 0x51: mem.pad1_buttons |= 0x0400; return 0; // Q = L1
        case 0x45: mem.pad1_buttons |= 0x0800; return 0; // E = R1
        case 0x5A: mem.pad1_buttons |= 0x0100; return 0; // Z = L2
        case 0x58: mem.pad1_buttons |= 0x0200; return 0; // X = R2
        }
        return 0;
    }

    case WM_TIMER:
        if (g_running || cpu.crashed) {
            InvalidateRect(hwnd, nullptr, FALSE);
        }
        return 0;

    case WM_ERASEBKGND:
        return 1; // We handle background in WM_PAINT

    case WM_SIZE:
        InvalidateRect(hwnd, nullptr, FALSE);
        return 0;

    case WM_CLOSE:
        g_running = false;
        cpu.close_log();
        DestroyWindow(hwnd);
        return 0;

    case WM_DESTROY:
        g_running = false;
        cpu.close_log();
        PostQuitMessage(0);
        return 0;
    }
    return DefWindowProcA(hwnd, msg, wParam, lParam);
}

// ============================================================================
// WINMAIN
// ============================================================================

int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrev, LPSTR cmdLine, int showCmd) {
    // Allocate console for debug output
    AllocConsole();
    freopen("CONOUT$", "w", stdout);
    freopen("CONOUT$", "w", stderr);
    printf("PSX TEST STATION — CyberGrime Debug\n");
    printf("====================================\n");

    // Init GDI+
    Gdiplus::GdiplusStartupInput gdiplusStartupInput;
    Gdiplus::GdiplusStartup(&gdiplusToken, &gdiplusStartupInput, nullptr);

    // Register window class
    WNDCLASSEXA wc = {0};
    wc.cbSize = sizeof(wc);
    wc.lpfnWndProc = WndProc;
    wc.hInstance = hInstance;
    wc.hCursor = LoadCursor(nullptr, IDC_ARROW);
    wc.lpszClassName = "PSXTestStation";
    wc.hbrBackground = nullptr; // We paint our own
    wc.style = CS_HREDRAW | CS_VREDRAW;
    RegisterClassExA(&wc);

    // Create window
    g_hwnd = CreateWindowExA(
        0, "PSXTestStation", APP_TITLE,
        WS_OVERLAPPEDWINDOW,
        CW_USEDEFAULT, CW_USEDEFAULT, 1200, 800,
        nullptr, nullptr, hInstance, nullptr);

    ShowWindow(g_hwnd, showCmd);
    UpdateWindow(g_hwnd);

    // Set timer for UI refresh
    SetTimer(g_hwnd, 1, 50, nullptr); // 20fps UI refresh

    // Auto-load disc if path provided on command line or default
    const char* defaultDisc = "C:\\LuxAura\\VoidWalkers_Project\\DQLOSTTRANSLATION\\Dragon Quest IV - Michibikareshi Mono Tachi (Japan).bin";
    if (cmdLine && cmdLine[0]) {
        // Strip quotes
        char path[512];
        strncpy(path, cmdLine, 511);
        if (path[0] == '"') { memmove(path, path+1, strlen(path)); char* q = strchr(path, '"'); if (q) *q = 0; }
        LoadDisc(path);
    } else {
        // Try auto-load default disc
        FILE* test = fopen(defaultDisc, "rb");
        if (test) {
            fclose(test);
            LoadDisc(defaultDisc);
        }
    }

    // Message loop
    MSG msg;
    while (GetMessage(&msg, nullptr, 0, 0)) {
        TranslateMessage(&msg);
        DispatchMessage(&msg);
    }

    Gdiplus::GdiplusShutdown(gdiplusToken);
    return (int)msg.wParam;
}
