#!/usr/bin/env python3
"""Disassemble the actual stall loop in DW7/Frankenstein EXE.
The CyberGrime trace shows the game looping at 0x800986C8-0x80098840.
Disassemble the full function to find where s2 is set."""
import struct, os
from capstone import Cs, CS_ARCH_MIPS, CS_MODE_MIPS32, CS_MODE_LITTLE_ENDIAN

def read_exe_from_disc(disc_path, exe_lba=24, sector_size=2352, user_offset=24, user_size=2048):
    with open(disc_path, 'rb') as f:
        exe_sectors = 340
        f.seek(exe_lba * sector_size)
        raw = f.read(exe_sectors * sector_size)
    exe_data = bytearray()
    for i in range(exe_sectors):
        sector = raw[i * sector_size:(i + 1) * sector_size]
        if len(sector) < user_offset + user_size:
            break
        exe_data += sector[user_offset:user_offset + user_size]
    return bytes(exe_data)

def disasm_range(exe_data, load_addr, start_ram, end_ram):
    code_offset = 0x800
    file_start = start_ram - load_addr + code_offset
    file_end = end_ram - load_addr + code_offset
    if file_start < 0 or file_end > len(exe_data):
        return "  (outside EXE)\n"
    code = exe_data[file_start:file_end]
    md = Cs(CS_ARCH_MIPS, CS_MODE_MIPS32 | CS_MODE_LITTLE_ENDIAN)
    lines = []
    for insn in md.disasm(code, start_ram):
        lines.append(f"  0x{insn.address:08X}: {insn.mnemonic:8s} {insn.op_str}")
    return '\n'.join(lines) + '\n'

base = r"C:\LuxAura\VoidWalkers_Project\DQLOSTTRANSLATION"
disc = os.path.join(base, "dq4_frankenstein_v41.bin")
load_addr = 0x80017F00

exe = read_exe_from_disc(disc)
print(f"EXE: {len(exe)} bytes, magic={exe[0:8]}")

# Disassemble the full function containing the stall loop
# The loop is at 0x800986C8-0x80098840, but the function starts earlier
# Look for the function prologue (addiu sp, sp, -XX) before 0x800986C8
print("\n=== STALL LOOP FUNCTION (0x80098500-0x80098900) ===")
print(disasm_range(exe, load_addr, 0x80098500, 0x80098900))

# Also disassemble the VSync wait function at 0x800965E8
print("\n=== VSYNC WAIT FUNCTION (0x800965E8-0x80096760) ===")
print(disasm_range(exe, load_addr, 0x800965E8, 0x80096760))

# And the display init check at 0x8009694C
print("\n=== DISPLAY INIT CHECK (0x8009694C-0x80096960) ===")
print(disasm_range(exe, load_addr, 0x8009694C, 0x80096960))

# Check what's at 0x800B5312 in the EXE (display init flag)
# This is in BSS, so it won't be in the EXE file, but let's check the offset
b5312_offset = 0x800B5312 - load_addr + 0x800
print(f"\n=== 0x800B5312 (display init flag) ===")
print(f"  RAM: 0x800B5312, EXE file offset: 0x{b5312_offset:X}")
if b5312_offset < len(exe):
    val = struct.unpack_from('<H', exe, b5312_offset)[0]
    print(f"  Value in EXE: 0x{val:04X}")
else:
    print(f"  Beyond EXE (BSS region, zeroed at runtime)")

# Check 0x800B63D8 (VBlank counter)
b63d8_offset = 0x800B63D8 - load_addr + 0x800
print(f"\n=== 0x800B63D8 (VBlank counter) ===")
print(f"  RAM: 0x800B63D8, EXE file offset: 0x{b63d8_offset:X}")
if b63d8_offset < len(exe):
    val = struct.unpack_from('<I', exe, b63d8_offset)[0]
    print(f"  Value in EXE: 0x{val:08X}")
else:
    print(f"  Beyond EXE (BSS region, zeroed at runtime)")

# Check 0x800F2C88 and 0x800F2C8C
for addr in [0x800F2C88, 0x800F2C8C]:
    off = addr - load_addr + 0x800
    print(f"\n=== 0x{addr:08X} ===")
    print(f"  EXE file offset: 0x{off:X}")
    if off < len(exe):
        val = struct.unpack_from('<I', exe, off)[0]
        print(f"  Value in EXE: 0x{val:08X}")
    else:
        print(f"  Beyond EXE (BSS region)")
