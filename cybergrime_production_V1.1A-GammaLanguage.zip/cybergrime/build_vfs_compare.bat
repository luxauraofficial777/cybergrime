@echo off
call "C:\Program Files (x86)\Microsoft Visual Studio\2022\BuildTools\VC\Auxiliary\Build\vcvars64.bat" >nul 2>&1
cl /EHsc /O2 /std:c++17 /D_CRT_SECURE_NO_WARNINGS vfs_compare.cpp /Fe:vfs_compare.exe
