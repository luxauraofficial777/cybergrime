#!/usr/bin/env python3
"""Trace initialization from 0x8004F344 and find VBlank handler setup."""
import struct

def read_sector(disc, lba):
    return disc[lba * 2352 + 24: lba * 2352 + 24 + 2048]

def read_exe_from_disc(disc_path, exe_lba, exe_size):
    with open(disc_path, 'rb') as f:
        disc = f.read()
    exe = bytearray()
    sectors = (exe_size + 2047) // 2048
    for i in range(sectors):
        exe.extend(read_sector(disc, exe_lba + i))
    return bytes(exe[:exe_size])

DISC = r'c:\LuxAura\VoidWalkers_Project\DQLOSTTRANSLATION\dq4_phaseC_build1.bin'
exe = read_exe_from_disc(DISC, 24, 960948)
DW7_DISC = r'c:\LuxAura\VoidWalkers_Project\DQLOSTTRANSLATION\DW7D1\DW7D1.bin'
dw7_exe = read_exe_from_disc(DW7_DISC, 24, 675840)

LOAD_ADDR = 0x80017F00
EXE_HEADER = 0x800

REG = ['zero','at','v0','v1','a0','a1','a2','a3','t0','t1','t2','t3','t4','t5','t6','t7','s0','s1','s2','s3','s4','s5','s6','s7','t8','t9','k0','k1','gp','sp','fp','ra']

def disasm(word, pc):
    op = (word >> 26) & 0x3f
    rs = (word >> 21) & 0x1f
    rt = (word >> 16) & 0x1f
    rd = (word >> 11) & 0x1f
    shamt = (word >> 6) & 0x1f
    funct = word & 0x3f
    imm = word & 0xffff
    simm = imm if imm < 0x8000 else imm - 0x10000
    target = (word & 0x3ffffff) << 2 | (pc & 0xf0000000)
    if word == 0: return 'nop'
    if op == 0:
        if funct == 0x20: return f'add {REG[rd]},{REG[rs]},{REG[rt]}'
        if funct == 0x21: return f'addu {REG[rd]},{REG[rs]},{REG[rt]}'
        if funct == 0x23: return f'subu {REG[rd]},{REG[rs]},{REG[rt]}'
        if funct == 0x24: return f'and {REG[rd]},{REG[rs]},{REG[rt]}'
        if funct == 0x25: return f'or {REG[rd]},{REG[rs]},{REG[rt]}'
        if funct == 0x26: return f'xor {REG[rd]},{REG[rs]},{REG[rt]}'
        if funct == 0x27: return f'nor {REG[rd]},{REG[rs]},{REG[rt]}'
        if funct == 0x08: return f'jr {REG[rs]}'
        if funct == 0x09: return f'jalr {REG[rd]},{REG[rs]}'
        if funct == 0x00: return f'sll {REG[rd]},{REG[rt]},{shamt}'
        if funct == 0x02: return f'srl {REG[rd]},{REG[rt]},{shamt}'
        if funct == 0x03: return f'sra {REG[rd]},{REG[rt]},{shamt}'
        if funct == 0x04: return f'sllv {REG[rd]},{REG[rt]},{REG[rs]}'
        if funct == 0x06: return f'srlv {REG[rd]},{REG[rt]},{REG[rs]}'
        if funct == 0x07: return f'srav {REG[rd]},{REG[rt]},{REG[rs]}'
        if funct == 0x2a: return f'slt {REG[rd]},{REG[rs]},{REG[rt]}'
        if funct == 0x2b: return f'sltu {REG[rd]},{REG[rs]},{REG[rt]}'
        if funct == 0x10: return f'mfhi {REG[rd]}'
        if funct == 0x12: return f'mflo {REG[rd]}'
        if funct == 0x18: return f'mult {REG[rs]},{REG[rt]}'
        if funct == 0x19: return f'multu {REG[rs]},{REG[rt]}'
        if funct == 0x1a: return f'div {REG[rs]},{REG[rt]}'
        if funct == 0x1b: return f'divu {REG[rs]},{REG[rt]}'
        return f'.special 0x{funct:02x}'
    if op == 0x01:
        if rt == 0: return f'bltz {REG[rs]},0x{pc + 4 + simm*4:08X}'
        if rt == 1: return f'bgez {REG[rs]},0x{pc + 4 + simm*4:08X}'
        return f'.regimm 0x{rt:02x}'
    if op == 0x02: return f'j 0x{target:08X}'
    if op == 0x03: return f'jal 0x{target:08X}'
    if op == 0x04: return f'beq {REG[rs]},{REG[rt]},0x{pc + 4 + simm*4:08X}'
    if op == 0x05: return f'bne {REG[rs]},{REG[rt]},0x{pc + 4 + simm*4:08X}'
    if op == 0x06: return f'blez {REG[rs]},0x{pc + 4 + simm*4:08X}'
    if op == 0x07: return f'bgtz {REG[rs]},0x{pc + 4 + simm*4:08X}'
    if op == 0x08: return f'addi {REG[rt]},{REG[rs]},{simm}'
    if op == 0x09: return f'addiu {REG[rt]},{REG[rs]},{simm}'
    if op == 0x0a: return f'slti {REG[rt]},{REG[rs]},{simm}'
    if op == 0x0b: return f'sltiu {REG[rt]},{REG[rs]},{simm}'
    if op == 0x0c: return f'andi {REG[rt]},{REG[rs]},0x{imm:04X}'
    if op == 0x0d: return f'ori {REG[rt]},{REG[rs]},0x{imm:04X}'
    if op == 0x0e: return f'xori {REG[rt]},{REG[rs]},0x{imm:04X}'
    if op == 0x0f: return f'lui {REG[rt]},0x{imm:04X}'
    if op == 0x20: return f'lb {REG[rt]},{simm}({REG[rs]})'
    if op == 0x21: return f'lh {REG[rt]},{simm}({REG[rs]})'
    if op == 0x23: return f'lw {REG[rt]},{simm}({REG[rs]})'
    if op == 0x24: return f'lbu {REG[rt]},{simm}({REG[rs]})'
    if op == 0x25: return f'lhu {REG[rt]},{simm}({REG[rs]})'
    if op == 0x28: return f'sb {REG[rt]},{simm}({REG[rs]})'
    if op == 0x29: return f'sh {REG[rt]},{simm}({REG[rs]})'
    if op == 0x2b: return f'sw {REG[rt]},{simm}({REG[rs]})'
    return f'.unk 0x{word:08X}'

def ram_to_file(ram):
    return ram - LOAD_ADDR + EXE_HEADER

def disasm_range(exe, start_ram, count, label=""):
    print(f"\n=== {label}: 0x{start_ram:08X} ({count} instructions) ===")
    for i in range(count):
        ram = start_ram + i * 4
        off = ram_to_file(ram)
        if 0 <= off < len(exe) - 4:
            word = struct.unpack_from('<I', exe, off)[0]
            d = disasm(word, ram)
            # Check if this word is different from DW7
            dw_off = ram_to_file(ram)
            dw_word = struct.unpack_from('<I', dw7_exe, dw_off)[0] if dw_off < len(dw7_exe) - 4 else 0
            marker = " *PATCHED*" if dw_word != word and dw_off < len(dw7_exe) - 4 else ""
            print(f"  0x{ram:08X}: 0x{word:08X}  {d}{marker}")

# Main init at 0x8004F344 (where PC0 jumps after BSS clear)
disasm_range(exe, 0x8004F344, 80, "MAIN INIT (0x8004F344)")

# Check callers of the stall function
disasm_range(exe, 0x80096660, 30, "CALLER OF STALL FUNC (0x80096698)")

# Search for writes to 0x800B63D8 (VBlank counter) - this is where the handler increments it
print("\n=== SEARCH FOR WRITES TO 0x800B63D8 (VBlank counter) ===")
target_addr = 0x800B63D8
# lui rt, 0x800B = 0x3C02800B (for v0) or similar
# Then sw rt, 0x63D8(rs) where rs has 0x800B
for off in range(0x800, len(exe) - 4, 4):
    word = struct.unpack_from('<I', exe, off)[0]
    op = (word >> 26) & 0x3f
    if op == 0x2b:  # sw
        rs = (word >> 21) & 0x1f
        rt = (word >> 16) & 0x1f
        imm = word & 0xffff
        simm = imm if imm < 0x8000 else imm - 0x10000
        # Check if this could be sw to 0x800B63D8
        # Need lui rs, 0x800B before this
        if imm == 0x63D8 or (simm == 0x63D8):
            ram = LOAD_ADDR + off - EXE_HEADER
            # Check previous instruction for lui
            if off >= 4:
                prev = struct.unpack_from('<I', exe, off - 4)[0]
                prev_op = (prev >> 26) & 0x3f
                prev_rt = (prev >> 16) & 0x1f
                prev_imm = prev & 0xffff
                if prev_op == 0x0f and prev_imm == 0x800B:  # lui rs, 0x800B
                    print(f"  0x{ram:08X}: sw {REG[rt]},0x{simm:04X}({REG[rs]}) [lui {REG[prev_rt]},0x800B before]")

# Also search for the VBlank interrupt handler setup
# Look for writes to interrupt handler registers (0xBF801070 = I_STAT, 0xBF801074 = I_MASK)
# Or calls to BIOS EnqueueTimerVblank (C:3) or ChangeClearRCnt (C:0A)
print("\n=== SEARCH FOR BIOS CALLS (syscall) ===")
for off in range(0x800, len(exe) - 4, 4):
    word = struct.unpack_from('<I', exe, off)[0]
    # syscall = 0x0000000C
    if word == 0x0000000C:
        ram = LOAD_ADDR + off - EXE_HEADER
        # Check surrounding context for a0 (function number)
        for j in range(-4, 1):
            ctx_off = off + j * 4
            if 0 <= ctx_off < len(exe) - 4:
                ctx_word = struct.unpack_from('<I', exe, ctx_off)[0]
                ctx_op = (ctx_word >> 26) & 0x3f
                if ctx_op == 0x09:  # addiu
                    rt = (ctx_word >> 16) & 0x1f
                    simm = ctx_word & 0xffff
                    if simm >= 0x8000: simm -= 0x10000
                    if rt == 4:  # a0
                        print(f"  0x{ram:08X}: syscall (a0={simm})")
                        break

# Check the disc-check patched function at 0x800506CC
disasm_range(exe, 0x800506C0, 20, "DISC-CHECK STUB (0x800506CC)")
