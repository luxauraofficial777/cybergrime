#!/usr/bin/env python3
"""Check disc-check patches and their effect on the stall."""
import struct

def read_sector(disc, lba):
    return disc[lba * 2352 + 24: lba * 2352 + 24 + 2048]

def read_exe_from_disc(disc_path, exe_lba, exe_size):
    with open(disc_path, 'rb') as f:
        disc = f.read()
    exe = bytearray()
    sectors = (exe_size + 2047) // 2048
    for i in range(sectors):
        exe.extend(read_sector(disc, exe_lba + i))
    return bytes(exe[:exe_size])

DISC = r'c:\LuxAura\VoidWalkers_Project\DQLOSTTRANSLATION\dq4_phaseC_build1.bin'
exe = read_exe_from_disc(DISC, 24, 960948)
DW7_DISC = r'c:\LuxAura\VoidWalkers_Project\DQLOSTTRANSLATION\DW7D1\DW7D1.bin'
dw7_exe = read_exe_from_disc(DW7_DISC, 24, 675840)

LOAD_ADDR = 0x80017F00
EXE_HEADER = 0x800

REG = ['zero','at','v0','v1','a0','a1','a2','a3','t0','t1','t2','t3','t4','t5','t6','t7','s0','s1','s2','s3','s4','s5','s6','s7','t8','t9','k0','k1','gp','sp','fp','ra']

def disasm(word, pc):
    op = (word >> 26) & 0x3f
    rs = (word >> 21) & 0x1f
    rt = (word >> 16) & 0x1f
    rd = (word >> 11) & 0x1f
    shamt = (word >> 6) & 0x1f
    funct = word & 0x3f
    imm = word & 0xffff
    simm = imm if imm < 0x8000 else imm - 0x10000
    target = (word & 0x3ffffff) << 2 | (pc & 0xf0000000)
    if word == 0: return 'nop'
    if op == 0:
        if funct == 0x20: return f'add {REG[rd]},{REG[rs]},{REG[rt]}'
        if funct == 0x21: return f'addu {REG[rd]},{REG[rs]},{REG[rt]}'
        if funct == 0x23: return f'subu {REG[rd]},{REG[rs]},{REG[rt]}'
        if funct == 0x24: return f'and {REG[rd]},{REG[rs]},{REG[rt]}'
        if funct == 0x25: return f'or {REG[rd]},{REG[rs]},{REG[rt]}'
        if funct == 0x26: return f'xor {REG[rd]},{REG[rs]},{REG[rt]}'
        if funct == 0x27: return f'nor {REG[rd]},{REG[rs]},{REG[rt]}'
        if funct == 0x08: return f'jr {REG[rs]}'
        if funct == 0x09: return f'jalr {REG[rd]},{REG[rs]}'
        if funct == 0x00: return f'sll {REG[rd]},{REG[rt]},{shamt}'
        if funct == 0x02: return f'srl {REG[rd]},{REG[rt]},{shamt}'
        if funct == 0x03: return f'sra {REG[rd]},{REG[rt]},{shamt}'
        if funct == 0x2a: return f'slt {REG[rd]},{REG[rs]},{REG[rt]}'
        if funct == 0x2b: return f'sltu {REG[rd]},{REG[rs]},{REG[rt]}'
        if funct == 0x10: return f'mfhi {REG[rd]}'
        if funct == 0x12: return f'mflo {REG[rd]}'
        if funct == 0x18: return f'mult {REG[rs]},{REG[rt]}'
        if funct == 0x19: return f'multu {REG[rs]},{REG[rt]}'
        return f'.special 0x{funct:02x}'
    if op == 0x01:
        if rt == 0: return f'bltz {REG[rs]},0x{pc + 4 + simm*4:08X}'
        if rt == 1: return f'bgez {REG[rs]},0x{pc + 4 + simm*4:08X}'
        return f'.regimm 0x{rt:02x}'
    if op == 0x02: return f'j 0x{target:08X}'
    if op == 0x03: return f'jal 0x{target:08X}'
    if op == 0x04: return f'beq {REG[rs]},{REG[rt]},0x{pc + 4 + simm*4:08X}'
    if op == 0x05: return f'bne {REG[rs]},{REG[rt]},0x{pc + 4 + simm*4:08X}'
    if op == 0x06: return f'blez {REG[rs]},0x{pc + 4 + simm*4:08X}'
    if op == 0x07: return f'bgtz {REG[rs]},0x{pc + 4 + simm*4:08X}'
    if op == 0x08: return f'addi {REG[rt]},{REG[rs]},{simm}'
    if op == 0x09: return f'addiu {REG[rt]},{REG[rs]},{simm}'
    if op == 0x0a: return f'slti {REG[rt]},{REG[rs]},{simm}'
    if op == 0x0b: return f'sltiu {REG[rt]},{REG[rs]},{simm}'
    if op == 0x0c: return f'andi {REG[rt]},{REG[rs]},0x{imm:04X}'
    if op == 0x0d: return f'ori {REG[rt]},{REG[rs]},0x{imm:04X}'
    if op == 0x0e: return f'xori {REG[rt]},{REG[rs]},0x{imm:04X}'
    if op == 0x0f: return f'lui {REG[rt]},0x{imm:04X}'
    if op == 0x20: return f'lb {REG[rt]},{simm}({REG[rs]})'
    if op == 0x21: return f'lh {REG[rt]},{simm}({REG[rs]})'
    if op == 0x23: return f'lw {REG[rt]},{simm}({REG[rs]})'
    if op == 0x24: return f'lbu {REG[rt]},{simm}({REG[rs]})'
    if op == 0x25: return f'lhu {REG[rt]},{simm}({REG[rs]})'
    if op == 0x28: return f'sb {REG[rt]},{simm}({REG[rs]})'
    if op == 0x29: return f'sh {REG[rt]},{simm}({REG[rs]})'
    if op == 0x2b: return f'sw {REG[rt]},{simm}({REG[rs]})'
    return f'.unk 0x{word:08X}'

def ram_to_file(ram):
    return ram - LOAD_ADDR + EXE_HEADER

def disasm_both(frank_exe, dw7_exe, start_ram, count, label=""):
    print(f"\n=== {label}: 0x{start_ram:08X} ({count} instructions) ===")
    for i in range(count):
        ram = start_ram + i * 4
        off = ram_to_file(ram)
        fw = struct.unpack_from('<I', frank_exe, off)[0] if off < len(frank_exe) - 4 else 0
        dw = struct.unpack_from('<I', dw7_exe, off)[0] if off < len(dw7_exe) - 4 else 0
        fd = disasm(fw, ram)
        dd = disasm(dw, ram)
        marker = " *PATCHED*" if fw != dw and off < len(dw7_exe) - 4 else ""
        print(f"  0x{ram:08X}: FRANK=0x{fw:08X} {fd}{marker}")
        if fw != dw and off < len(dw7_exe) - 4:
            print(f"           DW7  =0x{dw:08X} {dd}")

# The disc-check patches are at these offsets locations:
# 0x6112C, 0x611D8, 0x613B8, 0x614A4, 0x614F8, 0x7308C, 0x61424, 0x61520, 0x61360
# Convert to RAM:
# file_off = ram - 0x80017F00 + 0x800
# ram = file_off + 0x80017F00 - 0x800 = file_off + 0x80017F00 - 0x800
dc_offsets = [0x6112C, 0x611D8, 0x613B8, 0x614A4, 0x614F8, 0x7308C, 0x61424, 0x61520, 0x61360]
print("=== DISC-CHECK PATCH SITES ===")
for off in dc_offsets:
    ram = off - EXE_HEADER + LOAD_ADDR
    fw = struct.unpack_from('<I', exe, off)[0]
    dw = struct.unpack_from('<I', dw7_exe, off)[0]
    print(f"  file=0x{off:X} ram=0x{ram:08X}:")
    print(f"    FRANK: 0x{fw:08X} = {disasm(fw, ram)}")
    print(f"    DW7:   0x{dw:08X} = {disasm(dw, ram)}")

# Show context around each patch
for off in dc_offsets:
    ram = off - EXE_HEADER + LOAD_ADDR
    start_ram = ram - 16
    count = 12
    disasm_both(exe, dw7_exe, start_ram, count, f"PATCH CONTEXT at 0x{ram:08X}")

# Also check the neutralize patch at 0x387CC
disasm_both(exe, dw7_exe, 0x387CC - EXE_HEADER + LOAD_ADDR - 16, 16, "NEUTRALIZE PATCH at 0x387CC")

# Check the BSS clear range - is it correct?
print("\n=== BSS CLEAR RANGE ===")
print(f"  Start: 0x800BCCC8 (lui v0,0x800C; addiu v0,v0,-13112)")
print(f"  End:   0x800E9E80 (lui v1,0x800E; addiu v1,v1,-24960)")
print(f"  Size:  {0x800E9E80 - 0x800BCCC8} bytes ({0x800E9E80 - 0x800BCCC8:#x})")

# Check the text_size
text_size = struct.unpack_from('<I', exe, 0x1C)[0]
print(f"\n=== TEXT SIZE ===")
print(f"  Frankenstein: 0x{text_size:X} ({text_size})")
print(f"  DW7: 0x{struct.unpack_from('<I', dw7_exe, 0x1C)[0]:X}")
print(f"  Frank EXE total: {len(exe)} bytes")
print(f"  DW7 EXE total: {len(dw7_exe)} bytes")
print(f"  Frank text_size + 0x800 = 0x{text_size + 0x800:X} vs EXE size {len(exe):X}")
print(f"  Extra bytes after text: {len(exe) - (text_size + 0x800)} bytes")

# Check what's in the extended region (after DW7 text_size)
dw7_text = struct.unpack_from('<I', dw7_exe, 0x1C)[0]
print(f"\n=== EXTENDED REGION (after DW7 text end at file 0x{dw7_text + 0x800:X}) ===")
ext_start = dw7_text + 0x800
for i in range(0, min(200, len(exe) - ext_start), 4):
    off = ext_start + i
    word = struct.unpack_from('<I', exe, off)[0]
    ram = LOAD_ADDR + off - EXE_HEADER
    d = disasm(word, ram)
    if word != 0:
        print(f"  0x{ram:08X}: 0x{word:08X}  {d}")

# Check the hybrid tree at 0xA5000
tree_off = 0xA5000
print(f"\n=== HYBRID TREE at file offset 0x{tree_off:X} ===")
if tree_off + 16 <= len(exe):
    sig = struct.unpack_from('<I', exe, tree_off)[0]
    print(f"  Signature: 0x{sig:08X}")
    for i in range(0, 32, 4):
        val = struct.unpack_from('<I', exe, tree_off + i)[0]
        print(f"  [{i:3d}] 0x{val:08X}")
