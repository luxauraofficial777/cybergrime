# The DW7 EXE doesn't directly access CDROM hardware registers.
# It must use BIOS calls. Let me look at this differently.
# 
# The BIOS B0 function table is at address 0xB0.
# The trampolines at 0x800A20xx do: li t2, 0xB0/0xA0/0xC0; jr t2; li t1, N
# This means the game calls BIOS functions via these trampolines.
#
# For CDROM_Setloc (B0 func 7), the trampoline is at 0x800A20F8.
# But the callers set a0 to 0xF0000009 etc, which doesn't make sense for Setloc.
#
# WAIT - maybe I miscounted. Let me look at the trampoline table more carefully.
# The trampolines are sequential:
# 0x800A20A8: li t2, 0xB0; jr t2; li t1, 0x38  (B0 func 56)
# 0x800A20B8: li t2, 0xA0; jr t2; li t1, 0x44  (A0 func 68)
# 0x800A20C8: li t2, 0xA0; jr t2; li t1, 0x49  (A0 func 73)
# 0x800A20E0: li t2, 0xA0; jr t2; li t1, 0x72  (A0 func 114)
# 0x800A20F8: li t2, 0xB0; jr t2; li t1, 0x07  (B0 func 7 = Setloc)
# 0x800A2108: li t2, 0xB0; jr t2; li t1, 0x08  (B0 func 8 = ReadN)
# etc.
#
# The callers of 0x800A20F8 are NOT calling Setloc.
# They're calling the trampoline which dispatches to B0 func 7.
# But a0=0xF0000009 is a hardware register address, not an MSF pointer.
#
# Actually, B0 func 7 might NOT be Setloc in this game's BIOS version.
# Let me check: PSX BIOS B0 functions:
# 0: CDROM_init
# 1: CDROM_get_status  
# 2: CDROM_set_loc (NOT 7!)
# ...
# Actually different sources list different numbers. Let me check the standard:
# B0-7 = CDROM_Setloc? Or is it something else?
# 
# Standard PSX BIOS B0 functions:
# B0-0: ChangeClearPadInt
# B0-1: CDROM_init  
# B0-2: CDROM_set_loc (TOC)
# B0-3: CDROM_read_sync
# B0-4: CDROM_get_status
# B0-5: CDROM_set_mode
# B0-6: CDROM_get_mode
# B0-7: CDROM_set_loc (MSF)  <- THIS IS SETLOC
# B0-8: CDROM_read
# B0-9: CDROM_read_async
# ...
# 
# Actually I'm not sure about the exact numbering. Let me look at what
# the callers actually do and what makes sense.
#
# Caller at 0x80091C78: a0 = 0xF0000009, a1 = 0x20
# If B0-7 is Setloc, a0 should be pointer to MSF buffer.
# 0xF0000009 is not a valid pointer.
#
# Maybe B0-7 is NOT Setloc. Let me look at what function would take
# a hardware register address and a value.
# That sounds like it could be a GPU/SIO interrupt register write.
#
# Let me search for the ACTUAL Setloc by looking at the DuckStation log.
# The log shows Setloc 32:34:71. The BCD bytes 0x32 0x34 0x71 must be
# written to CDROM registers 0x1F801AD0, 0x1F801AD1, 0x1F801AD2.
# 
# Maybe the game uses a different mechanism - perhaps through the
# CDROM library functions that are part of the game's own code,
# not BIOS calls.
#
# Let me search for the function that the XA/STR function (0x8008AEF4)
# calls. It calls 0x8008B65C at the start. Let me trace that.

$exePath = 'c:\LuxAura\VoidWalkers_Project\DQLOSTTRANSLATION\translation\SLUSP012.06'
$bytes = [System.IO.File]::ReadAllBytes($exePath)
$loadAddr = 0x80017F00

$rn = @('zero','at','v0','v1','a0','a1','a2','a3','t0','t1','t2','t3','t4','t5','t6','t7','s0','s1','s2','s3','s4','s5','s6','s7','t8','t9','k0','k1','gp','sp','fp','ra')

function D($ramAddr, $count) {
    $fileOff = $ramAddr - $loadAddr + 0x800
    for ($j = 0; $j -lt $count; $j++) {
        $off = $fileOff + $j * 4
        if ($off -lt 0 -or $off + 3 -ge $bytes.Length) { Write-Host "  [oor]"; continue }
        $val = [BitConverter]::ToUInt32($bytes, $off)
        $ram = $loadAddr + $off - 0x800
        $op = $val -shr 26
        $imm = $val -band 0xFFFF
        $immS = if ($imm -ge 0x8000) { $imm - 0x10000 } else { $imm }
        $rs = ($val -shr 21) -band 0x1F; $rt = ($val -shr 16) -band 0x1F; $rd = ($val -shr 11) -band 0x1F
        $funct = $val -band 0x3F
        $rsn=$rn[$rs]; $rtn=$rn[$rt]; $rdn=$rn[$rd]
        $d = ''
        if ($val -eq 0) { $d = 'nop' }
        elseif ($op -eq 0x09) { $d = "addiu $rtn,$rsn,$immS" }
        elseif ($op -eq 0x0F) { $d = "lui $rtn,0x$($imm.ToString('X4'))" }
        elseif ($op -eq 0x0D) { $d = "ori $rtn,$rsn,0x$($imm.ToString('X4'))" }
        elseif ($op -eq 0x0C) { $d = "andi $rtn,$rsn,0x$($imm.ToString('X4'))" }
        elseif ($op -eq 0x23) { $d = "lw $rtn,0x$($imm.ToString('X4'))($rsn)" }
        elseif ($op -eq 0x21) { $d = "lh $rtn,0x$($imm.ToString('X4'))($rsn)" }
        elseif ($op -eq 0x25) { $d = "lhu $rtn,0x$($imm.ToString('X4'))($rsn)" }
        elseif ($op -eq 0x24) { $d = "lbu $rtn,0x$($imm.ToString('X4'))($rsn)" }
        elseif ($op -eq 0x20) { $d = "lb $rtn,0x$($imm.ToString('X4'))($rsn)" }
        elseif ($op -eq 0x28) { $d = "sb $rtn,0x$($imm.ToString('X4'))($rsn)" }
        elseif ($op -eq 0x29) { $d = "sh $rtn,0x$($imm.ToString('X4'))($rsn)" }
        elseif ($op -eq 0x2B) { $d = "sw $rtn,0x$($imm.ToString('X4'))($rsn)" }
        elseif ($op -eq 0x03) { $t2=($val -band 0x3FFFFFF)-shl 2; $d="jal 0x$($t2.ToString('X8'))" }
        elseif ($op -eq 0x02) { $t2=($val -band 0x3FFFFFF)-shl 2; $d="j 0x$($t2.ToString('X8'))" }
        elseif ($op -eq 0x04) { $d="beq $rsn,$rtn,0x$(($ram + 4 + $immS * 4).ToString('X8'))" }
        elseif ($op -eq 0x05) { $d="bne $rsn,$rtn,0x$(($ram + 4 + $immS * 4).ToString('X8'))" }
        elseif ($op -eq 0x00 -and $funct -eq 0x08) { $d="jr $rsn" }
        elseif ($op -eq 0x00 -and $funct -eq 0x21) { $d="addu $rdn,$rsn,$rtn" }
        elseif ($op -eq 0x00 -and $funct -eq 0x25) { $d="or $rdn,$rsn,$rtn" }
        elseif ($op -eq 0x00 -and $funct -eq 0x02) { $sh=($val -shr 6)-band 0x1F; $d="srl $rdn,$rtn,$sh" }
        elseif ($op -eq 0x00 -and $funct -eq 0x00) { $sh=($val -shr 6)-band 0x1F; $d="sll $rdn,$rtn,$sh" }
        elseif ($op -eq 0x00 -and $funct -eq 0x09) { $d="jalr $rdn,$rsn" }
        else { $d="op=0x$($op.ToString('X2')) f=0x$($funct.ToString('X2'))" }
        Write-Host ("  0x{0:X8}: 0x{1:X8}  {2}" -f $ram, $val, $d)
    }
}

# Look at 0x8008B65C (called by XA/STR function)
Write-Host "=== Function at 0x8008B65C (called by XA/STR 0x8008AEF4) ==="
D 0x8008B65C 60
