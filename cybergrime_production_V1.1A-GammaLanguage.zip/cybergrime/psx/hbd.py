"""HBD1PS1D object-graph parser and editor.

Provides live inspection of HeartBeatData folders/files/text blocks without
relying on the game to parse them. This is the foundation for runtime HBD
remapping and dynamic text injection.
"""

import struct
from dataclasses import dataclass, field
from typing import BinaryIO, Dict, List, Optional, Tuple

from .iso import IsoIO

SECTOR_SIZE = 2048

TEXT_TYPES = {23, 24, 25, 27, 40, 42}


@dataclass
class HbdFile:
    index: int
    ftype: int
    flags: int
    size: int
    size_uncompressed: int
    block_id: Optional[int]
    offset: int          # byte offset within the folder data
    data: bytes = field(repr=False)


@dataclass
class HbdFolder:
    index: int
    sector: int
    num_sectors: int
    num_files: int
    size: int
    files: List[HbdFile]


@dataclass
class HbdEntry:
    index: int
    sector: int
    type: str  # 'first', 'h600', 'folder', 'zeros', 'unknown'
    size_sectors: int
    folder: Optional[HbdFolder] = None


class HbdArchive:
    """Parse an HBD1PS1D blob (already extracted from ISO) into folders/files."""

    def __init__(self, data: bytes):
        self.raw = data
        self.entries: List[HbdEntry] = []
        self.folders: Dict[int, HbdFolder] = {}
        self._parse()

    def _is_h600(self, sector: bytes) -> bool:
        return sector[0:4] == bytes([0x60, 0x01, 0x01, 0x80])

    def _is_folder(self, sector: bytes) -> bool:
        return sector[0] != 0 and sector[1:4] == bytes([0, 0, 0])

    def _parse(self) -> None:
        pos = 0
        sector_index = 0
        entry_index = 0
        n = len(self.raw)

        # First sector is always a directory header
        if n >= SECTOR_SIZE:
            self.entries.append(HbdEntry(entry_index, sector_index, "first", 1))
            pos += SECTOR_SIZE
            sector_index += 1
            entry_index += 1

        while pos + SECTOR_SIZE <= n:
            sector = self.raw[pos:pos + SECTOR_SIZE]

            if self._is_h600(sector):
                self.entries.append(HbdEntry(entry_index, sector_index, "h600", 1))
                pos += SECTOR_SIZE
                sector_index += 1
                entry_index += 1
            elif self._is_folder(sector):
                num_files = struct.unpack_from("<I", sector, 0)[0]
                num_sectors = struct.unpack_from("<I", sector, 4)[0]
                size = struct.unpack_from("<I", sector, 8)[0]
                folder_data = self.raw[pos:pos + num_sectors * SECTOR_SIZE]

                files = []
                header_end = 16 + num_files * 16
                content_offset = header_end
                for i in range(num_files):
                    foff = 16 + i * 16
                    fsize = struct.unpack_from("<I", folder_data, foff)[0]
                    fsize_unc = struct.unpack_from("<I", folder_data, foff + 4)[0]
                    fflags = struct.unpack_from("<H", folder_data, foff + 12)[0]
                    ftype = struct.unpack_from("<H", folder_data, foff + 14)[0]

                    block_id = None
                    if ftype in TEXT_TYPES and content_offset + 8 <= len(folder_data):
                        block_id = struct.unpack_from("<I", folder_data, content_offset + 4)[0]

                    file_data = folder_data[content_offset:content_offset + fsize]
                    files.append(HbdFile(
                        index=i, ftype=ftype, flags=fflags, size=fsize,
                        size_uncompressed=fsize_unc, block_id=block_id,
                        offset=content_offset, data=file_data))
                    content_offset += fsize

                folder = HbdFolder(index=entry_index, sector=sector_index,
                                   num_sectors=num_sectors, num_files=num_files,
                                   size=size, files=files)
                entry = HbdEntry(entry_index, sector_index, "folder",
                                 num_sectors, folder=folder)
                self.entries.append(entry)
                self.folders[entry_index] = folder
                pos += num_sectors * SECTOR_SIZE
                sector_index += num_sectors
                entry_index += 1
            elif all(b == 0 for b in sector):
                # Count consecutive zero sectors
                zcount = 0
                while pos + SECTOR_SIZE <= n and all(b == 0 for b in self.raw[pos:pos + SECTOR_SIZE]):
                    pos += SECTOR_SIZE
                    sector_index += 1
                    zcount += 1
                self.entries.append(HbdEntry(entry_index, sector_index - zcount, "zeros", zcount))
                entry_index += 1
            else:
                self.entries.append(HbdEntry(entry_index, sector_index, "unknown", 1))
                pos += SECTOR_SIZE
                sector_index += 1
                entry_index += 1

    def summary(self) -> str:
        lines = [f"HBD archive: {len(self.raw)} bytes, {len(self.entries)} top-level entries"]
        for e in self.entries[:50]:
            if e.type == "folder":
                lines.append(f"  [{e.index:4d}] folder @ sector {e.sector} ({e.size_sectors} sectors, {e.folder.num_files} files)")
            else:
                lines.append(f"  [{e.index:4d}] {e.type} @ sector {e.sector} ({e.size_sectors} sectors)")
        return "\n".join(lines)

    @classmethod
    def from_iso(cls, iso_path: str, hbd_lba: int, hbd_size: int,
                 iso: Optional[IsoIO] = None) -> "HbdArchive":
        if iso is None:
            iso = IsoIO(iso_path)
        sectors = (hbd_size + 2047) // 2048
        data = bytearray()
        with open(iso_path, "rb") as f:
            for i in range(sectors):
                data.extend(iso.read_sector(f, hbd_lba + i))
        return cls(bytes(data[:hbd_size]))


class HbdFolderRemapper:
    """Compute folder address remaps so a foreign EXE can find HBD data.

    The DW7 EXE expects folder tables at addresses derived from the original
    DW7 HBD layout. When we replace the HBD with DQ4 data, those addresses
    become stale. This class builds a remapping table.
    """

    def __init__(self, archive: HbdArchive, base_ram: int = 0x80120000):
        self.archive = archive
        self.base_ram = base_ram

    def build_pointer_table(self) -> List[Tuple[int, int, int]]:
        """Return list of (folder_index, ram_addr, size) for each folder."""
        out = []
        current = self.base_ram
        for entry in self.archive.entries:
            if entry.type == "folder":
                out.append((entry.index, current, entry.folder.size))
                current += entry.folder.size
                # Align to 2048 boundary
                current = (current + 2047) & ~2047
        return out
