@echo off
set BASE=c:\LuxAura\VoidWalkers_Project\DQLOSTTRANSLATION
set DQ4_DISC=%BASE%\Dragon Quest IV - Michibikareshi Mono Tachi (Japan).bin
set DW7_EXE=%BASE%\translation\SLUSP012.06_clean.bin
set HYBRID_TREE=%BASE%\frozen\dw7_hybrid_tree.bin
set FOLDER_MAP=%BASE%\translation\folder_mapping.json
set EDCRE=%BASE%\edcre\edcre-v1.1.0-windows-x86_64-static\edcre.exe
set OUTPUT_BIN=%BASE%\build_staging\dq4_reverse_a.bin
set OUTPUT_CUE=%BASE%\build_staging\dq4_reverse_a.cue
set STAGING=%BASE%\build_staging

cd /d %BASE%\cybergrime
frankenstein_build.exe --reverse --dq4-hbd "%DQ4_DISC%" --dw7-exe "%DW7_EXE%" --hybrid-tree "%HYBRID_TREE%" --folder-map "%FOLDER_MAP%" --edcre "%EDCRE%" --output "%OUTPUT_BIN%" --output-cue "%OUTPUT_CUE%" --duckstation --reencode-hbd --skip-hash-check --staging-dir "%STAGING%"
