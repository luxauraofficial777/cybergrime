# Find all JAL call sites to FMV functions in DW7 EXE
$exePath = "c:\LuxAura\VoidWalkers_Project\DQLOSTTRANSLATION\translation\SLUSP012.06"
$bytes = [System.IO.File]::ReadAllBytes($exePath)
$loadAddr = 0x80017F00

# JAL target encodings
$jalXaStr = 0x0C022BBD   # jal 0x8008AEF4
$jalMdec  = 0x0C0232B4   # jal 0x8008CAD0

Write-Host "=== JAL calls to XA/STR function (0x8008AEF4) ==="
for ($i = 0x800; $i -lt $bytes.Length - 3; $i += 4) {
    $insn = [BitConverter]::ToUInt32($bytes, $i)
    if ($insn -eq $jalXaStr) {
        $ram = $loadAddr + $i - 0x800
        # Read surrounding context (previous and next 2 instructions)
        $prev = [BitConverter]::ToUInt32($bytes, $i - 4)
        $next1 = [BitConverter]::ToUInt32($bytes, $i + 4)
        $next2 = [BitConverter]::ToUInt32($bytes, $i + 8)
        Write-Host ("  RAM 0x{0:X8} (file 0x{1:X})  prev=0x{2:X8}  jal=0x{3:X8}  +4=0x{4:X8}  +8=0x{5:X8}" -f $ram, $i, $prev, $insn, $next1, $next2)
    }
}

Write-Host ""
Write-Host "=== JAL calls to MDEC init function (0x8008CAD0) ==="
for ($i = 0x800; $i -lt $bytes.Length - 3; $i += 4) {
    $insn = [BitConverter]::ToUInt32($bytes, $i)
    if ($insn -eq $jalMdec) {
        $ram = $loadAddr + $i - 0x800
        $prev = [BitConverter]::ToUInt32($bytes, $i - 4)
        $next1 = [BitConverter]::ToUInt32($bytes, $i + 4)
        $next2 = [BitConverter]::ToUInt32($bytes, $i + 8)
        Write-Host ("  RAM 0x{0:X8} (file 0x{1:X})  prev=0x{2:X8}  jal=0x{3:X8}  +4=0x{4:X8}  +8=0x{5:X8}" -f $ram, $i, $prev, $insn, $next1, $next2)
    }
}
