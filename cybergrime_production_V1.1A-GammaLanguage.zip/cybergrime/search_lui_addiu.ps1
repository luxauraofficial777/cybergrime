# Search for MIPS instruction pairs that load LBA 146621 (0x23C7D)
# Pattern 1: lui $reg, 0x0002; addiu $reg, $reg, 0x3C7D
# Pattern 2: lui $reg, 0x0002; ori $reg, $reg, 0x3C7D
# Also search for LBA-150 = 146471 (0x23C27)
# And HBD-relative offset 146267 (0x23B5B)

$exePath = 'c:\LuxAura\VoidWalkers_Project\DQLOSTTRANSLATION\translation\SLUSP012.06'
$bytes = [System.IO.File]::ReadAllBytes($exePath)
$loadAddr = 0x80017F00

$rn = @('zero','at','v0','v1','a0','a1','a2','a3','t0','t1','t2','t3','t4','t5','t6','t7','s0','s1','s2','s3','s4','s5','s6','s7','t8','t9','k0','k1','gp','sp','fp','ra')

function SearchLuiAddiu($name, $luiHi, $addiuLo) {
    Write-Host "=== ${name}: lui 0x$($luiHi.ToString('X4')) + addiu/ori 0x$($addiuLo.ToString('X4')) ==="
    $count = 0
    for ($i = 0x800; $i -lt $bytes.Length - 7; $i += 4) {
        $insn1 = [BitConverter]::ToUInt32($bytes, $i)
        $op1 = $insn1 -shr 26
        if ($op1 -eq 0x0F) {  # lui
            $rt1 = ($insn1 -shr 16) -band 0x1F
            $imm1 = $insn1 -band 0xFFFF
            if ($imm1 -eq $luiHi) {
                # Check next 1-3 instructions for addiu/ori with same register
                for ($j = 1; $j -le 3; $j++) {
                    $insn2 = [BitConverter]::ToUInt32($bytes, $i + $j * 4)
                    $op2 = $insn2 -shr 26
                    $rt2 = ($insn2 -shr 16) -band 0x1F
                    $rs2 = ($insn2 -shr 21) -band 0x1F
                    $imm2 = $insn2 -band 0xFFFF
                    if (($op2 -eq 0x09 -or $op2 -eq 0x0D) -and $rt2 -eq $rt1 -and $rs2 -eq $rt1 -and $imm2 -eq $addiuLo) {
                        $ram = $loadAddr + $i - 0x800
                        $ram2 = $loadAddr + $i + $j * 4 - 0x800
                        $opName = if ($op2 -eq 0x09) { 'addiu' } else { 'ori' }
                        Write-Host ("  RAM 0x{0:X8}: lui {1},0x{2:X4} -> 0x{3:X8}: {4} {1},0x{5:X4}" -f $ram, $rn[$rt1], $imm1, $ram2, $opName, $imm2)
                        $count++
                        break
                    }
                }
            }
        }
    }
    if ($count -eq 0) { Write-Host "  (none)" }
}

# LBA 146621 = 0x00023C7D
SearchLuiAddiu "LBA 146621" 0x0002 0x3C7D
# LBA-150 = 146471 = 0x00023C27
SearchLuiAddiu "LBA-150 146471" 0x0002 0x3C27
# HBD offset DW7 = 146267 = 0x00023B5B
SearchLuiAddiu "HBD offset 146267" 0x0002 0x3B5B
# HBD offset Frank = 146259 = 0x00023B53
SearchLuiAddiu "HBD offset Frank 146259" 0x0002 0x3B53

# Also try with lui 0x0003 and negative addiu
# 0x00023C7D = lui 0x0003 + addiu -0x4383 (0xBC7D sign-extended)
# 0x3C7D = 15501, 0x8000 - 0x3C7D = 0x4383, so addiu 0xBC7D = -0x4383
# lui 0x0003 = 0x30000, 0x30000 - 0x4383 = 0x2BC7D (wrong)
# Actually: lui 0x0003 = 0x30000, addiu 0xBC7D = 0x30000 + (-17205) = 0x2BC7D (wrong)
# Let me try: 0x23C7D = 0x20000 + 0x3C7D, so lui 0x0002 + addiu 0x3C7D (already searched)
# Or: 0x23C7D = 0x30000 - 0xC383, so lui 0x0003 + addiu -0x3C83 (0xC383)
SearchLuiAddiu "LBA 146621 alt" 0x0003 0xC383

# Also search for the BCD MSF as individual bytes loaded via addiu
# addiu $reg, $zero, 0x32 = load BCD minute 32
# addiu $reg, $zero, 0x34 = load BCD second 34
# addiu $reg, $zero, 0x71 = load BCD frame 71
# Search for addiu $reg, $zero, 0x71 (most unique value)
Write-Host ""
Write-Host "=== addiu/ori $reg, $zero, 0x71 (BCD frame 71) ==="
for ($i = 0x800; $i -lt $bytes.Length - 3; $i += 4) {
    $insn = [BitConverter]::ToUInt32($bytes, $i)
    $op = $insn -shr 26
    $imm = $insn -band 0xFFFF
    $rs = ($insn -shr 21) -band 0x1F
    $rt = ($insn -shr 16) -band 0x1F
    if (($op -eq 0x09 -or $op -eq 0x0D) -and $rs -eq 0 -and $imm -eq 0x71) {
        $ram = $loadAddr + $i - 0x800
        $opName = if ($op -eq 0x09) { 'addiu' } else { 'ori' }
        # Show context: 4 instructions before and after
        Write-Host ""
        Write-Host "--- $opName $($rn[$rt]), zero, 0x71 at RAM 0x$($ram.ToString('X8')) ---"
        for ($k = -4; $k -le 4; $k++) {
            $off2 = $i + $k * 4
            if ($off2 -lt 0x800 -or $off2 + 3 -ge $bytes.Length) { continue }
            $val2 = [BitConverter]::ToUInt32($bytes, $off2)
            $ram2 = $loadAddr + $off2 - 0x800
            $op2 = $val2 -shr 26
            $imm2 = $val2 -band 0xFFFF
            $immS2 = if ($imm2 -ge 0x8000) { $imm2 - 0x10000 } else { $imm2 }
            $rs2 = ($val2 -shr 21) -band 0x1F; $rt2 = ($val2 -shr 16) -band 0x1F
            $d2 = "op=0x$($op2.ToString('X2'))"
            if ($val2 -eq 0) { $d2 = 'nop' }
            elseif ($op2 -eq 0x09) { $d2 = "addiu $($rn[$rt2]),$($rn[$rs2]),$immS2" }
            elseif ($op2 -eq 0x0F) { $d2 = "lui $($rn[$rt2]),0x$($imm2.ToString('X4'))" }
            elseif ($op2 -eq 0x0D) { $d2 = "ori $($rn[$rt2]),$($rn[$rs2]),0x$($imm2.ToString('X4'))" }
            elseif ($op2 -eq 0x28) { $d2 = "sb $($rn[$rt2]),0x$($imm2.ToString('X4'))($($rn[$rs2]))" }
            elseif ($op2 -eq 0x23) { $d2 = "lw $($rn[$rt2]),0x$($imm2.ToString('X4'))($($rn[$rs2]))" }
            elseif ($op2 -eq 0x03) { $t2=($val2 -band 0x3FFFFFF)-shl 2; $d2="jal 0x$($t2.ToString('X8'))" }
            $m = if ($k -eq 0) { ' <<<' } else { '' }
            Write-Host ("    0x{0:X8}: 0x{1:X8}  {2}{3}" -f $ram2, $val2, $d2, $m)
        }
    }
}
