$log = 'C:\LuxAura\VoidWalkers_Project\DuckStation\duckstation.log'
Write-Host "=== ALL Setloc entries ==="
Select-String -Path $log -Pattern 'Setloc' | ForEach-Object { Write-Output $_.Line }
Write-Host ""
Write-Host "=== Setmode entries ==="
Select-String -Path $log -Pattern 'Setmode' | ForEach-Object { Write-Output $_.Line }
