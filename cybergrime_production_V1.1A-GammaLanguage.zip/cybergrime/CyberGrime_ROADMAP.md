# CyberGrime — Comprehensive Development Roadmap

> **SUPERSEDED — see `study/SURGICAL_COMPLETION_VHB_CYBERGRIME_Aug3_2026.md`**
> This roadmap is factually wrong about 6 completed features (marks Lua/GDB/rewind/savestate/test-defs/ISO-toolkit as "NOT DONE" when all exist). Per M5, the surgical completion doc is the canonical source.
> **Status:** ARCHIVED. Do not use for planning.

**Created:** Jul 17, 2026  
**Supersedes:** `BLUEPRINT_CyberGrime_Jul16_2026.md`, `TESTING_ENVIRONMENT_UPGRADE_BLUEPRINT.md`, `ORCHESTRATION_BLUEPRINT.md` (as planning docs; those remain as reference)  
**Current Rating:** 7.5/10  
**Target Rating:** 9.5/10  

---

## 1. Project Overview

CyberGrime is a custom PSX emulator and agent harness built for the DQ4 Frankenstein ROM translation project. Its unique value proposition is **agent-driven testing**: JSON telemetry, scripted injection, batch testing, an orchestration engine with instruction-level hooks, and automated triage — features no other PSX emulator has.

**Primary use case:** Headless tracing and debugging of DQ4 Frankenstein builds to identify boot blockers, CD-ROM pipeline issues, and text rendering problems. DuckStation serves as the visual oracle; CyberGrime serves as the tracing oracle.

---

## 2. Source Blueprints Consolidated

| Document | Location | Lines | Scope |
|---|---|---|---|
| `BLUEPRINT_CyberGrime_Jul16_2026.md` | `study/` | 198 | 5 phases (CG-1 through CG-5), industry rating targets |
| `TESTING_ENVIRONMENT_UPGRADE_BLUEPRINT.md` | `cybergrime/` | 1493 | 9 phases (A through I), full architecture spec |
| `ORCHESTRATION_BLUEPRINT.md` | `cybergrime/` | 449 | 5 phases, hook table, auto-corrector, audit log |
| `CDROM_PIPELINE_GAPS.md` | `cybergrime/` | 474 | 19-section gap analysis vs DuckStation |
| `INTEGRATION_MANIFEST.md` | `cybergrime/` | 198 | PSoXide/PSn00bSDK/PSn00b-Debugger integration |
| `PROGRESS_CyberGrime_Jul16_2026.md` | `study/` | 95 | Jul 16 progress snapshot |

This roadmap merges all six into a single canonical plan with implementation status.

---

## 3. Current Architecture

### 3.1 Source Files

| File | Lines | Role |
|---|---|---|
| `psx_emulator_core.cpp` | ~4,200 | MIPS R3000A CPU, HLE BIOS, CD-ROM, exception handling |
| `psx_test_station.h` | ~1,300 | Memory system, hardware regs, CD-ROM controller, DMA, PAD |
| `psx_agent_runner.cpp` | ~650 | CLI runner, harness integration, batch mode |
| `agent_harness.h/.cpp` | ~2,100 | TTY capture, VFS logging, freeze detection, RAM injection, telemetry |
| `orchestration_engine.h` | ~400 | Hook table (64), register watches (32), audit log (4096), address map |
| `psx_gte.h` | 833 | GTE — all 38 COP2 instructions |
| `psx_gpu.h` | 535 | GPU — textured tri/quad, CLUT, semi-trans, dithering |
| `psx_spu.h` | 554 | SPU — 24 voices, ADSR, 512KB RAM, reverb |
| `psx_mdec.h` | 287 | MDEC — IDCT, quantization, RLE, YCbCr→RGB |
| `psx_xa.h` | 194 | XA-ADPCM — Form 2 sectors, 4-bit ADPCM |
| `psx_savestate.h` | 165 | Save state — CPU/RAM/VRAM/hardware snapshot |
| `psx_debugger.h` | 299 | CLI debugger — breakpoints, watchpoints, step, disasm |
| `psx_reference_integrations.h` | ~1,200 | Reference constants: BIOS syscalls, CD-ROM, events, TCB, disassembler |
| `txrt_hle.h` | 459 | TXRT Huffman decompression bypass |
| `CybergrimeUI.h/.cpp` | ~700 | Win32 GDI+ visual debug overlay |
| `vfs_compare.cpp` | ~800 | Binary-level ISO comparison |
| `psx_autoplayer.cpp` | ~538 | JSON scriptable pad input |
| `psx_headless.cpp` | 158 | Minimal headless runner |

### 3.2 Python Tooling (51 scripts)

Key scripts: `harness_runner.py`, `iteration_harness.py`, `telemetry_summary.py`, `analyze_telemetry.py`, `exe_patch.py`, `asm_to_inject.py`, `launch_duckstation_tests.py`, `duckstation_control_test.py`, `agent_telemetry.py`, `write_duckstation_settings.py`, plus 41 analysis/diagnostic scripts.

### 3.3 Build System

- `build_agent.bat` — MSVC single-command build, produces `psx_agent_runner.exe` (25MB)
- No CMake, no CI, no dependency management
- Compiles with MSVC 19.44.35224

---

## 4. Implementation Status Matrix

### Phase CG-1: Core Emulation Fidelity

| Task | Status | File | Notes |
|---|---|---|---|
| CG-1.1: GTE (38 instructions) | ✅ DONE | `psx_gte.h` (833 lines) | All COP2 ops, flags, registers. Included in `psx_test_station.h` |
| CG-1.2: GPU Polygon+Texture | ✅ DONE | `psx_gpu.h` (535 lines) | Tri/quad, CLUT, semi-trans, dithering. Included in `psx_test_station.h` |
| CG-1.3: SPU | ✅ DONE | `psx_spu.h` (554 lines) | 24 voices, ADSR, 512KB RAM, reverb. Included in `psx_emulator_core.cpp` |
| CG-1.4: MDEC | ✅ DONE | `psx_mdec.h` (287 lines) | IDCT, quantization, RLE, YCbCr→RGB. Included in `psx_emulator_core.cpp` |
| CG-1.5: XA-ADPCM | ✅ DONE | `psx_xa.h` (194 lines) | Form 2 sectors, 4-bit ADPCM. Included in `psx_emulator_core.cpp` |

**CG-1 is COMPLETE.** All five hardware stubs exist, are included in the build, and have header-only implementations. However, integration depth varies — SPU/MDEC/XA are implemented but may not be fully wired into the CD-ROM and DMA pipelines. See Phase 2 below for integration gaps.

### Phase CG-2: Debugger & Developer Tools

| Task | Status | File | Notes |
|---|---|---|---|
| CG-2.1: Enhanced Disassembler | ✅ DONE | `psx_reference_integrations.h` | `mips_disasm::disasm_str()` wired into trace ring |
| CG-2.2: Memory Viewer+Editor | ⬜ NOT DONE | — | No hex dump with ASCII sidebar in harness |
| CG-2.3: Register Inspector | ⬜ NOT DONE | — | No live register panel |
| CG-2.4: Breakpoint Upgrade | ✅ DONE | `psx_debugger.h` (299 lines) | Breakpoints, watchpoints, step, backtrace, conditional BPs |
| CG-2.5: Trace Visualizer | ⬜ NOT DONE | — | No `visualize_trace.py` (Graphviz call graph) |

### Phase CG-3: Testing & QA Framework

| Task | Status | Notes |
|---|---|---|
| CG-3.1: Test Profile System | ⬜ NOT DONE | No JSON test specs with breakpoints/injections/assertions |
| CG-3.2: Regression Test Suite | ⬜ NOT DONE | No `tests/` directory with formal test definitions |
| CG-3.3: Telemetry Diff Tool | ⬜ NOT DONE | No side-by-side telemetry comparison |
| CG-3.4: Automated Crash Triage | ⬜ PARTIAL | Basic triage in `agent_harness.cpp`, no `auto_triage.py` classifier |
| CG-3.5: cdrom_sectors_read Bug | ✅ DONE | `cdrom_total_sectors_read` accumulator added |

### Phase CG-4: Public Tooling & Documentation

| Task | Status | Notes |
|---|---|---|
| CG-4.1: Unified CLI | ⬜ NOT DONE | No `cybergrime.exe run\|debug\|batch\|compare` |
| CG-4.2: Python SDK | ⬜ NOT DONE | No `cybergrime_sdk` package |
| CG-4.3: Documentation | ⬜ PARTIAL | `README_TOOLCHAIN.md` (96 lines), `INTEGRATION_MANIFEST.md` exist |
| CG-4.4: Build System | ⬜ NOT DONE | No CMake, no CI, just `build_agent.bat` |

### Phase CG-5: Advanced Features

| Task | Status | File | Notes |
|---|---|---|---|
| CG-5.1: Save State System | ✅ DONE | `psx_savestate.h` (165 lines) | Full CPU+RAM+VRAM+hardware snapshot. Included in core |
| CG-5.2: Rewind System | ⬜ NOT DONE | — | No ring buffer snapshots |
| CG-5.3: Lua Scripting | ⬜ NOT DONE | — | No Lua 5.4 embedded |
| CG-5.4: GDB Remote Protocol | ⬜ NOT DONE | — | No GDB RSP stub |
| CG-5.5: ISO Toolkit | ⬜ NOT DONE | — | Uses external `edcre.exe` |

### Phase A-I (Testing Environment Upgrade Blueprint)

| Phase | Task | Status | Notes |
|---|---|---|---|
| A.1 | Save State | ✅ DONE | `psx_savestate.h` |
| A.2 | MIPS Disassembler | ✅ DONE | In `psx_reference_integrations.h` |
| A.3 | Memory Card | ⬜ NOT DONE | No `psx_memcard.h` |
| A.4 | Enhanced Trace Ring | ⬜ PARTIAL | Disasm added, no mem read/write tracking |
| B.1 | CD-ROM State Machine | ⬜ PARTIAL | Status reg fixed, FIFOs separated, 19 gaps remain (see §5) |
| B.2 | DMA Channel 3 | ⬜ PARTIAL | Basic transfer, no BFRD check, no proper buffer mgmt |
| B.3 | CD-ROM BIOS Calls | ⬜ PARTIAL | CdRead/CdReadSync exist, CdReadFile may be incomplete |
| B.4 | CD-ROM Interrupt Chain | ⬜ PARTIAL | INT1/INT2 fire, timing/event delivery issues |
| C.1 | File I/O (open/read/lseek/close) | ⬜ PARTIAL | Stubbed, may not handle all edge cases |
| C.2 | Missing BIOS Functions | ⬜ PARTIAL | FlushCache, GPU_cw done; some still missing |
| C.3 | BIOS Audit Tool | ⬜ NOT DONE | No `bios_audit.py` |
| D.1 | Structured Test Definitions | ⬜ NOT DONE | No `test_definitions.json` |
| D.2 | Screenshot Capture | ⬜ NOT DONE | No `psx_screenshot.h` |
| D.3 | VRAM Text Scanner | ⬜ NOT DONE | No `vram_text_scanner.h` |
| D.4 | Enhanced Triage | ⬜ PARTIAL | Disasm in triage, not full annotated output |
| D.5 | Test Result Database | ⬜ NOT DONE | No SQLite `test_results.db` |
| E.1 | Unified Patch Pipeline | ⬜ NOT DONE | No `patch_pipeline.py` |
| E.2 | ISO-Aware Binary Differ | ⬜ PARTIAL | `vfs_compare.cpp` exists, not upgraded |
| E.3 | EXE Patch Generator | ⬜ PARTIAL | `exe_patch.py` in Python, no C++ header |
| E.4 | MIPS Trampoline Generator | ⬜ NOT DONE | No `mips_trampoline.h` |
| F.1 | Framebuffer Capture & Comparison | ⬜ NOT DONE | No `visual_qa.py` |
| F.2 | Font Table Integration | ⬜ NOT DONE | No `font_table.h` |
| F.3 | Automated Screenshot Timeline | ⬜ NOT DONE | — |
| G.1 | DuckStation Bridge | ⬜ PARTIAL | `launch_duckstation_tests.py`, `duckstation_control_test.py` exist |
| G.2 | Trace Comparison Tool | ⬜ NOT DONE | No `trace_compare.py` |
| G.3 | SwanStation Bridge | ⬜ NOT DONE | — |
| H.1 | Test Matrix Definition | ⬜ NOT DONE | — |
| H.2 | Regression Test Runner | ⬜ NOT DONE | — |
| H.3 | CI/CD Integration | ⬜ NOT DONE | — |
| H.4 | Test Report Generator | ⬜ NOT DONE | — |
| I.1 | Nexus Integration | ⬜ NOT DONE | — |
| I.2 | Self-Healing Patch Iteration | ⬜ PARTIAL | `iteration_harness.py` (390 lines) exists |
| I.3 | RAG-Enhanced Debugging | ⬜ NOT DONE | — |

### Orchestration Engine (ORCHESTRATION_BLUEPRINT.md)

| Phase | Status | Notes |
|---|---|---|
| 1: Core Engine (`orchestration_engine.h`) | ✅ DONE | Hook table, reg watches, audit log, address map |
| 2: Wire into `step()` | ✅ DONE | Pre/post-exec hooks, auto-correct in crash paths |
| 3: Thread Injection Verification | ✅ DONE | Bubblegum stub fallback |
| 4: DW7 Reference Integration | ✅ DONE | Address map, bulk search |
| 5: CLI Interface | ⬜ PARTIAL | `--verbose` added; `--hook`, `--watch`, `--auto-correct`, `--telemetry`, `--audit-log`, `--delta-map` NOT added |

### Bug Fixes Applied

| Bug | Status | Date | Details |
|---|---|---|---|
| RFE handler not restoring v0 | ✅ FIXED | Jul 17 | `cpu.set_reg(2, saved_ctx.v0)` added to RFE handler |
| CD-ROM status register bit layout | ✅ FIXED | Jul 12 | Bits 3-7 corrected per DuckStation reference |
| Response/data FIFO separation | ✅ FIXED | Jul 12 | Separate `cdrom_response_fifo` and `cdrom_data_sector` |
| Interrupt flag register bits | ✅ FIXED | Jul 12 | Upper bits `| 0xF8`, ACK uses bits 0-2, param clear is bit 6 |
| CD-ROM command mapping (6 wrong, 9 missing) | ✅ FIXED | Jul 16 | Per PSoXide reference |
| CD-ROM timing constant | ✅ FIXED | Jul 16 | `cdrom_constants::CD_READ_TIME` (33868 cycles) |
| `cdrom_sectors_read` counter reset | ✅ FIXED | Jul 16 | `cdrom_total_sectors_read` accumulator |
| Verbose logging gated | ✅ FIXED | Jul 16 | `g_verbose` flag, `--verbose` CLI |
| GPU_DIAG spam | ✅ FIXED | Jul 16 | `last_gpu_diag_vblank` guard |
| Extra brace in `psx_test_station.h` | ✅ FIXED | Jul 16 | Compilation unblocked |

---

## 5. CD-ROM Pipeline Gap Analysis (from CDROM_PIPELINE_GAPS.md)

19 gaps documented. Current status of each:

### Must Fix (Game Won't Progress Without These)

| # | Gap | Status | Impact |
|---|---|---|---|
| 1 | Status register bit layout | ✅ FIXED | — |
| 2 | Response/data FIFO separation | ✅ FIXED | — |
| 3 | Interrupt flag register bits | ✅ FIXED | — |
| 4 | Command async delay + BUSYSTS | ⬜ NOT DONE | Game may spam commands |
| 5 | Setloc pending + BCD validation | ✅ FIXED | — |
| 6 | Secondary status register | ⬜ PARTIAL | Hardcoded 0x02, no seeking/reading states |
| 7 | Request register BFRD handling | ⬜ NOT DONE | Data reads not properly gated |
| 8 | DMA ch3 BFRD check | ⬜ NOT DONE | DMA can read when no data ready |
| 9 | Interrupt acknowledgment | ⬜ PARTIAL | Bit 6 fix applied, no pending async delivery |
| 10 | Missing commands (Test, SeekL, SeekP, Init) | ⬜ PARTIAL | Test/Init added, SeekL/SeekP not implemented |
| 11 | Seek operation | ⬜ NOT DONE | No seek delay or seek state |
| 12 | Sector delivery timing | ⬜ NOT DONE | 10x too fast (20K instrs/sector vs ~320K needed) |

### Should Fix

| # | Gap | Status | Impact |
|---|---|---|---|
| 13 | ADPCM/XA audio handling | ⬜ PARTIAL | `psx_xa.h` exists, not wired into CD-ROM pipeline |
| 14 | Game polling loop conditions | ⬜ UNRESOLVED | Unknown what game waits for at 0x800967xx |
| 15 | BIOS event relationship | ⬜ UNRESOLVED | Unknown how BIOS and game events interact |
| 16 | Thread bootstrap mapping | ⬜ WORKAROUND | Bubblegum stub at 0x800D9E80 |

### Nice to Have

| # | Gap | Status | Impact |
|---|---|---|---|
| 17 | Memory card persistence | ⬜ NOT DONE | No actual MC file |
| 18 | GPU framebuffer output | ⬜ PARTIAL | GPU renders to VRAM, no display output |
| 19 | XA-ADPCM audio | ⬜ PARTIAL | Header exists, not integrated |

---

## 6. Consolidated Roadmap

The remaining work is organized into 6 phases, ordered by dependency and value.

### Phase R1: CD-ROM Pipeline Completion (P0, 3-5 days)

**Goal:** Fix the remaining CD-ROM gaps so the game progresses past the VSync polling loop.

| Task | ID | Effort | Details |
|---|---|---|---|
| Secondary status register | R1.1 | 2h | Track motor_on, seeking, reading, shell_open, focus states. Return as first byte of all command responses |
| Command async delay + BUSYSTS | R1.2 | 4h | Set BUSYSTS=1 on command write, schedule execution after delay (2000-80000 ticks), clear on completion |
| Seek operation | R1.3 | 4h | Setloc stores pending position. ReadN/ReadS triggers seek with delay. `secondary_status.seeking=1` during seek |
| Request register BFRD | R1.4 | 3h | Handle BFRD bit in 0x1F801803 index=0. Gate data reads on BFRD. Clear BFRD + DRQSTS when buffer exhausted |
| DMA ch3 BFRD check | R1.5 | 2h | Only allow DMA read when BFRD set and data ready. Track buffer position. Fire event when exhausted |
| Sector delivery timing | R1.6 | 2h | Calibrate: 1x=75 sectors/sec=1.25 sectors/VBlank=~320K instrs/sector. Use system clock ticks |
| Interrupt ACK pending delivery | R1.7 | 2h | After ACK, check for pending async interrupt and deliver it. Deassert IRQ line when flag=0 |
| Missing commands (SeekL, SeekP) | R1.8 | 2h | Implement 0x15/0x16 with seek-then-ready flow |

**Acceptance:** Game issues Setloc→ReadN→receives INT1→DMA transfers data→game exits polling loop

### Phase R2: Hardware Integration Depth (P1, 2-3 days)

**Goal:** Wire SPU/MDEC/XA stubs into the CD-ROM and DMA pipelines so they actually process data.

| Task | ID | Effort | Details |
|---|---|---|---|
| MDEC → DMA ch0/ch1 wiring | R2.1 | 4h | Connect `psx_mdec.h` to DMA channels 0/1. MDEC output → VRAM via DMA |
| SPU → DMA ch4/ch5 wiring | R2.2 | 3h | Connect `psx_spu.h` to DMA channels 4/5. SPU RAM read/write via DMA |
| XA-ADPCM → CD-ROM integration | R2.3 | 3h | Detect XA sectors in CD-ROM read path, route to `psx_xa.h` decoder, output to SPU |
| GPU display interrupt | R2.4 | 2h | Generate VBlank/hblank interrupts from GPU state (currently from timer only) |
| Memory card emulation | R2.5 | 3h | Create `psx_memcard.h`: 128KB image, 16 blocks, BIOS calls (init/read/write), file persistence |

**Acceptance:** MDEC decodes FMV frames to VRAM, SPU plays ADPCM voices, XA audio streams from CD

### Phase R3: Testing & QA Framework (P1, 3-4 days)

**Goal:** Formal test definitions, regression suite, telemetry diff, automated triage.

| Task | ID | Effort | Details |
|---|---|---|---|
| Test profile system | R3.1 | 4h | JSON test specs: disc, max_instrs, breakpoints, injections, monitors, assertions. `harness_runner.py --profile` |
| Regression test suite | R3.2 | 3h | `tests/` directory: boot_dw7, boot_dq4jp, boot_frank, huffman_roundtrip, iso_read. `--batch tests/*.json` |
| Telemetry diff tool | R3.3 | 3h | `telemetry_diff.py`: side-by-side BIOS call counts, VBlank timeline, PC trajectory, divergence point |
| Automated crash triage | R3.4 | 3h | `auto_triage.py`: classify crash type (stack corruption, null deref, infinite loop, BIOS error), suggest root cause |
| Test result database | R3.5 | 3h | SQLite `test_results.db`: run history, pass/fail, screenshots, triage logs. Python API |
| Screenshot capture | R3.6 | 3h | `psx_screenshot.h`: framebuffer→BMP, compare screenshots, diff ratio. `--screenshot out.bmp` CLI |

**Acceptance:** `harness_runner.py --profile profiles/dq4_frank_v29.json` runs complete test with pass/fail

### Phase R4: Visual Verification & Cross-Emulator (P2, 2-3 days)

**Goal:** Verify English text renders in framebuffer, cross-validate with DuckStation.

| Task | ID | Effort | Details |
|---|---|---|---|
| VRAM text extraction | R4.1 | 4h | `vram_text_scanner.h`: scan VRAM for tile patterns, map to char codes via font table, decode text |
| Font table integration | R4.2 | 3h | `font_table.h`: DQ4/DW7 font mapping, tile index→char code, English/Japanese detection |
| Visual QA pipeline | R4.3 | 3h | `visual_qa.py`: capture at state, compare to reference, detect text regions, verify English text |
| DuckStation bridge upgrade | R4.4 | 3h | Upgrade `duckstation_control_test.py` to full bridge: run with logging, capture screenshots, validate boot |
| Trace comparison | R4.5 | 3h | `trace_compare.py`: compare two instruction traces, find first divergence, register diff at divergence |

**Acceptance:** Screenshot from CyberGrime shows English text; trace divergence vs DuckStation identified

### Phase R5: Developer Tooling & Polish (P2, 2-3 days)

**Goal:** Unified CLI, Python SDK, documentation, build system, remaining debugger tools.

| Task | ID | Effort | Details |
|---|---|---|---|
| Unified CLI | R5.1 | 4h | `cybergrime.exe run\|debug\|batch\|compare\|inject\|disasm\|scan\|profile` |
| Python SDK | R5.2 | 3h | `cybergrime_sdk` package: TestRunner, Telemetry, Injector classes |
| CMake build system | R5.3 | 3h | `CMakeLists.txt`, MSVC + GCC support, release binary |
| Documentation | R5.4 | 3h | GETTING_STARTED, ARCHITECTURE, PROFILES, INJECTION, TELEMETRY, ROM_HACKING, DEBUGGING, HLE_BIOS |
| Memory viewer | R5.5 | 2h | Hex dump with ASCII sidebar, goto, edit, search, diff view |
| Trace visualizer | R5.6 | 3h | `visualize_trace.py`: Graphviz call graph, timeline, hotspot analysis |
| BIOS audit tool | R5.7 | 2h | `bios_audit.py`: scan `handle_bios_call()`, compare against PSn00bSDK reference, coverage report |
| Enhanced trace ring | R5.8 | 2h | Add mem read/write tracking, branch-taken flag. Increase to 512 entries |

**Acceptance:** New user runs a test and understands telemetry within 30 minutes

### Phase R6: Advanced Features (P3, 2+ weeks)

**Goal:** Save state usage in tests, rewind, Lua scripting, GDB stub, ISO toolkit, AI integration.

| Task | ID | Effort | Details |
|---|---|---|---|
| Save state in tests | R6.1 | 2h | Wire `psx_savestate.h` into CLI: `--savestate out.bin`, `--loadstate state.bin` |
| Rewind system | R6.2 | 4h | Periodic snapshots (every 1M instrs), ring buffer of 50, rewind + branch |
| Lua scripting | R6.3 | 1w | Lua 5.4 embedded: memory R/W callbacks, BP conditionals, frame advance hook, REPL |
| GDB remote protocol | R6.4 | 4h | GDB RSP stub: `target remote localhost:3333`, R/W regs+memory, BPs, single-step |
| ISO toolkit | R6.5 | 4h | ISO9660 browser, LBA editor, EDC/ECC regen (replace `edcre.exe`), BIN/CUE↔ISO, subchannel Q |
| MIPS trampoline generator | R6.6 | 3h | `mips_trampoline.h`: generate hook code for real-emulator patches |
| Unified patch pipeline | R6.7 | 3h | `patch_pipeline.py`: build→verify→diff→xdelta→ppf |
| Self-healing iteration | R6.8 | 4h | Upgrade `iteration_harness.py` with AI analysis: triage→root cause→refined patches |
| CI/CD integration | R6.9 | 3h | `ci_runner.py`, GitHub Actions workflow, automated regression on push |
| Test report generator | R6.10 | 3h | `report_generator.py`: HTML report with screenshots, triage excerpts, trend charts |
| Nexus integration | R6.11 | 3h | Connect harness to VW Nexus agent system for event feed + AI analysis |
| RAG-enhanced debugging | R6.12 | 3h | Search past solutions via RAG, feed context to AI agent for triage |
| SwanStation bridge | R6.13 | 2h | RetroArch headless mode for DW7 compatibility testing |

---

## 7. Dependency Graph

```
R1 (CD-ROM Pipeline) ─────┐
                          │
R2 (Hardware Integration)─┤
                          ├── R3 (Testing & QA)
R5.7 (BIOS Audit) ────────┤       │
                          │       ├── R4 (Visual Verification)
                          │       │       │
                          │       ├── R5 (Developer Tooling)
                          │       │       │
                          │       └── R6 (Advanced Features)
                          │
R5.1 (Unified CLI) ───────┘
```

**Critical path:** R1 → R3 → R4 → ship  
**Parallel track:** R2 (can proceed independently)  
**Tooling track:** R5 (can proceed in parallel with R3/R4)

---

## 8. Rating Trajectory

| Criterion | Current | After R1-R2 | After R3-R4 | After R5-R6 | Target |
|---|---|---|---|---|---|
| CPU Accuracy | 7.0 | 8.0 | 8.0 | 8.5 | 9.0 |
| GPU Rendering | 6.0 | 7.5 | 7.5 | 8.0 | 9.0 |
| Audio (SPU) | 5.0 | 7.0 | 7.0 | 8.0 | 9.0 |
| MDEC/FMV | 5.0 | 7.0 | 7.0 | 8.0 | 9.0 |
| CD-ROM Pipeline | 5.0 | 8.0 | 8.0 | 8.5 | 9.0 |
| Debugger | 7.5 | 7.5 | 8.0 | 9.5 | 9.5 |
| Testing Framework | 5.0 | 5.0 | 9.0 | 9.5 | 9.5 |
| Tooling/SDK | 5.0 | 5.0 | 7.0 | 9.0 | 9.0 |
| Documentation | 5.0 | 5.0 | 7.0 | 9.0 | 9.0 |
| Agent Harness | 8.5 | 8.5 | 9.5 | 9.5 | 9.5 |
| ROM Hacking | 7.0 | 7.0 | 7.0 | 9.0 | 9.0 |
| **Overall** | **7.5** | **8.0** | **8.5** | **9.0** | **9.5** |

---

## 9. Sprint Plan

| Sprint | Phases | Duration | Deliverable |
|---|---|---|---|
| 1 | R1 (CD-ROM) | 3-5 days | Game progresses past polling loop |
| 2 | R2 (Hardware) + R3.1-R3.2 (Test profiles) | 3-4 days | MDEC/SPU/XA wired, basic test profiles |
| 3 | R3.3-R3.6 (Telemetry diff, triage, screenshots) | 3 days | Full QA framework |
| 4 | R4 (Visual QA + DuckStation bridge) | 2-3 days | English text verified in framebuffer |
| 5 | R5 (CLI, SDK, CMake, docs, tools) | 2-3 days | Public-ready tooling |
| 6 | R6 (Advanced: Lua, GDB, rewind, AI) | 2+ weeks | Industry-standard emulator |

---

## 10. Key Files to Create

| File | Phase | Purpose |
|---|---|---|
| `psx_memcard.h` | R2.5 | Memory card emulation |
| `psx_screenshot.h` | R3.6 | Screenshot capture & comparison |
| `vram_text_scanner.h` | R4.1 | VRAM text extraction |
| `font_table.h` | R4.2 | Font table mapping |
| `mips_trampoline.h` | R6.6 | MIPS hook/trampoline generator |
| `telemetry_diff.py` | R3.3 | Telemetry comparison tool |
| `auto_triage.py` | R3.4 | Automated crash classifier |
| `visual_qa.py` | R4.3 | Visual verification pipeline |
| `trace_compare.py` | R4.5 | Execution trace comparison |
| `visualize_trace.py` | R5.6 | Graphviz call graph generator |
| `bios_audit.py` | R5.7 | BIOS coverage audit |
| `patch_pipeline.py` | R6.7 | Unified patch build/verify/diff |
| `regression_runner.py` | R6.9 | Master regression runner |
| `ci_runner.py` | R6.9 | CI/CD entry point |
| `report_generator.py` | R6.10 | HTML report generator |
| `test_definitions.json` | R3.1 | Formal test specs |
| `test_matrix.json` | R3.2 | Disc × emulator test matrix |
| `CMakeLists.txt` | R5.3 | CMake build system |

## 11. Key Files to Modify

| File | Phase | Changes |
|---|---|---|
| `psx_emulator_core.cpp` | R1, R2 | Secondary status, BUSYSTS, seek, BFRD, DMA ch3, MDEC/SPU/XA wiring |
| `psx_test_station.h` | R1, R2 | CDROM_Controller struct, seek state, timing calibration, memcard |
| `psx_agent_runner.cpp` | R3, R5, R6 | Save state CLI, screenshot CLI, test profile loading, unified CLI flags |
| `agent_harness.h/.cpp` | R3 | Screenshot capture, enhanced triage, test result DB |
| `harness_runner.py` | R3 | Test definition support, regression runner integration |
| `orchestration_engine.h` | R6 | CLI flags for hooks/watches/auto-correct/telemetry/audit |

---

## 12. Known Issues & Risks

| Risk | Mitigation |
|---|---|
| CD-ROM timing calibration may not match real hardware | Use DuckStation trace as reference; compare VBlank-to-sector ratios |
| SPU/MDEC/XA headers exist but may have bugs | Round-trip test with known PSX FMV content before relying on output |
| Game polling loop root cause unknown | R1 fixes may not resolve; may need MIPS analysis of game code at 0x800967xx |
| No CI means regressions go undetected | R5.3 (CMake) + R6.9 (CI) address this, but deferred to sprint 5-6 |
| 51 Python scripts with overlap | Consolidate into `cybergrime_sdk` package during R5.2 |
| `psx_agent_runner.exe` locked by running instance | `taskkill /f /im psx_agent_runner.exe` before rebuild |

---

*This document is the canonical CyberGrime development roadmap. Update as phases are completed.*
