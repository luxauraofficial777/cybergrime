#!/usr/bin/env python3
"""Disassemble just the VBlank wait loop and the FMV function bodies."""
import struct

SECTOR_SIZE = 2352
DATA_OFFSET = 24
USER_SIZE = 2048

def read_sector_user(f, lba):
    f.seek(lba * SECTOR_SIZE + DATA_OFFSET)
    return f.read(USER_SIZE)

def read_exe_from_disc(disc_path, exe_lba=24, exe_size=678496):
    with open(disc_path, 'rb') as f:
        data = bytearray()
        sectors = (exe_size + USER_SIZE - 1) // USER_SIZE
        for i in range(sectors):
            chunk = read_sector_user(f, exe_lba + i)
            data.extend(chunk)
        return bytes(data[:exe_size])

def disasm(word, addr=0):
    op = (word >> 26) & 0x3F
    rs = (word >> 21) & 0x1F
    rt = (word >> 16) & 0x1F
    rd = (word >> 11) & 0x1F
    shamt = (word >> 6) & 0x1F
    funct = word & 0x3F
    imm = word & 0xFFFF
    simm = imm if imm < 0x8000 else imm - 0x10000
    target = word & 0x3FFFFFF
    
    regs = ['zero','at','v0','v1','a0','a1','a2','a3',
            't0','t1','t2','t3','t4','t5','t6','t7',
            's0','s1','s2','s3','s4','s5','s6','s7',
            't8','t9','k0','k1','gp','sp','fp','ra']
    
    if op == 0:
        if funct == 0x08: return f"jr {regs[rs]}"
        if funct == 0x09: return f"jalr {regs[rd]}, {regs[rs]}"
        if funct == 0x21: return f"addu {regs[rd]}, {regs[rs]}, {regs[rt]}"
        if funct == 0x23: return f"subu {regs[rd]}, {regs[rs]}, {regs[rt]}"
        if funct == 0x24: return f"and {regs[rd]}, {regs[rs]}, {regs[rt]}"
        if funct == 0x25: return f"or {regs[rd]}, {regs[rs]}, {regs[rt]}"
        if funct == 0x27: return f"nor {regs[rd]}, {regs[rs]}, {regs[rt]}"
        if funct == 0x2A: return f"slt {regs[rd]}, {regs[rs]}, {regs[rt]}"
        if funct == 0x2B: return f"sltu {regs[rd]}, {regs[rs]}, {regs[rt]}"
        if funct == 0x00: return f"sll {regs[rd]}, {regs[rt]}, {shamt}" if word != 0 else "nop"
        if funct == 0x02: return f"srl {regs[rd]}, {regs[rt]}, {shamt}"
        if funct == 0x03: return f"sra {regs[rd]}, {regs[rt]}, {shamt}"
        if funct == 0x04: return f"sllv {regs[rd]}, {regs[rt]}, {regs[rs]}"
        if funct == 0x06: return f"srlv {regs[rd]}, {regs[rt]}, {regs[rs]}"
        if funct == 0x07: return f"srav {regs[rd]}, {regs[rt]}, {regs[rs]}"
        if funct == 0x10: return f"mfhi {regs[rd]}"
        if funct == 0x12: return f"mflo {regs[rd]}"
        if funct == 0x18: return f"mult {regs[rs]}, {regs[rt]}"
        if funct == 0x19: return f"multu {regs[rs]}, {regs[rt]}"
        if funct == 0x20: return f"add {regs[rd]}, {regs[rs]}, {regs[rt]}"
        if funct == 0x22: return f"sub {regs[rd]}, {regs[rs]}, {regs[rt]}"
        if funct == 0x0C: return f"syscall 0x{(word >> 6) & 0xFFFFF:05X}"
        if funct == 0x0D: return f"break"
        return f"R-type f=0x{funct:02X}"
    if op == 0x01:
        if rt == 0: return f"bltz {regs[rs]}, 0x{addr+4+(simm<<2):08X}"
        if rt == 1: return f"bgez {regs[rs]}, 0x{addr+4+(simm<<2):08X}"
        return f"REGIMM rt={rt}"
    if op == 0x02: return f"j 0x{((target << 2) | (addr & 0xF0000000)):08X}"
    if op == 0x03: return f"jal 0x{((target << 2) | (addr & 0xF0000000)):08X}"
    if op == 0x04: return f"beq {regs[rs]}, {regs[rt]}, 0x{addr+4+(simm<<2):08X}"
    if op == 0x05: return f"bne {regs[rs]}, {regs[rt]}, 0x{addr+4+(simm<<2):08X}"
    if op == 0x06: return f"blez {regs[rs]}, 0x{addr+4+(simm<<2):08X}"
    if op == 0x07: return f"bgtz {regs[rs]}, 0x{addr+4+(simm<<2):08X}"
    if op == 0x08: return f"addi {regs[rt]}, {regs[rs]}, {simm}"
    if op == 0x09: return f"addiu {regs[rt]}, {regs[rs]}, {simm}"
    if op == 0x0A: return f"slti {regs[rt]}, {regs[rs]}, {simm}"
    if op == 0x0B: return f"sltiu {regs[rt]}, {regs[rs]}, {simm}"
    if op == 0x0C: return f"andi {regs[rt]}, {regs[rs]}, 0x{imm:04X}"
    if op == 0x0D: return f"ori {regs[rt]}, {regs[rs]}, 0x{imm:04X}"
    if op == 0x0E: return f"xori {regs[rt]}, {regs[rs]}, 0x{imm:04X}"
    if op == 0x0F: return f"lui {regs[rt]}, 0x{imm:04X}"
    if op == 0x20: return f"lb {regs[rt]}, {simm}({regs[rs]})"
    if op == 0x21: return f"lh {regs[rt]}, {simm}({regs[rs]})"
    if op == 0x23: return f"lw {regs[rt]}, {simm}({regs[rs]})"
    if op == 0x24: return f"lbu {regs[rt]}, {simm}({regs[rs]})"
    if op == 0x25: return f"lhu {regs[rt]}, {simm}({regs[rs]})"
    if op == 0x28: return f"sb {regs[rt]}, {simm}({regs[rs]})"
    if op == 0x29: return f"sh {regs[rt]}, {simm}({regs[rs]})"
    if op == 0x2B: return f"sw {regs[rt]}, {simm}({regs[rs]})"
    if op == 0x10: return f"mfc0 {regs[rt]}, {regs[rd]}"
    if op == 0x12: return f"mtc0 {regs[rt]}, {regs[rd]}"
    return f"op=0x{op:02X} w=0x{word:08X}"

disc = r"C:\LuxAura\VoidWalkers_Project\DQLOSTTRANSLATION\build_staging\dq4_reverse_a.bin"
orig_path = r"C:\LuxAura\VoidWalkers_Project\DQLOSTTRANSLATION\translation\SLUSP012.06_clean.bin"

# Read built disc EXE
exe = read_exe_from_disc(disc)
load_addr = struct.unpack_from('<I', exe, 0x18)[0]

# Read original EXE
with open(orig_path, 'rb') as f:
    orig = f.read()
orig_load = struct.unpack_from('<I', orig, 0x18)[0]

print(f"Built EXE load_addr=0x{load_addr:08X}")
print(f"Orig EXE load_addr=0x{orig_load:08X}")

# Disassemble the VBlank wait loop
print(f"\n=== VBlank wait loop (0x80096780 - 0x80096800) ===")
for addr in range(0x80096780, 0x80096800, 4):
    off = addr - load_addr + 0x800
    if 0 <= off and off + 4 <= len(exe):
        word = struct.unpack_from('<I', exe, off)[0]
        marker = ""
        if addr == 0x800967A4: marker = " <-- WAIT PC"
        if addr == 0x800967D0: marker = " <-- STUCK PC"
        print(f"  0x{addr:08X}: 0x{word:08X}  {disasm(word, addr)}{marker}")

# Disassemble original fmv1 function body (first 40 instructions)
print(f"\n=== Original fmv1 (0x8008AEF4) — first 40 instructions ===")
for i in range(40):
    addr = 0x8008AEF4 + i * 4
    off = addr - orig_load + 0x800
    if 0 <= off and off + 4 <= len(orig):
        word = struct.unpack_from('<I', orig, off)[0]
        print(f"  0x{addr:08X}: 0x{word:08X}  {disasm(word, addr)}")

# Disassemble original fmv2 function body (first 40 instructions)
print(f"\n=== Original fmv2 (0x8008CAD0) — first 40 instructions ===")
for i in range(40):
    addr = 0x8008CAD0 + i * 4
    off = addr - orig_load + 0x800
    if 0 <= off and off + 4 <= len(orig):
        word = struct.unpack_from('<I', orig, off)[0]
        print(f"  0x{addr:08X}: 0x{word:08X}  {disasm(word, addr)}")

# Count callers
fmv1_callers = 0
fmv2_callers = 0
for off in range(0, len(orig) - 4, 4):
    word = struct.unpack_from('<I', orig, off)[0]
    op = (word >> 26) & 0x3F
    if op == 0x03:
        target = (word & 0x3FFFFFF) << 2
        target |= 0x80000000
        if target == 0x8008AEF4: fmv1_callers += 1
        if target == 0x8008CAD0: fmv2_callers += 1

print(f"\n=== Caller counts ===")
print(f"  fmv1 (0x8008AEF4): {fmv1_callers} callers")
print(f"  fmv2 (0x8008CAD0): {fmv2_callers} callers")
