$j = Get-Content telemetry_render_50m.json -Raw | ConvertFrom-Json
Write-Host "=== RENDER 50M Run State ==="
Write-Host "Status: $($j.Pass_Status)"
Write-Host "Instructions: $($j.Instructions_Executed)"
Write-Host "VBlanks: $($j.VBlank_Count)"
Write-Host "Crashed: $($j.Crashed)"
Write-Host "Crash Reason: $($j.Crash_Reason)"
Write-Host "PC: $($j.Register_Dump.PC)"
Write-Host "GP: $($j.Register_Dump.gp)"
Write-Host ""

# Check for breakpoint hits in TTY
$tty = $j.TTY_Tail
Write-Host "TTY Tail (first 4000 chars):"
Write-Host $tty.Substring(0, [Math]::Min(4000, $tty.Length))
