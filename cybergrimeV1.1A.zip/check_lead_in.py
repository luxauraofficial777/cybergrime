#!/usr/bin/env python3
"""Check if disc has lead-in by comparing sectors 16 and 166."""
import struct

SECTOR_SIZE = 2352
DATA_OFFSET = 24

def read_sector_user(f, lba):
    f.seek(lba * SECTOR_SIZE + DATA_OFFSET)
    return f.read(2048)

disc = r"C:\LuxAura\VoidWalkers_Project\DQLOSTTRANSLATION\build_staging\dq4_reverse_a.bin"
dq4_disc = r"C:\LuxAura\VoidWalkers_Project\DQLOSTTRANSLATION\Dragon Quest IV - Michibikareshi Mono Tachi (Japan).bin"

with open(disc, 'rb') as f:
    print("=== Built disc ===")
    for lba in [0, 16, 22, 23, 24, 150, 166, 172, 173, 174, 356]:
        data = read_sector_user(f, lba)
        desc = ""
        if data[:5] == b'CD001':
            desc = " [PVD!]"
        elif data[:8] == b'PS-X EXE':
            desc = " [EXE!]"
        elif data[:4] == b'BOOT':
            desc = " [SYSTEM.CNF!]"
        print(f"  Sector {lba}: first 16 bytes = {data[:16].hex()}{desc}")

with open(dq4_disc, 'rb') as f:
    print("\n=== DQ4 original disc ===")
    for lba in [0, 16, 22, 23, 24, 150, 166, 172, 173, 174]:
        data = read_sector_user(f, lba)
        desc = ""
        if data[:5] == b'CD001':
            desc = " [PVD!]"
        elif data[:8] == b'PS-X EXE':
            desc = " [EXE!]"
        elif data[:4] == b'BOOT':
            desc = " [SYSTEM.CNF!]"
        print(f"  Sector {lba}: first 16 bytes = {data[:16].hex()}{desc}")
    
    # Check total sectors
    import os
    sz = os.path.getsize(dq4_disc)
    print(f"\n  Total size: {sz} bytes, {sz // 2352} sectors")
