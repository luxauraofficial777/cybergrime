#!/usr/bin/env python3
"""
duckstation_supervisor.py — Live supervisor wrapping DuckStation.

Uses duckstation_bridge.py to:
  1. Launch DuckStation with a disc
  2. Discover PSX RAM and CPU state
  3. Poll PC/registers at configurable interval
  4. Detect stall loops
  5. Feed telemetry to build_orchestrator.py for analysis
  6. Inject patches when orchestrator commands
  7. Log full session

Usage:
  python duckstation_supervisor.py --cue dq4_frankenstein_v38a.cue --monitor 60
  python duckstation_supervisor.py --cue dq4_frankenstein_v40a.cue --monitor 120 --inject 0x800D9E80:0x01000000
"""

import argparse
import json
import os
import sys
import time
from typing import Optional, List, Dict

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from duckstation_bridge import DuckStationBridge, MIPS_REGS


class DuckStationSupervisor:
    """Live supervisor that monitors and controls DuckStation."""

    def __init__(self, cue_path: str, bios_dir: str = None,
                 poll_interval: float = 0.05,
                 output_log: str = "supervisor_log.json"):
        self.cue_path = cue_path
        self.bios_dir = bios_dir
        self.poll_interval = poll_interval
        self.output_log = output_log

        self.bridge = DuckStationBridge(bios_dir=bios_dir)
        self.running = False
        self.log: List[dict] = []
        self.breakpoints: Dict[int, dict] = {}
        self.watchpoints: Dict[int, dict] = {}
        self.inject_queue: List[dict] = []
        self._scheduled_injections: List[dict] = []

        # Stall detection
        self.stall_window = 128
        self.stall_detected = False
        self.stall_pc: Optional[int] = None

        # Telemetry counters
        self.sample_count = 0
        self.start_time = 0.0

    def add_breakpoint(self, psx_addr: int, callback=None, description: str = ""):
        """Add a software breakpoint (polled, not hardware)."""
        self.breakpoints[psx_addr] = {
            'address': psx_addr,
            'callback': callback,
            'description': description,
            'hit_count': 0,
        }
        print(f"[SUPERVISOR] Breakpoint at 0x{psx_addr:08X}: {description}")

    def add_watchpoint(self, psx_addr: int, size: int = 4,
                       callback=None, description: str = ""):
        """Add a memory watchpoint (polls for value changes)."""
        initial = self.bridge.read_u32(psx_addr)
        self.watchpoints[psx_addr] = {
            'address': psx_addr,
            'size': size,
            'callback': callback,
            'description': description,
            'last_value': initial,
            'change_count': 0,
        }
        print(f"[SUPERVISOR] Watchpoint at 0x{psx_addr:08X}: {description} "
              f"(initial=0x{initial:08X})" if initial is not None
              else f"[SUPERVISOR] Watchpoint at 0x{psx_addr:08X}: {description}")

    def queue_injection(self, psx_addr: int, data: bytes, description: str = ""):
        """Queue a memory injection to be applied on next poll cycle."""
        self.inject_queue.append({
            'address': psx_addr,
            'data': data,
            'description': description,
            'timestamp': time.time(),
        })
        print(f"[SUPERVISOR] Queued injection: 0x{psx_addr:08X} "
              f"({len(data)} bytes) — {description}")

    def queue_injection_u32(self, psx_addr: int, value: int, description: str = ""):
        """Queue a 32-bit word injection."""
        import struct
        self.queue_injection(psx_addr, struct.pack('<I', value & 0xFFFFFFFF), description)

    def run(self, duration: float = 60.0):
        """Run the supervisor loop for the specified duration."""
        print(f"\n[SUPERVISOR] Starting — disc: {self.cue_path}")
        print(f"[SUPERVISOR] Duration: {duration}s, poll interval: {self.poll_interval}s")

        # Launch DuckStation
        self.bridge.launch(self.cue_path)

        # Wait for RAM
        if not self.bridge.wait_for_ram(timeout=30):
            print("[SUPERVISOR] FATAL: Could not find PSX RAM")
            return

        # Wait for game to boot past BIOS init (so $gp = 0x800BC668)
        print("[SUPERVISOR] Waiting 5s for game to boot past BIOS init...")
        time.sleep(5)

        # Find CPU state
        self.bridge._find_cpu_state(timeout=15)

        # Set up default breakpoints for our critical addresses
        self._setup_default_breakpoints()

        self.running = True
        self.start_time = time.time()
        end_time = self.start_time + duration

        # Reset scheduled injection fire times relative to monitoring start
        for inj in self._scheduled_injections:
            inj['fire_time'] = self.start_time + (inj.get('delay_offset', 0) or
                                                   (inj['fire_time'] - time.time()))

        print(f"\n[SUPERVISOR] Monitoring started at {time.strftime('%H:%M:%S')}")
        print(f"[SUPERVISOR] Breakpoints: {len(self.breakpoints)}, "
              f"Watchpoints: {len(self.watchpoints)}")
        print()

        while self.running and time.time() < end_time:
            # Check if DuckStation is still alive
            if self.bridge.process and self.bridge.process.poll() is not None:
                print("[SUPERVISOR] DuckStation exited")
                break

            # Poll PC
            pc = self.bridge.read_pc()
            if pc is not None:
                self._handle_pc(pc)

            # Process injections
            self._process_injections()

            # Process scheduled injections
            now = time.time()
            for inj in self._scheduled_injections[:]:
                if now >= inj['fire_time']:
                    self.queue_injection(inj['address'], inj['data'], inj['description'])
                    self._scheduled_injections.remove(inj)

            # Check watchpoints
            self._check_watchpoints()

            # Log sample
            if self.sample_count % 100 == 0:  # Log every 100 samples
                self._log_sample(pc)

            self.sample_count += 1
            time.sleep(self.poll_interval)

        # Final telemetry
        self._log_final()
        self._write_log()

        print(f"\n[SUPERVISOR] Session complete:")
        print(f"  Samples: {self.sample_count}")
        print(f"  Duration: {time.time() - self.start_time:.1f}s")
        print(f"  Stall detected: {self.stall_detected}")
        if self.stall_pc:
            print(f"  Stall PC: 0x{self.stall_pc:08X}")
        print(f"  Log: {self.output_log}")

        self.bridge.close()

    def _setup_default_breakpoints(self):
        """Set up breakpoints for known critical addresses."""
        critical_pcs = {
            0x8008E284: "BSS clear entry",
            0x8008E294: "BSS clear loop",
            0x800D9E80: "Thread entry (should be non-zero)",
            0x80073670: "Huffman decompress",
            0x8009885C: "Stall loop (event flag poll)",
            0x80098780: "Stall loop variant",
            0x800BCCF0: "Copy routine entry (PC0)",
            0x800BC700: "Copy routine (tree copy)",
        }
        for pc, desc in critical_pcs.items():
            self.add_breakpoint(pc, description=desc)

        # Watch thread entry for zeroing
        self.add_watchpoint(0x800D9E80, description="Thread entry — watch for zeroing")
        # Watch BSS end instruction (file offset 0x8A198 - 0x800 header + 0x80017F00 load)
        self.add_watchpoint(0x800A1898, description="BSS end addiu instruction")
        # Watch tree at 0x80100000 (if reloc payload present)
        self.add_watchpoint(0x80100000, description="Tree at 0x80100000")

    def _handle_pc(self, pc: int):
        """Handle a PC sample — check breakpoints, detect stalls."""
        self.bridge.pc_history.append(pc)
        if len(self.bridge.pc_history) > self.bridge.max_pc_history:
            self.bridge.pc_history = self.bridge.pc_history[-self.bridge.max_pc_history:]

        # Check breakpoints
        if pc in self.breakpoints:
            bp = self.breakpoints[pc]
            bp['hit_count'] += 1
            if bp['hit_count'] <= 5:  # Only log first 5 hits
                regs = self.bridge.read_all_regs()
                print(f"[BP] 0x{pc:08X} hit #{bp['hit_count']} — {bp['description']}")
                if regs:
                    print(f"      $v0=0x{regs.get('v0',0):08X} "
                          f"$v1=0x{regs.get('v1',0):08X} "
                          f"$sp=0x{regs.get('sp',0):08X} "
                          f"$ra=0x{regs.get('ra',0):08X}")

                # Special handling for BSS clear loop
                if pc == 0x8008E294 and bp['hit_count'] == 1:
                    v1 = regs.get('v1', 0) if regs else 0
                    print(f"      BSS clear: $v1 (end) = 0x{v1:08X}")
                    if v1 > 0x800D9E80:
                        print(f"      ⚠ BSS end > thread entry — WILL ZERO IT!")

                # Special handling for thread entry
                if pc == 0x800D9E80 and bp['hit_count'] == 1:
                    entry = self.bridge.read_u32(0x800D9E80)
                    print(f"      Thread entry value: 0x{entry:08X}"
                          f"{' ⚠ ZEROED!' if entry == 0 else ' ✓'}")

            if bp['callback']:
                bp['callback'](pc, regs)

        # Stall detection
        stall = self.bridge.detect_stall(window=self.stall_window)
        if stall and not self.stall_detected:
            self.stall_detected = True
            self.stall_pc = stall
            print(f"\n[SUPERVISOR] ⚠ STALL DETECTED at PC=0x{stall:08X}")
            print(f"[SUPERVISOR]   PC has been in same range for {self.stall_window} samples")
            regs = self.bridge.read_all_regs()
            if regs:
                print(f"[SUPERVISOR]   $v0=0x{regs.get('v0',0):08X} "
                      f"$v1=0x{regs.get('v1',0):08X} "
                      f"$a0=0x{regs.get('a0',0):08X} "
                      f"$ra=0x{regs.get('ra',0):08X}")

            # Dump critical state
            self._dump_stall_state(stall)

    def _dump_stall_state(self, stall_pc: int):
        """Dump critical state when a stall is detected."""
        print(f"\n[SUPERVISOR] === STALL STATE DUMP ===")

        # Read thread entry
        thread_entry = self.bridge.read_u32(0x800D9E80)
        print(f"  Thread entry (0x800D9E80): 0x{thread_entry:08X}"
              f"{' ⚠ ZEROED' if thread_entry == 0 else ''}")

        # Read BSS clear boundaries
        print(f"  BSS area sample (0x800BC668): 0x{self.bridge.read_u32(0x800BC668):08X}")
        print(f"  BSS area sample (0x800D9E80): 0x{self.bridge.read_u32(0x800D9E80):08X}")
        print(f"  BSS area sample (0x800F4980): 0x{self.bridge.read_u32(0x800F4980):08X}")
        print(f"  BSS end instr (0x800A1898): 0x{self.bridge.read_u32(0x800A1898):08X}")

        # Read tree
        tree = self.bridge.read_u32(0x80100000)
        print(f"  Tree at 0x80100000: 0x{tree:08X}"
              f"{' ⚠ ZEROED' if tree == 0 else ''}")

        # Dump 32 bytes at stall PC
        stall_data = self.bridge.read_mem(stall_pc, 32)
        if stall_data:
            words = [int.from_bytes(stall_data[i:i+4], 'little')
                     for i in range(0, 32, 4)]
            print(f"  Instructions at stall PC:")
            for i, w in enumerate(words):
                print(f"    0x{stall_pc + i*4:08X}: 0x{w:08X}")

        print(f"[SUPERVISOR] === END STALL DUMP ===\n")

    def _process_injections(self):
        """Process queued memory injections."""
        while self.inject_queue:
            inj = self.inject_queue.pop(0)
            ok = self.bridge.write_mem(inj['address'], inj['data'])
            print(f"[SUPERVISOR] Injection: 0x{inj['address']:08X} "
                  f"← {inj['data'].hex()} {'✓' if ok else '✗'} — {inj['description']}")

    def _check_watchpoints(self):
        """Check all watchpoints for value changes."""
        for addr, wp in self.watchpoints.items():
            current = self.bridge.read_u32(addr)
            if current is None:
                continue
            if current != wp['last_value']:
                wp['change_count'] += 1
                old = wp['last_value']
                wp['last_value'] = current
                if wp['change_count'] <= 10:  # Log first 10 changes
                    print(f"[WP] 0x{addr:08X}: 0x{old:08X} → 0x{current:08X} "
                          f"#{wp['change_count']} — {wp['description']}")

    def _log_sample(self, pc: int):
        """Log a periodic telemetry sample."""
        regs = self.bridge.read_all_regs()
        elapsed = time.time() - self.start_time

        sample = {
            'time': elapsed,
            'sample': self.sample_count,
            'pc': f'0x{pc:08X}' if pc else 'N/A',
            'regs': {k: f'0x{v:08X}' for k, v in regs.items()} if regs else {},
            'stall': self.stall_detected,
        }
        self.log.append(sample)

        # Periodic console output
        pc_str = f'0x{pc:08X}' if pc else 'N/A'
        stall_str = ' ⚠STALL' if self.stall_detected else ''
        print(f"[T+{elapsed:6.1f}] PC={pc_str} samples={self.sample_count}{stall_str}")

    def _log_final(self):
        """Log final state."""
        regs = self.bridge.read_all_regs()
        pc = self.bridge.read_pc()

        final = {
            'time': time.time() - self.start_time,
            'type': 'final',
            'pc': f'0x{pc:08X}' if pc else 'N/A',
            'regs': {k: f'0x{v:08X}' for k, v in regs.items()} if regs else {},
            'stall_detected': self.stall_detected,
            'stall_pc': f'0x{self.stall_pc:08X}' if self.stall_pc else None,
            'breakpoint_hits': {
                f'0x{bp["address"]:08X}': bp['hit_count']
                for bp in self.breakpoints.values()
            },
            'watchpoint_changes': {
                f'0x{wp["address"]:08X}': wp['change_count']
                for wp in self.watchpoints.values()
            },
        }
        self.log.append(final)

    def _write_log(self):
        """Write the full session log."""
        output = {
            'session': {
                'cue': self.cue_path,
                'start_time': self.start_time,
                'duration': time.time() - self.start_time,
                'samples': self.sample_count,
                'stall_detected': self.stall_detected,
                'stall_pc': f'0x{self.stall_pc:08X}' if self.stall_pc else None,
            },
            'breakpoints': {
                f'0x{bp["address"]:08X}': {
                    'description': bp['description'],
                    'hits': bp['hit_count'],
                }
                for bp in self.breakpoints.values()
            },
            'watchpoints': {
                f'0x{wp["address"]:08X}': {
                    'description': wp['description'],
                    'changes': wp['change_count'],
                    'final_value': f'0x{wp["last_value"]:08X}' if wp['last_value'] else 'N/A',
                }
                for wp in self.watchpoints.values()
            },
            'log': self.log,
        }

        with open(self.output_log, 'w') as f:
            json.dump(output, f, indent=2)


def main():
    parser = argparse.ArgumentParser(
        description="DuckStation Supervisor — live telemetry & injection bridge"
    )
    parser.add_argument("--cue", required=True, help="CUE file to launch")
    parser.add_argument("--bios", default=None, help="BIOS directory path")
    parser.add_argument("--monitor", type=float, default=60,
                        help="Monitor duration in seconds")
    parser.add_argument("--poll", type=float, default=0.05,
                        help="Poll interval in seconds (default: 50ms)")
    parser.add_argument("--inject", action="append", default=[],
                        help="Queue injection: ADDR:HEXBYTES (can repeat)")
    parser.add_argument("--inject-delay", type=float, default=0,
                        help="Delay before applying injections (seconds after monitoring starts)")
    parser.add_argument("--output", default="supervisor_log.json",
                        help="Output log file")
    args = parser.parse_args()

    sup = DuckStationSupervisor(
        cue_path=args.cue,
        bios_dir=args.bios,
        poll_interval=args.poll,
        output_log=args.output,
    )

    # Queue any injections
    inject_delay = args.inject_delay
    for inj_spec in args.inject:
        parts = inj_spec.split(':')
        if len(parts) == 2:
            addr = int(parts[0], 0)
            hex_str = parts[1]
            if hex_str.startswith('0x'):
                hex_str = hex_str[2:]
            data = bytes.fromhex(hex_str)
            if inject_delay > 0:
                # Schedule delayed injection
                sup._scheduled_injections.append({
                    'address': addr,
                    'data': data,
                    'description': f"CLI delayed injection: {inj_spec}",
                    'fire_time': time.time() + inject_delay,
                    'delay_offset': inject_delay,
                })
            else:
                sup.queue_injection(addr, data, f"CLI injection: {inj_spec}")

    sup.run(duration=args.monitor)


if __name__ == "__main__":
    main()
