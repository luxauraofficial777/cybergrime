#!/usr/bin/env python3
"""
Comprehensive DQ4 disc scanner: find STR/FMV sectors, verify sector formats,
and identify the exact DQ4 intro FMV location for the Frankenstein build.

PSX CD-ROM MODE2 raw sector layout (2352 bytes):
  0-11:   Sync pattern (00 FF*10 00)
  12-14:  MSF address (BCD)
  15:     Mode byte (1 or 2)
  16-19:  Subheader (file#, channel#, submode, coding info) [MODE2 only]
  20-23:  Subheader copy (repeat of 16-19) [MODE2 only]
  24-2071: User data (Form1: 2048 bytes, Form2: 2324 bytes)
  2072+:  EDC/ECC or spare

Submode byte (offset 18) flags:
  bit 0 (0x01): End of File
  bit 1 (0x02): Real Time
  bit 2 (0x04): Form2
  bit 3 (0x08): Trigger
  bit 4 (0x10): Data
  bit 5 (0x20): Audio
  bit 6 (0x40): Video
  bit 7 (0x80): Audio-Video (interleaved STR)
"""
import struct
import os

DQ4_DISC = r"C:\LuxAura\VoidWalkers_Project\DQLOSTTRANSLATION\Dragon Quest IV - Michibikareshi Mono Tachi (Japan).bin"
DW7_DISC = r"C:\LuxAura\VoidWalkers_Project\DQLOSTTRANSLATION\DW7D1\DW7D1.bin"
SECTOR_SIZE = 2352
USER_SIZE = 2048

def to_bcd(val):
    return ((val // 10) << 4) | (val % 10)

def lba_to_bcd_msf(lba):
    m = lba // (75 * 60)
    s = (lba // 75) % 60
    f = lba % 75
    return (to_bcd(m), to_bcd(s), to_bcd(f))

def scan_disc_modes(disc_path, max_sectors=None):
    """Scan disc and report mode byte distribution and submode flags."""
    sz = os.path.getsize(disc_path)
    total = sz // SECTOR_SIZE
    if max_sectors:
        total = min(total, max_sectors)
    
    mode_counts = {}
    submode_ranges = {}  # submode_value -> [(start, end, count), ...]
    current_submode = None
    current_start = 0
    
    with open(disc_path, 'rb') as f:
        for lba in range(total):
            f.seek(lba * SECTOR_SIZE + 15)
            mode_byte = f.read(1)[0]
            mode_counts[mode_byte] = mode_counts.get(mode_byte, 0) + 1
            
            if mode_byte == 2:
                f.seek(lba * SECTOR_SIZE + 18)
                submode = f.read(1)[0]
            else:
                submode = 0
            
            if submode != current_submode:
                if current_submode is not None and current_submode != 0:
                    if current_submode not in submode_ranges:
                        submode_ranges[current_submode] = []
                    submode_ranges[current_submode].append((current_start, lba - 1, lba - current_start))
                current_submode = submode
                current_start = lba
    
    if current_submode is not None and current_submode != 0:
        if current_submode not in submode_ranges:
            submode_ranges[current_submode] = []
        submode_ranges[current_submode].append((current_start, total - 1, total - current_start))
    
    return mode_counts, submode_ranges

def scan_str_sectors(disc_path, max_sectors=None):
    """Find STR/FMV sectors using correct submode offset (byte 18)."""
    sz = os.path.getsize(disc_path)
    total = sz // SECTOR_SIZE
    if max_sectors:
        total = min(total, max_sectors)
    
    ranges = []
    in_str = False
    start_lba = 0
    
    with open(disc_path, 'rb') as f:
        for lba in range(total):
            f.seek(lba * SECTOR_SIZE + 15)
            mode_byte = f.read(1)[0]
            
            is_str = False
            if mode_byte == 2:
                f.seek(lba * SECTOR_SIZE + 18)
                submode = f.read(1)[0]
                # STR = realtime + (video OR audio-video)
                is_str = bool(submode & 0x02) and (bool(submode & 0x40) or bool(submode & 0x80))
            
            if is_str and not in_str:
                in_str = True
                start_lba = lba
            elif not is_str and in_str:
                ranges.append((start_lba, lba - 1, lba - start_lba))
                in_str = False
    
    if in_str:
        ranges.append((start_lba, total - 1, total - start_lba))
    
    return ranges

def scan_for_str_headers(disc_path, max_sectors=None):
    """Scan user data for PSX STR frame headers (0x00 0x00 0x01 0xBA = MPEG)."""
    sz = os.path.getsize(disc_path)
    total = sz // SECTOR_SIZE
    if max_sectors:
        total = min(total, max_sectors)
    
    hits = []
    with open(disc_path, 'rb') as f:
        for lba in range(total):
            f.seek(lba * SECTOR_SIZE + 24)  # User data start
            data = f.read(8)
            # PSX STR typically starts with sector header: 0x00 0x00 0x01 0xBA (MPEG pack)
            # or STR frame: version (0x80 or 0x00), etc.
            if data[:4] == b'\x00\x00\x01\xBA':
                hits.append(lba)
            # Also check for PSX STR frame header: 0x00 0x00 0x01 0xBF (MPEG system header)
            elif data[:4] == b'\x00\x00\x01\xBF':
                hits.append(lba)
    
    return hits

def scan_all_submodes(disc_path, max_sectors=None):
    """List all unique submode values and their sector counts."""
    sz = os.path.getsize(disc_path)
    total = sz // SECTOR_SIZE
    if max_sectors:
        total = min(total, max_sectors)
    
    submode_counts = {}
    with open(disc_path, 'rb') as f:
        for lba in range(total):
            f.seek(lba * SECTOR_SIZE + 15)
            mode_byte = f.read(1)[0]
            if mode_byte == 2:
                f.seek(lba * SECTOR_SIZE + 18)
                submode = f.read(1)[0]
                key = (mode_byte, submode)
                submode_counts[key] = submode_counts.get(key, 0) + 1
            else:
                key = (mode_byte, 0)
                submode_counts[key] = submode_counts.get(key, 0) + 1
    
    return submode_counts

def main():
    print("=" * 70)
    print("  DQ4 + DW7 Disc Structure Analysis")
    print("=" * 70)
    
    for name, path in [("DQ4", DQ4_DISC), ("DW7", DW7_DISC)]:
        sz = os.path.getsize(path)
        total = sz // SECTOR_SIZE
        print(f"\n{'='*70}")
        print(f"  {name} Disc: {sz:,} bytes ({sz/1024/1024:.1f} MB, {total:,} sectors)")
        print(f"{'='*70}")
        
        # Mode distribution
        print(f"\n  Mode byte distribution:")
        mode_counts, submode_ranges = scan_disc_modes(path, max_sectors=min(total, 5000))
        for mode, count in sorted(mode_counts.items()):
            print(f"    Mode {mode}: {count} sectors (in first 5000)")
        
        # All submode values
        print(f"\n  Submode value distribution (first 5000 sectors):")
        sm_counts = scan_all_submodes(path, max_sectors=5000)
        for (mode, sm), count in sorted(sm_counts.items()):
            flags = []
            if sm & 0x01: flags.append("EOF")
            if sm & 0x02: flags.append("RT")
            if sm & 0x04: flags.append("Form2")
            if sm & 0x08: flags.append("Trigger")
            if sm & 0x10: flags.append("Data")
            if sm & 0x20: flags.append("Audio")
            if sm & 0x40: flags.append("Video")
            if sm & 0x80: flags.append("AV")
            flag_str = "|".join(flags) if flags else "none"
            print(f"    Mode={mode} Submode=0x{sm:02X} ({flag_str}): {count} sectors")
        
        # STR ranges
        print(f"\n  STR/FMV sector ranges (submode scan, full disc):")
        str_ranges = scan_str_sectors(path)
        total_str = sum(r[2] for r in str_ranges)
        print(f"    Found {len(str_ranges)} STR ranges, total {total_str} sectors ({total_str * USER_SIZE / 1024 / 1024:.1f} MB)")
        
        for i, (start, end, count) in enumerate(str_ranges[:30]):
            size_mb = count * USER_SIZE / 1024 / 1024
            bcd_m, bcd_s, bcd_f = lba_to_bcd_msf(start)
            bcd_str = f"{bcd_m:02X}:{bcd_s:02X}:{bcd_f:02X}"
            print(f"    {i:3d}  LBA {start:7d}-{end:7d}  {count:6d} sectors  {size_mb:6.1f}MB  BCD {bcd_str}")
        
        if len(str_ranges) > 30:
            print(f"    ... and {len(str_ranges) - 30} more ranges")
        
        # MPEG pack headers
        print(f"\n  MPEG pack header scan (0x000001BA, first 10000 sectors):")
        mpeg_hits = scan_for_str_headers(path, max_sectors=10000)
        if mpeg_hits:
            print(f"    Found {len(mpeg_hits)} MPEG pack headers")
            for h in mpeg_hits[:20]:
                bcd_m, bcd_s, bcd_f = lba_to_bcd_msf(h)
                print(f"    LBA {h:7d}  BCD {bcd_m:02X}:{bcd_s:02X}:{bcd_f:02X}")
        else:
            print(f"    No MPEG pack headers found in first 10000 sectors")
    
    # Summary for build plan
    print(f"\n{'='*70}")
    print(f"  BUILD PLAN VERIFICATION")
    print(f"{'='*70}")
    
    dq4_sz = os.path.getsize(DQ4_DISC)
    dq4_total = dq4_sz // SECTOR_SIZE
    
    hbd_start = 354
    hbd_size = 319436800
    hbd_sectors = hbd_size // USER_SIZE  # 155975
    hbd_end = hbd_start + hbd_sectors - 1  # 156328
    
    print(f"  HBD at LBA {hbd_start} to {hbd_end} ({hbd_sectors} sectors)")
    print(f"  Free space after HBD: LBA {hbd_end + 1} to {dq4_total - 1} ({dq4_total - hbd_end - 1} sectors)")
    print(f"  Free space: {(dq4_total - hbd_end - 1) * USER_SIZE / 1024:.0f} KB")
    
    # Check DQ4 STR ranges for the first one (intro FMV)
    dq4_strs = scan_str_sectors(DQ4_DISC)
    if dq4_strs:
        first_str = dq4_strs[0]
        bcd_m, bcd_s, bcd_f = lba_to_bcd_msf(first_str[0])
        print(f"\n  DQ4 first STR range: LBA {first_str[0]}-{first_str[1]} ({first_str[2]} sectors, {first_str[2]*USER_SIZE/1024/1024:.1f} MB)")
        print(f"  BCD MSF: {bcd_m:02X}:{bcd_s:02X}:{bcd_f:02X}")
        print(f"  BCD bytes for patch: 0x{bcd_m:02X}, 0x{bcd_s:02X}, 0x{bcd_f:02X}")
        
        # If we place this STR right after HBD at LBA 156329
        new_str_lba = hbd_end + 1  # 156329
        bcd_m2, bcd_s2, bcd_f2 = lba_to_bcd_msf(new_str_lba)
        print(f"\n  If STR placed at LBA {new_str_lba}:")
        print(f"  BCD MSF: {bcd_m2:02X}:{bcd_s2:02X}:{bcd_f2:02X}")
        print(f"  BCD bytes for patch: 0x{bcd_m2:02X}, 0x{bcd_s2:02X}, 0x{bcd_f2:02X}")
        print(f"  STR size: {first_str[2]*USER_SIZE/1024/1024:.1f} MB ({first_str[2]} sectors)")
        print(f"  STR end: LBA {new_str_lba + first_str[2] - 1}")
        print(f"  Disc end: LBA {dq4_total - 1}")
        print(f"  Fits? {'YES' if new_str_lba + first_str[2] - 1 < dq4_total else 'NO'}")
    else:
        print(f"\n  *** NO STR RANGES FOUND ON DQ4 DISC ***")
        print(f"  DQ4 may not have standalone STR/FMV sectors.")
        print(f"  FMV data may be embedded within HBD, or DQ4 uses a different video format.")
        
        # Check if DQ4 HBD region contains any STR-like submode sectors
        print(f"\n  Checking DQ4 HBD region (LBA 362-156336) for any non-data submodes...")
        with open(DQ4_DISC, 'rb') as f:
            interesting = []
            for lba in range(362, min(156337, dq4_total)):
                f.seek(lba * SECTOR_SIZE + 15)
                mode = f.read(1)[0]
                if mode == 2:
                    f.seek(lba * SECTOR_SIZE + 18)
                    sm = f.read(1)[0]
                    if sm & 0x02 or sm & 0x40 or sm & 0x80:  # RT or Video or AV
                        interesting.append((lba, mode, sm))
            if interesting:
                print(f"    Found {len(interesting)} interesting sectors in HBD region:")
                for lba, mode, sm in interesting[:20]:
                    flags = []
                    if sm & 0x02: flags.append("RT")
                    if sm & 0x04: flags.append("Form2")
                    if sm & 0x10: flags.append("Data")
                    if sm & 0x20: flags.append("Audio")
                    if sm & 0x40: flags.append("Video")
                    if sm & 0x80: flags.append("AV")
                    print(f"    LBA {lba:7d}  Mode={mode} Submode=0x{sm:02X} ({'|'.join(flags)})")
            else:
                print(f"    No RT/Video/AV submodes found in HBD region")
        
        # Check pre-HBD region (LBA 338-361) for STR
        print(f"\n  Checking pre-HBD region (LBA 338-361) for STR...")
        with open(DQ4_DISC, 'rb') as f:
            for lba in range(338, min(362, dq4_total)):
                f.seek(lba * SECTOR_SIZE + 15)
                mode = f.read(1)[0]
                if mode == 2:
                    f.seek(lba * SECTOR_SIZE + 18)
                    sm = f.read(1)[0]
                else:
                    sm = 0
                flags = []
                if sm & 0x02: flags.append("RT")
                if sm & 0x04: flags.append("Form2")
                if sm & 0x10: flags.append("Data")
                if sm & 0x20: flags.append("Audio")
                if sm & 0x40: flags.append("Video")
                if sm & 0x80: flags.append("AV")
                print(f"    LBA {lba:7d}  Mode={mode} Submode=0x{sm:02X} ({'|'.join(flags) if flags else 'none'})")
                # Also show first 16 bytes of user data
                f.seek(lba * SECTOR_SIZE + 24)
                data = f.read(16)
                print(f"           Data: {data.hex()}")
    
    # DW7 STR ranges for comparison
    print(f"\n  DW7 STR/FMV ranges (for comparison):")
    dw7_strs = scan_str_sectors(DW7_DISC)
    total_dw7_str = sum(r[2] for r in dw7_strs)
    print(f"    Found {len(dw7_strs)} STR ranges, total {total_dw7_str} sectors ({total_dw7_str * USER_SIZE / 1024 / 1024:.1f} MB)")
    for i, (start, end, count) in enumerate(dw7_strs[:10]):
        bcd_m, bcd_s, bcd_f = lba_to_bcd_msf(start)
        print(f"    {i:3d}  LBA {start:7d}-{end:7d}  {count:6d} sectors  {count*USER_SIZE/1024/1024:6.1f}MB  BCD {bcd_m:02X}:{bcd_s:02X}:{bcd_f:02X}")

if __name__ == '__main__':
    main()
