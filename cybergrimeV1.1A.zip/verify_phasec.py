#!/usr/bin/env python3
"""Verify Phase C disc: EXE string, ISO directory, LBA references."""
import struct

DISC = r'c:\LuxAura\VoidWalkers_Project\DQLOSTTRANSLATION\dq4_phaseC_build1.bin'
EXE_LBA = 24
LOAD_ADDR = 0x80017F00
EXE_HEADER = 0x800

with open(DISC, 'rb') as f:
    disc = f.read()

def read_sector(lba, mode2=True):
    """Read user data from a MODE2/2352 sector."""
    offset = lba * 2352 + 24
    return disc[offset:offset + 2048]

def read_exe_from_disc(exe_lba, exe_size):
    """Read EXE from disc sector-by-sector."""
    sectors_needed = (exe_size + 2047) // 2048
    exe = bytearray()
    for i in range(sectors_needed):
        exe.extend(read_sector(exe_lba + i))
    return bytes(exe[:exe_size])

# Read ISO directory
print("=== ISO DIRECTORY (from PVD) ===")
pvd = read_sector(16)
root_dr = pvd[156:156+34]
root_lba = struct.unpack_from('<I', root_dr, 2)[0]
root_size = struct.unpack_from('<I', root_dr, 10)[0]
root_data = read_sector(root_lba)

pos = 0
files = {}
while pos < len(root_data):
    dr_len = root_data[pos]
    if dr_len == 0:
        break
    lba = struct.unpack_from('<I', root_data, pos + 2)[0]
    size = struct.unpack_from('<I', root_data, pos + 10)[0]
    flags = root_data[pos + 25]
    name_len = root_data[pos + 32]
    name = root_data[pos + 33:pos + 33 + name_len].decode('ascii', errors='replace')
    if name and name[0] != '\x00':
        type_str = "DIR" if flags & 0x02 else "FILE"
        print(f"  {type_str} LBA={lba:6d} size={size:10d}  {name!r}")
        files[name.split(';1')[0]] = (lba, size)
    pos += dr_len

# Read EXE
print("\n=== EXE HEADER ===")
exe_size = files.get('SLUSP012.06', (24, 960948))[1]
exe_lba = files.get('SLUSP012.06', (24, 960948))[0]
print(f"  EXE LBA: {exe_lba}, size: {exe_size}")
exe = read_exe_from_disc(exe_lba, exe_size)
print(f"  EXE magic: {exe[:8]}")
pc0 = struct.unpack_from('<I', exe, 0x10)[0]
load_addr = struct.unpack_from('<I', exe, 0x18)[0]
text_size = struct.unpack_from('<I', exe, 0x1C)[0]
print(f"  PC0: 0x{pc0:08X}, Load: 0x{load_addr:08X}, Text: 0x{text_size:08X} ({text_size} bytes)")

# Search for HBD filename string in EXE
print("\n=== HBD FILENAME STRING IN EXE ===")
for pattern, label in [(b'hbd1ps1d.w71', 'w71 (ORIGINAL)'), (b'hbd1ps1d.q41', 'q41 (PATCHED)'), (b'HBD1PS1D.W71', 'W71 UPPER'), (b'HBD1PS1D.Q41', 'Q41 UPPER')]:
    idx = 0
    count = 0
    while True:
        idx = exe.find(pattern, idx)
        if idx == -1:
            break
        ram = load_addr + idx - EXE_HEADER
        print(f"  Found {label} at file offset 0x{idx:X} (RAM 0x{ram:08X})")
        # Show context
        ctx_start = max(0, idx - 16)
        ctx_end = min(len(exe), idx + len(pattern) + 16)
        ctx = exe[ctx_start:ctx_end]
        print(f"    Context: {ctx.hex()}")
        idx += 1
        count += 1
    if count == 0:
        print(f"  {label}: NOT FOUND")

# Check LBA references in EXE — look for sector 356 (HBD on Frankenstein Phase B) and 354 (HBD on DW7)
print("\n=== LBA REFERENCES IN EXE ===")
for target_lba, label in [(356, "HBD@356 (Frankenstein Phase B)"), (354, "HBD@354 (DW7 original)"), (362, "HBD@362 (DQ4-JP)")]:
    target_bytes = struct.pack('<I', target_lba)
    idx = 0
    count = 0
    while True:
        idx = exe.find(target_bytes, idx)
        if idx == -1:
            break
        ram = load_addr + idx - EXE_HEADER
        # Check if it's in code or data region
        region = "CODE" if idx < text_size + EXE_HEADER else "DATA"
        if count < 5:
            print(f"  {label} at file offset 0x{idx:X} (RAM 0x{ram:08X}) [{region}]")
        idx += 4
        count += 1
    if count == 0:
        print(f"  {label}: NOT FOUND")
    elif count > 5:
        print(f"  ... and {count - 5} more")

# Check the sequential sector table (EXE offset 0xA39AA-0xA3A02 per scan results)
print("\n=== SEQUENTIAL SECTOR TABLE (file offset 0xA39AA) ===")
table_off = 0xA39AA
if table_off + 80 < len(exe):
    for i in range(20):
        val = struct.unpack_from('<I', exe, table_off + i * 4)[0]
        ram = load_addr + table_off + i * 4 - EXE_HEADER
        marker = ""
        if val == 500:
            marker = " <<< HBD_LBA"
        elif val == 354:
            marker = " <<< DW7 HBD"
        elif val == 362:
            marker = " <<< DQ4 HBD"
        print(f"  [{i:2d}] file=0x{table_off + i*4:X} ram=0x{ram:08X}: {val}{marker}")

# Check what's at the file search string location
print("\n=== FILE SEARCH CONTEXT ===")
# The wrapper functions call 0x8003DDC4 which does a file search
# Let's check what the CD-ROM init code looks like
# Check for Setloc commands to sector 500
for i in range(EXE_HEADER, min(len(exe) - 4, EXE_HEADER + text_size), 4):
    word = struct.unpack_from('<I', exe, i)[0]
    # Look for lui $v0, 0x0000 + addiu $v0, $v0, 500 (li v0, 500)
    # Or lui + ori patterns that load 500
    # 500 = 0x1F4
    # addiu $v0, $zero, 500 = 0x240201F4
    if word == 0x240201F4:
        ram = load_addr + i - EXE_HEADER
        print(f"  li $v0, 500 at file=0x{i:X} ram=0x{ram:08X}")
    # addiu $v0, $zero, 354 = 0x24020162
    if word == 0x24020162:
        ram = load_addr + i - EXE_HEADER
        print(f"  li $v0, 354 at file=0x{i:X} ram=0x{ram:08X}")
    # lui $at, 0x0000; ori $at, $at, 500
    # ori $at, $at, 0x1F4 = 0x340401F4
    if word == 0x340401F4:
        ram = load_addr + i - EXE_HEADER
        print(f"  ori $at, $at, 500 at file=0x{i:X} ram=0x{ram:08X}")
