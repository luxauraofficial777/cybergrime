#!/usr/bin/env python3
"""Check the sequential sector table at 0xA39AA and search for LBA 354 as immediate."""
import struct

exe_path = r'..\translation\SLUSP012.06_disc_extract.bin'
with open(exe_path, 'rb') as f:
    data = f.read()

LOAD_ADDR = 0x80017F00

def f2r(off):
    return LOAD_ADDR + off - 0x800

def r2f(ram):
    return ram - LOAD_ADDR + 0x800

def disasm(insn):
    op = (insn >> 26) & 0x3F
    rs = (insn >> 21) & 0x1F
    rt = (insn >> 16) & 0x1F
    rd = (insn >> 11) & 0x1F
    shamt = (insn >> 6) & 0x1F
    funct = insn & 0x3F
    imm = insn & 0xFFFF
    simm = imm if imm < 0x8000 else imm - 0x10000
    target = insn & 0x3FFFFFF
    R = ['zero','at','v0','v1','a0','a1','a2','a3','t0','t1','t2','t3','t4','t5','t6','t7','s0','s1','s2','s3','s4','s5','s6','s7','t8','t9','k0','k1','gp','sp','fp','ra']
    if op==0:
        if funct==0x08: return f"jr ${R[rs]}"
        if funct==0x09: return f"jalr ${R[rd]},${R[rs]}"
        if funct==0x21: return f"addu ${R[rd]},${R[rs]},${R[rt]}"
        if funct==0x23: return f"subu ${R[rd]},${R[rs]},${R[rt]}"
        if funct==0x24: return f"and ${R[rd]},${R[rs]},${R[rt]}"
        if funct==0x25: return f"or ${R[rd]},${R[rs]},${R[rt]}"
        if funct==0x2A: return f"slt ${R[rd]},${R[rs]},${R[rt]}"
        if funct==0x00: return "nop" if insn==0 else f"sll ${R[rd]},${R[rt]},{shamt}"
        if funct==0x03: return f"sra ${R[rd]},${R[rt]},{shamt}"
        if funct==0x0C: return "syscall"
        if funct==0x2B: return f"sltu ${R[rd]},${R[rs]},${R[rt]}"
        if funct==0x04: return f"sllv ${R[rd]},${R[rt]},${R[rs]}"
        if funct==0x06: return f"srlv ${R[rd]},${R[rt]},${R[rs]}"
        if funct==0x07: return f"srav ${R[rd]},${R[rt]},${R[rs]}"
        if funct==0x26: return f"nor ${R[rd]},${R[rs]},${R[rt]}"
        if funct==0x22: return f"add ${R[rd]},${R[rs]},${R[rt]}"
        return f".word 0x{insn:08X}"
    if op==0x01:
        if rt==0: return f"bltz ${R[rs]},+{simm*4+4}"
        if rt==1: return f"bgez ${R[rs]},+{simm*4+4}"
        return f".word 0x{insn:08X}"
    if op==0x02: return f"j 0x{(target<<2):08X}"
    if op==0x03: return f"jal 0x{(target<<2):08X}"
    if op==0x04: return f"beq ${R[rs]},${R[rt]},+{simm*4+4}"
    if op==0x05: return f"bne ${R[rs]},${R[rt]},+{simm*4+4}"
    if op==0x06: return f"blez ${R[rs]},+{simm*4+4}"
    if op==0x07: return f"bgtz ${R[rs]},+{simm*4+4}"
    if op==0x08: return f"addi ${R[rt]},${R[rs]},{simm}"
    if op==0x09: return f"addiu ${R[rt]},${R[rs]},{simm}"
    if op==0x0A: return f"slti ${R[rt]},${R[rs]},{simm}"
    if op==0x0B: return f"sltiu ${R[rt]},${R[rs]},{simm}"
    if op==0x0C: return f"andi ${R[rt]},${R[rs]},0x{imm:04X}"
    if op==0x0D: return f"ori ${R[rt]},${R[rs]},0x{imm:04X}"
    if op==0x0E: return f"xori ${R[rt]},${R[rs]},0x{imm:04X}"
    if op==0x0F: return f"lui ${R[rt]},0x{imm:04X}"
    if op==0x20: return f"lb ${R[rt]},{simm}(${R[rs]})"
    if op==0x21: return f"lh ${R[rt]},{simm}(${R[rs]})"
    if op==0x23: return f"lw ${R[rt]},{simm}(${R[rs]})"
    if op==0x24: return f"lbu ${R[rt]},{simm}(${R[rs]})"
    if op==0x25: return f"lhu ${R[rt]},{simm}(${R[rs]})"
    if op==0x28: return f"sb ${R[rt]},{simm}(${R[rs]})"
    if op==0x29: return f"sh ${R[rt]},{simm}(${R[rs]})"
    if op==0x2B: return f"sw ${R[rt]},{simm}(${R[rs]})"
    return f".word 0x{insn:08X}"

# 1. Check sequential sector table at 0xA39AA
print('=== Sequential sector table at file offset 0xA39AA ===')
base = 0xA39AA
for i in range(-16, 80, 2):
    off = base + i
    if off + 2 <= len(data):
        val16 = struct.unpack('<H', data[off:off+2])[0]
        ram = f2r(off)
        if 300 <= val16 <= 400:
            print(f'  file 0x{off:X} (RAM 0x{ram:08X}): 0x{val16:04X} ({val16}) <-- LBA-like')
        elif i % 4 == 0:
            val32 = struct.unpack('<I', data[off:off+4])[0] if off + 4 <= len(data) else 0
            if 300 <= val32 <= 400:
                print(f'  file 0x{off:X} (RAM 0x{ram:08X}): 0x{val32:08X} ({val32}) <-- LBA 32-bit')

# 2. Dump as 32-bit words too
print('\n=== Same area as 32-bit words ===')
for i in range(0, 80, 4):
    off = base - 16 + i
    if off + 4 <= len(data):
        val = struct.unpack('<I', data[off:off+4])[0]
        ram = f2r(off)
        print(f'  0x{ram:08X}: 0x{val:08X} ({val})')

# 3. Search for addiu/ori with immediate 0x162 (354) or 0x162-ish
print('\n=== Instructions with immediate 0x162 (354) ===')
for i in range(0x800, len(data) - 4, 4):
    insn = struct.unpack('<I', data[i:i+4])[0]
    op = (insn >> 26) & 0x3F
    if op in (0x08, 0x09, 0x0A, 0x0B, 0x0C, 0x0D, 0x0E):  # addi/addiu/slti/sltiu/andi/ori/xori
        imm = insn & 0xFFFF
        if imm == 0x0162:
            ram = f2r(i)
            print(f'  0x{ram:08X}: 0x{insn:08X}  {disasm(insn)}')

# 4. Search for lui with 0x0162
print('\n=== lui with immediate 0x0162 ===')
for i in range(0x800, len(data) - 4, 4):
    insn = struct.unpack('<I', data[i:i+4])[0]
    if (insn >> 26) == 0x0F and (insn & 0xFFFF) == 0x0162:
        ram = f2r(i)
        print(f'  0x{ram:08X}: 0x{insn:08X}  {disasm(insn)}')

# 5. The table at 0x8001B800 might be accessed via a pointer in the .data section
# or via a register set up in a constructor/init function.
# Let's search for code that loads from addresses near 0x8001B800
# by looking for lui 0x8001 + ANY addiu/ori (not just 0xB800)
# and then checking if the resulting address is near the table
print('\n=== All lui 0x8001 + addiu/ori pairs ===')
pairs = []
for i in range(0x800, len(data) - 8, 4):
    insn = struct.unpack('<I', data[i:i+4])[0]
    if (insn >> 26) == 0x0F and (insn & 0xFFFF) == 0x8001:
        reg = (insn >> 16) & 0x1F
        for j in range(1, 8):
            if i + j*4 + 4 > len(data):
                break
            next_insn = struct.unpack('<I', data[i+j*4:i+j*4+4])[0]
            next_op = (next_insn >> 26) & 0x3F
            if next_op == 0x09:  # addiu same reg
                if ((next_insn >> 21) & 0x1F) == reg:
                    next_imm = next_insn & 0xFFFF
                    next_simm = next_imm if next_imm < 0x8000 else next_imm - 0x10000
                    addr = 0x80010000 + next_simm
                    if 0x8001A000 <= addr <= 0x8001F000:
                        ram = f2r(i)
                        pairs.append((ram, addr, reg))
                        print(f'  0x{ram:08X}: lui ${reg},0x8001 + addiu = 0x{addr:08X}')
                    break
            elif next_op == 0x0D:  # ori same reg
                if ((next_insn >> 21) & 0x1F) == reg:
                    next_imm = next_insn & 0xFFFF
                    addr = 0x80010000 | next_imm
                    if 0x8001A000 <= addr <= 0x8001F000:
                        ram = f2r(i)
                        pairs.append((ram, addr, reg))
                        print(f'  0x{ram:08X}: lui ${reg},0x8001 + ori = 0x{addr:08X}')
                    break

# 6. The table might be at a completely different address than we think.
# Let's search for the pointer values from the table (0x8012F3C0, 0x8012F5E4, etc.)
# as they might be referenced elsewhere
print('\n=== Search for pointer 0x8012F3C0 (first table entry) ===')
ptr_val = 0x8012F3C0
ptr_bytes = struct.pack('<I', ptr_val)
pos = 0x800
count = 0
while True:
    idx = data.find(ptr_bytes, pos)
    if idx == -1:
        break
    ram = f2r(idx)
    print(f'  0x{ptr_val:08X} at file 0x{idx:X} (RAM 0x{ram:08X})')
    count += 1
    pos = idx + 1
    if count > 10:
        break

# 7. Let's look at the EXE's entry point and trace forward to find HBD init
print('\n=== Entry point PC0 = 0x8008E284 ===')
start_off = r2f(0x8008E284)
for i in range(0, 60, 4):
    off = start_off + i
    if off + 4 <= len(data):
        insn = struct.unpack('<I', data[off:off+4])[0]
        ram = f2r(off)
        print(f'  0x{ram:08X}: 0x{insn:08X}  {disasm(insn)}')

# 8. Check if there's a file named "HBD1PS1D" in the DQ4 disc's ISO directory
print('\n=== DQ4 disc ISO directory ===')
dq4_path = r'..\Dragon Quest IV - Michibikareshi Mono Tachi (Japan).bin'
with open(dq4_path, 'rb') as f:
    # PVD is at sector 16, offset 24+2048 = sector 16 * 2352 + 24
    pvd_sector = 16
    f.seek(pvd_sector * 2352 + 24)
    pvd = f.read(2048)
    # PVD at offset 0
    if pvd[0] == 1 and pvd[1:6] == b'CD001':
        print(f'  PVD found at sector {pvd_sector}')
        # Root directory record at PVD offset 156 (0x9C)
        root_lba = struct.unpack('<I', pvd[158:162])[0]
        root_size = struct.unpack('<I', pvd[162:166])[0]
        print(f'  Root directory LBA: {root_lba}, size: {root_size}')
        # Read root directory
        f.seek(root_lba * 2352 + 24)
        root_dir = f.read(root_size)
        # Parse directory records
        pos = 0
        while pos < len(root_dir):
            if root_dir[pos] == 0:
                break
            rec_len = root_dir[pos]
            if pos + rec_len > len(root_dir):
                break
            lba = struct.unpack('<I', root_dir[pos+2:pos+6])[0]
            size = struct.unpack('<I', root_dir[pos+10:pos+14])[0]
            flags = root_dir[pos+25]
            name_len = root_dir[pos+32]
            name = root_dir[pos+33:pos+33+name_len]
            # Clean up name
            if b';' in name:
                name = name[:name.index(b';')]
            print(f'  {"[DIR]" if flags & 2 else "[FILE]"} LBA={lba} size={size} name="{name.decode("ascii", errors="replace")}"')
            pos += rec_len
    else:
        print('  PVD not found!')

# 9. Also check DW7 disc ISO directory
print('\n=== DW7 disc ISO directory ===')
dw7_path = r'..\DW7D1\DW7D1.bin'
with open(dw7_path, 'rb') as f:
    pvd_sector = 16
    f.seek(pvd_sector * 2352 + 24)
    pvd = f.read(2048)
    if pvd[0] == 1 and pvd[1:6] == b'CD001':
        print(f'  PVD found at sector {pvd_sector}')
        root_lba = struct.unpack('<I', pvd[158:162])[0]
        root_size = struct.unpack('<I', pvd[162:166])[0]
        print(f'  Root directory LBA: {root_lba}, size: {root_size}')
        f.seek(root_lba * 2352 + 24)
        root_dir = f.read(root_size)
        pos = 0
        while pos < len(root_dir):
            if root_dir[pos] == 0:
                break
            rec_len = root_dir[pos]
            if pos + rec_len > len(root_dir):
                break
            lba = struct.unpack('<I', root_dir[pos+2:pos+6])[0]
            size = struct.unpack('<I', root_dir[pos+10:pos+14])[0]
            flags = root_dir[pos+25]
            name_len = root_dir[pos+32]
            name = root_dir[pos+33:pos+33+name_len]
            if b';' in name:
                name = name[:name.index(b';')]
            print(f'  {"[DIR]" if flags & 2 else "[FILE]"} LBA={lba} size={size} name="{name.decode("ascii", errors="replace")}"')
            pos += rec_len

# 10. Check the Frankenstein build's ISO directory
print('\n=== Frankenstein build ISO directory ===')
frank_path = r'..\dq4_test_aug3.bin'
with open(frank_path, 'rb') as f:
    pvd_sector = 16
    f.seek(pvd_sector * 2352 + 24)
    pvd = f.read(2048)
    if pvd[0] == 1 and pvd[1:6] == b'CD001':
        print(f'  PVD found at sector {pvd_sector}')
        root_lba = struct.unpack('<I', pvd[158:162])[0]
        root_size = struct.unpack('<I', pvd[162:166])[0]
        print(f'  Root directory LBA: {root_lba}, size: {root_size}')
        f.seek(root_lba * 2352 + 24)
        root_dir = f.read(root_size)
        pos = 0
        while pos < len(root_dir):
            if root_dir[pos] == 0:
                break
            rec_len = root_dir[pos]
            if pos + rec_len > len(root_dir):
                break
            lba = struct.unpack('<I', root_dir[pos+2:pos+6])[0]
            size = struct.unpack('<I', root_dir[pos+10:pos+14])[0]
            flags = root_dir[pos+25]
            name_len = root_dir[pos+32]
            name = root_dir[pos+33:pos+33+name_len]
            if b';' in name:
                name = name[:name.index(b';')]
            print(f'  {"[DIR]" if flags & 2 else "[FILE]"} LBA={lba} size={size} name="{name.decode("ascii", errors="replace")}"')
            pos += rec_len

print('\n=== Done ===')
