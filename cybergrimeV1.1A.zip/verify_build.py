"""Verify v107 build using sector-aware EXE extraction (Appendix A)."""
import struct, sys

def extract_exe(bin_path, start_lba=24, nbytes=700000):
    out = bytearray()
    with open(bin_path, 'rb') as f:
        lba = start_lba
        while len(out) < nbytes:
            f.seek(lba * 2352 + 24)
            out += f.read(2048)
            lba += 1
    return bytes(out[:nbytes])

def read32(data, off):
    return struct.unpack_from('<I', data, off)[0]

def ram_to_off(ram):
    return ram - 0x80017F00 + 0x800

bin_path = sys.argv[1] if len(sys.argv) > 1 else r'c:\LuxAura\VoidWalkers_Project\DQLOSTTRANSLATION\build_staging\dq4_frankenstein_v107.bin'

print(f"Extracting EXE from {bin_path}...")
exe = extract_exe(bin_path)

# Check EXE magic
magic = exe[0:8]
print(f"EXE magic: {magic}")
assert magic == b'PS-X EXE', "Bad EXE magic!"

# PC0
pc0 = read32(exe, 0x10)
load_addr = read32(exe, 0x18)
text_size = read32(exe, 0x1C)
print(f"PC0: 0x{pc0:08X}, Load: 0x{load_addr:08X}, TextSize: 0x{text_size:08X} ({text_size} bytes)")

# Expected values from blueprint §1.1
checks = [
    # (name, RAM, expected, note)
    ("xa_stub_li",        0x8008B32C, 0x24020001, "li $v0,1"),
    ("xa_stub_lui_at",    0x8008B330, 0x3C01800E, "lui $at,0x800E"),
    ("xa_stub_sw_2038",   0x8008B334, 0xAC222038, "D1 FIX: sw $v0,0x2038($at)"),
    ("xa_stub_sw_3d94",   0x8008B338, 0xAC223D94, "sw $v0,0x3D94($at)"),
    ("xa_stub_jr",        0x8008B33C, 0x03E00008, "jr $ra"),
    ("xa_stub_nop",       0x8008B340, 0x00000000, "nop"),
    # Poll loops — should be ORIGINAL (not NOP) since hotfixes_empty.txt
    ("poll_1",            0x8004F4D8, 0x1040FFF7, "beq $v0,$zero (original)"),
    ("poll_2",            0x8004F510, 0x1040FFF7, "beq $v0,$zero (original)"),
    ("poll_3",            0x8004F5D0, 0x1040FFF5, "beq $v0,$zero (original)"),
    ("poll_4",            0x8004F5E0, 0x1040FFF1, "beq $v0,$zero (original)"),
    # Disc-check
    ("disc_check_1",      0x8007902C, 0x24020001, "li $v0,1"),
    ("disc_check_2",      0x800790D8, 0x24020001, "li $v0,1"),
    ("disc_check_3",      0x800792B8, 0x24020001, "li $v0,1"),
    # VBlank bypass
    ("vblank_jr_ra",      0x800965E8, 0x03E00008, "jr $ra"),
    ("vblank_move",       0x800965EC, 0x00001021, "move $v0,$zero"),
    ("vblank_nop",        0x800965F0, 0x00000000, "nop"),
    # BSS clear
    ("bss_start",         0x8008E288, 0x2442D700, "addiu $s2,$s2,0xD700"),
    ("bss_end_lui",       0x8008E28C, 0x3C03800E, "lui $v1,0x800E"),
    ("bss_end_addiu",     0x8008E290, 0x24639E80, "addiu $v1,$v1,0x9E80"),
    # HBD string
    ("hbd_string",        None,       None,       "check at file offset 0xF600"),
]

passes = 0
fails = 0
for name, ram, expected, note in checks:
    if ram is None:
        continue
    off = ram_to_off(ram)
    actual = read32(exe, off)
    status = "PASS" if actual == expected else "FAIL"
    if status == "PASS":
        passes += 1
    else:
        fails += 1
    print(f"  {status} {name:24s} RAM=0x{ram:08X} off=0x{off:06X} got=0x{actual:08X} want=0x{expected:08X} ({note})")

# HBD string check
hbd_str = exe[0xF600:0xF614]
print(f"  HBD string at 0xF600: {hbd_str}")
if b'hbd1ps1d.q41' in hbd_str:
    print(f"  PASS hbd_string")
    passes += 1
else:
    print(f"  FAIL hbd_string")
    fails += 1

print(f"\nVERIFY: {'PASS' if fails == 0 else 'FAIL'} ({passes}/{passes+fails})")
sys.exit(0 if fails == 0 else 1)
