#!/usr/bin/env python3
"""Disassemble DW7 EXE entry point only — focused output."""
import struct

exe_path = r'C:\LuxAura\VoidWalkers_Project\DQLOSTTRANSLATION\translation\SLUSP012.06_clean.bin'
LOAD_ADDR = 0x80017F00

with open(exe_path, 'rb') as f:
    exe = f.read()

def rd32(off):
    return struct.unpack_from('<I', exe, off)[0]

def ram_to_off(ram):
    return ram - LOAD_ADDR + 0x800

def decode(word, addr):
    op = (word >> 26) & 0x3F
    rs = (word >> 21) & 0x1F
    rt = (word >> 16) & 0x1F
    imm = word & 0xFFFF
    target = word & 0x3FFFFFF
    rd = (word >> 11) & 0x1F
    funct = word & 0x3F
    shamt = (word >> 6) & 0x1F
    regs = ['zero','at','v0','v1','a0','a1','a2','a3',
            't0','t1','t2','t3','t4','t5','t6','t7',
            's0','s1','s2','s3','s4','s5','s6','s7',
            't8','t9','k0','k1','gp','sp','fp','ra']
    simm = struct.unpack('h', struct.pack('H', imm))[0]
    
    if word == 0: return 'nop'
    if op == 0:
        if funct == 0x08: return f'jr {regs[rs]}'
        if funct == 0x09: return f'jalr {regs[rd]}, {regs[rs]}'
        if funct == 0x21: return f'addu {regs[rd]}, {regs[rs]}, {regs[rt]}'
        if funct == 0x23: return f'subu {regs[rd]}, {regs[rs]}, {regs[rt]}'
        if funct == 0x24: return f'and {regs[rd]}, {regs[rs]}, {regs[rt]}'
        if funct == 0x25: return f'or {regs[rd]}, {regs[rs]}, {regs[rt]}'
        if funct == 0x2A: return f'slt {regs[rd]}, {regs[rs]}, {regs[rt]}'
        if funct == 0x2B: return f'sltu {regs[rd]}, {regs[rs]}, {regs[rt]}'
        if funct == 0x00: return f'sll {regs[rd]}, {regs[rt]}, {shamt}'
        if funct == 0x03: return f'sra {regs[rd]}, {regs[rt]}, {shamt}'
        if funct == 0x02: return f'srl {regs[rd]}, {regs[rt]}, {shamt}'
        if funct == 0x04: return f'sllv {regs[rd]}, {regs[rt]}, {regs[rs]}'
        if funct == 0x06: return f'srlv {regs[rd]}, {regs[rt]}, {regs[rs]}'
        if funct == 0x07: return f'srav {regs[rd]}, {regs[rt]}, {regs[rs]}'
        if funct == 0x10: return f'mfhi {regs[rd]}'
        if funct == 0x12: return f'mflo {regs[rd]}'
        if funct == 0x18: return f'mult {regs[rs]}, {regs[rt]}'
        if funct == 0x19: return f'multu {regs[rs]}, {regs[rt]}'
        if funct == 0x1A: return f'div {regs[rs]}, {regs[rt]}'
        if funct == 0x1B: return f'divu {regs[rs]}, {regs[rt]}'
        if funct == 0x0C: return f'syscall'
        if funct == 0x0D: return f'break'
        return f'.word 0x{word:08X}'
    if op == 0x01:
        if rt == 0: return f'bltz {regs[rs]}, 0x{addr + 4 + (simm << 2):08X}'
        if rt == 1: return f'bgez {regs[rs]}, 0x{addr + 4 + (simm << 2):08X}'
        return f'regimm rt={rt} {regs[rs]}, 0x{addr + 4 + (simm << 2):08X}'
    if op == 0x02: return f'j 0x{(addr & 0xF0000000) | (target << 2):08X}'
    if op == 0x03: return f'jal 0x{(addr & 0xF0000000) | (target << 2):08X}'
    if op == 0x04: return f'beq {regs[rs]}, {regs[rt]}, 0x{addr + 4 + (simm << 2):08X}'
    if op == 0x05: return f'bne {regs[rs]}, {regs[rt]}, 0x{addr + 4 + (simm << 2):08X}'
    if op == 0x06: return f'blez {regs[rs]}, 0x{addr + 4 + (simm << 2):08X}'
    if op == 0x07: return f'bgtz {regs[rs]}, 0x{addr + 4 + (simm << 2):08X}'
    if op == 0x08: return f'addi {regs[rt]}, {regs[rs]}, {simm}'
    if op == 0x09: return f'addiu {regs[rt]}, {regs[rs]}, {simm}'
    if op == 0x0A: return f'slti {regs[rt]}, {regs[rs]}, {simm}'
    if op == 0x0B: return f'sltiu {regs[rt]}, {regs[rs]}, {simm}'
    if op == 0x0C: return f'andi {regs[rt]}, {regs[rs]}, 0x{imm:04X}'
    if op == 0x0D: return f'ori {regs[rt]}, {regs[rs]}, 0x{imm:04X}'
    if op == 0x0E: return f'xori {regs[rt]}, {regs[rs]}, 0x{imm:04X}'
    if op == 0x0F: return f'lui {regs[rt]}, 0x{imm:04X}'
    if op == 0x20: return f'lb {regs[rt]}, {simm}({regs[rs]})'
    if op == 0x21: return f'lh {regs[rt]}, {simm}({regs[rs]})'
    if op == 0x23: return f'lw {regs[rt]}, {simm}({regs[rs]})'
    if op == 0x24: return f'lbu {regs[rt]}, {simm}({regs[rs]})'
    if op == 0x25: return f'lhu {regs[rt]}, {simm}({regs[rs]})'
    if op == 0x28: return f'sb {regs[rt]}, {simm}({regs[rs]})'
    if op == 0x29: return f'sh {regs[rt]}, {simm}({regs[rs]})'
    if op == 0x2B: return f'sw {regs[rt]}, {simm}({regs[rs]})'
    if op == 0x10: return f'mfc0 {regs[rt]}, {rd}'
    return f'.word 0x{word:08X} (op={op:02X})'

# Entry point
pc0 = rd32(0x10)
entry_off = ram_to_off(pc0)
print(f"PC0 = 0x{pc0:08X} (file offset 0x{entry_off:X})")
print(f"EXE size: {len(exe)} bytes")
print(f"Text size: 0x{rd32(0x1C):X}")

# Disassemble entry point — first 60 instructions
print(f"\n=== Entry Point (RAM 0x{pc0:08X}) ===")
for i in range(60):
    off = entry_off + i * 4
    if off + 4 > len(exe): break
    word = rd32(off)
    ram = LOAD_ADDR + off - 0x800
    print(f"  0x{ram:08X}: 0x{word:08X}  {decode(word, ram)}")

# Check what's at the thread entry area (BSS region)
print(f"\n=== Thread Entry Area (RAM 0x800D9E80) ===")
thread_off = ram_to_off(0x800D9E80)
print(f"  File offset: 0x{thread_off:X}")
if thread_off < len(exe):
    for i in range(10):
        off = thread_off + i * 4
        if off + 4 > len(exe): break
        word = rd32(off)
        ram = LOAD_ADDR + off - 0x800
        print(f"  0x{ram:08X}: 0x{word:08X}  {decode(word, ram)}")
else:
    print(f"  BEYOND EXE TEXT (offset 0x{thread_off:X} > exe size {len(exe)})")
    print(f"  This is BSS — code must be copied here at runtime or was in original DW7 disc")

# Check the BSS clear instructions
print(f"\n=== BSS Clear (file offset 0x76B84) ===")
for i in range(12):
    off = 0x76B84 + i * 4
    if off + 4 > len(exe): break
    word = rd32(off)
    ram = LOAD_ADDR + off - 0x800
    print(f"  0x{ram:08X}: 0x{word:08X}  {decode(word, ram)}")

# Check what the game does right after BSS clear
# BSS clear is at 0x8008E284, ~6 instructions, then falls through
print(f"\n=== Post-BSS-Clear (RAM 0x8008E2B4) ===")
post_off = ram_to_off(0x8008E2B4)
for i in range(30):
    off = post_off + i * 4
    if off + 4 > len(exe): break
    word = rd32(off)
    ram = LOAD_ADDR + off - 0x800
    print(f"  0x{ram:08X}: 0x{word:08X}  {decode(word, ram)}")
