#!/usr/bin/env python3
"""Static English probe gate — verifies English translation is present on disc.

Phase B acceptance test per PIPELINE_AUDIT_PHASES_TO_COMPLETION_Aug4_2026.md §9.1.
Scans for 6 encoded English probe sequences in the disc's HBD region.

Usage:
    python verify_english_on_disc.py <disc.bin> [hbd_sector] [hbd_sectors]
    Default: hbd_sector=500, hbd_sectors=155975 (Phase A layout)
"""
import sys
import os

probes = {
    'Clovis':    '39cfd3c9dc020000',
    'BnmtPrsn':  '7015c5d891ab0500',
    'Schnk':     '8c77d3ae05000000',
    'Zolak':     '397cced5b5000000',
    'Kptcha':    'af2471b7cb020000',
    'Galan':     '70ae73a905000000',
}
probes = {k: bytes.fromhex(v) for k, v in probes.items()}

def scan(path, lba=None, sectors=None, label=None):
    with open(path, 'rb') as f:
        if lba is not None:
            f.seek(lba * 2352)
            data = f.read(sectors * 2352)
        else:
            data = f.read()
    hits = []
    for k, b in probes.items():
        pos = data.find(b)
        if pos >= 0:
            hits.append((k, pos))
    name = label or os.path.basename(path)
    if hits:
        print(f"  {name}: ENGLISH_PROBES: {len(hits)}/6 FOUND")
        for k, pos in hits:
            print(f"    {k}: found at offset {pos} (0x{pos:X})")
    else:
        print(f"  {name}: ENGLISH_PROBES: *** NONE ***")
    return len(hits)

def main():
    if len(sys.argv) < 2:
        print("Usage: python verify_english_on_disc.py <disc.bin> [hbd_sector] [hbd_sectors]")
        sys.exit(1)
    
    disc_path = sys.argv[1]
    hbd_sector = int(sys.argv[2]) if len(sys.argv) > 2 else 500
    hbd_sectors = int(sys.argv[3]) if len(sys.argv) > 3 else 155975
    
    print("=== Phase B: Static English Probe Gate ===")
    print(f"  Disc: {disc_path}")
    print(f"  HBD region: sector {hbd_sector}, {hbd_sectors} sectors")
    print()
    
    # Positive control: translation_map.bin
    tm_path = os.path.join(os.path.dirname(disc_path), '..', 'cybergrime', 'translation_map.bin')
    if not os.path.exists(tm_path):
        tm_path = os.path.join(os.path.dirname(os.path.abspath(disc_path)), 'cybergrime', 'translation_map.bin')
    if os.path.exists(tm_path):
        print("  Positive control (translation_map.bin):")
        tm_hits = scan(tm_path)
        print()
    else:
        print(f"  WARNING: translation_map.bin not found at {tm_path}")
        tm_hits = 0
        print()
    
    # Scan disc HBD region
    print(f"  Disc HBD region (sector {hbd_sector}):")
    disc_hits = scan(disc_path, hbd_sector, hbd_sectors, label=f"{os.path.basename(disc_path)} [HBD@{hbd_sector}]")
    print()
    
    # Full disc scan (catch-all)
    print(f"  Full disc scan:")
    full_hits = scan(disc_path, label=f"{os.path.basename(disc_path)} [full]")
    print()
    
    # Verdict
    if disc_hits >= 6:
        print(f"  GATE: PASS — {disc_hits}/6 English probes found in HBD region")
        return 0
    elif full_hits >= 6:
        print(f"  GATE: PASS (full scan) — {full_hits}/6 English probes found in disc (outside expected HBD region)")
        return 0
    else:
        print(f"  GATE: FAIL — only {disc_hits}/6 in HBD, {full_hits}/6 in full disc")
        print(f"  English translation is NOT present on this disc.")
        return 1

if __name__ == '__main__':
    sys.exit(main())
