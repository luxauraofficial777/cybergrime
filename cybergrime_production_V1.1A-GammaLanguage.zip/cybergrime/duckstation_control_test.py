#!/usr/bin/env python3
"""DuckStation Control Test Harness

Launches DuckStation with a given CUE file, waits for a configurable duration,
captures results (log file, screenshot if possible), and outputs structured JSON.

Usage:
    python duckstation_control_test.py --cue "path/to/game.cue" --name test_name --duration 120
    python duckstation_control_test.py --batch control_matrix.json
"""
import argparse
import json
import os
import subprocess
import sys
import time
import hashlib
from pathlib import Path
from datetime import datetime

DUCKSTATION_EXE = r"C:\LuxAura\VoidWalkers_Project\DQLOSTTRANSLATION\duckstation\duckstation-qt-x64-ReleaseLTCG.exe"
DUCKSTATION_DIR = r"C:\LuxAura\VoidWalkers_Project\DQLOSTTRANSLATION\duckstation"
LOG_DIR = r"C:\LuxAura\VoidWalkers_Project\DQLOSTTRANSLATION\tools\frankenstein_qa\logs"
RESULTS_DIR = r"C:\LuxAura\VoidWalkers_Project\DQLOSTTRANSLATION\tools\frankenstein_qa\results"


def ensure_dirs():
    os.makedirs(LOG_DIR, exist_ok=True)
    os.makedirs(RESULTS_DIR, exist_ok=True)


def run_test(cue_path: str, test_name: str, duration: int = 120) -> dict:
    """Run a single DuckStation test.

    Args:
        cue_path: Absolute path to the .cue file.
        test_name: Short name for the test (used in log filenames).
        duration: Seconds to let DuckStation run before killing.

    Returns:
        Dict with test results.
    """
    ensure_dirs()
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    log_file = os.path.join(LOG_DIR, f"{test_name}_{timestamp}.log")
    result_file = os.path.join(RESULTS_DIR, f"{test_name}_{timestamp}.json")

    result = {
        "test_name": test_name,
        "cue_path": cue_path,
        "timestamp": timestamp,
        "duration_seconds": duration,
        "duckstation_exe": DUCKSTATION_EXE,
        "log_file": log_file,
        "cue_exists": os.path.exists(cue_path),
        "bin_exists": False,
        "bin_path": None,
        "process_started": False,
        "process_killed": False,
        "exit_code": None,
        "log_size": 0,
        "gpu_commands": 0,
        "fps_mentions": 0,
        "error_lines": [],
        "cdrom_lines": [],
        "bios_lines": [],
        "first_gpu_command": None,
        "first_frame_presented": None,
        "verdict": "UNKNOWN",
    }

    # Parse CUE to find BIN
    if result["cue_exists"]:
        with open(cue_path, 'r') as f:
            for line in f:
                line = line.strip()
                if line.startswith('FILE'):
                    parts = line.split('"')
                    if len(parts) >= 2:
                        bin_name = parts[1]
                        bin_path = os.path.join(os.path.dirname(cue_path), bin_name)
                        result["bin_path"] = bin_path
                        result["bin_exists"] = os.path.exists(bin_path)
                    break

    if not result["cue_exists"] or not result["bin_exists"]:
        result["verdict"] = "FAIL_MISSING_FILES"
        with open(result_file, 'w') as f:
            json.dump(result, f, indent=2)
        return result

    # Launch DuckStation
    print(f"[TEST] Launching {test_name}: {cue_path}")
    print(f"[TEST] BIN: {result['bin_path']} ({os.path.getsize(result['bin_path'])} bytes)")

    try:
        proc = subprocess.Popen(
            [DUCKSTATION_EXE, "-batch", "-earlyconsole", cue_path],
            cwd=DUCKSTATION_DIR,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            creationflags=subprocess.CREATE_NEW_PROCESS_GROUP,
        )
        result["process_started"] = True
        result["pid"] = proc.pid
        print(f"[TEST] PID={proc.pid}, waiting {duration}s...")
    except Exception as e:
        result["verdict"] = f"FAIL_LAUNCH: {e}"
        with open(result_file, 'w') as f:
            json.dump(result, f, indent=2)
        return result

    # Wait for duration
    time.sleep(duration)

    # Kill the process
    try:
        proc.terminate()
        time.sleep(2)
        if proc.poll() is None:
            proc.kill()
            result["process_killed"] = True
        result["exit_code"] = proc.returncode
    except Exception as e:
        result["verdict"] = f"FAIL_KILL: {e}"
        with open(result_file, 'w') as f:
            json.dump(result, f, indent=2)
        return result

    # Capture stdout output as log
    try:
        stdout_data = proc.stdout.read().decode('utf-8', errors='replace') if proc.stdout else ""
        with open(log_file, 'w', encoding='utf-8') as f:
            f.write(stdout_data)
        result["log_size"] = os.path.getsize(log_file)
    except Exception:
        stdout_data = ""
        result["log_size"] = 0

    # Also check the configured DuckStation log file (LogPath in settings)
    ds_log_path = os.path.join(LOG_DIR, "duckstation.log")
    if os.path.exists(ds_log_path):
        try:
            with open(ds_log_path, 'r', encoding='utf-8', errors='replace') as f:
                ds_log = f.read()
            # Append DuckStation's own log
            with open(log_file, 'a', encoding='utf-8') as f:
                f.write("\n\n=== DuckStation Log File ===\n\n")
                f.write(ds_log)
            result["log_size"] = os.path.getsize(log_file)
            # Also check for duckstation.log in settings dir
        except Exception:
            pass
    
    # Check settings dir for log too
    ds_log_alt = os.path.join(DUCKSTATION_DIR, "settings", "duckstation.log")
    if os.path.exists(ds_log_alt) and os.path.getsize(ds_log_alt) > 0:
        try:
            with open(ds_log_alt, 'r', encoding='utf-8', errors='replace') as f:
                ds_log = f.read()
            with open(log_file, 'a', encoding='utf-8') as f:
                f.write("\n\n=== DuckStation Settings Log ===\n\n")
                f.write(ds_log)
            result["log_size"] = os.path.getsize(log_file)
        except Exception:
            pass

    # Parse log for indicators
    log_text = stdout_data
    if os.path.exists(log_file):
        with open(log_file, 'r', encoding='utf-8', errors='replace') as f:
            log_text = f.read()

    lines = log_text.split('\n')
    for i, line in enumerate(lines):
        line_lower = line.lower()

        if 'gpu' in line_lower and ('command' in line_lower or 'draw' in line_lower or 'render' in line_lower):
            result["gpu_commands"] += 1
            if result["first_gpu_command"] is None:
                result["first_gpu_command"] = f"line {i}: {line.strip()[:200]}"

        if 'fps' in line_lower or ('frame' in line_lower and 'present' in line_lower) or 'PerfMon' in line:
            result["fps_mentions"] += 1
            if result["first_frame_presented"] is None and ('present' in line_lower or 'PerfMon' in line):
                result["first_frame_presented"] = f"line {i}: {line.strip()[:200]}"

        if 'error' in line_lower or 'fatal' in line_lower or 'crash' in line_lower:
            result["error_lines"].append(f"line {i}: {line.strip()[:200]}")

        if 'cdrom' in line_lower or 'cd-rom' in line_lower or 'sector' in line_lower:
            result["cdrom_lines"].append(f"line {i}: {line.strip()[:200]}")

        if 'bios' in line_lower:
            result["bios_lines"].append(f"line {i}: {line.strip()[:200]}")

    # Truncate lists
    result["error_lines"] = result["error_lines"][:20]
    result["cdrom_lines"] = result["cdrom_lines"][:20]
    result["bios_lines"] = result["bios_lines"][:10]

    # Determine verdict
    if result["gpu_commands"] > 0:
        result["verdict"] = "PASS_GPU_ACTIVITY"
    elif result["fps_mentions"] > 5:
        result["verdict"] = "PASS_FRAMES_PRESENTED"
    elif any("FPS:" in line for line in result.get("error_lines", []) + lines[:500]):
        result["verdict"] = "PASS_FPS_DETECTED"
    elif result["error_lines"]:
        result["verdict"] = "FAIL_ERRORS"
    elif result["cdrom_lines"]:
        result["verdict"] = "PARTIAL_CDROM_ONLY"
    else:
        result["verdict"] = "FAIL_NO_OUTPUT"

    # Save result
    with open(result_file, 'w') as f:
        json.dump(result, f, indent=2)

    print(f"[TEST] Verdict: {result['verdict']}")
    print(f"[TEST] GPU commands: {result['gpu_commands']}, FPS mentions: {result['fps_mentions']}")
    print(f"[TEST] Log: {log_file} ({result['log_size']} bytes)")
    print(f"[TEST] Result: {result_file}")

    return result


def run_batch(batch_path: str):
    """Run a batch of tests from a JSON config file."""
    with open(batch_path, 'r') as f:
        config = json.load(f)

    results = []
    for test in config.get("tests", []):
        result = run_test(
            cue_path=test["cue"],
            test_name=test["name"],
            duration=test.get("duration", 120),
        )
        results.append(result)
        print()

    # Summary
    print("=" * 60)
    print("  BATCH SUMMARY")
    print("=" * 60)
    for r in results:
        status_emoji = "PASS" if "PASS" in r["verdict"] else "FAIL" if "FAIL" in r["verdict"] else "PARTIAL"
        print(f"  {r['test_name']:30s} {status_emoji:8s} {r['verdict']}")
    print("=" * 60)

    # Save batch summary
    summary_file = os.path.join(RESULTS_DIR, f"batch_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json")
    with open(summary_file, 'w') as f:
        json.dump(results, f, indent=2)
    print(f"\nBatch summary: {summary_file}")

    return results


def main():
    parser = argparse.ArgumentParser(description="DuckStation Control Test Harness")
    parser.add_argument("--cue", help="Path to .cue file for single test")
    parser.add_argument("--name", help="Test name (for single test)", default="single_test")
    parser.add_argument("--duration", type=int, default=120, help="Duration in seconds (default 120)")
    parser.add_argument("--batch", help="Path to batch JSON config file")
    args = parser.parse_args()

    if args.batch:
        run_batch(args.batch)
    elif args.cue:
        run_test(args.cue, args.name, args.duration)
    else:
        # Default: run control matrix
        control_matrix = {
            "tests": [
                {
                    "name": "control_a_dq4_jp",
                    "cue": r"C:\LuxAura\VoidWalkers_Project\DQLOSTTRANSLATION\Dragon Quest IV - Michibikareshi Mono Tachi (Japan).cue",
                    "duration": 90
                },
                {
                    "name": "control_b_dw7_us",
                    "cue": r"C:\LuxAura\VoidWalkers_Project\DQLOSTTRANSLATION\DW7D1\DW7D1.cue",
                    "duration": 90
                },
                {
                    "name": "test_1_frank_v16",
                    "cue": r"C:\LuxAura\VoidWalkers_Project\DQLOSTTRANSLATION\dq4_frankenstein_v16.cue",
                    "duration": 120
                },
                {
                    "name": "test_2_rc2",
                    "cue": r"C:\LuxAura\VoidWalkers_Project\DQLOSTTRANSLATION\_archive\dq4_en_rc2.cue",
                    "duration": 90
                }
            ]
        }
        batch_path = os.path.join(RESULTS_DIR, "control_matrix.json")
        ensure_dirs()
        with open(batch_path, 'w') as f:
            json.dump(control_matrix, f, indent=2)
        print(f"Control matrix written to {batch_path}")
        print("Run with: python duckstation_control_test.py --batch \"" + batch_path + '"')
        print("\nOr run individual tests:")
        print('  python duckstation_control_test.py --cue "path/to/game.cue" --name test_name --duration 120')


if __name__ == "__main__":
    main()
