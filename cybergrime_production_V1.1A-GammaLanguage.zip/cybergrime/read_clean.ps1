$j = Get-Content telemetry_clean_50m.json -Raw | ConvertFrom-Json
Write-Host "=== CLEAN 50M Run State ==="
Write-Host "Status: $($j.Pass_Status)"
Write-Host "Instructions: $($j.Instructions_Executed)"
Write-Host "VBlanks: $($j.VBlank_Count)"
Write-Host "Crashed: $($j.Crashed)"
Write-Host "PC: $($j.Register_Dump.PC)"
Write-Host "GP: $($j.Register_Dump.gp)"
Write-Host ""

# Search TTY for BIOS calls and GPU references
$tty = $j.TTY_Tail
# Extract all BIOS call lines
$biosLines = [regex]::Matches($tty, 'BIOS [ABC]:0x[0-9A-Fa-f]+') | ForEach-Object { $_.Value }
Write-Host "BIOS calls in TTY tail ($($biosLines.Count) total):"
$biosLines | Select-Object -First 20 | ForEach-Object { Write-Host "  $_" }
Write-Host ""

# Search for GPU_cw or GPU-related calls
$gpuLines = $tty -split "`n" | Where-Object { $_ -match 'GPU|gpu_cw|0x800A5D|mem2vram|VRAM|font|render' }
Write-Host "GPU/render references in TTY tail ($($gpuLines.Count) total):"
$gpuLines | Select-Object -First 10 | ForEach-Object { Write-Host "  $_" }
Write-Host ""

# Check the full TTY for PUPPETEER graft messages
$puppetLines = $tty -split "`n" | Where-Object { $_ -match 'PUPPETEER' }
Write-Host "PUPPETEER graft messages ($($puppetLines.Count) total):"
$puppetLines | Select-Object -First 10 | ForEach-Object { Write-Host "  $_" }
