#!/usr/bin/env python3
"""Disassemble the WaitEvent caller at 0x80093AB8."""
import os
from capstone import Cs, CS_ARCH_MIPS, CS_MODE_MIPS32, CS_MODE_LITTLE_ENDIAN

def read_exe_from_disc(disc_path, exe_lba=24, sector_size=2352, user_offset=24, user_size=2048):
    with open(disc_path, 'rb') as f:
        exe_sectors = 340
        f.seek(exe_lba * sector_size)
        raw = f.read(exe_sectors * sector_size)
    exe_data = bytearray()
    for i in range(exe_sectors):
        sector = raw[i * sector_size:(i + 1) * sector_size]
        if len(sector) < user_offset + user_size:
            break
        exe_data += sector[user_offset:user_offset + user_size]
    return bytes(exe_data)

def disasm_range(exe_data, load_addr, start_ram, end_ram):
    code_offset = 0x800
    file_start = start_ram - load_addr + code_offset
    file_end = end_ram - load_addr + code_offset
    if file_start < 0 or file_end > len(exe_data):
        return "  (outside EXE)\n"
    code = exe_data[file_start:file_end]
    md = Cs(CS_ARCH_MIPS, CS_MODE_MIPS32 | CS_MODE_LITTLE_ENDIAN)
    lines = []
    for insn in md.disasm(code, start_ram):
        lines.append(f"  0x{insn.address:08X}: {insn.mnemonic:8s} {insn.op_str}")
    return '\n'.join(lines) + '\n'

base = r"C:\LuxAura\VoidWalkers_Project\DQLOSTTRANSLATION"
disc = os.path.join(base, "dq4_frankenstein_v41.bin")
load_addr = 0x80017F00
exe = read_exe_from_disc(disc)

# WaitEvent caller at ra=0x80093AC0, so jal is at 0x80093AB8
# Disassemble a wide area around this
print("=== WaitEvent CALLER (0x80093A60-0x80093B40) ===")
print(disasm_range(exe, load_addr, 0x80093A60, 0x80093B40))

# Also check the function entry — find the prologue
print("\n=== FUNCTION ENTRY (0x80093A00-0x80093A70) ===")
print(disasm_range(exe, load_addr, 0x80093A00, 0x80093A70))

# And what happens after WaitEvent returns
print("\n=== AFTER WaitEvent (0x80093AC0-0x80093B20) ===")
print(disasm_range(exe, load_addr, 0x80093AC0, 0x80093B20))
