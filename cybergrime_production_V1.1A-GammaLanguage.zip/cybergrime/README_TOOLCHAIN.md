# PSX Agent Toolchain — Quick Reference

## Build

```powershell
# Clean rebuild of psx_agent_runner.exe
cd cybergrime
.\build_agent.bat clean
```

## Run a Test

```powershell
# Standardized test runner with telemetry + triage capture
cd cybergrime
.\run_test.ps1 -Disc dq4_frankenstein_v14.bin -Profile frank_v14 -MaxInstrs 50000000
```

## Inspect Telemetry

```powershell
# Summary table of all runs
python cybergrime\telemetry_summary.py --dir cybergrime\telemetry --sort time

# Fail CI-style if any run did not pass
python cybergrime\telemetry_summary.py --fail-if-not-pass
```

## MIPS Assembly

```powershell
# Assemble/disassemble from Python
$env:PYTHONPATH="C:\LuxAura\VoidWalkers_Project\DQLOSTTRANSLATION\cybergrime"
python -c "
from mips import assemble, disassemble
words, labels = assemble('lui \$t0, 0x800B; ori \$t1, \$zero, 1')
print([hex(w) for w in words])
"
```

## EXE Patching

```powershell
# List code caves
python cybergrime\exe_patch.py --iso _archive\dq4_frankenstein_v14.bin --lba 24 --caves

# Disassemble at a crash PC
python cybergrime\exe_patch.py --iso _archive\dq4_frankenstein_v14.bin --lba 24 --disasm 0x8004BD70 --count 8

# Inject a MIPS stub from a file and hook an address (writes ISO!)
python cybergrime\exe_patch.py --iso _archive\dq4_frankenstein_v14.bin --lba 24 --hook 0x8004BD70 --asm example_stub.asm --out patched_frank.bin
```

## Runtime Injection

```powershell
# Convert assembly to a harness injection JSON
python cybergrime\asm_to_inject.py example_stub.asm --addr 0x800D9E80 --cond immediate --out inject.json

# Run with the injection
psx_agent_runner.exe _archive\dq4_frankenstein_v14.bin frank 50000000 telemetry.json 0 --inject inject.json
```

## Interactive Console

```powershell
# Enable stdin console (commands: b/reak, m/em, r/egs, pc, w/rite, p/ause, c/ontinue, s/tep, q/uit)
psx_agent_runner.exe _archive\dq4_frankenstein_v14.bin frank 50000000 telemetry.json 0 --console
```

Example session:
```
> b 0x8004BD70
> c
[CONSOLE] Breakpoint hit at 0x8004BD70 (instr #4523694)
> r
> m 0x8004BD70 32
> q
```

## Symbol Table

```python
from psx.symbols import SymbolTable
sym = SymbolTable("cybergrime/psx/symbols.json")
print(hex(sym["CD_INIT_DONE"]))  # 0x800b91cc
```

## After Modifying a Raw 2352-byte ISO

The `exe_patch.py` tool does **not** regenerate EDC/ECC. Run `edcre.exe` on the output image before testing in real hardware or other emulators.

```powershell
edcre.exe patched_frank.bin
```
