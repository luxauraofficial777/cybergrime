@echo off
REM psx_ops_build.bat — Build psx_ops.dll from C++ source
REM Primary: g++ (MinGW from Strawberry Perl: C:\Strawberry\c\bin)
REM Fallback: MSVC cl.exe (Developer Command Prompt)
REM -static eliminates runtime dependency on libgcc_s_seh-1.dll / libstdc++-6.dll

setlocal
set SRC_DIR=%~dp0
set SRC=%SRC_DIR%psx_binary_ops.cpp
set OUT=%SRC_DIR%psx_ops.dll

where g++ >nul 2>nul
if %ERRORLEVEL% equ 0 (
    echo Building psx_ops.dll with g++ (static)...
    g++ -O2 -shared -static -std=c++17 -o "%OUT%" "%SRC%" -Wl,--out-implib,psx_ops.lib
    goto :check_result
)

where cl >nul 2>nul
if %ERRORLEVEL% equ 0 (
    echo Building psx_ops.dll with cl (MSVC)...
    cl /O2 /LD /EHsc /std:c++17 /W3 /D_CRT_SECURE_NO_WARNINGS "%SRC%" /Fe:"%OUT%" /link /NODEFAULTLIB:LIBCMT
    goto :check_result
)

echo ERROR: Neither g++ nor cl found in PATH.
echo For g++: Add C:\Strawberry\c\bin to PATH
echo For cl:  Run from Developer Command Prompt for Visual Studio
exit /b 2

:check_result
if %ERRORLEVEL% neq 0 (
    echo BUILD FAILED with error %ERRORLEVEL%
    exit /b 1
)

echo Build succeeded: %OUT%
echo Running round-trip tests...
python "%SRC_DIR%test_psx_ops.py"
endlocal
