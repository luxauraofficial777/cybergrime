import struct, sys

with open(r'..\dq4_frankenstein_v100.bin', 'rb') as f:
    exe_lba = 24; sector_size = 2352; user_offset = 24; user_size = 2048; exe_sectors = 340
    f.seek(exe_lba * sector_size)
    raw = f.read(exe_sectors * sector_size)

exe_data = bytearray()
for i in range(exe_sectors):
    sector = raw[i * sector_size:(i + 1) * sector_size]
    exe_data += sector[user_offset:user_offset + user_size]

load_addr = struct.unpack_from('<I', exe_data, 0x10)[0]
print(f"Load addr: 0x{load_addr:08X}")

start = int(sys.argv[1], 16) if len(sys.argv) > 1 else 0x800966A0
end = int(sys.argv[2], 16) if len(sys.argv) > 2 else 0x80096708

for target in range(start, end, 4):
    off = target - load_addr + 0x800
    if 0 <= off and off + 4 <= len(exe_data):
        word = struct.unpack_from('<I', exe_data, off)[0]
        # Simple MIPS disassembler
        op = (word >> 26) & 0x3F
        rs = (word >> 21) & 0x1F
        rt = (word >> 16) & 0x1F
        rd = (word >> 11) & 0x1F
        shamt = (word >> 6) & 0x1F
        funct = word & 0x3F
        imm = word & 0xFFFF
        simm = imm if imm < 0x8000 else imm - 0x10000
        target_addr = (target + 4 + (simm << 2)) & 0xFFFFFFFF
        
        regs = ['zero','at','v0','v1','a0','a1','a2','a3','t0','t1','t2','t3','t4','t5','t6','t7',
                's0','s1','s2','s3','s4','s5','s6','s7','t8','t9','k0','k1','gp','sp','fp','ra']
        
        desc = ''
        if op == 0:  # SPECIAL
            if funct == 0x20: desc = f'add {regs[rd]},{regs[rs]},{regs[rt]}'
            elif funct == 0x21: desc = f'addu {regs[rd]},{regs[rs]},{regs[rt]}'
            elif funct == 0x22: desc = f'sub {regs[rd]},{regs[rs]},{regs[rt]}'
            elif funct == 0x23: desc = f'subu {regs[rd]},{regs[rs]},{regs[rt]}'
            elif funct == 0x24: desc = f'and {regs[rd]},{regs[rs]},{regs[rt]}'
            elif funct == 0x25: desc = f'or {regs[rd]},{regs[rs]},{regs[rt]}'
            elif funct == 0x26: desc = f'xor {regs[rd]},{regs[rs]},{regs[rt]}'
            elif funct == 0x27: desc = f'nor {regs[rd]},{regs[rs]},{regs[rt]}'
            elif funct == 0x2A: desc = f'slt {regs[rd]},{regs[rs]},{regs[rt]}'
            elif funct == 0x2B: desc = f'sltu {regs[rd]},{regs[rs]},{regs[rt]}'
            elif funct == 0x00: desc = f'sll {regs[rd]},{regs[rt]},{shamt}' if word != 0 else 'nop'
            elif funct == 0x02: desc = f'srl {regs[rd]},{regs[rt]},{shamt}'
            elif funct == 0x03: desc = f'sra {regs[rd]},{regs[rt]},{shamt}'
            elif funct == 0x04: desc = f'sllv {regs[rd]},{regs[rt]},{regs[rs]}'
            elif funct == 0x06: desc = f'srlv {regs[rd]},{regs[rt]},{regs[rs]}'
            elif funct == 0x07: desc = f'srav {regs[rd]},{regs[rt]},{regs[rs]}'
            elif funct == 0x08: desc = f'jr {regs[rs]}'
            elif funct == 0x09: desc = f'jalr {regs[rd]},{regs[rs]}'
            elif funct == 0x0C: desc = f'syscall'
            elif funct == 0x10: desc = f'mfhi {regs[rd]}'
            elif funct == 0x12: desc = f'mflo {regs[rd]}'
            elif funct == 0x18: desc = f'mult {regs[rs]},{regs[rt]}'
            elif funct == 0x19: desc = f'multu {regs[rs]},{regs[rt]}'
            elif funct == 0x1A: desc = f'div {regs[rs]},{regs[rt]}'
            elif funct == 0x1B: desc = f'divu {regs[rs]},{regs[rt]}'
            else: desc = f'special funct=0x{funct:02X}'
        elif op == 1:  # REGIMM
            if rt == 0: desc = f'bltz {regs[rs]},0x{target_addr:08X}'
            elif rt == 1: desc = f'bgez {regs[rs]},0x{target_addr:08X}'
            else: desc = f'regimm rt={rt} {regs[rs]},0x{target_addr:08X}'
        elif op == 2: desc = f'j 0x{(word & 0x3FFFFFF) << 2 | 0x80000000:08X}'
        elif op == 3: desc = f'jal 0x{(word & 0x3FFFFFF) << 2 | 0x80000000:08X}'
        elif op == 4: desc = f'beq {regs[rs]},{regs[rt]},0x{target_addr:08X}'
        elif op == 5: desc = f'bne {regs[rs]},{regs[rt]},0x{target_addr:08X}'
        elif op == 6: desc = f'blez {regs[rs]},0x{target_addr:08X}'
        elif op == 7: desc = f'bgtz {regs[rs]},0x{target_addr:08X}'
        elif op == 8: desc = f'addi {regs[rt]},{regs[rs]},{simm}'
        elif op == 9: desc = f'addiu {regs[rt]},{regs[rs]},{simm}'
        elif op == 0x0A: desc = f'slti {regs[rt]},{regs[rs]},{simm}'
        elif op == 0x0B: desc = f'sltiu {regs[rt]},{regs[rs]},{simm}'
        elif op == 0x0C: desc = f'andi {regs[rt]},{regs[rs]},0x{imm:04X}'
        elif op == 0x0D: desc = f'ori {regs[rt]},{regs[rs]},0x{imm:04X}'
        elif op == 0x0E: desc = f'xori {regs[rt]},{regs[rs]},0x{imm:04X}'
        elif op == 0x0F: desc = f'lui {regs[rt]},0x{imm:04X}'
        elif op == 0x20: desc = f'lb {regs[rt]},{simm}({regs[rs]})'
        elif op == 0x21: desc = f'lh {regs[rt]},{simm}({regs[rs]})'
        elif op == 0x23: desc = f'lw {regs[rt]},{simm}({regs[rs]})'
        elif op == 0x24: desc = f'lbu {regs[rt]},{simm}({regs[rs]})'
        elif op == 0x25: desc = f'lhu {regs[rt]},{simm}({regs[rs]})'
        elif op == 0x28: desc = f'sb {regs[rt]},{simm}({regs[rs]})'
        elif op == 0x29: desc = f'sh {regs[rt]},{simm}({regs[rs]})'
        elif op == 0x2B: desc = f'sw {regs[rt]},{simm}({regs[rs]})'
        else: desc = f'op=0x{op:02X}'
        
        print(f'  0x{target:08X}: 0x{word:08X}  {desc}')
    else:
        print(f'  0x{target:08X}: (outside EXE, off=0x{off:X})')
