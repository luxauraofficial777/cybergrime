#!/usr/bin/env python3
"""Search for BCD 32:34:71 and 23:31:08 in the EXE embedded in the built disc."""
import sys

SECTOR_SIZE = 2352
USER_SIZE = 2048
EXE_LBA = 24
HEADER = 24

disc_path = sys.argv[1] if len(sys.argv) > 1 else r"C:\LuxAura\VoidWalkers_Project\DQLOSTTRANSLATION\build_staging\dq4_gold.bin"

with open(disc_path, "rb") as f:
    disc = f.read()

# Extract EXE from sector 24
exe_start = EXE_LBA * SECTOR_SIZE + HEADER
exe = disc[exe_start:exe_start + 677888]

print(f"Disc: {len(disc)} bytes")
print(f"EXE: {len(exe)} bytes")

# Search for BCD 32:34:71 (DW7 FMV)
pat1 = bytes([0x32, 0x34, 0x71])
idx = 0
count = 0
while True:
    idx = exe.find(pat1, idx)
    if idx == -1:
        break
    print(f"  BCD 32:34:71 at EXE offset 0x{idx:06X} (RAM 0x{idx + 0x80017F00:08X})")
    count += 1
    idx += 1
print(f"  Total 32:34:71: {count}")

# Search for BCD 23:31:08 (patched DQ4 FMV)
pat2 = bytes([0x23, 0x31, 0x08])
idx = 0
count2 = 0
while True:
    idx = exe.find(pat2, idx)
    if idx == -1:
        break
    print(f"  BCD 23:31:08 at EXE offset 0x{idx:06X} (RAM 0x{idx + 0x80017F00:08X})")
    count2 += 1
    idx += 1
print(f"  Total 23:31:08: {count2}")

# Also search for LE32 146621 = 0x00023C5D
import struct
pat3 = struct.pack("<I", 146621)
idx = 0
count3 = 0
while True:
    idx = exe.find(pat3, idx)
    if idx == -1:
        break
    print(f"  LE32 146621 at EXE offset 0x{idx:06X} (RAM 0x{idx + 0x80017F00:08X})")
    count3 += 1
    idx += 1
print(f"  Total LE32 146621: {count3}")

# Search for BCD 32:34:71 in the entire disc (not just EXE)
idx = 0
count4 = 0
while True:
    idx = disc.find(pat1, idx)
    if idx == -1:
        break
    sector = idx // SECTOR_SIZE
    offset_in_sector = idx % SECTOR_SIZE
    if offset_in_sector >= 24 and offset_in_sector < 24 + USER_SIZE:  # user data area
        print(f"  BCD 32:34:71 in disc at byte {idx} (sector {sector}, user offset {offset_in_sector - 24})")
        count4 += 1
    idx += 1
print(f"  Total in disc user data: {count4}")
