$j = Get-Content telemetry_cdromfix2_15m.json -Raw | ConvertFrom-Json
Write-Host "Instructions: $($j.Instructions_Executed)"
Write-Host "VBlanks: $($j.VBlank_Count)"
Write-Host "Crashed: $($j.Crashed)"
Write-Host "PC: $($j.Register_Dump.PC)"
$lines = $j.TTY_Tail -split "`n"
Write-Host "TTY lines: $($lines.Count)"
Write-Host "=== Last 40 TTY lines ==="
$lines | Select-Object -Last 40 | ForEach-Object { Write-Host "  $_" }
Write-Host ""
Write-Host "=== VBC2 lines ==="
$vbc = $lines | Where-Object { $_ -match 'VBC2' }
Write-Host "VBC2 lines: $($vbc.Count)"
$vbc | Select-Object -Last 10 | ForEach-Object { Write-Host "  $_" }
Write-Host ""
Write-Host "=== CD-ROM sector/INT1 lines ==="
$cd = $lines | Where-Object { $_ -match 'INT1|sector.*ready|CDROM.*Read|Setloc|ReadN|ReadS' }
Write-Host "CD-ROM read lines: $($cd.Count)"
$cd | Select-Object -First 20 | ForEach-Object { Write-Host "  $_" }
Write-Host ""
Write-Host "=== GPU lines ==="
$gpu = $lines | Where-Object { $_ -match 'GP0WR|GP1WR|DMA.*GPU|GPU timeout' }
Write-Host "GPU lines: $($gpu.Count)"
$gpu | Select-Object -First 20 | ForEach-Object { Write-Host "  $_" }
Write-Host ""
Write-Host "=== MEMDUMP ==="
$mem = $lines | Where-Object { $_ -match 'MEMDUMP|VBC2|CD_STAT|CD_READY|DISP_FLAG|EVT_FLAG' }
$mem | ForEach-Object { Write-Host "  $_" }
Write-Host ""
Write-Host "=== BIOS Calls (unique) ==="
$calls = @{}
foreach ($e in $j.BIOS_Call_Log) {
    $fn = '{0:X2}' -f [int]$e.fn
    $key = "$($e.table):0x$fn"
    if (-not $calls.ContainsKey($key)) { $calls[$key] = 0 }
    $calls[$key]++
}
foreach ($k in ($calls.Keys | Sort-Object)) {
    Write-Host "  $k : $($calls[$k]) calls"
}
Write-Host ""
Write-Host "=== Last 20 BIOS calls ==="
$j.BIOS_Call_Log | Select-Object -Last 20 | ForEach-Object {
    $fn = '{0:X2}' -f [int]$_.fn
    Write-Host ("  #{0} {1}:0x{2} ra=0x{3} a0=0x{4}" -f $_.instr, $_.table, $fn, $_.ra, $_.a0)
}
