#!/usr/bin/env python3
"""Disassemble DW7 EXE around the VSync wait loop area (0x80099F00-0x80099FC0)
and DQ4 JP EXE at the same range, to compare the full loop context."""
import struct
import os
from capstone import Cs, CS_ARCH_MIPS, CS_MODE_MIPS32, CS_MODE_LITTLE_ENDIAN

def read_exe_from_disc(disc_path, exe_lba=24, sector_size=2352, user_offset=24, user_size=2048):
    """Read EXE from disc at given LBA."""
    with open(disc_path, 'rb') as f:
        # Read enough sectors for the EXE (typically ~675KB = 330 sectors)
        exe_sectors = 340
        f.seek(exe_lba * sector_size)
        raw = f.read(exe_sectors * sector_size)
    
    # Extract user data from each sector
    exe_data = bytearray()
    for i in range(exe_sectors):
        sector = raw[i * sector_size:(i + 1) * sector_size]
        if len(sector) < user_offset + user_size:
            break
        exe_data += sector[user_offset:user_offset + user_size]
    
    return bytes(exe_data)

def disassemble_range(exe_data, load_addr, start_ram, end_ram):
    """Disassemble a range of RAM addresses from the EXE."""
    code_offset = 0x800  # EXE header size
    file_start = start_ram - load_addr + code_offset
    file_end = end_ram - load_addr + code_offset
    
    if file_start < 0 or file_end > len(exe_data):
        return f"  (range 0x{start_ram:08X}-0x{end_ram:08X} outside EXE)\n"
    
    code_bytes = exe_data[file_start:file_end]
    md = Cs(CS_ARCH_MIPS, CS_MODE_MIPS32 | CS_MODE_LITTLE_ENDIAN)
    md.detail = True
    
    lines = []
    for insn in md.disasm(code_bytes, start_ram):
        lines.append(f"  0x{insn.address:08X}: {insn.mnemonic:8s} {insn.op_str}")
    
    return '\n'.join(lines) + '\n'

def main():
    base = r"C:\LuxAura\VoidWalkers_Project\DQLOSTTRANSLATION"
    
    discs = {
        "DQ4_JP": (os.path.join(base, "Dragon Quest IV - Michibikareshi Mono Tachi (Japan).bin"), 0x80017F00),
        "DW7_US": (os.path.join(base, "DW7D1", "DW7D1.bin"), 0x80017F00),
        "Frank_v41": (os.path.join(base, "dq4_frankenstein_v41.bin"), 0x80017F00),
    }
    
    # Ranges to disassemble
    ranges = [
        ("DW7_loop_context", 0x80099F00, 0x80099FC0),
        ("DQ4_vsync_full", 0x80099F20, 0x80099FC0),
        ("DQ4_vsync_caller", 0x80099EE0, 0x80099F50),
        # Also check the area around 0x800D5190 (loading complete flag)
        ("loading_flag_area", 0x800D5180, 0x800D51A0),
        # Check 0x800BA294 area (DQ4 VBlank counter)
        ("vblank_counter_area", 0x800BA280, 0x800BA2A0),
    ]
    
    for name, (path, load_addr) in discs.items():
        if not os.path.exists(path):
            print(f"\n[{name}] FILE NOT FOUND: {path}")
            continue
        
        print(f"\n{'='*60}")
        print(f"[{name}] {os.path.basename(path)}")
        print(f"{'='*60}")
        
        exe_data = read_exe_from_disc(path)
        hdr_magic = exe_data[0:8]
        if hdr_magic != b'PS-X EXE':
            print(f"  ERROR: Invalid EXE magic: {hdr_magic}")
            continue
        
        pc0 = struct.unpack_from('<I', exe_data, 0x10)[0]
        t_addr = struct.unpack_from('<I', exe_data, 0x18)[0]
        t_size = struct.unpack_from('<I', exe_data, 0x1C)[0]
        print(f"  PC0=0x{pc0:08X} t_addr=0x{t_addr:08X} t_size=0x{t_size:08X} end=0x{t_addr+t_size:08X}")
        
        for label, start, end in ranges:
            print(f"\n  [{label}] (0x{start:08X}-0x{end:08X}):")
            print(disassemble_range(exe_data, load_addr, start, end))
    
    # Save output
    import io
    import sys
    output = io.StringIO()
    oldstdout = sys.stdout
    sys.stdout = output
    sys.stdout = oldstdout
    
    print("\nDone.")

if __name__ == '__main__':
    main()
