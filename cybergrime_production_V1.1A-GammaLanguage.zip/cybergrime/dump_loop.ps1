$b = [System.IO.File]::ReadAllBytes('thread_code_blob.bin')
$base = 0x800D9E80
$start = 0x800D9F24 - $base
for ($i = $start; $i -lt ($start + 0x20); $i += 4) {
    $v = [BitConverter]::ToUInt32($b, $i)
    $addr = $base + $i
    Write-Host ("{0:X8}: {1:X8}" -f $addr, $v)
}
