#!/usr/bin/env python3
"""
vector_db.py — Retrieval-augmented search over historical session logs.

Indexes 50+ telemetry JSON files (500MB+ of session logs) into a local
vector database. When a live DuckStation error is flagged, the system
converts it into an embedding query and searches for matching historical
failure states.

The database uses:
  - TelemetryEncoder for vectorization
  - Cosine similarity for ranking
  - Historical failure signatures (HF-001 through HF-006) for structured matching
  - Crash vectors from vector_index.json for PC-level matching

Usage:
    db = VectorDB()
    db.build_index()  # One-time index build from telemetry files
    results = db.query(live_telemetry, top_k=5)
    # results = [{ 'source': 'telemetry_v38a.json', 'similarity': 0.92,
    #              'historical_failure': 'HF-001', 'resolution': '...', ... }]
"""

import json
import os
import struct
import time
from typing import Dict, List, Optional, Any, Tuple
from telemetry_encoder import TelemetryEncoder

# ── Historical Failure Signatures (from build_orchestrator.py) ───────────────
# These are the structured failure definitions extracted from 500MB of logs.

HISTORICAL_FAILURES = [
    {
        'id': 'HF-001', 'name': 'BSS_ZEROS_THREAD_ENTRY',
        'signature': {
            'pc_stall': [0x80098780, 0x8009885C, 0x80098840, 0x80048004],
            'bss_zero_target': 0x800D9E80,
            'bss_zero_instr_pc': 0x8008E294,
            'symptom': 'event_flag_stall',
        },
        'root_cause': 'BSS clear loop at 0x8008E294 zeros CD-ROM thread entry at 0x800D9E80.',
        'verified_fix': 'Narrow BSS clear end from 0x800F4980 to 0x800BCCC8.',
        'fix_address': 0x8008E290, 'fix_value': 0x2462CCC8,
        'status': 'PATCHED_AT_BUILD_TIME',
        'false_hypotheses': [
            '0x80100000 is unmapped RAM (FALSE)',
            'CD-ROM intercept not on disc at 0x80F64 (FALSE)',
            'LUI/ADDIU swapped at 0x76B84/0x76B88 (FALSE)',
            'Hang at 146621 is the FMV (FALSE — boot overlay)',
        ],
    },
    {
        'id': 'HF-002', 'name': 'HBD_SECTOR_EXTENSION_CORRUPTION',
        'signature': {'disc_extension_lba': 302537, 'symptom': 'emulator_cannot_read_extension'},
        'root_cause': 'Disc extension beyond original DW7 end was raw zeros.',
        'verified_fix': 'extend_disc_mode2() writes valid MODE2 Form1 sectors.',
        'status': 'FIXED',
    },
    {
        'id': 'HF-003', 'name': 'TREE_IN_BSS_RANGE',
        'signature': {'tree_addr': 0x800EF1C8, 'bss_range': [0x800BC668, 0x800F4980]},
        'root_cause': 'Huffman tree at 0x800EF1C8 inside BSS clear range.',
        'verified_fix': 'Relocate tree to 0x80100000.',
        'status': 'FIXED',
    },
    {
        'id': 'HF-004', 'name': 'COPY_ROUTINE_BUGS',
        'signature': {'copy_routine_pc': 0x800BC700, 'missing_nop': True},
        'root_cause': 'Copy routine had missing NOP and wrong BNE offset.',
        'verified_fix': 'All 14 copy routine instructions verified correct.',
        'status': 'FIXED',
    },
    {
        'id': 'HF-005', 'name': 'ENGINE_PATCH_BISECTION_GAP',
        'signature': {'symptom': 'no_enix_logo', 'stall_after_overlay': True},
        'root_cause': '10-patch disc-check bypass may leave drive-state in bad value.',
        'verified_fix': 'v38a/v38b bisection plan.',
        'status': 'UNRESOLVED',
        'false_hypotheses': [
            'Hang at 146621 is the FMV (FALSE — boot overlay)',
            '0x80100000 unmapped (FALSE)',
            'CD-ROM intercept not on disc (FALSE)',
            'LUI/ADDIU swapped (FALSE — read bug)',
        ],
    },
    {
        'id': 'HF-006', 'name': 'LBA_POINTER_DRIFT',
        'signature': {'original_lba': 354, 'frankenstein_lba': 355, 'delta': 1},
        'root_cause': 'DW7 HBD at LBA 354, Frankenstein at 355. All pointers must shift +1.',
        'verified_fix': 'remap_pointers_matched_only() applies +1 delta.',
        'status': 'FIXED',
    },
]


class VectorDB:
    """Local vector database for retrieval-augmented diagnostics."""

    def __init__(self, base_dir: str = None, index_cache: str = None):
        self.encoder = TelemetryEncoder()
        self.base_dir = base_dir or os.path.dirname(os.path.abspath(__file__))
        self.index_cache = index_cache or os.path.join(self.base_dir, 'vector_db_cache.json')
        self.entries: List[Dict] = []
        self.vectors: List[List[float]] = []
        self._index_loaded = False

    def build_index(self, force_rebuild: bool = False) -> int:
        """Build the vector index from all telemetry JSON files.

        Returns the number of indexed entries.
        """
        if os.path.exists(self.index_cache) and not force_rebuild:
            with open(self.index_cache, 'r', encoding='utf-8', errors='replace') as f:
                cache = json.load(f)
            self.entries = cache.get('entries', [])
            self.vectors = cache.get('vectors', [])
            self._index_loaded = True
            print(f"[VectorDB] Loaded {len(self.entries)} entries from cache")
            return len(self.entries)

        print("[VectorDB] Building index from telemetry files...")
        self.entries = []
        self.vectors = []

        # Find all telemetry JSON files
        telemetry_files = self._find_telemetry_files()
        print(f"[VectorDB] Found {len(telemetry_files)} telemetry files")

        for tf_path in telemetry_files:
            try:
                with open(tf_path, 'r', encoding='utf-8', errors='replace') as f:
                    data = json.load(f)

                # Extract telemetry in the format the encoder expects
                telemetry = self._normalize_telemetry(data, tf_path)
                if telemetry is None:
                    continue

                vec = self.encoder.encode(telemetry)
                entry = {
                    'source': os.path.basename(tf_path),
                    'path': tf_path,
                    'telemetry': telemetry,
                    'timestamp': os.path.getmtime(tf_path),
                }
                self.entries.append(entry)
                self.vectors.append(vec)

            except (json.JSONDecodeError, KeyError, TypeError) as e:
                continue

        # Also index historical failure signatures as synthetic entries
        for hf in HISTORICAL_FAILURES:
            sig = hf['signature']
            synthetic_telemetry = {
                'Last_Known_PC': sig.get('pc_stall', [0])[0] if 'pc_stall' in sig else 0,
                'Instructions_Executed': 0,
                'Register_Dump': {},
                'Frozen': True,
                'Crashed': False,
                'thread_entry': 0 if 'bss_zero_target' in sig else None,
                'bss_clear_end_instr': 0x24634980 if hf['id'] == 'HF-001' else None,
                'tree_value': 0 if hf['id'] == 'HF-003' else None,
                'source': f"historical_{hf['id']}",
            }
            vec = self.encoder.encode(synthetic_telemetry)
            entry = {
                'source': f"historical_{hf['id']}",
                'path': None,
                'telemetry': synthetic_telemetry,
                'historical_failure': hf,
                'timestamp': 0,
            }
            self.entries.append(entry)
            self.vectors.append(vec)

        # Save cache
        cache = {
            'entries': self.entries,
            'vectors': self.vectors,
            'built_at': time.time(),
            'entry_count': len(self.entries),
        }
        with open(self.index_cache, 'w', encoding='utf-8') as f:
            json.dump(cache, f, indent=2)

        self._index_loaded = True
        print(f"[VectorDB] Indexed {len(self.entries)} entries "
              f"({len(self.vectors)} vectors)")
        return len(self.entries)

    def _find_telemetry_files(self) -> List[str]:
        """Find all telemetry JSON files in the project."""
        results = []
        for root, dirs, files in os.walk(self.base_dir):
            for fname in files:
                if fname.startswith('telemetry') and fname.endswith('.json'):
                    results.append(os.path.join(root, fname))
                elif fname.startswith('closed_loop') and fname.endswith('.json'):
                    results.append(os.path.join(root, fname))
        # Also check parent directory
        parent = os.path.dirname(self.base_dir)
        for fname in os.listdir(parent):
            if fname.startswith('telemetry') and fname.endswith('.json'):
                results.append(os.path.join(parent, fname))
        return sorted(results)

    def _normalize_telemetry(self, data: Dict, source_path: str) -> Optional[Dict]:
        """Normalize a telemetry JSON file into the encoder's expected format."""
        # Handle different telemetry formats
        if 'Last_Known_PC' in data:
            return data
        elif 'last_pc' in data:
            return {
                'Last_Known_PC': data['last_pc'],
                'Instructions_Executed': data.get('instruction_count', 0),
                'Register_Dump': data.get('registers', {}),
                'Frozen': data.get('frozen', False),
                'Crashed': data.get('crashed', False),
            }
        elif 'iterations' in data:
            # closed_loop_controller output format
            iterations = data.get('iterations', [])
            if iterations:
                last = iterations[-1] if isinstance(iterations, list) else iterations
                return {
                    'Last_Known_PC': last.get('stall_pc', 0),
                    'Instructions_Executed': last.get('instructions', 0),
                    'Frozen': True,
                    'Crashed': False,
                    'thread_entry': last.get('thread_entry', None),
                    'bss_clear_end_instr': last.get('bss_end_instr', None),
                    'tree_value': last.get('tree_value', None),
                }
        return None

    def query(self, live_telemetry: Dict[str, Any], top_k: int = 5) -> List[Dict]:
        """Query the vector database for matching historical failure states.

        Args:
            live_telemetry: Dict with PC, registers, memory state from live DuckStation
            top_k: Number of top matches to return

        Returns:
            List of match dicts sorted by similarity, each containing:
            - source: File/historical ID
            - similarity: Cosine similarity score (0-1)
            - historical_failure: HF definition if matched
            - resolution: Verified fix from historical match
            - false_hypotheses: Known dead ends to avoid
        """
        if not self._index_loaded:
            self.build_index()

        query_vec = self.encoder.encode(live_telemetry)

        # Compute similarities
        scored = []
        for i, (entry, vec) in enumerate(zip(self.entries, self.vectors)):
            sim = self.encoder.cosine_similarity(query_vec, vec)
            scored.append((sim, entry, vec))

        scored.sort(key=lambda x: x[0], reverse=True)

        # Also do structured matching against historical failure signatures
        structured_matches = self._structured_match(live_telemetry)

        # Merge results
        results = []
        seen_sources = set()

        # Add structured matches first (higher confidence)
        for hf in structured_matches:
            source = f"historical_{hf['id']}"
            if source not in seen_sources:
                results.append({
                    'source': source,
                    'similarity': 1.0,  # Structured match = perfect
                    'match_type': 'STRUCTURED',
                    'historical_failure': hf,
                    'resolution': hf.get('verified_fix', 'N/A'),
                    'root_cause': hf.get('root_cause', 'N/A'),
                    'false_hypotheses': hf.get('false_hypotheses', []),
                    'status': hf.get('status', 'UNKNOWN'),
                })
                seen_sources.add(source)

        # Add vector similarity matches
        for sim, entry, vec in scored[:top_k * 2]:
            source = entry['source']
            if source in seen_sources:
                continue
            if sim < 0.3:  # Threshold
                continue

            hf = entry.get('historical_failure')
            result = {
                'source': source,
                'similarity': sim,
                'match_type': 'VECTOR_SIMILARITY',
                'historical_failure': hf,
                'resolution': hf.get('verified_fix') if hf else None,
                'root_cause': hf.get('root_cause') if hf else None,
                'false_hypotheses': hf.get('false_hypotheses', []) if hf else [],
                'telemetry_summary': self.encoder.describe_vector(vec),
            }
            results.append(result)
            seen_sources.add(source)

            if len(results) >= top_k:
                break

        return results[:top_k]

    def _structured_match(self, telemetry: Dict[str, Any]) -> List[Dict]:
        """Match telemetry against structured historical failure signatures."""
        matches = []
        pc = telemetry.get('Last_Known_PC', 0)
        if isinstance(pc, str):
            try:
                pc = int(pc, 16)
            except ValueError:
                pc = 0

        thread_entry = telemetry.get('thread_entry')
        if isinstance(thread_entry, str):
            try:
                thread_entry = int(thread_entry, 16)
            except ValueError:
                thread_entry = None

        for hf in HISTORICAL_FAILURES:
            sig = hf['signature']
            matched = False

            # Check PC stall match
            if 'pc_stall' in sig:
                stall_pcs = sig['pc_stall']
                if isinstance(stall_pcs[0], str):
                    stall_pcs = [int(s, 16) for s in stall_pcs]
                if pc in stall_pcs:
                    matched = True

            # Check BSS zero target
            if 'bss_zero_target' in sig and thread_entry is not None:
                if thread_entry == 0:
                    matched = True

            # Check tree zeroed
            tree_val = telemetry.get('tree_value')
            if isinstance(tree_val, str):
                try:
                    tree_val = int(tree_val, 16)
                except ValueError:
                    tree_val = None
            if 'tree_addr' in sig and tree_val is not None:
                if tree_val == 0:
                    matched = True

            if matched:
                matches.append(hf)

        return matches

    def get_context_for_agent(self, live_telemetry: Dict[str, Any],
                               top_k: int = 3) -> str:
        """Generate a context string for injection into the LLM agent.

        This provides the agent with:
        1. Live crash trace summary
        2. Top matching historical resolutions
        3. Known false hypotheses to avoid
        4. Verified fix instructions if available
        """
        results = self.query(live_telemetry, top_k=top_k)

        lines = []
        lines.append("=== VECTOR DATABASE RETRIEVAL CONTEXT ===")
        lines.append(f"Query: PC=0x{live_telemetry.get('Last_Known_PC', 0):08X} "
                     f"(if int) or {live_telemetry.get('Last_Known_PC', '?')}")
        lines.append(f"Matches found: {len(results)}")
        lines.append("")

        for i, match in enumerate(results):
            lines.append(f"--- Match {i+1}: {match['source']} "
                        f"(sim={match['similarity']:.2f}, "
                        f"type={match['match_type']}) ---")

            if match.get('root_cause'):
                lines.append(f"  Root cause: {match['root_cause']}")

            if match.get('resolution'):
                lines.append(f"  Verified fix: {match['resolution']}")

            if match.get('false_hypotheses'):
                lines.append("  ⚠ FALSE HYPOTHESES TO AVOID:")
                for fh in match['false_hypotheses']:
                    lines.append(f"    - {fh}")

            hf = match.get('historical_failure')
            if hf:
                lines.append(f"  HF ID: {hf.get('id', '?')}")
                lines.append(f"  Status: {hf.get('status', '?')}")
                if 'fix_address' in hf and 'fix_value' in hf:
                    lines.append(f"  Fix: {hf['fix_address']} = 0x{hf['fix_value']:08X}")

            lines.append("")

        lines.append("=== END CONTEXT ===")
        return '\n'.join(lines)
