#include "psx_test_station.h"
#include "txrt_hle.h"
#include <cstdio>
#include <cstring>

static PSX_Memory mem;
static MIPS_CPU cpu;

int main(int argc, char* argv[]) {
    printf("PSX HEADLESS TRACER v2.0\n");
    printf("=========================\n");

    // Default disc path
    const char* disc = "C:\\LuxAura\\VoidWalkers_Project\\DQLOSTTRANSLATION\\dq4_frankenstein_final.bin";
    if (argc >= 2) disc = argv[1];

    uint64_t max_instrs = 200000000;
    if (argc >= 3) max_instrs = strtoull(argv[2], nullptr, 10);

    printf("[0] Disc: %s\n", disc);
    printf("[0] Max instructions: %llu\n", max_instrs);

    // Load disc
    printf("[1] Loading disc...\n");
    if (!mem.load_cd(disc)) {
        printf("FAILED to open disc: %s\n", disc);
        return 1;
    }
    printf("[2] Disc opened OK\n");

    // Parse ISO9660 directory
    mem.parse_iso_directory();

    // Auto-detect boot EXE from SYSTEM.CNF
    uint32_t exe_lba, exe_sectors;
    char exe_name[256];
    if (!mem.find_boot_exe(exe_lba, exe_sectors, exe_name, sizeof(exe_name))) {
        printf("FAILED to find boot EXE\n");
        return 1;
    }

    // Load EXE
    uint32_t pc, dest, size;
    if (!mem.load_exe_from_cd(exe_lba, exe_sectors, pc, dest, size)) {
        printf("FAILED to load EXE\n");
        return 1;
    }
    printf("[3] EXE loaded: %s PC=0x%08X dest=0x%08X size=0x%X\n", exe_name, pc, dest, size);

    // Load TXRT translation payload from host filesystem
    const char* txrt_path = "C:\\LuxAura\\VoidWalkers_Project\\DQLOSTTRANSLATION\\translation-tools\\txrt_payload.bin";
    // Default mode: diagnostic (log registers at decompression entry to identify block ID + output buffer)
    BypassMode txrt_mode = BYPASS_DIAGNOSTIC;
    // Parse TXRT mode from command line: --txrt-mode=diagnostic|bypass|post|disabled
    for (int i = 2; i < argc; i++) {
        if (strncmp(argv[i], "--txrt-mode=", 12) == 0) {
            const char* m = argv[i] + 12;
            if      (!strcmp(m, "bypass"))     txrt_mode = BYPASS_PRE_DECOMP;
            else if (!strcmp(m, "post"))      txrt_mode = BYPASS_POST_DECOMP;
            else if (!strcmp(m, "disabled"))  txrt_mode = BYPASS_DISABLED;
            else                                txrt_mode = BYPASS_DIAGNOSTIC;
        } else if (strncmp(argv[i], "--txrt=", 8) == 0) {
            txrt_path = argv[i] + 8;
        }
    }
    if (txrt_load(txrt_path)) {
        txrt_set_mode(txrt_mode);
        printf("[4] TXRT payload loaded — mode: %s\n",
               txrt_mode == BYPASS_PRE_DECOMP ? "PRE-DECOMP (surgical bypass)" :
               txrt_mode == BYPASS_POST_DECOMP ? "POST-DECOMP (fallback swap)" :
               txrt_mode == BYPASS_DIAGNOSTIC ? "DIAGNOSTIC (log only)" : "DISABLED");
    } else {
        printf("[4] TXRT payload not loaded — bypass disabled\n");
    }

    // Setup CPU
    cpu.read32 = cb_read32; cpu.read16 = cb_read16; cpu.read8 = cb_read8;
    cpu.write32 = cb_write32; cpu.write16 = cb_write16; cpu.write8 = cb_write8;
    cpu.mem_ctx = &mem;
    g_mem = &mem;
    g_cpu = &cpu;
    cpu.pc = pc;
    cpu.next_pc = pc + 4;
    // Use EXE header SP/GP if available, otherwise defaults
    cpu.set_reg(29, mem.exe_init_sp ? mem.exe_init_sp : 0x801FFF00);
    cpu.set_reg(28, mem.exe_init_gp ? mem.exe_init_gp : 0x800BC668);
    cpu.set_reg(31, 0x00000000);

    // Initialize HLE BIOS event system
    mem.init_events();
    // Enable VBlank in I_MASK
    mem.intc_mask = 0x01;
    // Enable CP0 interrupts: IEc=1, IM bit 8=1, keep CU2
    cpu.cp0_status = 0x40000101;

    // Use C++ HLE exception handler (calls HookEntryInt → game's VBlank handler)
    // The MIPS fallback handler doesn't call HookEntryInt, so game flags never get set.
    // mem.install_mips_exception_handler();
    printf("[5] C++ HLE exception handler active (HookEntryInt dispatch)\n");

    cpu.log_enabled = false;
    printf("[6] Running emulation...\n\n");

    // Run
    int bios_count = 0;
    int irq_count = 0;
    uint64_t last_bios_instr = 0;
    while (!cpu.crashed && cpu.instructions < max_instrs) {
        // Print BIOS calls
        if (cpu.pc == 0xA0 || cpu.pc == 0xB0 || cpu.pc == 0xC0) {
            uint32_t fn = cpu.get_reg(9) & 0xFF;
            uint32_t a0 = cpu.get_reg(4), a1 = cpu.get_reg(5), a2 = cpu.get_reg(6), a3 = cpu.get_reg(7);
            uint64_t gap = cpu.instructions - last_bios_instr;
            last_bios_instr = cpu.instructions;
            const char* tbl = cpu.pc == 0xA0 ? "A" : (cpu.pc == 0xB0 ? "B" : "C");
            printf("[BIOS] %s:0x%02X at instr #%llu (gap=%llu) $ra=0x%08X a0=0x%08X a1=0x%08X a2=0x%08X a3=0x%08X\n",
                   tbl, fn, cpu.instructions, gap, cpu.get_reg(31), a0, a1, a2, a3);
            bios_count++;
        }
        // Print VBlank IRQ delivery
        if (cpu.pc == 0x80000080) {
            irq_count++;
            if (irq_count <= 10 || irq_count % 100 == 0) {
                printf("[IRQ] VBlank #%d at instr #%llu EPC=0x%08X SR=0x%08X\n",
                       irq_count, cpu.instructions, cpu.cp0_epc, cpu.cp0_status);
            }
        }
        if (!cpu.step()) break;

        // Periodic status
        if (cpu.instructions % 1000000 == 0) {
            uint32_t vblank_counter = mem.read32(0x800B63D8);
            uint16_t display_flag = mem.read16(0x800B5312);
            uint8_t event_flag = mem.read8(0x800B679C);
            uint32_t gpu_status = mem.read32(0x1F801814);
            uint32_t i_stat = mem.intc_stat;
            uint32_t i_mask = mem.intc_mask;
            printf("[STATUS] instr=%llu PC=0x%08X vblank=%u | vbcnt=0x%08X disp=0x%04X evt=0x%02X gpu=0x%08X istat=0x%02X imask=0x%02X\n",
                   cpu.instructions, cpu.pc, mem.vblank_counter,
                   vblank_counter, display_flag, event_flag, gpu_status, i_stat, i_mask);
        }
    }

    printf("\n[DONE] instr=%llu crashed=%d\n", cpu.instructions, cpu.crashed);
    if (cpu.crashed) printf("[CRASH] %s\n", cpu.crash_reason);
    printf("[BIOS calls total: %d]\n", bios_count);
    printf("[VBlank IRQs delivered: %d]\n", irq_count);
    printf("[VBlank counter: %u]\n", mem.vblank_counter);
    printf("[CP0 Status: 0x%08X  Cause: 0x%08X  EPC: 0x%08X]\n", cpu.cp0_status, cpu.cp0_cause, cpu.cp0_epc);
    txrt_status();

    // Full state dump on exit
    mem.dump_full_state(cpu);

    if (cpu.log_file) { fflush(cpu.log_file); cpu.close_log(); }
    return cpu.crashed ? 1 : 0;
}
