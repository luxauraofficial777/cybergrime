#!/usr/bin/env python3
"""
telemetry_encoder.py — Convert live DuckStation telemetry into embedding vectors.

Transforms PC, registers, memory state, and instruction traces into a
fixed-dimensional feature vector for similarity search against the
historical vector database.

Vector Construction:
  The embedding is a 64-dimensional float vector encoding:
    - PC region (one-hot bucketed into 16 PSX memory zones)
    - Register anomalies (8 flags for known-bad register values)
    - Memory state (8 flags for critical address zero/value checks)
    - Instruction fingerprint (16 MIPS opcode histogram buckets)
    - Stall characteristics (8 features: duration, uniqueness, loop range)
    - Historical context (8 features from crash vector matching)

Usage:
    encoder = TelemetryEncoder()
    vec = encoder.encode(telemetry_dict)
    # vec is a list[float] of length 64
"""

import struct
import hashlib
import os
import json
from typing import Dict, List, Optional, Any, Tuple

# ── PSX Memory Zones (16 buckets for PC one-hot encoding) ────────────────────
PSX_ZONES = [
    (0x80000000, 0x80010000, "BIOS_VECTOR"),
    (0x80010000, 0x80018000, "BIOS_HLE"),
    (0x80018000, 0x80030000, "EXE_HEADER"),
    (0x80030000, 0x80050000, "EXE_BOOT"),
    (0x80050000, 0x80080000, "EXE_INIT"),
    (0x80080000, 0x800A0000, "EXE_CODE_1"),
    (0x800A0000, 0x800C0000, "EXE_CODE_2"),
    (0x800C0000, 0x800F0000, "EXE_DATA"),
    (0x800F0000, 0x80100000, "EXE_BSS_END"),
    (0x80100000, 0x80110000, "HEAP_TREE"),
    (0x80110000, 0x80140000, "HEAP_DYNAMIC"),
    (0x80140000, 0x801F0000, "HEAP_EXPANDED"),
    (0x801F0000, 0x801FFFF0, "STACK"),
    (0x801FFFF0, 0x80200000, "STACK_TOP"),
    (0x1F000000, 0x1F800000, "PARALLEL_PORT"),
    (0x1FC00000, 0x1FC80000, "BIOS_ROM"),
]

# ── Known-bad register values ────────────────────────────────────────────────
BAD_REG_VALUES = {
    'ra': [0x00000000, 0x00000001, 0x80000000],
    'sp': [0x00000000],
    'gp': [0x00000000],
    'pc': [0x00000000, 0x00000001],
}

# ── Critical memory addresses to check ───────────────────────────────────────
CRITICAL_ADDRS = [
    (0x800D9E80, "thread_entry", lambda v: v == 0, "ZEROED"),
    (0x80100000, "tree_dest", lambda v: v == 0, "ZEROED"),
    (0x8008E290, "bss_end_instr", lambda v: v == 0x24634980, "ORIGINAL_UNPATCHED"),
    (0x800BC668, "bss_start", lambda v: v != 0, "NONZERO"),
    (0x800F4980, "bss_orig_end", lambda v: v != 0 and v != 0x08, "UNEXPECTED"),
]

# ── MIPS opcode buckets for instruction fingerprinting ───────────────────────
OPCODE_BUCKETS = {
    0x00: "SPECIAL", 0x01: "REGIMM", 0x02: "J", 0x03: "JAL",
    0x04: "BEQ", 0x05: "BNE", 0x06: "BLEZ", 0x07: "BGTZ",
    0x08: "ADDI", 0x09: "ADDIU", 0x0A: "SLTI", 0x0B: "SLTIU",
    0x0C: "ANDI", 0x0D: "ORI", 0x0E: "XORI", 0x0F: "LUI",
    0x20: "LB", 0x21: "LH", 0x23: "LW", 0x24: "LBU",
    0x25: "LHU", 0x28: "SB", 0x29: "SH", 0x2B: "SW",
    0x2D: "SH_LWC2",
}


class TelemetryEncoder:
    """Encode live telemetry into a fixed-dimensional embedding vector."""

    VECTOR_DIM = 64

    def __init__(self, vector_index_path: str = None):
        """Load the vector index for address lookup and crash vector matching."""
        self.vector_index = {}
        self.crash_vectors = []
        if vector_index_path is None:
            vector_index_path = os.path.join(
                os.path.dirname(os.path.abspath(__file__)),
                'vector_index.json'
            )
        if os.path.exists(vector_index_path):
            with open(vector_index_path, 'r') as f:
                idx = json.load(f)
                self.vector_index = idx.get('memory_map', {})
                self.crash_vectors = idx.get('crash_vectors', [])

    def encode(self, telemetry: Dict[str, Any]) -> List[float]:
        """Encode a telemetry dict into a 64-dimensional float vector.

        Args:
            telemetry: Dict with keys like 'Last_Known_PC', 'Register_Dump',
                       'thread_entry', 'bss_clear_end_instr', 'tree_value',
                       'stall_instructions' (optional list of uint32)

        Returns:
            List of 64 floats in [0.0, 1.0] range.
        """
        vec = [0.0] * self.VECTOR_DIM
        pc = telemetry.get('Last_Known_PC', 0)
        if isinstance(pc, str):
            pc = int(pc, 16)

        # ── Features 0-15: PC zone one-hot encoding ──
        for i, (lo, hi, name) in enumerate(PSX_ZONES):
            if lo <= pc < hi:
                vec[i] = 1.0
                break
        else:
            # Unknown zone — spread across bucket 15
            vec[15] = 0.5

        # ── Features 16-23: Register anomaly flags ──
        regs = telemetry.get('Register_Dump', {})
        for i, (reg_name, bad_vals) in enumerate(BAD_REG_VALUES.items()):
            reg_val = regs.get(reg_name, '0x0')
            if isinstance(reg_val, str):
                try:
                    reg_val = int(reg_val, 16)
                except ValueError:
                    reg_val = 0
            vec[16 + i] = 1.0 if reg_val in bad_vals else 0.0

        # ── Features 24-31: Critical memory state flags ──
        for i, (addr, name, check_fn, label) in enumerate(CRITICAL_ADDRS):
            val = telemetry.get(name)
            if val is None:
                # Try reading from telemetry keys
                if name == 'thread_entry':
                    val = telemetry.get('thread_entry', None)
                elif name == 'bss_end_instr':
                    val = telemetry.get('bss_clear_end_instr', None)
                elif name == 'tree_dest':
                    val = telemetry.get('tree_value', None)

            if val is not None:
                if isinstance(val, str):
                    try:
                        val = int(val, 16)
                    except ValueError:
                        val = 0
                vec[24 + i] = 1.0 if check_fn(val) else 0.0
            else:
                vec[24 + i] = 0.0  # Unknown — not flagged

        # ── Features 32-47: Instruction opcode histogram ──
        stall_instrs = telemetry.get('stall_instructions', [])
        if not stall_instrs and 'stall_pc' in telemetry:
            # Try to extract from raw instruction dump
            raw = telemetry.get('stall_raw_bytes', b'')
            if raw:
                for j in range(0, min(len(raw), 32), 4):
                    if len(raw) >= j + 4:
                        word = struct.unpack_from('<I', raw, j)[0]
                        stall_instrs.append(word)

        bucket_counts = [0] * 16
        for word in stall_instrs[:16]:  # Up to 16 instructions
            opcode = (word >> 26) & 0x3F
            bucket_idx = opcode % 16  # Map to 16 buckets
            bucket_counts[bucket_idx] += 1

        max_count = max(bucket_counts) if bucket_counts else 1
        for i, c in enumerate(bucket_counts):
            vec[32 + i] = c / max_count if max_count > 0 else 0.0

        # ── Features 48-55: Stall characteristics ──
        instrs = telemetry.get('Instructions_Executed', 0)
        if isinstance(instrs, str):
            try:
                instrs = int(instrs)
            except ValueError:
                instrs = 0

        # Normalize instruction count (log scale)
        vec[48] = min(1.0, (instrs / 100000.0) if instrs > 0 else 0.0)
        vec[49] = 1.0 if instrs < 1000 else 0.0  # Early exit
        vec[50] = 1.0 if 1000 <= instrs < 50000 else 0.0  # Boot phase
        vec[51] = 1.0 if 50000 <= instrs < 500000 else 0.0  # Init phase
        vec[52] = 1.0 if instrs >= 500000 else 0.0  # Late stall

        # Frozen/crashed flags
        vec[53] = 1.0 if telemetry.get('Frozen', False) else 0.0
        vec[54] = 1.0 if telemetry.get('Crashed', False) else 0.0

        # Patch count (normalized)
        patches = telemetry.get('patches_applied', 0)
        vec[55] = min(1.0, patches / 10.0) if patches else 0.0

        # ── Features 56-63: Historical crash vector matching ──
        # Match against known crash vectors from vector_index.json
        for i, cv in enumerate(self.crash_vectors[:8]):
            cv_pc = cv.get('pc', 0)
            cv_instrs = cv.get('instr_count', 0)

            # PC proximity (within 256 bytes)
            pc_dist = abs(pc - cv_pc)
            pc_match = 1.0 if pc_dist < 256 else 0.0

            # Instruction count proximity (within 10%)
            if cv_instrs > 0 and instrs > 0:
                instr_ratio = min(instrs, cv_instrs) / max(instrs, cv_instrs)
            else:
                instr_ratio = 0.0

            vec[56 + i] = (pc_match * 0.7 + instr_ratio * 0.3)

        return vec

    def encode_to_hash(self, telemetry: Dict[str, Any]) -> str:
        """Encode telemetry to a short hash string for deduplication."""
        vec = self.encode(telemetry)
        # Quantize to bytes and hash
        quantized = bytes([int(v * 255) for v in vec])
        return hashlib.sha256(quantized).hexdigest()[:16]

    def cosine_similarity(self, vec_a: List[float], vec_b: List[float]) -> float:
        """Compute cosine similarity between two vectors."""
        dot = sum(a * b for a, b in zip(vec_a, vec_b))
        mag_a = sum(a * a for a in vec_a) ** 0.5
        mag_b = sum(b * b for b in vec_b) ** 0.5
        if mag_a == 0 or mag_b == 0:
            return 0.0
        return dot / (mag_a * mag_b)

    def euclidean_distance(self, vec_a: List[float], vec_b: List[float]) -> float:
        """Compute euclidean distance between two vectors."""
        return sum((a - b) ** 2 for a, b in zip(vec_a, vec_b)) ** 0.5

    def describe_vector(self, vec: List[float]) -> Dict[str, Any]:
        """Human-readable description of a telemetry vector's features."""
        desc = {}

        # PC zone
        for i, (lo, hi, name) in enumerate(PSX_ZONES):
            if vec[i] > 0.5:
                desc['pc_zone'] = name
                break

        # Register anomalies
        anomalies = []
        for i, (reg_name, _) in enumerate(BAD_REG_VALUES.items()):
            if vec[16 + i] > 0.5:
                anomalies.append(f"{reg_name}_anomaly")
        if anomalies:
            desc['register_anomalies'] = anomalies

        # Memory state
        mem_issues = []
        for i, (_, name, _, label) in enumerate(CRITICAL_ADDRS):
            if vec[24 + i] > 0.5:
                mem_issues.append(f"{name}_{label}")
        if mem_issues:
            desc['memory_issues'] = mem_issues

        # Stall phase
        if vec[49] > 0.5:
            desc['stall_phase'] = 'EARLY_EXIT'
        elif vec[50] > 0.5:
            desc['stall_phase'] = 'BOOT'
        elif vec[51] > 0.5:
            desc['stall_phase'] = 'INIT'
        elif vec[52] > 0.5:
            desc['stall_phase'] = 'LATE'

        # Historical matches
        hist_matches = []
        for i in range(8):
            if vec[56 + i] > 0.3:
                hist_matches.append(f"crash_vector_{i}")
        if hist_matches:
            desc['historical_matches'] = hist_matches

        return desc
