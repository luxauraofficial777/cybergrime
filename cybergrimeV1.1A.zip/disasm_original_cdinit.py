#!/usr/bin/env python3
"""Disassemble the original CD init function (before patching) from the DW7 disc."""
import os
from capstone import Cs, CS_ARCH_MIPS, CS_MODE_MIPS32, CS_MODE_LITTLE_ENDIAN

def read_exe_from_disc(disc_path, exe_lba=24, sector_size=2352, user_offset=24, user_size=2048, exe_sectors=340):
    with open(disc_path, 'rb') as f:
        f.seek(exe_lba * sector_size)
        raw = f.read(exe_sectors * sector_size)
    exe_data = bytearray()
    for i in range(exe_sectors):
        sector = raw[i * sector_size:(i + 1) * sector_size]
        if len(sector) < user_offset + user_size:
            break
        exe_data += sector[user_offset:user_offset + user_size]
    return bytes(exe_data)

def disasm_range(exe_data, load_addr, start_ram, end_ram):
    code_offset = 0x800
    file_start = start_ram - load_addr + code_offset
    file_end = end_ram - load_addr + code_offset
    if file_start < 0 or file_end > len(exe_data):
        return "  (outside EXE)\n"
    code = exe_data[file_start:file_end]
    md = Cs(CS_ARCH_MIPS, CS_MODE_MIPS32 | CS_MODE_LITTLE_ENDIAN)
    lines = []
    for insn in md.disasm(code, start_ram):
        lines.append(f"  0x{insn.address:08X}: {insn.mnemonic:8s} {insn.op_str}")
    return '\n'.join(lines) + '\n'

base = r"C:\LuxAura\VoidWalkers_Project\DQLOSTTRANSLATION"

# Read the ORIGINAL DW7 EXE (unpatched)
dw7_disc = os.path.join(base, "DW7D1", "DW7D1.bin")
if not os.path.exists(dw7_disc):
    # Try alternate path
    dw7_disc = os.path.join(base, "DW7D1.bin")
    if not os.path.exists(dw7_disc):
        print(f"Cannot find DW7 disc at {dw7_disc}")
        exit(1)

load_addr = 0x80017F00
exe = read_exe_from_disc(dw7_disc)

# The cd_init patch is at offset 0x60FA4, which is RAM 0x80078EA4
# Show the original (unpatched) function
print("=== ORIGINAL DW7 CD init function (0x80078EA4 - 0x80078F40) ===")
print(disasm_range(exe, load_addr, 0x80078EA4, 0x80078F40))

# Also show more of the function
print("\n=== CD init function continued (0x80078F40 - 0x80079000) ===")
print(disasm_range(exe, load_addr, 0x80078F40, 0x80079000))

# Show the nop_timeout and nop_error areas in original
print("\n=== ORIGINAL nop_timeout area (0x80079394 - 0x80079410) ===")
print(disasm_range(exe, load_addr, 0x80079394, 0x80079410))

print("\n=== ORIGINAL nop_error area (0x800793E8 - 0x80079430) ===")
print(disasm_range(exe, load_addr, 0x800793E8, 0x80079430))

# Show the disc check function entry (the function that contains exit1/exit2/exit3)
print("\n=== Disc check function (0x80078F00 - 0x80079300) ===")
print(disasm_range(exe, load_addr, 0x80078F00, 0x80079300))
