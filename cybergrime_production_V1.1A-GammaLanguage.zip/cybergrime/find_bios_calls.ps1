# Search DQ4 EXE for BIOS call dispatch patterns
# The game calls BIOS via: addiu $t2, $zero, 0xA0/0xB0/0xC0 then jr $t2
# Or: lui $t2, 0x0000; addiu $t2, $t2, 0xA0; jr $t2
# Pattern: 0x240900A0 (addiu $t1, $zero, 0xA0) or 0x240A00A0 (addiu $t2, $zero, 0xA0)
$b = [System.IO.File]::ReadAllBytes('..\dq4_exe.bin')
$load = 0x80017F00

# Find BIOS dispatch sites: addiu $t1/$t2, $zero, 0xA0/0xB0/0xC0
$biosSites = @()
for ($i = 0x800; $i -lt $b.Length - 4; $i += 4) {
    $val = [BitConverter]::ToUInt32($b, $i)
    # addiu $t1, $zero, 0xA0 = 0x240900A0
    # addiu $t2, $zero, 0xA0 = 0x240A00A0
    # addiu $t1, $zero, 0xB0 = 0x240900B0
    # addiu $t2, $zero, 0xB0 = 0x240A00B0
    # addiu $t1, $zero, 0xC0 = 0x240900C0
    # addiu $t2, $zero, 0xC0 = 0x240A00C0
    if ($val -eq 0x240900A0 -or $val -eq 0x240A00A0 -or
        $val -eq 0x240900B0 -or $val -eq 0x240A00B0 -or
        $val -eq 0x240900C0 -or $val -eq 0x240A00C0) {
        $addr = $load + $i - 0x800
        # Look backwards for the function number setup: addiu $t1, $zero, fn
        # Actually $t1 = fn, $t2 = table. Let me check which register has the table
        $regNum = ($val -shr 16) -band 0x1F
        $reg = if ($regNum -eq 9) { "t1" } else { "t2" }
        # Look for jr $t2 or jr $t1 nearby (within 4 instructions)
        $jrFound = $false
        for ($j = 1; $j -le 6; $j++) {
            if ($i + $j * 4 -ge $b.Length) { break }
            $next = [BitConverter]::ToUInt32($b, $i + $j * 4)
            if (($next -shr 26) -eq 0x00 -and (($next -band 0x07C00000) -shr 21) -eq 0x08) {
                $jrFound = $true
                break
            }
        }
        $table = if (($val -band 0xFFFF) -eq 0xA0) { "A" } elseif (($val -band 0xFFFF) -eq 0xB0) { "B" } else { "C" }
        $biosSites += "0x$($addr.ToString('X8')) table=$table reg=$reg jr=$jrFound"
    }
}
Write-Host "BIOS dispatch sites: $($biosSites.Count)"
foreach ($s in $biosSites) { Write-Host "  $s" }

# Now find the actual function numbers called
# Before the table register setup, there should be: addiu $t1, $zero, fn
# Or: ori $t1, $zero, fn
Write-Host ""
Write-Host "=== BIOS function calls with fn numbers ==="
$biosCalls = @()
for ($i = 0x800; $i -lt $b.Length - 12; $i += 4) {
    $val1 = [BitConverter]::ToUInt32($b, $i)
    $val2 = [BitConverter]::ToUInt32($b, $i + 4)
    $val3 = [BitConverter]::ToUInt32($b, $i + 8)
    
    # Pattern: addiu $t1, $zero, fn (0x240900xx) then addiu $t2, $zero, 0xA0/0xB0/0xC0
    if (($val1 -band 0xFFFF0000) -eq 0x24090000) {
        $fn = $val1 -band 0xFF
        if ($val2 -eq 0x240A00A0 -or $val2 -eq 0x240A00B0 -or $val2 -eq 0x240A00C0) {
            $addr = $load + $i - 0x800
            $table = if (($val2 -band 0xFFFF) -eq 0xA0) { "A" } elseif (($val2 -band 0xFFFF) -eq 0xB0) { "B" } else { "C" }
            # Check if jr $t2 follows
            if (($val3 -shr 26) -eq 0x00 -and (($val3 -band 0x07C00000) -shr 21) -eq 0x0A) {
                $biosCalls += "$table`:0x$($fn.ToString('X2')) at 0x$($addr.ToString('X8'))"
            }
        }
    }
    # Also check pattern: addiu $t2, $zero, table then jr $t2 (fn already in $t1)
    if ($val2 -eq 0x240A00A0 -or $val2 -eq 0x240A00B0 -or $val2 -eq 0x240A00C0) {
        if (($val3 -shr 26) -eq 0x00 -and (($val3 -band 0x07C00000) -shr 21) -eq 0x0A) {
            # $t1 should have been set before $val1
            if (($val1 -band 0xFFFF0000) -eq 0x24090000) {
                # Already captured above
            } else {
                $addr = $load + $i - 0x800
                $table = if (($val2 -band 0xFFFF) -eq 0xA0) { "A" } elseif (($val2 -band 0xFFFF) -eq 0xB0) { "B" } else { "C" }
                # Try to find $t1 setup within 8 instructions before
                $fn = -1
                for ($k = 1; $k -le 8; $k++) {
                    if ($i - $k * 4 -lt 0x800) { break }
                    $prev = [BitConverter]::ToUInt32($b, $i - $k * 4)
                    if (($prev -band 0xFFFF0000) -eq 0x24090000) {
                        $fn = $prev -band 0xFF
                        break
                    }
                }
                if ($fn -ge 0) {
                    $biosCalls += "$table`:0x$($fn.ToString('X2')) at 0x$($addr.ToString('X8')) (fn from -$k)"
                }
            }
        }
    }
}
Write-Host "Total BIOS calls with fn: $($biosCalls.Count)"
# Show unique function numbers
$unique = $biosCalls | ForEach-Object { ($_ -split ' ')[0] } | Sort-Object -Unique
Write-Host "Unique BIOS functions called:"
foreach ($u in $unique) { Write-Host "  $u" }
Write-Host ""
Write-Host "All BIOS call sites:"
foreach ($c in $biosCalls) { Write-Host "  $c" }
