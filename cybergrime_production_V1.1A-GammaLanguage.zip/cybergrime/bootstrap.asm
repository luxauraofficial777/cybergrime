# Custom bootstrap routine for Frankenstein ROMs.
# Injects into a code cave, sets the CD status flags that DW7's boot
# sequence waits on, then jumps to the game's original main entry point.
#
# Usage:
#   python mips_asm.py bootstrap.asm --base 0x800D9E80 -o bootstrap.bin --json bootstrap_inject.json --cond at_pc --trigger 0x8008E284

    .set noreorder

    # CD status / init flags live in the DW7 scratch region
    lui   $t0, 0x800B

    # 0x800B9164 = 2  (CD status: ready / mode)
    ori   $t1, $zero, 2
    sb    $t1, 0x9164($t0)

    # 0x800B91CC = 1  (CD init done)
    ori   $t1, $zero, 1
    sb    $t1, 0x91CC($t0)

    # 0x800B91CE = 1  (CD ready flag)
    sb    $t1, 0x91CE($t0)

    # Patch the HBD filename pointer so the loader sees the merged file.
    # 0x80026D00 should already point at "hbd1qs1d.w71"; just ensure it is non-zero.
    # (If a real filename string is needed it is placed by the builder.)

    # Jump to the original game main entry point.
    # The PS-X EXE header sets initial PC = 0x8008E284.
    lui   $t2, 0x8008
    ori   $t2, $t2, 0xE284
    jr    $t2
    nop
