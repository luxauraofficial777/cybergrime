@echo off
echo === Golden Mile v108c Boot Test ===
echo Using SCPH-1001 BIOS (NOT FRANKENSTEIN.BIOS)
echo.
"C:\Users\XFO777\AppData\Local\hermes\hermes-agent\venv\Scripts\python.exe" "c:\LuxAura\VoidWalkers_Project\DQLOSTTRANSLATION\cybergrime\boot_test_v108c.py"
echo.
echo === Done. Check log: build_staging\v108c_boot.log ===
pause
