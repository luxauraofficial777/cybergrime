#!/usr/bin/env python3
"""Run v34 in CyberGrime smoke test (50M instructions, no breakpoints)."""
import json, os, subprocess

DISC = r'c:\LuxAura\VoidWalkers_Project\DQLOSTTRANSLATION\dq4_frankenstein_v34.bin'
RUNNER = r'c:\LuxAura\VoidWalkers_Project\DQLOSTTRANSLATION\cybergrime\psx_agent_runner.exe'
TELEMETRY = r'c:\LuxAura\VoidWalkers_Project\DQLOSTTRANSLATION\cybergrime\telemetry\telemetry_v34_smoke.json'
TRIAGE = r'c:\LuxAura\VoidWalkers_Project\DQLOSTTRANSLATION\cybergrime\emulator_triage_v34_smoke.log'

cmd = [RUNNER, DISC, 'v34_smoke', '50000000', TELEMETRY, '0', '--triage', TRIAGE, '--verbose']
print(f"Running CyberGrime v34 smoke test: 50M instructions")
try:
    proc = subprocess.run(cmd, capture_output=True, text=True, timeout=300)
    print(f"Exit code: {proc.returncode}")
except subprocess.TimeoutExpired as e:
    print(f"TIMEOUT")

if os.path.exists(TELEMETRY):
    with open(TELEMETRY, 'r', encoding='utf-8', errors='replace') as f:
        tel = json.load(f)
    print(f"\n=== Telemetry ===")
    print(f"Status: {tel.get('Pass_Status', 'UNKNOWN')}")
    print(f"Instructions: {tel.get('Instructions_Executed', 0)}")
    print(f"VBlanks: {tel.get('VBlank_Count', 0)}")
    print(f"Last PC: 0x{tel.get('Last_Known_PC', 0):08X}")
    print(f"Crashed: {tel.get('Crashed', False)}")
    print(f"Frozen: {tel.get('Frozen', False)}")
    if tel.get('Crashed'):
        print(f"Crash reason: {tel.get('Crash_Reason', '')}")
    regs = tel.get('Register_Dump', {})
    if regs:
        print(f"\nRegisters:")
        for k in ['PC', 'sp', 'gp', 'ra', 'v0', 'v1', 'a0', 'a1']:
            if k in regs:
                print(f"  {k}: {regs[k]}")
    tty = tel.get('TTY_Tail', '')
    print(f"\nTTY Tail (last 1500 chars):")
    print(tty[-1500:])
    hw = tel.get('HW_State', {})
    print(f"\nHW State:")
    for k, v in hw.items():
        print(f"  {k}: {v}")
else:
    print(f"No telemetry file found")
