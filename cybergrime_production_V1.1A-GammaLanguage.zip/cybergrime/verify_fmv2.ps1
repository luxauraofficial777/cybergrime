$binPath = 'c:\LuxAura\VoidWalkers_Project\DQLOSTTRANSLATION\cybergrime\dq4_reverse_v97_fmv.bin'
$fs = [System.IO.File]::OpenRead($binPath)

# EXE is written starting at LBA 24 using write_raw_data
# write_raw_data writes USER_SIZE (2048) bytes per sector via iso.write_sector
# iso.write_sector writes to the data portion of the raw sector

# The EXE file offset 0x92936 is at:
# sector_index = 0x92936 / 2048 = 299 (integer division)
# offset_in_sector = 0x92936 % 2048
$exeOffset = 0x92936
$sectorIdx = [Math]::Floor($exeOffset / 2048)
$offsetInSector = $exeOffset % 2048
$discLBA = 24 + $sectorIdx

Write-Host "EXE offset 0x$($exeOffset.ToString('X')) -> sector idx $sectorIdx, offset $offsetInSector, disc LBA $discLBA"

# Now read from the BIN file
# IsoImage stores sectors as raw 2352-byte sectors
# The data portion starts at offset 24 in a Mode 2 Form 1 sector
$binOffset = $discLBA * 2352 + 24 + $offsetInSector
Write-Host "BIN file offset: 0x$($binOffset.ToString('X'))"

$fs.Seek($binOffset, 'Begin') | Out-Null
$buf = New-Object byte[] 4
$fs.Read($buf, 0, 3) | Out-Null
Write-Host ("Bytes: {0:X2} {1:X2} {2:X2}" -f $buf[0], $buf[1], $buf[2])

if ($buf[0] -eq 0x23 -and $buf[1] -eq 0x31 -and $buf[2] -eq 0x15) {
    Write-Host "PATCH VERIFIED: BCD MSF is now 23:31:15 (DQ4 FMV location)"
} elseif ($buf[0] -eq 0x32 -and $buf[1] -eq 0x34 -and $buf[2] -eq 0x71) {
    Write-Host "NOT PATCHED: Still has DW7 BCD MSF 32:34:71"
} else {
    Write-Host "UNEXPECTED bytes"
}

$fs.Close()
