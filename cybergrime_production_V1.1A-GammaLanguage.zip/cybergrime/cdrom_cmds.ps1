$log = 'C:\LuxAura\VoidWalkers_Project\DuckStation\duckstation.log'
$lines = Get-Content $log
Write-Host "=== CDROM commands (Setloc/Setmode/ReadN/Pause/Play) from DQ4 native boot ==="
$lines | Where-Object { $_ -match 'Setloc|Setmode|ReadN|ReadS|Pause|Play|Demute|Init|Getstat|Getmode' } | ForEach-Object { Write-Output $_ }
