#!/usr/bin/env python3
"""
Blueprint Hook Example — scripted orchestration hook
Demonstrates how to hook into the emulation loop via Python
to implement custom test logic.

Usage:
    psx_agent_runner.exe disc.bin hook_test telemetry.json 600000 --inject examples/blueprint_hook.py
"""

import json
import sys
import time

def on_boot_complete(telemetry):
    """Called when the emulator reaches boot completion."""
    print(f"[HOOK] Boot complete: {telemetry.get('instruction_count', 0)} instructions")
    
    # Check if we reached the expected state
    vblank = telemetry.get("vblank_count", 0)
    if vblank < 10:
        print(f"[HOOK] WARNING: Only {vblank} vblanks — possible freeze")
        return False
    
    print(f"[HOOK] VBlank count OK: {vblank}")
    return True

def on_title_screen(telemetry):
    """Called when title screen is detected."""
    pc = telemetry.get("final_pc", 0)
    print(f"[HOOK] Title screen PC: 0x{pc:08X}")
    
    # Verify we're in the game's main loop
    if 0x800A0000 <= pc <= 0x800B0000:
        print("[HOOK] PC in expected range — game loop active")
        return True
    else:
        print(f"[HOOK] PC outside expected range")
        return False

def evaluate_test(telemetry_path):
    """Main evaluation function."""
    with open(telemetry_path, "r") as f:
        telemetry = json.load(f)
    
    status = telemetry.get("final_status", "UNKNOWN")
    print(f"[HOOK] Final status: {status}")
    
    if status == "CRASH":
        print(f"[HOOK] Crash reason: {telemetry.get('crash_reason', 'unknown')}")
        return False
    
    if status == "FREEZE":
        print("[HOOK] Emulation froze")
        return False
    
    # Run custom checks
    checks = [
        ("Boot complete", on_boot_complete(telemetry)),
        ("Title screen", on_title_screen(telemetry)),
    ]
    
    all_pass = True
    for name, result in checks:
        status = "PASS" if result else "FAIL"
        print(f"  [{status}] {name}")
        if not result:
            all_pass = False
    
    return all_pass

if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Usage: python blueprint_hook.py <telemetry.json>")
        sys.exit(1)
    
    passed = evaluate_test(sys.argv[1])
    sys.exit(0 if passed else 1)
