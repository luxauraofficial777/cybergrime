import struct, os

dq4_disc = r"c:\LuxAura\VoidWalkers_Project\DQLOSTTRANSLATION\Dragon Quest IV - Michibikareshi Mono Tachi (Japan).bin"
sector_size = 2352
data_offset = 24
user_size = 2048

with open(dq4_disc, 'rb') as f:
    # Read PVD at sector 16
    f.seek(16 * sector_size + data_offset)
    pvd = f.read(user_size)
    
    # PVD structure:
    # [0] type (1), [1-5] "CD001", [6] version, [7] unused
    # [8-39] system ID, [40-71] volume ID
    print(f"PVD type: {pvd[0]}")
    print(f"PVD ID: {pvd[1:6]}")
    print(f"Volume ID: {pvd[40:72].decode('ascii', errors='replace').strip()}")
    
    # Root directory record at offset 156 (34 bytes)
    # Actually in ISO 9660 PVD, root dir is at offset 156, not 158
    root_rec = pvd[156:156+34]
    print(f"\nRoot dir record (offset 156): len={root_rec[0]}")
    if root_rec[0] > 0 and root_rec[0] <= 34:
        root_lba = struct.unpack_from('<I', root_rec, 2)[0]
        root_size = struct.unpack_from('<I', root_rec, 10)[0]
        print(f"  LBA={root_lba}, size={root_size}")
        
        # Read root directory
        f.seek(root_lba * sector_size + data_offset)
        dir_sectors = max(1, (root_size + user_size - 1) // user_size)
        dir_data = f.read(root_size)
        
        print(f"\nRoot directory ({root_size} bytes):")
        pos = 0
        while pos < len(dir_data):
            rec_len = dir_data[pos]
            if rec_len == 0:
                break
            if pos + 33 <= len(dir_data):
                file_lba = struct.unpack_from('<I', dir_data, pos + 2)[0]
                file_size_val = struct.unpack_from('<I', dir_data, pos + 10)[0]
                flags = dir_data[pos + 25]
                name_len = dir_data[pos + 32]
                name = dir_data[pos + 33:pos + 33 + name_len]
                ftype = "DIR " if flags & 0x02 else "FILE"
                # Clean up name (remove version suffix ;1)
                name_str = name.decode('ascii', errors='replace').rstrip('\x00')
                if ';' in name_str:
                    name_str = name_str.split(';')[0]
                print(f"  {ftype} '{name_str}': LBA={file_lba}, size={file_size_val}")
            pos += rec_len
    else:
        print("  Invalid root dir record")
        # Try offset 158 too
        root_rec2 = pvd[158:158+34]
        print(f"\nRoot dir record (offset 158): len={root_rec2[0]}")
        if root_rec2[0] > 0 and root_rec2[0] <= 34:
            root_lba = struct.unpack_from('<I', root_rec2, 2)[0]
            root_size = struct.unpack_from('<I', root_rec2, 10)[0]
            print(f"  LBA={root_lba}, size={root_size}")
    
    # Also dump PVD bytes 150-200 for manual inspection
    print("\nPVD bytes 150-200:")
    for i in range(150, min(200, len(pvd))):
        if (i - 150) % 16 == 0:
            print(f"  [{i:3d}] ", end="")
        print(f"{pvd[i]:02X} ", end="")
        if (i - 150) % 16 == 15:
            print()
    print()
    
    # Read SYSTEM.CNF at sector 23
    f.seek(23 * sector_size + data_offset)
    cnf = f.read(user_size)
    # Find actual end
    cnf_text = cnf.decode('ascii', errors='replace')
    null_pos = cnf_text.find('\x00')
    if null_pos > 0:
        cnf_text = cnf_text[:null_pos]
    print(f"\nSYSTEM.CNF (sector 23):\n{cnf_text}")
    
    # Read DQ4 EXE header at sector 24
    f.seek(24 * sector_size + data_offset)
    exe_hdr = f.read(64)
    print(f"\nDQ4 EXE header (sector 24):")
    print(f"  Magic: {exe_hdr[:8]}")
    if exe_hdr[:4] == b'PS-X':
        load_addr = struct.unpack_from('<I', exe_hdr, 0x10)[0]
        text_size = struct.unpack_from('<I', exe_hdr, 0x1C)[0]
        pc0 = struct.unpack_from('<I', exe_hdr, 0x14)[0]
        print(f"  load_addr=0x{load_addr:08X}, text_size=0x{text_size:08X} ({text_size}), pc0=0x{pc0:08X}")
        # DQ4 EXE size on disc from directory
        # Let's check: how many sectors until HBD at 362?
        exe_sectors = 362 - 24  # 338 sectors
        exe_max_size = exe_sectors * user_size
        print(f"  Max EXE space (24→362): {exe_max_size} bytes ({exe_sectors} sectors)")
        print(f"  DQ4 EXE actual text_size: {text_size} bytes ({text_size // user_size} sectors)")
