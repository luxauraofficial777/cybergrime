# CyberGrime Testing Guide

## Writing Tests

Tests are defined in `test_definitions.json`:

```json
{
  "tests": [
    {
      "id": "boot_smoke",
      "name": "Boot Smoke Test",
      "type": "emulator",
      "disc": "../dq4_frankenstein_v21.bin",
      "max_instrs": 5000000,
      "wallclock_ms": 60000,
      "expect": {
        "no_crash": true,
        "min_vblank": 10,
        "thread_executes": true
      },
      "tags": ["smoke", "boot"]
    }
  ],
  "profiles": [
    {
      "name": "quick_smoke",
      "tests": ["boot_smoke"]
    }
  ]
}
```

### Test Types

- **emulator** — Runs `psx_agent_runner.exe` with the specified disc
- **python** — Runs a Python script (exit code 0 = pass)
- **unit** — Component unit test (placeholder, no harness yet)

### Expect Criteria

| Criterion | Description |
|---|---|
| `no_crash` | Final status must not be CRASH |
| `no_freeze` | Final status must not be FREEZE |
| `min_vblank` | VBlank count must meet or exceed value |
| `thread_executes` | ChangeTh(1) must be called (thread started) |
| `cdrom_sectors_delivered` | Minimum CD-ROM sectors read |
| `pc_in_range` | Final PC must be within [low, high] range |

## Running Tests

```powershell
# Run all tests
python regression_runner.py

# Run a specific profile
python regression_runner.py quick_smoke

# Run full regression suite
python regression_runner.py full_regression
```

## Baselines

```powershell
# Save a known-good baseline
python baseline_manager.py save build_v21 telemetry_boot_smoke.json

# Compare a new run against baseline
python baseline_manager.py compare build_v21 telemetry_boot_smoke.json

# Detailed diff
python baseline_manager.py diff build_v21 telemetry_boot_smoke.json

# List all baselines
python baseline_manager.py list
```

### Baseline Comparison Tolerances

- Instruction count: 5% delta allowed
- VBlank count: 10% regression threshold
- BIOS call histogram: 30% per-call deviation threshold

## Results Database

All test results are stored in `test_results.db` (SQLite):

```sql
SELECT test_id, pass, fail_reason, instr_count, vblank_count
FROM test_results
ORDER BY run_timestamp DESC;
```

## Telemetry JSON Format

The emulator outputs a telemetry JSON file containing:

```json
{
  "final_status": "COMPLETE|CRASH|FREEZE|TIMEOUT",
  "instruction_count": 55000000,
  "vblank_count": 126,
  "final_pc": "0x80012345",
  "crash_reason": null,
  "duration_ms": 45000,
  "bios_calls": [
    {"table": "A", "function": 0, "ra": "0x800...", "a0": "0x...", ...}
  ],
  "vfs_logs": [
    {"path": "SLUS_012.06", "lba": 24, "size": 675840, "found": true}
  ]
}
```
