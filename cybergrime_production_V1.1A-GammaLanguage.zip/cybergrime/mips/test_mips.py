"""Quick sanity test for the MIPS assembler/disassembler."""

import struct
from mips import assemble, disassemble, disassemble_word


def test_round_trip():
    text = """
boot:
    lui   $t0, 0x800B
    ori   $t1, $zero, 2
    sb    $t1, 0x9164($t0)
    li    $a0, 0x12345678
    jal   some_func
    nop
    j     boot
some_func:
    jr    $ra
    nop
"""
    words, labels = assemble(text)
    print("Labels:", labels)
    print("Words:", [f"{w:08X}" for w in words])

    data = b"".join(struct.pack("<I", w) for w in words)
    for addr, txt in disassemble(data, 0):
        print(f"0x{addr:08X}: {txt}")

    # Spot-check the lui encoding
    assert words[0] == 0x3C08800B, f"lui encoding wrong: {words[0]:08X}"
    print("Round-trip test passed.")


if __name__ == "__main__":
    test_round_trip()
