#!/usr/bin/env python3
"""Compare DW7 disc EXE, clean EXE file, and Frankenstein Phase C EXE."""
import struct
import os

def read_sector(disc, lba):
    return disc[lba * 2352 + 24: lba * 2352 + 24 + 2048]

def read_exe_from_disc(disc_path, exe_lba, exe_size):
    with open(disc_path, 'rb') as f:
        disc = f.read()
    exe = bytearray()
    sectors = (exe_size + 2047) // 2048
    for i in range(sectors):
        exe.extend(read_sector(disc, exe_lba + i))
    return bytes(exe[:exe_size])

# Read DW7 EXE from disc
DW7_DISC = r'c:\LuxAura\VoidWalkers_Project\DQLOSTTRANSLATION\DW7D1\DW7D1.bin'
dw7_exe = read_exe_from_disc(DW7_DISC, 24, 675840)

# Read Frankenstein EXE from disc
DISC = r'c:\LuxAura\VoidWalkers_Project\DQLOSTTRANSLATION\dq4_phaseC_build1.bin'
frank_exe = read_exe_from_disc(DISC, 24, 960948)

# Compare headers
print("=== EXE HEADER COMPARISON ===")
for label, exe in [("DW7", dw7_exe), ("FRANK", frank_exe)]:
    magic = exe[:8]
    pc0 = struct.unpack_from('<I', exe, 0x10)[0]
    load = struct.unpack_from('<I', exe, 0x18)[0]
    text = struct.unpack_from('<I', exe, 0x1C)[0]
    print(f"  {label}: magic={magic}, PC0=0x{pc0:08X}, load=0x{load:08X}, text=0x{text:08X} ({text})")

# Compare words
diff_count = 0
first_diffs = []
min_size = min(len(dw7_exe), len(frank_exe))
for i in range(0x800, min_size, 4):
    dw = struct.unpack_from('<I', dw7_exe, i)[0] if i + 4 <= len(dw7_exe) else 0
    fw = struct.unpack_from('<I', frank_exe, i)[0]
    if dw != fw:
        diff_count += 1
        if len(first_diffs) < 30:
            ram = 0x80017F00 + i - 0x800
            first_diffs.append((i, ram, dw, fw))

print(f"\n=== DIFFERENCES (first {min_size} bytes) ===")
print(f"Total different words: {diff_count} out of {(min_size - 0x800) // 4}")
print(f"\nFirst 30 differences:")
for off, ram, dw, fw in first_diffs:
    print(f"  file=0x{off:X} ram=0x{ram:08X}: DW7=0x{dw:08X} FRANK=0x{fw:08X}")

# Check the clean EXE file
clean_path = r'c:\LuxAura\VoidWalkers_Project\DQLOSTTRANSLATION\translation\SLUSP012.06_clean.bin'
if os.path.exists(clean_path):
    with open(clean_path, 'rb') as f:
        clean = f.read()
    print(f"\n=== CLEAN EXE FILE ===")
    print(f"  Path: {clean_path}")
    print(f"  Size: {len(clean)} bytes")
    print(f"  Magic: {clean[:8]}")
    print(f"  PC0: 0x{struct.unpack_from('<I', clean, 0x10)[0]:08X}")
    print(f"  Load: 0x{struct.unpack_from('<I', clean, 0x18)[0]:08X}")
    print(f"  Text: 0x{struct.unpack_from('<I', clean, 0x1C)[0]:08X}")
    
    # Compare clean vs DW7 disc
    clean_vs_dw7_diffs = 0
    for i in range(0x800, min(len(clean), len(dw7_exe)), 4):
        cw = struct.unpack_from('<I', clean, i)[0]
        dw = struct.unpack_from('<I', dw7_exe, i)[0]
        if cw != dw:
            clean_vs_dw7_diffs += 1
    print(f"  Clean vs DW7 disc diffs: {clean_vs_dw7_diffs} words")
    
    # Compare clean vs Frank
    clean_vs_frank_diffs = 0
    for i in range(0x800, min(len(clean), len(frank_exe)), 4):
        cw = struct.unpack_from('<I', clean, i)[0]
        fw = struct.unpack_from('<I', frank_exe, i)[0]
        if cw != fw:
            clean_vs_frank_diffs += 1
    print(f"  Clean vs Frank diffs: {clean_vs_frank_diffs} words")
else:
    print(f"\n  SLUSP012.06_clean.bin NOT FOUND")
    trans_dir = r'c:\LuxAura\VoidWalkers_Project\DQLOSTTRANSLATION\translation'
    if os.path.isdir(trans_dir):
        for f in os.listdir(trans_dir):
            if 'SLUS' in f or 'slus' in f.lower():
                full = os.path.join(trans_dir, f)
                print(f"  Found: {f} ({os.path.getsize(full)} bytes)")
    else:
        print(f"  translation dir not found: {trans_dir}")
