#pragma once
#include <cstdint>
#include <cstring>
#include <vector>
#include <fstream>
#include <string>
#include <unordered_map>
#include <unordered_set>

// ===== Locked Constants =====
constexpr uint32_t EXE_LBA=24, HBD_LBA=500, SECTOR_SIZE=2352, USER_OFFSET=24, USER_SIZE=2048;
constexpr uint32_t DQ4_HBD_SIZE=319436800, DW7_HBD_SIZE=618563584, HYBRID_TREE_SIZE=1480;
constexpr uint32_t EXE_LOAD_ADDR=0x80017F00, ORIGINAL_PC0=0x8008E284;
constexpr uint32_t TREE_RAM_RELOC=0x80100000, TRAMPOLINE_RAM=0x801005C8, COPY_ROUTINE_RAM=0x800BCCF0;
constexpr uint32_t BSS_CLEAR_START=0x800BC668, BSS_CLEAR_END=0x800F4980;
constexpr uint32_t THREAD_ENTRY=0x800D9E80;
constexpr uint32_t ABS_TABLE_START=0x4184, REL_TABLE_START=0x511C, TABLE_ENTRY_SIZE=8, MAX_TABLE_ENTRIES=6000;
constexpr uint32_t CDROM_CMD_WRITE_OFF=0x80F64, CDROM_BRANCH_OFF=0x80F68;
constexpr uint32_t CDROM_BRANCH_TARGET=0x80098898, CDROM_AFTER_BRANCH_RAM=0x80098670;

// ===== CD-ROM stall bypass constants (HF-005) =====
// The DW7 engine polls CD-ROM status at two sites after BSS clear.
// When DQ4 HBD sector layout differs from DW7 expectations, the polling
// loops never see the expected status bits and stall indefinitely.
//
// Site 1: PC 0x80048004 — thread status polling loop
//   Reads base pointer from 0x800BC6CC (BSS), iterates 4 threads checking
//   status byte at offset 0x1382. If BSS not zeroed, garbage pointer causes
//   infinite loop. Fix: zero pre-tree BSS region (build-time).
//
// Site 2: PC 0x800986F0 — CD-ROM event flag timeout loop
//   Polls event flag counter at 0x800F2C8C. Loops up to 3.9M iterations
//   waiting for CD-ROM event. When HBD data at LBA 146621 is zeros,
//   CD-ROM read fails and event never fires.
//   Fix: preserve DW7 data at LBA 146621 (HBD truncation fix).
//   Bypass: patch the bne at 0x800986E0 to always branch (skip the wait).
constexpr uint32_t CDROM_POLL_RAM=0x800986F0;
constexpr uint32_t CDROM_POLL_BNE_OFF=0x807E0;       // EXE offset of bne at 0x800986E0
constexpr uint32_t CDROM_POLL_TIMEOUT_OFF=0x80804;   // EXE offset of beq at 0x8009870C

// ===== P3: CD-ROM command interception constants =====
// The DW7 CD-ROM dispatch function sets index=0 at 0x80098608, then writes params
// to 0x1F801802 in a loop, then writes the command byte to 0x1F801801 at 0x80098664.
// We intercept at 0x80098608 (BEFORE the param loop) so we can modify the param
// buffer in RAM ($s0) before it gets written to the CD-ROM FIFO.
// At the intercept point: $s1=command, $s0=param buffer, $v0=0x1F801800
//   1. If Setloc (0x02) and minute >= 0x32 (BCD), overwrite params with DQ4 FMV MSF
//   2. Otherwise pass through (no Setmode interception — let 0xA0 pass normally)
constexpr uint32_t CDROM_DISPATCH_RAM=0x80098608;     // Intercept BEFORE param write loop
constexpr uint32_t CDROM_DISPATCH_OFF=0x80F08;        // EXE file offset (0x80098608 - 0x80017F00 + 0x800)
constexpr uint32_t FMV_START_LBA=146621;              // First FMV sector in DW7 HBD (BCD minute 0x32)
constexpr uint32_t DQ4_FMV_LBA=105690;                // DQ4 intro FMV LBA (BCD MSF 23:31:15)
constexpr uint32_t CDROM_INTERCEPT_TRAMP_RAM=0x80101100; // Trampoline location (after HBD type trampoline)
constexpr uint32_t CDROM_REG_BASE=0x1F801800;         // CD-ROM register base
constexpr uint32_t CDROM_REG_CMD=0x03;                // Command register offset (index 0)
constexpr uint32_t CDROM_REG_PARAM=0x02;              // Parameter register offset (index 0)

// ===== Malloc clamp (P1) =====
// Descriptor publish at 0x8007AD74: sw $a2, 8744($v1) writes descriptor base to 0x800F2228.
// $a2 comes from 0x800C9A40 (descriptor table offset+8), set by bump allocator starting
// from heap base 0x80190000. DQ4 HBD over-allocation pushes bump pointer past 0x80800000.
// Clamp trampoline at tramp_base+0x80 checks $a2 >= 0x80800000, clamps to 0x80100000.
constexpr uint32_t DESC_PUBLISH_RAM=0x8007AD74;       // sw $a2, 8744($v1) — descriptor base publish
constexpr uint32_t DESC_PUBLISH_OFF=0x63674;          // EXE file offset
constexpr uint32_t DESC_PUBLISH_ORIG=0xAC662228;      // Original instruction (sw $a2, 0x2228($v1))
constexpr uint32_t DESC_PUBLISH_NEXT=0x24632228;      // Next instruction (addiu $v1, $v1, 0x2228)
constexpr uint32_t DESC_PUBLISH_CONT_RAM=0x8007AD7C;  // Continue target after trampoline
constexpr uint32_t RAM_CEILING=0x80800000;            // 8MB RAM ceiling
constexpr uint32_t DESC_CLAMP_VALUE=0x80100000;       // Safe fallback descriptor base
constexpr uint32_t MALLOC_CLAMP_TRAMP_OFFSET=0x80;    // Offset from tramp_base for clamp trampoline

// ===== Pre-tree BSS zero region =====
constexpr uint32_t PRE_TREE_BSS_START=0x800BC668;
constexpr uint32_t PRE_TREE_BSS_END=0x800BC700;
constexpr uint32_t PRE_TREE_BSS_LEN=PRE_TREE_BSS_END-PRE_TREE_BSS_START;  // 152 bytes

// Thread-entry fix constants (from VECTOR_ANALYSIS_REPORT.md)
// BSS clear loop: lui $v0,0x800C; addiu $v0,0xC668; lui $v1,0x800F; addiu $v1,imm; sw $zero,0($v0)
// EXE file offsets (0x800 header INCLUDED — do NOT add +0x800):
//   0x76B84 = lui $v0, 0x800C    (0x3C02800C) — BSS start upper
//   0x76B88 = addiu $v0, 0xC668  (0x2442C668) — BSS start lower
//   0x76B8C = lui $v1, 0x800F    (0x3C03800F) — BSS end upper (MUST PATCH to 0x800C)
//   0x76B90 = addiu $v1, imm     (0x24634980) — BSS end lower (MUST PATCH to 0xCCC8)
//   0x76B94 = sw $zero, 0($v0)   (0xAC400000) — store zero
//
// CRITICAL: addiu uses SIGNED 16-bit immediate. 0xCCC8 = -13112.
// With lui 0x800F: v1 = 0x800F0000 - 13112 = 0x800ECCC8 (WRONG — includes thread entry)
// With lui 0x800C: v1 = 0x800C0000 - 13112 = 0x800BCCC8 (CORRECT — preserves thread entry)
constexpr uint32_t BSS_CLEAR_LUI_V1_OFF=0x76B8C;   // EXE offset of lui $v1 (BSS end upper)
constexpr uint32_t BSS_CLEAR_ADDIU_V1_OFF=0x76B90;  // EXE offset of addiu $v1 (BSS end lower)
constexpr uint16_t BSS_CLEAR_LUI_V1_ORIG=0x800F;    // Original lui immediate
constexpr uint16_t BSS_CLEAR_LUI_V1_NARROW=0x800C;  // Patched lui immediate
constexpr uint16_t BSS_CLEAR_ADDIU_V1_ORIG=0x4980;  // Original addiu immediate (positive)
constexpr uint16_t BSS_CLEAR_ADDIU_V1_NARROW=0xCCC8; // Patched addiu immediate (signed negative)
// Legacy compat (deprecated — use the two-instruction patch above)
constexpr uint32_t BSS_CLEAR_END_PATCH_OFF=0x76B90;  // FIXED: was 0x76B88 (wrong instruction)
constexpr uint16_t BSS_CLEAR_END_ORIG_IMM=0x4980;
constexpr uint16_t BSS_CLEAR_END_NARROW_IMM=0xCCC8;
constexpr uint32_t THREAD_ENTRY_SAFE_RAM=0x80101000;  // Safe location for thread entry copy (outside BSS)

// ===== BSS clear START patch constants =====
// To preserve the hybrid tree at 0x800BC700, we move BSS START past it.
// BSS start is controlled by lui $v0 + addiu $v0 at offsets 0x76B84/0x76B88.
// New BSS start = 0x800BCCC8 (past tree end):
//   lui $v0, 0x800C (unchanged) + addiu $v0, 0xCCC8 (signed -13112) = 0x800BCCC8
constexpr uint32_t BSS_CLEAR_LUI_V0_OFF=0x76B84;     // EXE offset of lui $v0 (BSS start upper)
constexpr uint32_t BSS_CLEAR_ADDIU_V0_OFF=0x76B88;   // EXE offset of addiu $v0 (BSS start lower)
constexpr uint16_t BSS_CLEAR_ADDIU_V0_ORIG=0xC668;   // Original addiu immediate
constexpr uint16_t BSS_CLEAR_ADDIU_V0_NEW=0xCCC8;    // Patched: BSS start -> 0x800BCCC8 (past tree)

// Thread-entry-preserving BSS END: narrow to 0x800D9E80 (just before thread entry)
// MIPS addiu sign-extends: 0x9E80 >= 0x8000 → treated as -0x6180
// lui $v1, 0x800E + addiu $v1, 0x9E80 = 0x800E0000 - 0x6180 = 0x800D9E80
constexpr uint16_t BSS_CLEAR_LUI_V1_THREADSAFE=0x800E;
constexpr uint16_t BSS_CLEAR_ADDIU_V1_THREADSAFE=0x9E80;

// ===== Additional build constants =====
constexpr uint32_t OLD_LUI_IMM=0x800F, OLD_ADDIU_IMM=0xF1C8;

// ===== Decompressor patch targets (from patch_targets.md) =====
// Target 4: Tree pointer — register variable mapping
//   Patches addiu at 0x8006F100 and 0x8006F148 to load tree base from
//   a runtime variable at 0x800BC6F8 instead of hardcoded immediate.
//   This allows per-block tree updates without code changes.
constexpr uint32_t DECOMP_TREE_PTR1_OFF=0x57200;      // File offset of addiu $v0 (site 1)
constexpr uint32_t DECOMP_TREE_PTR2_OFF=0x57248;      // File offset of addiu $v0 (site 2)
constexpr uint32_t DECOMP_TREE_PTR3_OFF=0x572A4;      // File offset of addiu $t2 (site 3, Target 5)
constexpr uint32_t TREE_PTR_VAR_RAM=0x800BC6F8;        // Runtime tree pointer variable (RAM)
constexpr uint32_t TREE_PTR_VAR_OFF=0xA4FF8;           // File offset of tree pointer variable (0x800BC6F8 - 0x80017F00 + 0x800)

// Target 5: Root ID +1 — DQ4 uses (value & 0x7FFF) + 1, DW7 uses value & 0x7FFF
//   Adds +2 to the tree base immediate at 0x8006F1A4, effectively adding +1
//   to the child node index (nodes are 2 bytes).
constexpr uint32_t DECOMP_ROOT_ID_OFF=0x572A4;         // File offset of addiu $t2

// Target 6: Offset_b mask removal — DW7 forces offset_b even with andi 0xFFFE
//   DQ4 requires odd offset_b values. Replace andi with nop.
constexpr uint32_t DECOMP_OFFSET_B_OFF=0x1AFB8;        // File offset of andi $v0,$v0,0xFFFE
constexpr uint32_t DECOMP_OFFSET_B_ORIG=0x3042FFFE;    // Original andi instruction
constexpr uint32_t DQ4_HBD_DISC_START=362;
constexpr uint32_t DQ4_HBD_SECTORS=DQ4_HBD_SIZE/USER_SIZE;   // 155975
constexpr uint32_t DQ4_HBD_END=DQ4_HBD_DISC_START+DQ4_HBD_SECTORS;  // 156337
constexpr uint32_t SEQ_TABLE_START=0xA39AA, SEQ_TABLE_END=0xA3A02;
constexpr uint32_t SEQ_TABLE_MIN=300, SEQ_TABLE_MAX=400;

// ===== Folder mapping entry (from folder_mapping.json) =====
struct FolderMapping{
    uint32_t dw7_sector;
    uint32_t dq4_sector;
};

// ===== Disc-check patch entry (variable-length byte patches) =====
struct DiscCheckPatch{
    uint32_t offset;        // EXE offset (without 0x800 header)
    uint32_t patch_len;     // Length of patch data
    const uint8_t* patch_data;
    const char* desc;
};

// ===== Build result struct =====
struct BuildResult{
    uint32_t lba_patches;
    uint32_t seq_patches;
    uint32_t abs_matched;
    uint32_t abs_delta;
    uint32_t rel_matched;
    uint32_t disc_patches;
    uint32_t tree_patches;
    uint32_t trampoline_patches;
    uint32_t exe_size;
    uint32_t new_pc0;
    uint32_t disc_size;
    uint32_t hbd_blocks_processed;
    uint32_t hbd_blocks_converted;
    uint32_t hbd_subblock_swaps;
    uint32_t hbd_lba_patches;
    int success;
};

// ===== MIPS Instruction Encoding (compile-time verified) =====
constexpr uint32_t MIPS_JAL(uint32_t t){return(0x03<<26)|((t>>2)&0x03FFFFFF);}
constexpr uint32_t MIPS_J(uint32_t t){return(0x02<<26)|((t>>2)&0x03FFFFFF);}
constexpr uint32_t MIPS_LUI(uint8_t rt,uint16_t imm){return(0x0F<<26)|(rt<<16)|imm;}
constexpr uint32_t MIPS_ADDIU(uint8_t rt,uint8_t rs,uint16_t imm){return(0x09<<26)|(rs<<21)|(rt<<16)|imm;}
constexpr uint32_t MIPS_LW(uint8_t rt,uint16_t off,uint8_t base){return(0x23<<26)|(base<<21)|(rt<<16)|off;}
constexpr uint32_t MIPS_SW(uint8_t rt,uint16_t off,uint8_t base){return(0x2B<<26)|(base<<21)|(rt<<16)|off;}
constexpr uint32_t MIPS_BNE(uint8_t rs,uint8_t rt,int16_t off){return(0x05<<26)|(rs<<21)|(rt<<16)|(uint16_t)off;}
constexpr uint32_t MIPS_BEQ(uint8_t rs,uint8_t rt,int16_t off){return(0x04<<26)|(rs<<21)|(rt<<16)|(uint16_t)off;}
constexpr uint32_t MIPS_SB(uint8_t rt,uint16_t off,uint8_t base){return(0x28<<26)|(base<<21)|(rt<<16)|off;}
constexpr uint32_t MIPS_NOP=0x00000000;
constexpr uint32_t MIPS_JR_RA=0x03E00008;

// ===== Structs (byte-exact to hardware) =====
struct HbdBlockHeader{
    uint32_t end_marker,block_id,hts,tree_end,text_end,unknown;
};
static_assert(sizeof(HbdBlockHeader)==24,"HBD block header layout");

// ===== HuffTree: Huffman tree parser + codec (DQ4/DW7 formats) =====
class HuffTree{
    struct Node{
        bool is_branch;
        uint16_t value;     // leaf: content value; branch: branch id
        int left,right;     // child indices, -1 for leaves
    };
    std::vector<Node> nodes;
    int root_idx;
    std::unordered_map<uint16_t,std::string> code_table;

    int parse_node(const uint8_t* tree,uint32_t tree_len,int branch_id,
                   uint32_t offset_b,std::unordered_set<int>& seen);
    void build_codes(int node_idx,const std::string& prefix);
public:
    HuffTree():root_idx(-1){}
    bool parse_dq4(const uint8_t* tree,uint32_t len);
    bool parse_dw7(const uint8_t* tree,uint32_t len);
    std::vector<uint16_t> decode(const uint8_t* text,uint32_t len) const;
    std::vector<uint8_t> encode(const std::vector<uint16_t>& leaves) const;
    bool valid() const{return root_idx>=0;}
};

// ===== IsoImage: ISO 9660 raw-sector I/O =====
class IsoImage{
    std::fstream file;
    uint32_t sector_sz, data_off;
public:
    bool open(const char* path);
    void close();
    int read_sector(uint32_t lba,void* buf2048);
    int write_sector(uint32_t lba,const void* buf2048);
    int read_range(uint32_t lba,uint32_t count,void* buf);
    uint32_t file_size() const;
    uint32_t sector_size() const{return sector_sz;}
};

// ===== Patch record for validation + revert =====
struct PatchRecord {
    uint32_t offset;           // EXE file offset (including 0x800 header)
    uint32_t original_value;   // Original 32-bit word before patch
    uint32_t patched_value;    // Value written by the patch
    uint32_t ram_addr;         // RAM address (load_addr + offset - 0x800)
    char patch_name[48];       // Human-readable patch name
    bool reverted;             // True if this patch was reverted
};

// ===== ExePatcher: type-safe EXE read/write/patch =====
class ExePatcher{
    std::vector<uint8_t> data;
    uint32_t load_addr, text_sz, pc0_val;
    uint32_t tramp_base = 0x80101000;  // HBD trampoline RAM (overridable for reverse build)
    std::vector<PatchRecord> patch_history;
    // Internal: record a 32-bit patch for later revert/validation
    void record_patch(uint32_t file_offset, uint32_t orig, uint32_t patched, const char* name);
    // Internal: record a 16-bit patch (stored as 32-bit with upper bits from original)
    void record_patch16(uint32_t file_offset, uint16_t orig, uint16_t patched, const char* name);
public:
    bool load(const uint8_t* buf,uint32_t size);
    uint32_t ram_to_offset(uint32_t ram)const;
    uint32_t read32(uint32_t ram)const;
    void write32(uint32_t ram,uint32_t val);
    uint16_t read16(uint32_t ram)const;
    void write16(uint32_t ram,uint16_t val);
    uint32_t patch_lba_references(uint32_t old_lba,uint32_t new_lba);
    uint32_t patch_sequential_sector_table(uint32_t old_lba,uint32_t new_lba);
    uint32_t patch_tree_references(uint32_t old_lui,uint16_t old_addiu,uint16_t new_lui,uint16_t new_addiu);
    uint32_t patch_disc_check(const uint32_t* offsets,const uint32_t* patches,uint32_t count);
    uint32_t patch_disc_check_variable(const DiscCheckPatch* patches,uint32_t count);
    void append_payload(const uint8_t* payload,uint32_t size);
    void append_reloc_payload(const uint8_t* tree,uint32_t tree_sz,uint32_t tree_target_ram,uint32_t orig_pc0);
    // Thread-entry fix: Option B — narrow BSS clear to preserve 0x800D9E80
    bool patch_bss_clear_narrow();
    // Thread-entry fix: Option A — extend copy routine with post-BSS thread injection
    void append_reloc_payload_with_thread_fix(const uint8_t* tree,uint32_t tree_sz,
        uint32_t tree_target_ram,uint32_t orig_pc0,
        const uint8_t* thread_entry_data,uint32_t thread_entry_sz);
    // Folder pointer remapping (ABS + REL tables, matched + delta)
    void remap_folder_pointers(const FolderMapping* mappings,uint32_t count,
        uint32_t lba_delta,uint32_t dq4_base_sector,
        uint32_t& abs_matched,uint32_t& abs_delta_count,
        uint32_t& rel_matched);
    // Compute tree address with sign-extension
    static void compute_tree_addr(uint32_t target_ram,uint16_t& lui,uint16_t& addiu);
    // HBD sub-block type trampoline: patch 0x800562E4 to JAL 0x80101000
    // and append trampoline code to EXE payload
    bool patch_hbd_type_trampoline();
    // CD-ROM stall bypass (HF-005): patch event-flag poll at 0x800986F0
    // to return success immediately instead of waiting for CD-ROM state
    bool patch_cdrom_stall_bypass();
    // FMV skip: patch Setmode to use normal speed (0x00) instead of
    // double-speed ADPCM (0xA0) to skip FMV playback
    bool patch_fmv_skip();  // DEPRECATED — use patch_fmv_stubs instead
    bool patch_fmv_stubs(); // FMV skip via function stubs (BAD-2 fix)
    // P3: CD-ROM command interception — inject MIPS trampoline at 0x80098898
    // to intercept Setloc (redirect FMV-range LBAs to safe sector) and
    // Setmode (change 0xA0 FMV mode to 0x00 normal mode)
    bool patch_cdrom_cmd_intercept();
    // P1: Malloc clamp — patch descriptor publish at 0x8007AD74 to jump to
    // trampoline that clamps $a2 to 0x80100000 if >= 0x80800000 (8MB ceiling)
    bool patch_malloc_clamp();
    // Zero pre-tree BSS region (0x800BC668-0x800BC700) to fix thread
    // status polling loop at PC 0x80048004
    void zero_pre_tree_bss();
    // Decompressor Target 4: Patch tree pointer loads at 0x8006F100 and
    // 0x8006F148 to load from runtime variable at 0x800BC6F8 instead of
    // hardcoded immediate. Stores tree address in the variable.
    bool patch_decomp_tree_pointer();
    // Decompressor Target 5: Add +2 to tree base immediate at 0x8006F1A4
    // to implement DQ4's root_id = (value & 0x7FFF) + 1 convention.
    bool patch_decomp_root_id_plus1();
    // Decompressor Target 6: Replace andi $v0,$v0,0xFFFE at 0x80032EB8
    // with nop to allow odd offset_b values (DQ4 requirement).
    bool patch_decomp_offset_b_mask();
    // Refresh pc0_val from data after external patch
    void refresh_pc0(){pc0_val=*(uint32_t*)(data.data()+0x10);}
    void update_text_size();
    void set_tramp_base(uint32_t ram){tramp_base=ram;}
    const uint8_t* raw()const{return data.data();}
    uint32_t size()const{return(uint32_t)data.size();}
    uint32_t pc0()const{return pc0_val;}
    uint32_t load_address()const{return load_addr;}

    // --- P2-4: Patch validation + revert ---

    // Verify CD-ROM event wait loop at 0x800986E0 is intact (not stall-bypassed)
    bool verify_cdrom_flow() const;

    // Full EXE integrity check after all patches
    // Checks: PC0, load addr, text size, CD-ROM event loop, no forbidden patches
    bool verify_integrity() const;

    // Revert a specific patch by name (restores original value)
    bool revert_patch(const char* name);

    // Revert all patches (restores EXE to original state)
    void revert_all_patches();

    // List all recorded patches
    void list_patches() const;

    // Get patch history (for external inspection / JSON telemetry)
    const std::vector<PatchRecord>& get_patch_history() const { return patch_history; }

    // Check if a specific patch was applied
    bool has_patch(const char* name) const;
};

// ===== FrankensteinBuilder: full v39 build pipeline in C++ =====
class FrankensteinBuilder{
public:
    // Run the complete v39 build. All paths are absolute.
    // Returns BuildResult with patch counts and success flag.
    static BuildResult build_v39(
        const char* dw7_disc_path,      // DW7D1/DW7D1.bin
        const char* dw7_exe_path,       // translation/SLUSP012.06
        const char* dq4_hbd_disc_path,  // dq4_heart_v17.bin
        const char* hybrid_tree_path,   // dw7_hybrid_tree.bin
        const char* folder_map_path,    // translation/folder_mapping.json
        const char* output_bin_path,    // output .bin
        const char* output_cue_path,    // output .cue
        const char* edcre_path,         // edcre.exe path (or nullptr to skip)
        int tree_mode = 3,              // 0=no tree, 1=tree@0x800F4980, 2=tree@0x80100000, 3=tree@0x800BC700+BSS narrow
        uint32_t build_flags = 0        // bit0=skip CD-ROM stall bypass (for DuckStation)
    );

    // Reverse Frankenstein (Option A): DQ4 disc as base, DW7 EXE swapped in.
    // DQ4 HBD at native sector 362, optionally re-encoded to DW7 format.
    static BuildResult build_reverse_option_a(
        const char* dq4_disc_path,      // DQ4 translated disc (base)
        const char* dw7_exe_path,       // DW7 US EXE (to patch + swap in)
        const char* hybrid_tree_path,   // dw7_hybrid_tree.bin
        const char* output_bin_path,    // output .bin
        const char* output_cue_path,    // output .cue
        const char* edcre_path,         // edcre.exe path (or nullptr to skip)
        uint32_t build_flags = 0        // bit 0: CD-ROM command intercept, bit 1: stall bypass, bit 2: HBD re-encoding
    );
};

// ===== HbdReencoder: HBD text block re-encoding =====
struct ParsedBlock{
    uint32_t offset,end,block_id,hts,tree_end,text_end,unk1;
    uint32_t tree_start,tree_middle,tree_nodes;
    uint32_t at_end,dp_count,total_size;
    std::vector<uint8_t> text_bytes,tree_bytes,dp_data;
    bool has_per_block_tree;
};

struct HbdProcessResult{
    uint32_t blocks_processed;
    uint32_t blocks_converted;
    uint32_t blocks_reencoded;
    uint32_t blocks_reencode_failed;
    uint32_t subblock_swaps;
    uint32_t lba_patches;
    uint32_t folders_parsed;
    uint32_t files_parsed;
    uint32_t errors;
    int success;
};

class HbdReencoder{
    std::vector<uint8_t> hbd;
    const uint8_t* hybrid_tree;
    uint32_t tree_sz;
public:
    bool load(const uint8_t* data,uint32_t size,const uint8_t* tree,uint32_t tree_sz);
    bool parse_block(uint32_t offset,ParsedBlock& out);
    int handle_zero_length_tree(uint32_t offset);
    std::vector<uint8_t> reencode_block(const ParsedBlock& parsed);
    HbdProcessResult process_hbd(uint32_t source_lba,uint32_t target_lba);
    bool validate_processed(uint32_t source_lba);
    const uint8_t* raw()const{return hbd.data();}
    uint32_t size()const{return(uint32_t)hbd.size();}
};

// ===== C API for ctypes =====
extern "C"{
    // IsoImage
    void* iso_open(const char* path);
    void  iso_close(void* iso);
    int   iso_read_sector(void* iso,uint32_t lba,void* buf);
    int   iso_write_sector(void* iso,uint32_t lba,const void* buf);
    uint32_t iso_file_size(void* iso);

    // ExePatcher
    void* exe_load(const uint8_t* buf,uint32_t size);
    void  exe_free(void* exe);
    uint32_t exe_read32(void* exe,uint32_t ram);
    void  exe_write32(void* exe,uint32_t ram,uint32_t val);
    uint32_t exe_patch_lba(void* exe,uint32_t old_lba,uint32_t new_lba);
    uint32_t exe_patch_seq_table(void* exe,uint32_t old_lba,uint32_t new_lba);
    uint32_t exe_patch_tree_refs(void* exe,uint16_t old_lui,uint16_t old_addiu,uint16_t new_lui,uint16_t new_addiu);
    uint32_t exe_patch_disc_check(void* exe,const uint32_t* offsets,const uint32_t* patches,uint32_t count);
    void  exe_append_reloc_payload(void* exe,const uint8_t* tree,uint32_t tree_sz,uint32_t tree_target_ram,uint32_t orig_pc0);
    int   exe_patch_bss_clear_narrow(void* exe);
    int   exe_patch_cdrom_stall_bypass(void* exe);
    int   exe_patch_fmv_skip(void* exe);
    int   exe_patch_fmv_stubs(void* exe);
    int   exe_patch_cdrom_cmd_intercept(void* exe);
    int   exe_patch_malloc_clamp(void* exe);
    void  exe_zero_pre_tree_bss(void* exe);
    int   exe_patch_decomp_tree_pointer(void* exe);
    int   exe_patch_decomp_root_id_plus1(void* exe);
    int   exe_patch_decomp_offset_b_mask(void* exe);
    void  exe_append_reloc_payload_with_thread_fix(void* exe,const uint8_t* tree,uint32_t tree_sz,
        uint32_t tree_target_ram,uint32_t orig_pc0,
        const uint8_t* thread_entry_data,uint32_t thread_entry_sz);
    const uint8_t* exe_raw(void* exe);
    uint32_t exe_size(void* exe);
    uint32_t exe_pc0(void* exe);

    // P2-4: Patch validation + revert
    int   exe_verify_cdrom_flow(void* exe);
    int   exe_verify_integrity(void* exe);
    int   exe_revert_patch(void* exe, const char* name);
    void  exe_revert_all_patches(void* exe);
    void  exe_list_patches(void* exe);
    int   exe_has_patch(void* exe, const char* name);
    uint32_t exe_patch_count(void* exe);

    // HbdReencoder
    void* hbd_load(const uint8_t* data,uint32_t size,const uint8_t* tree,uint32_t tree_sz);
    void  hbd_free(void* hbd);
    int   hbd_handle_zero_tree(void* hbd,uint32_t offset);
    const uint8_t* hbd_raw(void* hbd);
    uint32_t hbd_size(void* hbd);
    HbdProcessResult hbd_process(void* hbd,uint32_t source_lba,uint32_t target_lba);
    int   hbd_validate(void* hbd,uint32_t source_lba);

    // Utility: extend disc with valid MODE2 sectors
    int   extend_disc_mode2(const char* path,uint64_t new_size);

    // FrankensteinBuilder — full v39 build in C++
    BuildResult build_frankenstein_v39(
        const char* dw7_disc_path,
        const char* dw7_exe_path,
        const char* dq4_hbd_disc_path,
        const char* hybrid_tree_path,
        const char* folder_map_path,
        const char* output_bin_path,
        const char* output_cue_path,
        const char* edcre_path
    );
}
