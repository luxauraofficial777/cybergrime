#!/usr/bin/env python3
"""Trace the stall: disassemble the function at 0x80096788 and callers."""
import struct

def read_sector(disc, lba):
    return disc[lba * 2352 + 24: lba * 2352 + 24 + 2048]

def read_exe_from_disc(disc_path, exe_lba, exe_size):
    with open(disc_path, 'rb') as f:
        disc = f.read()
    exe = bytearray()
    sectors = (exe_size + 2047) // 2048
    for i in range(sectors):
        exe.extend(read_sector(disc, exe_lba + i))
    return bytes(exe[:exe_size])

DISC = r'c:\LuxAura\VoidWalkers_Project\DQLOSTTRANSLATION\dq4_phaseC_build1.bin'
exe = read_exe_from_disc(DISC, 24, 960948)

LOAD_ADDR = 0x80017F00
EXE_HEADER = 0x800

REG = ['zero','at','v0','v1','a0','a1','a2','a3','t0','t1','t2','t3','t4','t5','t6','t7','s0','s1','s2','s3','s4','s5','s6','s7','t8','t9','k0','k1','gp','sp','fp','ra']

def disasm(word, pc):
    op = (word >> 26) & 0x3f
    rs = (word >> 21) & 0x1f
    rt = (word >> 16) & 0x1f
    rd = (word >> 11) & 0x1f
    shamt = (word >> 6) & 0x1f
    funct = word & 0x3f
    imm = word & 0xffff
    simm = imm if imm < 0x8000 else imm - 0x10000
    target = (word & 0x3ffffff) << 2 | (pc & 0xf0000000)
    if word == 0: return 'nop'
    if op == 0:
        if funct == 0x20: return f'add {REG[rd]},{REG[rs]},{REG[rt]}'
        if funct == 0x21: return f'addu {REG[rd]},{REG[rs]},{REG[rt]}'
        if funct == 0x23: return f'subu {REG[rd]},{REG[rs]},{REG[rt]}'
        if funct == 0x24: return f'and {REG[rd]},{REG[rs]},{REG[rt]}'
        if funct == 0x25: return f'or {REG[rd]},{REG[rs]},{REG[rt]}'
        if funct == 0x26: return f'xor {REG[rd]},{REG[rs]},{REG[rt]}'
        if funct == 0x27: return f'nor {REG[rd]},{REG[rs]},{REG[rt]}'
        if funct == 0x08: return f'jr {REG[rs]}'
        if funct == 0x09: return f'jalr {REG[rd]},{REG[rs]}'
        if funct == 0x00: return f'sll {REG[rd]},{REG[rt]},{shamt}'
        if funct == 0x02: return f'srl {REG[rd]},{REG[rt]},{shamt}'
        if funct == 0x03: return f'sra {REG[rd]},{REG[rt]},{shamt}'
        if funct == 0x04: return f'sllv {REG[rd]},{REG[rt]},{REG[rs]}'
        if funct == 0x06: return f'srlv {REG[rd]},{REG[rt]},{REG[rs]}'
        if funct == 0x07: return f'srav {REG[rd]},{REG[rt]},{REG[rs]}'
        if funct == 0x2a: return f'slt {REG[rd]},{REG[rs]},{REG[rt]}'
        if funct == 0x2b: return f'sltu {REG[rd]},{REG[rs]},{REG[rt]}'
        if funct == 0x0c: return f'syscall'
        if funct == 0x10: return f'mfhi {REG[rd]}'
        if funct == 0x12: return f'mflo {REG[rd]}'
        if funct == 0x11: return f'mthi {REG[rd]}'
        if funct == 0x13: return f'mtlo {REG[rd]}'
        if funct == 0x18: return f'mult {REG[rs]},{REG[rt]}'
        if funct == 0x19: return f'multu {REG[rs]},{REG[rt]}'
        if funct == 0x1a: return f'div {REG[rs]},{REG[rt]}'
        if funct == 0x1b: return f'divu {REG[rs]},{REG[rt]}'
        return f'.special 0x{funct:02x}'
    if op == 0x01:
        if rt == 0: return f'bltz {REG[rs]},0x{pc + 4 + simm*4:08X}'
        if rt == 1: return f'bgez {REG[rs]},0x{pc + 4 + simm*4:08X}'
        return f'.regimm 0x{rt:02x}'
    if op == 0x02: return f'j 0x{target:08X}'
    if op == 0x03: return f'jal 0x{target:08X}'
    if op == 0x04: return f'beq {REG[rs]},{REG[rt]},0x{pc + 4 + simm*4:08X}'
    if op == 0x05: return f'bne {REG[rs]},{REG[rt]},0x{pc + 4 + simm*4:08X}'
    if op == 0x06: return f'blez {REG[rs]},0x{pc + 4 + simm*4:08X}'
    if op == 0x07: return f'bgtz {REG[rs]},0x{pc + 4 + simm*4:08X}'
    if op == 0x08: return f'addi {REG[rt]},{REG[rs]},{simm}'
    if op == 0x09: return f'addiu {REG[rt]},{REG[rs]},{simm}'
    if op == 0x0a: return f'slti {REG[rt]},{REG[rs]},{simm}'
    if op == 0x0b: return f'sltiu {REG[rt]},{REG[rs]},{simm}'
    if op == 0x0c: return f'andi {REG[rt]},{REG[rs]},0x{imm:04X}'
    if op == 0x0d: return f'ori {REG[rt]},{REG[rs]},0x{imm:04X}'
    if op == 0x0e: return f'xori {REG[rt]},{REG[rs]},0x{imm:04X}'
    if op == 0x0f: return f'lui {REG[rt]},0x{imm:04X}'
    if op == 0x20: return f'lb {REG[rt]},{simm}({REG[rs]})'
    if op == 0x21: return f'lh {REG[rt]},{simm}({REG[rs]})'
    if op == 0x23: return f'lw {REG[rt]},{simm}({REG[rs]})'
    if op == 0x24: return f'lbu {REG[rt]},{simm}({REG[rs]})'
    if op == 0x25: return f'lhu {REG[rt]},{simm}({REG[rs]})'
    if op == 0x28: return f'sb {REG[rt]},{simm}({REG[rs]})'
    if op == 0x29: return f'sh {REG[rt]},{simm}({REG[rs]})'
    if op == 0x2b: return f'sw {REG[rt]},{simm}({REG[rs]})'
    if op == 0x30: return f'lwc0 {REG[rt]},{simm}({REG[rs]})'
    if op == 0x38: return f'swc0 {REG[rt]},{simm}({REG[rs]})'
    if op == 0x3a: return f'swc2 {REG[rt]},{simm}({REG[rs]})'
    return f'.unk 0x{word:08X}'

def ram_to_file(ram):
    return ram - LOAD_ADDR + EXE_HEADER

def disasm_range(exe, start_ram, end_ram, label=""):
    print(f"\n=== {label}: 0x{start_ram:08X} - 0x{end_ram:08X} ===")
    for ram in range(start_ram, end_ram, 4):
        off = ram_to_file(ram)
        if 0 <= off < len(exe) - 4:
            word = struct.unpack_from('<I', exe, off)[0]
            d = disasm(word, ram)
            print(f"  0x{ram:08X}: 0x{word:08X}  {d}")

# Disassemble the full function containing the stall point
# Look backward from 0x800967E0 for function start (addiu sp,sp,-X)
disasm_range(exe, 0x80096760, 0x80096800, "STALL FUNCTION (0x80096788 loop)")

# Look at what calls this function - search for JAL to 0x80096788 region
# The function likely starts at 0x80096760 or earlier
# Let's find the function start by looking for addiu sp,sp,-X
print("\n=== SEARCHING FOR FUNCTION START ===")
for ram in range(0x80096700, 0x800967E0, 4):
    off = ram_to_file(ram)
    if off < len(exe) - 4:
        word = struct.unpack_from('<I', exe, off)[0]
        op = (word >> 26) & 0x3f
        if op == 0x09:  # addiu
            rt = (word >> 16) & 0x1f
            simm = word & 0xffff
            if simm >= 0x8000: simm -= 0x10000
            if rt == 29 and simm < 0:  # addiu sp,sp,-X
                print(f"  Function start at 0x{ram:08X}: {disasm(word, ram)}")

# Search for JAL to addresses in 0x800967xx range
print("\n=== JAL CALLERS TO 0x800967xx ===")
for off in range(0x800, len(exe) - 4, 4):
    word = struct.unpack_from('<I', exe, off)[0]
    op = (word >> 26) & 0x3f
    if op == 0x03:  # JAL
        ram = LOAD_ADDR + off - EXE_HEADER
        target = (word & 0x3ffffff) << 2 | (ram & 0xf0000000)
        if 0x80096700 <= target <= 0x80096800:
            print(f"  0x{ram:08X}: jal 0x{target:08X}")

# Also check what's at PC0 (0x8008E284) - the entry point
disasm_range(exe, 0x8008E284, 0x8008E320, "PC0 ENTRY POINT")

# Check the BSS clear code
disasm_range(exe, 0x8008E284, 0x8008E2C0, "BSS CLEAR (near PC0)")

# Check what variable is at 0x800B63D8 (the loop counter)
print("\n=== VARIABLE AT 0x800B63D8 ===")
print(f"  This is in BSS region (0x800BCCC8 - 0x800E9E80)")
print(f"  Address 0x800B63D8 is BEFORE BSS start (0x800BCCC8)")
print(f"  It's in the data region - initialized by EXE load")
# Check what's at this offset in the EXE
var_file = 0x800B63D8 - LOAD_ADDR + EXE_HEADER
if var_file < len(exe):
    val = struct.unpack_from('<I', exe, var_file)[0]
    print(f"  EXE file offset 0x{var_file:X}: 0x{val:08X}")
else:
    print(f"  File offset 0x{var_file:X} is beyond EXE size ({len(exe)})")
