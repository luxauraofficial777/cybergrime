#pragma once

// ============================================================================
// PSX GTE (Geometry Transformation Engine) — MIT-licensed reference logic
// adapted from pctation (https://github.com/pcstation/pctation). Replaced
// glm/gsl dependencies with plain C++ structs to keep CyberGrime dependency-free.
// ============================================================================

#include <cstdint>
#include <cstdlib>
#include <cstring>
#include <algorithm>
#include <array>

using s8 = int8_t;
using s16 = int16_t;
using s32 = int32_t;
using s64 = int64_t;
using u8 = uint8_t;
using u16 = uint16_t;
using u32 = uint32_t;
using u64 = uint64_t;

struct Vec2_s16 { s16 x = 0, y = 0; };
struct Vec3_s16 { s16 x = 0, y = 0, z = 0; };
struct Col4_u8  { u8 r = 0, g = 0, b = 0, a = 0; };
struct Col3_s32 { s32 r = 0, g = 0, b = 0; };
struct Vec2_s32 { s32 x = 0, y = 0; };
struct Vec3_s32 {
    s32 x = 0, y = 0, z = 0;
    Vec3_s32() = default;
    Vec3_s32(s32 x_, s32 y_, s32 z_) : x(x_), y(y_), z(z_) {}
    Vec3_s32(const Col3_s32& c) : x(c.r), y(c.g), z(c.b) {}
};
struct Vec3_s64 { s64 x = 0, y = 0, z = 0; };
struct Mat3x3_s16 { s16 m[3][3] = {}; };

inline Col4_u8 col4_from_word(u32 val) {
    Col4_u8 out;
    out.r = (u8)(val);
    out.g = (u8)(val >> 8);
    out.b = (u8)(val >> 16);
    out.a = (u8)(val >> 24);
    return out;
}

inline u32 col4_to_word(const Col4_u8& c) {
    return (u32)c.r | ((u32)c.g << 8) | ((u32)c.b << 16) | ((u32)c.a << 24);
}

inline s32 gte_clamp(s32 val, s32 min, s32 max) {
    if (val > max) return max;
    if (val < min) return min;
    return val;
}

inline s32 sign_extend_16(s32 v) { return (s32)((s16)v); }

inline u32 leading_zeroes_u32(s32 v) {
    u32 u = (u32)v;
    if (u == 0) return 32;
    u32 n = 0;
    if (u <= 0x0000FFFF) { n += 16; u <<= 16; }
    if (u <= 0x00FFFFFF) { n += 8;  u <<= 8; }
    if (u <= 0x0FFFFFFF) { n += 4;  u <<= 4; }
    if (u <= 0x3FFFFFFF) { n += 2;  u <<= 2; }
    if (u <= 0x7FFFFFFF) { n += 1; }
    return n;
}

class PSX_GTE {
public:
    PSX_GTE();

    void reset();

    // CPU interface
    u32 read_reg(u32 src_reg);
    void write_reg(u32 dest_reg, u32 val);
    void execute(u32 word); // full COP2 instruction word (lower 25 bits are the command)

private:
    // ------------------------------------------------------------------------
    // Flag register
    // ------------------------------------------------------------------------
    union FlagRegister {
        enum {
            IR0_SAT = 1 << 12,
            SY2_SAT = 1 << 13,
            SX2_SAT = 1 << 14,
            MAC0_OVF_NEG = 1 << 15,
            MAC0_OVF_POS = 1 << 16,
            DIVIDE_OVF = 1 << 17,
            SZ3_OTZ_SAT = 1 << 18,
            COLOR_B_SAT = 1 << 19,
            COLOR_G_SAT = 1 << 20,
            COLOR_R_SAT = 1 << 21,
            IR3_SAT = 1 << 22,
            IR2_SAT = 1 << 23,
            IR1_SAT = 1 << 24,
            MAC3_OVF_NEG = 1 << 25,
            MAC2_OVF_NEG = 1 << 26,
            MAC1_OVF_NEG = 1 << 27,
            MAC3_OVF_POS = 1 << 28,
            MAC2_OVF_POS = 1 << 29,
            MAC1_OVF_POS = 1 << 30,
            FLAG = 1 << 31
        };

        u32 word = 0;

        struct {
            u32 _pad : 12;
            u32 ir0_sat : 1;
            u32 sy2_sat : 1;
            u32 sx2_sat : 1;
            u32 mac0_ovf_neg : 1;
            u32 mac0_ovf_pos : 1;
            u32 div_ovf : 1;
            u32 sz3_otz_sat : 1;
            u32 col_b_sat : 1;
            u32 col_g_sat : 1;
            u32 col_r_sat : 1;
            u32 ir3_sat : 1;
            u32 ir2_sat : 1;
            u32 ir1_sat : 1;
            u32 mac3_ovf_neg : 1;
            u32 mac2_ovf_neg : 1;
            u32 mac1_ovf_neg : 1;
            u32 mac3_ovf_pos : 1;
            u32 mac2_ovf_pos : 1;
            u32 mac1_ovf_pos : 1;
            u32 flag : 1;
        };

        void reset() { word = 0; }
        u32 read() {
            flag = ((word & 0x7F87E000) != 0);
            word &= 0xFFFFF000;
            return word;
        }
    };

    // ------------------------------------------------------------------------
    // Command helpers
    // ------------------------------------------------------------------------
    void check_ovf_and_udf_31(s64 val, u32 ovf_bit, u32 udf_bit);
    void check_ovf_and_udf_43(s64 val, u32 ovf_bit, u32 udf_bit);
    void check_mac_ovf_and_udf_1(s64 val);
    void check_mac_ovf_and_udf_2(s64 val);
    void check_mac_ovf_and_udf_3(s64 val);
    s64 check_mac_ovf_and_extend_1(s64 val);
    s64 check_mac_ovf_and_extend_2(s64 val);
    s64 check_mac_ovf_and_extend_3(s64 val);

    void mul_vec_vec(Vec3_s16 v1, Vec3_s16 v2, Vec3_s16 tr = {});
    Vec3_s64 mul_mat_vec(Mat3x3_s16 mat, Vec3_s16 vec, Vec3_s32 tr, bool rtp);
    s64 mul_mat_vec_rtp(Mat3x3_s16 mat, Vec3_s16 vec, Vec3_s32 tr);

    void set_ir1(s32 val, bool lm);
    void set_ir2(s32 val, bool lm);
    void set_ir3(s32 val, bool lm);
    s64 set_mac1(s64 val);
    s64 set_mac2(s64 val);
    s64 set_mac3(s64 val);
    s64 set_mac0(s64 val);
    void set_mac_and_ir1(s64 val, bool lm);
    void set_mac_and_ir2(s64 val, bool lm);
    void set_mac_and_ir3(s64 val, bool lm);
    void set_otz(s64 val);

    void push_screen_xy(s32 x, s32 y);
    void push_screen_z(s32 z);
    void push_color(u32 r, u32 g, u32 b);
    void push_color();

    u32 recip(u16 divisor);
    u32 divide_unr(u32 lhs, u32 rhs);

    s16 rgbc_r() const { return (s16)(rgbc.r << 4); }
    s16 rgbc_g() const { return (s16)(rgbc.g << 4); }
    s16 rgbc_b() const { return (s16)(rgbc.b << 4); }
    Vec3_s16 ir_to_vec() const { return { ir[1], ir[2], ir[3] }; }
    Vec3_s16 ir0_to_vec() const { return { ir[0], ir[0], ir[0] }; }
    Vec3_s16 rgbc_to_vec() const { return { rgbc_r(), rgbc_g(), rgbc_b() }; }

    // ------------------------------------------------------------------------
    // Commands
    // ------------------------------------------------------------------------
    void cmd_rtps(u8 vec_idx = 0, bool set_mac0 = true);
    void cmd_nclip();
    void cmd_op();
    void cmd_dpcs(bool use_rgb0 = false);
    void cmd_intpl();
    void cmd_mvmva(u32 mul_mat_idx, u32 mul_vec_idx, u32 tr_vec_idx);
    void cmd_ncds(u8 vec_idx = 0);
    void cmd_cdp();
    void cmd_ncdt();
    void cmd_nccs(u8 vec_idx = 0);
    void cmd_cc();
    void cmd_ncs(u8 vec_idx = 0);
    void cmd_nct();
    void cmd_sqr();
    void cmd_dcpl();
    void cmd_dpct();
    void cmd_avsz3();
    void cmd_avsz4();
    void cmd_rtpt();
    void cmd_gpf();
    void cmd_gpl();
    void cmd_ncct();

    // ------------------------------------------------------------------------
    // Registers
    // ------------------------------------------------------------------------
    // Data Registers
    Vec3_s16 v[3];
    Col4_u8 rgbc;
    u16 avg_z;
    s16 ir[4];
    Vec2_s16 s_xy[4];
    u16 s_z[4];
    Col4_u8 rgb_fifo[3];
    u32 res;
    s32 mac[4];
    u16 rgb_conv;
    s32 lzcs;
    s32 lzcr;

    // Control Registers
    Mat3x3_s16 rot_mat;
    Vec3_s32 trans_vec;
    Mat3x3_s16 light_mat;
    Col3_s32 bg_col;
    Mat3x3_s16 light_col_src_mat;
    Col3_s32 far_color;
    Vec2_s32 screen_offset;
    u16 h;
    s16 dqa;
    s32 dqb;
    s16 zsf3;
    s16 zsf4;
    FlagRegister flag;

    bool m_sf = false;
    bool m_lm = false;
    std::array<u8, 257> UNR_TABLE;

    static constexpr u32 DIVIDE_OVERFLOW_VAL = 0x1FFFF;
};

// ---------------------------------------------------------------------------
// GTE Command decoder (packed into the lower 25 bits of a COP2 instruction)
// ---------------------------------------------------------------------------
struct GteCommand {
    enum Opcode {
        RTPS = 0x01,
        NCLIP = 0x06,
        OP = 0x0C,
        DPCS = 0x10,
        INTPL = 0x11,
        MVMVA = 0x12,
        NCDS = 0x13,
        CDP = 0x14,
        NCDT = 0x16,
        NCCS = 0x1B,
        CC = 0x1C,
        NCS = 0x1E,
        NCT = 0x20,
        SQR = 0x28,
        DCPL = 0x29,
        DPCT = 0x2A,
        AVSZ3 = 0x2D,
        AVSZ4 = 0x2E,
        RTPT = 0x30,
        GPF = 0x3D,
        GPL = 0x3E,
        NCCT = 0x3F,
    };

    explicit GteCommand(u32 word) : word(word & 0x1FFFFFF) {}

    u32 word;
    struct {
        u32 _opcode : 6;
        u32 : 4;
        u32 lm : 1;
        u32 : 2;
        u32 mvmva_trans : 2;
        u32 mvmva_mul_vec : 2;
        u32 mvmva_mul_mat : 2;
        u32 sf : 1;
        u32 op_fake : 5;
    };

    Opcode opcode() const { return static_cast<Opcode>(_opcode); }
};

// ---------------------------------------------------------------------------
// Implementation
// ---------------------------------------------------------------------------

inline PSX_GTE::PSX_GTE() {
    for (int i = 0; i < 257; i++) {
        int numer = 0x40000 / (i + 0x100) + 1;
        int val = numer / 2 - 257;
        UNR_TABLE[i] = (u8)(val > 0 ? val : 0);
    }
    reset();
}

inline void PSX_GTE::reset() {
    memset(v, 0, sizeof(v));
    memset(&rgbc, 0, sizeof(rgbc));
    avg_z = 0;
    memset(ir, 0, sizeof(ir));
    memset(s_xy, 0, sizeof(s_xy));
    memset(s_z, 0, sizeof(s_z));
    memset(rgb_fifo, 0, sizeof(rgb_fifo));
    res = 0;
    memset(mac, 0, sizeof(mac));
    rgb_conv = 0;
    lzcs = 0;
    lzcr = 0;
    memset(&rot_mat, 0, sizeof(rot_mat));
    memset(&trans_vec, 0, sizeof(trans_vec));
    memset(&light_mat, 0, sizeof(light_mat));
    memset(&bg_col, 0, sizeof(bg_col));
    memset(&light_col_src_mat, 0, sizeof(light_col_src_mat));
    memset(&far_color, 0, sizeof(far_color));
    memset(&screen_offset, 0, sizeof(screen_offset));
    h = 0;
    dqa = 0;
    dqb = 0;
    zsf3 = 0;
    zsf4 = 0;
    flag.reset();
    m_sf = false;
    m_lm = false;
}

inline u32 PSX_GTE::read_reg(u32 src_reg) {
    switch (src_reg) {
        case 0:  return ((u16)(u16)v[0].y << 16) | (u16)(u16)v[0].x;
        case 1:  return (u32)(s32)v[0].z;
        case 2:  return ((u16)(u16)v[1].y << 16) | (u16)(u16)v[1].x;
        case 3:  return (u32)(s32)v[1].z;
        case 4:  return ((u16)(u16)v[2].y << 16) | (u16)(u16)v[2].x;
        case 5:  return (u32)(s32)v[2].z;
        case 6:  return col4_to_word(rgbc);
        case 7:  return avg_z;
        case 8:  return (u32)(s32)ir[0];
        case 9:  return (u32)(s32)ir[1];
        case 10: return (u32)(s32)ir[2];
        case 11: return (u32)(s32)ir[3];
        case 12: return ((u16)(u16)s_xy[0].y << 16) | (u16)(u16)s_xy[0].x;
        case 13: return ((u16)(u16)s_xy[1].y << 16) | (u16)(u16)s_xy[1].x;
        case 14: // fallthrough
        case 15: return ((u16)(u16)s_xy[2].y << 16) | (u16)(u16)s_xy[2].x;
        case 16: return (u16)s_z[0];
        case 17: return (u16)s_z[1];
        case 18: return (u16)s_z[2];
        case 19: return (u16)s_z[3];
        case 20: return col4_to_word(rgb_fifo[0]);
        case 21: return col4_to_word(rgb_fifo[1]);
        case 22: return col4_to_word(rgb_fifo[2]);
        case 23: return res;
        case 24: return (u32)mac[0];
        case 25: return (u32)mac[1];
        case 26: return (u32)mac[2];
        case 27: return (u32)mac[3];
        case 28: // fallthrough
        case 29:
            rgb_conv = (u16)std::clamp((s32)(ir[1] / 0x80), 0, 0x1f);
            rgb_conv |= (u16)std::clamp((s32)(ir[2] / 0x80), 0, 0x1f) << 5;
            rgb_conv |= (u16)std::clamp((s32)(ir[3] / 0x80), 0, 0x1f) << 10;
            return rgb_conv;
        case 30: return (u32)lzcs;
        case 31: return (u32)lzcr;

        case 32: return ((u16)(u16)rot_mat.m[0][1] << 16) | (u16)(u16)rot_mat.m[0][0];
        case 33: return ((u16)(u16)rot_mat.m[1][0] << 16) | (u16)(u16)rot_mat.m[0][2];
        case 34: return ((u16)(u16)rot_mat.m[1][2] << 16) | (u16)(u16)rot_mat.m[1][1];
        case 35: return ((u16)(u16)rot_mat.m[2][1] << 16) | (u16)(u16)rot_mat.m[2][0];
        case 36: return (u32)(s32)rot_mat.m[2][2];
        case 37: return (u32)trans_vec.x;
        case 38: return (u32)trans_vec.y;
        case 39: return (u32)trans_vec.z;
        case 40: return ((u16)(u16)light_mat.m[0][1] << 16) | (u16)(u16)light_mat.m[0][0];
        case 41: return ((u16)(u16)light_mat.m[1][0] << 16) | (u16)(u16)light_mat.m[0][2];
        case 42: return ((u16)(u16)light_mat.m[1][2] << 16) | (u16)(u16)light_mat.m[1][1];
        case 43: return ((u16)(u16)light_mat.m[2][1] << 16) | (u16)(u16)light_mat.m[2][0];
        case 44: return (u32)(s32)light_mat.m[2][2];
        case 45: return (u32)bg_col.r;
        case 46: return (u32)bg_col.g;
        case 47: return (u32)bg_col.b;
        case 48: return ((u16)(u16)light_col_src_mat.m[0][1] << 16) | (u16)(u16)light_col_src_mat.m[0][0];
        case 49: return ((u16)(u16)light_col_src_mat.m[1][0] << 16) | (u16)(u16)light_col_src_mat.m[0][2];
        case 50: return ((u16)(u16)light_col_src_mat.m[1][2] << 16) | (u16)(u16)light_col_src_mat.m[1][1];
        case 51: return ((u16)(u16)light_col_src_mat.m[2][1] << 16) | (u16)(u16)light_col_src_mat.m[2][0];
        case 52: return (u32)(s32)light_col_src_mat.m[2][2];
        case 53: return (u32)far_color.r;
        case 54: return (u32)far_color.g;
        case 55: return (u32)far_color.b;
        case 56: return (u32)screen_offset.x;
        case 57: return (u32)screen_offset.y;
        case 58: return (u32)(s32)(s16)h;
        case 59: return (u32)(s32)dqa;
        case 60: return (u32)dqb;
        case 61: return (u32)(s32)(s16)zsf3;
        case 62: return (u32)(s32)(s16)zsf4;
        case 63: return flag.read();
    }
    return 0;
}

inline void PSX_GTE::write_reg(u32 dest_reg, u32 val) {
    switch (dest_reg) {
        case 0: v[0].x = (s16)val; v[0].y = (s16)(val >> 16); break;
        case 1: v[0].z = (s32)val; break;
        case 2: v[1].x = (s16)val; v[1].y = (s16)(val >> 16); break;
        case 3: v[1].z = (s32)val; break;
        case 4: v[2].x = (s16)val; v[2].y = (s16)(val >> 16); break;
        case 5: v[2].z = (s32)val; break;
        case 6: rgbc = col4_from_word(val); break;
        case 7: avg_z = (u16)val; break;
        case 8: ir[0] = (s16)val; break;
        case 9: ir[1] = (s16)val; break;
        case 10: ir[2] = (s16)val; break;
        case 11: ir[3] = (s16)val; break;
        case 12: s_xy[0].y = (s16)(val >> 16); s_xy[0].x = (s16)val; break;
        case 13: s_xy[1].y = (s16)(val >> 16); s_xy[1].x = (s16)val; break;
        case 14: s_xy[2].y = (s16)(val >> 16); s_xy[2].x = (s16)val; break;
        case 15:
            s_xy[0] = s_xy[1];
            s_xy[1] = s_xy[2];
            s_xy[2].y = (s16)(val >> 16);
            s_xy[2].x = (s16)val;
            break;
        case 16: s_z[0] = (u16)val; break;
        case 17: s_z[1] = (u16)val; break;
        case 18: s_z[2] = (u16)val; break;
        case 19: s_z[3] = (u16)val; break;
        case 20: rgb_fifo[0] = col4_from_word(val); break;
        case 21: rgb_fifo[1] = col4_from_word(val); break;
        case 22: rgb_fifo[2] = col4_from_word(val); break;
        case 23: res = val; break;
        case 24: mac[0] = (s32)val; break;
        case 25: mac[1] = (s32)val; break;
        case 26: mac[2] = (s32)val; break;
        case 27: mac[3] = (s32)val; break;
        case 28:
            rgb_conv = (u16)(val & 0x7FFF);
            ir[1] = (s16)((val & 0x1F) * 0x80);
            ir[2] = (s16)(((val >> 5) & 0x1F) * 0x80);
            ir[3] = (s16)(((val >> 10) & 0x1F) * 0x80);
            break;
        case 29: break;
        case 30:
            lzcs = (s32)val;
            lzcr = (s32)leading_zeroes_u32(lzcs);
            break;
        case 31: break;

        case 32: rot_mat.m[0][0] = (s16)val; rot_mat.m[0][1] = (s16)(val >> 16); break;
        case 33: rot_mat.m[0][2] = (s16)val; rot_mat.m[1][0] = (s16)(val >> 16); break;
        case 34: rot_mat.m[1][1] = (s16)val; rot_mat.m[1][2] = (s16)(val >> 16); break;
        case 35: rot_mat.m[2][0] = (s16)val; rot_mat.m[2][1] = (s16)(val >> 16); break;
        case 36: rot_mat.m[2][2] = (s16)val; break;
        case 37: trans_vec.x = (s32)val; break;
        case 38: trans_vec.y = (s32)val; break;
        case 39: trans_vec.z = (s32)val; break;
        case 40: light_mat.m[0][0] = (s16)val; light_mat.m[0][1] = (s16)(val >> 16); break;
        case 41: light_mat.m[0][2] = (s16)val; light_mat.m[1][0] = (s16)(val >> 16); break;
        case 42: light_mat.m[1][1] = (s16)val; light_mat.m[1][2] = (s16)(val >> 16); break;
        case 43: light_mat.m[2][0] = (s16)val; light_mat.m[2][1] = (s16)(val >> 16); break;
        case 44: light_mat.m[2][2] = (s16)val; break;
        case 45: bg_col.r = (s32)val; break;
        case 46: bg_col.g = (s32)val; break;
        case 47: bg_col.b = (s32)val; break;
        case 48: light_col_src_mat.m[0][0] = (s16)val; light_col_src_mat.m[0][1] = (s16)(val >> 16); break;
        case 49: light_col_src_mat.m[0][2] = (s16)val; light_col_src_mat.m[1][0] = (s16)(val >> 16); break;
        case 50: light_col_src_mat.m[1][1] = (s16)val; light_col_src_mat.m[1][2] = (s16)(val >> 16); break;
        case 51: light_col_src_mat.m[2][0] = (s16)val; light_col_src_mat.m[2][1] = (s16)(val >> 16); break;
        case 52: light_col_src_mat.m[2][2] = (s16)val; break;
        case 53: far_color.r = (s32)val; break;
        case 54: far_color.g = (s32)val; break;
        case 55: far_color.b = (s32)val; break;
        case 56: screen_offset.x = (s32)val; break;
        case 57: screen_offset.y = (s32)val; break;
        case 58: h = (u16)val; break;
        case 59: dqa = (s16)val; break;
        case 60: dqb = (s32)val; break;
        case 61: zsf3 = (s16)val; break;
        case 62: zsf4 = (s16)val; break;
        case 63: flag.word = val; break;
    }
}

// Overflow/underflow helpers
inline void PSX_GTE::check_ovf_and_udf_31(s64 val, u32 ovf_bit, u32 udf_bit) {
    if (val >= (1LL << 31)) flag.word |= ovf_bit;
    if (val < -(1LL << 31)) flag.word |= udf_bit;
}
inline void PSX_GTE::check_ovf_and_udf_43(s64 val, u32 ovf_bit, u32 udf_bit) {
    if (val >= (1LL << 43)) flag.word |= ovf_bit;
    if (val < -(1LL << 43)) flag.word |= udf_bit;
}
inline void PSX_GTE::check_mac_ovf_and_udf_1(s64 val) { check_ovf_and_udf_43(val, FlagRegister::MAC1_OVF_POS, FlagRegister::MAC1_OVF_NEG); }
inline void PSX_GTE::check_mac_ovf_and_udf_2(s64 val) { check_ovf_and_udf_43(val, FlagRegister::MAC2_OVF_POS, FlagRegister::MAC2_OVF_NEG); }
inline void PSX_GTE::check_mac_ovf_and_udf_3(s64 val) { check_ovf_and_udf_43(val, FlagRegister::MAC3_OVF_POS, FlagRegister::MAC3_OVF_NEG); }

inline s64 PSX_GTE::check_mac_ovf_and_extend_1(s64 val) { check_mac_ovf_and_udf_1(val); return (s64)((val << (64 - 44)) >> (64 - 44)); }
inline s64 PSX_GTE::check_mac_ovf_and_extend_2(s64 val) { check_mac_ovf_and_udf_2(val); return (s64)((val << (64 - 44)) >> (64 - 44)); }
inline s64 PSX_GTE::check_mac_ovf_and_extend_3(s64 val) { check_mac_ovf_and_udf_3(val); return (s64)((val << (64 - 44)) >> (64 - 44)); }

inline s64 PSX_GTE::set_mac0(s64 val) {
    check_ovf_and_udf_31(val, FlagRegister::MAC0_OVF_POS, FlagRegister::MAC0_OVF_NEG);
    mac[0] = (s32)val;
    return val;
}
inline s64 PSX_GTE::set_mac1(s64 val) {
    check_mac_ovf_and_udf_1(val);
    if (m_sf) val >>= 12;
    mac[1] = (s32)val;
    return val;
}
inline s64 PSX_GTE::set_mac2(s64 val) {
    check_mac_ovf_and_udf_2(val);
    if (m_sf) val >>= 12;
    mac[2] = (s32)val;
    return val;
}
inline s64 PSX_GTE::set_mac3(s64 val) {
    check_mac_ovf_and_udf_3(val);
    if (m_sf) val >>= 12;
    mac[3] = (s32)val;
    return val;
}

inline void PSX_GTE::set_ir1(s32 val, bool lm) { ir[1] = (s16)gte_clamp(val, lm ? 0 : -0x8000, 0x7FFF); if (ir[1] != val) flag.word |= FlagRegister::IR1_SAT; }
inline void PSX_GTE::set_ir2(s32 val, bool lm) { ir[2] = (s16)gte_clamp(val, lm ? 0 : -0x8000, 0x7FFF); if (ir[2] != val) flag.word |= FlagRegister::IR2_SAT; }
inline void PSX_GTE::set_ir3(s32 val, bool lm) { ir[3] = (s16)gte_clamp(val, lm ? 0 : -0x8000, 0x7FFF); if (ir[3] != val) flag.word |= FlagRegister::IR3_SAT; }

inline void PSX_GTE::set_mac_and_ir1(s64 val, bool lm) { set_ir1((s32)set_mac1(val), lm); }
inline void PSX_GTE::set_mac_and_ir2(s64 val, bool lm) { set_ir2((s32)set_mac2(val), lm); }
inline void PSX_GTE::set_mac_and_ir3(s64 val, bool lm) { set_ir3((s32)set_mac3(val), lm); }

inline void PSX_GTE::set_otz(s64 val) {
    s32 v32 = (s32)(val >> 12);
    if (v32 > 0xFFFF) { v32 = 0xFFFF; flag.word |= FlagRegister::SZ3_OTZ_SAT; }
    if (v32 < 0) { v32 = 0; flag.word |= FlagRegister::SZ3_OTZ_SAT; }
    avg_z = (u16)v32;
}

inline void PSX_GTE::mul_vec_vec(Vec3_s16 v1, Vec3_s16 v2, Vec3_s16 tr) {
    set_mac_and_ir1(((s64)tr.x << 12) + v1.x * v2.x, m_lm);
    set_mac_and_ir2(((s64)tr.y << 12) + v1.y * v2.y, m_lm);
    set_mac_and_ir3(((s64)tr.z << 12) + v1.z * v2.z, m_lm);
}

inline Vec3_s64 PSX_GTE::mul_mat_vec(Mat3x3_s16 mat, Vec3_s16 vec, Vec3_s32 tr, bool rtp) {
    Vec3_s64 product;
    product.x = check_mac_ovf_and_extend_1(
        check_mac_ovf_and_extend_1(
            check_mac_ovf_and_extend_1(((s64)tr.x << 12) + mat.m[0][0] * vec.x) + mat.m[0][1] * vec.y) +
        mat.m[0][2] * vec.z);
    product.y = check_mac_ovf_and_extend_2(
        check_mac_ovf_and_extend_2(
            check_mac_ovf_and_extend_2(((s64)tr.y << 12) + mat.m[1][0] * vec.x) + mat.m[1][1] * vec.y) +
        mat.m[1][2] * vec.z);
    product.z = check_mac_ovf_and_extend_3(
        check_mac_ovf_and_extend_3(
            check_mac_ovf_and_extend_3(((s64)tr.z << 12) + mat.m[2][0] * vec.x) + mat.m[2][1] * vec.y) +
        mat.m[2][2] * vec.z);

    set_mac_and_ir1(product.x, m_lm);
    set_mac_and_ir2(product.y, m_lm);
    if (!rtp) set_mac_and_ir3(product.z, m_lm);
    else mac[3] = (s32)(m_sf ? (product.z >> 12) : product.z);
    return product;
}

inline s64 PSX_GTE::mul_mat_vec_rtp(Mat3x3_s16 mat, Vec3_s16 vec, Vec3_s32 tr) {
    const Vec3_s64 product = mul_mat_vec(mat, vec, tr, true);
    s32 ir3_clamped = gte_clamp((s32)(product.z >> 12), -0x8000, 0x7FFF);
    if (ir3_clamped != (s32)(product.z >> 12)) flag.word |= FlagRegister::IR3_SAT;
    ir[3] = (s16)gte_clamp(mac[3], m_lm ? 0 : -0x8000, 0x7FFF);
    return product.z;
}

inline void PSX_GTE::push_screen_xy(s32 x, s32 y) {
    s_xy[0] = s_xy[1];
    s_xy[1] = s_xy[2];
    s_xy[2].x = (s16)gte_clamp(x, -0x400, 0x3FF);
    if (s_xy[2].x != x) flag.word |= FlagRegister::SX2_SAT;
    s_xy[2].y = (s16)gte_clamp(y, -0x400, 0x3FF);
    if (s_xy[2].y != y) flag.word |= FlagRegister::SY2_SAT;
}

inline void PSX_GTE::push_screen_z(s32 z) {
    s_z[0] = s_z[1];
    s_z[1] = s_z[2];
    s_z[2] = s_z[3];
    s_z[3] = (u16)gte_clamp(z, 0, 0xFFFF);
    if (s_z[3] != (u16)z) flag.word |= FlagRegister::SZ3_OTZ_SAT;
}

inline void PSX_GTE::push_color(u32 r, u32 g, u32 b) {
    rgb_fifo[0] = rgb_fifo[1];
    rgb_fifo[1] = rgb_fifo[2];
    rgb_fifo[2].r = (u8)gte_clamp((s32)r, 0, 0xFF);
    if (rgb_fifo[2].r != r) flag.word |= FlagRegister::COLOR_R_SAT;
    rgb_fifo[2].g = (u8)gte_clamp((s32)g, 0, 0xFF);
    if (rgb_fifo[2].g != g) flag.word |= FlagRegister::COLOR_G_SAT;
    rgb_fifo[2].b = (u8)gte_clamp((s32)b, 0, 0xFF);
    if (rgb_fifo[2].b != b) flag.word |= FlagRegister::COLOR_B_SAT;
    rgb_fifo[2].a = rgbc.a;
}

inline void PSX_GTE::push_color() { push_color((u32)(mac[1] >> 4), (u32)(mac[2] >> 4), (u32)(mac[3] >> 4)); }

inline u32 PSX_GTE::recip(u16 divisor) {
    s32 x = (s32)(257 + UNR_TABLE[((divisor & 0x7FFF) + 0x40) >> 7]);
    s32 tmp = (((s32)divisor * -x) + 0x80) >> 8;
    s32 tmp2 = ((x * (0x20000 + tmp)) + 0x80) >> 8;
    return (u32)tmp2;
}

inline u32 PSX_GTE::divide_unr(u32 lhs, u32 rhs) {
    if (rhs * 2 <= lhs) {
        flag.div_ovf = true;
        return DIVIDE_OVERFLOW_VAL;
    }
    u32 shift = leading_zeroes_u32((s32)rhs);
    lhs <<= shift;
    rhs <<= shift;
    u32 reciprocal = recip((u16)(rhs | 0x8000));
    u64 result64 = ((u64)lhs * reciprocal + 0x8000) >> 16;
    u32 result = (u32)result64;
    if (result > DIVIDE_OVERFLOW_VAL) {
        flag.div_ovf = true;
        return DIVIDE_OVERFLOW_VAL;
    }
    return result;
}

// ---------------------------------------------------------------------------
// Commands
// ---------------------------------------------------------------------------
inline void PSX_GTE::execute(u32 word) {
    GteCommand cmd(word);
    flag.reset();
    m_sf = cmd.sf != 0;
    m_lm = cmd.lm != 0;

    switch (cmd.opcode()) {
        case GteCommand::RTPS:  cmd_rtps(); break;
        case GteCommand::NCLIP: cmd_nclip(); break;
        case GteCommand::OP:    cmd_op(); break;
        case GteCommand::DPCS:  cmd_dpcs(); break;
        case GteCommand::INTPL: cmd_intpl(); break;
        case GteCommand::MVMVA: cmd_mvmva(cmd.mvmva_mul_mat, cmd.mvmva_mul_vec, cmd.mvmva_trans); break;
        case GteCommand::NCDS:  cmd_ncds(); break;
        case GteCommand::CDP:   cmd_cdp(); break;
        case GteCommand::NCDT:  cmd_ncdt(); break;
        case GteCommand::NCCS:  cmd_nccs(); break;
        case GteCommand::CC:    cmd_cc(); break;
        case GteCommand::NCS:   cmd_ncs(); break;
        case GteCommand::NCT:   cmd_nct(); break;
        case GteCommand::SQR:   cmd_sqr(); break;
        case GteCommand::DCPL:  cmd_dcpl(); break;
        case GteCommand::DPCT:  cmd_dpct(); break;
        case GteCommand::AVSZ3: cmd_avsz3(); break;
        case GteCommand::AVSZ4: cmd_avsz4(); break;
        case GteCommand::RTPT:  cmd_rtpt(); break;
        case GteCommand::GPF:   cmd_gpf(); break;
        case GteCommand::GPL:   cmd_gpl(); break;
        case GteCommand::NCCT:  cmd_ncct(); break;
        default: break;
    }
}

inline void PSX_GTE::cmd_rtps(u8 vec_idx, bool do_depth) {
    s64 mac3 = mul_mat_vec_rtp(rot_mat, v[vec_idx], trans_vec);
    push_screen_z((s32)(mac3 >> 12));
    u32 h_s3z = divide_unr(h, s_z[3]);

    s32 x = (s32)(set_mac0((s64)(h_s3z * ir[1]) + (s64)screen_offset.x) >> 16);
    s32 y = (s32)(set_mac0((s64)(h_s3z * ir[2]) + (s64)screen_offset.y) >> 16);
    push_screen_xy(x, y);

    if (do_depth) {
        s64 mac0 = set_mac0((s64)(h_s3z * dqa) + dqb);
        ir[0] = (s16)gte_clamp((s32)(mac0 >> 12), 0, 0x1000);
        if (ir[0] != (s16)(mac0 >> 12)) flag.word |= FlagRegister::IR0_SAT;
    }
}

inline void PSX_GTE::cmd_nclip() {
    set_mac0((s64)s_xy[0].x * s_xy[1].y + s_xy[1].x * s_xy[2].y + s_xy[2].x * s_xy[0].y -
             s_xy[0].x * s_xy[2].y - s_xy[1].x * s_xy[0].y - s_xy[2].x * s_xy[1].y);
}

inline void PSX_GTE::cmd_op() {
    // Outer product: MAC = R x IR (using rotation matrix and IR vector)
    set_mac_and_ir1((s64)rot_mat.m[1][0] * ir[3] - (s64)rot_mat.m[2][1] * ir[2], m_lm);
    set_mac_and_ir2((s64)rot_mat.m[2][1] * ir[1] - (s64)rot_mat.m[0][0] * ir[3], m_lm);
    set_mac_and_ir3((s64)rot_mat.m[0][0] * ir[2] - (s64)rot_mat.m[1][0] * ir[1], m_lm);
}

inline void PSX_GTE::cmd_dpcs(bool use_rgb0) {
    s16 r = use_rgb0 ? (s16)(rgb_fifo[0].r << 4) : rgbc_r();
    s16 g = use_rgb0 ? (s16)(rgb_fifo[0].g << 4) : rgbc_g();
    s16 b = use_rgb0 ? (s16)(rgb_fifo[0].b << 4) : rgbc_b();

    set_mac_and_ir1(((s64)far_color.r << 12) - ((s64)r << 12), false);
    set_mac_and_ir2(((s64)far_color.g << 12) - ((s64)g << 12), false);
    set_mac_and_ir3(((s64)far_color.b << 12) - ((s64)b << 12), false);

    mul_vec_vec(ir0_to_vec(), ir_to_vec(), Vec3_s16{ r, g, b });
    push_color();
}

inline void PSX_GTE::cmd_intpl() {
    set_mac_and_ir1(((s64)far_color.r << 12) - ((s64)mac[1] << 12), false);
    set_mac_and_ir2(((s64)far_color.g << 12) - ((s64)mac[2] << 12), false);
    set_mac_and_ir3(((s64)far_color.b << 12) - ((s64)mac[3] << 12), false);
    mul_vec_vec(ir0_to_vec(), ir_to_vec(), ir_to_vec());
    push_color();
}

inline void PSX_GTE::cmd_mvmva(u32 mul_mat_idx, u32 mul_vec_idx, u32 tr_vec_idx) {
    Mat3x3_s16 mul_mat = {};
    if (mul_mat_idx == 0) mul_mat = rot_mat;
    else if (mul_mat_idx == 1) mul_mat = light_mat;
    else if (mul_mat_idx == 2) mul_mat = light_col_src_mat;
    else { mul_mat = {}; }

    Vec3_s16 mul_vec;
    if (mul_vec_idx == 0) mul_vec = v[0];
    else if (mul_vec_idx == 1) mul_vec = v[1];
    else if (mul_vec_idx == 2) mul_vec = v[2];
    else { mul_vec.x = ir[1]; mul_vec.y = ir[2]; mul_vec.z = ir[3]; }

    Vec3_s32 tr_vec = {};
    if (tr_vec_idx == 0) tr_vec = trans_vec;
    else if (tr_vec_idx == 1) { tr_vec.x = bg_col.r; tr_vec.y = bg_col.g; tr_vec.z = bg_col.b; }
    else if (tr_vec_idx == 2) { tr_vec.x = far_color.r; tr_vec.y = far_color.g; tr_vec.z = far_color.b; }
    else { tr_vec = {}; }

    mul_mat_vec(mul_mat, mul_vec, tr_vec, false);
}

inline void PSX_GTE::cmd_ncds(u8 vec_idx) {
    mul_mat_vec(light_mat, v[vec_idx], {}, false);
    mul_mat_vec(light_col_src_mat, ir_to_vec(), bg_col, false);
    Vec3_s16 ir_vec_tmp = ir_to_vec();

    set_mac_and_ir1(((s64)far_color.r << 12) - (rgbc_r() * ir[1]), false);
    set_mac_and_ir2(((s64)far_color.g << 12) - (rgbc_g() * ir[2]), false);
    set_mac_and_ir3(((s64)far_color.b << 12) - (rgbc_b() * ir[3]), false);

    set_mac_and_ir1((rgbc_r() * ir_vec_tmp.x) + ir[0] * ir[1], m_lm);
    set_mac_and_ir2((rgbc_g() * ir_vec_tmp.y) + ir[0] * ir[2], m_lm);
    set_mac_and_ir3((rgbc_b() * ir_vec_tmp.z) + ir[0] * ir[3], m_lm);
    push_color();
}

inline void PSX_GTE::cmd_cdp() {
    mul_mat_vec(light_col_src_mat, ir_to_vec(), bg_col, false);
    Vec3_s16 ir_vec_tmp = ir_to_vec();
    set_mac_and_ir1(((s64)far_color.r << 12) - (rgbc_r() * ir[1]), false);
    set_mac_and_ir2(((s64)far_color.g << 12) - (rgbc_g() * ir[2]), false);
    set_mac_and_ir3(((s64)far_color.b << 12) - (rgbc_b() * ir[3]), false);
    set_mac_and_ir1((rgbc_r() * ir_vec_tmp.x) + ir[0] * ir[1], m_lm);
    set_mac_and_ir2((rgbc_g() * ir_vec_tmp.y) + ir[0] * ir[2], m_lm);
    set_mac_and_ir3((rgbc_b() * ir_vec_tmp.z) + ir[0] * ir[3], m_lm);
    push_color();
}

inline void PSX_GTE::cmd_ncdt() { cmd_ncds(0); cmd_ncds(1); cmd_ncds(2); }

inline void PSX_GTE::cmd_nccs(u8 vec_idx) {
    mul_mat_vec(light_mat, v[vec_idx], {}, false);
    mul_mat_vec(light_col_src_mat, ir_to_vec(), bg_col, false);
    mul_vec_vec(rgbc_to_vec(), ir_to_vec());
    push_color();
}

inline void PSX_GTE::cmd_cc() {
    mul_mat_vec(light_col_src_mat, ir_to_vec(), bg_col, false);
    mul_vec_vec(rgbc_to_vec(), ir_to_vec());
    push_color();
}

inline void PSX_GTE::cmd_ncs(u8 vec_idx) {
    mul_mat_vec(light_mat, v[vec_idx], {}, false);
    mul_mat_vec(light_col_src_mat, ir_to_vec(), bg_col, false);
    push_color();
}

inline void PSX_GTE::cmd_nct() { cmd_ncs(0); cmd_ncs(1); cmd_ncs(2); }

inline void PSX_GTE::cmd_sqr() { mul_vec_vec(ir_to_vec(), ir_to_vec()); }

inline void PSX_GTE::cmd_dcpl() {
    set_mac_and_ir1(((s64)far_color.r << 12) - (rgbc_r() * ir[1]), false);
    set_mac_and_ir2(((s64)far_color.g << 12) - (rgbc_g() * ir[2]), false);
    set_mac_and_ir3(((s64)far_color.b << 12) - (rgbc_b() * ir[3]), false);
    mul_vec_vec(ir0_to_vec(), ir_to_vec(), rgbc_to_vec());
    push_color();
}

inline void PSX_GTE::cmd_dpct() { cmd_dpcs(true); cmd_dpcs(true); cmd_dpcs(true); }

inline void PSX_GTE::cmd_avsz3() { set_otz(set_mac0((s64)zsf3 * (s_z[1] + s_z[2] + s_z[3]))); }

inline void PSX_GTE::cmd_avsz4() { set_otz(set_mac0((s64)zsf4 * (s_z[0] + s_z[1] + s_z[2] + s_z[3]))); }

inline void PSX_GTE::cmd_rtpt() { cmd_rtps(0, false); cmd_rtps(1, false); cmd_rtps(2); }

inline void PSX_GTE::cmd_gpf() { mul_vec_vec(ir0_to_vec(), ir_to_vec()); push_color(); }

inline void PSX_GTE::cmd_gpl() {
    set_mac_and_ir1(((s64)mac[1] << (m_sf ? 12 : 0)) + ir[0] * ir[1], m_lm);
    set_mac_and_ir2(((s64)mac[2] << (m_sf ? 12 : 0)) + ir[0] * ir[2], m_lm);
    set_mac_and_ir3(((s64)mac[3] << (m_sf ? 12 : 0)) + ir[0] * ir[3], m_lm);
    push_color();
}

inline void PSX_GTE::cmd_ncct() { cmd_nccs(0); cmd_nccs(1); cmd_nccs(2); }
