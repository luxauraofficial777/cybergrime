#!/usr/bin/env python3
"""Check ISO directory of phaseC disc to see what files are listed."""
import struct, sys

DISC_PATH = r'c:\LuxAura\VoidWalkers_Project\DQLOSTTRANSLATION\dq4_phaseC_build1.bin'

with open(DISC_PATH, 'rb') as f:
    data = f.read()

# PSX discs are MODE2/2352. Sector 0 is boot, sector 16 is PVD
# PVD is at sector 16, offset 16*2352+24 = 37656
PVD_SECTOR = 16
pvd_offset = PVD_SECTOR * 2352 + 24

print("=== PVD (Primary Volume Descriptor) ===")
pvd = data[pvd_offset:pvd_offset+2048]
# PVD signature at offset 0 should be 0x01, "CD001" at offset 1-5
print(f"  Type: 0x{pvd[0]:02X}")
print(f"  ID: {pvd[1:6]}")
print(f"  Version: {pvd[6]:02X}")
# Volume ID at offset 40, 32 bytes
vol_id = pvd[40:72].decode('ascii', errors='replace').strip()
print(f"  Volume ID: {vol_id!r}")

# Root directory record at PVD offset 156, 34 bytes
root_dr = pvd[156:156+34]
root_lba = struct.unpack_from('<I', root_dr, 2)[0]
root_size = struct.unpack_from('<I', root_dr, 10)[0]
print(f"  Root dir LBA: {root_lba}")
print(f"  Root dir size: {root_size}")

# Read root directory
print()
print("=== ROOT DIRECTORY ===")
root_offset = root_lba * 2352 + 24
root_data = data[root_offset:root_offset + root_size]

pos = 0
while pos < len(root_data):
    dr_len = root_data[pos]
    if dr_len == 0:
        break
    # Parse directory record
    lba = struct.unpack_from('<I', root_data, pos + 2)[0]
    size = struct.unpack_from('<I', root_data, pos + 10)[0]
    flags = root_data[pos + 25]
    name_len = root_data[pos + 32]
    name = root_data[pos + 33:pos + 33 + name_len].decode('ascii', errors='replace')
    
    # Filter out padding bytes
    if name and name[0] != '\x00':
        type_str = "DIR" if flags & 0x02 else "FILE"
        print(f"  {type_str:4s} LBA={lba:6d} size={size:10d}  {name!r}")
    
    pos += dr_len

# Also check what files the DW7 disc has
print()
print("=== DW7 DISC DIRECTORY (for comparison) ===")
DW7_PATH = r'c:\LuxAura\VoidWalkers_Project\DQLOSTTRANSLATION\DW7D1\DW7D1.bin'
with open(DW7_PATH, 'rb') as f:
    dw7_data = f.read()

dw7_pvd = dw7_data[16*2352+24:16*2352+24+2048]
dw7_vol_id = dw7_pvd[40:72].decode('ascii', errors='replace').strip()
print(f"  Volume ID: {dw7_vol_id!r}")
dw7_root_dr = dw7_pvd[156:156+34]
dw7_root_lba = struct.unpack_from('<I', dw7_root_dr, 2)[0]
dw7_root_size = struct.unpack_from('<I', dw7_root_dr, 10)[0]
dw7_root_offset = dw7_root_lba * 2352 + 24
dw7_root_data = dw7_data[dw7_root_offset:dw7_root_offset + dw7_root_size]

pos = 0
while pos < len(dw7_root_data):
    dr_len = dw7_root_data[pos]
    if dr_len == 0:
        break
    lba = struct.unpack_from('<I', dw7_root_data, pos + 2)[0]
    size = struct.unpack_from('<I', dw7_root_data, pos + 10)[0]
    flags = dw7_root_data[pos + 25]
    name_len = dw7_root_data[pos + 32]
    name = dw7_root_data[pos + 33:pos + 33 + name_len].decode('ascii', errors='replace')
    
    if name and name[0] != '\x00':
        type_str = "DIR" if flags & 0x02 else "FILE"
        print(f"  {type_str:4s} LBA={lba:6d} size={size:10d}  {name!r}")
    
    pos += dr_len

# Also check DQ4 JP disc
print()
print("=== DQ4 JP DISC DIRECTORY ===")
DQ4_PATH = r'c:\LuxAura\VoidWalkers_Project\DQLOSTTRANSLATION\Dragon Quest IV - Michibikareshi Mono Tachi (Japan).bin'
with open(DQ4_PATH, 'rb') as f:
    dq4_data = f.read()

dq4_pvd = dq4_data[16*2352+24:16*2352+24+2048]
dq4_vol_id = dq4_pvd[40:72].decode('ascii', errors='replace').strip()
print(f"  Volume ID: {dq4_vol_id!r}")
dq4_root_dr = dq4_pvd[156:156+34]
dq4_root_lba = struct.unpack_from('<I', dq4_root_dr, 2)[0]
dq4_root_size = struct.unpack_from('<I', dq4_root_dr, 10)[0]
dq4_root_offset = dq4_root_lba * 2352 + 24
dq4_root_data = dq4_data[dq4_root_offset:dq4_root_offset + dq4_root_size]

pos = 0
while pos < len(dq4_root_data):
    dr_len = dq4_root_data[pos]
    if dr_len == 0:
        break
    lba = struct.unpack_from('<I', dq4_root_data, pos + 2)[0]
    size = struct.unpack_from('<I', dq4_root_data, pos + 10)[0]
    flags = dq4_root_data[pos + 25]
    name_len = dq4_root_data[pos + 32]
    name = dq4_root_data[pos + 33:pos + 33 + name_len].decode('ascii', errors='replace')
    
    if name and name[0] != '\x00':
        type_str = "DIR" if flags & 0x02 else "FILE"
        print(f"  {type_str:4s} LBA={lba:6d} size={size:10d}  {name!r}")
    
    pos += dr_len
