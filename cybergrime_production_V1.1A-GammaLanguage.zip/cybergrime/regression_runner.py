#!/usr/bin/env python3
"""
CyberGrime Regression Runner — Phase 3
Loads test_definitions.json, runs each test via psx_agent_runner.exe,
evaluates pass/fail criteria against telemetry JSON, and records results
in test_results.db (SQLite).

Usage:
    python regression_runner.py [profile_name]
    python regression_runner.py quick_smoke
    python regression_runner.py full_regression
    python regression_runner.py unit_only

Exit code: 0 if all tests pass, 1 if any fail.
"""

import json
import os
import sqlite3
import subprocess
import sys
import time
from pathlib import Path

BASE_DIR = Path(__file__).parent.resolve()
RUNNER = BASE_DIR / "psx_agent_runner.exe"
TEST_DEFS = BASE_DIR / "test_definitions.json"
DB_PATH = BASE_DIR / "test_results.db"


def load_test_defs():
    with open(TEST_DEFS, "r", encoding="utf-8") as f:
        return json.load(f)


def init_db(db_path):
    conn = sqlite3.connect(str(db_path))
    c = conn.cursor()
    c.execute("""
        CREATE TABLE IF NOT EXISTS test_results (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            test_id TEXT NOT NULL,
            test_name TEXT,
            run_timestamp TEXT NOT NULL,
            pass INTEGER NOT NULL,
            fail_reason TEXT,
            instr_count INTEGER,
            vblank_count INTEGER,
            final_pc TEXT,
            duration_ms INTEGER,
            telemetry_path TEXT,
            screenshot_path TEXT,
            timeline_path TEXT
        )
    """)
    conn.commit()
    return conn


def load_telemetry(json_path):
    if not os.path.exists(json_path):
        return None
    with open(json_path, "r", encoding="utf-8") as f:
        data = json.load(f)
    return _normalize_telemetry(data)


def _normalize_telemetry(t):
    """Map harness telemetry schema (Instructions_Executed/VBlank_Count/...)
    onto the keys evaluate_pass reads (instruction_count/vblank_count/...).
    Added Aug 4, 2026: without this, every emulator test auto-failed with
    instr=0/vblank=0 regardless of actual emulation."""
    if not isinstance(t, dict):
        return t
    if "instruction_count" not in t:
        t["instruction_count"] = t.get("Instructions_Executed", 0)
    if "vblank_count" not in t:
        t["vblank_count"] = t.get("VBlank_Count", 0)
    if "final_pc" not in t:
        pc = t.get("Last_Known_PC", 0)
        if isinstance(pc, str):
            try:
                pc = int(pc, 16)
            except ValueError:
                pc = 0
        t["final_pc"] = pc
    if "final_status" not in t:
        if t.get("Crashed"):
            t["final_status"] = "CRASH"
            t.setdefault("crash_reason", t.get("Crash_Reason", "unknown"))
        elif t.get("Frozen"):
            t["final_status"] = "FREEZE"
    if "bios_calls" not in t:
        t["bios_calls"] = t.get("BIOS_Call_Log", [])
    return t


def evaluate_pass(test_def, telemetry):
    """Evaluate pass/fail criteria against telemetry JSON."""
    if telemetry is None:
        return False, "No telemetry file produced"

    expect = test_def.get("expect", {})
    reasons = []

    # Check no_crash
    if expect.get("no_crash", False):
        status = telemetry.get("final_status", "unknown")
        if status in ("CRASH", "crash"):
            reasons.append(f"Crashed: {telemetry.get('crash_reason', 'unknown')}")

    # Check no_freeze
    if expect.get("no_freeze", False):
        status = telemetry.get("final_status", "unknown")
        if status in ("FREEZE", "freeze"):
            reasons.append("Emulation froze")

    # Check min_vblanks
    min_vb = expect.get("min_vblank", 0)
    if min_vb > 0:
        actual_vb = telemetry.get("vblank_count", 0)
        if actual_vb < min_vb:
            reasons.append(f"VBlank count {actual_vb} < expected {min_vb}")

    # Check thread_executes
    if expect.get("thread_executes", False):
        bios_calls = telemetry.get("bios_calls", [])
        has_changeth = any(
            call.get("table") == "B" and call.get("function") == 0x10
            for call in bios_calls
        )
        if not has_changeth:
            reasons.append("ChangeTh(1) never called — thread not started")

    # Check cdrom_sectors_delivered
    min_sectors = expect.get("cdrom_sectors_delivered", 0)
    if min_sectors > 0:
        cdrom_reads = telemetry.get("cdrom_reads", [])
        if len(cdrom_reads) < min_sectors:
            reasons.append(
                f"CD-ROM sectors delivered {len(cdrom_reads)} < expected {min_sectors}"
            )

    # Check pc_in_range
    pc_range = expect.get("pc_in_range")
    if pc_range and len(pc_range) == 2:
        final_pc = telemetry.get("final_pc", 0)
        lo = int(pc_range[0], 16) if isinstance(pc_range[0], str) else pc_range[0]
        hi = int(pc_range[1], 16) if isinstance(pc_range[1], str) else pc_range[1]
        if final_pc < lo or final_pc > hi:
            reasons.append(f"Final PC 0x{final_pc:08X} outside range [0x{lo:08X}, 0x{hi:08X}]")

    if reasons:
        return False, "; ".join(reasons)
    return True, "PASS"


def run_test(test_def, conn):
    test_id = test_def["id"]
    test_name = test_def.get("name", test_id)
    disc = test_def.get("disc", "")
    max_instrs = test_def.get("max_instrs", 5000000)
    wallclock = test_def.get("wallclock_ms", 60000)
    test_type = test_def.get("type", "emulator")

    # Handle non-emulator tests
    if test_type == "python":
        script = test_def.get("script")
        if script and (BASE_DIR / script).exists():
            print(f"  [PYTHON] Running {script}...")
            t0 = time.time()
            result = subprocess.run(
                [sys.executable, str(BASE_DIR / script)],
                capture_output=True, text=True, timeout=120
            )
            duration_ms = int((time.time() - t0) * 1000)
            passed = result.returncode == 0
            reason = "PASS" if passed else f"Exit code {result.returncode}"
            _record_result(conn, test_id, test_name, passed, reason,
                           0, 0, "", duration_ms, "", "", "")
            return passed
        else:
            _record_result(conn, test_id, test_name, False,
                           f"Script not found: {script}", 0, 0, "", 0, "", "", "")
            return False

    if test_type == "unit":
        # Unit tests would run component-specific test executables
        # For now, skip with a note
        print(f"  [UNIT] {test_name} — skipped (no unit test harness yet)")
        _record_result(conn, test_id, test_name, True, "SKIPPED (no unit harness)",
                       0, 0, "", 0, "", "", "")
        return True

    # Emulator test
    disc_path = BASE_DIR / disc if not os.path.isabs(disc) else disc
    if not disc_path.exists():
        print(f"  [SKIP] Disc not found: {disc_path}")
        _record_result(conn, test_id, test_name, False,
                       f"Disc not found: {disc_path}", 0, 0, "", 0, "", "", "")
        return False

    json_path = BASE_DIR / f"telemetry_{test_id}.json"
    screenshot_path = BASE_DIR / f"screenshot_{test_id}.bmp"
    timeline_path = BASE_DIR / f"timeline_{test_id}.json"

    cmd = [
        str(RUNNER),
        str(disc_path),
        test_id,
        str(max_instrs),
        str(json_path),
        str(wallclock),
        "--screenshot", str(screenshot_path),
        "--timeline", str(timeline_path),
    ]

    # Add load_state if specified
    load_state = test_def.get("load_state")
    if load_state:
        state_path = BASE_DIR / load_state if not os.path.isabs(load_state) else load_state
        if state_path.exists():
            cmd.extend(["--loadstate", str(state_path)])

    print(f"  [RUN] {test_name}")
    print(f"        disc={disc_path.name} max_instrs={max_instrs}")
    t0 = time.time()
    result = subprocess.run(cmd, capture_output=True, text=True, timeout=wallclock // 1000 + 60)
    duration_ms = int((time.time() - t0) * 1000)

    # Load and evaluate telemetry
    telemetry = load_telemetry(json_path)
    passed, reason = evaluate_pass(test_def, telemetry)

    instr_count = telemetry.get("instruction_count", 0) if telemetry else 0
    vblank_count = telemetry.get("vblank_count", 0) if telemetry else 0
    final_pc = telemetry.get("final_pc", 0) if telemetry else 0
    final_pc_str = f"0x{final_pc:08X}" if final_pc else ""

    status_str = "PASS" if passed else "FAIL"
    print(f"  [{status_str}] {test_id}: {reason}")
    print(f"        instr={instr_count} vblank={vblank_count} pc={final_pc_str} time={duration_ms}ms")

    _record_result(conn, test_id, test_name, passed, reason,
                   instr_count, vblank_count, final_pc_str, duration_ms,
                   str(json_path), str(screenshot_path), str(timeline_path))

    return passed


def _record_result(conn, test_id, test_name, passed, reason,
                   instr_count, vblank_count, final_pc, duration_ms,
                   telemetry_path, screenshot_path, timeline_path):
    c = conn.cursor()
    c.execute("""
        INSERT INTO test_results
        (test_id, test_name, run_timestamp, pass, fail_reason,
         instr_count, vblank_count, final_pc, duration_ms,
         telemetry_path, screenshot_path, timeline_path)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    """, (test_id, test_name, time.strftime("%Y-%m-%d %H:%M:%S"),
          1 if passed else 0, reason,
          instr_count, vblank_count, final_pc, duration_ms,
          telemetry_path, screenshot_path, timeline_path))
    conn.commit()


def closed_loop_build_and_test():
    """Build v43 disc, verify HBD re-encoding, then run emulator tests.

    Implements the closed-loop pipeline: build → verify → smoke → extended.
    Each stage has strict pass/fail gates — failure aborts the pipeline.
    """
    builder_path = BASE_DIR.parent / "translation-tools" / "frankenstein_builder.py"
    disc_path = BASE_DIR.parent / "dq4_frankenstein_v43.bin"

    print("=" * 60)
    print("CLOSED-LOOP BUILD-TO-TEST PIPELINE — v43")
    print("=" * 60)

    # Stage 1: Build
    print("\n[STAGE 1/4] Building v43 disc...")
    if not builder_path.exists():
        print(f"  FAIL: Builder not found: {builder_path}")
        return 1
    t0 = time.time()
    result = subprocess.run(
        [sys.executable, str(builder_path), "--profile", "frank_v43"],
        capture_output=True, text=True, timeout=900
    )
    build_time = time.time() - t0
    print(result.stdout[-2000:] if len(result.stdout) > 2000 else result.stdout)
    if result.returncode != 0:
        print(f"  FAIL: Build failed (exit {result.returncode})")
        print(result.stderr[-500:])
        return 1
    if not disc_path.exists():
        print(f"  FAIL: Disc not created: {disc_path}")
        return 1
    print(f"  PASS: Build complete ({build_time:.1f}s, {disc_path.stat().st_size:,} bytes)")

    # Stage 2: HBD re-encode verification
    print("\n[STAGE 2/4] Verifying HBD re-encoding...")
    verify_script = BASE_DIR / "verify_v43_hbd.py"
    result = subprocess.run(
        [sys.executable, str(verify_script)],
        capture_output=True, text=True, timeout=120
    )
    print(result.stdout)
    if result.returncode != 0:
        print(f"  FAIL: HBD verification failed (exit {result.returncode})")
        return 1
    print(f"  PASS: HBD re-encode verified")

    # Stage 3: Smoke test
    print("\n[STAGE 3/4] Running smoke test (5M instructions)...")
    conn = init_db(DB_PATH)
    defs = load_test_defs()
    smoke_test = next((t for t in defs["tests"] if t["id"] == "v43_smoke"), None)
    if not smoke_test:
        print("  FAIL: v43_smoke test definition not found")
        return 1
    smoke_passed = run_test(smoke_test, conn)
    if not smoke_passed:
        print("  FAIL: Smoke test failed — aborting pipeline")
        conn.close()
        return 1
    print(f"  PASS: Smoke test passed")

    # Stage 4: Extended test
    print("\n[STAGE 4/4] Running extended test (55M instructions)...")
    ext_test = next((t for t in defs["tests"] if t["id"] == "v43_extended"), None)
    if not ext_test:
        print("  SKIP: v43_extended test definition not found")
        conn.close()
        return 0
    ext_passed = run_test(ext_test, conn)
    conn.close()

    print("\n" + "=" * 60)
    if ext_passed:
        print("CLOSED-LOOP PIPELINE: ALL STAGES PASSED")
    else:
        print("CLOSED-LOOP PIPELINE: EXTENDED TEST FAILED")
        print("  (Smoke passed — disc boots but may have runtime issues)")
    print("=" * 60)

    return 0 if ext_passed else 1


def main():
    if not RUNNER.exists():
        print(f"ERROR: {RUNNER} not found. Build first with build_agent.bat")
        return 1

    # Check for --closed-loop flag
    if len(sys.argv) > 1 and sys.argv[1] == "--closed-loop":
        return closed_loop_build_and_test()

    defs = load_test_defs()
    tests = defs.get("tests", [])
    profiles = defs.get("profiles", [])

    # Determine which tests to run
    profile_name = sys.argv[1] if len(sys.argv) > 1 else None
    if profile_name:
        profile = next((p for p in profiles if p["name"] == profile_name), None)
        if profile:
            test_ids = set(profile["tests"])
            tests = [t for t in tests if t["id"] in test_ids]
            print(f"Running profile: {profile_name} ({len(tests)} tests)\n")
        else:
            print(f"Profile not found: {profile_name}")
            print(f"Available: {', '.join(p['name'] for p in profiles)}")
            return 1
    else:
        print(f"Running all {len(tests)} tests\n")

    conn = init_db(DB_PATH)
    results = []
    for test_def in tests:
        passed = run_test(test_def, conn)
        results.append((test_def["id"], passed))

    conn.close()

    # Summary
    print("\n" + "=" * 60)
    print("REGRESSION SUMMARY")
    print("=" * 60)
    passed_count = sum(1 for _, p in results if p)
    failed_count = len(results) - passed_count
    for test_id, passed in results:
        status = "PASS" if passed else "FAIL"
        print(f"  {status:4s}  {test_id}")
    print(f"\n  {passed_count}/{len(results)} passed, {failed_count} failed")
    print(f"  Results DB: {DB_PATH}")
    print("=" * 60)

    return 0 if failed_count == 0 else 1


if __name__ == "__main__":
    sys.exit(main())
