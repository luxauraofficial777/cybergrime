# Minimal MIPS hook stub — inject at a code cave to redirect execution
# This example patches the return address to force a thread switch
#
# Assemble with: mips-as -o stub.o stub.asm
# Or inject raw bytes via --inject examples/inject.json

.set noreorder

# Force ChangeTh(1) via BIOS B-table
# $a0 = 1 (thread 1 = CD-ROM loader)
li      $a0, 1
li      $t1, 0x10        # ChangeTh function number
li      $t2, 0xB0        # BIOS B-table vector
jr      $t2              # Jump to BIOS
nop                      # Delay slot
