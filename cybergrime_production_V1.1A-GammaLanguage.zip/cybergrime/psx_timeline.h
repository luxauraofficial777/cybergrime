#pragma once

// ============================================================================
// PSX Event Timeline — Records significant emulation events for analysis
// Tracks VBlanks, CD-ROM commands, DMA transfers, IRQs, BIOS calls,
// register watches, freezes, injections, and screenshots.
// Exports as JSON for analyze_telemetry.py.
// Header-only, dependency-free.
// ============================================================================

#include <cstdint>
#include <cstdio>
#include <cstring>
#include <vector>
#include <string>

class PSXTimeline {
public:
    enum EventType : uint8_t {
        EV_VBLANK = 0,
        EV_CDROM_CMD,
        EV_CDROM_IRQ,
        EV_DMA_TRANSFER,
        EV_IRQ,
        EV_BIOS_CALL,
        EV_BREAKPOINT,
        EV_WATCHPOINT,
        EV_FREEZE,
        EV_INJECTION,
        EV_SCREENSHOT,
        EV_SAVESTATE,
        EV_GTE_CMD,
        EV_GPU_CMD,
        EV_SPU_WRITE,
        EV_MDEC_CMD,
        EV_THREAD_SWITCH,
        EV_CUSTOM
    };

    struct Event {
        uint64_t   instr_count;
        uint32_t   pc;
        EventType  type;
        uint32_t   data1;  // type-specific (e.g. BIOS fn, CD cmd, DMA channel)
        uint32_t   data2;  // type-specific (e.g. arg0, sector LBA, transfer size)
        uint32_t   data3;  // type-specific (e.g. arg1, response, dest addr)
        char       label[48];
    };

    std::vector<Event> events;
    bool enabled;
    uint32_t max_events;  // cap to prevent unbounded growth
    uint64_t start_instr;

    PSXTimeline() : enabled(false), max_events(100000), start_instr(0) {}

    void enable() { enabled = true; }
    void disable() { enabled = false; }
    void clear() { events.clear(); }
    void set_max_events(uint32_t n) { max_events = n; }

    // Record an event
    void record(EventType type, uint64_t instr, uint32_t pc,
                uint32_t d1 = 0, uint32_t d2 = 0, uint32_t d3 = 0,
                const char* lbl = nullptr) {
        if (!enabled) return;
        if (events.size() >= max_events) {
            // Drop oldest 10% to make room
            size_t drop = max_events / 10;
            events.erase(events.begin(), events.begin() + drop);
        }
        Event e;
        e.instr_count = instr;
        e.pc = pc;
        e.type = type;
        e.data1 = d1;
        e.data2 = d2;
        e.data3 = d3;
        if (lbl) {
            strncpy(e.label, lbl, sizeof(e.label) - 1);
            e.label[sizeof(e.label) - 1] = '\0';
        } else {
            e.label[0] = '\0';
        }
        events.push_back(e);
    }

    // Convenience methods
    void record_vblank(uint64_t instr, uint32_t vblank_count) {
        record(EV_VBLANK, instr, 0, vblank_count, 0, 0, "VBlank");
    }

    void record_bios_call(uint64_t instr, uint32_t pc, uint8_t table, uint8_t fn,
                          uint32_t a0, uint32_t a1) {
        record(EV_BIOS_CALL, instr, pc, (table << 8) | fn, a0, a1, "BIOS");
    }

    void record_cdrom_cmd(uint64_t instr, uint32_t pc, uint8_t cmd, uint32_t param) {
        record(EV_CDROM_CMD, instr, pc, cmd, param, 0, "CDROM");
    }

    void record_cdrom_irq(uint64_t instr, uint8_t irq_type, uint8_t response) {
        record(EV_CDROM_IRQ, instr, 0, irq_type, response, 0, "CDROM_IRQ");
    }

    void record_dma(uint64_t instr, uint8_t channel, uint32_t madr, uint32_t bcr) {
        record(EV_DMA_TRANSFER, instr, 0, channel, madr, bcr, "DMA");
    }

    void record_irq(uint64_t instr, uint32_t pc, uint8_t irq_bit) {
        record(EV_IRQ, instr, pc, irq_bit, 0, 0, "IRQ");
    }

    void record_breakpoint(uint64_t instr, uint32_t pc, const char* label = nullptr) {
        record(EV_BREAKPOINT, instr, pc, 0, 0, 0, label ? label : "BP");
    }

    void record_freeze(uint64_t instr, uint32_t pc, const char* reason) {
        record(EV_FREEZE, instr, pc, 0, 0, 0, reason ? reason : "FREEZE");
    }

    void record_gte_cmd(uint64_t instr, uint32_t pc, uint32_t cmd) {
        record(EV_GTE_CMD, instr, pc, cmd, 0, 0, "GTE");
    }

    void record_gpu_cmd(uint64_t instr, uint32_t pc, uint8_t cmd) {
        record(EV_GPU_CMD, instr, pc, cmd, 0, 0, "GPU");
    }

    void record_thread_switch(uint64_t instr, uint8_t old_thread, uint8_t new_thread) {
        record(EV_THREAD_SWITCH, instr, 0, old_thread, new_thread, 0, "ThreadSwitch");
    }

    // Export to JSON file
    bool export_json(const char* filename) const {
        FILE* f = fopen(filename, "w");
        if (!f) return false;

        fprintf(f, "{\n");
        fprintf(f, "  \"event_count\": %zu,\n", events.size());
        fprintf(f, "  \"events\": [\n");

        const char* type_names[] = {
            "vblank", "cdrom_cmd", "cdrom_irq", "dma", "irq",
            "bios_call", "breakpoint", "watchpoint", "freeze",
            "injection", "screenshot", "savestate", "gte_cmd",
            "gpu_cmd", "spu_write", "mdec_cmd", "thread_switch", "custom"
        };

        for (size_t i = 0; i < events.size(); i++) {
            const Event& e = events[i];
            const char* tname = (e.type <= EV_CUSTOM) ? type_names[e.type] : "unknown";
            fprintf(f, "    {\"i\": %llu, \"pc\": \"0x%08X\", \"type\": \"%s\", "
                       "\"d1\": \"0x%08X\", \"d2\": \"0x%08X\", \"d3\": \"0x%08X\"",
                    (unsigned long long)e.instr_count, e.pc, tname,
                    e.data1, e.data2, e.data3);
            if (e.label[0]) {
                fprintf(f, ", \"label\": \"%s\"", e.label);
            }
            fprintf(f, "}%s\n", (i + 1 < events.size()) ? "," : "");
        }

        fprintf(f, "  ]\n");
        fprintf(f, "}\n");
        fclose(f);
        return true;
    }

    // Print summary to stdout
    void print_summary() const {
        uint32_t counts[EV_CUSTOM + 1] = {};
        for (const auto& e : events) {
            if (e.type <= EV_CUSTOM) counts[e.type]++;
        }
        const char* type_names[] = {
            "VBlank", "CDROM_CMD", "CDROM_IRQ", "DMA", "IRQ",
            "BIOS_CALL", "BREAKPOINT", "WATCHPOINT", "FREEZE",
            "INJECTION", "SCREENSHOT", "SAVESTATE", "GTE_CMD",
            "GPU_CMD", "SPU_WRITE", "MDEC_CMD", "THREAD_SWITCH", "CUSTOM"
        };
        printf("[TIMELINE] %zu events recorded:\n", events.size());
        for (int i = 0; i <= EV_CUSTOM; i++) {
            if (counts[i] > 0) {
                printf("  %-16s %u\n", type_names[i], counts[i]);
            }
        }
        if (!events.empty()) {
            printf("  Range: instr %llu -> %llu\n",
                   (unsigned long long)events.front().instr_count,
                   (unsigned long long)events.back().instr_count);
        }
    }

    // Query events by type
    std::vector<const Event*> get_events(EventType type) const {
        std::vector<const Event*> result;
        for (const auto& e : events) {
            if (e.type == type) result.push_back(&e);
        }
        return result;
    }

    // Get last N events of a type
    std::vector<const Event*> get_last_events(EventType type, size_t n) const {
        std::vector<const Event*> all = get_events(type);
        if (all.size() <= n) return all;
        return std::vector<const Event*>(all.end() - n, all.end());
    }
};
