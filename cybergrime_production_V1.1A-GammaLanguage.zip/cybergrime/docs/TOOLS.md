# CyberGrime Tools Reference

## psx_agent_runner.exe

The core emulator runner. All testing and debugging goes through this binary.

```
psx_agent_runner.exe <disc.bin> <profile_name> [max_instrs] [json_path] [wallclock_ms] [flags...]
```

### Flags

| Flag | Description |
|---|---|
| `--bp <addr>` | Add breakpoint (log only) |
| `--bp-halt <addr>` | Add breakpoint that halts execution |
| `--wp <addr>` | Add memory watchpoint |
| `--trace-from <addr>` | Start instruction trace from address |
| `--trace-to <file>` | Trace output file path |
| `--inject <json>` | RAM injection spec file |
| `--monitor <json>` | Buffer monitor spec file |
| `--symbols <json>` | Load symbol table for named addresses |
| `--console` | Enable interactive stdin console |
| `--savestate-out <file>` | Save emulator state to file on exit |
| `--loadstate <file>` | Load emulator state from file before boot |
| `--screenshot <file.bmp>` | Dump framebuffer to BMP on exit |
| `--timeline <file.json>` | Export event timeline as JSON |
| `--gdb [port]` | Start GDB remote stub (default port 3333) |
| `--rewind` | Enable rewind snapshot buffer |
| `--lua <file.lua>` | Load Lua automation script |
| `--psn00b-align` | Map watchpoints to BIOS vectors + GTE registers |
| `--huffman-trace` | Active trace on decompression + text cache buffer |
| `--rebuild-iso <xml>` | Generate ISO rebuild manifest from layout XML |

### Interactive Console Commands

When `--console` is used, the following commands are available on stdin:

| Command | Description |
|---|---|
| `b <pc>` | Add breakpoint |
| `bc` | Clear all breakpoints |
| `bl` | List breakpoints |
| `w <addr> <size>` | Add memory watchpoint |
| `wr <reg> <val>` | Add register watch |
| `m <addr> <len>` | Hex dump memory |
| `mm <addr> <val>` | Write 32-bit value to memory |
| `r` | Dump all registers |
| `pc` | Show current PC |
| `s` | Single step |
| `si` | Step into delay slot |
| `c` | Continue execution |
| `p` | Pause execution |
| `dis <pc> <count>` | Disassemble instructions |
| `bt` | Backtrace via $ra chain |
| `info <cd\|dma\|gpu\|gte\|spu\|timers>` | Hardware state dump |
| `save <file>` | Save state |
| `load <file>` | Load state |
| `screenshot <file>` | Capture framebuffer to BMP |
| `log <on\|off>` | Toggle trace logging |
| `quit` | Exit emulator |

## regression_runner.py

```
python regression_runner.py [profile_name]
```

Runs tests from `test_definitions.json`. Records results in `test_results.db`.
Returns exit code 0 if all pass, 1 if any fail.

## baseline_manager.py

```
python baseline_manager.py save <build_id> <telemetry.json>
python baseline_manager.py compare <build_id> <telemetry.json>
python baseline_manager.py list
python baseline_manager.py diff <build_id> <telemetry.json>
```

## iso_toolkit.py

```
python iso_toolkit.py list <iso>
python iso_toolkit.py info <iso>
python iso_toolkit.py extract <iso> <file> <out>
python iso_toolkit.py inject <iso> <file> <src> <out>
python iso_toolkit.py patch <iso> <spec.json> <out>
python iso_toolkit.py edc <iso>
python iso_toolkit.py diff <a> <b>
```

## build_agent.bat

```
build_agent.bat           — release build
build_agent.bat debug     — debug build with logging
build_agent.bat clean     — clean + release build
```
