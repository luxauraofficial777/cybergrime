#!/usr/bin/env python3
"""Disassemble 0x80075430 (desc walk), 0x8007AD44 (desc publish), 0x8007A500 (bump alloc), and search for writes to 0x800D9A40."""
import struct

EXE_PATH = r"..\translation\SLUSP012.06"
LOAD_ADDR = 0x80017F00
EXE_HDR_SIZE = 0x800

def ram_to_file(ram_addr):
    return ram_addr - LOAD_ADDR + EXE_HDR_SIZE

def file_to_ram(file_off):
    return file_off + LOAD_ADDR - EXE_HDR_SIZE

REG = ["$zero","$at","$v0","$v1","$a0","$a1","$a2","$a3",
       "$t0","$t1","$t2","$t3","$t4","$t5","$t6","$t7",
       "$s0","$s1","$s2","$s3","$s4","$s5","$s6","$s7",
       "$t8","$t9","$k0","$k1","$gp","$sp","$fp","$ra"]

def sx16(v): return v - 0x10000 if v & 0x8000 else v

def disasm(word, pc):
    op=(word>>26)&0x3F; rs=(word>>21)&0x1F; rt=(word>>16)&0x1F
    rd=(word>>11)&0x1F; sa=(word>>6)&0x1F; fn=word&0x3F
    imm=word&0xFFFF; simm=sx16(imm); tgt=word&0x3FFFFFF
    if op==0:
        if word==0: return "nop"
        if fn==0x20: return f"add {REG[rd]},{REG[rs]},{REG[rt]}"
        if fn==0x21: return f"addu {REG[rd]},{REG[rs]},{REG[rt]}"
        if fn==0x23: return f"subu {REG[rd]},{REG[rs]},{REG[rt]}"
        if fn==0x24: return f"and {REG[rd]},{REG[rs]},{REG[rt]}"
        if fn==0x25: return f"or {REG[rd]},{REG[rs]},{REG[rt]}"
        if fn==0x27: return f"nor {REG[rd]},{REG[rs]},{REG[rt]}"
        if fn==0x2A: return f"slt {REG[rd]},{REG[rs]},{REG[rt]}"
        if fn==0x2B: return f"sltu {REG[rd]},{REG[rs]},{REG[rt]}"
        if fn==0x00: return f"sll {REG[rd]},{REG[rt]},{sa}"
        if fn==0x02: return f"srl {REG[rd]},{REG[rt]},{sa}"
        if fn==0x03: return f"sra {REG[rd]},{REG[rt]},{sa}"
        if fn==0x04: return f"sllv {REG[rd]},{REG[rt]},{REG[rs]}"
        if fn==0x06: return f"srlv {REG[rd]},{REG[rt]},{REG[rs]}"
        if fn==0x07: return f"srav {REG[rd]},{REG[rt]},{REG[rs]}"
        if fn==0x08: return f"jr {REG[rs]}"
        if fn==0x09: return f"jalr {REG[rd]},{REG[rs]}"
        if fn==0x10: return f"mfhi {REG[rd]}"
        if fn==0x12: return f"mflo {REG[rd]}"
        if fn==0x18: return f"mult {REG[rs]},{REG[rt]}"
        if fn==0x19: return f"multu {REG[rs]},{REG[rt]}"
        if fn==0x1A: return f"div {REG[rs]},{REG[rt]}"
        if fn==0x1B: return f"divu {REG[rs]},{REG[rt]}"
        return f".special 0x{fn:02x}"
    if op==0x01:
        if rt==0: return f"bltz {REG[rs]},0x{pc+4+simm*4:08X}"
        if rt==1: return f"bgez {REG[rs]},0x{pc+4+simm*4:08X}"
        return f".regimm 0x{rt:02x}"
    if op==0x02: return f"j 0x{(pc&0xF0000000)|(tgt<<2):08X}"
    if op==0x03: return f"jal 0x{(pc&0xF0000000)|(tgt<<2):08X}"
    if op==0x04: return f"beq {REG[rs]},{REG[rt]},0x{pc+4+simm*4:08X}"
    if op==0x05: return f"bne {REG[rs]},{REG[rt]},0x{pc+4+simm*4:08X}"
    if op==0x06: return f"blez {REG[rs]},0x{pc+4+simm*4:08X}"
    if op==0x07: return f"bgtz {REG[rs]},0x{pc+4+simm*4:08X}"
    if op==0x08: return f"addi {REG[rt]},{REG[rs]},{simm}"
    if op==0x09: return f"addiu {REG[rt]},{REG[rs]},{simm}"
    if op==0x0A: return f"slti {REG[rt]},{REG[rs]},{simm}"
    if op==0x0B: return f"sltiu {REG[rt]},{REG[rs]},{simm}"
    if op==0x0C: return f"andi {REG[rt]},{REG[rs]},0x{imm:04X}"
    if op==0x0D: return f"ori {REG[rt]},{REG[rs]},0x{imm:04X}"
    if op==0x0E: return f"xori {REG[rt]},{REG[rs]},0x{imm:04X}"
    if op==0x0F: return f"lui {REG[rt]},0x{imm:04X}"
    if op==0x20: return f"lb {REG[rt]},{simm}({REG[rs]})"
    if op==0x21: return f"lh {REG[rt]},{simm}({REG[rs]})"
    if op==0x23: return f"lw {REG[rt]},{simm}({REG[rs]})"
    if op==0x24: return f"lbu {REG[rt]},{simm}({REG[rs]})"
    if op==0x25: return f"lhu {REG[rt]},{simm}({REG[rs]})"
    if op==0x28: return f"sb {REG[rt]},{simm}({REG[rs]})"
    if op==0x29: return f"sh {REG[rt]},{simm}({REG[rs]})"
    if op==0x2B: return f"sw {REG[rt]},{simm}({REG[rs]})"
    return f".word 0x{word:08X}"

def disasm_range(data, start, count, label):
    print(f"\n=== {label} 0x{start:08X} ===")
    fo = ram_to_file(start)
    for i in range(count):
        o = fo + i*4
        if o+4 > len(data): break
        w = struct.unpack_from("<I", data, o)[0]
        pc = start + i*4
        print(f"  0x{pc:08X}: {w:08X}  {disasm(w, pc)}")

def main():
    with open(EXE_PATH, "rb") as f:
        data = f.read()
    print(f"EXE: {len(data)} bytes")

    # 1. Descriptor walk function at 0x80075430
    disasm_range(data, 0x80075430, 80, "DESC WALK (returns $s2)")

    # 2. Descriptor publish at 0x8007AD44
    disasm_range(data, 0x8007AD44, 60, "DESC PUBLISH (sets *0x800F2228)")

    # 3. Bump allocator around 0x8007A500 (loads heap base from 0x800C9A28)
    disasm_range(data, 0x8007A4F0, 60, "BUMP ALLOC (loads from 0x800C9A28)")

    # 4. Search for writes to 0x800D9A40
    # 0x800D9A40 = 0x800E0000 + sign_extend(0x9A40) = 0x800E0000 - 0x65C0
    # Or 0x800D0000 + sign_extend(0x9A40) = 0x800D0000 - 0x65C0 = 0x800C9A40
    # Wait, let me recalculate: 0x9A40 as signed = -0x65C0 = -26048
    # 0x800D0000 - 26048 = 0x800D0000 - 0x65C0 = 0x800C9A40
    # 0x800E0000 - 26048 = 0x800E0000 - 0x65C0 = 0x800D9A40  <-- THIS ONE
    print(f"\n=== Search for writes to 0x800D9A40 (lui 0x800E + sw/lw 0x9A40) ===")
    for o in range(EXE_HDR_SIZE, len(data)-4, 4):
        w = struct.unpack_from("<I", data, o)[0]
        op = (w >> 26) & 0x3F
        if op == 0x0F:  # lui
            imm = w & 0xFFFF
            if imm == 0x800E:
                rt = (w >> 16) & 0x1F
                for j in range(1, 8):
                    no = o + j*4
                    if no+4 > len(data): break
                    nw = struct.unpack_from("<I", data, no)[0]
                    nimm = nw & 0xFFFF
                    if nimm == 0x9A40:
                        nrs = (nw >> 21) & 0x1F
                        nrt = (nw >> 16) & 0x1F
                        if nrs == rt or nrt == rt:
                            ram = file_to_ram(no)
                            print(f"  0x{ram:08X}: {nw:08X}  {disasm(nw, ram)}")

    # Also search with lui 0x800D + offset 0x9A40 (sign-extended = 0x800C9A40)
    print(f"\n=== Search for access to 0x800C9A40 (lui 0x800D + sw/lw 0x9A40) ===")
    for o in range(EXE_HDR_SIZE, len(data)-4, 4):
        w = struct.unpack_from("<I", data, o)[0]
        op = (w >> 26) & 0x3F
        if op == 0x0F:
            imm = w & 0xFFFF
            if imm == 0x800D:
                rt = (w >> 16) & 0x1F
                for j in range(1, 8):
                    no = o + j*4
                    if no+4 > len(data): break
                    nw = struct.unpack_from("<I", data, no)[0]
                    nimm = nw & 0xFFFF
                    if nimm == 0x9A40:
                        nrs = (nw >> 21) & 0x1F
                        nrt = (nw >> 16) & 0x1F
                        if nrs == rt or nrt == rt:
                            ram = file_to_ram(no)
                            print(f"  0x{ram:08X}: {nw:08X}  {disasm(nw, ram)}")

    # 5. Search for writes to 0x800F2228 (published desc base)
    # 0x800F2228 = 0x800F0000 + 0x2228
    print(f"\n=== Search for writes to 0x800F2228 (lui 0x800F + sw 0x2228) ===")
    for o in range(EXE_HDR_SIZE, len(data)-4, 4):
        w = struct.unpack_from("<I", data, o)[0]
        op = (w >> 26) & 0x3F
        if op == 0x0F:
            imm = w & 0xFFFF
            if imm == 0x800F:
                rt = (w >> 16) & 0x1F
                for j in range(1, 8):
                    no = o + j*4
                    if no+4 > len(data): break
                    nw = struct.unpack_from("<I", data, no)[0]
                    nimm = nw & 0xFFFF
                    if nimm == 0x2228:
                        nrs = (nw >> 21) & 0x1F
                        nrt = (nw >> 16) & 0x1F
                        if nrs == rt or nrt == rt:
                            ram = file_to_ram(no)
                            print(f"  0x{ram:08X}: {nw:08X}  {disasm(nw, ram)}")

if __name__ == "__main__":
    main()
