#!/usr/bin/env python3
"""Read 0x800B6788 and disassemble the function prologue before 0x80098620."""
import struct
from capstone import Cs, CS_ARCH_MIPS, CS_MODE_MIPS32, CS_MODE_LITTLE_ENDIAN

EXE_PATH = r"c:\LuxAura\VoidWalkers_Project\DQLOSTTRANSLATION\translation\SLUSP012.06"
LOAD_ADDR = 0x80017F00
HEADER_SIZE = 0x800

with open(EXE_PATH, "rb") as f:
    data = f.read()

def ram_to_offset(ram):
    return (ram - LOAD_ADDR) + HEADER_SIZE

# Read 0x800B6788
off = ram_to_offset(0x800B6788)
val = struct.unpack("<I", data[off:off+4])[0]
print(f"0x800B6788: 0x{val:08X}")

# Also read 0x800B6784 (already known: 0x1F801800)
off2 = ram_to_offset(0x800B6784)
val2 = struct.unpack("<I", data[off2:off2+4])[0]
print(f"0x800B6784: 0x{val2:08X}")

# Disassemble function prologue — search backwards from 0x80098620 for addiu $sp, $sp, -NN
md = Cs(CS_ARCH_MIPS, CS_MODE_MIPS32 | CS_MODE_LITTLE_ENDIAN)
md.detail = True

print("\n=== Searching for function prologue before 0x80098620 ===")
for addr in range(0x80098500, 0x80098620, 4):
    off = ram_to_offset(addr)
    word = struct.unpack("<I", data[off:off+4])[0]
    op = (word >> 26) & 0x3F
    rt = (word >> 16) & 0x1F
    rs = (word >> 21) & 0x1F
    imm = word & 0xFFFF
    if op == 0x09 and rs == 29 and rt == 29 and (imm & 0x8000):  # addiu $sp, $sp, -NN
        print(f"  Found prologue at 0x{addr:08X}: addiu $sp, $sp, -{0x10000-imm}")

# Disassemble from the prologue to 0x80098670
print("\n=== Full function from prologue ===")
# Let's disassemble from 0x80098580 to 0x80098670
start = 0x80098580
end = 0x80098670
start_off = ram_to_offset(start)
end_off = ram_to_offset(end)
code = data[start_off:end_off]
for insn in md.disasm(code, start):
    print(f"  0x{insn.address:08X}:  {insn.mnemonic:<8s} {insn.op_str}")
