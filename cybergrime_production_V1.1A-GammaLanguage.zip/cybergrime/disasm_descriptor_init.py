#!/usr/bin/env python3
"""
P0: Disassemble descriptor init at 0x8007A340 and crash site at 0x800761DC.
Find what writes the bad descriptor base to 0x800D9A70.
"""
import struct
import sys

EXE_PATH = r"..\translation\SLUSP012.06"
LOAD_ADDR = 0x80017F00
EXE_HDR_SIZE = 0x800  # PS-X EXE header is 2048 bytes

def ram_to_file(ram_addr):
    return ram_addr - LOAD_ADDR + EXE_HDR_SIZE

def file_to_ram(file_off):
    return file_off + LOAD_ADDR - EXE_HDR_SIZE

def read_exe(path):
    with open(path, "rb") as f:
        return f.read()

# MIPS R3000A disassembler (simplified, enough for our purposes)
REG_NAMES = ["$zero","$at","$v0","$v1","$a0","$a1","$a2","$a3",
             "$t0","$t1","$t2","$t3","$t4","$t5","$t6","$t7",
             "$s0","$s1","$s2","$s3","$s4","$s5","$s6","$s7",
             "$t8","$t9","$k0","$k1","$gp","$sp","$fp","$ra"]

def sign_extend16(v):
    return v - 0x10000 if v & 0x8000 else v

def disasm_one(word, pc):
    op = (word >> 26) & 0x3F
    rs = (word >> 21) & 0x1F
    rt = (word >> 16) & 0x1F
    rd = (word >> 11) & 0x1F
    shamt = (word >> 6) & 0x1F
    funct = word & 0x3F
    imm = word & 0xFFFF
    simm = sign_extend16(imm)
    target = word & 0x3FFFFFF

    if op == 0x00:  # SPECIAL
        if funct == 0x20: return f"add {REG_NAMES[rd]}, {REG_NAMES[rs]}, {REG_NAMES[rt]}"
        if funct == 0x21: return f"addu {REG_NAMES[rd]}, {REG_NAMES[rs]}, {REG_NAMES[rt]}"
        if funct == 0x22: return f"sub {REG_NAMES[rd]}, {REG_NAMES[rs]}, {REG_NAMES[rt]}"
        if funct == 0x23: return f"subu {REG_NAMES[rd]}, {REG_NAMES[rs]}, {REG_NAMES[rt]}"
        if funct == 0x24: return f"and {REG_NAMES[rd]}, {REG_NAMES[rs]}, {REG_NAMES[rt]}"
        if funct == 0x25: return f"or  {REG_NAMES[rd]}, {REG_NAMES[rs]}, {REG_NAMES[rt]}"
        if funct == 0x26: return f"xor {REG_NAMES[rd]}, {REG_NAMES[rs]}, {REG_NAMES[rt]}"
        if funct == 0x27: return f"nor {REG_NAMES[rd]}, {REG_NAMES[rs]}, {REG_NAMES[rt]}"
        if funct == 0x2A: return f"slt {REG_NAMES[rd]}, {REG_NAMES[rs]}, {REG_NAMES[rt]}"
        if funct == 0x2B: return f"sltu {REG_NAMES[rd]}, {REG_NAMES[rs]}, {REG_NAMES[rt]}"
        if funct == 0x00: 
            if word == 0: return "nop"
            return f"sll {REG_NAMES[rd]}, {REG_NAMES[rt]}, {shamt}"
        if funct == 0x02: return f"srl {REG_NAMES[rd]}, {REG_NAMES[rt]}, {shamt}"
        if funct == 0x03: return f"sra {REG_NAMES[rd]}, {REG_NAMES[rt]}, {shamt}"
        if funct == 0x04: return f"sllv {REG_NAMES[rd]}, {REG_NAMES[rt]}, {REG_NAMES[rs]}"
        if funct == 0x06: return f"srlv {REG_NAMES[rd]}, {REG_NAMES[rt]}, {REG_NAMES[rs]}"
        if funct == 0x07: return f"srav {REG_NAMES[rd]}, {REG_NAMES[rt]}, {REG_NAMES[rs]}"
        if funct == 0x08: return f"jr {REG_NAMES[rs]}"
        if funct == 0x09: return f"jalr {REG_NAMES[rd]}, {REG_NAMES[rs]}"
        if funct == 0x0C: return f"syscall 0x{(word >> 6) & 0xFFFFF:05x}"
        if funct == 0x10: return f"mfhi {REG_NAMES[rd]}"
        if funct == 0x12: return f"mflo {REG_NAMES[rd]}"
        if funct == 0x11: return f"mthi {REG_NAMES[rs]}"
        if funct == 0x13: return f"mtlo {REG_NAMES[rs]}"
        if funct == 0x18: return f"mult {REG_NAMES[rs]}, {REG_NAMES[rt]}"
        if funct == 0x19: return f"multu {REG_NAMES[rs]}, {REG_NAMES[rt]}"
        if funct == 0x1A: return f"div {REG_NAMES[rs]}, {REG_NAMES[rt]}"
        if funct == 0x1B: return f"divu {REG_NAMES[rs]}, {REG_NAMES[rt]}"
        return f".special 0x{funct:02x}"

    if op == 0x01:  # REGIMM
        if rt == 0x00: return f"bltz {REG_NAMES[rs]}, 0x{pc + 4 + simm*4:08X}"
        if rt == 0x01: return f"bgez {REG_NAMES[rs]}, 0x{pc + 4 + simm*4:08X}"
        if rt == 0x10: return f"bltzal {REG_NAMES[rs]}, 0x{pc + 4 + simm*4:08X}"
        if rt == 0x11: return f"bgezal {REG_NAMES[rs]}, 0x{pc + 4 + simm*4:08X}"
        return f".regimm 0x{rt:02x}"

    if op == 0x02: return f"j 0x{(pc & 0xF0000000) | (target << 2):08X}"
    if op == 0x03: return f"jal 0x{(pc & 0xF0000000) | (target << 2):08X}"
    if op == 0x04: return f"beq {REG_NAMES[rs]}, {REG_NAMES[rt]}, 0x{pc + 4 + simm*4:08X}"
    if op == 0x05: return f"bne {REG_NAMES[rs]}, {REG_NAMES[rt]}, 0x{pc + 4 + simm*4:08X}"
    if op == 0x06: return f"blez {REG_NAMES[rs]}, 0x{pc + 4 + simm*4:08X}"
    if op == 0x07: return f"bgtz {REG_NAMES[rs]}, 0x{pc + 4 + simm*4:08X}"
    if op == 0x08: return f"addi {REG_NAMES[rt]}, {REG_NAMES[rs]}, {simm}"
    if op == 0x09: return f"addiu {REG_NAMES[rt]}, {REG_NAMES[rs]}, {simm}"
    if op == 0x0A: return f"slti {REG_NAMES[rt]}, {REG_NAMES[rs]}, {simm}"
    if op == 0x0B: return f"sltiu {REG_NAMES[rt]}, {REG_NAMES[rs]}, {simm}"
    if op == 0x0C: return f"andi {REG_NAMES[rt]}, {REG_NAMES[rs]}, 0x{imm:04X}"
    if op == 0x0D: return f"ori {REG_NAMES[rt]}, {REG_NAMES[rs]}, 0x{imm:04X}"
    if op == 0x0E: return f"xori {REG_NAMES[rt]}, {REG_NAMES[rs]}, 0x{imm:04X}"
    if op == 0x0F: return f"lui {REG_NAMES[rt]}, 0x{imm:04X}"
    if op == 0x20: return f"lb {REG_NAMES[rt]}, {simm}({REG_NAMES[rs]})"
    if op == 0x21: return f"lh {REG_NAMES[rt]}, {simm}({REG_NAMES[rs]})"
    if op == 0x23: return f"lw {REG_NAMES[rt]}, {simm}({REG_NAMES[rs]})"
    if op == 0x24: return f"lbu {REG_NAMES[rt]}, {simm}({REG_NAMES[rs]})"
    if op == 0x25: return f"lhu {REG_NAMES[rt]}, {simm}({REG_NAMES[rs]})"
    if op == 0x28: return f"sb {REG_NAMES[rt]}, {simm}({REG_NAMES[rs]})"
    if op == 0x29: return f"sh {REG_NAMES[rt]}, {simm}({REG_NAMES[rs]})"
    if op == 0x2B: return f"sw {REG_NAMES[rt]}, {simm}({REG_NAMES[rs]})"
    if op == 0x30: return f"lwc2 $f{rt}, {simm}({REG_NAMES[rs]})"
    if op == 0x38: return f"swc2 $f{rt}, {simm}({REG_NAMES[rs]})"
    if op == 0x10: return f"cop0 mfc0 {REG_NAMES[rt]}, ${rd}"
    if op == 0x11: return f"cop1"
    if op == 0x12: return f"cop2"
    if op == 0x40: return f"mfc0 {REG_NAMES[rt]}, ${rd}"
    if op == 0x48: return f"mtc0 {REG_NAMES[rt]}, ${rd}"
    return f".word 0x{word:08X}"

def disasm_range(data, start_ram, count, label=""):
    start_file = ram_to_file(start_ram)
    print(f"\n{'='*80}")
    print(f"  {label}: RAM 0x{start_ram:08X} (file offset 0x{start_file:X})")
    print(f"{'='*80}")
    for i in range(count):
        off = start_file + i * 4
        if off + 4 > len(data):
            print(f"  0x{start_ram + i*4:08X}:  <out of range>")
            continue
        word = struct.unpack_from("<I", data, off)[0]
        pc = start_ram + i * 4
        asm = disasm_one(word, pc)
        marker = ""
        # Highlight sw to 0x800D9A70
        if (word >> 26) == 0x2B:  # sw
            rs = (word >> 21) & 0x1F
            simm = sign_extend16(word & 0xFFFF)
            # We don't know register values yet, but flag all sw instructions
            marker = "  <-- SW"
        print(f"  0x{pc:08X}: {word:08X}  {asm}{marker}")

def find_sw_to_address(data, target_ram):
    """Find all sw instructions that could write to target_ram address."""
    target_low16 = target_ram & 0xFFFF
    target_hi = (target_ram >> 16) & 0xFFFF
    # For lui/addiu pattern: lui $r, hi; sw $rt, lo($r)
    # or lui $r, hi+1 if lo is negative
    results = []
    exe_data_start = EXE_HDR_SIZE
    exe_data_end = len(data)
    
    for off in range(exe_data_start, exe_data_end - 4, 4):
        word = struct.unpack_from("<I", data, off)[0]
        op = (word >> 26) & 0x3F
        if op != 0x2B:  # sw
            continue
        simm = sign_extend16(word & 0xFFFF)
        rs = (word >> 21) & 0x1F
        rt = (word >> 16) & 0x1F
        ram = file_to_ram(off)
        
        # Check if this sw could target our address with common base registers
        # Look backwards for lui that sets rs
        for back in range(1, 32):
            prev_off = off - back * 4
            if prev_off < exe_data_start:
                break
            prev_word = struct.unpack_from("<I", data, prev_off)[0]
            prev_op = (prev_word >> 26) & 0x3F
            if prev_op == 0x0F:  # lui
                prev_rt = (prev_word >> 16) & 0x1F
                prev_imm = prev_word & 0xFFFF
                if prev_rt == rs:
                    base = (prev_imm << 16) + simm
                    if base == target_ram:
                        results.append({
                            'sw_ram': ram,
                            'sw_off': off,
                            'lui_ram': file_to_ram(prev_off),
                            'lui_off': prev_off,
                            'base_reg': REG_NAMES[rs],
                            'val_reg': REG_NAMES[rt],
                            'lui_imm': prev_imm,
                            'sw_imm': simm,
                        })
                    break  # Found the lui for this rs
            # Also check addiu pattern
            if prev_op == 0x09:  # addiu
                prev_rt = (prev_word >> 16) & 0x1F
                if prev_rt == rs:
                    break  # addiu sets rs, stop looking
    
    return results

def find_all_sw_to_descriptor_base(data):
    """Search for sw targeting 0x800D9A70 using lui+sw pattern."""
    target = 0x800D9A70
    print(f"\n{'='*80}")
    print(f"  Searching for sw instructions targeting 0x{target:08X}")
    print(f"{'='*80}")
    
    hits = find_sw_to_address(data, target)
    if not hits:
        # Also try with +1 adjusted hi (for negative lo)
        # 0x800D9A70: hi=0x800D, lo=0x9A70 (positive, no adjustment needed)
        # But also try 0x800E + (-0x6590) = 0x800D9A70
        target2_hi = 0x800E
        target2_lo = sign_extend16(0x10000 - 0x6590)  # = -0x6590
        # Actually let's just scan more broadly
        print("  No direct lui+sw hits. Trying broader scan...")
        # Scan for any sw with imm matching low 16 bits of target
        target_lo16 = target & 0xFFFF
        exe_data_start = EXE_HDR_SIZE
        for off in range(exe_data_start, len(data) - 4, 4):
            word = struct.unpack_from("<I", data, off)[0]
            op = (word >> 26) & 0x3F
            if op == 0x2B and (word & 0xFFFF) == target_lo16:
                ram = file_to_ram(off)
                rs = (word >> 21) & 0x1F
                rt = (word >> 16) & 0x1F
                simm = sign_extend16(word & 0xFFFF)
                print(f"  POTENTIAL: 0x{ram:08X} sw {REG_NAMES[rt]}, {simm}({REG_NAMES[rs]})")
    else:
        for h in hits:
            print(f"\n  MATCH FOUND:")
            print(f"    lui at 0x{h['lui_ram']:08X}: lui {h['base_reg']}, 0x{h['lui_imm']:04X}")
            print(f"    sw   at 0x{h['sw_ram']:08X}: sw {h['val_reg']}, {h['sw_imm']}({h['base_reg']})")
            print(f"    => writes {h['val_reg']} to 0x{target:08X}")
            # Disassemble around the sw to see context
            disasm_range(data, h['lui_ram'] - 20, 40, f"Context around sw to 0x{target:08X}")

def find_lui_addiu_chains(data, target_ram):
    """Find lui/addiu pairs that compute target_ram, then find sw using that register."""
    target_hi = (target_ram >> 16) & 0xFFFF
    target_lo = target_ram & 0xFFFF
    target_lo_signed = sign_extend16(target_lo)
    
    print(f"\n{'='*80}")
    print(f"  Searching for lui/addiu pairs computing 0x{target_ram:08X}")
    print(f"  (hi=0x{target_hi:04X}, lo=0x{target_lo:04X} signed={target_lo_signed})")
    print(f"{'='*80}")
    
    exe_data_start = EXE_HDR_SIZE
    pairs = []
    
    for off in range(exe_data_start, len(data) - 8, 4):
        word = struct.unpack_from("<I", data, off)[0]
        op = (word >> 26) & 0x3F
        if op != 0x0F:  # lui
            continue
        rt = (word >> 16) & 0x1F
        imm = word & 0xFFFF
        if imm != target_hi:
            continue
        # Check next few instructions for addiu with matching lo
        for i in range(1, 8):
            next_off = off + i * 4
            if next_off + 4 > len(data):
                break
            next_word = struct.unpack_from("<I", data, next_off)[0]
            next_op = (next_word >> 26) & 0x3F
            if next_op == 0x09:  # addiu
                next_rt = (next_word >> 16) & 0x1F
                next_rs = (next_word >> 21) & 0x1F
                next_imm = sign_extend16(next_word & 0xFFFF)
                if next_rt == rt and next_rs == rt and next_imm == target_lo_signed:
                    ram = file_to_ram(off)
                    pairs.append({
                        'lui_ram': ram,
                        'addiu_ram': file_to_ram(next_off),
                        'reg': REG_NAMES[rt],
                    })
                    break
    
    print(f"  Found {len(pairs)} lui/addiu pairs computing 0x{target_ram:08X}")
    for p in pairs:
        print(f"    0x{p['lui_ram']:08X}: lui {p['reg']}, 0x{target_hi:04X}")
        print(f"    0x{p['addiu_ram']:08X}: addiu {p['reg']}, {p['reg']}, {target_lo_signed}")
        
        # Now find sw using this register nearby
        for search_off in range(EXE_HDR_SIZE, len(data) - 4, 4):
            word = struct.unpack_from("<I", data, search_off)[0]
            op = (word >> 26) & 0x3F
            if op != 0x2B:  # sw
                continue
            rs = (word >> 21) & 0x1F
            if REG_NAMES[rs] != p['reg']:
                continue
            simm = sign_extend16(word & 0xFFFF)
            sw_ram = file_to_ram(search_off)
            # Check if this sw targets 0x800D9A70
            if simm == 0:  # sw $rt, 0($reg) where reg = 0x800D9A70
                rt = (word >> 16) & 0x1F
                print(f"      => sw {REG_NAMES[rt]}, 0({p['reg']}) at 0x{sw_ram:08X}")
                # Disassemble context
                disasm_range(data, sw_ram - 40, 30, f"Context: sw to descriptor base via {p['reg']}")

def scan_for_descriptor_refs(data):
    """Broad scan for any instruction referencing 0x800D9A70 or nearby descriptor addresses."""
    targets = [
        (0x800D9A28, "descriptor table start / bump base"),
        (0x800D9A38, "descriptor struct A"),
        (0x800D9A40, "descriptor A+8 (base pointer)"),
        (0x800D9A48, "descriptor A+16"),
        (0x800D9A50, "descriptor A+24"),
        (0x800D9A68, "descriptor struct B"),
        (0x800D9A70, "descriptor B+8 (base -> crash)"),
    ]
    
    print(f"\n{'='*80}")
    print(f"  Broad scan for references to descriptor table addresses")
    print(f"{'='*80}")
    
    for target, desc in targets:
        hits = find_sw_to_address(data, target)
        if hits:
            print(f"\n  0x{target:08X} ({desc}):")
            for h in hits:
                print(f"    lui at 0x{h['lui_ram']:08X} + sw at 0x{h['sw_ram']:08X}: sw {h['val_reg']}, {h['sw_imm']}({h['base_reg']})")

def main():
    print("Loading DW7 EXE...")
    data = read_exe(EXE_PATH)
    print(f"  Size: {len(data)} bytes (0x{len(data):X})")
    print(f"  Load address: 0x{LOAD_ADDR:08X}")
    print(f"  EXE header: {EXE_HDR_SIZE} bytes")
    print(f"  Text range: 0x{file_to_ram(EXE_HDR_SIZE):08X} - 0x{file_to_ram(len(data)):08X}")
    
    # 1. Disassemble crash site at 0x800761DC
    disasm_range(data, 0x800761DC - 32, 64, "CRASH SITE: descriptor table walk at 0x800761DC")
    
    # 2. Disassemble descriptor init at 0x8007A340
    disasm_range(data, 0x8007A340, 80, "DESCRIPTOR INIT: 0x8007A340")
    
    # 3. Find all sw instructions targeting 0x800D9A70
    find_all_sw_to_descriptor_base(data)
    
    # 4. Find lui/addiu chains computing descriptor addresses
    find_lui_addiu_chains(data, 0x800D9A70)
    find_lui_addiu_chains(data, 0x800D9A68)
    find_lui_addiu_chains(data, 0x800D9A40)
    
    # 5. Broad scan for all descriptor table references
    scan_for_descriptor_refs(data)
    
    # 6. Also check what's at 0x800D9A70 in the EXE (BSS region — should be zeros)
    desc_off = ram_to_file(0x800D9A70)
    if desc_off < len(data):
        words = struct.unpack_from("<8I", data, desc_off)
        print(f"\n{'='*80}")
        print(f"  EXE data at 0x800D9A70 (file offset 0x{desc_off:X}):")
        print(f"  {' '.join(f'{w:08X}' for w in words)}")
    else:
        print(f"\n  0x800D9A70 is beyond EXE data (file offset 0x{desc_off:X} > 0x{len(data):X})")
        print(f"  This address is in BSS (uninitialized) — value set at runtime")
    
    # 7. Disassemble around 0x80075430 (ID->struct lookup mentioned in BSS gap doc)
    disasm_range(data, 0x80075430, 60, "ID->struct lookup at 0x80075430")

if __name__ == "__main__":
    main()
