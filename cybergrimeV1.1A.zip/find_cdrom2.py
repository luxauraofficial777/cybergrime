#!/usr/bin/env python3
"""Focused: disassemble around jal 0x800A2808 calls and find CD-ROM register access."""
import struct

disc_path = r"C:\LuxAura\VoidWalkers_Project\DQLOSTTRANSLATION\build_staging\dq4_gold.bin"
SECTOR_SIZE = 2352
USER_SIZE = 2048
EXE_LBA = 24
HEADER = 24
LOAD_ADDR = 0x80017F00

with open(disc_path, "rb") as f:
    disc = f.read()

def read_exe_from_disc(disc, start_lba, exe_size):
    exe = bytearray()
    sectors_needed = (exe_size + USER_SIZE - 1) // USER_SIZE
    for i in range(sectors_needed):
        sec_start = (start_lba + i) * SECTOR_SIZE + HEADER
        chunk = disc[sec_start:sec_start + USER_SIZE]
        exe.extend(chunk)
    return bytes(exe[:exe_size])

exe = read_exe_from_disc(disc, EXE_LBA, 677888)

REGS = ["$zero","$at","$v0","$v1","$a0","$a1","$a2","$a3",
        "$t0","$t1","$t2","$t3","$t4","$t5","$t6","$t7",
        "$s0","$s1","$s2","$s3","$s4","$s5","$s6","$s7",
        "$t8","$t9","$k0","$k1","$gp","$sp","$fp","$ra"]

def decode_mips(word, addr):
    op = (word >> 26) & 0x3F
    rs = (word >> 21) & 0x1F
    rt = (word >> 16) & 0x1F
    rd = (word >> 11) & 0x1F
    shamt = (word >> 6) & 0x1F
    funct = word & 0x3F
    imm = word & 0xFFFF
    simm = imm if imm < 0x8000 else imm - 0x10000
    target = word & 0x3FFFFFF
    if op == 0:
        if funct == 0x20: return f"add {REGS[rd]}, {REGS[rs]}, {REGS[rt]}"
        if funct == 0x21: return f"addu {REGS[rd]}, {REGS[rs]}, {REGS[rt]}"
        if funct == 0x23: return f"subu {REGS[rd]}, {REGS[rs]}, {REGS[rt]}"
        if funct == 0x24: return f"and {REGS[rd]}, {REGS[rs]}, {REGS[rt]}"
        if funct == 0x25: return f"or {REGS[rd]}, {REGS[rs]}, {REGS[rt]}"
        if funct == 0x26: return f"xor {REGS[rd]}, {REGS[rs]}, {REGS[rt]}"
        if funct == 0x27: return f"nor {REGS[rd]}, {REGS[rs]}, {REGS[rt]}"
        if funct == 0x2A: return f"slt {REGS[rd]}, {REGS[rs]}, {REGS[rt]}"
        if funct == 0x2B: return f"sltu {REGS[rd]}, {REGS[rs]}, {REGS[rt]}"
        if funct == 0x00: return f"sll {REGS[rd]}, {REGS[rt]}, {shamt}"
        if funct == 0x03: return f"sra {REGS[rd]}, {REGS[rt]}, {shamt}"
        if funct == 0x07: return f"srav {REGS[rd]}, {REGS[rt]}, {REGS[rs]}"
        if funct == 0x04: return f"sllv {REGS[rd]}, {REGS[rt]}, {REGS[rs]}"
        if funct == 0x06: return f"srlv {REGS[rd]}, {REGS[rt]}, {REGS[rs]}"
        if funct == 0x08: return f"jr {REGS[rs]}"
        if funct == 0x09: return f"jalr {REGS[rd]}, {REGS[rs]}"
        if funct == 0x0C: return f"syscall"
        if funct == 0x10: return f"mfhi {REGS[rd]}"
        if funct == 0x12: return f"mflo {REGS[rd]}"
        if funct == 0x18: return f"mult {REGS[rs]}, {REGS[rt]}"
        if funct == 0x19: return f"multu {REGS[rs]}, {REGS[rt]}"
        if funct == 0x1A: return f"div {REGS[rs]}, {REGS[rt]}"
        if funct == 0x1B: return f"divu {REGS[rs]}, {REGS[rt]}"
        return f".word 0x{word:08X}"
    if op == 0x01:
        if rt == 0x00: return f"bltz {REGS[rs]}, 0x{(addr + 4 + simm*4):08X}"
        if rt == 0x01: return f"bgez {REGS[rs]}, 0x{(addr + 4 + simm*4):08X}"
        return f".word 0x{word:08X}"
    if op == 0x02: return f"j 0x{(target << 2):08X}"
    if op == 0x03: return f"jal 0x{(target << 2):08X}"
    if op == 0x04: return f"beq {REGS[rs]}, {REGS[rt]}, 0x{(addr + 4 + simm*4):08X}"
    if op == 0x05: return f"bne {REGS[rs]}, {REGS[rt]}, 0x{(addr + 4 + simm*4):08X}"
    if op == 0x06: return f"blez {REGS[rs]}, 0x{(addr + 4 + simm*4):08X}"
    if op == 0x07: return f"bgtz {REGS[rs]}, 0x{(addr + 4 + simm*4):08X}"
    if op == 0x08: return f"addi {REGS[rt]}, {REGS[rs]}, {simm}"
    if op == 0x09: return f"addiu {REGS[rt]}, {REGS[rs]}, {simm}"
    if op == 0x0A: return f"slti {REGS[rt]}, {REGS[rs]}, {simm}"
    if op == 0x0B: return f"sltiu {REGS[rt]}, {REGS[rs]}, {simm}"
    if op == 0x0C: return f"andi {REGS[rt]}, {REGS[rs]}, 0x{imm:04X}"
    if op == 0x0D: return f"ori {REGS[rt]}, {REGS[rs]}, 0x{imm:04X}"
    if op == 0x0E: return f"xori {REGS[rt]}, {REGS[rs]}, 0x{imm:04X}"
    if op == 0x0F: return f"lui {REGS[rt]}, 0x{imm:04X}"
    if op == 0x20: return f"lb {REGS[rt]}, {simm}({REGS[rs]})"
    if op == 0x21: return f"lh {REGS[rt]}, {simm}({REGS[rs]})"
    if op == 0x23: return f"lw {REGS[rt]}, {simm}({REGS[rs]})"
    if op == 0x24: return f"lbu {REGS[rt]}, {simm}({REGS[rs]})"
    if op == 0x25: return f"lhu {REGS[rt]}, {simm}({REGS[rs]})"
    if op == 0x28: return f"sb {REGS[rt]}, {simm}({REGS[rs]})"
    if op == 0x29: return f"sh {REGS[rt]}, {simm}({REGS[rs]})"
    if op == 0x2B: return f"sw {REGS[rt]}, {simm}({REGS[rs]})"
    return f".word 0x{word:08X}"

def disasm_range(exe, start_ram, end_ram, markers=None):
    if markers is None: markers = {}
    start_off = start_ram - LOAD_ADDR
    end_off = end_ram - LOAD_ADDR
    for i in range(start_off & ~3, end_off, 4):
        if i < 0 or i + 4 > len(exe): continue
        word = struct.unpack("<I", exe[i:i+4])[0]
        ram = i + LOAD_ADDR
        asm = decode_mips(word, ram)
        marker = markers.get(ram, "")
        print(f"  0x{ram:08X}: {word:08X}  {asm}{marker}")

# 1. Disassemble around the two jal 0x800A2808 calls
for call_ram in [0x800A2C68, 0x800A2CF8]:
    print(f"\n=== Context around jal at 0x{call_ram:08X} ===")
    markers = {call_ram: " <-- jal call"}
    disasm_range(exe, call_ram - 128, call_ram + 64, markers)

# 2. CD-ROM register access (lui $reg, 0xBF80)
print(f"\n=== lui $reg, 0xBF80 (CD-ROM register access) ===")
for i in range(0, len(exe) - 4, 4):
    word = struct.unpack("<I", exe[i:i+4])[0]
    op = (word >> 26) & 0x3F
    rt = (word >> 16) & 0x1F
    imm = word & 0xFFFF
    if op == 0x0F and imm == 0xBF80:
        ram = i + LOAD_ADDR
        print(f"  0x{ram:08X}: lui {REGS[rt]}, 0x{imm:04X}")

# 3. Search for B0 function dispatch via addiu $t1, $zero, N + jr 0xB0
# The game might inline the B0 dispatch instead of calling the stub
# Pattern: addiu $t2, $zero, 0xB0 (0x240A00B0) ... jr $t2 (0x01400008)
# with addiu $t1, $zero, 7 in the delay slot
print(f"\n=== Inline B0(07) dispatch: addiu $t2, $zero, 0xB0 ===")
pat_t2_b0 = struct.pack("<I", 0x240A00B0)
idx = 0
while True:
    idx = exe.find(pat_t2_b0, idx)
    if idx == -1: break
    ram = idx + LOAD_ADDR
    # Check if next instruction is jr $t2
    if idx + 8 <= len(exe):
        next_word = struct.unpack("<I", exe[idx+4:idx+8])[0]
        if next_word == 0x01400008:  # jr $t2
            # Check delay slot for function number
            if idx + 12 <= len(exe):
                ds_word = struct.unpack("<I", exe[idx+8:idx+12])[0]
                ds_imm = ds_word & 0xFFFF
                ds_op = (ds_word >> 26) & 0x3F
                func = ds_imm if ds_op == 0x09 else -1
                if func == 7:
                    print(f"  0x{ram:08X}: B0(07) Setloc dispatch! ctx: {exe[idx:idx+16].hex()}")
    idx += 1

# 4. The game might call B0 functions through a function pointer table
# Search for 0x800A28F8 as a 32-bit value in the EXE (function pointer)
setloc_stub = 0x800A28F8
ptr_pat = struct.pack("<I", setloc_stub)
idx = 0
print(f"\n=== Searching for 0x{setloc_stub:08X} as pointer in EXE ===")
while True:
    idx = exe.find(ptr_pat, idx)
    if idx == -1: break
    ram = idx + LOAD_ADDR
    print(f"  0x{ram:08X}: .word 0x{setloc_stub:08X}")
    idx += 1

# 5. Search for the actual CD-ROM command writing code
# CD-ROM command register at 0xBF801019 (or 0xBF801020)
# sb $reg, 0x19($s0) where $s0 = 0xBF801000
# or sw to 0xBF801018
print(f"\n=== Searching for sb to offset 0x19 (CD-ROM cmd reg) ===")
for i in range(0, len(exe) - 4, 4):
    word = struct.unpack("<I", exe[i:i+4])[0]
    op = (word >> 26) & 0x3F
    if op == 0x28:  # sb
        imm = word & 0xFFFF
        simm = imm if imm < 0x8000 else imm - 0x10000
        if simm == 0x19:
            ram = i + LOAD_ADDR
            rs = (word >> 21) & 0x1F
            rt = (word >> 16) & 0x1F
            print(f"  0x{ram:08X}: sb {REGS[rt]}, 0x19({REGS[rs]})")
