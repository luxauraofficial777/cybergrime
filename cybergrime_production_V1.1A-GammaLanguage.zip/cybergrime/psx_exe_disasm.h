#pragma once
#include <cstdint>
#include <cstring>
#include <cstdio>
#include <unordered_map>
#include <string>
#include <vector>

// ===== DW7 EXE Disassembler with Symbol Map =====
// Decodes MIPS R3000A instructions and annotates with known DW7 symbols.
// Used for crash diagnosis, CD-ROM call chain analysis, and patch verification.

struct SymbolEntry {
    uint32_t addr;
    char name[48];
    char category[16];  // "cdrom", "event", "thread", "patch", "func"
};

class ExeDisassembler {
public:
    std::unordered_map<uint32_t, SymbolEntry> symbols;
    uint32_t load_addr;

    ExeDisassembler() : load_addr(0x80017F00) {
        register_dw7_symbols();
    }

    void register_dw7_symbols() {
        // CD-ROM driver routines (from DW7_RE_Study_extracted.txt)
        add_sym(0x80076040, "cd_filesystem_init", "cdrom");
        add_sym(0x80076400, "cd_open_file", "cdrom");
        add_sym(0x80077000, "cd_read_sectors", "cdrom");
        add_sym(0x80078000, "cd_seek", "cdrom");
        add_sym(0x80078400, "cd_getstat", "cdrom");
        add_sym(0x80078800, "cd_setloc", "cdrom");
        add_sym(0x80078C00, "cd_command_dispatch", "cdrom");
        add_sym(0x80079000, "disc_check_main", "cdrom");
        add_sym(0x8007902C, "disc_check_exit1", "patch");
        add_sym(0x800790D4, "disc_check_exit2", "patch");
        add_sym(0x800792BC, "disc_check_exit3", "patch");
        add_sym(0x800793A4, "disc_check_timeout", "patch");
        add_sym(0x800793F8, "disc_check_error", "patch");
        add_sym(0x80079324, "graft_a_gate1", "patch");
        add_sym(0x80079420, "graft_b_gate3", "patch");
        add_sym(0x80079260, "graft_c_string_cmp", "patch");

        // CD-ROM command write and event loop
        add_sym(0x80098664, "cdrom_cmd_write", "cdrom");
        add_sym(0x800986A8, "cdrom_event_flag_check", "cdrom");
        add_sym(0x800986B0, "cdrom_testevent_poll", "cdrom");
        add_sym(0x800986E0, "cdrom_event_wait_loop", "cdrom");
        add_sym(0x80098848, "cdrom_copy_loop", "cdrom");
        add_sym(0x80098898, "cdrom_post_cmd_branch", "cdrom");

        // Thread and BSS
        add_sym(0x8008E284, "pc0_entry", "thread");
        add_sym(0x800BC668, "bss_clear_start", "thread");
        add_sym(0x800BCCC8, "bss_clear_end_narrow", "thread");
        add_sym(0x800F4980, "bss_clear_end_full", "thread");
        add_sym(0x800D9E80, "cdrom_thread_entry", "thread");

        // Huffman tree
        add_sym(0x800EF1C8, "huffman_tree_original", "tree");
        add_sym(0x800BC700, "huffman_tree_inplace", "tree");
        add_sym(0x80096FA0, "huffman_tree_in_exe", "tree");

        // Disc-check bypass
        add_sym(0x8008B08C, "disc_trap_redirect", "patch");
        add_sym(0x80079028, "disc_check_bne_exit1", "patch");
        add_sym(0x800790D4, "disc_check_bne_exit2", "patch");

        // Event system
        add_sym(0x80096650, "event_poll_loop", "event");
        add_sym(0x80096700, "main_game_loop", "event");

        // FMV / STR playback
        add_sym(0x80082480, "sound_stream_start", "fmv");
        add_sym(0x800849D4, "sound_stream_end", "fmv");

        // Key RAM locations
        add_sym(0x800B679C, "cdrom_event_flag_ram", "cdrom");
        add_sym(0x800D5190, "loading_complete_flag", "cdrom");
    }

    void add_sym(uint32_t addr, const char* name, const char* category) {
        SymbolEntry e;
        e.addr = addr;
        strncpy(e.name, name, sizeof(e.name) - 1);
        strncpy(e.category, category, sizeof(e.category) - 1);
        e.name[sizeof(e.name) - 1] = '\0';
        e.category[sizeof(e.category) - 1] = '\0';
        symbols[addr] = e;
    }

    const char* lookup(uint32_t addr) const {
        auto it = symbols.find(addr);
        return (it != symbols.end()) ? it->second.name : nullptr;
    }

    const char* lookup_category(uint32_t addr) const {
        auto it = symbols.find(addr);
        return (it != symbols.end()) ? it->second.category : nullptr;
    }

    struct DisasmEntry {
        uint32_t addr;
        uint32_t raw;
        char text[80];
    };

    static void decode_reg(char* buf, int reg) {
        static const char* names[32] = {
            "zero", "at", "v0", "v1", "a0", "a1", "a2", "a3",
            "t0", "t1", "t2", "t3", "t4", "t5", "t6", "t7",
            "s0", "s1", "s2", "s3", "s4", "s5", "s6", "s7",
            "t8", "t9", "k0", "k1", "gp", "sp", "fp", "ra",
        };
        snprintf(buf, 8, "$%s", names[reg & 31]);
    }

    // Disassemble a single MIPS word at given RAM address
    static DisasmEntry disasm_one(uint32_t addr, uint32_t word) {
        DisasmEntry e;
        e.addr = addr;
        e.raw = word;

        int opcode = (word >> 26) & 0x3F;
        int rs = (word >> 21) & 0x1F;
        int rt = (word >> 16) & 0x1F;
        int rd = (word >> 11) & 0x1F;
        int shamt = (word >> 6) & 0x1F;
        int funct = word & 0x3F;
        int imm_raw = word & 0xFFFF;
        int imm = (imm_raw & 0x8000) ? (imm_raw - 0x10000) : imm_raw;

        char rs_buf[8], rt_buf[8], rd_buf[8];
        decode_reg(rs_buf, rs);
        decode_reg(rt_buf, rt);
        decode_reg(rd_buf, rd);

        switch (opcode) {
            case 0x00: // SPECIAL
                switch (funct) {
                    case 0x00: snprintf(e.text, sizeof(e.text), "sll %s, %s, %d", rd_buf, rt_buf, shamt); break;
                    case 0x02: snprintf(e.text, sizeof(e.text), "srl %s, %s, %d", rd_buf, rt_buf, shamt); break;
                    case 0x03: snprintf(e.text, sizeof(e.text), "sra %s, %s, %d", rd_buf, rt_buf, shamt); break;
                    case 0x08: snprintf(e.text, sizeof(e.text), "jr %s", rs_buf); break;
                    case 0x09: snprintf(e.text, sizeof(e.text), "jalr %s, %s", rd_buf, rs_buf); break;
                    case 0x0C: snprintf(e.text, sizeof(e.text), "syscall 0x%05X", (word >> 6) & 0xFFFFF); break;
                    case 0x0D: snprintf(e.text, sizeof(e.text), "break 0x%05X", (word >> 6) & 0xFFFFF); break;
                    case 0x10: snprintf(e.text, sizeof(e.text), "mfhi %s", rd_buf); break;
                    case 0x12: snprintf(e.text, sizeof(e.text), "mflo %s", rd_buf); break;
                    case 0x18: snprintf(e.text, sizeof(e.text), "mult %s, %s", rs_buf, rt_buf); break;
                    case 0x19: snprintf(e.text, sizeof(e.text), "multu %s, %s", rs_buf, rt_buf); break;
                    case 0x1A: snprintf(e.text, sizeof(e.text), "div %s, %s", rs_buf, rt_buf); break;
                    case 0x1B: snprintf(e.text, sizeof(e.text), "divu %s, %s", rs_buf, rt_buf); break;
                    case 0x20: snprintf(e.text, sizeof(e.text), "add %s, %s, %s", rd_buf, rs_buf, rt_buf); break;
                    case 0x21: snprintf(e.text, sizeof(e.text), "addu %s, %s, %s", rd_buf, rs_buf, rt_buf); break;
                    case 0x22: snprintf(e.text, sizeof(e.text), "sub %s, %s, %s", rd_buf, rs_buf, rt_buf); break;
                    case 0x23: snprintf(e.text, sizeof(e.text), "subu %s, %s, %s", rd_buf, rs_buf, rt_buf); break;
                    case 0x24: snprintf(e.text, sizeof(e.text), "and %s, %s, %s", rd_buf, rs_buf, rt_buf); break;
                    case 0x25: snprintf(e.text, sizeof(e.text), "or %s, %s, %s", rd_buf, rs_buf, rt_buf); break;
                    case 0x26: snprintf(e.text, sizeof(e.text), "xor %s, %s, %s", rd_buf, rs_buf, rt_buf); break;
                    case 0x27: snprintf(e.text, sizeof(e.text), "nor %s, %s, %s", rd_buf, rs_buf, rt_buf); break;
                    case 0x2A: snprintf(e.text, sizeof(e.text), "slt %s, %s, %s", rd_buf, rs_buf, rt_buf); break;
                    case 0x2B: snprintf(e.text, sizeof(e.text), "sltu %s, %s, %s", rd_buf, rs_buf, rt_buf); break;
                    default: snprintf(e.text, sizeof(e.text), "special 0x%02X", funct); break;
                }
                break;
            case 0x01: { // REGIMM
                int bt = addr + 4 + (imm << 2);
                if (rt == 0) snprintf(e.text, sizeof(e.text), "bltz %s, 0x%08X", rs_buf, bt);
                else if (rt == 1) snprintf(e.text, sizeof(e.text), "bgez %s, 0x%08X", rs_buf, bt);
                else snprintf(e.text, sizeof(e.text), "regimm_%d %s, 0x%08X", rt, rs_buf, bt);
                break;
            }
            case 0x02: { // J
                uint32_t tgt = (word & 0x3FFFFFF) << 2;
                tgt |= (addr + 4) & 0xF0000000;
                snprintf(e.text, sizeof(e.text), "j 0x%08X", tgt);
                break;
            }
            case 0x03: { // JAL
                uint32_t tgt = (word & 0x3FFFFFF) << 2;
                tgt |= (addr + 4) & 0xF0000000;
                snprintf(e.text, sizeof(e.text), "jal 0x%08X", tgt);
                break;
            }
            case 0x04: { int bt = addr + 4 + (imm << 2); snprintf(e.text, sizeof(e.text), "beq %s, %s, 0x%08X", rs_buf, rt_buf, bt); break; }
            case 0x05: { int bt = addr + 4 + (imm << 2); snprintf(e.text, sizeof(e.text), "bne %s, %s, 0x%08X", rs_buf, rt_buf, bt); break; }
            case 0x06: { int bt = addr + 4 + (imm << 2); snprintf(e.text, sizeof(e.text), "blez %s, 0x%08X", rs_buf, bt); break; }
            case 0x07: { int bt = addr + 4 + (imm << 2); snprintf(e.text, sizeof(e.text), "bgtz %s, 0x%08X", rs_buf, bt); break; }
            case 0x08: snprintf(e.text, sizeof(e.text), "addi %s, %s, %d", rt_buf, rs_buf, imm); break;
            case 0x09: snprintf(e.text, sizeof(e.text), "addiu %s, %s, %d", rt_buf, rs_buf, imm); break;
            case 0x0A: snprintf(e.text, sizeof(e.text), "slti %s, %s, %d", rt_buf, rs_buf, imm); break;
            case 0x0B: snprintf(e.text, sizeof(e.text), "sltiu %s, %s, %d", rt_buf, rs_buf, imm); break;
            case 0x0C: snprintf(e.text, sizeof(e.text), "andi %s, %s, 0x%04X", rt_buf, rs_buf, imm_raw); break;
            case 0x0D: snprintf(e.text, sizeof(e.text), "ori %s, %s, 0x%04X", rt_buf, rs_buf, imm_raw); break;
            case 0x0E: snprintf(e.text, sizeof(e.text), "xori %s, %s, 0x%04X", rt_buf, rs_buf, imm_raw); break;
            case 0x0F: snprintf(e.text, sizeof(e.text), "lui %s, 0x%04X", rt_buf, imm_raw); break;
            case 0x10: snprintf(e.text, sizeof(e.text), "cop0 0x%08X", word); break;
            case 0x20: snprintf(e.text, sizeof(e.text), "lb %s, %d(%s)", rt_buf, imm, rs_buf); break;
            case 0x21: snprintf(e.text, sizeof(e.text), "lh %s, %d(%s)", rt_buf, imm, rs_buf); break;
            case 0x23: snprintf(e.text, sizeof(e.text), "lw %s, %d(%s)", rt_buf, imm, rs_buf); break;
            case 0x24: snprintf(e.text, sizeof(e.text), "lbu %s, %d(%s)", rt_buf, imm, rs_buf); break;
            case 0x25: snprintf(e.text, sizeof(e.text), "lhu %s, %d(%s)", rt_buf, imm, rs_buf); break;
            case 0x28: snprintf(e.text, sizeof(e.text), "sb %s, %d(%s)", rt_buf, imm, rs_buf); break;
            case 0x29: snprintf(e.text, sizeof(e.text), "sh %s, %d(%s)", rt_buf, imm, rs_buf); break;
            case 0x2B: snprintf(e.text, sizeof(e.text), "sw %s, %d(%s)", rt_buf, imm, rs_buf); break;
            default: snprintf(e.text, sizeof(e.text), ".word 0x%08X", word); break;
        }
        return e;
    }

    // Disassemble a range of bytes from EXE data
    void disasm_range(FILE* f, const uint8_t* exe_data, uint32_t exe_size,
                      uint32_t ram_addr, uint32_t byte_count) const {
        uint32_t file_off = ram_addr - load_addr + 0x800;
        if (file_off >= exe_size) {
            fprintf(f, "  [ERROR: offset 0x%X beyond EXE size 0x%X]\n", file_off, exe_size);
            return;
        }

        fprintf(f, "\n  === Disassembly: 0x%08X - 0x%08X ===\n", ram_addr, ram_addr + byte_count);
        for (uint32_t i = 0; i < byte_count; i += 4) {
            if (file_off + i + 4 > exe_size) break;
            uint32_t word = *(uint32_t*)(exe_data + file_off + i);
            uint32_t addr = ram_addr + i;

            DisasmEntry e = disasm_one(addr, word);
            const char* sym = lookup(addr);
            if (sym) {
                fprintf(f, "  0x%08X: %08X  %-40s ; %s\n", addr, word, e.text, sym);
            } else {
                fprintf(f, "  0x%08X: %08X  %s\n", addr, word, e.text);
            }
        }
    }

    // Disassemble around a crash point (16 instructions before and after)
    void disasm_around_crash(FILE* f, const uint8_t* exe_data, uint32_t exe_size,
                              uint32_t crash_addr) const {
        uint32_t start = (crash_addr - 64) & ~3;
        uint32_t count = 160;  // 40 instructions
        disasm_range(f, exe_data, exe_size, start, count);
    }

    // Dump all known symbols grouped by category
    void dump_symbols(FILE* f) const {
        fprintf(f, "\n=== DW7 Symbol Map (%zu symbols) ===\n", symbols.size());
        const char* cats[] = {"cdrom", "event", "thread", "patch", "tree", "fmv", "func"};
        for (const char* cat : cats) {
            fprintf(f, "\n  [%s]\n", cat);
            for (const auto& p : symbols) {
                if (strcmp(p.second.category, cat) == 0) {
                    fprintf(f, "    0x%08X  %s\n", p.second.addr, p.second.name);
                }
            }
        }
    }
};
