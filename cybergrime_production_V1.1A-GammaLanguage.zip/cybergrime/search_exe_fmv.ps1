# Search the DW7 EXE for all possible encodings of FMV LBA/MSF
# The EXE is small (~680KB) so this will be fast
$exePath = 'c:\LuxAura\VoidWalkers_Project\DQLOSTTRANSLATION\translation\SLUSP012.06'
$bytes = [System.IO.File]::ReadAllBytes($exePath)
$loadAddr = 0x80017F00

Write-Host "EXE size: $($bytes.Length) bytes"

# 1. BCD MSF 32:34:71 = 0x32 0x34 0x71 (already found at 0x92936, patched)
Write-Host "`n=== BCD 32 34 71 ==="
for ($i = 0; $i -lt $bytes.Length - 2; $i++) {
    if ($bytes[$i] -eq 0x32 -and $bytes[$i+1] -eq 0x34 -and $bytes[$i+2] -eq 0x71) {
        $ram = $loadAddr + $i - 0x800
        Write-Host ("  file 0x{0:X} RAM 0x{1:X8}" -f $i, $ram)
    }
}

# 2. Binary MSF: 32, 34, 71 = 0x20 0x22 0x47
Write-Host "`n=== Binary MSF 32,34,71 (0x20 0x22 0x47) ==="
for ($i = 0; $i -lt $bytes.Length - 2; $i++) {
    if ($bytes[$i] -eq 0x20 -and $bytes[$i+1] -eq 0x22 -and $bytes[$i+2] -eq 0x47) {
        $ram = $loadAddr + $i - 0x800
        Write-Host ("  file 0x{0:X} RAM 0x{1:X8}" -f $i, $ram)
    }
}

# 3. LBA as 32-bit LE: 146621 = 0x00023C7D
Write-Host "`n=== 146621 (0x23C7D) as 32-bit LE ==="
for ($i = 0; $i -lt $bytes.Length - 3; $i++) {
    if ($bytes[$i] -eq 0x7D -and $bytes[$i+1] -eq 0x3C -and $bytes[$i+2] -eq 0x02 -and $bytes[$i+3] -eq 0x00) {
        $ram = $loadAddr + $i - 0x800
        Write-Host ("  file 0x{0:X} RAM 0x{1:X8}" -f $i, $ram)
    }
}

# 4. LBA-150 = 146471 = 0x00023C47
Write-Host "`n=== 146471 (0x23C47) as 32-bit LE ==="
for ($i = 0; $i -lt $bytes.Length - 3; $i++) {
    if ($bytes[$i] -eq 0x47 -and $bytes[$i+1] -eq 0x3C -and $bytes[$i+2] -eq 0x02 -and $bytes[$i+3] -eq 0x00) {
        $ram = $loadAddr + $i - 0x800
        Write-Host ("  file 0x{0:X} RAM 0x{1:X8}" -f $i, $ram)
    }
}

# 5. Search for li $rt, 0x32 (addiu $rt, $zero, 0x32 = 0x24020032)
# This would be used to load BCD minute value
Write-Host "`n=== li \$rt, 0x32 (BCD minute 32) ==="
for ($i = 0x800; $i -lt $bytes.Length - 3; $i += 4) {
    $insn = [BitConverter]::ToUInt32($bytes, $i)
    if ($insn -eq 0x24020032 -or $insn -eq 0x24030032 -or $insn -eq 0x24040032 -or $insn -eq 0x24050032) {
        $ram = $loadAddr + $i - 0x800
        $next = [BitConverter]::ToUInt32($bytes, $i + 4)
        Write-Host ("  RAM 0x{0:X8}: 0x{1:X8} next=0x{2:X8}" -f $ram, $insn, $next)
    }
}

# 6. Search for li $rt, 0x71 (BCD frame 71)
Write-Host "`n=== li \$rt, 0x71 (BCD frame 71) ==="
for ($i = 0x800; $i -lt $bytes.Length - 3; $i += 4) {
    $insn = [BitConverter]::ToUInt32($bytes, $i)
    if (($insn -band 0xFFFF0000) -eq 0x24000000 -and ($insn -band 0x0000FFFF) -eq 0x00000071) {
        $ram = $loadAddr + $i - 0x800
        $prev = [BitConverter]::ToUInt32($bytes, $i - 4)
        $next = [BitConverter]::ToUInt32($bytes, $i + 4)
        Write-Host ("  RAM 0x{0:X8}: 0x{1:X8} prev=0x{2:X8} next=0x{3:X8}" -f $ram, $insn, $prev, $next)
    }
}

# 7. Search for 0x32 as immediate in any instruction (broader)
Write-Host "`n=== Instructions with immediate 0x0032 (BCD 32) ==="
$count = 0
for ($i = 0x800; $i -lt $bytes.Length - 3; $i += 4) {
    $insn = [BitConverter]::ToUInt32($bytes, $i)
    if (($insn -band 0x0000FFFF) -eq 0x00000032) {
        $ram = $loadAddr + $i - 0x800
        $prev = [BitConverter]::ToUInt32($bytes, $i - 4)
        $next = [BitConverter]::ToUInt32($bytes, $i + 4)
        Write-Host ("  RAM 0x{0:X8}: 0x{1:X8} prev=0x{2:X8} next=0x{3:X8}" -f $ram, $insn, $prev, $next)
        $count++
        if ($count -ge 20) { Write-Host "  ... truncated"; break }
    }
}

# 8. The value might be stored as two 16-bit halves in lui/addiu
# lui $rt, 0x0002; addiu $rt, $rt, 0x3C7D -> 0x00023C7D = 146621
# or lui $rt, 0x0002; addiu $rt, $rt, 0x3C47 -> 0x00023C47 = 146471
Write-Host "`n=== lui 0x0002 + addiu 0x3C7D or 0x3C47 ==="
for ($i = 0x800; $i -lt $bytes.Length - 7; $i += 4) {
    $insn1 = [BitConverter]::ToUInt32($bytes, $i)
    $insn2 = [BitConverter]::ToUInt32($bytes, $i + 4)
    if (($insn1 -shr 26) -eq 0x0F -and ($insn1 -band 0x0000FFFF) -eq 0x0002) {
        $imm2 = $insn2 -band 0x0000FFFF
        if ($imm2 -eq 0x3C7D -or $imm2 -eq 0x3C47) {
            $ram = $loadAddr + $i - 0x800
            Write-Host ("  RAM 0x{0:X8}: lui 0x{1:X8} + 0x{2:X8} (imm=0x{3:X4})" -f $ram, $insn1, $insn2, $imm2)
        }
    }
}

# 9. Maybe the value is in a table of 4-byte entries. Search for 146621 or 146471
# as 16-bit values: 0x3C7D or 0x3C47
Write-Host "`n=== 16-bit 0x3C7D (146621 low) or 0x3C47 (146471 low) ==="
for ($i = 0x800; $i -lt $bytes.Length - 1; $i += 2) {
    $val = [BitConverter]::ToUInt16($bytes, $i)
    if ($val -eq 0x3C7D -or $val -eq 0x3C47) {
        $ram = $loadAddr + $i - 0x800
        $context = [BitConverter]::ToUInt32($bytes, [Math]::Max($i - 2, 0))
        Write-Host ("  file 0x{0:X} RAM 0x{1:X8}: 0x{2:X4} (context32=0x{3:X8})" -f $i, $ram, $val, $context)
    }
}
