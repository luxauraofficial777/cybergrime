#!/usr/bin/env python3
"""
1. Verify BCD patch on disc by reading EXE sector-by-sector
2. Find FMV playback function by searching for Setmode 0xA0 instruction
3. Disassemble surrounding code to find the FMV call site
"""
import struct

SECTOR_SIZE = 2352
USER_SIZE = 2048
EXE_LBA = 24
HEADER = 24  # sync(12) + header(4) + subheader(8) = 24
LOAD_ADDR = 0x80017F00

disc_path = r"C:\LuxAura\VoidWalkers_Project\DQLOSTTRANSLATION\build_staging\dq4_gold.bin"
clean_path = r"C:\LuxAura\VoidWalkers_Project\DQLOSTTRANSLATION\translation\SLUSP012.06_clean.bin"

with open(disc_path, "rb") as f:
    disc = f.read()
with open(clean_path, "rb") as f:
    clean = f.read()

# Read EXE from disc sector by sector
def read_exe_from_disc(disc, start_lba, exe_size):
    exe = bytearray()
    sectors_needed = (exe_size + USER_SIZE - 1) // USER_SIZE
    for i in range(sectors_needed):
        sec_start = (start_lba + i) * SECTOR_SIZE + HEADER
        chunk = disc[sec_start:sec_start + USER_SIZE]
        exe.extend(chunk)
    return bytes(exe[:exe_size])

disc_exe = read_exe_from_disc(disc, EXE_LBA, 677888)
print(f"Disc EXE (sector-by-sector): {len(disc_exe)} bytes")
print(f"Clean EXE: {len(clean)} bytes")

# Check BCD patch
FMV_BCD_OFFSET = 0x092936
print(f"\n=== BCD patch verification ===")
print(f"Clean EXE at 0x{FMV_BCD_OFFSET:06X}: {clean[FMV_BCD_OFFSET:FMV_BCD_OFFSET+3].hex()}")
print(f"Disc EXE at 0x{FMV_BCD_OFFSET:06X}:  {disc_exe[FMV_BCD_OFFSET:FMV_BCD_OFFSET+3].hex()}")
print(f"Expected (patched): 233108")

# Search for BCD 32:34:71 in disc EXE
pat = bytes([0x32, 0x34, 0x71])
idx = 0
matches = []
while True:
    idx = disc_exe.find(pat, idx)
    if idx == -1: break
    matches.append(idx)
    idx += 1
print(f"\nBCD 32:34:71 in disc EXE: {len(matches)} matches")
for m in matches:
    print(f"  0x{m:06X} (RAM 0x{m+LOAD_ADDR:08X}) ctx: {disc_exe[m-8:m+11].hex()}")

# Search for BCD 23:31:08 in disc EXE
pat2 = bytes([0x23, 0x31, 0x08])
idx = 0
matches2 = []
while True:
    idx = disc_exe.find(pat2, idx)
    if idx == -1: break
    matches2.append(idx)
    idx += 1
print(f"BCD 23:31:08 in disc EXE: {len(matches2)} matches")
for m in matches2:
    print(f"  0x{m:06X} (RAM 0x{m+LOAD_ADDR:08X}) ctx: {disc_exe[m-8:m+11].hex()}")

# Compare clean vs disc EXE to find all differences
print(f"\n=== EXE differences (clean vs disc) ===")
diff_count = 0
diff_regions = []
i = 0
while i < min(len(clean), len(disc_exe)):
    if clean[i] != disc_exe[i]:
        start = i
        while i < min(len(clean), len(disc_exe)) and clean[i] != disc_exe[i]:
            i += 1
        diff_regions.append((start, i))
        diff_count += (i - start)
    else:
        i += 1

print(f"Total different bytes: {diff_count} in {len(diff_regions)} regions")
for start, end in diff_regions[:30]:
    ram = start + LOAD_ADDR
    clean_hex = clean[start:min(end,start+16)].hex()
    disc_hex = disc_exe[start:min(end,start+16)].hex()
    print(f"  0x{start:06X}-0x{end:06X} (RAM 0x{ram:08X}) len={end-start}: clean={clean_hex} disc={disc_hex}")

# Search for Setmode 0xA0 instruction: addiu $a0, $zero, 0xA0 = 0x240400A0
print(f"\n=== Searching for Setmode 0xA0 (0x240400A0) ===")
setmode_pat = struct.pack("<I", 0x240400A0)
idx = 0
setmode_matches = []
while True:
    idx = disc_exe.find(setmode_pat, idx)
    if idx == -1: break
    setmode_matches.append(idx)
    idx += 1
print(f"Found {len(setmode_matches)} matches")
for m in setmode_matches:
    ram = m + LOAD_ADDR
    print(f"  0x{m:06X} (RAM 0x{ram:08X})")

# Also search for ori $a0, $zero, 0xA0 = 0x340400A0
setmode_pat2 = struct.pack("<I", 0x340400A0)
idx = 0
while True:
    idx = disc_exe.find(setmode_pat2, idx)
    if idx == -1: break
    ram = idx + LOAD_ADDR
    print(f"  ori: 0x{idx:06X} (RAM 0x{ram:08X})")
    idx += 1

# Search for li $a0, 0xA0 via lui+ori
# lui $a0, 0x0000 = 0x3C040000; ori $a0, $a0, 0x00A0 = 0x348400A0
# This is unlikely but check anyway

# Also search for the BCD 0x32 being loaded as an immediate
# addiu $reg, $zero, 0x32 = 0x240?0032
print(f"\n=== Searching for addiu $reg, $zero, 0x32 (BCD minute) ===")
for reg in range(32):
    insn = 0x24000032 | (reg << 16)
    pat = struct.pack("<I", insn)
    idx = 0
    while True:
        idx = disc_exe.find(pat, idx)
        if idx == -1: break
        ram = idx + LOAD_ADDR
        reg_name = ["$zero","$at","$v0","$v1","$a0","$a1","$a2","$a3",
                    "$t0","$t1","$t2","$t3","$t4","$t5","$t6","$t7",
                    "$s0","$s1","$s2","$s3","$s4","$s5","$s6","$s7",
                    "$t8","$t9","$k0","$k1","$gp","$sp","$fp","$ra"][reg]
        # Check if 0x34 and 0x71 are loaded nearby (within 32 instructions = 128 bytes)
        nearby_34 = False
        nearby_71 = False
        for off in range(-128, 128, 4):
            if idx + off < 0 or idx + off + 4 > len(disc_exe):
                continue
            w = struct.unpack("<I", disc_exe[idx+off:idx+off+4])[0]
            if (w & 0xFFFF) == 0x0034 and ((w >> 26) == 0x09):  # addiu with imm 0x34
                nearby_34 = True
            if (w & 0xFFFF) == 0x0071 and ((w >> 26) == 0x09):  # addiu with imm 0x71
                nearby_71 = True
        if nearby_34 or nearby_71:
            print(f"  0x{idx:06X} (RAM 0x{ram:08X}) addiu {reg_name}, $zero, 0x32  {'[near 0x34]' if nearby_34 else ''} {'[near 0x71]' if nearby_71 else ''}")
        idx += 1
