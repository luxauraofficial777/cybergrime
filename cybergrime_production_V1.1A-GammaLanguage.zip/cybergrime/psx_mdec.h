#pragma once

// ============================================================================
// PSX MDEC — Motion Decoder
// Decodes JPEG-like macroblocks (RLE + IQ + IDCT + YUV→RGB) and feeds
// them to VRAM via DMA channel 1. Header-only, dependency-free.
// Adapted from Nocash PSXspec and DuckStation MDEC logic.
// ============================================================================

#include <cstdint>
#include <cstring>
#include <cmath>
#ifndef M_PI
#define M_PI 3.14159265358979323846
#endif

class PSX_MDEC {
public:
    static constexpr int BLOCK_SIZE = 8;          // 8x8 DCT block
    static constexpr int MB_PIXELS = 16 * 16;     // Macroblock = 16x16
    static constexpr int IQ_TABLE_SIZE = 64;
    static constexpr int DCT_SIZE = 64;

    // MDEC command register bits
    enum Command : uint32_t {
        CMD_DECODE = 0x30000000,
        CMD_QUANT = 0x20000000,
        CMD_IDCT = 0x1F000000,
    };

    // State
    uint32_t command;
    uint32_t status;
    uint32_t control;
    bool busy;
    bool data_in_ready;
    bool data_out_ready;
    bool color_mode;        // false = 15bpp, true = 24bpp

    // Quantization tables (luminance + chrominance)
    uint8_t iq_luma[IQ_TABLE_SIZE];
    uint8_t iq_chroma[IQ_TABLE_SIZE];
    uint16_t scale[IQ_TABLE_SIZE]; // Scale table

    // Input/output buffers
    uint32_t input_fifo[256];
    int input_count;
    int input_pos;

    uint16_t output_buffer[MB_PIXELS * 3]; // RGB555 per pixel (16x16)
    int output_count;

    // Current macroblock decode state
    int16_t dct_blocks[6][DCT_SIZE]; // 4 Y + 1 Cb + 1 Cr
    int current_block;
    int current_coeff;

    // DMA destination (VRAM address for DMA ch1)
    uint32_t dma_dest;
    bool dma_active;

    PSX_MDEC() { reset(); }

    void reset() {
        command = 0;
        status = 0x80000000; // Ready
        control = 0;
        busy = false;
        data_in_ready = false;
        data_out_ready = false;
        color_mode = false;
        memset(iq_luma, 0, sizeof(iq_luma));
        memset(iq_chroma, 0, sizeof(iq_chroma));
        memset(scale, 0, sizeof(scale));
        memset(input_fifo, 0, sizeof(input_fifo));
        input_count = 0;
        input_pos = 0;
        memset(output_buffer, 0, sizeof(output_buffer));
        output_count = 0;
        memset(dct_blocks, 0, sizeof(dct_blocks));
        current_block = 0;
        current_coeff = 0;
        dma_dest = 0;
        dma_active = false;

        // Default quantization tables (standard JPEG)
        static const uint8_t default_iq_luma[64] = {
            2,16,19,22,26,27,29,34,
            16,16,22,24,27,29,34,37,
            19,22,26,27,29,34,34,38,
            22,22,26,27,29,34,37,40,
            22,26,27,29,32,35,40,48,
            26,27,29,32,35,40,48,56,
            27,29,34,37,40,48,56,64,
            29,34,37,40,48,56,64,78
        };
        static const uint8_t default_iq_chroma[64] = {
            2,19,26,27,29,34,37,40,
            19,26,27,29,34,37,40,48,
            26,27,29,34,37,40,48,56,
            27,29,34,37,40,48,56,64,
            29,34,37,40,48,56,64,72,
            34,37,40,48,56,64,72,80,
            37,40,48,56,64,72,80,88,
            40,48,56,64,72,80,88,96
        };
        memcpy(iq_luma, default_iq_luma, 64);
        memcpy(iq_chroma, default_iq_chroma, 64);
        for (int i = 0; i < 64; i++) scale[i] = 8;
    }

    // --- Register interface (0x1F801820-0x1F80182F) ---
    uint32_t read_reg(uint32_t addr) {
        switch (addr & 0xF) {
            case 0x0: // Data out
                if (output_count > 0) {
                    return output_buffer[--output_count] | (output_buffer[--output_count] << 16);
                }
                return 0;
            case 0x4: // Status
                return status;
            default:
                return 0;
        }
    }

    void write_reg(uint32_t addr, uint32_t val) {
        switch (addr & 0xF) {
            case 0x0: // Data in
                input_fifo[input_count++ & 0xFF] = val;
                if ((command & 0xFF000000) == CMD_DECODE) {
                    // Accumulate data for decode
                    if (input_count >= 32) {
                        decode_macroblock();
                    }
                }
                break;
            case 0x4: // Command/control
                command = val;
                if ((val & 0xFF000000) == CMD_QUANT) {
                    // Load quantization table
                    int table = (val >> 24) & 1;
                    for (int i = 0; i < 32 && i < input_count; i++) {
                        uint32_t w = input_fifo[i];
                        if (table == 0) {
                            iq_luma[i * 2] = w & 0xFF;
                            iq_luma[i * 2 + 1] = (w >> 8) & 0xFF;
                        } else {
                            iq_chroma[i * 2] = w & 0xFF;
                            iq_chroma[i * 2 + 1] = (w >> 8) & 0xFF;
                        }
                    }
                    input_count = 0;
                } else if ((val & 0xFF000000) == CMD_DECODE) {
                    busy = true;
                    status &= ~0x80000000;
                    color_mode = (val >> 25) & 1;
                    input_count = 0;
                    output_count = 0;
                    current_block = 0;
                    current_coeff = 0;
                }
                break;
        }
    }

    // --- Macroblock decode ---
    void decode_macroblock() {
        // Decode 6 DCT blocks: 4 Y, 1 Cb, 1 Cr
        // Each block: RLE decode → dequantize → IDCT → YUV→RGB

        for (int blk = 0; blk < 6; blk++) {
            int16_t block[64];
            memset(block, 0, sizeof(block));

            // RLE decode from input FIFO (simplified — real MDEC uses bitstream)
            // DC coefficient
            if (input_pos < input_count) {
                block[0] = (int16_t)(input_fifo[input_pos++] & 0xFFFF);
            }

            // AC coefficients (RLE encoded — simplified)
            while (input_pos < input_count) {
                uint32_t w = input_fifo[input_pos++];
                uint8_t run = (w >> 10) & 0x3F;
                uint8_t level = w & 0x3FF;
                if (run == 0 && level == 0) break; // EOB
                current_coeff += run + 1;
                if (current_coeff < 64) {
                    block[current_coeff] = (int16_t)(level > 511 ? level - 1024 : level);
                }
            }

            // Dequantize
            const uint8_t* iq = (blk < 4) ? iq_luma : iq_chroma;
            for (int i = 0; i < 64; i++) {
                block[i] = (int16_t)(block[i] * iq[i] * scale[i] / 8);
            }

            // IDCT (2D inverse DCT)
            idct_2d(block);

            // Store decoded block
            memcpy(dct_blocks[blk], block, sizeof(block));
        }

        // Convert YUV→RGB and fill output buffer
        yuv_to_rgb();

        input_count = 0;
        input_pos = 0;
        output_count = MB_PIXELS; // 256 pixels
        busy = false;
        status |= 0x80000000; // Ready
    }

    // 2D Inverse DCT (8x8)
    void idct_2d(int16_t block[64]) {
        double tmp[64];

        // Row-wise IDCT
        for (int y = 0; y < 8; y++) {
            for (int x = 0; x < 8; x++) {
                double sum = 0.0;
                for (int u = 0; u < 8; u++) {
                    double cu = (u == 0) ? 1.0 / sqrt(2.0) : 1.0;
                    sum += cu * block[y * 8 + u] *
                           cos((2.0 * x + 1.0) * u * M_PI / 16.0);
                }
                tmp[y * 8 + x] = sum * 0.5;
            }
        }

        // Column-wise IDCT
        for (int x = 0; x < 8; x++) {
            for (int y = 0; y < 8; y++) {
                double sum = 0.0;
                for (int v = 0; v < 8; v++) {
                    double cv = (v == 0) ? 1.0 / sqrt(2.0) : 1.0;
                    sum += cv * tmp[v * 8 + x] *
                           cos((2.0 * y + 1.0) * v * M_PI / 16.0);
                }
                block[y * 8 + x] = (int16_t)(sum * 0.5);
            }
        }
    }

    // YUV 4:2:0 → RGB555 conversion for 16x16 macroblock
    void yuv_to_rgb() {
        for (int py = 0; py < 16; py++) {
            for (int px = 0; px < 16; px++) {
                int blk = (py / 8) * 2 + (px / 8);
                int bx = px % 8;
                int by = py % 8;

                int16_t y = dct_blocks[blk][by * 8 + bx];
                int16_t cb = dct_blocks[4][(py / 2) * 8 + (px / 2)];
                int16_t cr = dct_blocks[5][(py / 2) * 8 + (px / 2)];

                // YUV→RGB
                int r = (int)(y + 1.402 * (cr - 128));
                int g = (int)(y - 0.344 * (cb - 128) - 0.714 * (cr - 128));
                int b = (int)(y + 1.772 * (cb - 128));

                // Clamp
                r = r < 0 ? 0 : (r > 255 ? 255 : r);
                g = g < 0 ? 0 : (g > 255 ? 255 : g);
                b = b < 0 ? 0 : (b > 255 ? 255 : b);

                // RGB555
                output_buffer[py * 16 + px] = (uint16_t)((r >> 3) | ((g >> 3) << 5) | ((b >> 3) << 10));
            }
        }
    }

    // Check if MDEC has data ready for DMA
    bool has_output() const { return output_count > 0; }

    // Read one output word for DMA
    uint32_t read_dma() {
        if (output_count < 2) return 0;
        uint16_t lo = output_buffer[--output_count];
        uint16_t hi = output_buffer[--output_count];
        return lo | ((uint32_t)hi << 16);
    }
};
