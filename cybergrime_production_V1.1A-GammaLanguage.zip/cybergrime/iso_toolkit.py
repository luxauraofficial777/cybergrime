#!/usr/bin/env python3
"""
CyberGrime ISO Toolkit — Phase 5
Unified ISO9660 manipulation tool for PSX disc images.

Usage:
    python iso_toolkit.py list <iso>
    python iso_toolkit.py extract <iso> <file> <out>
    python iso_toolkit.py inject <iso> <file> <src> <out>
    python iso_toolkit.py patch <iso> <spec.json> <out>
    python iso_toolkit.py edc <iso>
    python iso_toolkit.py diff <a> <b>
    python iso_toolkit.py info <iso>
"""

import json
import os
import struct
import sys
from pathlib import Path

SECTOR_SIZE = 2352
MODE2_FORM1 = 2048
MODE2_FORM2 = 2324
SYNC_HEADER = 12
MODE_HEADER = 4


def read_sector(f, lba, raw=True):
    """Read a sector at LBA. Returns raw 2352 bytes or data payload."""
    f.seek(lba * SECTOR_SIZE)
    data = f.read(SECTOR_SIZE)
    if not raw:
        # Strip sync + header (12+4 bytes) for MODE2
        if len(data) >= 16 and data[15] == 2:
            # MODE2 — check sub-header for form
            sub_mode = data[16 + 2]  # sub-mode byte
            if sub_mode & 0x40:  # FORM2
                return data[24:24 + MODE2_FORM2]
            else:  # FORM1
                return data[24:24 + MODE2_FORM1]
        elif len(data) >= 16 and data[15] == 1:
            # MODE1
            return data[16:16 + 2048]
    return data


def parse_iso9660(f):
    """Parse ISO9660 root directory and return file entries."""
    # Read PVD at LBA 16
    f.seek(16 * SECTOR_SIZE + 16)  # Skip sync+header
    pvd = f.read(2048)
    if pvd[0:5] != b'CD001':
        # Try MODE2
        f.seek(16 * SECTOR_SIZE)
        raw = f.read(SECTOR_SIZE)
        pvd = raw[24:24 + 2048]

    if pvd[0:5] != b'CD001':
        print("ERROR: Not a valid ISO9660 image")
        return []

    # Root directory record at offset 156 in PVD
    root_len = pvd[156]
    root_lba = struct.unpack_from('<I', pvd, 158)[0]
    root_size = struct.unpack_from('<I', pvd, 166)[0]

    entries = []
    _parse_dir(f, root_lba, root_size, "", entries, 0)
    return entries


def _parse_dir(f, dir_lba, dir_size, prefix, entries, depth):
    if depth > 10:
        return

    sectors = (dir_size + 2047) // 2048
    f.seek(dir_lba * SECTOR_SIZE + 24)  # MODE2 data offset
    data = f.read(sectors * 2048)

    offset = 0
    while offset < len(data):
        rec_len = data[offset]
        if rec_len == 0:
            # Padding to sector boundary
            offset = (offset // 2048 + 1) * 2048
            if offset >= len(data):
                break
            continue

        ext_attr = data[offset + 1]
        lba = struct.unpack_from('<I', data, offset + 2)[0]
        size = struct.unpack_from('<I', data, offset + 10)[0]
        flags = data[offset + 25]
        name_len = data[offset + 32]
        name = data[offset + 33:offset + 33 + name_len]

        if name == b'\x00' or name == b'\x01':
            offset += rec_len
            continue

        # Decode name
        name_str = name.decode('ascii', errors='replace').rstrip(';1')

        full_path = f"{prefix}/{name_str}" if prefix else name_str

        if flags & 0x02:  # Directory
            _parse_dir(f, lba, size, full_path, entries, depth + 1)
        else:
            entries.append({
                'name': full_path,
                'lba': lba,
                'size': size,
                'flags': flags,
            })

        offset += rec_len


def cmd_list(iso_path):
    with open(iso_path, 'rb') as f:
        entries = parse_iso9660(f)

    print(f"{'Name':<40} {'LBA':>10} {'Size':>12}")
    print("-" * 64)
    for e in entries:
        size_str = f"{e['size']:,}"
        print(f"{e['name']:<40} {e['lba']:>10} {size_str:>12}")
    print(f"\n{len(entries)} files")


def cmd_info(iso_path):
    file_size = os.path.getsize(iso_path)
    sectors = file_size // SECTOR_SIZE
    with open(iso_path, 'rb') as f:
        f.seek(16 * SECTOR_SIZE + 24)
        pvd = f.read(2048)

    if pvd[0:5] == b'CD001':
        vol_id = pvd[40:72].decode('ascii', errors='replace').strip()
        print(f"File: {iso_path}")
        print(f"Size: {file_size:,} bytes ({sectors} sectors)")
        print(f"Volume ID: {vol_id}")
    else:
        print(f"File: {iso_path}")
        print(f"Size: {file_size:,} bytes ({sectors} sectors)")
        print("Volume ID: <not found>")


def cmd_extract(iso_path, file_name, out_path):
    with open(iso_path, 'rb') as f:
        entries = parse_iso9660(f)

    entry = None
    for e in entries:
        if e['name'].upper() == file_name.upper():
            entry = e
            break

    if not entry:
        print(f"ERROR: File '{file_name}' not found in ISO")
        return 1

    sectors = (entry['size'] + 2047) // 2048
    f.seek(entry['lba'] * SECTOR_SIZE + 24)  # MODE2 data offset
    data = f.read(sectors * 2048)[:entry['size']]

    with open(out_path, 'wb') as out:
        out.write(data)

    print(f"Extracted {file_name} ({entry['size']:,} bytes) to {out_path}")
    return 0


def cmd_diff(iso_a, iso_b):
    size_a = os.path.getsize(iso_a)
    size_b = os.path.getsize(iso_b)

    print(f"Comparing:\n  A: {iso_a} ({size_a:,} bytes)\n  B: {iso_b} ({size_b:,} bytes)")

    if size_a != size_b:
        print(f"  Size difference: {size_b - size_a:+,} bytes")

    min_sectors = min(size_a, size_b) // SECTOR_SIZE
    diff_sectors = 0

    with open(iso_a, 'rb') as fa, open(iso_b, 'rb') as fb:
        for i in range(min_sectors):
            sa = fa.read(SECTOR_SIZE)
            sb = fb.read(SECTOR_SIZE)
            if sa != sb:
                diff_sectors += 1
                if diff_sectors <= 20:
                    # Find first differing byte
                    for j in range(min(len(sa), len(sb))):
                        if sa[j] != sb[j]:
                            print(f"  Sector {i}: first diff at byte {j}: "
                                  f"0x{sa[j]:02X} -> 0x{sb[j]:02X}")
                            break

    print(f"\n  Differing sectors: {diff_sectors}/{min_sectors} "
          f"({diff_sectors/min_sectors*100:.1f}%)")
    return 0


def cmd_edc(iso_path):
    """Regenerate EDC/ECC for all sectors."""
    edcre_path = Path(__file__).parent / "edcre.exe"
    if not edcre_path.exists():
        # Check parent directory
        edcre_path = Path(__file__).parent.parent / "edcre" / "edcre-v1.1.0-windows-x86_64-static" / "edcre.exe"

    if not edcre_path.exists():
        print("ERROR: edcre.exe not found")
        return 1

    import subprocess
    print(f"Regenerating EDC/ECC for {iso_path}...")
    result = subprocess.run([str(edcre_path), iso_path], capture_output=True, text=True)
    if result.returncode == 0:
        print("EDC/ECC regeneration complete")
        return 0
    else:
        print(f"EDC/ECC failed: {result.stderr}")
        return 1


def cmd_patch(iso_path, spec_path, out_path):
    """Apply byte patches from JSON spec."""
    with open(spec_path, 'r') as f:
        spec = json.load(f)

    patches = spec.get('patches', [])

    with open(iso_path, 'rb') as f:
        data = bytearray(f.read())

    applied = 0
    for patch in patches:
        lba = patch.get('lba', 0)
        offset = patch.get('offset', 0)
        sector_offset = lba * SECTOR_SIZE + 24 + offset  # MODE2 data offset
        values = patch.get('bytes', [])

        for i, val in enumerate(values):
            if sector_offset + i < len(data):
                old = data[sector_offset + i]
                data[sector_offset + i] = val & 0xFF
                if old != (val & 0xFF):
                    applied += 1

    with open(out_path, 'wb') as f:
        f.write(data)

    print(f"Patched {applied} bytes, output: {out_path}")
    return 0


def main():
    if len(sys.argv) < 2:
        print(__doc__)
        return 1

    cmd = sys.argv[1]

    if cmd == "list" and len(sys.argv) == 3:
        cmd_list(sys.argv[2])
    elif cmd == "info" and len(sys.argv) == 3:
        cmd_info(sys.argv[2])
    elif cmd == "extract" and len(sys.argv) == 5:
        return cmd_extract(sys.argv[2], sys.argv[3], sys.argv[4])
    elif cmd == "diff" and len(sys.argv) == 4:
        return cmd_diff(sys.argv[2], sys.argv[3])
    elif cmd == "edc" and len(sys.argv) == 3:
        return cmd_edc(sys.argv[2])
    elif cmd == "patch" and len(sys.argv) == 5:
        return cmd_patch(sys.argv[2], sys.argv[3], sys.argv[4])
    else:
        print(__doc__)
        return 1

    return 0


if __name__ == "__main__":
    sys.exit(main())
