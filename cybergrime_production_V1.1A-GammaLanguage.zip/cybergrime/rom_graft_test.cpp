// rom_graft_test.cpp — Test harness for ROM graft verification
//
// Compiles with: g++ -std=c++17 -o rom_graft_test rom_graft_test.cpp
// Run: rom_graft_test.exe dq4_frankenstein_v38a.bin
//
#include "rom_graft_verifier.h"
#include <iostream>
#include <cstdlib>

using namespace rom_graft;

int main(int argc, char* argv[]) {
    if (argc < 2) {
        std::cerr << "Usage: " << argv[0] << " <disc.bin>\n";
        return 1;
    }

    std::string disc_path = argv[1];

    try {
        MasterVerifier verifier(disc_path);

        // Add additional protected regions if needed
        verifier.protected_regions().add_region(
            "custom_overlay", 0x800D0000, 0x800D1000, false);

        // Run the full audit
        verifier.run_full_audit();

        std::cout << "\n✅ ROM graft verification PASSED\n";
        return 0;

    } catch (const std::exception& e) {
        std::cerr << "\n❌ VERIFICATION FAILED: " << e.what() << "\n";
        return 1;
    }
}
