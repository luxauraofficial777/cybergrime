#!/usr/bin/env python3
"""Shared PS-X EXE header parser — single source of truth for all scripts.

Standard PS-X EXE layout (per Sony PSX spec):
  0x00: magic      (8 bytes: "PS-X EXE\0")
  0x08: padding    (8 bytes zeros)
  0x10: pc0        (u32 — initial PC)
  0x14: gp0        (u32 — global pointer)
  0x18: t_addr     (u32 — text load address in RAM)
  0x1C: t_size     (u32 — text size in bytes)
  0x20: s_addr     (u32 — stack/heap base? — varies by toolchain)
  0x24: s_size     (u32 — stack/heap size)
  0x28: padding    (8 bytes zeros)
  0x30: s_addr2    (u32 — BSS/data load address)
  0x34: s_size2    (u32 — BSS/data size)
  0x38: padding    (remaining header to 0x800)
  0x800: text/data begins

NOTE: Many tools in this project mislabeled t_addr as "text_size" and
      t_size as "data_size". This module uses the canonical Sony names.
"""
import struct
from dataclasses import dataclass
from typing import Optional


EXE_HEADER_SIZE = 0x800
MAGIC = b"PS-X EXE\x00"


@dataclass
class PsxExeHeader:
    magic: bytes
    pc0: int          # 0x10 — initial PC
    gp0: int          # 0x14 — global pointer
    t_addr: int       # 0x18 — text load address (RAM)
    t_size: int       # 0x1C — text size (bytes)
    s_addr: int       # 0x20 — stack base
    s_size: int       # 0x24 — stack size
    s_addr2: int      # 0x30 — BSS/data base
    s_size2: int      # 0x34 — BSS/data size

    @property
    def text_end(self) -> int:
        return self.t_addr + self.t_size

    @property
    def is_valid(self) -> bool:
        return self.magic == MAGIC

    def __repr__(self) -> str:
        return (
            f"PsxExeHeader(valid={self.is_valid}, "
            f"pc0=0x{self.pc0:08X}, gp0=0x{self.gp0:08X}, "
            f"t_addr=0x{self.t_addr:08X}, t_size=0x{self.t_size:X} ({self.t_size}), "
            f"s_addr=0x{self.s_addr:08X}, s_size=0x{self.s_size:X}, "
            f"s_addr2=0x{self.s_addr2:08X}, s_size2=0x{self.s_size2:X})"
        )


def parse_header(data: bytes, offset: int = 0) -> PsxExeHeader:
    """Parse a PS-X EXE header from raw bytes.

    Args:
        data: Raw bytes containing the EXE (at least 0x38 bytes after offset).
        offset: Byte offset into data where the header starts.

    Returns:
        PsxExeHeader with parsed fields.

    Raises:
        ValueError if data is too short.
    """
    if len(data) - offset < 0x38:
        raise ValueError(f"Need at least 0x38 bytes after offset {offset}, got {len(data) - offset}")

    magic = bytes(data[offset:offset + 8])
    pc0, gp0, t_addr, t_size = struct.unpack_from('<IIII', data, offset + 0x10)
    s_addr, s_size = struct.unpack_from('<II', data, offset + 0x20)
    s_addr2, s_size2 = struct.unpack_from('<II', data, offset + 0x30)

    return PsxExeHeader(
        magic=magic, pc0=pc0, gp0=gp0,
        t_addr=t_addr, t_size=t_size,
        s_addr=s_addr, s_size=s_size,
        s_addr2=s_addr2, s_size2=s_size2,
    )


def read_exe_from_iso(iso_path: str, exe_lba: int = 24, sector_size: int = 2352,
                      data_offset: int = 24, max_text_size: int = 0x200000) -> tuple[PsxExeHeader, bytes]:
    """Read EXE header + text from an ISO image, sector-by-sector.

    CRITICAL: CD-ROM sectors are 2352 bytes apart, not 2048. Must read
    each sector's user data individually to avoid sync/header garbage.

    Args:
        iso_path: Path to the .bin ISO file.
        exe_lba: LBA of the EXE file (default 24 for standard PSX).
        sector_size: Sector size (default 2352 for MODE2).
        data_offset: Data offset within sector (default 24 for MODE2).
        max_text_size: Maximum text to read (safety cap).

    Returns:
        Tuple of (PsxExeHeader, raw_text_bytes).
    """
    user_size = sector_size - data_offset - 280  # 2048 for MODE2

    def read_sector_user(f, lba):
        f.seek(lba * sector_size + data_offset)
        return f.read(user_size)

    with open(iso_path, 'rb') as f:
        header_data = read_sector_user(f, exe_lba)
        header = parse_header(header_data)

        if not header.is_valid:
            raise ValueError(f"Invalid EXE magic: {header.magic!r}")

        read_size = min(header.t_size, max_text_size)
        text_data = bytearray()
        remaining = read_size
        sector = exe_lba + 1  # text starts in the next sector (after 0x800 header)
        while remaining > 0:
            chunk = read_sector_user(f, sector)
            if not chunk:
                break
            take = min(len(chunk), remaining)
            text_data.extend(chunk[:take])
            remaining -= take
            sector += 1

    return header, bytes(text_data)


def read_exe_from_file(exe_path: str, max_text_size: int = 0x200000) -> tuple[PsxExeHeader, bytes]:
    """Read EXE header + text from a standalone .EXE file.

    Args:
        exe_path: Path to the .EXE file (e.g., SLUSP012.06).
        max_text_size: Maximum text to read (safety cap).

    Returns:
        Tuple of (PsxExeHeader, raw_text_bytes).
    """
    with open(exe_path, 'rb') as f:
        header_data = f.read(EXE_HEADER_SIZE)
        header = parse_header(header_data)

        if not header.is_valid:
            raise ValueError(f"Invalid EXE magic: {header.magic!r}")

        read_size = min(header.t_size, max_text_size)
        text_data = f.read(read_size)

    return header, text_data


def read_word(data: bytes, offset: int) -> int:
    """Read a little-endian 32-bit word from data."""
    return struct.unpack_from('<I', data, offset)[0]


def write_word(data: bytearray, offset: int, value: int) -> None:
    """Write a little-endian 32-bit word to data."""
    struct.pack_into('<I', data, offset, value)


def ram_to_exe_offset(ram_addr: int, header: PsxExeHeader) -> int:
    """Convert a RAM address to an offset within the EXE text section."""
    if ram_addr < header.t_addr or ram_addr >= header.t_addr + header.t_size:
        raise ValueError(
            f"RAM address 0x{ram_addr:08X} is outside text range "
            f"0x{header.t_addr:08X}-0x{header.t_addr + header.t_size:08X}"
        )
    return ram_addr - header.t_addr


def exe_offset_to_ram(exe_offset: int, header: PsxExeHeader) -> int:
    """Convert an EXE text offset to a RAM address."""
    return header.t_addr + exe_offset
