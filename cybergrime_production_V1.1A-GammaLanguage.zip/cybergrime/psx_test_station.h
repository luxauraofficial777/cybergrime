#pragma once

// ============================================================================
// PSX TEST STATION — MIPS R3000A Emulator + CyberGrime Debug UI
// ============================================================================
// Standalone Win32 app for testing Frankenstein ROM builds.
// Emulates PSX MIPS CPU with BIOS stubs, CD-ROM access, and hardware regs.
// ============================================================================

#include <windows.h>

// Verbose logging flag (defined in psx_emulator_core.cpp)
extern bool g_verbose;

// CD-ROM command tracer (defined in psx_emulator_core.cpp)
#include "psx_cdrom_tracer.h"
extern CdromTracer g_cdrom_tracer;

// EXE disassembler with DW7 symbols (defined in psx_emulator_core.cpp)
#include "psx_exe_disasm.h"
extern ExeDisassembler g_disasm;
#include <gdiplus.h>
#include <cstdint>
#include <cstdio>
#include <cstring>
#include <cmath>
#include "psx_gte.h"
#include "psx_reference_integrations.h"

// CD-ROM trace log macro (writes to same file as CDLOG in psx_emulator_core.cpp)
extern FILE* g_cdlog;
extern int g_cdlog_count;
extern FILE* g_diaglog;  // diagnostic log — bypasses harness stdout pipe
static FILE* g_cdlog2 = nullptr;
static int g_cdlog2_count = 0;
#define CDLOG2(fmt, ...) do { \
    if (g_verbose) { \
    if (!g_cdlog2) g_cdlog2 = fopen("cdrom_trace.log", "a"); \
    if (g_cdlog2 && g_cdlog2_count < 5000) { \
        fprintf(g_cdlog2, fmt, ##__VA_ARGS__); \
        g_cdlog2_count++; \
        if (g_cdlog2_count % 100 == 0) fflush(g_cdlog2); \
    } \
    } \
} while(0)
#include <cstdlib>

#pragma comment(lib, "gdiplus.lib")
#pragma comment(lib, "user32.lib")
#pragma comment(lib, "gdi32.lib")

// ── CyberGrime Theme Constants ──────────────────────────────────────────────
namespace CG {
    const uint32_t VOID_BLACK   = 0xFF0A0A0F;
    const uint32_t VOID_DEEP    = 0xFF111118;
    const uint32_t VOID_SURFACE = 0xFF1A1A24;
    const uint32_t VOID_ELEVATED= 0xFF22222E;
    const uint32_t CYAN_GLOW    = 0xFF00D4FF;
    const uint32_t CYAN_DIM     = 0xFF0088AA;
    const uint32_t PURPLE_GLOW  = 0xFFA855F7;
    const uint32_t CRIMSON      = 0xFFFF3366;
    const uint32_t AMBER        = 0xFFF59E0B;
    const uint32_t GREEN        = 0xFF00FF88;
    const uint32_t TEXT_PRIMARY = 0xFFE2E8F0;
    const uint32_t TEXT_SECONDARY= 0xFF94A3B8;
    const uint32_t TEXT_MUTED   = 0xFF475569;
    const uint32_t BORDER       = 0xFF2A2A3A;

    inline uint8_t R(uint32_t c) { return (c >> 16) & 0xFF; }
    inline uint8_t G(uint32_t c) { return (c >> 8) & 0xFF; }
    inline uint8_t B(uint32_t c) { return c & 0xFF; }
    inline uint8_t A(uint32_t c) { return (c >> 24) & 0xFF; }
}

// Forward declarations for globals used in inline methods
class PSX_Memory;
class MIPS_CPU;
extern PSX_Memory* g_mem;
extern MIPS_CPU*   g_cpu;

// ── MIPS R3000A CPU ──────────────────────────────────────────────────────────
class MIPS_CPU {
public:
    uint32_t regs[32];
    uint32_t pc;
    uint32_t hi, lo;
    uint32_t next_pc;       // For delay slot: the PC after the delay slot instruction
    bool in_branch_delay;   // True when executing the instruction after a branch
    uint32_t branch_target; // Where to jump after the delay slot
    bool pending_branch;    // A branch was taken, delay slot is next
    uint64_t instructions;
    bool crashed;
    char crash_reason[256];
    uint64_t vblank_timer;  // Counts instructions for VBlank interrupt simulation

    // CP0 registers for interrupt/exception handling
    uint32_t cp0_status;   // reg 12: bit0=IE, bit2=EXL
    uint32_t cp0_cause;    // reg 13: ExcCode in bits 2-6
    uint32_t cp0_epc;      // reg 14: exception return PC
    bool interrupt_pending; // Set when VBlank fires, checked in step()
    bool bios_set_pc;       // When true, BIOS call already set PC (e.g. ReturnFromException)

    // Callbacks for memory access
    typedef uint32_t (*Read32Fn)(uint32_t addr, void* ctx);
    typedef uint16_t (*Read16Fn)(uint32_t addr, void* ctx);
    typedef uint8_t  (*Read8Fn)(uint32_t addr, void* ctx);
    typedef void     (*Write32Fn)(uint32_t addr, uint32_t val, void* ctx);
    typedef void     (*Write16Fn)(uint32_t addr, uint16_t val, void* ctx);
    typedef void     (*Write8Fn)(uint32_t addr, uint8_t val, void* ctx);

    Read32Fn  read32; Read16Fn read16; Read8Fn read8;
    Write32Fn write32; Write16Fn write16; Write8Fn write8;
    void* mem_ctx;

    // Logging
    static const int MAX_LOG = 65536;
    struct LogEntry {
        uint64_t instr_count;
        uint32_t pc;
        uint32_t raw;
        char desc[80];
        uint32_t regs_snapshot[8]; // first 8 regs
    };
    LogEntry log[MAX_LOG];
    int log_count;
    bool log_enabled;
    FILE* log_file;  // File trace log (psx_trace.log)

    // Breakpoints
    static const int MAX_BP = 16;
    uint32_t breakpoints[MAX_BP];
    int bp_count;
    bool hit_breakpoint;

    // Divergence detection: ring buffer of last 100 meaningful instructions
    // Captures the exact execution path before the ROM goes off-rails
    struct TraceFrame {
        uint64_t instr_count;
        uint32_t pc;
        uint32_t raw_instr;
        uint32_t regs_snapshot[32];  // Full register file
        uint32_t hi, lo;
        uint32_t cp0_status, cp0_cause, cp0_epc;
        char desc[80];
        bool is_bios_call;
        bool is_irq;
    };
    static const int TRACE_RING_SIZE = 65536;
    TraceFrame trace_ring[TRACE_RING_SIZE];
    int trace_ring_head;  // Next write position
    int trace_ring_count; // Number of valid entries

    void trace_ring_push(uint32_t frame_pc, uint32_t raw, const char* frame_desc,
                         bool bios = false, bool irq = false) {
        TraceFrame& f = trace_ring[trace_ring_head];
        f.instr_count = instructions;
        f.pc = frame_pc;
        f.raw_instr = raw;
        for (int i = 0; i < 32; i++) f.regs_snapshot[i] = regs[i];
        f.hi = hi; f.lo = lo;
        f.cp0_status = cp0_status; f.cp0_cause = cp0_cause; f.cp0_epc = cp0_epc;
        if (frame_desc) strncpy(f.desc, frame_desc, 79); else f.desc[0] = 0;
        f.desc[79] = 0;
        f.is_bios_call = bios;
        f.is_irq = irq;
        trace_ring_head = (trace_ring_head + 1) % TRACE_RING_SIZE;
        if (trace_ring_count < TRACE_RING_SIZE) trace_ring_count++;
    }

    void dump_trace_ring(const char* label) {
        printf("\n=== DIVERGENCE TRACE: %s ===\n", label);
        printf("Showing last %d meaningful instructions before divergence:\n\n", trace_ring_count);
        int start = (trace_ring_head - trace_ring_count + TRACE_RING_SIZE) % TRACE_RING_SIZE;
        for (int i = 0; i < trace_ring_count; i++) {
            int idx = (start + i) % TRACE_RING_SIZE;
            TraceFrame& f = trace_ring[idx];
            const char* tag = "";
            if (f.is_bios_call) tag = " [BIOS]";
            if (f.is_irq) tag = " [IRQ]";
            printf("  #%llu PC=0x%08X 0x%08X %s%s\n",
                   f.instr_count, f.pc, f.raw_instr, f.desc, tag);
            // Print key registers on BIOS/IRQ frames or every 16th frame
            if (f.is_bios_call || f.is_irq || (i % 16 == 0) || (i >= trace_ring_count - 8)) {
                printf("    $a0=0x%08X $a1=0x%08X $a2=0x%08X $a3=0x%08X $ra=0x%08X $sp=0x%08X $gp=0x%08X\n",
                       f.regs_snapshot[4], f.regs_snapshot[5], f.regs_snapshot[6],
                       f.regs_snapshot[7], f.regs_snapshot[31], f.regs_snapshot[29], f.regs_snapshot[28]);
                printf("    $v0=0x%08X $v1=0x%08X $t0=0x%08X $t1=0x%08X SR=0x%08X EPC=0x%08X\n",
                       f.regs_snapshot[2], f.regs_snapshot[3], f.regs_snapshot[8],
                       f.regs_snapshot[9], f.cp0_status, f.cp0_epc);
            }
        }
        printf("=== END DIVERGENCE TRACE ===\n\n");
    }

    MIPS_CPU() : read32(nullptr), read16(nullptr), read8(nullptr),
                 write32(nullptr), write16(nullptr), write8(nullptr),
                 mem_ctx(nullptr), log_count(0), log_enabled(true),
                 log_file(nullptr),
                 bp_count(0), hit_breakpoint(false) {
        reset();
    }

    void reset() {
        memset(regs, 0, sizeof(regs));
        pc = 0; next_pc = 0; hi = 0; lo = 0;
        in_branch_delay = false; branch_target = 0;
        pending_branch = false;
        instructions = 0; crashed = false;
        vblank_timer = 0;
        cp0_status = 0x40000000; cp0_cause = 0; cp0_epc = 0; // CU2 enabled
        interrupt_pending = false;
        bios_set_pc = false;
        trace_ring_head = 0;
        trace_ring_count = 0;
        crash_reason[0] = 0;
        log_count = 0; hit_breakpoint = false;
    }

    void open_log(const char* path) {
        if (log_file) fclose(log_file);
        log_file = fopen(path, "w");
    }
    void close_log() {
        if (log_file) { fclose(log_file); log_file = nullptr; }
    }

    void set_reg(int n, uint32_t v) { if (n) regs[n] = v; }
    uint32_t get_reg(int n) const { return n ? regs[n] : 0; }

    static int32_t  sext16(uint16_t v) { return (int32_t)(int16_t)v; }
    static int32_t  sext8(uint8_t v)   { return (int32_t)(int8_t)v; }
    static int32_t  s32(uint32_t v)    { return (int32_t)v; }

    const char* rn(int n) const {
        static const char* names[] = {
            "zero","at","v0","v1","a0","a1","a2","a3",
            "t0","t1","t2","t3","t4","t5","t6","t7",
            "s0","s1","s2","s3","s4","s5","s6","s7",
            "t8","t9","k0","k1","gp","sp","fp","ra"
        };
        return n < 32 ? names[n] : "?";
    }

    void add_log(uint32_t pc_val, uint32_t raw, const char* desc) {
        // Write to file log
        if (log_file) {
            fprintf(log_file, "[%7llu] PC=0x%08X 0x%08X %s\n", instructions, pc_val, raw, desc);
        }
        // Write to in-memory ring buffer for UI
        if (log_count >= MAX_LOG) {
            memmove(log, log + 1024, (MAX_LOG - 1024) * sizeof(LogEntry));
            log_count -= 1024;
        }
        LogEntry& e = log[log_count++];
        e.instr_count = instructions;
        e.pc = pc_val;
        e.raw = raw;
        strncpy(e.desc, desc, 79);
        e.desc[79] = 0;
        for (int i = 0; i < 8; i++) e.regs_snapshot[i] = regs[i];
    }

    void add_breakpoint(uint32_t addr) {
        if (bp_count < MAX_BP) breakpoints[bp_count++] = addr;
    }

    void remove_breakpoint(uint32_t addr) {
        for (int i = 0; i < bp_count; i++) {
            if (breakpoints[i] == addr) {
                breakpoints[i] = breakpoints[--bp_count];
                return;
            }
        }
    }

    bool step();
};

// ── PSX Memory Map ───────────────────────────────────────────────────────────
class PSX_Memory {
public:
    static const uint32_t RAM_SIZE = 0x200000; // 2MB
    uint8_t ram[RAM_SIZE];
    
    // Hardware register storage
    uint32_t hw_regs[0x20000]; // 0x1F000000-0x1F7FFFFF region
    
    // BIOS ROM area (stubbed)
    uint8_t bios[0x80000]; // 512KB BIOS space
    bool use_real_bios;     // true when a real BIOS file is loaded into bios[]
    bool bios_loaded;       // true when load_bios() succeeded
    
    // Scratchpad
    uint8_t scratch[0x1000]; // 4KB scratchpad at 0x1F800000
    
    // CD-ROM file
    FILE* cd_file;
    char cd_path[512];
    bool cd_loaded;
    
    // Hardware state
    uint32_t cdrom_status;
    // Response FIFO (read via 0x1F801801) — command responses
    uint8_t cdrom_response_fifo[16];
    int cdrom_response_pos;     // Read position in response FIFO
    int cdrom_response_count;   // Number of valid bytes in response FIFO
    // Data FIFO (read via 0x1F801802) — sector data
    uint8_t cdrom_data_sector[2048]; // Sector data buffer for data reads
    int cdrom_data_sector_pos;  // Read position within sector data
    bool cdrom_data_ready;      // True when a data sector is ready to read
    // Legacy compat (kept for DMA code that references cdrom_data_fifo)
    uint32_t cdrom_data_fifo[16];
    int cdrom_fifo_pos;
    uint8_t cdrom_index;         // CD-ROM index register (bits 0-1 of 0x1F801800 write)
    uint8_t cdrom_int_enable;    // CD-ROM interrupt enable mask (index=1, 0x1F801803)
    uint8_t cdrom_int_flag;      // Interrupt flag register (bits 0-2 = INT code)
    uint8_t cdrom_secondary_status; // Drive status: bit0=error, bit1=motor_on, bit2=seek_error, bit3=id_error, bit4=shell_open, bit5=reading, bit6=seeking, bit7=playing
    bool cdrom_command_busy;    // True when a command is being processed (BUSYSTS)
    int cdrom_command_delay;    // Delay before command executes
    uint8_t cdrom_pending_command; // Command waiting to execute
    // CD-ROM read position state
    uint8_t cdrom_setloc_min, cdrom_setloc_sec, cdrom_setloc_sector;
    uint32_t cdrom_setloc_lba;  // Pending setloc position (applied on ReadN/ReadS/Seek)
    bool cdrom_setloc_pending;  // True when setloc has been set but not yet applied
    uint32_t cdrom_cur_lba;     // Current read position in LBA
    bool cdrom_reading;         // True when ReadN/ReadS active
    uint8_t cdrom_param_fifo[16]; // Parameter FIFO for Setloc etc.
    int cdrom_param_pos;        // Number of parameters written
    int cdrom_event_id;         // Event ID for CD-ROM data ready (-1 if none)
    uint8_t cdrom_irq_code;     // CD-ROM interrupt code (0=none, 1=INT1, 2=INT2, etc.)
    int cdrom_irq_delay;        // Delay counter before firing CD-ROM IRQ (0 = no pending)
    // Second-response (INT2 Complete) state for commands that need it
    bool cdrom_int2_pending;    // True when a delayed INT2 is scheduled
    int cdrom_int2_delay;       // Delay counter before firing INT2
    uint8_t cdrom_int2_response[16]; // Response bytes for INT2
    int cdrom_int2_response_count; // Number of INT2 response bytes
    bool cdrom_response_ready;  // True when response FIFO has data (for RSLRRDY bit)
    bool cdrom_bfrd;            // Request register BFRD bit — controls data FIFO reads
    bool cdrom_data_transfer_active; // Bit 7 of request register — arms sector buffer for MMIO/DMA
    // CD-ROM continuous read state machine
    int cdrom_sector_delay;     // Instructions remaining before next sector is ready
    int cdrom_sector_delay_max; // Reset value for sector delay (~20000 instrs per sector)
    bool cdrom_read_pending;    // True when a sector read is in progress (waiting for delay)
    uint32_t cdrom_read_start_lba; // LBA where reading started
    int cdrom_sectors_read;     // Count of sectors read since ReadN/ReadS started
    uint64_t cdrom_total_sectors_read; // Total sectors read across ALL CdRead calls (CG-3.5)
    int cdrom_read_mode;        // 0=ReadN, 1=ReadS
    uint32_t cdrom_read_sectors_requested; // How many sectors CdRead was asked to read
    uint32_t cdrom_read_dest;   // Destination RAM address for CdRead
    bool cdrom_pause_requested; // True if Pause command was issued
    bool cdrom_seek_done;       // True if drive has already completed a seek (PSoXide seek_done)
    bool cdrom_location_changed; // True if read position changed — adds 30x delay for first sector (PSoXide)
    bool cdrom_read_rescheduled; // True if sector delivery was delayed due to pending IRQ (PSoXide read_rescheduled)
    bool cdrom_motor_on;        // Motor spin state (separate from secondary_status bit)
    uint8_t cdrom_mode;         // Setmode value (speed, ADPCM, etc.)
    bool cdrom_muted;           // Audio mute state (CdlMute/CdlDemute)
    uint8_t cdrom_filter_file;  // File filter for Setfilter command
    uint8_t cdrom_filter_channel; // Channel filter for Setfilter command
    uint32_t gpu_status;
    uint32_t timer_count[4];
    uint32_t timer_mode[4];
    uint32_t timer_target[4];
    uint32_t intc_mask;
    uint32_t intc_stat;
    // SIO0 (controller/memory card serial interface) state
    uint32_t sio0_data;         // Data register at 0x1F801000
    uint32_t sio0_status;       // Status register at 0x1F801004
    uint32_t sio0_control;      // Control register at 0x1F801008
    uint32_t sio0_baud;         // Baud rate at 0x1F80100C
    uint8_t sio0_rx_buf[16];    // Receive buffer (controller data)
    int sio0_rx_pos;            // Read position in RX buffer
    int sio0_rx_count;          // Number of valid bytes in RX buffer
    uint32_t dma_ctrl[8];       // DPCR per channel
    uint32_t dma_madr[8];       // DMA base address per channel
    uint32_t dma_bcr[8];        // DMA block control per channel
    uint32_t dma_chcr[8];       // DMA channel control per channel
    bool dma_done[8];           // DMA transfer complete flag
    
    // VBlank interrupt emulation
    // PSX runs at 33.8688 MHz, VBlank fires at ~60 Hz (NTSC) = every 564480 instructions
    uint32_t vblank_counter;    // Incremented each VBlank
    uint32_t vblank_interval;   // Instructions between VBlanks
    uint64_t instr_since_vblank;
    bool vblank_active;         // True during VBlank period (dot clock stops)
    
    // GPU command FIFO (for GPU DMA emulation)
    uint32_t gpu_read_data;
    
    // I/O port for BIOS calls
    char bios_string_buf[256];
    int bios_string_pos;

    // HLE BIOS Event System — flat handle-indexed table
    // The game computes event handles as (class & 0x1F) | (spec_index << 8)
    // We store events in a flat array indexed by this handle.
    // DeliverEvent searches by class+spec to find the matching handle.
    static const uint32_t EvStUNUSED  = 0;
    static const uint32_t EvStWAIT    = 1;
    static const uint32_t EvStACTIVE  = 2;
    static const uint32_t EvStALREADY = 3;
    static const uint32_t EvMdINTR    = 0x1000;
    static const uint32_t EvMdNOINTR  = 0x2000;

    struct EvEntry {
        uint32_t status;
        uint32_t mode;
        uint32_t fhandler;
        uint32_t ev_class;  // original class for DeliverEvent matching
        uint32_t ev_spec;   // original spec for DeliverEvent matching
        bool used;          // true if this slot is occupied
    };
    static const int EV_TABLE_SIZE = 4096;
    EvEntry events[EV_TABLE_SIZE];
    bool events_initialized;

    // HookEntryInt state — game's custom interrupt entry point
    // When set, VBlank exception jumps to game's handler instead of HLE RFE
    uint32_t hook_entry_int_addr;
    bool hook_entry_int_set;

    // Recursion guard for event handler sub-calls
    bool in_soft_call;

    // Saved register context for ReturnFromException
    // When we dispatch to HookEntryInt handler, we save the interrupted
    // context here. ReturnFromException restores from this buffer.
    struct SavedCtx {
        uint32_t regs[32]; // ALL GPRs (index 0 = zero, unused)
        uint32_t hi, lo;
        bool valid;
    } saved_ctx;

    // Thread system (basic — for OpenTh/ChangeTh)
    struct ThreadCtx {
        uint32_t ra, sp, fp, gp;
        uint32_t s[8]; // s0-s7
        uint32_t pc;   // entry point
        bool active;
    };
    static const int MAX_THREADS = 4;
    ThreadCtx threads[MAX_THREADS];
    int current_thread;  // -1 = main thread

    // GPU state (Phase 2)
    uint32_t gpu_display_mode;
    bool gpu_display_enabled;
    uint32_t gpu_dma_dir;  // DMA direction: 0=off, 1=CPU→VRAM, 2=VRAM→CPU, 3=CPU→GP0
    uint32_t gpu_display_start_x;
    uint32_t gpu_display_start_y;
    uint32_t gpu_display_range_h;
    uint32_t gpu_display_range_v;
    uint32_t gpu_horiz_res;
    uint32_t gpu_vert_res;

    // ── Phase 7: GPU VRAM + Rendering ─────────────────────────────────────
    // PSX VRAM: 1MB = 1024x512 pixels at 16bpp
    static const uint32_t VRAM_W = 1024;
    static const uint32_t VRAM_H = 512;
    uint16_t vram[VRAM_W * VRAM_H];  // 1MB VRAM

    // GPU command FIFO for GP0 polygon/rectangle/blit commands
    static const int GPU_FIFO_SIZE = 64;
    uint32_t gpu_cmd_fifo[GPU_FIFO_SIZE];
    int gpu_cmd_count;

    // GPU diagnostics counters
    uint64_t gpu_gp0_cmd_total;   // Total GP0 commands received
    uint64_t gpu_gp1_cmd_total;   // Total GP1 commands received
    uint64_t gpu_vram_write_total; // Total VRAM pixel writes
    uint32_t gpu_cmd_type;  // Current command being assembled (high byte)
    int gpu_cmd_words_needed;  // Total words for current command
    int gpu_cmd_words_got;     // Words received so far

    // Drawing state
    uint32_t gpu_texpage;  // Texture page settings
    uint32_t gpu_texwin;   // Texture window
    uint32_t gpu_draw_area_tl, gpu_draw_area_br;
    uint32_t gpu_draw_offset;
    uint32_t gpu_tpage_x, gpu_tpage_y;  // Texture page base coords
    bool gpu_tex_abr;  // Semi-transparency mode
    uint8_t gpu_dither;
    uint8_t gpu_tex_color_mode; // 0=4bit, 1=8bit, 2=15bit, 3=reserved
    uint8_t gpu_semi_trans_mode; // 0..3 from texpage
    int gpu_off_x, gpu_off_y; // Drawing offset
    int gpu_draw_x1, gpu_draw_y1, gpu_draw_x2, gpu_draw_y2; // Drawing area
    uint16_t gpu_texwin_mask_x, gpu_texwin_mask_y;
    uint16_t gpu_texwin_off_x, gpu_texwin_off_y;

    // VRAM transfer state (for GP0 CPU→VRAM and VRAM→CPU)
    uint16_t gpu_xfer_x, gpu_xfer_y;     // Transfer start position
    uint16_t gpu_xfer_w, gpu_xfer_h;      // Transfer dimensions
    uint16_t gpu_xfer_cx, gpu_xfer_cy;    // Current position in transfer
    bool gpu_xfer_is_read;                // true = VRAM→CPU, false = CPU→VRAM
    bool gpu_interlace_field;             // Interlace field: false=odd, true=even (toggles each VBlank)
    bool gpu_drawing_busy;                // True while GPU is drawing (always false — we process instantly)

    // Framebuffer for display: 320x240 RGB (what gets blitted to screen)
    static const uint32_t FB_W = 320;
    static const uint32_t FB_H = 240;
    uint32_t framebuffer[FB_W * FB_H];  // 32-bit ARGB for Win32 blitting
    bool fb_dirty;

    // GPU command processing
    void gpu_reset();
    void gpu_gp0(uint32_t val);
    void gpu_gp1(uint32_t val);
    void gpu_process_command();
    void gpu_vram_write(uint16_t x, uint16_t y, uint16_t w, uint16_t h, const uint16_t* src);
    void gpu_vram_read(uint16_t x, uint16_t y, uint16_t w, uint16_t h, uint16_t* dst);
    void gpu_render_framebuffer();  // Convert VRAM display area to framebuffer
    void gpu_draw_rect(int x, int y, int w, int h, uint32_t color);
    void gpu_clear_vram();
    uint32_t compute_gpustat();  // Full GPUSTAT register computation (shared by HW read + BIOS 0x4D)

    struct GPVertex {
        int x, y;
        uint32_t color; // 24-bit BGR
        uint16_t u, v;
        uint16_t clut;
    };
    void gpu_draw_triangle(const GPVertex& v0, const GPVertex& v1, const GPVertex& v2,
                           bool textured, bool shaded, bool semi_trans, bool raw);
    void gpu_draw_quad(const GPVertex& v0, const GPVertex& v1, const GPVertex& v2, const GPVertex& v3,
                       bool textured, bool shaded, bool semi_trans, bool raw);
    void gpu_draw_line(const GPVertex& v0, const GPVertex& v1, bool shaded, bool semi_trans);
    void gpu_draw_sprite(const GPVertex& v, int w, int h, bool textured, bool semi_trans, bool raw);
    void gpu_write_pixel(int x, int y, uint16_t color, bool semi_trans);

    // Root counter / timer state (Phase 3)
    bool rcnt_active[4];
    bool rcnt_target_irq[4];
    bool rcnt_overflow_irq[4];

    // ── Phase 4: CD-ROM File I/O ──────────────────────────────────────────
    struct FileDesc {
        char name[32];
        uint32_t mode;
        uint32_t offset;   // Current file offset in bytes
        uint32_t size;      // File size in bytes
        uint32_t lba;       // Starting LBA on CD-ROM
        bool in_use;
    };
    static const int MAX_FDESCS = 16;
    FileDesc fdescs[MAX_FDESCS];

    // ISO9660 directory entry cache
    struct DirEntry {
        char name[32];
        uint32_t lba;
        uint32_t size;
        bool is_dir;
    };
    static const int MAX_DIR_ENTRIES = 256;
    DirEntry dir_entries[MAX_DIR_ENTRIES];
    int dir_entry_count;
    bool dir_cached;

    // ── Robustness: LBA ownership map for detecting reads from wrong files ──
    struct LbaFileRange {
        uint32_t start_lba;
        uint32_t end_lba;   // exclusive
        char     name[32];
    };
    static const int MAX_LBA_RANGES = 512;
    LbaFileRange lba_ranges[MAX_LBA_RANGES];
    int lba_range_count;
    void build_lba_file_map();
    const char* get_lba_owner(uint32_t lba) const;

    // ── Phase 5: Controller Input (PAD) ───────────────────────────────────
    uint32_t pad_buf1_addr;   // RAM address of pad 1 buffer
    uint32_t pad_buf2_addr;   // RAM address of pad 2 buffer
    int pad_buf1_len;
    int pad_buf2_len;
    uint32_t pad_buf_addr;    // PAD_init buffer (interrupt-driven pad)
    bool pad_started;
    // Digital pad button state (bit=0 means pressed)
    uint16_t pad1_buttons;
    uint16_t pad2_buttons;
    // Analog stick values (0x80 = center)
    uint8_t pad1_rx, pad1_ry, pad1_lx, pad1_ly;
    uint8_t pad2_rx, pad2_ry, pad2_lx, pad2_ly;
    // Scriptable input queue
    struct InputEvent {
        uint64_t at_vblank;   // VBlank count to fire at
        uint16_t buttons;     // Button state to set
        bool press;           // true=press, false=release
    };
    static const int MAX_INPUT_QUEUE = 512;
    InputEvent input_queue[MAX_INPUT_QUEUE];
    int input_queue_count;

    // ── Virtual Memory Card ──────────────────────────────────────────────
    static const uint32_t MEMCARD_SIZE = 128 * 1024; // 128KB = 16 blocks × 8KB
    uint8_t memcard_data[MEMCARD_SIZE];
    bool memcard_initialized;
    bool memcard_dirty;       // Set when _card_write is called
    int memcard_write_count;  // Number of _card_write calls
    int memcard_read_count;   // Number of _card_read calls
    int memcard_create_count; // Number of _card_create calls
    uint32_t memcard_last_write_addr;  // RAM addr of last _card_write buffer
    uint32_t memcard_last_write_size;  // Size of last _card_write
    char memcard_last_filename[32];    // Last file created/opened
    // File descriptor table for memory card files
    struct MemCardFD {
        bool in_use;
        int block;       // Starting block on card
        int num_blocks;  // Number of blocks
        int offset;      // Current read/write offset
        char name[32];   // File name
    };
    MemCardFD memcard_fds[4];
    int memcard_fd_count;

    void memcard_init();
    void memcard_save_to_file(const char* path);
    bool memcard_load_from_file(const char* path);
    void dump_memcard_state();
    void dump_save_buffer(uint32_t ram_addr, uint32_t size);
    bool verify_save_data();

    // GTE (Geometry Transformation Engine)
    PSX_GTE gte;

    // ── Phase 6: Interactive Debugging ────────────────────────────────────
    struct Watchpoint {
        uint32_t addr;
        uint32_t mask;
        bool on_read;
        bool on_write;
        bool hit;
    };
    static const int MAX_WATCHPOINTS = 32;
    Watchpoint watchpoints[MAX_WATCHPOINTS];
    int wp_count;

    // Call stack tracking (jal/jr pairs)
    struct StackFrame {
        uint32_t call_pc;
        uint32_t target_pc;
        uint64_t instr_count;
    };
    static const int MAX_CALL_STACK = 64;
    StackFrame call_stack[MAX_CALL_STACK];
    int call_stack_depth;

    bool single_step_mode;
    uint32_t step_break_addr;   // Run until this PC
    bool step_break_enabled;

    // Compute event handle from class and spec the way the game does:
    // handle = (class & 0x1F) | (spec_index << 8)
    int compute_handle(uint32_t ev_class, uint32_t spec_val) {
        int subclass = ev_class & 0x1F;
        int spec_idx = 0;
        if (spec_val == 0x0301) spec_idx = 16;
        else if (spec_val == 0x0302) spec_idx = 17;
        else {
            for (int i = 0; i < 16; i++) {
                if (spec_val & (1 << i)) { spec_idx = i; break; }
            }
        }
        return subclass | (spec_idx << 8);
    }

    void init_events() {
        memset(events, 0, sizeof(events));
        events_initialized = true;
        hook_entry_int_addr = 0;
        hook_entry_int_set = false;
        in_soft_call = false;
    }

    // DeliverEvent — find event by class+spec.
    // For EvMdINTR (0x1000) events: call the handler subroutine via sub-execution
    // (like PCSX-R softCall2). For EvMdNOINTR (0x2000): set status to EvStALREADY.
    void deliver_event(uint32_t ev_class, uint32_t spec_val) {
        int handle = compute_handle(ev_class, spec_val);
        if (handle < 0 || handle >= EV_TABLE_SIZE) {
            if (g_diaglog) { fprintf(g_diaglog, "[EVT] deliver_event: no handle for class=0x%08X spec=0x%08X\n", ev_class, spec_val); fflush(g_diaglog); }
            return;
        }
        if (!events[handle].used) {
            if (g_diaglog) { fprintf(g_diaglog, "[EVT] deliver_event: handle=%d unused for class=0x%08X spec=0x%08X\n", handle, ev_class, spec_val); fflush(g_diaglog); }
            return;
        }
        uint32_t st = events[handle].status;
        // PCSX-R only delivers to ACTIVE events, not WAIT.
        // WAIT events haven't been enabled via EnableEvent yet.
        if (st != EvStACTIVE) {
            if (g_diaglog) { fprintf(g_diaglog, "[EVT] deliver_event: handle=%d NOT ACTIVE (status=%d) class=0x%08X spec=0x%08X\n", handle, st, ev_class, spec_val); fflush(g_diaglog); }
            return;
        }
        if (g_diaglog) { fprintf(g_diaglog, "[EVT] deliver_event: handle=%d ACTIVE mode=0x%08X handler=0x%08X class=0x%08X spec=0x%08X instr #%llu\n",
                 handle, events[handle].mode, events[handle].fhandler, ev_class, spec_val,
                 (unsigned long long)(g_cpu ? g_cpu->instructions : 0)); fflush(g_diaglog); }
        // Trace event delivery
        g_cdrom_tracer.log_event(handle, ev_class, spec_val, events[handle].status, "deliver");
        if (!g_cdrom_tracer.events.empty() && g_cpu)
            g_cdrom_tracer.events.back().instruction_count = g_cpu->instructions;

        if (events[handle].mode == 0x1000 && events[handle].fhandler && g_cpu && !in_soft_call) {
            // EvMdINTR: call handler as MIPS subroutine (PCSX-R softCall2 pattern)
            uint32_t saved_regs[32];
            for (int i = 0; i < 32; i++) saved_regs[i] = g_cpu->get_reg(i);
            uint32_t saved_pc = g_cpu->pc;
            bool saved_bd = g_cpu->in_branch_delay;
            bool saved_pb = g_cpu->pending_branch;

            uint32_t sentinel = 0x80001000;
            g_cpu->set_reg(31, sentinel);
            g_cpu->pc = events[handle].fhandler;
            g_cpu->in_branch_delay = false;
            g_cpu->pending_branch = false;
            in_soft_call = true;

            if (g_cdlog && g_cdlog_count < 20000) {
                fprintf(g_cdlog, "[EVCALL] Calling handler 0x%08X for class=0x%08X spec=0x%08X at instr #%llu\n",
                        events[handle].fhandler, ev_class, spec_val,
                        (unsigned long long)g_cpu->instructions);
                g_cdlog_count++;
            }

            int max_steps = 50000;
            while (g_cpu->pc != sentinel && max_steps-- > 0) {
                if (!g_cpu->step()) break;
            }

            if (g_cdlog && g_cdlog_count < 20000) {
                fprintf(g_cdlog, "[EVCALL] Handler returned (pc=0x%08X, steps left=%d) at instr #%llu\n",
                        g_cpu->pc, max_steps,
                        (unsigned long long)g_cpu->instructions);
                g_cdlog_count++;
            }

            in_soft_call = false;

            // Restore all registers (handler may have clobbered them)
            for (int i = 0; i < 32; i++) g_cpu->set_reg(i, saved_regs[i]);
            g_cpu->pc = saved_pc;
            g_cpu->in_branch_delay = saved_bd;
            g_cpu->pending_branch = saved_pb;
            // Do NOT change status — EvMdINTR events stay ACTIVE for next delivery
        } else {
            events[handle].status = EvStALREADY;
        }
    }

    // Deliver only VBlank-class events on VBlank interrupt.
    // PCSX-R only delivers RcEV[3][1] (VBlank root counter) on VSync,
    // NOT all events. CD-ROM events must only fire on CD-ROM IRQ.
    void deliver_vblank_events() {
        for (int i = 0; i < EV_TABLE_SIZE; i++) {
            if (!events[i].used) continue;
            if (events[i].status != EvStACTIVE) continue;
            // Only deliver VBlank-class events (0xF2000003 = RcEV[3], 0xF0000001 = VBlank)
            uint32_t cls = events[i].ev_class;
            if (cls == 0xF2000003 || cls == 0xF0000001) {
                events[i].status = EvStALREADY;
            }
        }
    }

    // Deliver RcEV event for root counter (timer) interrupts
    void deliver_rcnt_event(int counter, int spec_idx) {
        // RcEV class is 0xF2000000 + counter, spec is 1<<spec_idx
        uint32_t rc_class = 0xF2000000 | counter;
        uint32_t rc_spec = (spec_idx == 0) ? 0x01 : 0x02;
        int handle = compute_handle(rc_class, rc_spec);
        if (handle >= 0 && handle < EV_TABLE_SIZE && events[handle].used) {
            if (events[handle].status == EvStACTIVE || events[handle].status == EvStWAIT) {
                events[handle].status = EvStALREADY;
            }
        }
    }

    PSX_Memory() : cd_file(nullptr), cd_loaded(false), use_real_bios(false), bios_loaded(false) {
        memset(ram, 0, RAM_SIZE);
        memset(hw_regs, 0, sizeof(hw_regs));
        memset(bios, 0, sizeof(bios));
        memset(scratch, 0, sizeof(scratch));
        cdrom_status = 0;
        cdrom_fifo_pos = 0;
        cdrom_response_pos = 0;
        cdrom_response_count = 0;
        cdrom_setloc_min = 0; cdrom_setloc_sec = 0; cdrom_setloc_sector = 0;
        cdrom_setloc_lba = 0;
        cdrom_setloc_pending = false;
        cdrom_cur_lba = 0;
        cdrom_reading = false;
        cdrom_param_pos = 0;
        cdrom_event_id = -1;
        cdrom_irq_code = 0;
        cdrom_irq_delay = 0;
        cdrom_int2_pending = false;
        cdrom_int2_delay = 0;
        cdrom_int2_response_count = 0;
        cdrom_response_ready = false;
        cdrom_data_sector_pos = 0;
        cdrom_data_ready = false;
        cdrom_index = 0;
        cdrom_int_enable = 0x1F; // PSoXide: all 5 IRQ types enabled on reset
        cdrom_int_flag = 0;
        cdrom_secondary_status = cdrom_constants::STAT_MOTOR_ON; // motor on
        cdrom_command_busy = false;
        cdrom_command_delay = 0;
        cdrom_pending_command = 0;
        cdrom_bfrd = false;
        cdrom_data_transfer_active = false;
        cdrom_sector_delay = 0;
        cdrom_sector_delay_max = (int)cdrom_constants::CD_READ_TIME; // 451,584 cycles per sector at 1x
        cdrom_read_pending = false;
        cdrom_read_start_lba = 0;
        cdrom_sectors_read = 0;
        cdrom_total_sectors_read = 0;
        cdrom_read_mode = 0;
        cdrom_read_sectors_requested = 0;
        cdrom_read_dest = 0;
        cdrom_pause_requested = false;
        cdrom_seek_done = false;
        cdrom_location_changed = false;
        cdrom_read_rescheduled = false;
        cdrom_motor_on = true;
        cdrom_mode = 0x80; // PSoXide default: double-speed
        cdrom_muted = false;
        cdrom_filter_file = 0;
        cdrom_filter_channel = 0;
        memset(cdrom_data_sector, 0, sizeof(cdrom_data_sector));
        memset(cdrom_param_fifo, 0, sizeof(cdrom_param_fifo));
        memset(cdrom_response_fifo, 0, sizeof(cdrom_response_fifo));
        gpu_status = 0x04000000;  // bit 26 = ready for DMA
        intc_mask = 0;
        intc_stat = 0;
        memset(dma_ctrl, 0, sizeof(dma_ctrl));
        memset(dma_madr, 0, sizeof(dma_madr));
        memset(dma_bcr, 0, sizeof(dma_bcr));
        memset(dma_chcr, 0, sizeof(dma_chcr));
        memset(dma_done, 0, sizeof(dma_done));
        memset(timer_count, 0, sizeof(timer_count));
        memset(timer_mode, 0, sizeof(timer_mode));
        memset(timer_target, 0, sizeof(timer_target));
        sio0_data = 0;
        sio0_status = 0x00000004;  // Bit 2: CTS (clear to send) — always ready
        sio0_control = 0;
        sio0_baud = 0;
        memset(sio0_rx_buf, 0, sizeof(sio0_rx_buf));
        sio0_rx_pos = 0;
        sio0_rx_count = 0;
        vblank_counter = 0;
        vblank_interval = 564480;  // NTSC accurate: 33,868,800 Hz / 60 Hz = 564480 instructions
        instr_since_vblank = 0;
        vblank_active = false;
        gpu_read_data = 0;
        bios_string_pos = 0;
        events_initialized = false;
        hook_entry_int_addr = 0;
        hook_entry_int_set = false;
        in_soft_call = false;
        saved_ctx.valid = false;
        memset(threads, 0, sizeof(threads));
        current_thread = -1;
        gpu_display_enabled = false;
        gpu_dma_dir = 0;
        gpu_display_start_x = 0;
        gpu_display_start_y = 0;
        gpu_display_range_h = 0;
        gpu_display_range_v = 0;
        gpu_horiz_res = 320;
        gpu_vert_res = 240;
        memset(rcnt_active, 0, sizeof(rcnt_active));
        memset(rcnt_target_irq, 0, sizeof(rcnt_target_irq));
        memset(rcnt_overflow_irq, 0, sizeof(rcnt_overflow_irq));
        // Phase 7: GPU VRAM + rendering
        memset(vram, 0, sizeof(vram));
        gpu_cmd_count = 0;
        gpu_gp0_cmd_total = 0;
        gpu_gp1_cmd_total = 0;
        gpu_vram_write_total = 0;
        gpu_cmd_type = 0;
        gpu_cmd_words_needed = 0;
        gpu_cmd_words_got = 0;
        gpu_texpage = 0;
        gpu_texwin = 0;
        gpu_draw_area_tl = 0;
        gpu_draw_area_br = 0;
        gpu_draw_offset = 0;
    gpu_tpage_x = 0; gpu_tpage_y = 0;
    gpu_tex_abr = false;
    gpu_dither = 0;
    gpu_tex_color_mode = 0;
    gpu_semi_trans_mode = 0;
    gpu_off_x = 0; gpu_off_y = 0;
    gpu_draw_x1 = 0; gpu_draw_y1 = 0; gpu_draw_x2 = 1023; gpu_draw_y2 = 511;
    gpu_texwin_mask_x = 0; gpu_texwin_mask_y = 0;
    gpu_texwin_off_x = 0; gpu_texwin_off_y = 0;
        gpu_tex_color_mode = 0;
        gpu_semi_trans_mode = 0;
        gpu_off_x = 0; gpu_off_y = 0;
        gpu_draw_x1 = 0; gpu_draw_y1 = 0; gpu_draw_x2 = 1023; gpu_draw_y2 = 511;
        gpu_texwin_mask_x = 0; gpu_texwin_mask_y = 0;
        gpu_texwin_off_x = 0; gpu_texwin_off_y = 0;
        gpu_xfer_x = gpu_xfer_y = 0;
        gpu_xfer_w = gpu_xfer_h = 0;
        gpu_xfer_cx = gpu_xfer_cy = 0;
        gpu_xfer_is_read = false;
        memset(framebuffer, 0, sizeof(framebuffer));
        fb_dirty = true;
        // Phase 4
        memset(fdescs, 0, sizeof(fdescs));
        memset(dir_entries, 0, sizeof(dir_entries));
        dir_entry_count = 0;
        dir_cached = false;
        // Phase 5
        pad_buf1_addr = 0; pad_buf2_addr = 0;
        pad_buf1_len = 0; pad_buf2_len = 0;
        pad_buf_addr = 0; pad_started = false;
        pad1_buttons = 0xFFFF;  // No buttons pressed
        pad2_buttons = 0xFFFF;
        pad1_rx = 0x80; pad1_ry = 0x80; pad1_lx = 0x80; pad1_ly = 0x80;
        pad2_rx = 0x80; pad2_ry = 0x80; pad2_lx = 0x80; pad2_ly = 0x80;
        memset(input_queue, 0, sizeof(input_queue));
        input_queue_count = 0;
        // Virtual memory card
        memset(memcard_data, 0, MEMCARD_SIZE);
        memcard_initialized = false;
        memcard_dirty = false;
        memcard_write_count = 0;
        memcard_read_count = 0;
        memcard_create_count = 0;
        memcard_last_write_addr = 0;
        memcard_last_write_size = 0;
        memset(memcard_last_filename, 0, sizeof(memcard_last_filename));
        memset(memcard_fds, 0, sizeof(memcard_fds));
        memcard_fd_count = 0;
        memset(watchpoints, 0, sizeof(watchpoints));
        wp_count = 0;
        memset(call_stack, 0, sizeof(call_stack));
        call_stack_depth = 0;
        single_step_mode = false;
        step_break_addr = 0;
        step_break_enabled = false;
        exe_init_gp = 0;
        exe_init_sp = 0;
        gte.reset();
    }

    // Helper: push a byte into the response FIFO
    void cdrom_push_response(uint8_t val) {
        if (cdrom_response_count < 16) {
            cdrom_response_fifo[cdrom_response_count++] = val;
        }
        cdrom_response_ready = true;
    }

    // Helper: compute the status register value (0x1F801800 read)
    // Bit layout matches PSoXide status_byte():
    //   bits 0-1: index, bit 2: ADPBUSY, bit 3: PRMEMPTY,
    //   bit 4: PRMWRDY, bit 5: RSLRRDY, bit 6: DRQSTS, bit 7: BUSYSTS
    uint8_t cdrom_get_status() {
        uint8_t status = cdrom_index & 0x03;       // bits 0-1: index
        // bit 2: ADPBUSY — not implemented, always 0
        if (cdrom_param_pos == 0) status |= 0x08;  // bit 3: PRMEMPTY
        if (cdrom_param_pos < 16) status |= 0x10;  // bit 4: PRMWRDY (not full)
        if (cdrom_response_ready) status |= 0x20;  // bit 5: RSLRRDY
        if (cdrom_data_ready) status |= 0x40;      // bit 6: DRQSTS (data FIFO ready, no BFRD gate)
        if (cdrom_command_busy) status |= 0x80;    // bit 7: BUSYSTS
        return status;
    }

    // Helper: compute the stat byte for command responses (PSoXide stat_byte)
    // Uses drive_status bits with motor_on and reading from separate state vars
    uint8_t cdrom_stat_byte() {
        uint8_t s = cdrom_secondary_status & ~(cdrom_constants::STAT_MOTOR_ON | cdrom_constants::STAT_READING);
        if (cdrom_motor_on) s |= cdrom_constants::STAT_MOTOR_ON;
        if (cdrom_reading) s |= cdrom_constants::STAT_READING;
        return s;
    }

    // Helper: set interrupt and fire IRQ if enabled
    // Uses PSoXide FIRST_RESPONSE_CYCLES (2048) as the delay before the
    // first response IRQ fires, matching AddIrqQueue(cmd, 0x800) in Redux.
    void cdrom_set_interrupt(uint8_t code) {
        cdrom_int_flag = code & 0x07;
        cdrom_irq_code = code;
        cdrom_irq_delay = (int)cdrom_constants::FIRST_RESPONSE_CYCLES; // 2048 cycles
        // IRQ line is asserted if (int_flag & int_enable) != 0
        // In HLE mode, cdrom_int_enable is never set by software (no hardware reg writes),
        // so always assert the interrupt to ensure event delivery works
        if ((cdrom_int_enable & cdrom_int_flag) || !use_real_bios) {
            intc_stat |= 0x04;
            if (g_cpu) g_cpu->interrupt_pending = true;
        }
    }

    // Schedule a delayed INT2 (Complete) response — used by Setmode, Init, GetID, etc.
    void cdrom_schedule_int2(int delay, const uint8_t* resp, int count) {
        cdrom_int2_pending = true;
        cdrom_int2_delay = delay;
        cdrom_int2_response_count = count > 16 ? 16 : count;
        if (resp && count > 0) {
            memcpy(cdrom_int2_response, resp, cdrom_int2_response_count);
        } else {
            cdrom_int2_response_count = 0;
        }
        if (g_verbose) printf("[CDINT2] INT2 scheduled (delay=%d) at instr #%llu\n", delay, g_cpu ? g_cpu->instructions : 0);
        if (g_cdlog && g_cdlog_count < 20000) { fprintf(g_cdlog, "[CDINT2] INT2 scheduled (delay=%d) at instr #%llu\n", delay, g_cpu ? g_cpu->instructions : 0); g_cdlog_count++; }
    }

    // CD-ROM state machine tick — called from tick() every instruction
    // Ported from PSoXide cdrom.rs::tick() with IRQ flag gate, proper timing,
    // and BUSYSTS clearing on first response.
    void cdrom_tick() {
        // Handle IRQ delay countdown (first response / scheduled IRQ)
        if (cdrom_irq_delay > 0) {
            cdrom_irq_delay--;
            if (cdrom_irq_delay == 0 && cdrom_irq_code != 0) {
                // Before firing, check IRQ flag gate — if previous IRQ unacked, reschedule
                if (cdrom_int_flag != 0) {
                    // Previous IRQ not acknowledged — reschedule with short delay
                    cdrom_irq_delay = (int)cdrom_constants::IRQ_RESCHEDULE_CYCLES;
                    return;
                }
                // Fire CD-ROM interrupt — set int_flag and assert IRQ line
                cdrom_int_flag = cdrom_irq_code & 0x07;
                // Clear BUSYSTS when first response fires (PSoXide: command_busy = false)
                cdrom_command_busy = false;
                // Only assert IRQ if interrupt is enabled in int_enable register
                if (cdrom_int_enable & cdrom_int_flag) {
                    intc_stat |= 0x04; // CD-ROM IRQ bit 2
                    if (g_cpu) g_cpu->interrupt_pending = true;
                }
                if (g_verbose) printf("[CDIRQ] CD-ROM IRQ fired (code=%d) at instr #%llu\n",
                           cdrom_irq_code, g_cpu->instructions);
            }
        }

        // Handle INT2 (Complete) second response
        if (cdrom_int2_pending) {
            // IRQ flag gate — wait for previous IRQ to be acknowledged
            if (cdrom_int_flag != 0) {
                // Reschedule: bump delay by reschedule cycles
                cdrom_int2_delay = (int)cdrom_constants::IRQ_RESCHEDULE_CYCLES;
            } else {
                cdrom_int2_delay--;
                if (cdrom_int2_delay <= 0) {
                    cdrom_int2_pending = false;
                    if (g_verbose) printf("[CDINT2] INT2 firing at instr #%llu (delay reached 0)\n", g_cpu ? g_cpu->instructions : 0);
                    if (g_cdlog && g_cdlog_count < 20000) { fprintf(g_cdlog, "[CDINT2] INT2 firing at instr #%llu\n", g_cpu ? g_cpu->instructions : 0); g_cdlog_count++; }
                    // Load INT2 response into FIFO
                    cdrom_response_pos = 0;
                    cdrom_response_count = 0;
                    memset(cdrom_response_fifo, 0, sizeof(cdrom_response_fifo));
                    // First byte is always stat byte (PSoXide stat_byte())
                    cdrom_push_response(cdrom_stat_byte());
                    // Then any additional response bytes
                    for (int i = 0; i < cdrom_int2_response_count; i++) {
                        cdrom_push_response(cdrom_int2_response[i]);
                    }
                    cdrom_response_ready = true;
                    // Clear seeking bit after INT2 (seek complete) — bit6 = 0x40
                    cdrom_secondary_status &= ~cdrom_constants::STAT_SEEKING;
                    // Fire INT2
                    cdrom_set_interrupt(2);
                    if (g_cpu) {
                        CDLOG2("[CDROM] INT2 (Complete) fired at instr #%llu\n", g_cpu->instructions);
                    }
                }
            }
        }

        // Handle continuous sector delivery (PSoXide DataReady chain)
        if (cdrom_reading && !cdrom_read_pending && !cdrom_pause_requested) {
            // Start waiting for next sector
            cdrom_read_pending = true;
            // Initial sector delay: CD_READ_TIME for 2x, CD_READ_TIME*2 for 1x (PSoXide initial_sector_read_cycles)
            // For chained sectors: CD_READ_TIME/2 for 2x, CD_READ_TIME for 1x (PSoXide sector_read_cycles)
            if (cdrom_sectors_read == 0) {
                // First sector after ReadN/ReadS — use initial delay
                cdrom_sector_delay = (cdrom_mode & 0x80) ?
                    (int)cdrom_constants::CD_READ_TIME :
                    (int)(cdrom_constants::CD_READ_TIME * 2);
            } else {
                // Chained sector — use steady-state delay
                cdrom_sector_delay = (cdrom_mode & 0x80) ?
                    (int)cdrom_constants::CD_READ_TIME_DOUBLE :
                    (int)cdrom_constants::CD_READ_TIME_SINGLE;
            }
            // Location change adds 30x delay for first sector (PSoXide location_changed)
            if (cdrom_location_changed) {
                cdrom_sector_delay *= 30;
            }
        }

        if (cdrom_read_pending) {
            // IRQ flag gate — don't deliver sector if previous IRQ unacked (PSoXide)
            if (cdrom_int_flag != 0) {
                // Reschedule with short delay instead of firing
                cdrom_read_rescheduled = true;
                cdrom_sector_delay = (int)(cdrom_constants::CD_READ_TIME / 2);
                cdrom_int_flag = 0; // Will be re-checked next tick
                // Actually, don't clear int_flag — it should stay until ACK'd
                // Just bump the delay
                cdrom_sector_delay = (int)cdrom_constants::IRQ_RESCHEDULE_CYCLES;
                return;
            }
            cdrom_sector_delay--;
            if (cdrom_sector_delay <= 0) {
                // Sector is ready — read it from disc image
                uint8_t sector_buf[2048];
                if (read_cd_sector(cdrom_cur_lba, sector_buf)) {
                    memcpy(cdrom_data_sector, sector_buf, 2048);
                    cdrom_data_sector_pos = 0;
                    cdrom_data_ready = true;
                    cdrom_sectors_read++;
                    cdrom_total_sectors_read++;
                    cdrom_read_rescheduled = false;

                    // Copy sector to RAM destination if CdRead set one
                    if (cdrom_read_dest != 0 && cdrom_read_sectors_requested > 0) {
                        uint32_t dest_off = cdrom_read_dest + (cdrom_sectors_read - 1) * 2048;
                        uint32_t ram_off = dest_off - 0x80000000;
                        if (ram_off + 2048 <= RAM_SIZE) {
                            memcpy(&ram[ram_off], sector_buf, 2048);
                        }
                    }

                    // Fire INT1 (data ready) interrupt
                    cdrom_irq_code = 1; // INT1
                    cdrom_irq_delay = (int)cdrom_constants::IRQ_RESCHEDULE_CYCLES;
                    cdrom_int_flag = 1;

                    // Set response FIFO: stat byte (PSoXide stat_byte())
                    cdrom_response_pos = 0;
                    cdrom_response_count = 0;
                    memset(cdrom_response_fifo, 0, sizeof(cdrom_response_fifo));
                    cdrom_push_response(cdrom_stat_byte());
                    cdrom_response_ready = true;

                    ASSERT_INFO_STATE("CDROM_SECTOR_DELIVERED", "Sector delivered to RAM via cdrom_tick",
                                      cdrom_cur_lba, cdrom_sectors_read);

                    if (g_cpu) {
                        const char* owner = get_lba_owner(cdrom_cur_lba);
                        if (g_verbose) printf("[CDROM] INT1 sector #%d LBA=%u ready at instr #%llu (owner=%s)\n",
                               cdrom_sectors_read, cdrom_cur_lba, g_cpu->instructions, owner);
                        if (g_verbose) {
                            // Dedicated log file for QA analysis
                            static FILE* cdrom_log = nullptr;
                            if (!cdrom_log) cdrom_log = fopen("cdrom_read_log.txt", "w");
                            if (cdrom_log) {
                                fprintf(cdrom_log, "instr=%llu pc=0x%08X lba=%u owner=%s\n",
                                        g_cpu->instructions, g_cpu->pc, cdrom_cur_lba, owner);
                                if (cdrom_sectors_read % 32 == 0) fflush(cdrom_log);
                            }
                        }
                    }
                } else {
                    // Read error — fire INT5 (error)
                    cdrom_irq_code = 5;
                    cdrom_irq_delay = (int)cdrom_constants::IRQ_RESCHEDULE_CYCLES;
                    cdrom_reading = false;
                    ASSERT_STATE("CDROM_SECTOR_READ_ERROR", false,
                                 "cdrom_tick read_cd_sector failed",
                                 0, cdrom_cur_lba);
                    if (g_cpu) {
                        if (g_verbose) printf("[CDROM] Read error at LBA=%u at instr #%llu\n",
                               cdrom_cur_lba, g_cpu->instructions);
                    }
                }

                // Advance LBA for next sector
                cdrom_cur_lba++;
                cdrom_read_pending = false;

                // Check if CdRead has delivered all requested sectors
                if (cdrom_read_sectors_requested > 0 && cdrom_sectors_read >= (int)cdrom_read_sectors_requested) {
                    cdrom_reading = false;
                    cdrom_secondary_status &= ~cdrom_constants::STAT_READING; // clear reading bit (0x20)
                    // Deliver CD-ROM completion event
                    int handle = cdrom_event_id;
                    if (handle >= 0 && handle < EV_TABLE_SIZE && events[handle].used) {
                        events[handle].status = EvStALREADY;
                    }
                        if (g_verbose) printf("[CDROM] CdRead complete: %d sectors delivered, event fired at instr #%llu\n",
                               cdrom_sectors_read, g_cpu->instructions);
                    }
                }

                // Check pause
                if (cdrom_pause_requested) {
                    cdrom_reading = false;
                    cdrom_pause_requested = false;
                    cdrom_secondary_status &= ~cdrom_constants::STAT_READING; // clear reading bit (0x20)
                }
            }
        }

    // Called every instruction to advance hardware state
    void tick() {
        instr_since_vblank++;
        
        // VBlank period: last ~8% of frame (dot clock stops, Timer0 pauses)
        // PSX: ~263 scanlines, ~20 in VBlank = ~7.6%
        uint32_t vblank_start = vblank_interval - (vblank_interval / 13);  // ~7.7%
        if (instr_since_vblank >= vblank_start && !vblank_active) {
            vblank_active = true;
            // Fire VBlank interrupt at start of VBlank period
            vblank_counter++;
            // Toggle interlace field for GPUSTAT bit 31
            gpu_interlace_field = !gpu_interlace_field;
            if (g_cpu && g_verbose) {
                printf("[VBLANK] #%d fired at instr #%llu\n", vblank_counter, g_cpu->instructions);
            }
            // Don't assert I_STAT while in exception handler (EXL set) —
            // the game's HookEntryInt polls I_STAT directly and would loop
            // forever if VBlank re-asserts during handler execution.
            // VBlank will be re-asserted after ReturnFromException clears EXL.
            if (g_cpu && (g_cpu->cp0_status & 0x04)) {
                // EXL is set — skip I_STAT assertion but still count the VBlank
            } else {
                intc_stat |= 0x01;
                if (g_cpu) g_cpu->interrupt_pending = true;
            }
            process_input_queue();
            update_pad();
            // Increment VBlank counter in RAM at 0x800B63D8 (BIOS internal)
            {
                uint32_t off = ram_offset(0x800B63D8);
                uint32_t cur = ram[off] | (ram[off+1]<<8) | (ram[off+2]<<16) | (ram[off+3]<<24);
                cur++;
                ram[off] = cur & 0xFF;
                ram[off+1] = (cur >> 8) & 0xFF;
                ram[off+2] = (cur >> 16) & 0xFF;
                ram[off+3] = (cur >> 24) & 0xFF;
            }
            // Also write to 0x800BA294 — game's VSync function polls this address
            // (lui $v0,0x800C + lw $v0,0xA294($v0) = 0x800C0000 + (int16_t)0xA294 = 0x800BA294)
            {
                uint32_t off = ram_offset(0x800BA294);
                ram[off] = vblank_counter & 0xFF;
                ram[off+1] = (vblank_counter >> 8) & 0xFF;
                ram[off+2] = (vblank_counter >> 16) & 0xFF;
                ram[off+3] = (vblank_counter >> 24) & 0xFF;
                if (g_cpu && g_verbose) {
                    printf("[VBC2TICK] wrote %d to 0x800BA294 at instr #%llu\n", vblank_counter, g_cpu->instructions);
                }
            }
            // CD-ready flags (0x800B91CE, 0x800B91CC) are forced in read16
            // in psx_emulator_core.cpp — no VBlank writes needed here.
            // 0x800B9164 is NOT CD status — it's the Timer0 snapshot used by
            // the VSync function. Writing to it corrupts the spinlock.
        }
        
        // Tick timers (Timer0/dot clock pauses during VBlank)
        tick_timers();

        // Tick CD-ROM state machine (continuous sector delivery + IRQ timing)
        cdrom_tick();
        
        // End of frame: reset counters
        if (instr_since_vblank >= vblank_interval) {
            instr_since_vblank = 0;
            vblank_active = false;
        }
    }

    // Memory inspector: read 32-bit value from any address
    uint32_t inspect32(uint32_t addr) {
        return read32(addr);
    }

    ~PSX_Memory() {
        if (cd_file) fclose(cd_file);
    }

    bool load_cd(const char* path) {
        if (cd_file) { fclose(cd_file); cd_file = nullptr; }
        cd_file = fopen(path, "rb");
        if (!cd_file) return false;
        strncpy(cd_path, path, 511);
        cd_path[511] = 0;
        cd_loaded = true;
        return true;
    }

    bool load_bios(const char* path) {
        FILE* f = fopen(path, "rb");
        if (!f) return false;
        size_t n = fread(bios, 1, sizeof(bios), f);
        fclose(f);
        if (n != 0x80000) return false;
        use_real_bios = true;
        bios_loaded = true;
        return true;
    }

    // Read a 2048-byte user data sector from CD
    bool read_cd_sector(uint32_t lba, uint8_t* out) {
        if (!cd_file) return false;
        fseek(cd_file, (long)lba * 2352 + 24, SEEK_SET);
        size_t r = fread(out, 1, 2048, cd_file);
        return r == 2048;
    }

    // Memory access helpers
    uint32_t ram_offset(uint32_t addr) {
        return addr & 0x1FFFFF; // 2MB mirror
    }

    bool is_ram(uint32_t addr) {
        uint32_t seg = (addr >> 20) & 0xF;
        return (addr >= 0x00000000 && addr < 0x00200000) ||
               (addr >= 0x80000000 && addr < 0x80200000) ||
               (addr >= 0xA0000000 && addr < 0xA0200000);
    }

    uint32_t read32(uint32_t addr);
    uint16_t read16(uint32_t addr);
    uint8_t  read8(uint32_t addr);
    void     write32(uint32_t addr, uint32_t val);
    void     write16(uint32_t addr, uint16_t val);
    void     write8(uint32_t addr, uint8_t val);

    // EXE header values (set by load_exe_from_cd)
    uint32_t exe_init_gp;
    uint32_t exe_init_sp;

    // Find boot EXE from SYSTEM.CNF on CD
    bool find_boot_exe(uint32_t& out_lba, uint32_t& out_sectors, char* out_name = nullptr, int name_len = 0);

    // BIOS call handler — stub PSX BIOS functions
    bool handle_bios_call(uint32_t pc, MIPS_CPU& cpu);

    // Exception vector handler — HLE intercept of 0x80000080
    // Acknowledges VBlank in I_STAT, delivers events, returns to EPC
    bool handle_exception(MIPS_CPU& cpu);

    // Install a MIPS exception handler at 0x80000080 (fallback approach)
    void install_mips_exception_handler();

    // Load EXE from CD into RAM
    bool load_exe_from_cd(uint32_t exe_lba, uint32_t exe_sectors,
                          uint32_t& out_pc, uint32_t& out_dest, uint32_t& out_size);

    // ── Phase 4: CD-ROM ISO9660 directory parsing ──────────────────────────
    // Parse ISO9660 root directory and cache file LBA mappings
    bool parse_iso_directory();
    // Find file by path (e.g. "cdrom:FILE.EXT;1") and return LBA + size
    int find_cd_file(const char* path, uint32_t& out_lba, uint32_t& out_size);
    // Allocate a file descriptor
    int alloc_fdesc();
    // Read from CD file into RAM buffer
    int cd_read(int fd, uint32_t ram_buf, int nbytes);

    // ── Phase 5: PAD update (called on VBlank) ────────────────────────────
    void update_pad();
    // Write pad data to RAM buffers
    void write_pad_buffer(uint32_t buf_addr, uint16_t buttons,
                          uint8_t rx, uint8_t ry);
    // Process scriptable input queue
    void process_input_queue();
    // Queue a button press/release at a specific VBlank count
    void queue_input(uint64_t at_vblank, uint16_t buttons, bool press);

    // ── Phase 6: Debug helpers ────────────────────────────────────────────
    void add_watchpoint(uint32_t addr, uint32_t mask, bool on_read, bool on_write);
    bool check_watchpoint_read(uint32_t addr);
    bool check_watchpoint_write(uint32_t addr, uint32_t val);

    // Tick timers per instruction (PSX timers count continuously)
    void tick_timers();
    void push_call_stack(uint32_t call_pc, uint32_t target_pc);
    void pop_call_stack(uint32_t ret_pc);
    void dump_event_table();
    void dump_gpu_state();
    void dump_timer_state();
    void dump_call_stack();
    void dump_fdescs();
    void dump_full_state(MIPS_CPU& cpu);
};

// ── Static callback wrappers ─────────────────────────────────────────────────

static uint32_t cb_read32(uint32_t addr, void* ctx) {
    return ((PSX_Memory*)ctx)->read32(addr);
}
static uint16_t cb_read16(uint32_t addr, void* ctx) {
    return ((PSX_Memory*)ctx)->read16(addr);
}
static uint8_t cb_read8(uint32_t addr, void* ctx) {
    return ((PSX_Memory*)ctx)->read8(addr);
}
static void cb_write32(uint32_t addr, uint32_t val, void* ctx) {
    ((PSX_Memory*)ctx)->write32(addr, val);
}
static void cb_write16(uint32_t addr, uint16_t val, void* ctx) {
    ((PSX_Memory*)ctx)->write16(addr, val);
}
static void cb_write8(uint32_t addr, uint8_t val, void* ctx) {
    ((PSX_Memory*)ctx)->write8(addr, val);
}

#include "psx_gpu.h"
