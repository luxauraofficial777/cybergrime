# Convert DQ4 Setloc MSF entries to LBAs
# LBA = (M*60 + S)*75 + F - 150
$setlocs = @(
    '00:02:04', '00:02:05', '00:02:16', '00:02:18',
    '00:02:22', '00:02:23', '00:02:24', '00:02:25',
    '23:31:15', '23:52:36', '00:06:63', '00:06:66',
    '23:52:58', '00:10:15', '23:39:40',
    '00:06:62', '00:06:63', '00:06:66',
    '23:44:19', '23:46:64', '23:49:41', '23:46:64'
)

Write-Host "=== DQ4 Setloc MSF -> LBA ==="
foreach ($msf in $setlocs) {
    $parts = $msf.Split(':')
    $m = [int]$parts[0]
    $s = [int]$parts[1]
    $f = [int]$parts[2]
    $lba = ($m * 60 + $s) * 75 + $f - 150
    Write-Host ("  {0} -> LBA {1} (0x{1:X})" -f $msf, $lba)
}

Write-Host ""
Write-Host "=== DW7 FMV LBA 146621 (0x23C7D) search in EXE ==="
$exePath = 'c:\LuxAura\VoidWalkers_Project\DQLOSTTRANSLATION\translation\SLUSP012.06'
$bytes = [System.IO.File]::ReadAllBytes($exePath)
$loadAddr = 0x80017F00

# Search for 146621 as 32-bit LE (7D 3C 02 00)
$target = [BitConverter]::GetBytes([uint32]146621)
$pattern = ($target | ForEach-Object { $_.ToString('X2') }) -join ' '
Write-Host "Searching for LE pattern: $pattern"

for ($i = 0x800; $i -lt $bytes.Length - 3; $i += 4) {
    if ($bytes[$i] -eq $target[0] -and $bytes[$i+1] -eq $target[1] -and $bytes[$i+2] -eq $target[2] -and $bytes[$i+3] -eq $target[3]) {
        $ram = $loadAddr + $i - 0x800
        # Show surrounding context
        $prev = [BitConverter]::ToUInt32($bytes, $i - 4)
        $next = [BitConverter]::ToUInt32($bytes, $i + 4)
        Write-Host ("  FOUND at file 0x{0:X} (RAM 0x{1:X8})  prev=0x{2:X8}  val=0x{3:X8}  next=0x{4:X8}" -f $i, $ram, $prev, 146621, $next)
    }
}

# Also search for 146621 as 16-bit LE (might be split across two instructions)
Write-Host ""
Write-Host "=== Also searching for 0x023C (high 16 bits) and 0xC7D (low 16 bits) ==="
# addiu $rt, $rs, 0xC7D = 0x24__C7D or lui $rt, 0x023C = 0x3C__023C
for ($i = 0x800; $i -lt $bytes.Length - 3; $i += 4) {
    $insn = [BitConverter]::ToUInt32($bytes, $i)
    # lui $rt, 0x023C
    if (($insn -band 0xFFE0FFFF) -eq 0x3C00023C) {
        $rt = ($insn -shr 16) -band 0x1F
        $ram = $loadAddr + $i - 0x800
        $next = [BitConverter]::ToUInt32($bytes, $i + 4)
        Write-Host ("  lui $${rt}, 0x023C at RAM 0x{0:X8} (file 0x{1:X})  next=0x{2:X8}" -f $ram, $i, $next)
    }
    # addiu $rt, $rs, 0xC7D (sign-extended, could be 0x24__0C7D)
    if (($insn -band 0xFFFF0000) -eq 0x24000000 -and (($insn -band 0x0000FFFF) -eq 0x0000C7D -or ($insn -band 0x0000FFFF) -eq 0x000023C7D)) {
        $ram = $loadAddr + $i - 0x800
        Write-Host ("  addiu with 0xC7D at RAM 0x{0:X8} (file 0x{1:X})  insn=0x{2:X8}" -f $ram, $i, $insn)
    }
}

# Search for MSF in BCD: 32:34:71 = 0x32 0x34 0x71
Write-Host ""
Write-Host "=== Search for BCD MSF 32:34:71 (0x32 0x34 0x71) ==="
for ($i = 0x800; $i -lt $bytes.Length - 3; $i++) {
    if ($bytes[$i] -eq 0x32 -and $bytes[$i+1] -eq 0x34 -and $bytes[$i+2] -eq 0x71) {
        $ram = $loadAddr + $i - 0x800
        Write-Host ("  FOUND BCD MSF at file 0x{0:X} (RAM 0x{1:X8})" -f $i, $ram)
    }
}
