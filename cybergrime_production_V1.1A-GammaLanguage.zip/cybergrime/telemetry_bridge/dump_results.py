import json
data = json.load(open(r'c:\LuxAura\VoidWalkers_Project\DQLOSTTRANSLATION\cybergrime\telemetry_bridge\bridge_test_results.json','r'))
for r in data:
    if r.get('env') == 'Cybergrime':
        print(f'{r["disc"]} {r["bios"]}: exit={r.get("exit_code","?")}')
        s = r.get('stdout','')
        if s:
            print(f'  stdout[:800]={s[:800]}')
        e = r.get('stderr','')
        if e:
            print(f'  stderr[:500]={e[:500]}')
        t = r.get('telemetry',{})
        print(f'  telemetry={t}')
        print()
