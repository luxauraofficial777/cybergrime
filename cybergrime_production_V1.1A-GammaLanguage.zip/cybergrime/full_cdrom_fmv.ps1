$log = 'C:\LuxAura\VoidWalkers_Project\DuckStation\duckstation.log'
$lines = Get-Content $log
Write-Host "=== Full CDROM commands from Frankenstein FMV build ==="
$lines | Where-Object { $_ -match 'Setloc|Setmode|ReadN|ReadS|Pause|Play|Demute|Init|Getstat|Getmode|DataSector' } | ForEach-Object { Write-Output $_ }
