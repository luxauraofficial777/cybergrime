#pragma once
// ============================================================================
// instrumentation_bus.h — Live Instrumentation Bus for CyberGrime
// ============================================================================
// Bidirectional named-pipe communication between the PSX emulator and a
// Python analysis sidecar. Emits real-time CPU state, memory accesses, and
// VFS events. Receives patch commands (WRITE_MEM, WRITE_REG, SET_PC, etc.)
// for deterministic in-memory patch testing before burning to ROM.
//
// Protocol: JSON Lines (newline-delimited JSON objects)
// Pipe:     \\.\pipe\cybergrime_live
//
// Emulator → Python (emit):
//   {"type":"state","instr":N,"pc":"0x...","regs":{...},"hi":"0x..","lo":"0x..","sr":"0x..","vblank":N}
//   {"type":"mem","instr":N,"addr":"0x...","value":"0x...","write":bool,"pc":"0x..."}
//   {"type":"vfs","instr":N,"resource":"...","lba":N,"resolved":bool,"pc":"0x..."}
//   {"type":"bp_hit","pc":"0x...","instr":N,"regs":{...}}
//   {"type":"divergence","instr":N,"pc":"0x...","expected":"...","actual":"...","detail":"...","severity":"..."}
//
// Python → Emulator (inject):
//   {"type":"WRITE_MEM","addr":"0x...","value":"0x...","size":N,"description":"..."}
//   {"type":"WRITE_REG","addr":N,"value":"0x...","description":"..."}
//   {"type":"SET_PC","addr":"0x...","description":"..."}
//   {"type":"SET_BREAKPOINT","addr":"0x...","description":"..."}
//   {"type":"DUMP_REGION","addr":"0x...","size":N,"description":"..."}
//   {"type":"ROLLBACK","description":"..."}
// ============================================================================

#include <windows.h>
#include <cstdint>
#include <cstdio>
#include <cstring>
#include <string>
#include <vector>
#include <queue>
#include <mutex>

// Forward declarations
class MIPS_CPU;
class PSX_Memory;

// ── Patch Command (Python → Emulator) ────────────────────────────────────────
struct PatchCommand {
    enum Type {
        WRITE_MEM,
        WRITE_REG,
        SET_PC,
        SET_BREAKPOINT,
        REMOVE_BREAKPOINT,
        DUMP_REGION,
        ROLLBACK
    };
    Type type;
    uint32_t addr;          // RAM address or register index
    uint32_t value;         // Value to write
    uint32_t size;          // Byte count (for WRITE_MEM / DUMP_REGION)
    char description[128];
};

// ── Patch History (for rollback) ─────────────────────────────────────────────
struct MemPatchRecord {
    uint32_t addr;
    uint32_t original_value;
    uint32_t size;
};

struct RegPatchRecord {
    int reg_idx;
    uint32_t original_value;
};

// ── Instrumentation Bus ──────────────────────────────────────────────────────
class InstrumentationBus {
public:
    InstrumentationBus();
    ~InstrumentationBus();

    // ── Lifecycle ──
    bool start(const char* pipe_name, uint64_t emit_interval);
    void stop();
    bool is_enabled() const { return m_enabled; }
    bool is_connected() const { return m_connected; }

    // ── Emit (Emulator → Python) ──
    void emit_state(uint64_t instr_count, uint32_t pc,
                    const uint32_t regs[32], uint32_t hi, uint32_t lo,
                    uint32_t cp0_status, uint32_t vblank_count);
    void emit_mem_access(uint32_t addr, uint32_t value, bool is_write,
                         uint32_t pc, uint64_t instr_count);
    void emit_vfs(const char* resource, uint32_t lba, bool resolved,
                  uint32_t pc, uint64_t instr_count);
    void emit_breakpoint_hit(uint32_t bp_addr, uint64_t instr_count,
                             const uint32_t regs[32]);
    void emit_divergence(uint64_t instr_count, uint32_t pc,
                         const char* expected, const char* actual,
                         const char* detail, const char* severity);

    // ── Inject (Python → Emulator) ──
    bool has_pending_patches();
    PatchCommand pop_patch();
    void apply_patch(MIPS_CPU& cpu, PSX_Memory& mem);

    // ── Called from emulator main loop ──
    void tick(uint64_t instr_count, uint32_t pc, MIPS_CPU& cpu, PSX_Memory& mem);

    // ── Called on breakpoint hit ──
    void on_breakpoint(uint32_t bp_addr, uint64_t instr_count, MIPS_CPU& cpu,
                       PSX_Memory& mem);

private:
    HANDLE m_pipe;          // Named pipe handle
    HANDLE m_recv_thread;   // Reader thread for incoming commands
    bool m_connected;
    bool m_enabled;
    bool m_running;
    uint64_t m_emit_interval;
    uint64_t m_last_emit_instr;

    std::mutex m_write_mutex;     // Protects pipe writes
    std::mutex m_patch_mutex;     // Protects patch queue
    std::queue<PatchCommand> m_pending_patches;

    // Patch history for rollback
    std::vector<MemPatchRecord> m_mem_history;
    std::vector<RegPatchRecord> m_reg_history;

    // ── Internal helpers ──
    void write_json(const char* json_str);
    void parse_command(const char* json_str);
    static DWORD WINAPI recv_thread_proc(LPVOID param);
    void recv_loop();

    // JSON helpers
    static void format_regs(char* buf, size_t bufsize, const uint32_t regs[32]);
    static uint32_t parse_hex(const char* s);
    static uint32_t parse_uint(const char* s);
};

// Global instance
extern InstrumentationBus* g_instr_bus;
