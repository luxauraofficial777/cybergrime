#!/usr/bin/env python3
"""Search the disc EXE for BCD patterns and compare with clean EXE."""
import struct

SECTOR_SIZE = 2352
USER_SIZE = 2048
EXE_LBA = 24
HEADER = 24

disc_path = r"C:\LuxAura\VoidWalkers_Project\DQLOSTTRANSLATION\build_staging\dq4_gold.bin"
clean_path = r"C:\LuxAura\VoidWalkers_Project\DQLOSTTRANSLATION\translation\SLUSP012.06_clean.bin"

with open(disc_path, "rb") as f:
    disc = f.read()
with open(clean_path, "rb") as f:
    clean = f.read()

# Extract EXE from disc
exe_start = EXE_LBA * SECTOR_SIZE + HEADER
disc_exe = disc[exe_start:exe_start + 677888]

print(f"Clean EXE: {len(clean)} bytes")
print(f"Disc EXE:  {len(disc_exe)} bytes")

# Search both for 32:34:71 and 23:31:08
for name, data in [("clean", clean), ("disc", disc_exe)]:
    for pat_name, pat in [("32:34:71", bytes([0x32,0x34,0x71])), 
                           ("23:31:08", bytes([0x23,0x31,0x08])),
                           ("23:31:15", bytes([0x23,0x31,0x15]))]:
        idx = 0
        matches = []
        while True:
            idx = data.find(pat, idx)
            if idx == -1: break
            matches.append(idx)
            idx += 1
        if matches:
            print(f"\n{name} EXE — {pat_name}: {len(matches)} matches")
            for m in matches[:10]:
                ctx = data[max(0,m-8):m+11].hex()
                ram = m + 0x80017F00
                print(f"  0x{m:06X} (RAM 0x{ram:08X}) ctx: {ctx}")
        else:
            print(f"\n{name} EXE — {pat_name}: 0 matches")

# Now compare the region around 0x092936 in both EXEs
print(f"\n=== Clean EXE at 0x092936 ===")
print(f"  {clean[0x092936-8:0x092936+11].hex()}")
print(f"\n=== Disc EXE at 0x092936 ===")
print(f"  {disc_exe[0x092936-8:0x092936+11].hex()}")

# Find where the clean EXE's data at 0x092936 ended up in the disc EXE
# by searching for the surrounding context
context = clean[0x092936-16:0x092936+20]
print(f"\nClean context (32 bytes around 0x092936): {context.hex()}")
idx = disc_exe.find(context)
if idx != -1:
    print(f"Found in disc EXE at 0x{idx+16:06X} (RAM 0x{idx+16+0x80017F00:08X})")
    print(f"  BCD bytes at that location: {disc_exe[idx+16:idx+19].hex()}")
else:
    print("Context not found in disc EXE — data was modified")
    # Try a shorter context
    short_ctx = clean[0x092936-4:0x092936+7]
    print(f"Trying short context: {short_ctx.hex()}")
    idx = disc_exe.find(short_ctx)
    if idx != -1:
        print(f"Found at 0x{idx+4:06X}")
        print(f"  BCD bytes: {disc_exe[idx+4:idx+7].hex()}")
    else:
        print("Short context also not found")
