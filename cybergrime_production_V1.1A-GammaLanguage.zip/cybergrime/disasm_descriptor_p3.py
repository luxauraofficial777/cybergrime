#!/usr/bin/env python3
"""
P0 Phase 3: Disassemble malloc at 0x80097980, find heap config,
and trace how $s2 is set in the crash function's parent.
"""
import struct

EXE_PATH = r"..\translation\SLUSP012.06"
LOAD_ADDR = 0x80017F00
EXE_HDR_SIZE = 0x800

def ram_to_file(ram_addr):
    return ram_addr - LOAD_ADDR + EXE_HDR_SIZE

def file_to_ram(file_off):
    return file_off + LOAD_ADDR - EXE_HDR_SIZE

def read_exe(path):
    with open(path, "rb") as f:
        return f.read()

REG_NAMES = ["$zero","$at","$v0","$v1","$a0","$a1","$a2","$a3",
             "$t0","$t1","$t2","$t3","$t4","$t5","$t6","$t7",
             "$s0","$s1","$s2","$s3","$s4","$s5","$s6","$s7",
             "$t8","$t9","$k0","$k1","$gp","$sp","$fp","$ra"]

def sign_extend16(v):
    return v - 0x10000 if v & 0x8000 else v

def disasm_one(word, pc):
    op = (word >> 26) & 0x3F
    rs = (word >> 21) & 0x1F
    rt = (word >> 16) & 0x1F
    rd = (word >> 11) & 0x1F
    shamt = (word >> 6) & 0x1F
    funct = word & 0x3F
    imm = word & 0xFFFF
    simm = sign_extend16(imm)
    target = word & 0x3FFFFFF
    if op == 0x00:
        if funct == 0x20: return f"add {REG_NAMES[rd]}, {REG_NAMES[rs]}, {REG_NAMES[rt]}"
        if funct == 0x21: return f"addu {REG_NAMES[rd]}, {REG_NAMES[rs]}, {REG_NAMES[rt]}"
        if funct == 0x22: return f"sub {REG_NAMES[rd]}, {REG_NAMES[rs]}, {REG_NAMES[rt]}"
        if funct == 0x23: return f"subu {REG_NAMES[rd]}, {REG_NAMES[rs]}, {REG_NAMES[rt]}"
        if funct == 0x24: return f"and {REG_NAMES[rd]}, {REG_NAMES[rs]}, {REG_NAMES[rt]}"
        if funct == 0x25: return f"or  {REG_NAMES[rd]}, {REG_NAMES[rs]}, {REG_NAMES[rt]}"
        if funct == 0x26: return f"xor {REG_NAMES[rd]}, {REG_NAMES[rs]}, {REG_NAMES[rt]}"
        if funct == 0x27: return f"nor {REG_NAMES[rd]}, {REG_NAMES[rs]}, {REG_NAMES[rt]}"
        if funct == 0x2A: return f"slt {REG_NAMES[rd]}, {REG_NAMES[rs]}, {REG_NAMES[rt]}"
        if funct == 0x2B: return f"sltu {REG_NAMES[rd]}, {REG_NAMES[rs]}, {REG_NAMES[rt]}"
        if funct == 0x00:
            if word == 0: return "nop"
            return f"sll {REG_NAMES[rd]}, {REG_NAMES[rt]}, {shamt}"
        if funct == 0x02: return f"srl {REG_NAMES[rd]}, {REG_NAMES[rt]}, {shamt}"
        if funct == 0x03: return f"sra {REG_NAMES[rd]}, {REG_NAMES[rt]}, {shamt}"
        if funct == 0x04: return f"sllv {REG_NAMES[rd]}, {REG_NAMES[rt]}, {REG_NAMES[rs]}"
        if funct == 0x06: return f"srlv {REG_NAMES[rd]}, {REG_NAMES[rt]}, {REG_NAMES[rs]}"
        if funct == 0x07: return f"srav {REG_NAMES[rd]}, {REG_NAMES[rt]}, {REG_NAMES[rs]}"
        if funct == 0x08: return f"jr {REG_NAMES[rs]}"
        if funct == 0x09: return f"jalr {REG_NAMES[rd]}, {REG_NAMES[rs]}"
        if funct == 0x0C: return f"syscall"
        if funct == 0x10: return f"mfhi {REG_NAMES[rd]}"
        if funct == 0x12: return f"mflo {REG_NAMES[rd]}"
        if funct == 0x18: return f"mult {REG_NAMES[rs]}, {REG_NAMES[rt]}"
        if funct == 0x19: return f"multu {REG_NAMES[rs]}, {REG_NAMES[rt]}"
        if funct == 0x1A: return f"div {REG_NAMES[rs]}, {REG_NAMES[rt]}"
        if funct == 0x1B: return f"divu {REG_NAMES[rs]}, {REG_NAMES[rt]}"
        return f".special 0x{funct:02x}"
    if op == 0x01:
        if rt == 0x00: return f"bltz {REG_NAMES[rs]}, 0x{pc + 4 + simm*4:08X}"
        if rt == 0x01: return f"bgez {REG_NAMES[rs]}, 0x{pc + 4 + simm*4:08X}"
        return f".regimm 0x{rt:02x}"
    if op == 0x02: return f"j 0x{(pc & 0xF0000000) | (target << 2):08X}"
    if op == 0x03: return f"jal 0x{(pc & 0xF0000000) | (target << 2):08X}"
    if op == 0x04: return f"beq {REG_NAMES[rs]}, {REG_NAMES[rt]}, 0x{pc + 4 + simm*4:08X}"
    if op == 0x05: return f"bne {REG_NAMES[rs]}, {REG_NAMES[rt]}, 0x{pc + 4 + simm*4:08X}"
    if op == 0x06: return f"blez {REG_NAMES[rs]}, 0x{pc + 4 + simm*4:08X}"
    if op == 0x07: return f"bgtz {REG_NAMES[rs]}, 0x{pc + 4 + simm*4:08X}"
    if op == 0x08: return f"addi {REG_NAMES[rt]}, {REG_NAMES[rs]}, {simm}"
    if op == 0x09: return f"addiu {REG_NAMES[rt]}, {REG_NAMES[rs]}, {simm}"
    if op == 0x0A: return f"slti {REG_NAMES[rt]}, {REG_NAMES[rs]}, {simm}"
    if op == 0x0B: return f"sltiu {REG_NAMES[rt]}, {REG_NAMES[rs]}, {simm}"
    if op == 0x0C: return f"andi {REG_NAMES[rt]}, {REG_NAMES[rs]}, 0x{imm:04X}"
    if op == 0x0D: return f"ori {REG_NAMES[rt]}, {REG_NAMES[rs]}, 0x{imm:04X}"
    if op == 0x0E: return f"xori {REG_NAMES[rt]}, {REG_NAMES[rs]}, 0x{imm:04X}"
    if op == 0x0F: return f"lui {REG_NAMES[rt]}, 0x{imm:04X}"
    if op == 0x20: return f"lb {REG_NAMES[rt]}, {simm}({REG_NAMES[rs]})"
    if op == 0x21: return f"lh {REG_NAMES[rt]}, {simm}({REG_NAMES[rs]})"
    if op == 0x23: return f"lw {REG_NAMES[rt]}, {simm}({REG_NAMES[rs]})"
    if op == 0x24: return f"lbu {REG_NAMES[rt]}, {simm}({REG_NAMES[rs]})"
    if op == 0x25: return f"lhu {REG_NAMES[rt]}, {simm}({REG_NAMES[rs]})"
    if op == 0x28: return f"sb {REG_NAMES[rt]}, {simm}({REG_NAMES[rs]})"
    if op == 0x29: return f"sh {REG_NAMES[rt]}, {simm}({REG_NAMES[rs]})"
    if op == 0x2B: return f"sw {REG_NAMES[rt]}, {simm}({REG_NAMES[rs]})"
    return f".word 0x{word:08X}"

def disasm_range(data, start_ram, count, label=""):
    start_file = ram_to_file(start_ram)
    print(f"\n{'='*80}")
    print(f"  {label}: RAM 0x{start_ram:08X}")
    print(f"{'='*80}")
    for i in range(count):
        off = start_file + i * 4
        if off + 4 > len(data):
            print(f"  0x{start_ram + i*4:08X}:  <out of range>")
            continue
        word = struct.unpack_from("<I", data, off)[0]
        pc = start_ram + i * 4
        asm = disasm_one(word, pc)
        print(f"  0x{pc:08X}: {word:08X}  {asm}")

def find_function_prologue(data, addr, max_back=500):
    """Search backwards for addiu $sp, $sp, -N (function prologue)."""
    start_file = ram_to_file(addr)
    for i in range(max_back):
        off = start_file - (i + 1) * 4
        if off < EXE_HDR_SIZE:
            break
        word = struct.unpack_from("<I", data, off)[0]
        op = (word >> 26) & 0x3F
        if op == 0x09:  # addiu
            rt = (word >> 16) & 0x1F
            rs = (word >> 21) & 0x1F
            simm = sign_extend16(word & 0xFFFF)
            if rt == 29 and rs == 29 and simm < 0:
                # addiu $sp, $sp, -N — function prologue
                return file_to_ram(off)
    return None

def find_callers(data, target_ram):
    target_field = (target_ram >> 2) & 0x3FFFFFF
    callers = []
    for off in range(EXE_HDR_SIZE, len(data) - 4, 4):
        word = struct.unpack_from("<I", data, off)[0]
        op = (word >> 26) & 0x3F
        if op == 0x03:  # jal
            t = word & 0x3FFFFFF
            if t == target_field:
                callers.append(file_to_ram(off))
    return callers

def main():
    data = read_exe(EXE_PATH)
    print(f"EXE: {len(data)} bytes, load 0x{LOAD_ADDR:08X}")

    # 1. Disassemble malloc at 0x80097980
    disasm_range(data, 0x80097980, 80, "MALLOC/ALLOC at 0x80097980")

    # 2. Find the real function prologue containing the crash at 0x800761DC
    prologue = find_function_prologue(data, 0x800761DC, max_back=500)
    if prologue:
        print(f"\n  Function prologue found at 0x{prologue:08X}")
        disasm_range(data, prologue, 200, f"Full crash function from 0x{prologue:08X}")
    else:
        print(f"\n  No prologue found within 500 instructions back")

    # 3. Find callers of 0x80097980 (malloc)
    print(f"\n{'='*80}")
    print(f"  CALLERS of malloc 0x80097980")
    print(f"{'='*80}")
    callers = find_callers(data, 0x80097980)
    for c in callers[:20]:
        print(f"  0x{c:08X}: jal 0x80097980")

    # 4. Find callers of 0x8009A29C (called at 0x80076184)
    print(f"\n{'='*80}")
    print(f"  CALLERS of 0x8009A29C (called before crash)")
    print(f"{'='*80}")
    callers2 = find_callers(data, 0x8009A29C)
    for c in callers2[:20]:
        print(f"  0x{c:08X}: jal 0x8009A29C")

    # 5. Disassemble 0x8009A29C
    disasm_range(data, 0x8009A29C, 60, "Function at 0x8009A29C")

    # 6. Search for heap initialization — look for writes to 0x800D9A28 (bump base)
    # Using lui 0x800E + sw pattern
    print(f"\n{'='*80}")
    print(f"  Searching for lui 0x800E + sw/lw with 0x9Axx offsets (0x800D9Axx)")
    print(f"{'='*80}")
    for off in range(EXE_HDR_SIZE, len(data) - 4, 4):
        word = struct.unpack_from("<I", data, off)[0]
        op = (word >> 26) & 0x3F
        if op != 0x0F:
            continue
        rt = (word >> 16) & 0x1F
        imm = word & 0xFFFF
        if imm != 0x800E:
            continue
        for i in range(1, 12):
            next_off = off + i * 4
            if next_off + 4 > len(data):
                break
            next_word = struct.unpack_from("<I", data, next_off)[0]
            next_op = (next_word >> 26) & 0x3F
            next_imm = next_word & 0xFFFF
            if next_imm >= 0x9A00 and next_imm <= 0x9BFF:
                next_rs = (next_word >> 21) & 0x1F
                next_rt = (next_word >> 16) & 0x1F
                if next_rs == rt or next_rt == rt:
                    ram = file_to_ram(next_off)
                    computed = 0x800E0000 + sign_extend16(next_imm)
                    asm = disasm_one(next_word, ram)
                    print(f"  0x{ram:08X}: {next_word:08X}  {asm}  => 0x{computed:08X}")
            if next_op == 0x0F:
                break

    # 7. Search for 0x80190000 (mentioned as bump base in BSS gap doc)
    print(f"\n{'='*80}")
    print(f"  Searching for 0x80190000 (heap/bump base)")
    print(f"{'='*80}")
    target_hi = 0x8019
    for off in range(EXE_HDR_SIZE, len(data) - 4, 4):
        word = struct.unpack_from("<I", data, off)[0]
        op = (word >> 26) & 0x3F
        if op == 0x0F:  # lui
            rt = (word >> 16) & 0x1F
            imm = word & 0xFFFF
            if imm == target_hi:
                ram = file_to_ram(off)
                print(f"  0x{ram:08X}: lui {REG_NAMES[rt]}, 0x{imm:04X}  => 0x80190000")
                # Show next few instructions
                for j in range(1, 6):
                    noff = off + j * 4
                    if noff + 4 > len(data):
                        break
                    nw = struct.unpack_from("<I", data, noff)[0]
                    nram = file_to_ram(noff)
                    asm = disasm_one(nw, nram)
                    print(f"    0x{nram:08X}: {nw:08X}  {asm}")

    # 8. Search for 0x80100000 (heap base alternative)
    print(f"\n{'='*80}")
    print(f"  Searching for 0x80100000 references")
    print(f"{'='*80}")
    for off in range(EXE_HDR_SIZE, len(data) - 4, 4):
        word = struct.unpack_from("<I", data, off)[0]
        op = (word >> 26) & 0x3F
        if op == 0x0F:
            rt = (word >> 16) & 0x1F
            imm = word & 0xFFFF
            if imm == 0x8010:
                ram = file_to_ram(off)
                print(f"  0x{ram:08X}: lui {REG_NAMES[rt]}, 0x{imm:04X}")

if __name__ == "__main__":
    main()
