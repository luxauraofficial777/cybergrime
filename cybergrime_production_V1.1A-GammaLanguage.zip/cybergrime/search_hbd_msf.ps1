# The XA/STR function at 0x8008AEF4 calls 0x8008B65C which does some math
# but doesn't seem to be the Setloc function. The XA/STR function then
# iterates through a table at 0x800D58D0 (BSS, populated at runtime).
#
# The FMV MSF must be stored in the HBD data or computed from it.
# The BCD 32:34:71 at EXE offset 0x92936 was patched but the game
# still seeks to 32:34:71. This means:
# 1. The patched value IS in the EXE on disc, but
# 2. The game reads the MSF from somewhere else (HBD data or BSS)
#
# The HBD is loaded into RAM at runtime, populating BSS variables.
# The FMV MSF is likely stored in the HBD and loaded into a BSS variable.
#
# Instead of tracing the exact code path, let me try a different approach:
# Search the DQ4 HBD data for the BCD MSF 23:31:15 (the DQ4 FMV location).
# If the HBD already contains the correct MSF, then the problem is that
# the DW7 EXE is reading from a different offset in the HBD than expected.
#
# OR: The DW7 EXE has the FMV MSF hardcoded in its DATA section
# (at 0x92936) AND also reads it from the HBD. The HBD value
# overrides the EXE value.
#
# Let me check the DQ4 HBD for BCD MSF values.

$dq4Bin = 'c:\LuxAura\VoidWalkers_Project\DQLOSTTRANSLATION\cybergrime\dq4_reverse_v97_fmv.bin'
$fs = [System.IO.File]::OpenRead($dq4Bin)

# HBD is at sector 362 on the DQ4 disc (native position)
# Read first 100 sectors of HBD and search for BCD MSF patterns
$hbdLBA = 362
$hbdSectors = 200  # Read 200 sectors (~400KB)
$hbdData = New-Object byte[] ($hbdSectors * 2048)

for ($s = 0; $s -lt $hbdSectors; $s++) {
    $buf = New-Object byte[] 2352
    $fs.Seek(($hbdLBA + $s) * 2352, 'Begin') | Out-Null
    $fs.Read($buf, 0, 2352) | Out-Null
    [Array]::Copy($buf, 24, $hbdData, $s * 2048, 2048)
}
$fs.Close()

# Search for BCD 32:34:71 in HBD
Write-Host "=== BCD 32 34 71 in DQ4 HBD ==="
$count = 0
for ($i = 0; $i -lt $hbdData.Length - 2; $i++) {
    if ($hbdData[$i] -eq 0x32 -and $hbdData[$i+1] -eq 0x34 -and $hbdData[$i+2] -eq 0x71) {
        $sector = [Math]::Floor($i / 2048)
        $offset = $i % 2048
        Write-Host ("  HBD sector +{0} offset 0x{1:X} (byte {2})" -f $sector, $offset, $i)
        $count++
        if ($count -ge 10) { break }
    }
}
Write-Host "Total: $count"

# Search for BCD 23:31:15 in HBD (DQ4 FMV location)
Write-Host ""
Write-Host "=== BCD 23 31 15 in DQ4 HBD ==="
$count = 0
for ($i = 0; $i -lt $hbdData.Length - 2; $i++) {
    if ($hbdData[$i] -eq 0x23 -and $hbdData[$i+1] -eq 0x31 -and $hbdData[$i+2] -eq 0x15) {
        $sector = [Math]::Floor($i / 2048)
        $offset = $i % 2048
        Write-Host ("  HBD sector +{0} offset 0x{1:X} (byte {2})" -f $sector, $offset, $i)
        $count++
        if ($count -ge 10) { break }
    }
}
Write-Host "Total: $count"

# Also search for any BCD MSF pattern (MM:SS:FF where MM is 00-99 BCD, SS is 00-59 BCD, FF is 00-74 BCD)
# BCD MM: 0x00-0x99, BCD SS: 0x00-0x59, BCD FF: 0x00-0x74
# This is too broad. Let me search for patterns near the known DW7 FMV location.
# The DW7 FMV is at 32:34:71. Let me search for 0x32 followed by 0x34 in HBD
Write-Host ""
Write-Host "=== BCD 32 34 XX in DQ4 HBD (any frame) ==="
$count = 0
for ($i = 0; $i -lt $hbdData.Length - 2; $i++) {
    if ($hbdData[$i] -eq 0x32 -and $hbdData[$i+1] -eq 0x34) {
        $sector = [Math]::Floor($i / 2048)
        $offset = $i % 2048
        Write-Host ("  HBD sector +{0} offset 0x{1:X}: {2:X2} {3:X2} {4:X2}" -f $sector, $offset, $hbdData[$i], $hbdData[$i+1], $hbdData[$i+2])
        $count++
        if ($count -ge 20) { break }
    }
}
Write-Host "Total: $count"
