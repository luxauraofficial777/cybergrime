// dump_dq4_block.cpp — Extract first valid DQ4 HBD block and dump tree structure
#include "psx_binary_ops.h"
#include <cstdio>
#include <cstring>
#include <fstream>
#include <vector>

static std::vector<uint8_t> read_file(const char* path) {
    std::ifstream f(path, std::ios::binary);
    if (!f.is_open()) return {};
    return std::vector<uint8_t>((std::istreambuf_iterator<char>(f)),
                                 std::istreambuf_iterator<char>());
}

int main() {
    const char* dq4_disc = "c:\\LuxAura\\VoidWalkers_Project\\DQLOSTTRANSLATION\\Dragon Quest IV - Michibikareshi Mono Tachi (Japan).bin";
    const char* hybrid_tree_path = "c:\\LuxAura\\VoidWalkers_Project\\DQLOSTTRANSLATION\\frozen\\dw7_hybrid_tree.bin";
    
    printf("=== DQ4 HBD Block Tree Dump ===\n\n");
    
    // Extract DQ4 HBD using IsoImage
    printf("Extracting DQ4 HBD from sector %u, size=%u...\n", DQ4_HBD_DISC_START, DQ4_HBD_SIZE);
    IsoImage iso;
    if (!iso.open(dq4_disc)) {
        printf("ERROR: Cannot open DQ4 disc\n");
        return 1;
    }
    printf("Disc sector size: %u\n", iso.sector_size());
    
    std::vector<uint8_t> dq4_hbd(DQ4_HBD_SIZE, 0);
    uint32_t sectors = DQ4_HBD_SIZE / USER_SIZE;
    for (uint32_t i = 0; i < sectors; i++) {
        if (iso.read_sector(DQ4_HBD_DISC_START + i, dq4_hbd.data() + i * USER_SIZE) < 0) {
            printf("ERROR: Read failed at sector %u\n", DQ4_HBD_DISC_START + i);
            break;
        }
    }
    iso.close();
    printf("DQ4 HBD: %u bytes extracted\n\n", (uint32_t)dq4_hbd.size());
    
    // Parse first few blocks looking for hts=24 with per-block tree
    uint32_t offset = 0;
    int blocks_found = 0;
    
    while (offset + 24 < dq4_hbd.size() && blocks_found < 3) {
        uint32_t end, block_id, hts, tree_end, text_end, unk;
        memcpy(&end, dq4_hbd.data() + offset, 4);
        memcpy(&block_id, dq4_hbd.data() + offset + 4, 4);
        memcpy(&hts, dq4_hbd.data() + offset + 8, 4);
        memcpy(&tree_end, dq4_hbd.data() + offset + 12, 4);
        memcpy(&text_end, dq4_hbd.data() + offset + 16, 4);
        memcpy(&unk, dq4_hbd.data() + offset + 20, 4);
        
        if (hts != 24 || end < 24 || end > 1048576 || offset + end > dq4_hbd.size()) {
            offset += 4;
            continue;
        }
        
        printf("--- Block %d at offset %u ---\n", blocks_found, offset);
        printf("  end=%u block_id=%u(0x%X) hts=%u tree_end=%u text_end=%u unk=%u\n",
               end, block_id, block_id, hts, tree_end, text_end, unk);
        
        if (tree_end > 0 && text_end > 0 && tree_end <= end && text_end <= end) {
            // Has per-block tree
            if (offset + text_end + 10 <= dq4_hbd.size()) {
                uint32_t tree_start, tree_middle;
                uint16_t tree_nodes;
                memcpy(&tree_start, dq4_hbd.data() + offset + text_end, 4);
                memcpy(&tree_middle, dq4_hbd.data() + offset + text_end + 4, 4);
                memcpy(&tree_nodes, dq4_hbd.data() + offset + text_end + 8, 2);
                
                printf("  tree_start=%u tree_middle=%u tree_nodes=%u\n", tree_start, tree_middle, tree_nodes);
                
                if (tree_end > tree_start && offset + tree_end <= dq4_hbd.size()) {
                    uint32_t tree_size = tree_end - tree_start;
                    printf("  tree_size=%u bytes\n", tree_size);
                    
                    // Dump first 64 bytes of tree data
                    printf("  Tree data (first 64 bytes):\n");
                    for (uint32_t i = 0; i < tree_size && i < 64; i += 2) {
                        uint16_t val = dq4_hbd[offset + tree_start + i] | (dq4_hbd[offset + tree_start + i + 1] << 8);
                        const char* type = (val & 0x8000) ? "BRANCH" : "LEAF";
                        printf("    [%4u] 0x%04X (%s, id=%u)\n", i, val, type, val & 0x7FFF);
                    }
                    
                    // Parse with DQ4 convention
                    HuffTree dq4_tree;
                    if (dq4_tree.parse_dq4(dq4_hbd.data() + offset + tree_start, tree_size)) {
                        printf("  DQ4 parse: SUCCESS (valid=%d)\n", dq4_tree.valid());
                    } else {
                        printf("  DQ4 parse: FAILED\n");
                    }
                    
                    // Try DW7 convention on same tree
                    HuffTree dw7_tree;
                    if (dw7_tree.parse_dw7(dq4_hbd.data() + offset + tree_start, tree_size)) {
                        printf("  DW7 parse: SUCCESS (valid=%d)\n", dw7_tree.valid());
                    } else {
                        printf("  DW7 parse: FAILED\n");
                    }
                    
                    // Dump text data (first 32 bytes)
                    uint32_t text_off = offset + hts;
                    uint32_t text_sz = text_end - hts;
                    printf("  Text data (first 32 bytes, compressed):\n    ");
                    for (uint32_t i = 0; i < text_sz && i < 32; i++) {
                        printf("%02X ", dq4_hbd[text_off + i]);
                    }
                    printf("\n");
                    
                    // Decode text with DQ4 tree
                    auto leaves = dq4_tree.decode(dq4_hbd.data() + text_off, text_sz);
                    printf("  Decoded %zu leaves (first 20): ", leaves.size());
                    for (size_t i = 0; i < leaves.size() && i < 20; i++) {
                        printf("0x%04X ", leaves[i]);
                    }
                    printf("\n");
                }
            }
        } else {
            printf("  No per-block tree (tree_end=%u text_end=%u)\n", tree_end, text_end);
        }
        
        blocks_found++;
        offset += end;
        if (offset % 4) offset = (offset + 3) & ~3u;  // align to 4
    }
    
    if (blocks_found == 0) {
        printf("No valid DQ4 blocks found!\n");
        // Dump first 64 bytes of HBD
        printf("First 64 bytes of HBD:\n");
        for (size_t i = 0; i < 64 && i < dq4_hbd.size(); i += 4) {
            uint32_t v;
            memcpy(&v, dq4_hbd.data() + i, 4);
            printf("  [%4zu] 0x%08X (%u)\n", i, v, v);
        }
    }
    
    // Now compare with DW7 hybrid tree
    printf("\n=== DW7 Hybrid Tree Comparison ===\n\n");
    auto hybrid_tree = read_file(hybrid_tree_path);
    if (hybrid_tree.empty()) {
        printf("ERROR: Cannot read hybrid tree\n");
        return 1;
    }
    printf("DW7 hybrid tree: %zu bytes\n", hybrid_tree.size());
    
    // Dump first 64 bytes
    printf("Tree data (first 64 bytes):\n");
    for (size_t i = 0; i < hybrid_tree.size() && i < 64; i += 2) {
        uint16_t val = hybrid_tree[i] | (hybrid_tree[i + 1] << 8);
        const char* type = (val & 0x8000) ? "BRANCH" : "LEAF";
        printf("  [%4zu] 0x%04X (%s, id=%u)\n", i, val, type, val & 0x7FFF);
    }
    
    // Parse with DW7 convention
    HuffTree dw7_tree;
    if (dw7_tree.parse_dw7(hybrid_tree.data(), (uint32_t)hybrid_tree.size())) {
        printf("DW7 parse: SUCCESS (valid=%d)\n", dw7_tree.valid());
    } else {
        printf("DW7 parse: FAILED\n");
    }
    
    // Try DQ4 convention on hybrid tree
    HuffTree dq4_on_dw7;
    if (dq4_on_dw7.parse_dq4(hybrid_tree.data(), (uint32_t)hybrid_tree.size())) {
        printf("DQ4 convention on DW7 tree: SUCCESS (valid=%d)\n", dq4_on_dw7.valid());
    } else {
        printf("DQ4 convention on DW7 tree: FAILED\n");
    }
    
    // Root pointer comparison
    uint32_t dw7_last = (uint32_t)hybrid_tree.size() - 4;
    uint16_t dw7_root_val = hybrid_tree[dw7_last] | (hybrid_tree[dw7_last + 1] << 8);
    printf("\nDW7 root pointer: 0x%04X (branch=%d, id=%d)\n",
           dw7_root_val, (dw7_root_val & 0x8000) ? 1 : 0, dw7_root_val & 0x7FFF);
    printf("DW7 offset_b: %u (even=%d)\n", ((hybrid_tree.size() + 2) / 2 - 2) & ~1u,
           (((hybrid_tree.size() + 2) / 2 - 2) & ~1u) % 2 == 0);
    printf("DQ4 offset_b: %u (even=%d)\n", (hybrid_tree.size() + 2) / 2 - 2,
           ((hybrid_tree.size() + 2) / 2 - 2) % 2 == 0);
    
    printf("\n=== ISOMORPHISM VERDICT ===\n");
    printf("Node encoding: 2-byte LE, 0x8000 branch bit, 0x7FFF child mask — IDENTICAL\n");
    printf("Bit-packing: LSB-first, 8 bits per byte — IDENTICAL\n");
    printf("Leaf encoding: raw 15-bit value — IDENTICAL\n");
    printf("Root convention: DQ4=(val&0x7FFF)+1, DW7=(val&0x7FFF) — DELTA=+1\n");
    printf("Offset_b: DQ4=(len+2)/2-2, DW7=((len+2)/2-2)&~1 — minor alignment\n");
    
    return 0;
}
