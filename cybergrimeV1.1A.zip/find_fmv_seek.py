#!/usr/bin/env python3
"""
Scan DW7 EXE for FMV seek coordinates (BCD 32:34:71 / LBA 146621).
Also search for DQ4 equivalent (BCD 23:31:15 / LBA 105840).
"""
import struct
import sys

DW7_DISC = r"C:\LuxAura\VoidWalkers_Project\DQLOSTTRANSLATION\DW7D1\DW7D1.bin"
DQ4_DISC = r"C:\LuxAura\VoidWalkers_Project\DQLOSTTRANSLATION\Dragon Quest IV - Michibikareshi Mono Tachi (Japan).bin"

SECTOR_SIZE = 2352
USER_OFFSET = 24
USER_SIZE = 2048
EXE_LBA = 24  # DW7 EXE at sector 24

def read_exe_from_disc(disc_path, exe_lba, max_size=2*1024*1024):
    """Extract EXE from disc image."""
    with open(disc_path, 'rb') as f:
        f.seek(exe_lba * SECTOR_SIZE + USER_OFFSET)
        # Read PS-EXE header first (2048 bytes)
        header = f.read(USER_SIZE)
        if header[:8] != b'PS-X EXE':
            print(f"ERROR: Not a PS-X EXE at LBA {exe_lba}")
            return None
        # Get load size from header (offset 0x1C, little-endian 32-bit)
        text_size = struct.unpack_from('<I', header, 0x1C)[0]
        print(f"  PS-X EXE header found, text_size=0x{text_size:X} ({text_size} bytes)")
        
        # Read the full EXE
        total_size = min(text_size + 0x800, max_size)
        sectors_needed = (total_size + USER_SIZE - 1) // USER_SIZE
        
        f.seek(exe_lba * SECTOR_SIZE + USER_OFFSET)
        data = bytearray()
        for s in range(sectors_needed):
            sector = f.read(SECTOR_SIZE)
            if len(sector) < SECTOR_SIZE:
                break
            data.extend(sector[USER_OFFSET:USER_OFFSET+USER_SIZE])
        
        return bytes(data[:total_size])

def search_pattern(data, pattern, label, max_results=50):
    """Search for byte pattern in data, return list of offsets."""
    results = []
    start = 0
    while True:
        idx = data.find(pattern, start)
        if idx == -1:
            break
        results.append(idx)
        start = idx + 1
        if len(results) >= max_results:
            break
    return results

def lba_to_bcd_msf(lba):
    """Convert LBA to BCD MSF (MM:SS:FF in BCD)."""
    m = lba // (75 * 60)
    s = (lba // 75) % 60
    f = lba % 75
    return (to_bcd(m), to_bcd(s), to_bcd(f))

def to_bcd(val):
    """Convert integer to BCD."""
    return ((val // 10) << 4) | (val % 10)

def bcd_to_msf_str(b0, b1, b2):
    """Convert BCD bytes to MSF string."""
    m = ((b0 >> 4) & 0xF) * 10 + (b0 & 0xF)
    s = ((b1 >> 4) & 0xF) * 10 + (b1 & 0xF)
    f = ((b2 >> 4) & 0xF) * 10 + (b2 & 0xF)
    return f"{m:02d}:{s:02d}:{f:02d}"

def main():
    print("=" * 70)
    print("  DW7 EXE FMV Seek Pattern Scanner")
    print("=" * 70)
    
    # Extract DW7 EXE
    print("\nExtracting DW7 EXE...")
    exe = read_exe_from_disc(DW7_DISC, EXE_LBA)
    if not exe:
        print("FATAL: Cannot extract DW7 EXE")
        return
    
    print(f"  DW7 EXE: {len(exe)} bytes")
    
    # Target patterns
    # DW7 FMV seek: BCD 32:34:71 = bytes 0x32, 0x34, 0x71
    dw7_bcd = bytes([0x32, 0x34, 0x71])
    # DW7 FMV LBA: 146621 = 0x00023CBD, LE = BD 3C 02 00
    dw7_lba_le = struct.pack('<I', 146621)
    # Also try 3-byte LE: 146621 = 0x023CBD → BD 3C 02
    dw7_lba_le3 = bytes([0xBD, 0x3C, 0x02])
    
    # DQ4 FMV seek: BCD 23:31:15 = bytes 0x23, 0x31, 0x15
    dq4_bcd = bytes([0x23, 0x31, 0x15])
    # DQ4 FMV LBA: 105840 = 0x00019DE0, LE = E0 9D 01 00
    dq4_lba_le = struct.pack('<I', 105840)
    # 3-byte LE: 105840 = 0x019DE0 → E0 9D 01
    dq4_lba_le3 = bytes([0xE0, 0x9D, 0x01])
    
    # Also search for DQ4's second read: LBA 107436 = 0x0001A36C, LE = 6C A3 01 00
    dq4_lba2_le = struct.pack('<I', 107436)
    
    # Also search for DQ4's third read: LBA 765 = 0x000002FD, LE = FD 02 00 00
    dq4_lba3_le = struct.pack('<I', 765)
    
    print("\n" + "=" * 70)
    print("  PATTERN SEARCH RESULTS")
    print("=" * 70)
    
    # Search 1: DW7 BCD 32:34:71
    print(f"\n[1] DW7 BCD seek pattern: {dw7_bcd.hex()} (32:34:71 = LBA 146621)")
    hits = search_pattern(exe, dw7_bcd, "DW7 BCD")
    print(f"    Found {len(hits)} matches:")
    for off in hits:
        ram_addr = 0x80010000 + off  # PS-X EXE loads at 0x80010000 typically
        # Show context: 16 bytes before and after
        ctx_start = max(0, off - 8)
        ctx_end = min(len(exe), off + 16)
        ctx = exe[ctx_start:ctx_end]
        hex_ctx = ' '.join(f'{b:02x}' for b in ctx)
        marker_pos = (off - ctx_start) * 3
        print(f"    File offset 0x{off:06X} (RAM ~0x{ram_addr:08X}): ...{hex_ctx}...")
        # Check if preceded by Setloc-like instruction pattern
        # MIPS Setloc typically: lui/addiu to load BCD into registers
        if off >= 4:
            prev4 = struct.unpack_from('<I', exe, off - 4)[0]
            print(f"      Prev word: 0x{prev4:08X}")
    
    # Search 2: DW7 LBA as 32-bit LE
    print(f"\n[2] DW7 LBA as 32-bit LE: {dw7_lba_le.hex()} (146621)")
    hits2 = search_pattern(exe, dw7_lba_le, "DW7 LBA32")
    print(f"    Found {len(hits2)} matches:")
    for off in hits2:
        ram_addr = 0x80010000 + off
        ctx_start = max(0, off - 8)
        ctx_end = min(len(exe), off + 16)
        ctx = exe[ctx_start:ctx_end]
        hex_ctx = ' '.join(f'{b:02x}' for b in ctx)
        print(f"    File offset 0x{off:06X} (RAM ~0x{ram_addr:08X}): ...{hex_ctx}...")
    
    # Search 3: DW7 LBA as 3-byte LE
    print(f"\n[3] DW7 LBA as 3-byte LE: {dw7_lba_le3.hex()} (146621 low 3 bytes)")
    hits3 = search_pattern(exe, dw7_lba_le3, "DW7 LBA24")
    print(f"    Found {len(hits3)} matches:")
    for off in hits3:
        ram_addr = 0x80010000 + off
        ctx_start = max(0, off - 8)
        ctx_end = min(len(exe), off + 16)
        ctx = exe[ctx_start:ctx_end]
        hex_ctx = ' '.join(f'{b:02x}' for b in ctx)
        # Check the 4th byte
        if off + 3 < len(exe):
            full32 = struct.unpack_from('<I', exe, off)[0]
            print(f"    File offset 0x{off:06X} (RAM ~0x{ram_addr:08X}): LE32=0x{full32:08X} ({full32}) ...{hex_ctx}...")
        else:
            print(f"    File offset 0x{off:06X} (RAM ~0x{ram_addr:08X}): ...{hex_ctx}...")
    
    # Search 4: DQ4 BCD 23:31:15 (to check if already present)
    print(f"\n[4] DQ4 BCD seek pattern: {dq4_bcd.hex()} (23:31:15 = LBA 105840)")
    hits4 = search_pattern(exe, dq4_bcd, "DQ4 BCD")
    print(f"    Found {len(hits4)} matches:")
    for off in hits4:
        ram_addr = 0x80010000 + off
        ctx_start = max(0, off - 8)
        ctx_end = min(len(exe), off + 16)
        ctx = exe[ctx_start:ctx_end]
        hex_ctx = ' '.join(f'{b:02x}' for b in ctx)
        print(f"    File offset 0x{off:06X} (RAM ~0x{ram_addr:08X}): ...{hex_ctx}...")
    
    # Search 5: DQ4 LBA 105840 as 32-bit LE
    print(f"\n[5] DQ4 LBA 105840 as 32-bit LE: {dq4_lba_le.hex()}")
    hits5 = search_pattern(exe, dq4_lba_le, "DQ4 LBA32")
    print(f"    Found {len(hits5)} matches")
    for off in hits5[:10]:
        ram_addr = 0x80010000 + off
        print(f"    File offset 0x{off:06X} (RAM ~0x{ram_addr:08X})")
    
    # Search 6: Also check for Setloc instruction patterns
    # MIPS: addiu $reg, $zero, BCD_value is common for Setloc
    # addiu $a0, $zero, 0x0032 = 0x24040032
    # addiu $a1, $zero, 0x0034 = 0x24050034
    # addiu $a2, $zero, 0x0071 = 0x24060071
    print(f"\n[6] MIPS addiu patterns for BCD 32/34/71:")
    for reg_name, reg_num, bcd_val in [("$a0", 4, 0x32), ("$a1", 5, 0x34), ("$a2", 6, 0x71)]:
        # addiu $reg, $zero, imm16 = 0x24000000 | (reg << 16) | imm
        instr = 0x24000000 | (reg_num << 16) | bcd_val
        pat = struct.pack('<I', instr)
        hits = search_pattern(exe, pat, f"addiu {reg_name}")
        print(f"    addiu {reg_name}, $zero, 0x{bcd_val:02X} (0x{instr:08X}): {len(hits)} matches")
        for off in hits[:5]:
            ram_addr = 0x80010000 + off
            ctx_start = max(0, off - 4)
            ctx_end = min(len(exe), off + 20)
            ctx = exe[ctx_start:ctx_end]
            hex_ctx = ' '.join(f'{b:02x}' for b in ctx)
            print(f"      File offset 0x{off:06X} (RAM ~0x{ram_addr:08X}): {hex_ctx}")
    
    # Search 7: Broader search - any addiu loading 0x32, 0x34, or 0x71 as immediate
    print(f"\n[7] Any MIPS instruction with immediate 0x0032 (BCD 32):")
    pat_32 = bytes([0x32, 0x00])  # low 16 bits = 0x0032, LE = 32 00
    hits_32 = search_pattern(exe, pat_32, "imm32")
    # Filter to only those that look like addiu/lui instructions
    filtered = []
    for off in hits_32:
        if off >= 2:
            word = struct.unpack_from('<I', exe, off - 2)[0]
            opcode = (word >> 26) & 0x3F
            if opcode in [0x09, 0x0F, 0x0D]:  # addiu, lui, ori
                filtered.append((off - 2, word))
    print(f"    {len(filtered)} matches that look like addiu/lui/ori with imm=0x0032")
    for off, word in filtered[:10]:
        ram_addr = 0x80010000 + off
        print(f"      File offset 0x{off:06X} (RAM ~0x{ram_addr:08X}): 0x{word:08X}")
    
    # Search 8: Check known offset from memory (0x92936 was a BCD redirect site)
    print(f"\n[8] Checking known offset 0x92936 (previous BCD redirect site):")
    if 0x92936 + 16 <= len(exe):
        ctx = exe[0x92936-8:0x92936+16]
        hex_ctx = ' '.join(f'{b:02x}' for b in ctx)
        print(f"    {hex_ctx}")
        # Disassemble nearby words
        for i in range(0, min(32, len(ctx)-8), 4):
            word = struct.unpack_from('<I', ctx, i)[0]
            off = 0x92936 - 8 + i
            print(f"    0x{off:06X}: 0x{word:08X}")
    else:
        print(f"    Offset 0x92936 beyond EXE size ({len(exe)})")
    
    # Search 9: Check known XA/STR handler offset 0x737F4
    print(f"\n[9] Checking XA/STR handler at file offset 0x737F4:")
    if 0x737F4 + 32 <= len(exe):
        ctx = exe[0x737F4-16:0x737F4+32]
        for i in range(0, len(ctx)-4, 4):
            word = struct.unpack_from('<I', ctx, i)[0]
            off = 0x737F4 - 16 + i
            print(f"    0x{off:06X}: 0x{word:08X}")
    else:
        print(f"    Offset 0x737F4 beyond EXE size ({len(exe)})")
    
    # Search 10: Check MDEC handler offset 0x753D0
    print(f"\n[10] Checking MDEC handler at file offset 0x753D0:")
    if 0x753D0 + 32 <= len(exe):
        ctx = exe[0x753D0-16:0x753D0+32]
        for i in range(0, len(ctx)-4, 4):
            word = struct.unpack_from('<I', ctx, i)[0]
            off = 0x753D0 - 16 + i
            print(f"    0x{off:06X}: 0x{word:08X}")
    else:
        print(f"    Offset 0x753D0 beyond EXE size ({len(exe)})")
    
    # Search 11: Check dispatch table at 0x80F08
    print(f"\n[11] Checking dispatch table at file offset 0x80F08:")
    if 0x80F08 + 64 <= len(exe):
        ctx = exe[0x80F08:0x80F08+64]
        for i in range(0, len(ctx)-4, 4):
            word = struct.unpack_from('<I', ctx, i)[0]
            off = 0x80F08 + i
            print(f"    0x{off:06X}: 0x{word:08X}")
    else:
        print(f"    Offset 0x80F08 beyond EXE size ({len(exe)})")
    
    # Summary
    print("\n" + "=" * 70)
    print("  SUMMARY")
    print("=" * 70)
    print(f"  DW7 BCD 32:34:71 hits: {len(hits)}")
    print(f"  DW7 LBA 146621 (LE32) hits: {len(hits2)}")
    print(f"  DW7 LBA 146621 (LE24) hits: {len(hits3)}")
    print(f"  DQ4 BCD 23:31:15 hits: {len(hits4)}")
    
    if hits:
        print(f"\n  >>> PRIMARY PATCH TARGETS (BCD 32:34:71):")
        for off in hits:
            ram = 0x80010000 + off
            print(f"    File 0x{off:06X} → RAM 0x{ram:08X}")
            print(f"    Patch: 0x32 0x34 0x71 → 0x23 0x31 0x15")

if __name__ == '__main__':
    main()
