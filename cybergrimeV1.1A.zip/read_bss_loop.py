#!/usr/bin/env python3
"""Read BSS clear loop from DW7 EXE to understand the instruction layout."""
import struct

exe_path = r"C:\LuxAura\VoidWalkers_Project\DQLOSTTRANSLATION\translation\SLUSP012.06"
with open(exe_path, "rb") as f:
    data = f.read()

# BSS clear loop starts at file offset 0x76B84 (header included)
base = 0x76B84
load_addr = 0x80017F00

print(f"EXE size: {len(data)} bytes (0x{len(data):X})")
print(f"\nBSS clear loop region (file offset 0x{base:X}, RAM 0x{base - 0x800 + load_addr:08X}):")
print()

for i in range(16):
    off = base + i * 4
    if off + 4 > len(data):
        break
    val = struct.unpack_from("<I", data, off)[0]
    ram = off - 0x800 + load_addr
    
    # Basic MIPS disassembly
    opcode = (val >> 26) & 0x3F
    rs = (val >> 21) & 0x1F
    rt = (val >> 16) & 0x1F
    imm = val & 0xFFFF
    simm = imm if imm < 0x8000 else imm - 0x10000
    target = (val & 0x3FFFFFF) << 2
    
    reg_names = ["zero","at","v0","v1","a0","a1","a2","a3",
                 "t0","t1","t2","t3","t4","t5","t6","t7",
                 "s0","s1","s2","s3","s4","s5","s6","s7",
                 "t8","t9","k0","k1","gp","sp","fp","ra"]
    
    desc = ""
    if val == 0:
        desc = "nop"
    elif opcode == 0x0F:  # lui
        desc = f"lui ${reg_names[rt]}, 0x{imm:04X}"
    elif opcode == 0x09:  # addiu
        desc = f"addiu ${reg_names[rt]}, ${reg_names[rs]}, {simm} (0x{imm:04X})"
    elif opcode == 0x23:  # lw
        desc = f"lw ${reg_names[rt]}, {simm}(${reg_names[rs]})"
    elif opcode == 0x2B:  # sw
        desc = f"sw ${reg_names[rt]}, {simm}(${reg_names[rs]})"
    elif opcode == 0x05:  # bne
        target_ram = ram + 4 + simm * 4
        desc = f"bne ${reg_names[rs]}, ${reg_names[rt]}, 0x{target_ram:08X} (offset={simm})"
    elif opcode == 0x04:  # beq
        target_ram = ram + 4 + simm * 4
        desc = f"beq ${reg_names[rs]}, ${reg_names[rt]}, 0x{target_ram:08X} (offset={simm})"
    elif opcode == 0x02:  # j
        desc = f"j 0x{target:08X}"
    elif opcode == 0x03:  # jal
        desc = f"jal 0x{target:08X}"
    elif opcode == 0x00:  # R-type
        funct = val & 0x3F
        if funct == 0x08:
            desc = f"jr ${reg_names[rs]}"
        elif funct == 0x21:
            desc = f"addu ${reg_names[rd]}, ${reg_names[rs]}, ${reg_names[rt]}" if 'rd' in dir() else f"addu (rd={rt})"
        else:
            desc = f"R-type funct=0x{funct:02X}"
    else:
        desc = f"op=0x{opcode:02X} raw=0x{val:08X}"
    
    print(f"  0x{off:05X} (RAM 0x{ram:08X}): 0x{val:08X}  {desc}")

# Also read the thread blob
blob_path = r"C:\LuxAura\VoidWalkers_Project\DQLOSTTRANSLATION\cybergrime\thread_code_blob.bin"
with open(blob_path, "rb") as f:
    blob = f.read()
print(f"\nThread blob: {len(blob)} bytes (0x{len(blob):X})")
print(f"First 16 words:")
for i in range(min(16, len(blob)//4)):
    val = struct.unpack_from("<I", blob, i*4)[0]
    print(f"  [{i:2d}] 0x{val:08X}")

# Calculate file offset for thread entry
thread_ram = 0x800D9E80
thread_file_off = thread_ram - load_addr + 0x800
print(f"\nThread entry RAM: 0x{thread_ram:08X}")
print(f"Thread entry file offset: 0x{thread_file_off:X}")
print(f"Current EXE size: 0x{len(data):X}")
print(f"Need to extend by: 0x{thread_file_off + len(blob) - len(data):X} bytes")

# BSS end file offset
bss_end_ram = 0x800F4980
bss_end_file_off = bss_end_ram - load_addr + 0x800
print(f"\nBSS end RAM: 0x{bss_end_ram:08X}")
print(f"BSS end file offset: 0x{bss_end_file_off:X}")
print(f"Would need EXE size: 0x{bss_end_file_off:X} ({bss_end_file_off} bytes)")
print(f"Available space (LBA 24 to 356): {(356-24)*2048} bytes = 0x{(356-24)*2048:X}")
