# CyberGrime Testing Environment & Agent Harness — Comprehensive Upgrade Blueprint

**Author:** Cascade AI Agent  
**Date:** July 11, 2026  
**Project:** DQ4 PSX Frankenstein ROM Translation  
**Status:** Planning / Ready for Implementation  

---

## Table of Contents

1. [Current State Assessment](#1-current-state-assessment)
2. [Architecture Overview](#2-architecture-overview)
3. [Upgrade Pillars](#3-upgrade-pillars)
4. [Phase A: Emulator Core Hardening](#phase-a-emulator-core-hardening)
5. [Phase B: CD-ROM Pipeline Completion](#phase-b-cd-rom-pipeline-completion)
6. [Phase C: HLE BIOS Expansion](#phase-c-hle-bios-expansion)
7. [Phase D: Agent Harness Upgrade](#phase-d-agent-harness-upgrade)
8. [Phase E: ROM Hacking & Patch Tooling](#phase-e-rom-hacking--patch-tooling)
9. [Phase F: Visual Verification Pipeline](#phase-f-visual-verification-pipeline)
10. [Phase G: Cross-Emulator Validation](#phase-g-cross-emulator-validation)
11. [Phase H: Automated QA & Regression Suite](#phase-h-automated-qa--regression-suite)
12. [Phase I: AI Agent Integration](#phase-i-ai-agent-integration)
13. [Implementation Priority & Dependencies](#implementation-priority--dependencies)
14. [File Manifest](#file-manifest)

---

## 1. Current State Assessment

### 1.1 What Exists

| Component | File(s) | Lines | Status |
|-----------|---------|-------|--------|
| MIPS R3000A CPU Core | `psx_emulator_core.cpp` | ~4,173 | Functional — all base instructions, CP0, branch delay slots, trace ring |
| PSX Memory System | `psx_test_station.h` | ~823 | Functional — 2MB RAM, VRAM, scratchpad, hardware regs, ISO9660 parsing |
| HLE BIOS | `psx_emulator_core.cpp` | ~2,400 lines within | Partial — A0/B0/C0 tables stubbed, event system, HookEntryInt, ReturnFromException |
| CD-ROM Emulation | `psx_test_station.h` + core | ~300 lines | **Incomplete** — Setloc/ReadN stubbed, no data-ready IRQ chain, no DMA CD-ROM→RAM |
| GPU Emulation | `psx_test_station.h` + core | ~500 lines | Partial — VRAM, GP0/GP1 commands, framebuffer blit, no display output |
| Timer/Root Counter | `psx_test_station.h` + core | ~150 lines | Basic — tick per instruction, target/overflow IRQs |
| DMA Controller | `psx_test_station.h` + core | ~100 lines | Stubbed — madr/bcr/chcr tracked, no actual transfer |
| Controller Input (PAD) | `psx_test_station.h` + core | ~200 lines | Functional — digital pad, analog sticks, scriptable input queue |
| Agent Harness | `agent_harness.h/.cpp` | ~2,013 | Functional — TTY capture, VFS logging, freeze detection, RAM injection, buffer monitors, JSON telemetry, triage logs |
| Headless Runner | `psx_headless.cpp` | 158 | Functional — CLI, TXRT mode control, periodic status |
| Agent Runner | `psx_agent_runner.cpp` | ~603 | Functional — VFS hooks, harness integration, batch mode |
| Python Orchestrator | `harness_runner.py` | 580 | Functional — single/batch/compare modes, triage parser, telemetry parser, patch verifier |
| Iteration Harness | `iteration_harness.py` | 390 | Functional — automated patch→boot→analyze→refine loop |
| Autoplayer | `psx_autoplayer.cpp` | ~538 | Functional — JSON script loader, scripted button input |
| TXRT HLE Bypass | `txrt_hle.h` | 459 | Functional — surgical bypass, diagnostic mode, post-decomp swap |
| CyberGrime UI | `CybergrimeUI.h/.cpp` | ~700 | Functional — CRT/glitch visual debug overlay, GDI+ rendering |
| VFS Compare Tool | `vfs_compare.cpp` | ~800 | Functional — binary-level ISO comparison |
| Batch Profiles | `batch_profiles.json` | 46 | 5 profiles defined |
| Telemetry Data | `telemetry/*.json` | 14 files | Baseline + diagnostic runs captured |

### 1.2 Critical Gaps

1. **CD-ROM Data Pipeline** — Game stuck in CD-ROM wait loops. `ReadN`/`ReadS` commands don't complete the data-ready interrupt chain. No DMA channel 3 (CD-ROM→RAM) transfer. This is the #1 blocker preventing the game from reaching decompression.

2. **HLE BIOS Coverage** — Many A0/B0/C0 functions are stubbed or missing. Key gaps: `open()`, `lseek()`, `read()` file I/O via BIOS, `EnqueueTimerAndVblank`, `StCdInterrupt`, `CDROM_Init`.

3. **No Visual Output Verification** — GPU framebuffer is rendered but never compared against expected output. No screenshot capture, no text-in-image detection, no OCR pipeline.

4. **No Save State System** — Cannot snapshot emulator state to resume from a known point. Every test run starts from boot, wasting 50M+ instructions on boot sequence.

5. **No Cross-Emulator Validation** — No automated bridge to DuckStation/SwanStation for comparing execution traces or visual output.

6. **No Automated Text Verification** — Cannot verify that English text is actually rendering in the framebuffer. No mechanism to read VRAM text tiles and compare against translation database.

7. **No Regression Test Suite** — No formal test definitions with pass/fail criteria. Tests are ad-hoc runs with manual interpretation.

8. **No Memory Card Emulation** — Save/load functionality untestable.

9. **No SPU/Audio** — Audio subsystem completely absent. Not critical for text testing but needed for full QA.

10. **No MIPS Disassembler in Harness** — Triage logs show raw hex + mnemonic but no full disassembly view for reverse engineering.

---

## 2. Architecture Overview

```
┌─────────────────────────────────────────────────────────────────┐
│                    AGENT ORCHESTRATION LAYER                      │
│  ┌──────────┐  ┌───────────┐  ┌──────────┐  ┌───────────────┐  │
│  │ iteration │  │  harness  │  │  agent   │  │  cross-emu    │  │
│  │ harness   │  │  runner   │  │ telemetry│  │  bridge       │  │
│  │  .py      │  │  .py      │  │  .py     │  │  .py          │  │
│  └─────┬─────┘  └─────┬─────┘  └────┬─────┘  └──────┬────────┘  │
│        │              │              │               │           │
│        └──────────────┴──────────────┴───────────────┘           │
│                              │                                    │
│                    ┌─────────▼──────────┐                        │
│                    │  REGRESSION TEST    │                        │
│                    │  DEFINITIONS (JSON) │                        │
│                    └─────────┬──────────┘                        │
├──────────────────────────────┼────────────────────────────────────┤
│                    EMULATION LAYER                                │
│                    ┌─────────▼──────────┐                        │
│                    │  psx_agent_runner   │                        │
│                    │  .exe (harness-int) │                        │
│                    └─────────┬──────────┘                        │
│           ┌──────────────────┼──────────────────┐                │
│  ┌────────▼───────┐  ┌──────▼───────┐  ┌───────▼──────────┐     │
│  │  MIPS R3000A    │  │  PSX Memory  │  │  Agent Harness   │     │
│  │  CPU Core       │  │  & Hardware  │  │  (freeze/inject/  │     │
│  │  (step, CP0,    │  │  (RAM, VRAM, │  │   monitor/JSON)   │     │
│  │   IRQ, trace)   │  │   CD, GPU,   │  │                   │     │
│  │                 │  │   DMA, PAD)  │  │                   │     │
│  └────────┬───────┘  └──────┬───────┘  └───────┬──────────┘     │
│           │                 │                  │                  │
│  ┌────────▼───────┐  ┌─────▼──────┐  ┌───────▼──────────┐      │
│  │  HLE BIOS      │  │  CD-ROM    │  │  TXRT HLE Bypass  │      │
│  │  (A0/B0/C0)    │  │  Pipeline  │  │  (decomp bypass)  │      │
│  └────────────────┘  └────────────┘  └───────────────────┘      │
│                                                                    │
│  ┌──────────────────────────────────────────────────────────┐    │
│  │  OPTIONAL: CyberGrime Visual Debug UI (GDI+ window)      │    │
│  │  psx_test_station.exe                                     │    │
│  └──────────────────────────────────────────────────────────┘    │
├────────────────────────────────────────────────────────────────────┤
│                    TOOLING LAYER                                   │
│  ┌──────────┐  ┌──────────┐  ┌──────────┐  ┌──────────────┐     │
│  │ EDC/ECC  │  │ XDelta3  │  │ VFS      │  │ ROM Differ   │     │
│  │ edcre    │  │ patch    │  │ Compare  │  │ (binary diff)│     │
│  └──────────┘  └──────────┘  └──────────┘  └──────────────┘     │
└────────────────────────────────────────────────────────────────────┘
```

---

## 3. Upgrade Pillars

The upgrade is organized into **9 phases (A–I)**, each addressing a critical gap:

| Phase | Name | Priority | Effort | Unlocks |
|-------|------|----------|--------|---------|
| A | Emulator Core Hardening | P0 | Medium | Save states, MIPS disassembler, memory card |
| B | CD-ROM Pipeline Completion | P0 | High | Game progression past boot, TXRT bypass testing |
| C | HLE BIOS Expansion | P0 | Medium | File I/O, CD-ROM BIOS calls, event delivery |
| D | Agent Harness Upgrade | P1 | Medium | Structured test definitions, screenshot capture, text verification |
| E | ROM Hacking & Patch Tooling | P1 | Low | Automated patch generation, binary diffing, EDC/ECC pipeline |
| F | Visual Verification Pipeline | P1 | Medium | Screenshot comparison, VRAM text extraction, OCR |
| G | Cross-Emulator Validation | P2 | Medium | DuckStation bridge, trace comparison, output validation |
| H | Automated QA & Regression Suite | P2 | Medium | Formal test definitions, CI integration, pass/fail criteria |
| I | AI Agent Integration | P3 | Low | Self-healing patches, automated iteration, Nexus integration |

---

## Phase A: Emulator Core Hardening

### A.1 Save State System

**Goal:** Snapshot and restore full emulator state to skip boot sequence during testing.

**New file:** `psx_savestate.h`

```cpp
struct PSXSavestate {
    uint32_t magic;           // 0x53545150 ("PQTS")
    uint32_t version;
    uint64_t instruction_count;
    uint32_t vblank_counter;
    
    // CPU state
    uint32_t regs[32];
    uint32_t pc, next_pc, hi, lo;
    uint32_t cp0_status, cp0_cause, cp0_epc;
    bool in_branch_delay, pending_branch;
    uint32_t branch_target;
    
    // Memory state (2MB RAM + scratchpad)
    uint8_t ram[0x200000];
    uint8_t scratch[0x1000];
    
    // Hardware state
    uint32_t intc_mask, intc_stat;
    uint32_t hw_regs_snapshot[0x20000];
    uint16_t vram_snapshot[1024*512];
    
    // CD-ROM state
    uint32_t cdrom_cur_lba;
    bool cdrom_reading;
    uint8_t cdrom_index, cdrom_int_enable;
    
    // Timers
    uint32_t timer_count[4], timer_mode[4], timer_target[4];
    
    // Event table
    EvEntry events[EV_TABLE_SIZE];
    
    // PAD state
    uint16_t pad1_buttons, pad2_buttons;
    bool pad_started;
};
```

**API:**
- `bool save_state(PSX_Memory& mem, MIPS_CPU& cpu, const char* path);`
- `bool load_state(PSX_Memory& mem, MIPS_CPU& cpu, const char* path);`
- `bool save_state_compact(...)` — excludes VRAM for faster snapshots

**CLI integration:**
- `psx_agent_runner.exe --savestate out.bin --disc iso.bin --max-instrs 50000000`
- `psx_agent_runner.exe --loadstate state.bin --disc iso.bin --max-instrs 10000000`

**Implementation notes:**
- Save state after VBlank #100 (game past boot, in main loop) as `boot_state.bin`
- All subsequent tests load `boot_state.bin` and start from known-good state
- Saves ~50M instructions per test run (~30 seconds wall clock)

### A.2 Integrated MIPS Disassembler

**Goal:** Full disassembly view in triage logs and harness output for reverse engineering.

**New file:** `mips_disasm.h`

**API:**
```cpp
// Disassemble a single instruction at the given address
const char* mips_disasm(uint32_t pc, uint32_t raw, 
                        PSX_Memory* mem = nullptr);

// Disassemble a range of memory
void mips_disasm_range(PSX_Memory& mem, uint32_t start_pc, int count,
                       FILE* out, bool show_regs = false);

// Disassemble the trace ring (last N executed instructions)
void mips_disasm_trace(MIPS_CPU& cpu, PSX_Memory& mem, int count, FILE* out);
```

**Features:**
- All MIPS R3000A instructions (R-type, I-type, J-type)
- Register name resolution ($a0, $ra, etc.)
- Branch target calculation with labels
- Memory operand resolution (show value at referenced address)
- BIOS call annotation (e.g., `jal 0xA0` → `BIOS_A0:open()`)
- COP0 instruction decoding (MTC0, MFC0, RFE)
- Pseudo-instruction expansion (NOP, MOVE)

**Integration points:**
- `AgentHarness::write_triage_log()` — include disassembled loop body
- `MIPS_CPU::dump_trace_ring()` — include disassembly
- New CLI: `psx_agent_runner.exe --disasm 0x80073670 --count 50`

### A.3 Memory Card Emulation

**New file:** `psx_memcard.h`

**Features:**
- 128KB memory card image (standard PSX format)
- 16 blocks, block allocation table
- BIOS calls: `B0:43` (`init_card`), `B0:4A` (`card_read`), `B0:4B` (`card_write`)
- File-based persistence: `slot1.mcd`, `slot2.mcd`
- Detect save corruption / format errors

**Implementation:**
```cpp
class PSX_MemoryCard {
    uint8_t data[128 * 1024];  // 128KB
    bool inserted;
    bool formatted;
    int read_sector(int sector, uint8_t* out);
    int write_sector(int sector, const uint8_t* in);
    bool format();
    bool detect_corruption();
};
```

### A.4 Enhanced Trace Ring with Disassembly

**Upgrade `MIPS_CPU::TraceFrame`:**
```cpp
struct TraceFrame {
    // ... existing fields ...
    char disasm[128];           // NEW: disassembled instruction text
    uint32_t mem_reads[4];      // NEW: values read from memory this instruction
    uint32_t mem_read_addrs[4]; // NEW: addresses read
    int mem_read_count;         // NEW: number of memory reads
    uint32_t mem_write_addr;    // NEW: address written (if any)
    uint32_t mem_write_val;     // NEW: value written (if any)
    bool is_branch_taken;       // NEW: was branch taken?
};
```

Increase `TRACE_RING_SIZE` from 256 to 512 for longer trace history.

---

## Phase B: CD-ROM Pipeline Completion

**This is the #1 critical blocker.** The game never reaches decompression because CD-ROM reads never complete.

### B.1 CD-ROM Command State Machine

**Current state:** `Setloc` stores LBA, `ReadN`/`ReadS` sets `cdrom_reading = true`, but no data-ready interrupt chain fires.

**Required implementation in `psx_emulator_core.cpp`:**

```
CD-ROM Command Flow (Real Hardware):
1. Game writes Setloc (min/sec/sector) to 0x1F801802 (param FIFO)
2. Game writes ReadN command (0x06) or ReadS (0x1B) to 0x1F801801
3. CD-ROM controller seeks to LBA, reads sector
4. CD-ROM fires INT1 (data ready) → IRQ 2 in I_STAT
5. Game reads data from 0x1F801803 (data FIFO) or via DMA channel 3
6. After all sectors read, CD-ROM fires INT1 (last sector) or INT2 (end)
7. Game issues Pause (0x09) or Stop (0x08)
```

**New CD-ROM state machine:**

```cpp
enum CDROM_State {
    CD_IDLE,
    CD_SEEKING,       // Seeking to LBA (delay ~50000 instrs)
    CD_READING,       // Reading sectors, delivering INT1 per sector
    CD_PAUSING,       // Pause command, spinning down
    CD_STOPPED,       // Stopped
    CD_DATA_READY,    // Sector data in FIFO, waiting for game to read
    CD_DATA_PENDING,  // Sector read complete, INT1 about to fire
};

struct CDROM_Controller {
    CDROM_State state;
    uint32_t target_lba;
    uint32_t current_lba;
    int sectors_remaining;     // How many sectors left to read
    int seek_delay;            // Instructions remaining for seek
    int sector_delay;          // Instructions between sectors
    uint8_t data_fifo[2048];   // Current sector data
    int data_fifo_pos;
    bool data_fifo_full;
    uint8_t int_code;          // Pending interrupt code
    int int_delay;             // Delay before firing interrupt
    
    // Register interface
    uint8_t index;             // Index register (0-3)
    uint8_t param_fifo[16];    // Parameter FIFO
    int param_pos;
    uint8_t response_fifo[16]; // Response FIFO
    int response_pos;
    uint8_t int_enable;        // Interrupt enable mask
};
```

**Key implementation details:**
- Seek delay: ~50,000 instructions (simulates physical seek time)
- Sector-to-sector delay: ~33,500 instructions (simulates rotation)
- INT1 fires after each sector is ready
- Response FIFO populated with status byte (0x11 = playing, bit 7 = error)
- Data FIFO accessible via 0x1F801803 reads in index 0
- DMA channel 3 can transfer data FIFO → RAM automatically

### B.2 DMA Channel 3 (CD-ROM → RAM)

**Current state:** DMA registers tracked but no transfers executed.

**Required implementation:**

```cpp
void PSX_Memory::dma_transfer_cdrom() {
    // Channel 3: CD-ROM data → RAM
    uint32_t madr = dma_madr[3];   // RAM destination
    uint32_t bcr = dma_bcr[3];     // Block count + size
    uint32_t chcr = dma_chcr[3];   // Control (direction, enable)
    
    if (!(chcr & 0x01000000)) return;  // Not enabled
    
    int num_blocks = bcr >> 16;
    int block_size = bcr & 0xFFFF;
    if (block_size == 0) block_size = 0x10000;
    
    for (int b = 0; b < num_blocks; b++) {
        for (int w = 0; w < block_size; w++) {
            // Read from CD-ROM data FIFO
            uint32_t data = read_cdrom_data_fifo();
            write32(madr, data);
            madr += 4;
        }
    }
    
    // Set DMA complete interrupt
    intc_stat |= 0x08;  // DMA IRQ bit 3
    dma_chcr[3] &= ~0x01000000;  // Clear enable
    dma_done[3] = true;
}
```

### B.3 CD-ROM BIOS Call Integration

**Key BIOS functions to implement in `handle_bios_call()`:**

| Table | Function | Name | Implementation |
|-------|----------|------|----------------|
| A0 | 0x7A | `CdInit()` | Initialize CD-ROM controller, set `cd_initialized = true` |
| A0 | 0xB0 | `CdRead()` | Start reading `count` sectors from LBA into buffer. Returns 1 if started. |
| A0 | 0xB1 | `CdReadSync()` | Returns number of sectors remaining (0 = done). |
| A0 | 0xB2 | `CdGetToc()` | Return table of contents (stub: return fixed TOC) |
| A0 | 0xB3 | `CdGetStatus()` | Return CD-ROM status byte (0x11 = reading, 0x00 = stopped) |
| A0 | 0xB6 | `CdReadFile()` | High-level: open file, read sectors, close. Uses ISO9660 directory. |
| B0 | 0x5C | `CdGetStatus()` | Same as A0:0xB3 (duplicate) |
| B0 | 0x67 | `cd_read()` | BIOS-level file read (uses file descriptors) |

**`CdReadFile` is critical** — this is how the game loads HBD data from disc.

```cpp
// A0:0xB6 — CdReadFile(filename, addr, count, callback)
// Reads 'count' sectors from file 'filename' into RAM at 'addr'
bool bios_CdReadFile(MIPS_CPU& cpu) {
    const char* filename = read_bios_string(cpu.get_reg(4));
    uint32_t ram_addr = cpu.get_reg(5);
    uint32_t sector_count = cpu.get_reg(6);
    uint32_t callback = cpu.get_reg(7);
    
    // Find file in ISO9660
    uint32_t lba, size;
    if (find_cd_file(filename, lba, size) < 0) {
        cpu.set_reg(2, 0);  // Return 0 = failure
        return true;
    }
    
    // Read sectors directly into RAM
    for (uint32_t i = 0; i < sector_count; i++) {
        uint8_t sector[2048];
        read_cd_sector(lba + i, sector);
        uint32_t dst = ram_addr + i * 2048;
        for (int j = 0; j < 2048; j++) {
            write8(dst + j, sector[j]);
        }
    }
    
    // Deliver CD-ready event
    deliver_event(0xF2000000, 0x0003);  // CdEvent class, CdReady spec
    
    cpu.set_reg(2, sector_count);  // Return sectors read
    return true;
}
```

### B.4 CD-ROM Interrupt Delivery Chain

```cpp
void PSX_Memory::cdrom_tick() {
    if (cdrom.state == CD_SEEKING) {
        if (--cdrom.seek_delay <= 0) {
            cdrom.state = CD_READING;
            cdrom.sector_delay = 33500;  // ~1 sector rotation
        }
    }
    
    if (cdrom.state == CD_READING) {
        if (--cdrom.sector_delay <= 0) {
            // Read sector into data FIFO
            read_cd_sector(cdrom.current_lba, cdrom.data_fifo);
            cdrom.data_fifo_full = true;
            cdrom.data_fifo_pos = 0;
            
            // Fire INT1 (data ready)
            cdrom.int_code = 1;
            cdrom.int_delay = 1000;  // Small delay before IRQ
            cdrom.state = CD_DATA_READY;
            
            // If DMA channel 3 is enabled, auto-transfer
            if (dma_chcr[3] & 0x01000000) {
                dma_transfer_cdrom();
            }
            
            cdrom.current_lba++;
            if (--cdrom.sectors_remaining <= 0) {
                // Last sector — will fire INT2 after this
                cdrom.state = CD_DATA_PENDING;
            }
        }
    }
    
    // Fire CD-ROM interrupt after delay
    if (cdrom.int_delay > 0 && --cdrom.int_delay == 0) {
        intc_stat |= 0x04;  // CD-ROM IRQ (bit 2)
        if (g_cpu) g_cpu->interrupt_pending = true;
        
        // Deliver CD-ROM event to game's event handler
        deliver_event(0xF2000000, 0x0003);  // CdReady
    }
}
```

---

## Phase C: HLE BIOS Expansion

### C.1 File I/O Implementation

**Current state:** `open()`, `read()`, `lseek()`, `close()` partially stubbed.

**Required full implementation:**

```cpp
// A0:0x00 — open(filename, access_mode)
// Returns file descriptor (>= 0) or -1
bool bios_open(MIPS_CPU& cpu) {
    const char* path = read_bios_string(cpu.get_reg(4));
    uint32_t mode = cpu.get_reg(5);
    
    // Normalize path: "cdrom:FILE.EXT;1" → "FILE.EXT"
    char normalized[64];
    normalize_cdrom_path(path, normalized);
    
    int fd = alloc_fdesc();
    if (fd < 0) { cpu.set_reg(2, 0xFFFFFFFF); return true; }
    
    uint32_t lba, size;
    if (find_cd_file(normalized, lba, size) < 0) {
        fdescs[fd].in_use = false;
        cpu.set_reg(2, 0xFFFFFFFF);  // -1 = not found
        log_error("VFS", "open: file not found", cpu.pc, cpu.instructions);
        return true;
    }
    
    strncpy(fdescs[fd].name, normalized, 31);
    fdescs[fd].lba = lba;
    fdescs[fd].size = size;
    fdescs[fd].offset = 0;
    fdescs[fd].in_use = true;
    fdescs[fd].mode = mode;
    
    cpu.set_reg(2, fd);
    return true;
}

// A0:0x03 — read(fd, buf, nbytes)
// Returns bytes read
bool bios_read(MIPS_CPU& cpu) {
    int fd = (int)cpu.get_reg(4);
    uint32_t buf = cpu.get_reg(5);
    uint32_t nbytes = cpu.get_reg(6);
    
    // Delegate to existing cd_read
    int result = cd_read(fd, buf, nbytes);
    cpu.set_reg(2, result);
    return true;
}

// A0:0x09 — lseek(fd, offset, seek_type)
// Returns new offset
bool bios_lseek(MIPS_CPU& cpu) {
    int fd = (int)cpu.get_reg(4);
    uint32_t offset = cpu.get_reg(5);
    uint32_t whence = cpu.get_reg(6);
    
    if (fd < 0 || fd >= MAX_FDESCS || !fdescs[fd].in_use) {
        cpu.set_reg(2, 0xFFFFFFFF);
        return true;
    }
    
    switch (whence) {
        case 0: fdescs[fd].offset = offset; break;              // SEEK_SET
        case 1: fdescs[fd].offset += offset; break;             // SEEK_CUR
        case 2: fdescs[fd].offset = fdescs[fd].size + offset; break; // SEEK_END
    }
    
    cpu.set_reg(2, fdescs[fd].offset);
    return true;
}
```

### C.2 Missing BIOS Functions

| Table | Fn | Name | Priority | Notes |
|-------|----|------|----------|-------|
| A0 | 0x44 | `FlushCache()` | High | No-op is fine, but must return successfully |
| A0 | 0x5B | `GPU_cw()` | Medium | GPU command word — delegate to GPU GP0 |
| A0 | 0x72 | `Event0()` | Medium | Unknown — investigate game usage |
| B0 | 0x19 | `StopPAD()` | Low | Stop pad polling |
| B0 | 0x1B | `StopCARD()` | Low | Stop memory card access |
| B0 | 0x3A | `printf()` | Medium | TTY output — already captured by harness |
| B0 | 0x44 | `FlushCache()` | Low | Same as A0:0x44 |
| B0 | 0x5B | `GetC0Table()` | Low | Return C0 BIOS table address |
| B0 | 0x5C | `GetB0Table()` | Low | Return B0 BIOS table address |
| C0 | 0x02 | `SysEnqIntRP()` | Medium | Register interrupt handler — store for HookEntryInt |
| C0 | 0x06 | `ExceptionHandler()` | Medium | Return exception handler address |
| C0 | 0x0C | `InitDefInt()` | Medium | Initialize default interrupt handler |

### C.3 BIOS Function Table Audit

**New tool:** `bios_audit.py`

Scans the emulator's `handle_bios_call()` implementation and produces a coverage report:

```python
def audit_bios_coverage():
    """Compare implemented BIOS functions against PCSX-Reloaded reference."""
    # Parse psx_emulator_core.cpp for case statements
    # Compare against pcsxr_psxbios.c function table
    # Report: implemented / stubbed / missing
    # Output: bios_coverage_report.json
```

---

## Phase D: Agent Harness Upgrade

### D.1 Structured Test Definitions

**New file:** `test_definitions.json`

Replace ad-hoc batch profiles with formal test definitions:

```json
{
  "tests": [
    {
      "id": "boot_smoke",
      "name": "Boot Smoke Test",
      "description": "Verify ROM boots and reaches main event loop",
      "disc": "auto",  // Uses test matrix to select
      "max_instrs": 50000000,
      "wallclock_ms": 120000,
      "pass_criteria": {
        "min_vblanks": 50,
        "min_instructions": 40000000,
        "no_crash": true,
        "no_freeze": true,
        "pc_in_range": ["0x80096000", "0x80099000"]
      },
      "fail_actions": ["dump_triage", "dump_trace", "save_state"]
    },
    {
      "id": "cdrom_progression",
      "name": "CD-ROM Data Loading Test",
      "description": "Verify game loads HBD data from CD-ROM",
      "disc": "auto",
      "load_state": "boot_state.bin",
      "max_instrs": 100000000,
      "pass_criteria": {
        "min_vfs_accesses": 5,
        "vfs_must_include": ["HBD1PS1D"],
        "no_freeze": true
      }
    },
    {
      "id": "txrt_bypass",
      "name": "TXRT Decompression Bypass Test",
      "description": "Verify TXRT bypass fires and injects text",
      "disc": "auto",
      "load_state": "cdrom_ready_state.bin",
      "txrt_mode": "bypass",
      "txrt_payload": "txrt_payload.bin",
      "max_instrs": 50000000,
      "pass_criteria": {
        "min_bypass_count": 1,
        "no_crash": true
      }
    },
    {
      "id": "text_render",
      "name": "Text Rendering Verification",
      "description": "Verify English text appears in VRAM framebuffer",
      "disc": "auto",
      "load_state": "text_display_state.bin",
      "max_instrs": 10000000,
      "pass_criteria": {
        "vram_text_match": true,
        "screenshot_diff_max": 0.15
      }
    }
  ]
}
```

### D.2 Screenshot Capture System

**New file:** `psx_screenshot.h`

```cpp
struct Screenshot {
    uint32_t width;   // 320
    uint32_t height;  // 240
    uint32_t pixels[320 * 240];  // ARGB
    uint64_t instr_count;
    uint32_t vblank_count;
};

// Capture current framebuffer to screenshot struct
void capture_screenshot(PSX_Memory& mem, Screenshot& out);

// Save screenshot as BMP file
bool save_screenshot_bmp(const Screenshot& ss, const char* path);

// Save screenshot as raw RGB for comparison
bool save_screenshot_raw(const Screenshot& ss, const char* path);

// Compare two screenshots, return difference ratio (0.0 = identical)
float compare_screenshots(const Screenshot& a, const Screenshot& b);

// Compare screenshot against reference image file
float compare_screenshot_to_file(const Screenshot& ss, const char* ref_path);
```

**Integration:**
- `AgentHarness::capture_screenshot()` — called at pass criteria check
- `psx_agent_runner.exe --screenshot out.bmp` — capture at exit
- `psx_agent_runner.exe --screenshot-at-vblank 500 out.bmp` — timed capture
- Automatic screenshot on freeze/crash for visual triage

### D.3 VRAM Text Extraction & Verification

**New file:** `vram_text_scanner.h`

```cpp
// Scan VRAM for text tile patterns and extract character sequences
struct VRAMTextResult {
    int tiles_found;
    char extracted_text[4096];  // Decoded text from VRAM
    bool contains_english;       // Any ASCII letters found?
    bool contains_japanese;      // Any ShiftJIS katakana/kanji found?
    float english_ratio;         // 0.0 = all Japanese, 1.0 = all English
};

VRAMTextResult scan_vram_for_text(PSX_Memory& mem);

// Compare extracted VRAM text against translation database
bool verify_text_against_translation(const VRAMTextResult& vram,
                                      const char* translation_json_path);
```

**How it works:**
1. Scan VRAM 16bpp regions for tile patterns matching the game's font
2. Extract tile indices, map to character codes using the font table
3. Decode character sequences into text strings
4. Compare against `full_translation.json` entries
5. Report: English text found, Japanese text remaining, mismatched translations

### D.4 Enhanced Triage with Disassembly

**Upgrade `AgentHarness::write_triage_log()`:**

```
=== FREEZE DETECTION ===
Freeze Type: TIGHT_LOOP
Loop body (8 unique PCs):
  0x800967A0: 0x8FA20014  lw $v0, 0x14($sp)      ; load display flag
  0x800967A4: 0x10400003  beq $v0, $zero, +0xC    ; if display ready, skip
  0x800967A8: 0x00000000  nop                     ; delay slot
  0x800967AC: 0x08025D9E  j 0x80096798            ; loop back
  0x800967B0: 0x8FA20010  lw $v0, 0x10($sp)       ; load event flag
  0x800967B4: 0x10400005  beq $v0, $zero, +0x14   ; if event ready, skip
  0x800967B8: 0x00000000  nop
  0x800967BC: 0x08025D9E  j 0x80096798

  Root Cause Analysis:
  → Waiting for display flag at 0x800B5312 (value=0x0000)
  → Waiting for event flag at 0x800B679C (value=0x00)
  → These are set by VBlank interrupt handler
  → VBlank count: 357 (handler IS firing)
  → Possible cause: event delivery not reaching game's handler
```

### D.5 Test Result Database

**New file:** `test_results.db` (SQLite)

```sql
CREATE TABLE test_runs (
    id INTEGER PRIMARY KEY,
    timestamp TEXT,
    test_id TEXT,
    disc_path TEXT,
    profile TEXT,
    pass_status TEXT,
    instruction_count INTEGER,
    vblank_count INTEGER,
    freeze_type TEXT,
    last_pc TEXT,
    crash_reason TEXT,
    txrt_bypasses INTEGER,
    txrt_misses INTEGER,
    screenshot_path TEXT,
    triage_log_path TEXT,
    telemetry_json_path TEXT,
    notes TEXT
);

CREATE TABLE test_comparisons (
    id INTEGER PRIMARY KEY,
    run1_id INTEGER,
    run2_id INTEGER,
    diff_summary TEXT,
    FOREIGN KEY (run1_id) REFERENCES test_runs(id),
    FOREIGN KEY (run2_id) REFERENCES test_runs(id)
);
```

**Python API:**
```python
class TestResultDB:
    def record_run(self, test_id, result: dict) -> int: ...
    def get_history(self, test_id: str, limit: int = 10) -> list: ...
    def compare_runs(self, run1_id: int, run2_id: int) -> dict: ...
    def get_regression_summary(self) -> dict: ...
```

---

## Phase E: ROM Hacking & Patch Tooling

### E.1 Unified Patch Pipeline

**New file:** `patch_pipeline.py`

Single entry point for all patch operations:

```python
class PatchPipeline:
    """End-to-end patch application, verification, and distribution."""
    
    def build(self, source_iso, translation_json, output_iso):
        """Full build: patch text → update pointers → regenerate EDC/ECC."""
        # 1. Run Java patcher (dq4psx-patcher.jar)
        # 2. Run EDC/ECC regeneration (edcre.exe)
        # 3. Verify output integrity
        # 4. Generate build manifest
    
    def verify(self, patched_iso, patch_spec):
        """Verify all patches are correctly applied."""
        # Check each patch offset has expected bytes
        # Verify EDC/ECC checksums
        # Verify ISO structure intact
    
    def diff(self, iso_a, iso_b, output_report):
        """Binary diff two ISOs, report all differences."""
        # Sector-by-sector comparison
        # Categorize: text change / pointer change / EDC/ECC / other
    
    def generate_xdelta(self, source_iso, patched_iso, output_patch):
        """Generate XDelta3 patch for distribution."""
        # Run xdelta3.exe
    
    def generate_ppf(self, source_iso, patched_iso, output_patch):
        """Generate PPF3 patch for distribution."""
        # Alternative patch format
```

### E.2 Binary Differ with ISO Awareness

**Upgrade `vfs_compare.cpp` → `iso_differ.cpp`:**

```cpp
struct ISODiff {
    struct SectorDiff {
        uint32_t lba;
        uint8_t old_data[2048];
        uint8_t new_data[2048];
        int byte_changes;
        char category[32];  // "TEXT", "POINTER", "EDC_ECC", "HBD_DATA", "EXE_CODE"
    };
    
    std::vector<SectorDiff> changed_sectors;
    int total_sectors_changed;
    int text_sectors_changed;
    int pointer_sectors_changed;
    int edc_sectors_changed;
    
    // Categorize each change
    void categorize_change(SectorDiff& diff, uint32_t exe_start_lba);
    
    // Generate human-readable report
    void write_report(const char* path);
    
    // Generate machine-readable JSON
    void write_json(const char* path);
};
```

### E.3 EXE Patch Generator

**New file:** `exe_patcher.h`

```cpp
class EXEPatcher {
    // Find EXE in ISO by PS-X EXE magic
    uint32_t find_exe_offset(FILE* iso);
    
    // Read EXE into buffer
    bool extract_exe(FILE* iso, uint8_t* buf, uint32_t* out_size);
    
    // Apply MIPS instruction patches
    bool apply_mips_patch(uint8_t* exe, uint32_t exe_size,
                          uint32_t offset, uint32_t instruction);
    
    // Common patches:
    // - NOP out disc check
    // - Replace Huffman tree pointer
    // - Insert hook trampoline for TXRT bypass
    // - Patch boot region strings
    
    // Write patched EXE back to ISO
    bool write_exe_to_iso(FILE* iso, uint32_t exe_offset,
                          const uint8_t* exe, uint32_t exe_size);
    
    // Regenerate EDC/ECC for affected sectors
    void regenerate_edc_ecc(const char* iso_path, uint32_t start_lba, uint32_t end_lba);
};
```

### E.4 MIPS Trampoline Generator

**New file:** `mips_trampoline.h`

For generating in-ROM hook code when running on real emulators (DuckStation):

```cpp
struct TrampolineSpec {
    uint32_t hook_addr;       // Address to hook (function entry)
    uint32_t target_addr;     // Where to redirect (our patch code)
    uint32_t original_instr;  // Original instruction at hook_addr
    bool use_jal;             // true = JAL (call), false = J (jump)
};

// Generate trampoline bytes
// Inserts a J/JAL instruction at hook_addr that redirects to target_addr
// Saves original instruction for restoration
std::vector<uint8_t> generate_trampoline(const TrampolineSpec& spec);

// Generate a full hook with save/restore context
// Used for TXRT bypass on real emulators
std::vector<uint8_t> generate_context_save_hook(
    uint32_t hook_addr,
    uint32_t patch_code_addr,
    const std::vector<uint8_t>& patch_code
);
```

---

## Phase F: Visual Verification Pipeline

### F.1 Framebuffer Capture & Comparison

**New file:** `visual_qa.py`

```python
class VisualQA:
    """Automated visual verification of emulator output."""
    
    def capture_at_state(self, state_file, vblank_wait=100):
        """Load state, run N vblanks, capture framebuffer."""
        
    def compare_to_reference(self, screenshot, reference_path):
        """Compare screenshot against reference image."""
        # Uses pixel-by-pixel diff with tolerance
        # Returns: match_ratio, diff_image_path
        
    def detect_text_regions(self, screenshot):
        """Detect regions of the screen likely containing text."""
        # Scan for tile-aligned pixel patterns
        # Return list of bounding boxes
        
    def extract_text_from_region(self, screenshot, region):
        """Extract and decode text from a screen region."""
        # Map pixels to tile indices via font table
        # Decode tile indices to character codes
        # Return decoded text string
        
    def verify_english_text(self, screenshot, expected_texts):
        """Check that expected English text strings appear in the screenshot."""
        
    def generate_report(self, screenshot, reference, output_dir):
        """Generate full visual QA report with images and analysis."""
```

### F.2 Font Table Integration

**New file:** `font_table.h`

```cpp
// DQ4/DW7 font table mapping
// The game uses a custom font encoding where each character is a tile index
struct FontTable {
    uint16_t tile_index;
    uint16_t char_code;    // ShiftJIS or ASCII
    bool is_english;
    bool is_japanese;
};

// Load font table from extracted game data
bool load_font_table(const char* path);

// Map VRAM tile pixels to character codes
char decode_tile(const uint16_t* tile_pixels, int tile_w, int tile_h);

// Scan a VRAM region for text tiles
std::string decode_vram_text(PSX_Memory& mem, 
                              uint32_t vram_x, uint32_t vram_y,
                              int tiles_w, int tiles_h);
```

### F.3 Automated Screenshot Timeline

```python
def capture_timeline(disc_path, state_file, vblank_intervals):
    """Capture screenshots at multiple points during gameplay."""
    screenshots = []
    for vb in vblank_intervals:
        # Load state, run to vblank N, capture
        ss = run_and_capture(disc_path, state_file, target_vblank=vb)
        screenshots.append(ss)
    return screenshots

# Default timeline: every 100 vblanks for first 2000 vblanks
DEFAULT_TIMELINE = range(100, 2001, 100)
```

---

## Phase G: Cross-Emulator Validation

### G.1 DuckStation Bridge

**New file:** `duckstation_bridge.py`

```python
class DuckStationBridge:
    """Automated bridge to DuckStation for cross-validation."""
    
    def __init__(self, duckstation_path, bios_path):
        self.duckstation = duckstation_path
        self.bios = bios_path
        
    def run_with_logging(self, iso_path, max_frames=10000, output_dir="."):
        """Run DuckStation with debug logging, capture output."""
        # Launch DuckStation with -nogui -batch flags
        # Enable debug log: --log-file
        # Capture: execution log, screenshots, memory dumps
        
    def compare_traces(self, our_trace, duckstation_trace):
        """Compare instruction traces between our emulator and DuckStation."""
        # Find first divergence point
        # Report: matching instruction count, divergence PC, register differences
        
    def capture_screenshot(self, iso_path, frame_number, output_path):
        """Use DuckStation to capture a screenshot at a specific frame."""
        # Run with frame limit, capture via debug command
        
    def validate_boot(self, iso_path):
        """Verify ISO boots in DuckStation (gold standard)."""
        # Returns: boots (bool), reaches_menu (bool), error_message
```

### G.2 Trace Comparison Tool

**New file:** `trace_compare.py`

```python
def compare_execution_traces(trace_a_path, trace_b_path, 
                              max_comparisons=100000):
    """
    Compare two instruction trace logs.
    
    Each trace line format: [instr_count] PC=0xXXXXXXXX 0xXXXXXXXX <disasm>
    
    Returns:
    {
        'matching_instructions': N,
        'first_divergence': { 'instr_count': N, 'pc_a': '0x...', 'pc_b': '0x...' },
        'register_diff_at_divergence': {...},
        'divergence_type': 'PC_MISMATCH' | 'INSTRUCTION_MISMATCH' | 'REGISTER_DRIFT'
    }
    """
```

### G.3 SwanStation/RetroArch Bridge

```python
class SwanStationBridge:
    """Bridge to SwanStation (libretro core) for DW7 compatibility testing."""
    
    def run_headless(self, iso_path, max_frames, output_dir):
        """Run SwanStation via RetroArch headless mode."""
        # retroarch -L swanstation_libretro.dll --nogui iso.bin
        
    def capture_frame(self, iso_path, frame_number):
        """Capture a specific frame via RetroArch's screenshot command."""
```

---

## Phase H: Automated QA & Regression Suite

### H.1 Test Matrix Definition

**New file:** `test_matrix.json`

```json
{
  "discs": [
    {
      "id": "dq4_jp_original",
      "path": "Dragon Quest IV - Michibikareshi Mono Tachi (Japan).bin",
      "type": "original",
      "expected_boot": true,
      "expected_text": "japanese"
    },
    {
      "id": "dq4_native_v26",
      "path": "dq4_full_en_v26.bin",
      "type": "native_patch",
      "expected_boot": true,
      "expected_text": "english"
    },
    {
      "id": "dq4_rc2",
      "path": "dq4_en_rc2.bin",
      "type": "rc2_build",
      "expected_boot": true,
      "expected_text": "english"
    },
    {
      "id": "dw7_plain",
      "path": "DW7D1/DQVIID1.bin",
      "type": "dw7_baseline",
      "expected_boot": true,
      "expected_text": "english"
    }
  ],
  "emulators": ["cybergrime", "duckstation", "swanstation"],
  "test_combinations": [
    {"disc": "dq4_jp_original", "emulator": "cybergrime", "test": "boot_smoke"},
    {"disc": "dq4_jp_original", "emulator": "duckstation", "test": "boot_smoke"},
    {"disc": "dq4_native_v26", "emulator": "cybergrime", "test": "boot_smoke"},
    {"disc": "dq4_native_v26", "emulator": "duckstation", "test": "boot_smoke"},
    {"disc": "dq4_native_v26", "emulator": "duckstation", "test": "text_render"},
    {"disc": "dq4_rc2", "emulator": "swanstation", "test": "boot_smoke"},
    {"disc": "dq4_rc2", "emulator": "swanstation", "test": "text_render"}
  ]
}
```

### H.2 Regression Test Runner

**New file:** `regression_runner.py`

```python
class RegressionRunner:
    """Master regression test runner."""
    
    def __init__(self, test_matrix_path, test_defs_path):
        self.matrix = load_json(test_matrix_path)
        self.test_defs = load_json(test_defs_path)
        self.db = TestResultDB()
        
    def run_all(self):
        """Run entire test matrix."""
        results = []
        for combo in self.matrix['test_combinations']:
            result = self.run_single(combo)
            results.append(result)
            self.db.record_run(combo['test'], result)
        return results
    
    def run_single(self, combo):
        """Run a single test combination."""
        disc = self.find_disc(combo['disc'])
        test_def = self.find_test(combo['test'])
        emulator = combo['emulator']
        
        if emulator == 'cybergrime':
            return self.run_cybergrime(disc, test_def)
        elif emulator == 'duckstation':
            return self.run_duckstation(disc, test_def)
        elif emulator == 'swanstation':
            return self.run_swanstation(disc, test_def)
    
    def evaluate_pass_criteria(self, result, criteria):
        """Check if a test result meets pass criteria."""
        passed = True
        failures = []
        
        if criteria.get('min_vblanks'):
            if result['vblank_count'] < criteria['min_vblanks']:
                passed = False
                failures.append(f"VBlanks {result['vblank_count']} < {criteria['min_vblanks']}")
        
        if criteria.get('no_crash') and result['crashed']:
            passed = False
            failures.append(f"Crashed: {result.get('crash_reason', 'unknown')}")
        
        if criteria.get('no_freeze') and result['frozen']:
            passed = False
            failures.append(f"Frozen: {result.get('freeze_type', 'unknown')}")
        
        if criteria.get('min_bypass_count'):
            if result.get('txrt_bypasses', 0) < criteria['min_bypass_count']:
                passed = False
                failures.append(f"TXRT bypasses {result.get('txrt_bypasses', 0)} < {criteria['min_bypass_count']}")
        
        return {'passed': passed, 'failures': failures}
    
    def generate_report(self, results):
        """Generate HTML report with pass/fail summary."""
```

### H.3 CI/CD Integration

**New file:** `ci_runner.py`

```python
#!/usr/bin/env python3
"""CI/CD entry point for automated regression testing."""

def main():
    runner = RegressionRunner(
        'test_matrix.json',
        'test_definitions.json'
    )
    results = runner.run_all()
    
    # Generate reports
    runner.generate_report(results)
    
    # Exit with status code for CI
    all_passed = all(r['passed'] for r in results)
    sys.exit(0 if all_passed else 1)
```

**GitHub Actions / Local CI:**
```yaml
# .github/workflows/regression.yml
name: DQ4 ROM Regression Tests
on: [push, pull_request]
jobs:
  test:
    runs-on: windows-latest
    steps:
      - uses: actions/checkout@v3
      - name: Build Emulator
        run: cd cybergrime && build_agent.bat
      - name: Run Regression Tests
        run: python regression_runner.py
      - name: Upload Results
        uses: actions/upload-artifact@v3
        with:
          name: regression-report
          path: regression_report.html
```

### H.4 Test Report Generator

**New file:** `report_generator.py`

```python
class ReportGenerator:
    """Generate HTML test reports with screenshots and analysis."""
    
    def generate_html_report(self, results, output_path):
        """Full HTML report with:
        - Pass/fail summary table
        - Screenshot comparisons
        - Triage log excerpts
        - Register dumps at failure points
        - Historical trend charts
        - Link to detailed per-test pages
        """
```

---

## Phase I: AI Agent Integration

### I.1 Nexus Integration

**Connect the harness to the VW Nexus agent system:**

```python
# In harness_runner.py
from tools.vw_nexus.agent_identity import AgentClient

class NexusHarnessIntegration:
    def __init__(self):
        self.nexus = AgentClient(base_url="http://127.0.0.1:8651")
        
    def report_test_result(self, result):
        """Send test result to Nexus event feed."""
        self.nexus.post_event({
            'type': 'test_result',
            'test_id': result['test_id'],
            'passed': result['passed'],
            'details': result
        })
    
    def request_agent_analysis(self, triage_log):
        """Request an AI agent to analyze a failure."""
        # Post triage log to Nexus
        # Agent picks it up, analyzes, suggests fix
        # Returns suggested patch
```

### I.2 Self-Healing Patch Iteration

**Upgrade `iteration_harness.py`:**

```python
class SelfHealingIteration:
    """AI-driven automated patch iteration."""
    
    def __init__(self, disc, patches, max_iterations=20):
        self.disc = disc
        self.patches = patches
        self.history = []
        
    def run_iteration(self):
        """One iteration cycle:
        1. Apply current patches to ISO copy
        2. Regenerate EDC/ECC
        3. Boot in emulator
        4. Parse triage + telemetry
        5. If failure: analyze root cause
        6. Generate refined patches using AI analysis
        7. Save state for next iteration
        """
        # Apply patches
        iso = self.apply_patches()
        
        # Run emulator
        result = self.run_emulator(iso)
        
        # Analyze
        analysis = self.analyze_failure(result)
        
        # Refine
        new_patches = self.refine_patches(analysis)
        
        self.history.append({
            'iteration': len(self.history),
            'patches': self.patches,
            'result': result,
            'analysis': analysis,
            'new_patches': new_patches
        })
        
        self.patches = new_patches
        
    def analyze_failure(self, result):
        """Use AI to analyze failure and suggest fixes."""
        # Feed triage log + trace to AI agent
        # Get structured analysis:
        # - root_cause: "cdrom_wait_loop" | "freeze_at_display_check" | etc.
        # - suggested_patches: [{offset, bytes, reason}]
        # - confidence: 0.0-1.0
```

### I.3 RAG-Enhanced Debugging

**Integrate with VW Nexus RAG engine:**

```python
def rag_enhanced_triage(triage_log, telemetry):
    """Use RAG to find relevant past solutions."""
    from tools.vw_rag.retriever import Retriever
    
    retriever = Retriever()
    
    # Search for similar past issues
    query = f"freeze type {triage_log['freeze_type']} at PC {triage_log['last_pc']}"
    results = retriever.search(query, top_k=5)
    
    # Include relevant context in analysis
    context = "\n".join([r.content for r in results])
    
    # Feed to AI agent with context
    analysis = ai_analyze(triage_log, telemetry, context)
    return analysis
```

---

## Implementation Priority & Dependencies

```
Phase B (CD-ROM) ──────────────────────────┐
                                           │
Phase C (HLE BIOS) ───────────────────────┤
                                           │
Phase A.1 (Save States) ──────────────────┤
                                           │
Phase A.2 (Disassembler) ─────────────────┤─── Phase D (Harness Upgrade)
                                           │         │
Phase E (ROM Hacking) ────────────────────┤         │
                                           │         ├── Phase F (Visual QA)
                                           │         │         │
                                           │         ├── Phase G (Cross-Emu)
                                           │         │         │
                                           │         └── Phase H (Regression)
                                           │                   │
                                           │                   └── Phase I (AI)
                                           │
```

### Recommended Implementation Order

| Sprint | Phase | Tasks | Est. Effort |
|--------|-------|-------|-------------|
| 1 | B.1-B.4 | CD-ROM state machine, DMA ch3, BIOS CD calls, interrupt chain | 3-4 days |
| 1 | C.1-C.2 | File I/O (open/read/lseek/close), missing BIOS functions | 2 days |
| 2 | A.1 | Save state system | 1-2 days |
| 2 | A.2 | MIPS disassembler | 1-2 days |
| 2 | D.1-D.2 | Structured test defs, screenshot capture | 2 days |
| 3 | D.3-D.4 | VRAM text scanner, enhanced triage | 2-3 days |
| 3 | F.1-F.2 | Visual QA pipeline, font table | 2-3 days |
| 4 | E.1-E.4 | Patch pipeline, ISO differ, EXE patcher, trampoline gen | 2-3 days |
| 4 | G.1-G.2 | DuckStation bridge, trace comparison | 2 days |
| 5 | H.1-H.4 | Test matrix, regression runner, CI, report generator | 2-3 days |
| 5 | I.1-I.3 | Nexus integration, self-healing, RAG debugging | 2-3 days |
| 6 | A.3-A.4 | Memory card, enhanced trace ring | 1-2 days |
| 6 | G.3 | SwanStation bridge | 1 day |

### Critical Path to Shipping

```
1. Fix CD-ROM pipeline (Phase B) → game reaches decompression
2. Test TXRT bypass (existing code) → verify text injection works
3. Visual verification (Phase F) → confirm English text renders
4. Cross-emulator validation (Phase G) → confirm on DuckStation
5. Regression suite (Phase H) → automated pass/fail for all builds
6. XDelta3 patch generation (Phase E) → distributable patch
7. Ship!
```

---

## File Manifest

### New Files to Create

| File | Phase | Purpose |
|------|-------|---------|
| `psx_savestate.h` | A.1 | Save/load emulator state snapshots |
| `mips_disasm.h` | A.2 | Integrated MIPS disassembler |
| `psx_memcard.h` | A.3 | Memory card emulation |
| `cdrom_controller.h` | B.1 | CD-ROM state machine |
| `bios_audit.py` | C.3 | BIOS coverage audit tool |
| `test_definitions.json` | D.1 | Formal test definitions |
| `psx_screenshot.h` | D.2 | Screenshot capture & comparison |
| `vram_text_scanner.h` | D.3 | VRAM text extraction & verification |
| `test_results.db` | D.5 | SQLite test result database |
| `patch_pipeline.py` | E.1 | Unified patch build/verify/diff tool |
| `iso_differ.cpp` | E.2 | ISO-aware binary differ |
| `exe_patcher.h` | E.3 | EXE patch generator |
| `mips_trampoline.h` | E.4 | MIPS hook/trampoline generator |
| `visual_qa.py` | F.1 | Visual verification pipeline |
| `font_table.h` | F.2 | Font table mapping for text extraction |
| `duckstation_bridge.py` | G.1 | DuckStation automation bridge |
| `trace_compare.py` | G.2 | Execution trace comparison |
| `swanstation_bridge.py` | G.3 | SwanStation/RetroArch bridge |
| `test_matrix.json` | H.1 | Test matrix definition |
| `regression_runner.py` | H.2 | Master regression test runner |
| `ci_runner.py` | H.3 | CI/CD entry point |
| `report_generator.py` | H.4 | HTML report generator |

### Existing Files to Modify

| File | Phase | Changes |
|------|-------|---------|
| `psx_emulator_core.cpp` | B, C | CD-ROM state machine, DMA ch3, BIOS function expansion |
| `psx_test_station.h` | B, A | CDROM_Controller struct, save state hooks, enhanced TraceFrame |
| `agent_harness.h` | D | Screenshot capture, disassembly in triage, test result DB |
| `agent_harness.cpp` | D | Implementation of new harness features |
| `psx_agent_runner.cpp` | A, D | Save state CLI, screenshot CLI, test definition loading |
| `harness_runner.py` | D, H | Test definition support, regression runner integration |
| `iteration_harness.py` | I | Self-healing integration, AI analysis |
| `batch_profiles.json` | D | Migrate to test_definitions.json |

---

## Appendix: Key Addresses Reference

| Address | Purpose | Game |
|---------|---------|------|
| `0x80073670` | Primary Huffman decompression entry | DQ4/DW7 |
| `0x80084BF0` | Secondary decompression entry | DQ4/DW7 |
| `0x80072500` | Post-decompression return point | DQ4/DW7 |
| `0x800EF1C8` | Huffman tree global address | DW7 |
| `0x800B63D8` | VBlank counter (BIOS internal) | DW7 |
| `0x800B5312` | Display initialized flag | DW7 |
| `0x800B679C` | Event queue ready flag | DW7 |
| `0x800BA294` | VSync tick (game polls this) | DW7 |
| `0x800B91CE` | CD-ROM status flag | DW7 |
| `0x80000080` | General exception vector | PSX |
| `0xA0/0xB0/0xC0` | BIOS call vectors | PSX |

---

*End of Blueprint. This document should be updated as phases are completed.*
