#!/usr/bin/env python3
"""Round-trip test for psx_ops C++ library."""
import sys
import os
import struct

sys.path.insert(0, os.path.dirname(__file__))
from psx_ops import ExePatcher, HbdReencoder, is_available, extend_disc_mode2

def test_mips_encoding():
    """Verify constexpr MIPS encoders produce correct opcodes."""
    from psx_ops import _LIB
    # JAL 0x8008E284 -> opcode 0x03 (JAL) | target>>2
    expected_jal = 0x0C0238A1  # (0x03<<26) | (0x8008E284>>2 & 0x3FFFFFF)
    actual_jal = (0x03 << 26) | ((0x8008E284 >> 2) & 0x03FFFFFF)
    assert actual_jal == expected_jal, f"JAL mismatch: {actual_jal:#010x} != {expected_jal:#010x}"
    print("[PASS] MIPS JAL encoding")

def test_exe_patch():
    """Test ExePatcher load, read32/write32, and patch_bss_clear_narrow."""
    # Create a minimal fake EXE (8192 bytes, load_addr=0x80017F00)
    exe = bytearray(8192)
    # EXE header: "PS-X EXE" at offset 0
    exe[0:8] = b'PS-X EXE'
    # PC0 at 0x10
    struct.pack_into('<I', exe, 0x10, 0x8008E284)
    # Load addr at 0x18
    struct.pack_into('<I', exe, 0x18, 0x80017F00)
    # Text size at 0x1C = 8192 - 0x800 = 0x1800
    struct.pack_into('<I', exe, 0x1C, 0x1800)

    patcher = ExePatcher(bytes(exe))
    assert patcher.pc0 == 0x8008E284, f"PC0 mismatch: {patcher.pc0:#010x}"
    print(f"[PASS] ExePatcher load — PC0={patcher.pc0:#010x}")

    # Write/read32 at a valid RAM address within text area
    # RAM 0x80018700 = load_addr + 0x800, file offset = 0x800 + 0x800 = 0x1000
    test_ram = 0x80017F00 + 0x800  # = 0x80018700
    patcher.write32(test_ram, 0xDEADBEEF)
    val = patcher.read32(test_ram)
    assert val == 0xDEADBEEF, f"read32/write32 mismatch: {val:#010x}"
    print(f"[PASS] ExePatcher read32/write32 — val={val:#010x}")

    # Test get_data round-trip
    data = patcher.get_data()
    assert len(data) == patcher.size
    print(f"[PASS] ExePatcher get_data — size={len(data)}")

def test_hbd():
    """Test HbdReencoder basic load."""
    # Create minimal fake HBD data (just a header)
    hbd = bytearray(256)
    # Block header: end_marker=64, block_id=1, hts=24, reserved=0, tree_end=0, text_end=0, unk=0
    struct.pack_into('<IIIIIII', hbd, 0, 64, 1, 24, 0, 0, 0, 0)

    # Fake tree (just some bytes)
    tree = bytes(1480)

    enc = HbdReencoder(bytes(hbd), tree)
    assert enc.size == 256
    print(f"[PASS] HbdReencoder load — size={enc.size}")

    # Test handle_zero_tree (should return 0 for DW7-format block with treeEnd=0)
    result = enc.handle_zero_tree(0)
    assert result == 0, f"handle_zero_tree returned {result}, expected 0"
    print(f"[PASS] HbdReencoder handle_zero_tree — result={result}")

def test_dll_available():
    """Verify the DLL is loaded."""
    if is_available():
        print("[PASS] psx_ops.dll is available")
    else:
        print("[FAIL] psx_ops.dll not available")
        sys.exit(1)

if __name__ == '__main__':
    print("=== psx_ops Round-Trip Test ===\n")
    test_dll_available()
    test_mips_encoding()
    test_exe_patch()
    test_hbd()
    print("\n=== All tests passed ===")
