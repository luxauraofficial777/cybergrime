import struct, os

dq4_disc = r"c:\LuxAura\VoidWalkers_Project\DQLOSTTRANSLATION\Dragon Quest IV - Michibikareshi Mono Tachi (Japan).bin"
dw7_exe_path = r"c:\LuxAura\VoidWalkers_Project\DQLOSTTRANSLATION\translation\SLUSP012.06"
dw7_disc = r"c:\LuxAura\VoidWalkers_Project\DQLOSTTRANSLATION\DW7D1\DW7D1.bin"

sector_size = 2352
data_offset = 24
user_size = 2048

def read_sector(f, lba, count=1):
    f.seek(lba * sector_size + data_offset)
    return f.read(user_size * count)

def parse_iso_dir(dir_data, base_path=""):
    entries = []
    pos = 0
    while pos < len(dir_data):
        rec_len = dir_data[pos]
        if rec_len == 0:
            break
        if pos + 33 <= len(dir_data):
            file_lba = struct.unpack_from('<I', dir_data, pos + 2)[0]
            file_size_val = struct.unpack_from('<I', dir_data, pos + 10)[0]
            flags = dir_data[pos + 25]
            name_len = dir_data[pos + 32]
            name = dir_data[pos + 33:pos + 33 + name_len]
            if name not in [b'\x00', b'\x01']:
                entries.append({
                    'name': name, 'lba': file_lba, 'size': file_size_val,
                    'flags': flags, 'is_dir': bool(flags & 0x02)
                })
        pos += rec_len
    return entries

print("=== DQ4 DISC LAYOUT ===")
with open(dq4_disc, 'rb') as f:
    # PVD at sector 16
    pvd = read_sector(f, 16)
    root_rec = pvd[158:158+34]
    root_lba = struct.unpack_from('<I', root_rec, 2)[0]
    root_size = struct.unpack_from('<I', root_rec, 10)[0]
    print(f"Root directory: LBA={root_lba}, size={root_size}")
    
    # Read root directory
    dir_data = read_sector(f, root_lba, max(1, (root_size + user_size - 1) // user_size))
    entries = parse_iso_dir(dir_data[:root_size])
    
    for e in entries:
        ftype = "DIR " if e['is_dir'] else "FILE"
        print(f"  {ftype} {e['name']}: LBA={e['lba']}, size={e['size']}")
    
    # Check SYSTEM.CNF
    for e in entries:
        if b'CNF' in e['name'].upper() or b'SYSTEM' in e['name'].upper():
            cnf_data = read_sector(f, e['lba'], 1)[:e['size']]
            print(f"\n  SYSTEM.CNF content:\n    {cnf_data.decode('ascii', errors='replace')}")
    
    # Check EXE slot
    for e in entries:
        if not e['is_dir'] and (b'EXE' in e['name'].upper() or b'SLUS' in e['name'].upper() or b'SLPS' in e['name'].upper() or b'SCPH' in e['name'].upper()):
            exe_lba = e['lba']
            exe_size_on_disc = e['size']
            print(f"\n  DQ4 EXE: LBA={exe_lba}, size_on_disc={exe_size_on_disc}")
            
            # Read EXE header
            exe_data = read_sector(f, exe_lba, 1)
            magic = exe_data[:8]
            print(f"  DQ4 EXE magic: {magic}")
            if magic[:4] == b'PS-X':
                load_addr = struct.unpack_from('<I', exe_data, 0x10)[0]
                text_size = struct.unpack_from('<I', exe_data, 0x1C)[0]
                pc0 = struct.unpack_from('<I', exe_data, 0x14)[0]
                print(f"  DQ4 EXE: load_addr=0x{load_addr:08X}, text_size={text_size}, pc0=0x{pc0:08X}")

print("\n=== DW7 DISC LAYOUT ===")
with open(dw7_disc, 'rb') as f:
    pvd = read_sector(f, 16)
    root_rec = pvd[158:158+34]
    root_lba = struct.unpack_from('<I', root_rec, 2)[0]
    root_size = struct.unpack_from('<I', root_rec, 10)[0]
    print(f"Root directory: LBA={root_lba}, size={root_size}")
    
    dir_data = read_sector(f, root_lba, max(1, (root_size + user_size - 1) // user_size))
    entries = parse_iso_dir(dir_data[:root_size])
    
    for e in entries:
        ftype = "DIR " if e['is_dir'] else "FILE"
        print(f"  {ftype} {e['name']}: LBA={e['lba']}, size={e['size']}")

# DW7 EXE size
dw7_exe_size = os.path.getsize(dw7_exe_path)
print(f"\n=== SPACE ANALYSIS ===")
print(f"DW7 EXE file size: {dw7_exe_size} bytes ({dw7_exe_size // user_size} sectors)")
print(f"DW7 EXE text_size field: {dw7_exe_size - 0x800} bytes (payload)")

# DQ4 disc total size
dq4_disc_size = os.path.getsize(dq4_disc)
dq4_sectors = dq4_disc_size // sector_size
print(f"DQ4 disc: {dq4_disc_size} bytes, {dq4_sectors} sectors")

# Check gap between DQ4 EXE and HBD
# DQ4 EXE at LBA 24, HBD at LBA 362
# Available space: sectors 24 to 361 = 338 sectors = 338 * 2048 = 692224 bytes
available = (362 - 24) * user_size
print(f"\nDQ4 EXE slot: sectors 24-361 = {362-24} sectors = {available} bytes")
print(f"DW7 EXE needs: {dw7_exe_size} bytes ({dw7_exe_size // user_size + 1} sectors)")
if dw7_exe_size <= available:
    print(f"FIT: YES (margin: {available - dw7_exe_size} bytes)")
else:
    print(f"FIT: NO (overflow: {dw7_exe_size - available} bytes)")
    print(f"  Would need to shift HBD by {(dw7_exe_size - available + user_size - 1) // user_size} sectors")
