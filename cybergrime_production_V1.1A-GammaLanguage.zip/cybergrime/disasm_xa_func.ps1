$exePath = 'c:\LuxAura\VoidWalkers_Project\DQLOSTTRANSLATION\translation\SLUSP012.06'
$bytes = [System.IO.File]::ReadAllBytes($exePath)
$loadAddr = 0x80017F00

$regNames = @('zero','at','v0','v1','a0','a1','a2','a3','t0','t1','t2','t3','t4','t5','t6','t7','s0','s1','s2','s3','s4','s5','s6','s7','t8','t9','k0','k1','gp','sp','fp','ra')

function DisasmRange($ramAddr, $count) {
    $fileOff = $ramAddr - $loadAddr + 0x800
    for ($j = 0; $j -lt $count; $j++) {
        $off = $fileOff + $j * 4
        if ($off -lt 0 -or $off + 3 -ge $bytes.Length) { Write-Host "  [out of range]"; continue }
        $val = [BitConverter]::ToUInt32($bytes, $off)
        $ram = $loadAddr + $off - 0x800
        $opcode = ($val -shr 26) -band 0x3F
        $rs = ($val -shr 21) -band 0x1F
        $rt = ($val -shr 16) -band 0x1F
        $rd = ($val -shr 11) -band 0x1F
        $shamt = ($val -shr 6) -band 0x1F
        $funct = $val -band 0x3F
        $imm = $val -band 0xFFFF
        if ($imm -ge 0x8000) { $immS = $imm - 0x10000 } else { $immS = $imm }
        $target = ($val -band 0x3FFFFFF) -shl 2
        
        $rsn = $regNames[$rs]; $rtn = $regNames[$rt]; $rdn = $regNames[$rd]
        $desc = ''
        switch ($opcode) {
            0 { 
                if ($val -eq 0) { $desc = "nop" }
                elseif ($funct -eq 0x00) { $desc = "sll $rdn,$rtn,$shamt" }
                elseif ($funct -eq 0x02) { $desc = "srl $rdn,$rtn,$shamt" }
                elseif ($funct -eq 0x03) { $desc = "sra $rdn,$rtn,$shamt" }
                elseif ($funct -eq 0x08) { $desc = "jr $rsn" }
                elseif ($funct -eq 0x09) { $desc = "jalr $rdn,$rsn" }
                elseif ($funct -eq 0x0C) { $desc = "syscall" }
                elseif ($funct -eq 0x10) { $desc = "mfhi $rdn" }
                elseif ($funct -eq 0x12) { $desc = "mflo $rdn" }
                elseif ($funct -eq 0x18) { $desc = "mult $rsn,$rtn" }
                elseif ($funct -eq 0x19) { $desc = "multu $rsn,$rtn" }
                elseif ($funct -eq 0x1A) { $desc = "div $rsn,$rtn" }
                elseif ($funct -eq 0x1B) { $desc = "divu $rsn,$rtn" }
                elseif ($funct -eq 0x20) { $desc = "add $rdn,$rsn,$rtn" }
                elseif ($funct -eq 0x21) { $desc = "addu $rdn,$rsn,$rtn" }
                elseif ($funct -eq 0x22) { $desc = "sub $rdn,$rsn,$rtn" }
                elseif ($funct -eq 0x23) { $desc = "subu $rdn,$rsn,$rtn" }
                elseif ($funct -eq 0x24) { $desc = "and $rdn,$rsn,$rtn" }
                elseif ($funct -eq 0x25) { $desc = "or $rdn,$rsn,$rtn" }
                elseif ($funct -eq 0x26) { $desc = "xor $rdn,$rsn,$rtn" }
                elseif ($funct -eq 0x27) { $desc = "nor $rdn,$rsn,$rtn" }
                elseif ($funct -eq 0x2A) { $desc = "slt $rdn,$rsn,$rtn" }
                elseif ($funct -eq 0x2B) { $desc = "sltu $rdn,$rsn,$rtn" }
                else { $desc = "special funct=0x$($funct.ToString('X2'))" }
            }
            0x01 { $desc = "regimm rt=$rtn imm=0x$($imm.ToString('X4'))" }
            0x02 { $desc = "j 0x$($target.ToString('X8'))" }
            0x03 { $desc = "jal 0x$($target.ToString('X8'))" }
            0x04 { $desc = "beq $rsn,$rtn,0x$(($ram + 4 + $immS * 4).ToString('X8'))" }
            0x05 { $desc = "bne $rsn,$rtn,0x$(($ram + 4 + $immS * 4).ToString('X8'))" }
            0x06 { $desc = "blez $rsn,0x$(($ram + 4 + $immS * 4).ToString('X8'))" }
            0x07 { $desc = "bgtz $rsn,0x$(($ram + 4 + $immS * 4).ToString('X8'))" }
            0x08 { $desc = "addi $rtn,$rsn,$immS" }
            0x09 { $desc = "addiu $rtn,$rsn,$immS (0x$($imm.ToString('X4')))" }
            0x0A { $desc = "slti $rtn,$rsn,$immS" }
            0x0B { $desc = "sltiu $rtn,$rsn,$immS" }
            0x0C { $desc = "andi $rtn,$rsn,0x$($imm.ToString('X4'))" }
            0x0D { $desc = "ori $rtn,$rsn,0x$($imm.ToString('X4'))" }
            0x0E { $desc = "xori $rtn,$rsn,0x$($imm.ToString('X4'))" }
            0x0F { $desc = "lui $rtn,0x$($imm.ToString('X4'))" }
            0x20 { $desc = "lb $rtn,0x$($imm.ToString('X4'))($rsn)" }
            0x21 { $desc = "lh $rtn,0x$($imm.ToString('X4'))($rsn)" }
            0x23 { $desc = "lw $rtn,0x$($imm.ToString('X4'))($rsn)" }
            0x24 { $desc = "lbu $rtn,0x$($imm.ToString('X4'))($rsn)" }
            0x25 { $desc = "lhu $rtn,0x$($imm.ToString('X4'))($rsn)" }
            0x28 { $desc = "sb $rtn,0x$($imm.ToString('X4'))($rsn)" }
            0x29 { $desc = "sh $rtn,0x$($imm.ToString('X4'))($rsn)" }
            0x2B { $desc = "sw $rtn,0x$($imm.ToString('X4'))($rsn)" }
            default { $desc = "op=0x$($opcode.ToString('X2'))" }
        }
        Write-Host ("  0x{0:X8}: 0x{1:X8}  {2}" -f $ram, $val, $desc)
    }
}

# Disassemble the XA/STR function at 0x8008AEF4
Write-Host "=== XA/STR function at 0x8008AEF4 (first 80 instructions) ==="
DisasmRange 0x8008AEF4 80
