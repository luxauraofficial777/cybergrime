#!/usr/bin/env python3
"""Focused trace: PC0 → BSS clear → 0x8008E2B0 → bootstrap"""
import struct

def read_sector(disc, lba):
    return disc[lba * 2352 + 24: lba * 2352 + 24 + 2048]

def read_exe_from_disc(disc_path, exe_lba, exe_size):
    with open(disc_path, 'rb') as f:
        disc = f.read()
    exe = bytearray()
    sectors = (exe_size + 2047) // 2048
    for i in range(sectors):
        exe.extend(read_sector(disc, exe_lba + i))
    return bytes(exe[:exe_size])

DISC = r'c:\LuxAura\VoidWalkers_Project\DQLOSTTRANSLATION\dq4_phaseC_build1.bin'
exe = read_exe_from_disc(DISC, 24, 960948)
DW7_DISC = r'c:\LuxAura\VoidWalkers_Project\DQLOSTTRANSLATION\DW7D1\DW7D1.bin'
dw7_exe = read_exe_from_disc(DW7_DISC, 24, 675840)

LOAD_ADDR = 0x80017F00
EXE_HEADER = 0x800

def ram_to_file(ram):
    return ram - LOAD_ADDR + EXE_HEADER

def read_word(data, ram):
    foff = ram_to_file(ram)
    if foff + 4 <= len(data):
        return struct.unpack_from('<I', data, foff)[0]
    return None

def disasm(word, pc):
    if word == 0: return "nop"
    op = (word >> 26) & 0x3F
    rs = (word >> 21) & 0x1F
    rt = (word >> 16) & 0x1F
    rd = (word >> 11) & 0x1F
    shamt = (word >> 6) & 0x1F
    funct = word & 0x3F
    imm = word & 0xFFFF
    s_imm = imm - 65536 if imm >= 32768 else imm
    target = word & 0x03FFFFFF
    regs = ['zero','at','v0','v1','a0','a1','a2','a3','t0','t1','t2','t3','t4','t5','t6','t7','s0','s1','s2','s3','s4','s5','s6','s7','t8','t9','k0','k1','gp','sp','fp','ra']
    if op == 0:
        if funct == 0x08: return f"jr {regs[rs]}"
        if funct == 0x09: return f"jalr {regs[rd]}, {regs[rs]}"
        if funct == 0x20: return f"add {regs[rd]}, {regs[rs]}, {regs[rt]}"
        if funct == 0x21: return f"addu {regs[rd]}, {regs[rs]}, {regs[rt]}"
        if funct == 0x23: return f"subu {regs[rd]}, {regs[rs]}, {regs[rt]}"
        if funct == 0x24: return f"and {regs[rd]}, {regs[rs]}, {regs[rt]}"
        if funct == 0x25: return f"or {regs[rd]}, {regs[rs]}, {regs[rt]}"
        if funct == 0x2A: return f"slt {regs[rd]}, {regs[rs]}, {regs[rt]}"
        if funct == 0x2B: return f"sltu {regs[rd]}, {regs[rs]}, {regs[rt]}"
        if funct == 0x00: return f"sll {regs[rd]}, {regs[rt]}, {shamt}"
        if funct == 0x02: return f"srl {regs[rd]}, {regs[rt]}, {shamt}"
        if funct == 0x03: return f"sra {regs[rd]}, {regs[rt]}, {shamt}"
        if funct == 0x0C: return f"syscall"
        return f"special 0x{funct:02X}"
    if op == 0x01:
        if rt == 0: return f"bltz {regs[rs]}, 0x{pc + 4 + (s_imm << 2):08X}"
        if rt == 1: return f"bgez {regs[rs]}, 0x{pc + 4 + (s_imm << 2):08X}"
        return f"regimm {rt}"
    if op == 0x02: return f"j 0x{(pc & 0xF0000000) | (target << 2):08X}"
    if op == 0x03: return f"jal 0x{(pc & 0xF0000000) | (target << 2):08X}"
    if op == 0x04: return f"beq {regs[rs]}, {regs[rt]}, 0x{pc + 4 + (s_imm << 2):08X}"
    if op == 0x05: return f"bne {regs[rs]}, {regs[rt]}, 0x{pc + 4 + (s_imm << 2):08X}"
    if op == 0x06: return f"blez {regs[rs]}, 0x{pc + 4 + (s_imm << 2):08X}"
    if op == 0x07: return f"bgtz {regs[rs]}, 0x{pc + 4 + (s_imm << 2):08X}"
    if op == 0x08: return f"addi {regs[rt]}, {regs[rs]}, {s_imm}"
    if op == 0x09: return f"addiu {regs[rt]}, {regs[rs]}, {s_imm}"
    if op == 0x0A: return f"slti {regs[rt]}, {regs[rs]}, {s_imm}"
    if op == 0x0B: return f"sltiu {regs[rt]}, {regs[rs]}, {s_imm}"
    if op == 0x0C: return f"andi {regs[rt]}, {regs[rs]}, 0x{imm:04X}"
    if op == 0x0D: return f"ori {regs[rt]}, {regs[rs]}, 0x{imm:04X}"
    if op == 0x0E: return f"xori {regs[rt]}, {regs[rs]}, 0x{imm:04X}"
    if op == 0x0F: return f"lui {regs[rt]}, 0x{imm:04X}"
    if op == 0x20: return f"lb {regs[rt]}, {s_imm}({regs[rs]})"
    if op == 0x21: return f"lh {regs[rt]}, {s_imm}({regs[rs]})"
    if op == 0x23: return f"lw {regs[rt]}, {s_imm}({regs[rs]})"
    if op == 0x24: return f"lbu {regs[rt]}, {s_imm}({regs[rs]})"
    if op == 0x25: return f"lhu {regs[rt]}, {s_imm}({regs[rs]})"
    if op == 0x28: return f"sb {regs[rt]}, {s_imm}({regs[rs]})"
    if op == 0x29: return f"sh {regs[rt]}, {s_imm}({regs[rs]})"
    if op == 0x2B: return f"sw {regs[rt]}, {s_imm}({regs[rs]})"
    return f"op=0x{op:02X}"

def show(data, start, count, label=""):
    if label: print(f"\n--- {label} ---")
    for i in range(count):
        ram = start + i * 4
        w = read_word(data, ram)
        if w is None:
            print(f"  0x{ram:08X}: <beyond EXE>")
            break
        d = disasm(w, ram)
        print(f"  0x{ram:08X}: 0x{w:08X}  {d}")

# PC0 entry: BSS clear and what follows
print("=" * 60)
print("PC0 ENTRY PATH (0x8008E284)")
print("=" * 60)
show(exe, 0x8008E284, 20, "Frank PC0 → BSS clear → post-clear")
show(dw7_exe, 0x8008E284, 20, "DW7 PC0 → BSS clear → post-clear")

# The function at 0x8008E2B0 — who calls it?
# Search for jal 0x8008E2B0 = 0x0C0238AC
# Also search for j 0x8008E2B0 = 0x080238AC
# Also search for any reference to 0x8008E2B0
print("\n" + "=" * 60)
print("SEARCH FOR CALLERS OF 0x8008E2B0")
print("=" * 60)

# jal 0x8008E2B0
jal_word = 0x0C0238AC
# j 0x8008E2B0
j_word = 0x080238AC

for name, data in [("Frank", exe), ("DW7", dw7_exe)]:
    print(f"\n{name}:")
    for foff in range(0x800, len(data) - 4, 4):
        w = struct.unpack_from('<I', data, foff)[0]
        if w == jal_word or w == j_word:
            ram = foff - EXE_HEADER + LOAD_ADDR
            kind = "jal" if w == jal_word else "j"
            print(f"  {kind} 0x8008E2B0 at 0x{ram:08X}")
            # Show context
            for j in range(-4, 3):
                ctx_ram = ram + j * 4
                ctx_w = read_word(data, ctx_ram)
                if ctx_w is not None:
                    marker = " <<<" if j == 0 else ""
                    print(f"    0x{ctx_ram:08X}: 0x{ctx_w:08X}  {disasm(ctx_w, ctx_ram)}{marker}")

# Also check: what's the BSS clear end condition?
# BSS clear: lui v0, 0x800C; addiu v0, v0, 0xCCC8; lui v1, 0x800E; addiu v1, v1, 0x9E80
# Loop: sw zero, 0(v0); addiu v0, v0, 4; bne v0, v1, loop
# After loop: falls through to next instruction
print("\n" + "=" * 60)
print("BSS CLEAR LOOP DETAIL")
print("=" * 60)
show(exe, 0x8008E284, 8, "Frank BSS clear")
show(dw7_exe, 0x8008E284, 8, "DW7 BSS clear")

# Check what 0x800A2028 does (called from VBlank init)
print("\n" + "=" * 60)
print("0x800A2028 (called from VBlank init at 0x800969EC)")
print("=" * 60)
show(exe, 0x800A2028, 16, "Frank")
show(dw7_exe, 0x800A2028, 16, "DW7")

# Check 0x800A21E8 (stack setup, called from bootstrap)
print("\n" + "=" * 60)
print("0x800A21E8 (stack setup)")
print("=" * 60)
show(exe, 0x800A21E8, 16, "Frank")
show(dw7_exe, 0x800A21E8, 16, "DW7")

# Check 0x80096E94 (called from VBlank init)
print("\n" + "=" * 60)
print("0x80096E94 (called from VBlank init)")
print("=" * 60)
show(exe, 0x80096E94, 24, "Frank")
show(dw7_exe, 0x80096E94, 24, "DW7")
