# Find callers of the FMV setup function at 0x8008AB00
# 0x8008AB00 >> 2 = 0x022AC0
# jal = 0x0C022AC0, j = 0x08022AC0

$exePath = 'c:\LuxAura\VoidWalkers_Project\DQLOSTTRANSLATION\translation\SLUSP012.06'
$bytes = [System.IO.File]::ReadAllBytes($exePath)
$loadAddr = 0x80017F00

$rn = @('zero','at','v0','v1','a0','a1','a2','a3','t0','t1','t2','t3','t4','t5','t6','t7','s0','s1','s2','s3','s4','s5','s6','s7','t8','t9','k0','k1','gp','sp','fp','ra')

$target = 0x022AC0
Write-Host "=== Callers of FMV setup function at 0x8008AB00 ==="
for ($i = 0x800; $i -lt $bytes.Length - 3; $i += 4) {
    $insn = [BitConverter]::ToUInt32($bytes, $i)
    $op = $insn -shr 26
    if (($op -eq 2 -or $op -eq 3) -and (($insn -band 0x3FFFFFF) -eq $target)) {
        $ram = $loadAddr + $i - 0x800
        $type = if ($op -eq 3) { 'jal' } else { 'j' }
        Write-Host ""
        Write-Host "--- $type at RAM 0x$($ram.ToString('X8')) ---"
        # Show 12 instructions before to see a0 setup
        for ($k = -12; $k -le 2; $k++) {
            $off2 = $i + $k * 4
            if ($off2 -lt 0x800 -or $off2 + 3 -ge $bytes.Length) { continue }
            $val2 = [BitConverter]::ToUInt32($bytes, $off2)
            $ram2 = $loadAddr + $off2 - 0x800
            $op2 = $val2 -shr 26
            $imm2 = $val2 -band 0xFFFF
            $immS2 = if ($imm2 -ge 0x8000) { $imm2 - 0x10000 } else { $imm2 }
            $rs2 = ($val2 -shr 21) -band 0x1F; $rt2 = ($val2 -shr 16) -band 0x1F
            $rsn2=$rn[$rs2]; $rtn2=$rn[$rt2]
            $d2 = ''
            if ($val2 -eq 0) { $d2 = 'nop' }
            elseif ($op2 -eq 0x09) { $d2 = "addiu $rtn2,$rsn2,$immS2" }
            elseif ($op2 -eq 0x0F) { $d2 = "lui $rtn2,0x$($imm2.ToString('X4'))" }
            elseif ($op2 -eq 0x0D) { $d2 = "ori $rtn2,$rsn2,0x$($imm2.ToString('X4'))" }
            elseif ($op2 -eq 0x23) { $d2 = "lw $rtn2,0x$($imm2.ToString('X4'))($rsn2)" }
            elseif ($op2 -eq 0x24) { $d2 = "lbu $rtn2,0x$($imm2.ToString('X4'))($rsn2)" }
            elseif ($op2 -eq 0x21) { $d2 = "lh $rtn2,0x$($imm2.ToString('X4'))($rsn2)" }
            elseif ($op2 -eq 0x28) { $d2 = "sb $rtn2,0x$($imm2.ToString('X4'))($rsn2)" }
            elseif ($op2 -eq 0x2B) { $d2 = "sw $rtn2,0x$($imm2.ToString('X4'))($rsn2)" }
            elseif ($op2 -eq 0x03) { $t2=($val2 -band 0x3FFFFFF)-shl 2; $d2="jal 0x$($t2.ToString('X8'))" }
            elseif ($op2 -eq 0x02) { $t2=($val2 -band 0x3FFFFFF)-shl 2; $d2="j 0x$($t2.ToString('X8'))" }
            elseif ($op2 -eq 0x00 -and ($val2 -band 0x3F) -eq 0x08) { $d2="jr $($rn[$rs2])" }
            elseif ($op2 -eq 0x00 -and ($val2 -band 0x3F) -eq 0x21) { $rd2=($val2 -shr 11)-band 0x1F; $d2="addu $($rn[$rd2]),$rsn2,$rtn2" }
            else { $d2="op=0x$($op2.ToString('X2'))" }
            $m = if ($k -eq 0) { ' <<<' } else { '' }
            Write-Host ("    0x{0:X8}: 0x{1:X8}  {2}{3}" -f $ram2, $val2, $d2, $m)
        }
    }
}
