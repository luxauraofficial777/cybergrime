#!/usr/bin/env python3
"""Check what data is at the stack corruption address 0x800C0534"""
import struct

def read_sector(disc, lba):
    return disc[lba * 2352 + 24: lba * 2352 + 24 + 2048]

def read_exe_from_disc(disc_path, exe_lba, exe_size):
    with open(disc_path, 'rb') as f:
        disc = f.read()
    exe = bytearray()
    sectors = (exe_size + 2047) // 2048
    for i in range(sectors):
        exe.extend(read_sector(disc, exe_lba + i))
    return bytes(exe[:exe_size])

DISC = r'c:\LuxAura\VoidWalkers_Project\DQLOSTTRANSLATION\dq4_phaseC_build1.bin'
exe = read_exe_from_disc(DISC, 24, 960948)
DW7_DISC = r'c:\LuxAura\VoidWalkers_Project\DQLOSTTRANSLATION\DW7D1\DW7D1.bin'
dw7_exe = read_exe_from_disc(DW7_DISC, 24, 675840)

LOAD_ADDR = 0x80017F00
EXE_HEADER = 0x800

def ram_to_file(ram):
    return ram - LOAD_ADDR + EXE_HEADER

def read_word(data, ram):
    foff = ram_to_file(ram)
    if 0 <= foff and foff + 4 <= len(data):
        return struct.unpack_from('<I', data, foff)[0]
    return None

def read_bytes(data, ram, n):
    foff = ram_to_file(ram)
    if 0 <= foff and foff + n <= len(data):
        return data[foff:foff+n]
    return None

# The stack corruption address: sp=0x800C0514, ra saved at sp+32=0x800C0534
# Check what's in the EXE at this address
print("=== Stack area 0x800C0500-0x800C0560 ===")
print("\n--- Frank EXE ---")
for addr in range(0x800C0500, 0x800C0560, 4):
    w = read_word(exe, addr)
    if w is not None:
        print(f"  0x{addr:08X}: 0x{w:08X}")
    else:
        print(f"  0x{addr:08X}: <not in EXE>")

print("\n--- DW7 EXE ---")
for addr in range(0x800C0500, 0x800C0560, 4):
    w = read_word(dw7_exe, addr)
    if w is not None:
        print(f"  0x{addr:08X}: 0x{w:08X}")
    else:
        print(f"  0x{addr:08X}: <not in EXE>")

# Check EXE sizes and data/BSS boundaries
print("\n=== EXE Layout ===")
frank_exe_size = len(exe) - EXE_HEADER  # subtract header
dw7_exe_size = len(dw7_exe) - EXE_HEADER
frank_data_end = LOAD_ADDR + frank_exe_size
dw7_data_end = LOAD_ADDR + dw7_exe_size
print(f"Frank: EXE data size={frank_exe_size} (0x{frank_exe_size:X}), data end=0x{frank_data_end:08X}")
print(f"DW7:   EXE data size={dw7_exe_size} (0x{dw7_exe_size:X}), data end=0x{dw7_data_end:08X}")
print(f"Frank BSS: 0x800CCCC8 - 0x800E9E80")
print(f"DW7 BSS:   0x800BC668 - 0x800F4980")
print(f"Stack at 0x800C0514: Frank={'DATA' if 0x800C0514 < frank_data_end else 'BSS'}, DW7={'DATA' if 0x800C0514 < dw7_data_end else 'BSS'}")

# Check what the EXE header says about the load size
print("\n=== EXE Headers ===")
# PSX EXE header: offset 0x0C = load address, 0x1C = text size, 0x10 = PC0, 0x14 = GP, 0x18 = SP
frank_pc0 = struct.unpack_from('<I', exe, 0x10)[0]
frank_gp = struct.unpack_from('<I', exe, 0x14)[0]
frank_sp = struct.unpack_from('<I', exe, 0x18)[0]
frank_load = struct.unpack_from('<I', exe, 0x0C)[0]
frank_text = struct.unpack_from('<I', exe, 0x1C)[0]
print(f"Frank: PC0=0x{frank_pc0:08X} GP=0x{frank_gp:08X} SP=0x{frank_sp:08X} load=0x{frank_load:08X} text_size=0x{frank_text:X}")

dw7_pc0 = struct.unpack_from('<I', dw7_exe, 0x10)[0]
dw7_gp = struct.unpack_from('<I', dw7_exe, 0x14)[0]
dw7_sp = struct.unpack_from('<I', dw7_exe, 0x18)[0]
dw7_load = struct.unpack_from('<I', dw7_exe, 0x0C)[0]
dw7_text = struct.unpack_from('<I', dw7_exe, 0x1C)[0]
print(f"DW7:   PC0=0x{dw7_pc0:08X} GP=0x{dw7_gp:08X} SP=0x{dw7_sp:08X} load=0x{dw7_load:08X} text_size=0x{dw7_text:X}")

# Check if the stack area in Frank overlaps with any known data structures
# The VBlank callback table is at 0x800B63B8, vblank_cnt at 0x800B63D8
# Check if there are any global variables near 0x800C0514
print("\n=== Data at stack area in Frank EXE (initialized data) ===")
# The stack is at 0x800C0514. In Frank, this is in the data section.
# Check if this area contains non-zero data (which would indicate it's used for something)
nonzero_count = 0
for addr in range(0x800C0400, 0x800C0600, 4):
    w = read_word(exe, addr)
    if w is not None and w != 0:
        nonzero_count += 1
        if nonzero_count <= 20:
            print(f"  0x{addr:08X}: 0x{w:08X}")

if nonzero_count == 0:
    print("  All zeros in this range")
else:
    print(f"  ... {nonzero_count} non-zero words total")

# Check what the v22 trace function at 0x80096700 does
# It's the VBlank wait function — let's see what calls it
print("\n=== VBlank wait function at 0x80096700 ===")
# Check the function prologue
for addr in range(0x80096700, 0x80096720, 4):
    w = read_word(exe, addr)
    if w is not None:
        from trace_crash import disasm
        print(f"  0x{addr:08X}: 0x{w:08X}")
