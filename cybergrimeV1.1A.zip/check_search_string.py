#!/usr/bin/env python3
"""Check what string is at 0x8002844C in the DW7 EXE and disassemble the wait loop."""
import struct

exe_path = r'C:\LuxAura\VoidWalkers_Project\DQLOSTTRANSLATION\translation\SLUSP012.06_clean.bin'
LOAD_ADDR = 0x80017F00

with open(exe_path, 'rb') as f:
    exe = f.read()

def rd32(off):
    return struct.unpack_from('<I', exe, off)[0]

def ram_to_off(ram):
    return ram - LOAD_ADDR + 0x800

# Check string at 0x8002844C
str_off = ram_to_off(0x8002844C)
print(f"=== String at RAM 0x8002844C (file offset 0x{str_off:X}) ===")
s = exe[str_off:str_off+64]
# Print as null-terminated string
null_pos = s.find(b'\x00')
if null_pos >= 0:
    s = s[:null_pos]
print(f"  '{s.decode('ascii', errors='replace')}'")
print(f"  Hex: {s.hex()}")

# Also check 0x800F4930 (buffer used in B:53 calls)
buf_off = ram_to_off(0x800F4930)
print(f"\n=== Buffer at RAM 0x800F4930 (file offset 0x{buf_off:X}) ===")
if buf_off < len(exe):
    print(f"  First 32 bytes: {exe[buf_off:buf_off+32].hex()}")
else:
    print(f"  BEYOND EXE (BSS region)")

# Check 0x800AAFF0 (used in C:2 call)
buf2_off = ram_to_off(0x800AAFF0)
print(f"\n=== Buffer at RAM 0x800AAFF0 (file offset 0x{buf2_off:X}) ===")
if buf2_off < len(exe):
    print(f"  First 32 bytes: {exe[buf2_off:buf2_off+32].hex()}")
else:
    print(f"  BEYOND EXE (BSS region)")

# Disassemble the wait loop at 0x800967A0-0x80096800
print(f"\n=== Wait Loop (RAM 0x800967A0) ===")
loop_off = ram_to_off(0x800967A0)
for i in range(32):
    off = loop_off + i * 4
    if off + 4 > len(exe): break
    word = rd32(off)
    ram = LOAD_ADDR + off - 0x800
    # Simple decode
    op = (word >> 26) & 0x3F
    rs = (word >> 21) & 0x1F
    rt = (word >> 16) & 0x1F
    imm = word & 0xFFFF
    simm = struct.unpack('h', struct.pack('H', imm))[0]
    target = word & 0x3FFFFFF
    regs = ['zero','at','v0','v1','a0','a1','a2','a3',
            't0','t1','t2','t3','t4','t5','t6','t7',
            's0','s1','s2','s3','s4','s5','s6','s7',
            't8','t9','k0','k1','gp','sp','fp','ra']
    
    if word == 0: d = 'nop'
    elif op == 0x09: d = f'addiu {regs[rt]}, {regs[rs]}, {simm}'
    elif op == 0x0F: d = f'lui {regs[rt]}, 0x{imm:04X}'
    elif op == 0x23: d = f'lw {regs[rt]}, {simm}({regs[rs]})'
    elif op == 0x2B: d = f'sw {regs[rt]}, {simm}({regs[rs]})'
    elif op == 0x04: d = f'beq {regs[rs]}, {regs[rt]}, 0x{ram + 4 + (simm << 2):08X}'
    elif op == 0x05: d = f'bne {regs[rs]}, {regs[rt]}, 0x{ram + 4 + (simm << 2):08X}'
    elif op == 0x02: d = f'j 0x{(ram & 0xF0000000) | (target << 2):08X}'
    elif op == 0x03: d = f'jal 0x{(ram & 0xF0000000) | (target << 2):08X}'
    elif op == 0x00:
        funct = word & 0x3F
        if funct == 0x08: d = f'jr {regs[rs]}'
        elif funct == 0x21: d = f'addu {regs[(word>>11)&0x1F]}, {regs[rs]}, {regs[rt]}'
        elif funct == 0x24: d = f'and {regs[(word>>11)&0x1F]}, {regs[rs]}, {regs[rt]}'
        elif funct == 0x25: d = f'or {regs[(word>>11)&0x1F]}, {regs[rs]}, {regs[rt]}'
        elif funct == 0x00: d = f'sll {regs[(word>>11)&0x1F]}, {regs[rt]}, {(word>>6)&0x1F}'
        else: d = f'.word 0x{word:08X}'
    elif op == 0x01:
        d = f'b{["ltz","gez"][rt]} {regs[rs]}, 0x{ram + 4 + (simm << 2):08X}'
    elif op == 0x0D: d = f'ori {regs[rt]}, {regs[rs]}, 0x{imm:04X}'
    elif op == 0x0C: d = f'andi {regs[rt]}, {regs[rs]}, 0x{imm:04X}'
    elif op == 0x20: d = f'lb {regs[rt]}, {simm}({regs[rs]})'
    elif op == 0x24: d = f'lbu {regs[rt]}, {simm}({regs[rs]})'
    elif op == 0x28: d = f'sb {regs[rt]}, {simm}({regs[rs]})'
    else: d = f'.word 0x{word:08X} (op={op:02X})'
    
    print(f"  0x{ram:08X}: 0x{word:08X}  {d}")

# Also check what's around 0x800966C4 (the RA value)
print(f"\n=== RA Target (RAM 0x800966C4) ===")
ra_off = ram_to_off(0x800966C4)
for i in range(20):
    off = ra_off + i * 4
    if off + 4 > len(exe): break
    word = rd32(off)
    ram = LOAD_ADDR + off - 0x800
    op = (word >> 26) & 0x3F
    rs = (word >> 21) & 0x1F
    rt = (word >> 16) & 0x1F
    imm = word & 0xFFFF
    simm = struct.unpack('h', struct.pack('H', imm))[0]
    target = word & 0x3FFFFFF
    regs = ['zero','at','v0','v1','a0','a1','a2','a3',
            't0','t1','t2','t3','t4','t5','t6','t7',
            's0','s1','s2','s3','s4','s5','s6','s7',
            't8','t9','k0','k1','gp','sp','fp','ra']
    
    if word == 0: d = 'nop'
    elif op == 0x09: d = f'addiu {regs[rt]}, {regs[rs]}, {simm}'
    elif op == 0x0F: d = f'lui {regs[rt]}, 0x{imm:04X}'
    elif op == 0x23: d = f'lw {regs[rt]}, {simm}({regs[rs]})'
    elif op == 0x2B: d = f'sw {regs[rt]}, {simm}({regs[rs]})'
    elif op == 0x04: d = f'beq {regs[rs]}, {regs[rt]}, 0x{ram + 4 + (simm << 2):08X}'
    elif op == 0x05: d = f'bne {regs[rs]}, {regs[rt]}, 0x{ram + 4 + (simm << 2):08X}'
    elif op == 0x02: d = f'j 0x{(ram & 0xF0000000) | (target << 2):08X}'
    elif op == 0x03: d = f'jal 0x{(ram & 0xF0000000) | (target << 2):08X}'
    elif op == 0x00:
        funct = word & 0x3F
        if funct == 0x08: d = f'jr {regs[rs]}'
        elif funct == 0x21: d = f'addu {regs[(word>>11)&0x1F]}, {regs[rs]}, {regs[rt]}'
        elif funct == 0x24: d = f'and {regs[(word>>11)&0x1F]}, {regs[rs]}, {regs[rt]}'
        elif funct == 0x25: d = f'or {regs[(word>>11)&0x1F]}, {regs[rs]}, {regs[rt]}'
        elif funct == 0x00: d = f'sll {regs[(word>>11)&0x1F]}, {regs[rt]}, {(word>>6)&0x1F}'
        else: d = f'.word 0x{word:08X}'
    elif op == 0x01: d = f'b{["ltz","gez"][rt]} {regs[rs]}, 0x{ram + 4 + (simm << 2):08X}'
    elif op == 0x0D: d = f'ori {regs[rt]}, {regs[rs]}, 0x{imm:04X}'
    elif op == 0x0C: d = f'andi {regs[rt]}, {regs[rs]}, 0x{imm:04X}'
    elif op == 0x20: d = f'lb {regs[rt]}, {simm}({regs[rs]})'
    elif op == 0x24: d = f'lbu {regs[rt]}, {simm}({regs[rs]})'
    elif op == 0x28: d = f'sb {regs[rt]}, {simm}({regs[rs]})'
    else: d = f'.word 0x{word:08X} (op={op:02X})'
    
    print(f"  0x{ram:08X}: 0x{word:08X}  {d}")

# Check what the file search function looks like around 0x8008B9CC
# (called from main init at 0x8004F404)
print(f"\n=== File Search Function (RAM 0x8008B9CC) ===")
fs_off = ram_to_off(0x8008B9CC)
for i in range(20):
    off = fs_off + i * 4
    if off + 4 > len(exe): break
    word = rd32(off)
    ram = LOAD_ADDR + off - 0x800
    op = (word >> 26) & 0x3F
    rs = (word >> 21) & 0x1F
    rt = (word >> 16) & 0x1F
    imm = word & 0xFFFF
    simm = struct.unpack('h', struct.pack('H', imm))[0]
    target = word & 0x3FFFFFF
    regs = ['zero','at','v0','v1','a0','a1','a2','a3',
            't0','t1','t2','t3','t4','t5','t6','t7',
            's0','s1','s2','s3','s4','s5','s6','s7',
            't8','t9','k0','k1','gp','sp','fp','ra']
    
    if word == 0: d = 'nop'
    elif op == 0x09: d = f'addiu {regs[rt]}, {regs[rs]}, {simm}'
    elif op == 0x0F: d = f'lui {regs[rt]}, 0x{imm:04X}'
    elif op == 0x23: d = f'lw {regs[rt]}, {simm}({regs[rs]})'
    elif op == 0x2B: d = f'sw {regs[rt]}, {simm}({regs[rs]})'
    elif op == 0x04: d = f'beq {regs[rs]}, {regs[rt]}, 0x{ram + 4 + (simm << 2):08X}'
    elif op == 0x05: d = f'bne {regs[rs]}, {regs[rt]}, 0x{ram + 4 + (simm << 2):08X}'
    elif op == 0x02: d = f'j 0x{(ram & 0xF0000000) | (target << 2):08X}'
    elif op == 0x03: d = f'jal 0x{(ram & 0xF0000000) | (target << 2):08X}'
    elif op == 0x00:
        funct = word & 0x3F
        if funct == 0x08: d = f'jr {regs[rs]}'
        elif funct == 0x21: d = f'addu {regs[(word>>11)&0x1F]}, {regs[rs]}, {regs[rt]}'
        else: d = f'.word 0x{word:08X}'
    elif op == 0x01: d = f'b{["ltz","gez"][rt]} {regs[rs]}, 0x{ram + 4 + (simm << 2):08X}'
    elif op == 0x0D: d = f'ori {regs[rt]}, {regs[rs]}, 0x{imm:04X}'
    else: d = f'.word 0x{word:08X} (op={op:02X})'
    
    print(f"  0x{ram:08X}: 0x{word:08X}  {d}")

# Check what's at 0x8004F568 (thread 1 entry from OpenTh call)
print(f"\n=== Thread 1 Entry (RAM 0x8004F568) ===")
t1_off = ram_to_off(0x8004F568)
for i in range(20):
    off = t1_off + i * 4
    if off + 4 > len(exe): break
    word = rd32(off)
    ram = LOAD_ADDR + off - 0x800
    op = (word >> 26) & 0x3F
    rs = (word >> 21) & 0x1F
    rt = (word >> 16) & 0x1F
    imm = word & 0xFFFF
    simm = struct.unpack('h', struct.pack('H', imm))[0]
    target = word & 0x3FFFFFF
    regs = ['zero','at','v0','v1','a0','a1','a2','a3',
            't0','t1','t2','t3','t4','t5','t6','t7',
            's0','s1','s2','s3','s4','s5','s6','s7',
            't8','t9','k0','k1','gp','sp','fp','ra']
    
    if word == 0: d = 'nop'
    elif op == 0x09: d = f'addiu {regs[rt]}, {regs[rs]}, {simm}'
    elif op == 0x0F: d = f'lui {regs[rt]}, 0x{imm:04X}'
    elif op == 0x23: d = f'lw {regs[rt]}, {simm}({regs[rs]})'
    elif op == 0x2B: d = f'sw {regs[rt]}, {simm}({regs[rs]})'
    elif op == 0x04: d = f'beq {regs[rs]}, {regs[rt]}, 0x{ram + 4 + (simm << 2):08X}'
    elif op == 0x05: d = f'bne {regs[rs]}, {regs[rt]}, 0x{ram + 4 + (simm << 2):08X}'
    elif op == 0x02: d = f'j 0x{(ram & 0xF0000000) | (target << 2):08X}'
    elif op == 0x03: d = f'jal 0x{(ram & 0xF0000000) | (target << 2):08X}'
    elif op == 0x00:
        funct = word & 0x3F
        if funct == 0x08: d = f'jr {regs[rs]}'
        elif funct == 0x21: d = f'addu {regs[(word>>11)&0x1F]}, {regs[rs]}, {regs[rt]}'
        else: d = f'.word 0x{word:08X}'
    elif op == 0x01: d = f'b{["ltz","gez"][rt]} {regs[rs]}, 0x{ram + 4 + (simm << 2):08X}'
    elif op == 0x0D: d = f'ori {regs[rt]}, {regs[rs]}, 0x{imm:04X}'
    else: d = f'.word 0x{word:08X} (op={op:02X})'
    
    print(f"  0x{ram:08X}: 0x{word:08X}  {d}")
