// ============================================================================
// instrumentation_bus.cpp — Live Instrumentation Bus Implementation
// ============================================================================
#include "agent_harness.h"
#include "instrumentation_bus.h"
#include "psx_test_station.h"
#include <sstream>
#include <cstring>

// Global instance
InstrumentationBus* g_instr_bus = nullptr;

// ── Minimal JSON helpers (no external dependency) ────────────────────────────

static const char* skip_ws(const char* s) {
    while (*s == ' ' || *s == '\t' || *s == '\n' || *s == '\r') s++;
    return s;
}

static const char* find_key(const char* json, const char* key) {
    char pattern[128];
    snprintf(pattern, sizeof(pattern), "\"%s\"", key);
    const char* p = strstr(json, pattern);
    if (!p) return nullptr;
    p += strlen(pattern);
    p = skip_ws(p);
    if (*p != ':') return nullptr;
    p = skip_ws(p + 1);
    return p;
}

static std::string extract_string(const char* json, const char* key) {
    const char* p = find_key(json, key);
    if (!p || *p != '"') return "";
    p++;
    const char* end = strchr(p, '"');
    if (!end) return "";
    return std::string(p, end - p);
}

static uint32_t extract_hex(const char* json, const char* key) {
    const char* p = find_key(json, key);
    if (!p) return 0;
    if (p[0] == '0' && (p[1] == 'x' || p[1] == 'X'))
        return (uint32_t)strtoul(p + 2, nullptr, 16);
    return (uint32_t)strtoul(p, nullptr, 10);
}

static uint32_t extract_uint(const char* json, const char* key) {
    const char* p = find_key(json, key);
    if (!p) return 0;
    return (uint32_t)strtoul(p, nullptr, 10);
}

static std::string extract_type(const char* json) {
    return extract_string(json, "type");
}

// ── InstrumentationBus ───────────────────────────────────────────────────────

InstrumentationBus::InstrumentationBus()
    : m_pipe(INVALID_HANDLE_VALUE), m_recv_thread(nullptr),
      m_connected(false), m_enabled(false), m_running(false),
      m_emit_interval(10000), m_last_emit_instr(0) {}

InstrumentationBus::~InstrumentationBus() {
    stop();
}

bool InstrumentationBus::start(const char* pipe_name, uint64_t emit_interval) {
    m_emit_interval = emit_interval;

    // Create named pipe (duplex: both read and write)
    m_pipe = CreateNamedPipeA(
        pipe_name,
        PIPE_ACCESS_DUPLEX,
        PIPE_TYPE_MESSAGE | PIPE_READMODE_MESSAGE | PIPE_NOWAIT,
        1,           // Max instances
        65536,       // Out buffer size
        65536,       // In buffer size
        0,           // Default timeout
        nullptr);    // Default security

    if (m_pipe == INVALID_HANDLE_VALUE) {
        fprintf(stderr, "[INSTR] Failed to create pipe: %lu\n", GetLastError());
        return false;
    }

    // Start reader thread (non-blocking, polls for incoming commands)
    m_enabled = true;
    m_running = true;
    m_recv_thread = CreateThread(nullptr, 0, recv_thread_proc, this, 0, nullptr);

    printf("[INSTR] Pipe created: %s (emit every %llu instrs)\n",
           pipe_name, (unsigned long long)emit_interval);
    printf("[INSTR] Waiting for Python sidecar to connect...\n");

    return true;
}

void InstrumentationBus::stop() {
    m_running = false;
    m_enabled = false;

    if (m_recv_thread) {
        WaitForSingleObject(m_recv_thread, 2000);
        CloseHandle(m_recv_thread);
        m_recv_thread = nullptr;
    }

    if (m_pipe != INVALID_HANDLE_VALUE) {
        CloseHandle(m_pipe);
        m_pipe = INVALID_HANDLE_VALUE;
    }
    m_connected = false;
}

// ── Emit functions ───────────────────────────────────────────────────────────

void InstrumentationBus::write_json(const char* json_str) {
    if (!m_enabled || m_pipe == INVALID_HANDLE_VALUE) return;

    std::lock_guard<std::mutex> lock(m_write_mutex);

    // Try to connect (non-blocking)
    if (!m_connected) {
        if (ConnectNamedPipe(m_pipe, nullptr) || GetLastError() == ERROR_PIPE_CONNECTED) {
            m_connected = true;
            printf("[INSTR] Python sidecar connected\n");
        } else {
            return; // No client yet
        }
    }

    DWORD written;
    const char* data = json_str;
    size_t len = strlen(data);
    // Write as message
    if (!WriteFile(m_pipe, data, (DWORD)len, &written, nullptr)) {
        // Pipe may have broken
        if (GetLastError() == ERROR_NO_DATA || GetLastError() == ERROR_BROKEN_PIPE) {
            m_connected = false;
            DisconnectNamedPipe(m_pipe);
        }
    }
}

void InstrumentationBus::format_regs(char* buf, size_t bufsize, const uint32_t regs[32]) {
    // Format key registers as JSON object
    snprintf(buf, bufsize,
        "\"v0\":\"0x%08X\",\"v1\":\"0x%08X\","
        "\"a0\":\"0x%08X\",\"a1\":\"0x%08X\",\"a2\":\"0x%08X\",\"a3\":\"0x%08X\","
        "\"t0\":\"0x%08X\",\"t1\":\"0x%08X\",\"t2\":\"0x%08X\",\"t3\":\"0x%08X\","
        "\"t4\":\"0x%08X\",\"t5\":\"0x%08X\",\"t6\":\"0x%08X\",\"t7\":\"0x%08X\","
        "\"s0\":\"0x%08X\",\"s1\":\"0x%08X\",\"s2\":\"0x%08X\",\"s3\":\"0x%08X\","
        "\"s4\":\"0x%08X\",\"s5\":\"0x%08X\",\"s6\":\"0x%08X\",\"s7\":\"0x%08X\","
        "\"t8\":\"0x%08X\",\"t9\":\"0x%08X\","
        "\"sp\":\"0x%08X\",\"fp\":\"0x%08X\",\"ra\":\"0x%08X\",\"gp\":\"0x%08X\"",
        regs[2], regs[3],
        regs[4], regs[5], regs[6], regs[7],
        regs[8], regs[9], regs[10], regs[11],
        regs[12], regs[13], regs[14], regs[15],
        regs[16], regs[17], regs[18], regs[19],
        regs[20], regs[21], regs[22], regs[23],
        regs[24], regs[25],
        regs[29], regs[30], regs[31], regs[28]);
}

void InstrumentationBus::emit_state(uint64_t instr_count, uint32_t pc,
                                     const uint32_t regs[32], uint32_t hi, uint32_t lo,
                                     uint32_t cp0_status, uint32_t vblank_count) {
    char reg_buf[1024];
    format_regs(reg_buf, sizeof(reg_buf), regs);

    char json[2048];
    snprintf(json, sizeof(json),
        "{\"type\":\"state\",\"instr\":%llu,\"pc\":\"0x%08X\",\"regs\":{%s},"
        "\"hi\":\"0x%08X\",\"lo\":\"0x%08X\",\"sr\":\"0x%08X\",\"vblank\":%llu}\n",
        (unsigned long long)instr_count, pc, reg_buf,
        hi, lo, cp0_status, (unsigned long long)vblank_count);

    write_json(json);
}

void InstrumentationBus::emit_mem_access(uint32_t addr, uint32_t value, bool is_write,
                                          uint32_t pc, uint64_t instr_count) {
    char json[512];
    snprintf(json, sizeof(json),
        "{\"type\":\"mem\",\"instr\":%llu,\"addr\":\"0x%08X\",\"value\":\"0x%08X\","
        "\"write\":%s,\"pc\":\"0x%08X\"}\n",
        (unsigned long long)instr_count, addr, value,
        is_write ? "true" : "false", pc);
    write_json(json);
}

void InstrumentationBus::emit_vfs(const char* resource, uint32_t lba, bool resolved,
                                   uint32_t pc, uint64_t instr_count) {
    char json[512];
    snprintf(json, sizeof(json),
        "{\"type\":\"vfs\",\"instr\":%llu,\"resource\":\"%s\",\"lba\":%u,"
        "\"resolved\":%s,\"pc\":\"0x%08X\"}\n",
        (unsigned long long)instr_count, resource, lba,
        resolved ? "true" : "false", pc);
    write_json(json);
}

void InstrumentationBus::emit_breakpoint_hit(uint32_t bp_addr, uint64_t instr_count,
                                              const uint32_t regs[32]) {
    char reg_buf[1024];
    format_regs(reg_buf, sizeof(reg_buf), regs);

    char json[2048];
    snprintf(json, sizeof(json),
        "{\"type\":\"bp_hit\",\"pc\":\"0x%08X\",\"instr\":%llu,\"regs\":{%s}}\n",
        bp_addr, (unsigned long long)instr_count, reg_buf);
    write_json(json);
}

void InstrumentationBus::emit_divergence(uint64_t instr_count, uint32_t pc,
                                          const char* expected, const char* actual,
                                          const char* detail, const char* severity) {
    char json[1024];
    snprintf(json, sizeof(json),
        "{\"type\":\"divergence\",\"instr\":%llu,\"pc\":\"0x%08X\","
        "\"expected\":\"%s\",\"actual\":\"%s\",\"detail\":\"%s\",\"severity\":\"%s\"}\n",
        (unsigned long long)instr_count, pc, expected, actual, detail, severity);
    write_json(json);
}

// ── Inject functions ─────────────────────────────────────────────────────────

bool InstrumentationBus::has_pending_patches() {
    std::lock_guard<std::mutex> lock(m_patch_mutex);
    return !m_pending_patches.empty();
}

PatchCommand InstrumentationBus::pop_patch() {
    std::lock_guard<std::mutex> lock(m_patch_mutex);
    PatchCommand cmd = m_pending_patches.front();
    m_pending_patches.pop();
    return cmd;
}

void InstrumentationBus::apply_patch(MIPS_CPU& cpu, PSX_Memory& mem) {
    if (!has_pending_patches()) return;
    PatchCommand cmd = pop_patch();

    switch (cmd.type) {
        case PatchCommand::WRITE_MEM: {
            // Save original for rollback
            uint32_t orig = 0;
            for (uint32_t i = 0; i < cmd.size && i < 4; i++) {
                orig |= (mem.ram[cmd.addr & 0x1FFFFF + i] & 0xFF) << (i * 8);
            }
            m_mem_history.push_back({cmd.addr, orig, cmd.size});

            // Write new value to RAM (mask to 2MB)
            uint32_t ram_offset = cmd.addr & 0x1FFFFF;
            for (uint32_t i = 0; i < cmd.size; i++) {
                mem.ram[ram_offset + i] = (cmd.value >> (i * 8)) & 0xFF;
            }
            printf("[INJECT] WRITE_MEM 0x%08X = 0x%08X (%u bytes) — %s\n",
                   cmd.addr, cmd.value, cmd.size, cmd.description);
            break;
        }

        case PatchCommand::WRITE_REG: {
            int reg = (int)cmd.addr;
            if (reg >= 0 && reg < 32) {
                m_reg_history.push_back({reg, cpu.regs[reg]});
                cpu.regs[reg] = cmd.value;
                printf("[INJECT] WRITE_REG $%d = 0x%08X — %s\n",
                       reg, cmd.value, cmd.description);
            }
            break;
        }

        case PatchCommand::SET_PC: {
            cpu.pc = cmd.addr;
            cpu.next_pc = cmd.addr + 4;
            cpu.pending_branch = false;
            cpu.in_branch_delay = false;
            printf("[INJECT] SET_PC 0x%08X — %s\n", cmd.addr, cmd.description);
            break;
        }

        case PatchCommand::SET_BREAKPOINT: {
            if (cpu.bp_count < (int)(sizeof(cpu.breakpoints)/sizeof(cpu.breakpoints[0]))) {
                cpu.breakpoints[cpu.bp_count++] = cmd.addr;
                printf("[INJECT] SET_BREAKPOINT 0x%08X — %s\n",
                       cmd.addr, cmd.description);
            }
            break;
        }

        case PatchCommand::DUMP_REGION: {
            printf("[INJECT] DUMP_REGION 0x%08X +%u bytes — %s\n",
                   cmd.addr, cmd.size, cmd.description);
            // Emit memory contents back through the pipe
            uint32_t ram_offset = cmd.addr & 0x1FFFFF;
            for (uint32_t i = 0; i < cmd.size; i += 4) {
                if (ram_offset + i + 4 <= PSX_Memory::RAM_SIZE) {
                    uint32_t val = *(uint32_t*)(mem.ram + ram_offset + i);
                    emit_mem_access(cmd.addr + i, val, false, cpu.pc, cpu.instructions);
                }
            }
            break;
        }

        case PatchCommand::ROLLBACK: {
            // Restore all patched memory
            for (const auto& h : m_mem_history) {
                uint32_t ram_offset = h.addr & 0x1FFFFF;
                for (uint32_t i = 0; i < h.size; i++) {
                    mem.ram[ram_offset + i] = (h.original_value >> (i * 8)) & 0xFF;
                }
            }
            // Restore all patched registers
            for (const auto& r : m_reg_history) {
                cpu.regs[r.reg_idx] = r.original_value;
            }
            printf("[INJECT] ROLLBACK: restored %zu mem patches, %zu reg patches — %s\n",
                   m_mem_history.size(), m_reg_history.size(), cmd.description);
            m_mem_history.clear();
            m_reg_history.clear();
            break;
        }

        default:
            printf("[INJECT] Unknown command type %d\n", (int)cmd.type);
            break;
    }
}

// ── Tick (called from emulator main loop) ────────────────────────────────────

void InstrumentationBus::tick(uint64_t instr_count, uint32_t pc,
                               MIPS_CPU& cpu, PSX_Memory& mem) {
    if (!m_enabled) return;

    // Emit state at interval
    if (instr_count - m_last_emit_instr >= m_emit_interval) {
        m_last_emit_instr = instr_count;
        emit_state(instr_count, pc, cpu.regs, cpu.hi, cpu.lo,
                   cpu.cp0_status, cpu.vblank_timer);
    }

    // Apply any pending patches
    while (has_pending_patches()) {
        apply_patch(cpu, mem);
    }
}

void InstrumentationBus::on_breakpoint(uint32_t bp_addr, uint64_t instr_count,
                                        MIPS_CPU& cpu, PSX_Memory& mem) {
    if (!m_enabled) return;

    // Emit breakpoint hit with full register state
    emit_breakpoint_hit(bp_addr, instr_count, cpu.regs);

    // Apply any pending patches that were queued while paused
    while (has_pending_patches()) {
        apply_patch(cpu, mem);
    }
}

// ── Reader thread (receives commands from Python) ────────────────────────────

DWORD WINAPI InstrumentationBus::recv_thread_proc(LPVOID param) {
    InstrumentationBus* self = (InstrumentationBus*)param;
    self->recv_loop();
    return 0;
}

void InstrumentationBus::recv_loop() {
    char buf[4096];

    while (m_running) {
        if (!m_connected || m_pipe == INVALID_HANDLE_VALUE) {
            Sleep(100);
            continue;
        }

        // Non-blocking read (pipe is in NOWAIT mode)
        DWORD bytes_read = 0;
        BOOL ok = ReadFile(m_pipe, buf, sizeof(buf) - 1, &bytes_read, nullptr);

        if (ok && bytes_read > 0) {
            buf[bytes_read] = '\0';
            // May contain multiple newline-delimited commands
            char* line = buf;
            char* newline;
            while ((newline = strchr(line, '\n')) != nullptr) {
                *newline = '\0';
                if (*line) parse_command(line);
                line = newline + 1;
            }
            // Handle last line without newline
            if (*line) parse_command(line);
        } else {
            DWORD err = GetLastError();
            if (err == ERROR_NO_DATA) {
                // No data available (non-blocking) — just wait
                Sleep(10);
            } else if (err == ERROR_BROKEN_PIPE || err == ERROR_PIPE_NOT_CONNECTED) {
                m_connected = false;
                Sleep(100);
            }
        }
    }
}

void InstrumentationBus::parse_command(const char* json_str) {
    std::string type = extract_type(json_str);
    if (type.empty()) return;

    PatchCommand cmd = {};
    cmd.size = 4; // Default

    if (type == "WRITE_MEM") {
        cmd.type = PatchCommand::WRITE_MEM;
        cmd.addr = extract_hex(json_str, "addr");
        cmd.value = extract_hex(json_str, "value");
        cmd.size = extract_uint(json_str, "size");
        if (cmd.size == 0) cmd.size = 4;
    } else if (type == "WRITE_REG") {
        cmd.type = PatchCommand::WRITE_REG;
        cmd.addr = extract_uint(json_str, "addr"); // Register index
        cmd.value = extract_hex(json_str, "value");
    } else if (type == "SET_PC") {
        cmd.type = PatchCommand::SET_PC;
        cmd.addr = extract_hex(json_str, "addr");
    } else if (type == "SET_BREAKPOINT") {
        cmd.type = PatchCommand::SET_BREAKPOINT;
        cmd.addr = extract_hex(json_str, "addr");
    } else if (type == "DUMP_REGION") {
        cmd.type = PatchCommand::DUMP_REGION;
        cmd.addr = extract_hex(json_str, "addr");
        cmd.size = extract_uint(json_str, "size");
    } else if (type == "ROLLBACK") {
        cmd.type = PatchCommand::ROLLBACK;
    } else {
        return; // Unknown command
    }

    // Extract description
    std::string desc = extract_string(json_str, "description");
    strncpy(cmd.description, desc.c_str(), sizeof(cmd.description) - 1);
    cmd.description[sizeof(cmd.description) - 1] = '\0';

    // Queue the command
    {
        std::lock_guard<std::mutex> lock(m_patch_mutex);
        m_pending_patches.push(cmd);
    }

    printf("[INSTR] Received command: %s — %s\n", type.c_str(), cmd.description);
}
