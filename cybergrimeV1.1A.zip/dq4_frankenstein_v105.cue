FILE "dq4_frankenstein_v105.bin" BINARY
  TRACK 01 MODE2/2352
    INDEX 01 00:00:00
