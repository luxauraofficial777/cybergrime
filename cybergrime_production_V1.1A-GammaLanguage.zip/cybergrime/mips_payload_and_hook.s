# MIPS Assembly: Boot-Time Payload Loader + Post-Decompression RAM Hook
# Dragon Quest IV PSX Translation Project
# Assembled: July 10, 2026
#
# This file documents the complete MIPS assembly for three components:
# 1. Boot-time payload loader at EXE offset 0x3300 (RAM 0x8001B200)
# 2. Post-decompression RAM hook at RAM 0x800B4A68 (240 bytes)
# 3. JAL patch verification at EXE offset 0x5A600 (RAM 0x80072500)
#
# =============================================================================
# COMPONENT 1: BOOT-TIME PAYLOAD LOADER
# =============================================================================
# Load address: EXE offset 0x3300 = RAM 0x8001B200
# (DW7 EXE load addr = 0x80017F00, so 0x80017F00 + 0x3300 = 0x8001B200)
#
# Purpose:
#   Runs at boot before the game's main entry point. Opens the CD-ROM device,
#   seeks to LBA 156330, reads the translation payload (TXRT format) into
#   RAM 0x801F0000, then jumps to the original EXE entry point.
#
# BIOS A-table calls used:
#   A:0x00 = open(path, mode)       -> returns fd in $v0
#   A:0x01 = lseek(fd, offset, whence) -> returns new position in $v0
#   A:0x02 = read(fd, buf, nbytes)  -> returns bytes read in $v0
#
# PSX BIOS call convention:
#   $t1 = function number
#   $a0-$a3 = arguments
#   jal $0xA0 (table A), $0xB0 (table B), $0xC0 (table C)
#   Return value in $v0
#
# Payload format at 0x801F0000:
#   [0x00] uint32 magic = 0x54525845 ("TXRT" in little-endian)
#   [0x04] uint32 block_count
#   [0x08] uint32 payload_size (total size including header)
#   [0x0C] uint32 flags
#   [0x10] block_entry[0]: {uint16 block_id, uint16 seq_count, uint32 data_offset, uint32 data_size}
#   [0x1C] block_entry[1]: ...
#   ...   block_entry[N-1]
#   [data_offset] block data (raw 2-byte char codes)
#
# Size budget: 256 bytes max (EXE offset 0x3300-0x33FF is a NOP slide region)
# Actual size: 204 bytes = 51 instructions

.set noreorder

# Register usage:
#   $s0 = fd (file descriptor)
#   $s1 = bytes_read / status
#   $s2 = original entry point (hardcoded via lui/addiu, patched at build time)
#   $sp = stack pointer (must preserve)
#   $t2 = scratch for string construction

# --- Entry: save registers (32-byte frame) ---
loader_start:
    addiu   $sp, $sp, -32          # 0x27BDFFE0  allocate 32-byte stack frame
    sw      $ra, 28($sp)           # 0xAFBF001C  save return address
    sw      $s0, 24($sp)           # 0xAFB00018  save $s0
    sw      $s1, 20($sp)           # 0xAFB10014  save $s1
    sw      $s2, 16($sp)           # 0xAFB20010  save $s2

# --- Load original entry point (hardcoded, patched by build_hook_iso.py) ---
# The original EXE entry point is encoded as lui $s2, HI; addiu $s2, $s2, LO.
# build_hook_iso.py reads the original PC from the EXE header before
# overwriting it, then patches these two immediate fields.
# Default value: 0x80017F00 (DW7 entry point).
    lui     $s2, 0x8001            # 0x3C128001  $s2 = 0x80010000 (HI)
    addiu   $s2, $s2, 0x7F00       # 0x26527F00  $s2 = 0x80017F00 (LO)

# --- Build "cdrom:\0" string at $sp+0 (within 32-byte frame) ---
# PSX BIOS open() expects a null-terminated string pointer in $a0.
# "cdrom:" = 63 64 72 6F 6D 3A 00
# We construct it in little-endian within the allocated stack frame.
# Word at $sp+0: 0x6F726463 = "cdro" in LE (bytes: 63 64 72 6F)
# Halfword at $sp+4: 0x3A6D = "m:" in LE (bytes: 6D 3A)
# Byte at $sp+6: 0x00 = null terminator
    lui     $t2, 0x6F72            # 0x3C0A6F72  $t2 = 0x6F720000 ('ro' upper)
    ori     $t2, $t2, 0x6463       # 0x354A6463  $t2 = 0x6F726463 ('cd' lower)
    sw      $t2, 0($sp)            # 0xAFAA0000  store "cdro" at $sp+0
    addiu   $t2, $zero, 0x3A6D     # 0x240A3A6D  $t2 = 0x3A6D ('m:' in LE)
    sh      $t2, 4($sp)            # 0xA7AA0004  store "m:" at $sp+4
    sb      $zero, 6($sp)          # 0xA3A00006  null terminator at $sp+6

# BIOS A:0x00 open(path=$a0, mode=$a1)
    addiu   $a0, $sp, 0            # 0x27A40000  $a0 = path pointer ($sp+0)
    addiu   $a1, $zero, 0          # 0x24050000  $a1 = 0 (readonly)
    addiu   $t1, $zero, 0x00       # 0x24090000  $t1 = 0 (open function)
    jal     0x000000A0             # 0x0C000028  call BIOS A table
    nop                             # 0x00000000  delay slot

# Check if open succeeded ($v0 >= 0)
    slt     $t0, $zero, $v0        # 0x0002002A  $t0 = ($v0 > 0) ? 1 : 0
    beq     $t0, $zero, loader_done  # 0x11000016  if fd <= 0, skip to cleanup (22 words)
    nop                             # 0x00000000
    or      $s0, $v0, $zero        # 0x00028025  $s0 = fd

# --- Seek to LBA 156330 ---
# LBA 156330 = 0x0002632A
# BIOS A:0x01 lseek(fd=$a0, offset=$a1, whence=$a2)
# whence = 0 (SEEK_SET from beginning)
# Note: PSX BIOS lseek offset is in bytes. LBA * 2048 = byte offset.
# 156330 * 2048 = 320,030,400 = 0x1315_9500
# Actually, PSX BIOS CD-ROM lseek uses sector (LBA) units, not bytes.
# The emulator's lseek implementation adds offset to fd->offset directly.
# We need to check: does the emulator treat offset as sectors or bytes?
# From psx_emulator_core.cpp case 0x01: fd->offset += offset (raw addition)
# And cd_read reads from fd->offset * 2048. So offset is in SECTORS.
# Therefore: offset = 156330 = 0x0002632A

    or      $a0, $s0, $zero        # 0x02002025  $a0 = fd
    lui     $a1, 0x0002            # 0x3C050002  $a1 = 0x00020000
    addiu   $a1, $a1, 0x632A       # 0x24A5632A  $a1 = 0x0002632A (LBA 156330)
    addiu   $a2, $zero, 0          # 0x24060000  $a2 = 0 (SEEK_SET)
    addiu   $t1, $zero, 0x01       # 0x24090001  $t1 = 1 (lseek function)
    jal     0x000000A0             # 0x0C000028  call BIOS A table
    nop                             # 0x00000000

# --- Read payload into RAM 0x801F0000 ---
# BIOS A:0x02 read(fd=$a0, buf=$a1, nbytes=$a2)
# We read up to 65536 bytes (32 sectors worth, enough for test payload)
# Production payload may be larger; adjust $a2 accordingly.
    or      $a0, $s0, $zero        # 0x02002025  $a0 = fd
    lui     $a1, 0x801F            # 0x3C05801F  $a1 = 0x801F0000
    addiu   $a1, $a1, 0x0000       # 0x24A50000  $a1 = 0x801F0000 (dest)
    lui     $a2, 0x0001            # 0x3C060001  $a2 = 0x00010000
    addiu   $a2, $a2, 0x0000       # 0x24C60000  $a2 = 65536 bytes
    addiu   $t1, $zero, 0x02       # 0x24090002  $t1 = 2 (read function)
    jal     0x000000A0             # 0x0C000028  call BIOS A table
    nop                             # 0x00000000

    or      $s1, $v0, $zero        # 0x00028825  $s1 = bytes read

# --- Close CD-ROM device (optional, but clean) ---
# BIOS A:0x06 close(fd=$a0)
    or      $a0, $s0, $zero        # 0x02002025  $a0 = fd
    addiu   $t1, $zero, 0x06       # 0x24090006  $t1 = 6 (close function)
    jal     0x000000A0             # 0x0C000028  call BIOS A table
    nop                             # 0x00000000

# --- Jump to original EXE entry point ---
loader_done:                        # RAM 0x8001B2A8 (offset 0xA8 from loader_start)
    lw      $ra, 28($sp)           # 0x8FBF001C  restore $ra
    lw      $s0, 24($sp)           # 0x8FB00018  restore $s0
    lw      $s1, 20($sp)           # 0x8FB10014  restore $s1
    lw      $s2, 16($sp)           # 0x8FB20010  restore $s2
    addiu   $sp, $sp, 32           # 0x27BD0020  restore $sp
    jr      $s2                    # 0x02500008  jump to original entry
    nop                             # 0x00000000  delay slot

# --- Error path: payload load failed, continue without payload ---
# The hook at 0x800B4A68 will check for TXRT magic and skip if absent.
loader_fail:                        # RAM 0x8001B2C4 (offset 0xC4 from loader_start)
    j       loader_done            # 0x08006CAA  jump to cleanup (0x8001B2A8)
    nop                             # 0x00000000  delay slot

# =============================================================================
# COMPONENT 2: POST-DECOMPRESSION RAM HOOK (240 bytes)
# =============================================================================
# Load address: RAM 0x800B4A68 (EXE offset 0x9B168, in a NOP slide region)
# Size: 240 bytes = 60 instructions (0xF0 bytes)
#
# Purpose:
#   Called via JAL from the decompression return point at 0x80072500.
#   After the Huffman decompressor finishes writing text to the output buffer,
#   this hook:
#   1. Saves all registers that could be clobbered (including $t0-$t3)
#   2. Checks for TXRT magic at 0x801F0000
#   3. If found, looks up the current block ID in the payload's block table
#   4. Copies translated text over the decompression output buffer
#   5. Restores all registers
#   6. Executes the original replaced instruction
#   7. Jumps back to the instruction after the hook point
#
# Register preservation:
#   Saved: $ra, $v0, $a0, $a1, $t0, $t1, $t2, $t3, $t8, $t9 (10 regs on stack)
#   48-byte stack frame (10 regs * 4 bytes + 8 bytes padding)
#   $a0 = output buffer pointer (decompressed text destination)
#   $a1 = block ID (used for payload lookup)
#
# The original instruction at the hook point (0x80072500) is:
#   lui $v0, 0x00FF  (0x3C0200FF)
# This instruction sets $v0 = 0x00FF0000, which is used as a bitmask later.
# The hook must execute this instruction before returning.

.set HOOK_BASE, 0x800B4A68

hook_start:
# --- Save registers (12 instructions, 0x00-0x2C) ---
    addiu   $sp, $sp, -48          # 0x27BDFFD0  [0x00] allocate 48 bytes
    sw      $ra, 44($sp)           # 0xAFBF002C  [0x04] save $ra
    sw      $v0, 40($sp)           # 0xAFA20028  [0x08] save $v0
    sw      $a0, 36($sp)           # 0xAFA40024  [0x0C] save $a0 (output buf)
    sw      $a1, 32($sp)           # 0xAFA50020  [0x10] save $a1 (block ID)
    sw      $t0, 28($sp)           # 0xAFA8001C  [0x14] save $t0
    sw      $t1, 24($sp)           # 0xAFA90018  [0x18] save $t1
    sw      $t2, 20($sp)           # 0xAFAA0014  [0x1C] save $t2
    sw      $t3, 16($sp)           # 0xAFAB0010  [0x20] save $t3
    sw      $t8, 12($sp)           # 0xAFB8000C  [0x24] save $t8
    sw      $t9, 8($sp)            # 0xAFB90008  [0x28] save $t9
    or      $t8, $a0, $zero        # 0x01004025  [0x2C] $t8 = output buf ptr

# --- Check TXRT magic (6 instructions, 0x30-0x44) ---
    lui     $t9, 0x801F            # 0x3C19801F  [0x30] $t9 = 0x801F0000
    ori     $t9, $t9, 0x0000       # 0x33290000  [0x34] (payload base)
    lw      $t0, 0($t9)            # 0x8F280000  [0x38] $t0 = payload[0] (magic)
    lui     $t1, 0x5452            # 0x3C095452  [0x3C] $t1 = 'TR' << 16
    ori     $t1, $t1, 0x5845       # 0x35295845  [0x40] $t1 = 0x54525845 (TXRT)
    bne     $t0, $t1, hook_exit    # 0x1510001C  [0x44] if no payload, skip (28 words)
    nop                             # 0x00000000  [0x48] delay slot

# --- Block-ID lookup (3 instructions, 0x4C-0x54) ---
# TXRT header is 16 bytes: magic(4) + count(4) + size(4) + flags(4)
# Block entry is 12 bytes: block_id(2) + seq_count(2) + data_offset(4) + data_size(4)
    lw      $t1, 32($sp)           # 0x8FA90020  [0x4C] $t1 = block ID (from $a1)
    lw      $t2, 4($t9)            # 0x8F2A0004  [0x50] $t2 = block_count
    addiu   $t3, $t9, 16           # 0x27AB0010  [0x54] $t3 = &block_table[0] (16-byte header)

block_search_loop:                 # [0x58]
    beq     $t2, $zero, hook_exit  # 0x11400017  [0x58] if no more blocks, exit (23 words)
    nop                             # 0x00000000  [0x5C] delay slot
    lhu     $t0, 0($t3)            # 0x95280000  [0x60] $t0 = entry.block_id (16-bit)
    bne     $t0, $t1, next_block   # 0x15000006  [0x64] if not matching, next (6 words)
    nop                             # 0x00000000  [0x68] delay slot

# --- Found matching block: get offset and size ---
# Entry layout: [0:2]=block_id, [2:4]=seq_count, [4:8]=data_offset, [8:12]=data_size
    lw      $t0, 4($t3)            # 0x8F280004  [0x6C] $t0 = entry.data_offset
    addu    $t9, $t9, $t0          # 0x0328C821  [0x70] $t9 = payload_base + offset
    lw      $t2, 8($t3)            # 0x8F2A0008  [0x74] $t2 = entry.data_size
    j       copy_start             # 0x08002D2A  [0x78] jump to copy loop
    nop                             # 0x00000000  [0x7C] delay slot

# --- Next block entry ---
next_block:                        # [0x80]
    addiu   $t3, $t3, 12           # 0x276B000C  [0x80] advance to next entry
    addiu   $t2, $t2, -1           # 0x254AFFFF  [0x84] decrement counter
    j       block_search_loop      # 0x08002D16  [0x88] loop back
    nop                             # 0x00000000  [0x8C] delay slot

# --- Copy translated text over decompression output ---
copy_start:                        # [0x90]
    srl     $t2, $t2, 2            # 0x000A1082  [0x90] $t2 = word count (size/4)
    beq     $t2, $zero, hook_exit  # 0x11400008  [0x94] if zero, skip copy (8 words)
    nop                             # 0x00000000  [0x98] delay slot

copy_loop:                         # [0x9C]
    lw      $t0, 0($t9)            # 0x8F280000  [0x9C] load word from payload
    sw      $t0, 0($t8)            # 0xAF280000  [0xA0] store to output buffer
    addiu   $t9, $t9, 4            # 0x27290004  [0xA4] advance payload ptr
    addiu   $t8, $t8, 4            # 0x27180004  [0xA8] advance output ptr
    addiu   $t2, $t2, -1           # 0x254AFFFF  [0xAC] decrement word count
    bne     $t2, $zero, copy_loop  # 0x1540FFFA  [0xB0] if more, loop (-6 words)
    nop                             # 0x00000000  [0xB4] delay slot

# --- Restore registers and return (16 instructions, 0xB8-0xEC) ---
hook_exit:                         # [0xB8]
    lw      $ra, 44($sp)           # 0x8FBF002C  [0xB8] restore $ra
    lw      $v0, 40($sp)           # 0x8FA20028  [0xBC] restore $v0
    lw      $a0, 36($sp)           # 0x8FA40024  [0xC0] restore $a0
    lw      $a1, 32($sp)           # 0x8FA50020  [0xC4] restore $a1
    lw      $t0, 28($sp)           # 0x8FA8001C  [0xC8] restore $t0
    lw      $t1, 24($sp)           # 0x8FA90018  [0xCC] restore $t1
    lw      $t2, 20($sp)           # 0x8FAA0014  [0xD0] restore $t2
    lw      $t3, 16($sp)           # 0x8FAB0010  [0xD4] restore $t3
    lw      $t8, 12($sp)           # 0x8FB8000C  [0xD8] restore $t8
    lw      $t9, 8($sp)            # 0x8FB90008  [0xDC] restore $t9
    addiu   $sp, $sp, 48           # 0x27BD0030  [0xE0] restore $sp
    lui     $v0, 0x00FF            # 0x3C0200FF  [0xE4] execute original instr
    j       0x80072504             # 0x08001C94  [0xE8] jump to hook_point + 4
    nop                             # 0x00000000  [0xEC] delay slot

# Total: 60 instructions = 240 bytes (0xF0)
# Fits within the 256-byte NOP slide region.

# =============================================================================
# COMPONENT 3: JAL PATCH VERIFICATION
# =============================================================================
# Patch point: EXE offset 0x5A600 = RAM 0x80072500
#
# Original instruction at patch point:
#   0x3C0200FF = lui $v0, 0x00FF
#
# This instruction loads 0x00FF0000 into $v0, which is used as a bitmask
# in the decompression return path. The value is used to mask the high byte
# of decompressed character data.
#
# Replacement instruction:
#   JAL 0x800B4A68 = 0x0C006D2A
#
# JAL encoding: 0x0C000000 | (target >> 2 & 0x3FFFFFF)
#   target = 0x800B4A68
#   target >> 2 = 0x2002D29A
#   & 0x3FFFFFF = 0x002D29A
#   0x0C000000 | 0x002D29A = 0x0C002D2A
#
# Wait - let me recalculate:
#   0x800B4A68 >> 2 = 0x2002D29A
#   0x2002D29A & 0x03FFFFFF = 0x0002D29A
#   0x0C000000 | 0x0002D29A = 0x0C002D2A
#
# The hook_patch_spec.json says patch_bytes = "9AD2020C"
# In little-endian that's 0x0C02D29A
# Let me recheck: 0x800B4A68 >> 2 = 0x2002D29A
# 0x2002D29A & 0x03FFFFFF = 0x0002D29A
# 0x0C000000 | 0x0002D29A = 0x0C02D29A
# In little-endian bytes: 9A D2 02 0C
# This matches the spec. The correct JAL encoding is 0x0C02D29A.
#
# Safety analysis:
# 1. The original instruction (lui $v0, 0x00FF) is NOT in a branch delay slot.
#    It's at the start of a basic block following a JAL return.
# 2. The hook executes the original instruction at 0xE4 before returning.
# 3. The hook jumps to 0x80072504 (hook_point + 4), so execution continues
#    normally after the replaced instruction.
# 4. $v0 is saved and restored by the hook, so the lui $v0, 0x00FF at 0xE4
#    correctly sets $v0 before the return.
# 5. The JAL sets $ra = 0x80072504 (return to instruction after JAL).
#    But the hook doesn't use $ra to return — it uses j (jump) to 0x80072504.
#    The hook saves and restores $ra, so the caller's $ra is preserved.
# 6. $t0-$t3 are now saved and restored, ensuring total transparency against
#    any decompressor register usage (future-proofing).
#
# VERDICT: The patch is SAFE. The JAL replaces a non-critical instruction
# that is safely replayed inside the hook. Register state is fully preserved.
#
# =============================================================================
# HEX DUMP SUMMARY
# =============================================================================
#
# Boot loader (at EXE offset 0x3300, instruction words):
#   27BDFFE0  AFBF001C  AFB00018  AFB10014
#   AFB20010  3C128001  26527F00  3C0A6F72
#   354A6463  AFAA0000  240A3A6D  A7AA0004
#   A3A00006  27A40000  24050000  24090000
#   0C000028  00000000  0002002A  11000016
#   00000000  00028025  02002025  3C050002
#   24A5632A  24060000  24090001  0C000028
#   00000000  02002025  3C05801F  24A50000
#   3C060001  24C60000  24090002  0C000028
#   00000000  00028825  02002025  24090006
#   0C000028  00000000  8FBF001C  8FB00018
#   8FB10014  8FB20010  27BD0020  02500008
#   00000000  08006CAA  00000000
# (Stored in little-endian byte order in the EXE)
#
# Hook code (at EXE offset 0x9B168 / RAM 0x800B4A68):
#   See hook_patch_spec.json patch_bytes field for the exact hex.
#
# JAL patch (at EXE offset 0x5A600):
#   Original: FF 00 02 3C  (lui $v0, 0x00FF in LE)
#   Patch:    9A D2 02 0C  (JAL 0x800B4A68 in LE)
