#!/usr/bin/env python3
"""
Focused disassembly of the full CD-ROM function in DW7 EXE.
Disassemble 0x80098500-0x80098980 to find function boundaries and the Setloc call chain.
Also search for JAL calls to the CD-ROM function area.
"""

import struct
from capstone import Cs, CS_ARCH_MIPS, CS_MODE_MIPS32, CS_MODE_LITTLE_ENDIAN

EXE_PATH = r"c:\LuxAura\VoidWalkers_Project\DQLOSTTRANSLATION\translation\SLUSP012.06"
LOAD_ADDR = 0x80017F00
HEADER_SIZE = 0x800

def load_exe(path):
    with open(path, "rb") as f:
        return f.read()

def ram_to_offset(ram_addr):
    return (ram_addr - LOAD_ADDR) + HEADER_SIZE

def disasm_range(data, start_ram, end_ram, label=""):
    md = Cs(CS_ARCH_MIPS, CS_MODE_MIPS32 | CS_MODE_LITTLE_ENDIAN)
    md.detail = True
    
    start_off = ram_to_offset(start_ram)
    end_off = ram_to_offset(end_ram)
    
    if start_off < 0 or end_off > len(data) or start_off >= end_off:
        print(f"  [!] Invalid range: {start_ram:#010x}-{end_ram:#010x}")
        return
    
    code = data[start_off:end_off]
    print(f"\n{'='*70}")
    print(f"  {label}: 0x{start_ram:08X} - 0x{end_ram:08X}")
    print(f"{'='*70}")
    
    for insn in md.disasm(code, start_ram):
        # Annotate interesting instructions
        annotation = ""
        if insn.mnemonic == "jal":
            annotation = "  <== JAL"
        elif insn.mnemonic == "jr" and "$ra" in insn.op_str:
            annotation = "  <== RETURN"
        elif insn.mnemonic == "addiu" and "$sp" in insn.op_str and "-" in insn.op_str:
            annotation = "  <== PROLOGUE"
        elif insn.mnemonic == "sb" and "0x1f80" in insn.op_str.lower():
            annotation = "  <== CDROM REG WRITE"
        elif insn.mnemonic == "lbu" and "$a0" in insn.op_str:
            annotation = "  <== READ FROM A0 BUFFER"
        print(f"  0x{insn.address:08X}:  {insn.mnemonic:<8s} {insn.op_str}{annotation}")

def search_jal_to_range(data, target_start, target_end):
    """Find all JAL instructions targeting addresses in a range."""
    results = []
    for i in range(HEADER_SIZE, len(data) - 4, 4):
        word = struct.unpack("<I", data[i:i+4])[0]
        op = (word >> 26) & 0x3F
        if op == 0x03:  # JAL
            target = (word & 0x03FFFFFF) << 2
            caller_ram = (i - HEADER_SIZE) + LOAD_ADDR
            target_full = (caller_ram & 0xF0000000) | target
            if target_start <= target_full <= target_end:
                results.append((caller_ram, target_full))
    return results

def search_branch_to(data, target_ram):
    """Find branches (BNE, BEQ, BGEZ, etc.) targeting a specific address."""
    results = []
    for i in range(HEADER_SIZE, len(data) - 4, 4):
        word = struct.unpack("<I", data[i:i+4])[0]
        op = (word >> 26) & 0x3F
        caller_ram = (i - HEADER_SIZE) + LOAD_ADDR
        
        # Conditional branches (BEQ, BNE, BLEZ, BGTZ, etc.)
        if op in (0x04, 0x05, 0x06, 0x07):  # BEQ, BNE, BLEZ, BGTZ
            offset = word & 0xFFFF
            if offset & 0x8000:
                offset -= 0x10000
            branch_target = caller_ram + 4 + (offset << 2)
            if branch_target == target_ram:
                results.append((caller_ram, branch_target, f"branch op={op:02x}"))
        
        # J instruction
        if op == 0x02:
            target = (word & 0x03FFFFFF) << 2
            target_full = (caller_ram & 0xF0000000) | target
            if target_full == target_ram:
                results.append((caller_ram, target_full, "j"))
    
    return results

def main():
    data = load_exe(EXE_PATH)
    
    # 1. Disassemble the full CD-ROM function area
    disasm_range(data, 0x80098500, 0x80098700, "CD-ROM dispatch area (before intercept point)")
    disasm_range(data, 0x80098700, 0x80098980, "CD-ROM Setloc function (after intercept point)")
    
    # 2. Search for JAL to 0x800988C0 area (Setloc command writer)
    print(f"\n{'='*70}")
    print(f"  Searching for JAL to 0x800988C0-0x800988FF")
    print(f"{'='*70}")
    callers = search_jal_to_range(data, 0x800988C0, 0x800988FF)
    for caller, target in callers:
        print(f"  0x{caller:08X} -> JAL 0x{target:08X}")
    if not callers:
        print("  (none found)")
    
    # 3. Search for JAL to the broader CD-ROM function area
    print(f"\n{'='*70}")
    print(f"  Searching for JAL to 0x80098600-0x80098900")
    print(f"{'='*70}")
    callers = search_jal_to_range(data, 0x80098600, 0x80098900)
    for caller, target in callers:
        print(f"  0x{caller:08X} -> JAL 0x{target:08X}")
    if not callers:
        print("  (none found)")
    
    # 4. Search for branches to 0x800988C0
    print(f"\n{'='*70}")
    print(f"  Searching for branches/jumps to 0x800988C0")
    print(f"{'='*70}")
    branches = search_branch_to(data, 0x800988C0)
    for caller, target, btype in branches:
        print(f"  0x{caller:08X} -> {btype} 0x{target:08X}")
    if not branches:
        print("  (none found)")
    
    # 5. Search for branches to 0x80098664 (intercept point)
    print(f"\n{'='*70}")
    print(f"  Searching for branches/jumps to 0x80098664")
    print(f"{'='*70}")
    branches = search_branch_to(data, 0x80098664)
    for caller, target, btype in branches:
        print(f"  0x{caller:08X} -> {btype} 0x{target:08X}")
    if not branches:
        print("  (none found)")
    
    # 6. Look at the data pointers used by the Setloc function
    # 0x800B6784, 0x800B678C, 0x800B6790 — these hold pointers to CD-ROM registers
    print(f"\n{'='*70}")
    print(f"  Data at 0x800B6784, 0x800B678C, 0x800B6790 (CD-ROM register pointers)")
    print(f"{'='*70}")
    for ram in [0x800B6784, 0x800B678C, 0x800B6790]:
        off = ram_to_offset(ram)
        if off + 4 <= len(data):
            val = struct.unpack("<I", data[off:off+4])[0]
            print(f"  0x{ram:08X}: 0x{val:08X}")
        else:
            print(f"  0x{ram:08X}: beyond EXE data")
    
    # 7. Disassemble around 0x80098664 more carefully (the intercept point)
    disasm_range(data, 0x80098620, 0x800986A0, "Intercept point context (0x80098664)")
    
    # 8. Search for all sb instructions writing to 0x1F801800 area
    # Look for lui $reg, 0x1F80 followed by sb $reg2, offset($reg)
    print(f"\n{'='*70}")
    print(f"  Searching for lui $reg, 0x1F80 (CD-ROM register base setup)")
    print(f"{'='*70}")
    for i in range(HEADER_SIZE, len(data) - 4, 4):
        word = struct.unpack("<I", data[i:i+4])[0]
        op = (word >> 26) & 0x3F
        if op == 0x0F:  # lui
            imm = word & 0xFFFF
            rt = (word >> 16) & 0x1F
            if imm == 0x1F80:
                ram = (i - HEADER_SIZE) + LOAD_ADDR
                # Look at next few instructions for sb
                for j in range(1, 5):
                    if i + j*4 + 4 <= len(data):
                        next_word = struct.unpack("<I", data[i+j*4:i+j*4+4])[0]
                        next_op = (next_word >> 26) & 0x3F
                        if next_op == 0x28:  # sb
                            next_rt = (next_word >> 16) & 0x1F
                            next_base = (next_word >> 21) & 0x1F
                            next_off = next_word & 0xFFFF
                            if next_off & 0x8000:
                                next_off -= 0x10000
                            next_ram = (i+j*4 - HEADER_SIZE) + LOAD_ADDR
                            print(f"  0x{ram:08X}: lui ${rt}, 0x1F80  ->  0x{next_ram:08X}: sb ${next_rt}, {next_off}(${next_base})")

if __name__ == "__main__":
    main()
