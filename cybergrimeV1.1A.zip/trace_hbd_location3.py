#!/usr/bin/env python3
"""Search for indirect access to the LBA table and BIOS call mechanism."""
import struct

exe_path = r'..\translation\SLUSP012.06_disc_extract.bin'
with open(exe_path, 'rb') as f:
    data = f.read()

LOAD_ADDR = 0x80017F00

def f2r(off):
    return LOAD_ADDR + off - 0x800

def r2f(ram):
    return ram - LOAD_ADDR + 0x800

def disasm_mips(insn):
    op = (insn >> 26) & 0x3F
    rs = (insn >> 21) & 0x1F
    rt = (insn >> 16) & 0x1F
    rd = (insn >> 11) & 0x1F
    shamt = (insn >> 6) & 0x1F
    funct = insn & 0x3F
    imm = insn & 0xFFFF
    simm = imm if imm < 0x8000 else imm - 0x10000
    target = insn & 0x3FFFFFF
    regs = ['zero','at','v0','v1','a0','a1','a2','a3',
            't0','t1','t2','t3','t4','t5','t6','t7',
            's0','s1','s2','s3','s4','s5','s6','s7',
            't8','t9','k0','k1','gp','sp','fp','ra']
    if op == 0:
        if funct == 0x08: return f"jr ${regs[rs]}"
        if funct == 0x09: return f"jalr ${regs[rd]}, ${regs[rs]}"
        if funct == 0x21: return f"addu ${regs[rd]}, ${regs[rs]}, ${regs[rt]}"
        if funct == 0x23: return f"subu ${regs[rd]}, ${regs[rs]}, ${regs[rt]}"
        if funct == 0x24: return f"and ${regs[rd]}, ${regs[rs]}, ${regs[rt]}"
        if funct == 0x25: return f"or ${regs[rd]}, ${regs[rs]}, ${regs[rt]}"
        if funct == 0x2A: return f"slt ${regs[rd]}, ${regs[rs]}, ${regs[rt]}"
        if funct == 0x00: return "nop" if insn == 0 else f"sll ${regs[rd]}, ${regs[rt]}, {shamt}"
        if funct == 0x03: return f"sra ${regs[rd]}, ${regs[rt]}, {shamt}"
        if funct == 0x0C: return f"syscall"
        if funct == 0x2B: return f"sltu ${regs[rd]}, ${regs[rs]}, ${regs[rt]}"
        if funct == 0x04: return f"sllv ${regs[rd]}, ${regs[rt]}, ${regs[rs]}"
        if funct == 0x06: return f"srlv ${regs[rd]}, ${regs[rt]}, ${regs[rs]}"
        if funct == 0x07: return f"srav ${regs[rd]}, ${regs[rt]}, ${regs[rs]}"
        if funct == 0x26: return f"nor ${regs[rd]}, ${regs[rs]}, ${regs[rt]}"
        if funct == 0x22: return f"add ${regs[rd]}, ${regs[rs]}, ${regs[rt]}"
        return f".word 0x{insn:08X}"
    if op == 0x01:
        if rt == 0: return f"bltz ${regs[rs]}, +{simm*4+4}"
        if rt == 1: return f"bgez ${regs[rs]}, +{simm*4+4}"
        return f".word 0x{insn:08X}"
    if op == 0x02: return f"j 0x{(target<<2):08X}"
    if op == 0x03: return f"jal 0x{(target<<2):08X}"
    if op == 0x04: return f"beq ${regs[rs]}, ${regs[rt]}, +{simm*4+4}"
    if op == 0x05: return f"bne ${regs[rs]}, ${regs[rt]}, +{simm*4+4}"
    if op == 0x06: return f"blez ${regs[rs]}, +{simm*4+4}"
    if op == 0x07: return f"bgtz ${regs[rs]}, +{simm*4+4}"
    if op == 0x08: return f"addi ${regs[rt]}, ${regs[rs]}, {simm}"
    if op == 0x09: return f"addiu ${regs[rt]}, ${regs[rs]}, {simm}"
    if op == 0x0A: return f"slti ${regs[rt]}, ${regs[rs]}, {simm}"
    if op == 0x0B: return f"sltiu ${regs[rt]}, ${regs[rs]}, {simm}"
    if op == 0x0C: return f"andi ${regs[rt]}, ${regs[rs]}, 0x{imm:04X}"
    if op == 0x0D: return f"ori ${regs[rt]}, ${regs[rs]}, 0x{imm:04X}"
    if op == 0x0E: return f"xori ${regs[rt]}, ${regs[rs]}, 0x{imm:04X}"
    if op == 0x0F: return f"lui ${regs[rt]}, 0x{imm:04X}"
    if op == 0x20: return f"lb ${regs[rt]}, {simm}(${regs[rs]})"
    if op == 0x21: return f"lh ${regs[rt]}, {simm}(${regs[rs]})"
    if op == 0x23: return f"lw ${regs[rt]}, {simm}(${regs[rs]})"
    if op == 0x24: return f"lbu ${regs[rt]}, {simm}(${regs[rs]})"
    if op == 0x25: return f"lhu ${regs[rt]}, {simm}(${regs[rs]})"
    if op == 0x28: return f"sb ${regs[rt]}, {simm}(${regs[rs]})"
    if op == 0x29: return f"sh ${regs[rt]}, {simm}(${regs[rs]})"
    if op == 0x2B: return f"sw ${regs[rt]}, {simm}(${regs[rs]})"
    return f".word 0x{insn:08X}"

# 1. Search for ALL JAL targets to find BIOS call wrappers
print('=== All JAL targets (frequency) ===')
jal_targets = {}
for i in range(0x800, len(data) - 4, 4):
    insn = struct.unpack('<I', data[i:i+4])[0]
    if (insn >> 26) == 0x03:  # jal
        target = (insn & 0x3FFFFFF) << 2
        if target not in jal_targets:
            jal_targets[target] = []
        jal_targets[target].append(f2r(i))

# Show most-called targets
for target in sorted(jal_targets.keys()):
    callers = jal_targets[target]
    if len(callers) >= 5:
        print(f'  JAL 0x{target:08X} called {len(callers)} times')

# 2. Search for the table base via gp register
# MIPS uses $gp for global data access. $gp is typically set in function prologues.
# The table at 0x8001B900 might be accessed via gp-relative loads.
# $gp is usually set to 0x8001xxxx or similar.
print('\n=== $gp value search ===')
# Look for lui $gp, 0x8001 or addiu $gp, $gp, xxx
for i in range(0x800, len(data) - 8, 4):
    insn = struct.unpack('<I', data[i:i+4])[0]
    if (insn >> 26) == 0x0F and ((insn >> 16) & 0x1F) == 28:  # lui $gp
        imm = insn & 0xFFFF
        if imm == 0x8001:
            # Check next for addiu $gp, $gp, xxx
            next_insn = struct.unpack('<I', data[i+4:i+8])[0]
            if (next_insn >> 26) == 0x09 and ((next_insn >> 21) & 0x1F) == 28 and ((next_insn >> 16) & 0x1F) == 28:
                lo = next_insn & 0xFFFF
                slo = lo if lo < 0x8000 else lo - 0x10000
                gp_val = (imm << 16) + slo
                ram = f2r(i)
                print(f'  $gp = 0x{gp_val:08X} set at 0x{ram:08X}')
                # Now check if table at 0x8001B900 is gp-relative
                table_addr = 0x8001B900
                gp_offset = table_addr - gp_val
                if -0x8000 <= gp_offset <= 0x7FFF:
                    print(f'    Table at 0x{table_addr:08X} = $gp + {gp_offset} (0x{gp_offset & 0xFFFF:04X})')
                    # Search for lw/addiu with this gp offset
                    gp_off_imm = gp_offset & 0xFFFF
                    for j in range(0x800, len(data) - 4, 4):
                        insn2 = struct.unpack('<I', data[j:j+4])[0]
                        if (insn2 >> 26) == 0x23 and ((insn2 >> 21) & 0x1F) == 28:  # lw $rt, off($gp)
                            if (insn2 & 0xFFFF) == gp_off_imm:
                                r2 = f2r(j)
                                print(f'    lw ${regs[(insn2>>16)&0x1F]}, {gp_offset}($gp) at 0x{r2:08X}')
                        elif (insn2 >> 26) == 0x09 and ((insn2 >> 21) & 0x1F) == 28:  # addiu $rt, $gp, off
                            if (insn2 & 0xFFFF) == gp_off_imm:
                                r2 = f2r(j)
                                print(f'    addiu ${regs[(insn2>>16)&0x1F]}, $gp, {gp_offset} at 0x{r2:08X}')
                break

# 3. Search for the "cdrom file" string via gp-relative or any lui 0x8002
print('\n=== "cdrom file" string xref (0x80028F87) ===')
str_addr = 0x80028F87
# Try: lui $reg, 0x8002 + addiu $reg, $reg, 0x8F87
# But 0x8F87 is negative as signed: -0x7079
# So lui 0x8002 + addiu 0x8F87 = 0x80020000 - 0x7079 = 0x80018F87 (WRONG)
# Need: lui 0x8003 + addiu 0x8F87 = 0x80030000 - 0x7079 = 0x80028F87 (CORRECT!)
for i in range(0x800, len(data) - 8, 4):
    insn = struct.unpack('<I', data[i:i+4])[0]
    if (insn >> 26) == 0x0F and (insn & 0xFFFF) == 0x8003:
        reg = (insn >> 16) & 0x1F
        if i + 8 <= len(data):
            for j in range(1, 8):
                if i + j*4 + 4 > len(data):
                    break
                next_insn = struct.unpack('<I', data[i+j*4:i+j*4+4])[0]
                if (next_insn >> 26) == 0x09 and ((next_insn >> 21) & 0x1F) == reg:
                    next_imm = next_insn & 0xFFFF
                    next_simm = next_imm if next_imm < 0x8000 else next_imm - 0x10000
                    addr = 0x80030000 + next_simm
                    if 0x80028F80 <= addr <= 0x80029030:
                        ram = f2r(i)
                        print(f'  xref to 0x{addr:08X} at 0x{ram:08X}')
                        for k in range(0, 30):
                            off2 = i + k*4
                            if off2 + 4 <= len(data):
                                insn2 = struct.unpack('<I', data[off2:off2+4])[0]
                                r2 = f2r(off2)
                                print(f'    0x{r2:08X}: 0x{insn2:08X}  {disasm_mips(insn2)}')
                        break

# 4. Also check if the table is accessed via a pointer stored elsewhere
# Search for the value 0x8001B900 (or nearby) stored as a 32-bit word
print('\n=== Search for 0x8001B900-0x8001BA80 as stored pointer ===')
for target_addr in [0x8001B900, 0x8001B980, 0x8001B9DC]:
    target_bytes = struct.pack('<I', target_addr)
    pos = 0x800
    while True:
        idx = data.find(target_bytes, pos)
        if idx == -1:
            break
        ram = f2r(idx)
        print(f'  0x{target_addr:08X} stored at file 0x{idx:X} (RAM 0x{ram:08X})')
        pos = idx + 1

# 5. Look for the table start more carefully
# The table seems to start around 0x8001B900. Let's look further back.
print('\n=== Table structure analysis ===')
# Dump from 0x8001B800 to find the true start
start = r2f(0x8001B800)
for i in range(0, 128, 4):
    off = start + i
    if off + 4 <= len(data):
        val = struct.unpack('<I', data[off:off+4])[0]
        ram = f2r(off)
        if 0x100 <= val <= 0x2000:
            print(f'  0x{ram:08X}: 0x{val:08X}  LBA={val}')
        elif 0x80100000 <= val <= 0x801F0000:
            print(f'  0x{ram:08X}: 0x{val:08X}  PTR')
        elif 0x80000000 <= val <= 0x800FFFFF:
            print(f'  0x{ram:08X}: 0x{val:08X}  CODE_PTR')
        else:
            print(f'  0x{ram:08X}: 0x{val:08X}')

# 6. Search for the table base pointer in the BSS/data area
# The game might store the table base in a global variable
print('\n=== Search for table base in global vars ===')
# Look for 0x8001B8xx or 0x8001B9xx values
for i in range(0x800, len(data) - 4, 4):
    val = struct.unpack('<I', data[i:i+4])[0]
    if 0x8001B800 <= val <= 0x8001BC00:
        ram = f2r(i)
        print(f'  0x{val:08X} at file 0x{i:X} (RAM 0x{ram:08X})')

print('\n=== Done ===')
