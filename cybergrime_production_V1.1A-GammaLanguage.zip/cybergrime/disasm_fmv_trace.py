#!/usr/bin/env python3
"""
Focused disassembly of FMV-related functions in DW7 EXE.
Trace the Setloc call chain to find where MSF values originate.
"""

import struct
from capstone import Cs, CS_ARCH_MIPS, CS_MODE_MIPS32, CS_MODE_LITTLE_ENDIAN

EXE_PATH = r"c:\LuxAura\VoidWalkers_Project\DQLOSTTRANSLATION\translation\SLUSP012.06"
LOAD_ADDR = 0x80017F00
HEADER_SIZE = 0x800

def load_exe(path):
    with open(path, "rb") as f:
        return f.read()

def ram_to_offset(ram_addr):
    return (ram_addr - LOAD_ADDR) + HEADER_SIZE

def disasm_range(data, start_ram, end_ram, label=""):
    md = Cs(CS_ARCH_MIPS, CS_MODE_MIPS32 | CS_MODE_LITTLE_ENDIAN)
    md.detail = True
    
    start_off = ram_to_offset(start_ram)
    end_off = ram_to_offset(end_ram)
    
    if start_off < 0 or end_off > len(data) or start_off >= end_off:
        print(f"  [!] Invalid range: {start_ram:#010x}-{end_ram:#010x}")
        return
    
    code = data[start_off:end_off]
    print(f"\n{'='*70}")
    print(f"  {label}: 0x{start_ram:08X} - 0x{end_ram:08X}")
    print(f"{'='*70}")
    
    for insn in md.disasm(code, start_ram):
        print(f"  0x{insn.address:08X}:  {insn.mnemonic:<8s} {insn.op_str}")

def search_jal_to(data, target_ram):
    """Find all JAL instructions targeting a specific address."""
    results = []
    for i in range(HEADER_SIZE, len(data) - 4, 4):
        word = struct.unpack("<I", data[i:i+4])[0]
        op = (word >> 26) & 0x3F
        if op == 0x03:  # JAL
            target = (word & 0x03FFFFFF) << 2
            # Upper 4 bits from PC+4
            caller_ram = (i - HEADER_SIZE) + LOAD_ADDR
            target_full = (caller_ram & 0xF0000000) | target
            if target_full == target_ram:
                results.append(caller_ram)
    return results

def main():
    data = load_exe(EXE_PATH)
    
    # 1. Disassemble around the BCD value loads (0x800A2200, 0x800A2220, 0x800A2760)
    disasm_range(data, 0x800A21C0, 0x800A2280, "BCD 0x32 and 0x34 loads context")
    disasm_range(data, 0x800A2720, 0x800A27A0, "BCD 0x15 load context")
    
    # 2. Disassemble the full CD-ROM Setloc function (0x800988C0 onwards)
    disasm_range(data, 0x80098880, 0x80098940, "CD-ROM Setloc function (full)")
    
    # 3. Find who calls the Setloc function at 0x800988C0
    # The function seems to start earlier. Let's find the entry point.
    # Looking at 0x80098880, it seems like a return path. Let's look for the function start.
    disasm_range(data, 0x80098800, 0x800988C0, "CD-ROM function entry (before Setloc write)")
    
    # 4. Search for JAL to 0x800988C0 area (or the function entry)
    # First, let's find the function entry by looking for addiu $sp, $sp, -NN
    print(f"\n{'='*70}")
    print(f"  Searching for JAL to CD-ROM Setloc area (0x80098800-0x800988C0)")
    print(f"{'='*70}")
    for target in range(0x80098800, 0x800988C0, 4):
        callers = search_jal_to(data, target)
        if callers:
            print(f"  JAL to 0x{target:08X}: called from {[f'0x{c:08X}' for c in callers]}")
    
    # 5. Search for JAL to the BCD load area (0x800A21C0-0x800A2280)
    print(f"\n{'='*70}")
    print(f"  Searching for JAL to BCD load area (0x800A21C0-0x800A2280)")
    print(f"{'='*70}")
    for target in range(0x800A21C0, 0x800A2280, 4):
        callers = search_jal_to(data, target)
        if callers:
            print(f"  JAL to 0x{target:08X}: called from {[f'0x{c:08X}' for c in callers]}")
    
    # 6. Search for JAL to 0x800A2720-0x800A27A0
    print(f"\n{'='*70}")
    print(f"  Searching for JAL to BCD 0x15 area (0x800A2720-0x800A27A0)")
    print(f"{'='*70}")
    for target in range(0x800A2720, 0x800A27A0, 4):
        callers = search_jal_to(data, target)
        if callers:
            print(f"  JAL to 0x{target:08X}: called from {[f'0x{c:08X}' for c in callers]}")
    
    # 7. Look at the data table around 0x800AA036 (where 32 34 71 was found)
    disasm_range(data, 0x800AA020, 0x800AA060, "Data table at 0x800AA036 (32 34 71 location)")
    
    # 8. Search for all addiu $reg, $zero, 0x71 instructions
    print(f"\n{'='*70}")
    print(f"  Searching for addiu $reg, $zero, 0x71 (BCD frame 71)")
    print(f"{'='*70}")
    for i in range(HEADER_SIZE, len(data) - 4, 4):
        word = struct.unpack("<I", data[i:i+4])[0]
        op = (word >> 26) & 0x3F
        rt = (word >> 16) & 0x1F
        rs = (word >> 21) & 0x1F
        imm = word & 0xFFFF
        if op == 0x09 and rs == 0 and imm == 0x71:  # addiu $rt, $zero, 0x71
            ram = (i - HEADER_SIZE) + LOAD_ADDR
            print(f"  0x{ram:08X}: addiu ${rt}, $zero, 0x71")
    
    # 9. Search for sb $reg, offset($base) where reg might contain 0x71
    # Actually, let's search for ori $reg, $zero, 0x71 too
    print(f"\n{'='*70}")
    print(f"  Searching for ori $reg, $zero, 0x71")
    print(f"{'='*70}")
    for i in range(HEADER_SIZE, len(data) - 4, 4):
        word = struct.unpack("<I", data[i:i+4])[0]
        op = (word >> 26) & 0x3F
        rt = (word >> 16) & 0x1F
        rs = (word >> 21) & 0x1F
        imm = word & 0xFFFF
        if op == 0x0D and rs == 0 and imm == 0x71:  # ori $rt, $zero, 0x71
            ram = (i - HEADER_SIZE) + LOAD_ADDR
            print(f"  0x{ram:08X}: ori ${rt}, $zero, 0x71")
    
    # 10. Disassemble around 0x800B1B64 (lb $a1, 0x71($s6)) — might be loading from a table
    disasm_range(data, 0x800B1B40, 0x800B1BD0, "Context around lb $a1, 0x71($s6)")
    
    # 11. Look for the function that contains 0x800A2200 and 0x800A2220
    # These are 0x20 apart, likely in the same function
    disasm_range(data, 0x800A2100, 0x800A2300, "Full function containing BCD 0x32/0x34 loads")
    
    # 12. Also look at 0x800A2700-0x800A2800 for the 0x15 load
    disasm_range(data, 0x800A2700, 0x800A2800, "Full function containing BCD 0x15 load")

if __name__ == "__main__":
    main()
