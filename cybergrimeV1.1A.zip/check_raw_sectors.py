#!/usr/bin/env python3
"""Check raw sector structure to understand lead-in."""

disc = r"C:\LuxAura\VoidWalkers_Project\DQLOSTTRANSLATION\build_staging\dq4_reverse_a.bin"
dq4_disc = r"C:\LuxAura\VoidWalkers_Project\DQLOSTTRANSLATION\Dragon Quest IV - Michibikareshi Mono Tachi (Japan).bin"

for label, path in [("Built disc", disc), ("DQ4 original", dq4_disc)]:
    print(f"\n=== {label} ===")
    with open(path, 'rb') as f:
        for lba in [0, 1, 15, 16, 149, 150, 151, 165, 166]:
            f.seek(lba * 2352)
            raw = f.read(2352)
            sync = raw[:12].hex()
            addr = raw[12:16].hex()
            mode = raw[15]
            subhdr = raw[16:24].hex()
            user = raw[24:40].hex()
            print(f"  Sector {lba}: sync={sync} addr={addr} mode={mode} subhdr={subhdr} user={user}")
        
        # Check if sector 166 has PVD
        f.seek(166 * 2352 + 24)
        data166 = f.read(8)
        print(f"  Sector 166 user data: {data166} {'[PVD]' if data166[:5] == b'CD001' else ''}")
        
        # Check if sector 16 has PVD
        f.seek(16 * 2352 + 24)
        data16 = f.read(8)
        print(f"  Sector 16 user data: {data16} {'[PVD]' if data16[:5] == b'CD001' else ''}")
