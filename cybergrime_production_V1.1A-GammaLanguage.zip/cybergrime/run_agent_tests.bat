@echo off
REM ============================================================================
REM AGENT TEST RUNNER — Batch Pipeline for Multi-Profile Regression Testing
REM ============================================================================
REM Runs psx_agent_runner.exe against multiple ROM profiles sequentially.
REM Each profile produces a telemetry_<name>.json file.
REM After all profiles complete, prints a summary table.
REM
REM Usage:
REM   run_agent_tests.bat [max_instrs] [wallclock_ms]
REM
REM Defaults:
REM   max_instrs   = 200000000  (200M)
REM   wallclock_ms = 300000     (5 minutes)
REM ============================================================================

setlocal enabledelayedexpansion

set MAX_INSTRS=200000000
if not "%~1"=="" set MAX_INSTRS=%~1

set WALLCLOCK=300000
if not "%~2"=="" set WALLCLOCK=%~2

set BASE_DIR=C:\LuxAura\VoidWalkers_Project\DQLOSTTRANSLATION
set RUNNER=%BASE_DIR%\cybergrime\psx_agent_runner.exe
set JSON_DIR=%BASE_DIR%\cybergrime\telemetry

if not exist "%JSON_DIR%" mkdir "%JSON_DIR%"

REM ── Profile Definitions ────────────────────────────────────────────────────
REM Format: profile_name|disc_path
set PROFILES[0]=test_0|%BASE_DIR%\dq4_test_0.bin
set PROFILES[1]=test_f|%BASE_DIR%\dq4_test_f.bin
set PROFILES[2]=test_a|%BASE_DIR%\dq4_test_a.bin
set PROFILES[3]=test_d|%BASE_DIR%\dq4_test_d.bin
set PROFILES[4]=test_b|%BASE_DIR%\dq4_test_b.bin
set PROFILES[5]=frank_v12|%BASE_DIR%\dq4_frankenstein_v12.bin
set PROFILES[6]=rc2|%BASE_DIR%\dq4_en_rc2.bin
set PROFILES[7]=native_v26|%BASE_DIR%\dq4_full_en_v26.bin
set PROFILE_COUNT=8

echo ============================================
echo  AGENT TEST PIPELINE
echo  MaxInstrs: %MAX_INSTRS%
echo  WallClock: %WALLCLOCK%ms
echo  Profiles:  %PROFILE_COUNT%
echo  JSON Dir:  %JSON_DIR%
echo ============================================
echo.

set PASS_COUNT=0
set FAIL_COUNT=0
set SUMMARY_LINE=

for /L %%i in (0,1,%PROFILE_COUNT%-1) do (
    set ENTRY=!PROFILES[%%i]!
    for /f "tokens=1,2 delims=|" %%a in ("!ENTRY!") do (
        set PNAME=%%a
        set DISC=%%b

        echo [%%i/%PROFILE_COUNT%] Running profile: !PNAME!
        echo   Disc: !DISC!

        if not exist "!DISC!" (
            echo   SKIP: Disc file not found
            set SUMMARY_LINE=!SUMMARY_LINE!!PNAME!=SKIP,
        ) else (
            set JSON_OUT=%JSON_DIR%\telemetry_!PNAME!.json
            echo   JSON: !JSON_OUT!
            echo   Running...

            "%RUNNER%" "!DISC!" "!PNAME!" %MAX_INSTRS% "!JSON_OUT!" %WALLCLOCK%
            set EXITCODE=!errorlevel!

            if !EXITCODE! equ 0 (
                echo   RESULT: PASS
                set /a PASS_COUNT+=1
                set SUMMARY_LINE=!SUMMARY_LINE!!PNAME!=PASS,
            ) else (
                echo   RESULT: FAIL (exit code !EXITCODE!)
                set /a FAIL_COUNT+=1
                set SUMMARY_LINE=!SUMMARY_LINE!!PNAME!=FAIL(!EXITCODE!),
            )
        )
        echo.
    )
)

echo ============================================
echo  PIPELINE COMPLETE
echo  Pass: %PASS_COUNT%  Fail: %FAIL_COUNT%  Total: %PROFILE_COUNT%
echo  Results: %SUMMARY_LINE%
echo ============================================
echo.
echo Telemetry files in: %JSON_DIR%
echo Review with: type "%JSON_DIR%\telemetry_*.json"
echo.

endlocal
