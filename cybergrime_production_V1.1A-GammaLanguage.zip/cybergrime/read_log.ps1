$logPath = 'c:\LuxAura\VoidWalkers_Project\DQLOSTTRANSLATION\duckstation.log'
if (Test-Path $logPath) {
    $f = Get-Item $logPath
    Write-Host "Size: $($f.Length) bytes, Modified: $($f.LastWriteTime)"
    Write-Host "--- LAST 100 LINES ---"
    Get-Content $logPath -Tail 100
} else {
    Write-Host 'Log file not found'
}
