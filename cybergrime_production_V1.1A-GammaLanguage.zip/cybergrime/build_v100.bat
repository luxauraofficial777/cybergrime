@echo off
set BASE=c:\LuxAura\VoidWalkers_Project\DQLOSTTRANSLATION
set DW7_DISC=%BASE%\DW7D1\DW7D1.bin
set DW7_EXE=%BASE%\translation\SLUSP012.06
set DQ4_DISC=%BASE%\Dragon Quest IV - Michibikareshi Mono Tachi (Japan).bin
set HYBRID_TREE=%BASE%\frozen\dw7_hybrid_tree.bin
set FOLDER_MAP=%BASE%\translation\folder_mapping.json
set EDCRE=%BASE%\edcre\edcre-v1.1.0-windows-x86_64-static\edcre.exe
set OUTPUT_BIN=%BASE%\dq4_frankenstein_v100.bin
set OUTPUT_CUE=%BASE%\dq4_frankenstein_v100.cue

frankenstein_build.exe --dw7-disc "%DW7_DISC%" --dw7-exe "%DW7_EXE%" --dq4-hbd "%DQ4_DISC%" --hybrid-tree "%HYBRID_TREE%" --folder-map "%FOLDER_MAP%" --edcre "%EDCRE%" --output "%OUTPUT_BIN%" --output-cue "%OUTPUT_CUE%" --tree-mode 3 --reencode-hbd
