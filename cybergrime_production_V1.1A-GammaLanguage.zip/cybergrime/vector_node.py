#!/usr/bin/env python3
"""
vector_node.py — Vector Allocation Node (Agent-VA, Path A)

Ingests all telemetry JSON files, memory maps, and ROM documentation into a
unified, queryable vector index keyed by KSEG0 addresses (0x80xxxxxx).

Query API:
  query_address(addr)          — What is at this address?
  query_crash(symptom)         — Why does this symptom occur?
  query_pointer_chain(addr)    — Full dependency chain for an address
  query_collisions(rom_a, rom_b) — Cross-ROM collision zones
  query_patch_impact(exe_off)  — What does patching this EXE offset affect?

Output: cybergrime/vector_index.json
"""

import json
import os
import re
import glob
from typing import Dict, List, Any, Optional, Tuple

# ── Locked Constants (from UNIFIED_BLUEPRINT_Jul19_2026.md) ──────────────────

EXE_LBA          = 24
HBD_LBA          = 355
DQ4_HBD_SIZE     = 319_436_800
DW7_HBD_SIZE     = 618_563_584
HYBRID_TREE_SIZE = 1480
EXE_EXTENDED     = 677_888
ABS_TABLE_START  = 0x4184
REL_TABLE_START  = 0x511C
TREE_RAM_RELOC   = 0x80100000
TRAMPOLINE_RAM   = 0x801005C8
COPY_ROUTINE_RAM = 0x800BCCF0
ORIGINAL_PC0     = 0x8008E284
BSS_CLEAR_START  = 0x800BC668
BSS_CLEAR_END    = 0x800F4980
THREAD_ENTRY     = 0x800D9E80

TELEMETRY_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "telemetry")
INDEX_PATH    = os.path.join(os.path.dirname(os.path.abspath(__file__)), "vector_index.json")

# ── Memory Map (proven RAM layout from blueprint + study docs) ────────────────

MEMORY_MAP = {
    0x80017F00: ("EXE_LOAD", "EXE load address (BASE)", "DW7_711MB"),
    0x8008E284: ("BSS_CLEAR_ENTRY", "DQ4 BSS clear entry (original PC0)", "DW7_711MB"),
    0x8009674C: ("VBLANK_POLL_RETURN", "VBlank poll loop return", "DW7_711MB"),
    0x800986D0: ("VBLANK_OUTER_LOOP", "Outer VBlank wait loop", "DW7_711MB"),
    0x8009870C: ("VBLANK_COUNTER_CHECK", "VBlank counter check (beq)", "FRANK_v38b"),
    0x800B52A0: ("SPINLOCK_A", "Spinlock variable A", "DW7_711MB"),
    0x800B52A4: ("SPINLOCK_B", "Spinlock variable B", "DW7_711MB"),
    0x800B52A8: ("DELTA_VAR", "Delta computation variable", "DW7_711MB"),
    0x800B63D8: ("VBLANK_COUNT_REG", "VBlank count register", "DW7_711MB"),
    0x800BC668: ("BSS_CLEAR_START", "BSS clear start / GP register", "DW7_711MB"),
    0x800BC700: ("HYBRID_TREE_ONDISC", "Hybrid tree on-disc (within EXE)", "FRANK_v34"),
    0x800BCCF0: ("COPY_ROUTINE", "Copy routine (new PC0)", "FRANK_v34"),
    0x800D9E80: ("THREAD_ENTRY", "CD-ROM thread entry (ZEROED by BSS — ROOT CAUSE)", "DW7_711MB"),
    0x800EF1C8: ("DW7_GLOBAL_TREE", "DW7 original global tree (runtime)", "DW7_711MB"),
    0x800F2C88: ("VBLANK_THRESH_A", "VBlank threshold counter A", "DW7_711MB"),
    0x800F2C8C: ("VBLANK_THRESH_B", "VBlank threshold counter B", "DW7_711MB"),
    0x800F4930: ("DMA_BUFFER", "DMA buffer (game writes during init)", "DW7_711MB"),
    0x800F4950: ("GAME_INIT_WRITE", "Game init write target", "DW7_711MB"),
    0x800F4980: ("GAME_DATA_START", "Game data section start (BSS clear end)", "DW7_711MB"),
    0x800F9E54: ("GAME_DATA_END", "Game data section end (approx)", "DW7_711MB"),
    0x80100000: ("TREE_RELOCATED", "Hybrid tree relocated (safe high RAM)", "FRANK_v34"),
    0x801005C8: ("TRAMPOLINE_RELOC", "CD-ROM Stop trampoline (relocated)", "FRANK_v34"),
    0x80138000: ("DYNAMIC_HEAP", "Dynamic heap start (map geometry)", "DW7_711MB"),
    0x801FFFF0: ("STACK_TOP", "Stack top", "DW7_711MB"),
}

# ── EXE Patch Sites ───────────────────────────────────────────────────────────

EXE_PATCH_SITES = {
    0x03A94: {"ram": 0x8001B894, "patch": "LBA 354->355", "desc": "Primary HBD LBA reference"},
    0x6112C: {"ram": 0x8007902C, "patch": "0x24020001", "desc": "disc_check exit1 return success"},
    0x611D8: {"ram": 0x800790D8, "patch": "0x24020001", "desc": "disc_check exit2 return success"},
    0x613B8: {"ram": 0x800792BC, "patch": "0x24020001", "desc": "disc_check exit3 return success"},
    0x76B84: {"ram": 0x8008E284, "patch": "BSS clear start", "desc": "lui $v0, 0x800C"},
    0x76B88: {"ram": 0x8008E288, "patch": "0x2442CCC8", "desc": "addiu $v0, 0xC668->0xCCC8 (BSS patch)"},
    0x80F64: {"ram": 0x80098F64, "patch": "j 0x801005C8", "desc": "CD-ROM Stop intercept"},
    0x80F68: {"ram": 0x80098F68, "patch": "nop", "desc": "Delay slot"},
    0x96FA0: {"ram": 0x800AEFA0, "patch": "tree location", "desc": "DW7 global Huffman tree (744B)"},
    0xA39AA: {"ram": 0x800B59AA, "patch": "16-bit table", "desc": "Sequential sector table (44 entries)"},
    0xA5000: {"ram": 0x800BC700, "patch": "appended", "desc": "Hybrid tree + trampoline + copy routine"},
}

# ── Known Crash/Stall Events (from blueprint A.3.2) ──────────────────────────

KNOWN_CRASH_EVENTS = [
    {
        "event": "v34 freeze",
        "context_pc": 0x00000058,
        "effect": "VBlank stall, no IRQ delivery",
        "origin": "Copy routine ra=0x4",
        "source": "telemetry_v34_smoke.json",
        "rom_tag": "FRANK_v34",
    },
    {
        "event": "v32 crash",
        "context_pc": 0x800F4F68,
        "effect": "Invalid byte read 0xFFFF8002",
        "origin": "Trampoline corrupted by copy",
        "source": "V32_BUILD_AND_CYBERGRIME_RESULTS",
        "rom_tag": "FRANK_v32",
    },
    {
        "event": "v31 crash",
        "context_pc": 0x800F4F68,
        "effect": "EXE/HBD overlap, tree destroyed",
        "origin": "HBD at 354, EXE extends to 354",
        "source": "BSS_CLEAR_ANALYSIS",
        "rom_tag": "FRANK_v31",
    },
    {
        "event": "v33 fail",
        "context_pc": 0x801005C8,
        "effect": "Invalid byte read, wrong bne offset",
        "origin": "Copy routine bne=-4 not -6",
        "source": "V33_DEBUG_PROGRESS",
        "rom_tag": "FRANK_v33",
    },
    {
        "event": "v22 crash",
        "context_pc": 0x80000000,
        "effect": "ChangeTh returns ra=0x1",
        "origin": "CyberGrime ChangeTh bug",
        "source": "frank_v22_trace.json",
        "rom_tag": "FRANK_v22",
    },
    {
        "event": "v38 idle",
        "context_pc": 0x8009870C,
        "effect": "VBlank wait, thread entry zeroed",
        "origin": "BSS clears 0x800D9E80",
        "source": "telemetry_v38b.json",
        "rom_tag": "FRANK_v38b",
    },
    {
        "event": "DW7 idle",
        "context_pc": 0x8009674C,
        "effect": "Same VBlank wait, same BSS issue",
        "origin": "BSS clears 0x800D9E80",
        "source": "telemetry_baseline_dw7.json",
        "rom_tag": "DW7_711MB",
    },
    {
        "event": "v37 hang",
        "context_pc": None,
        "effect": "Boot overlay loads, then GPU idle",
        "origin": "Not FMV — overlay calls EXE",
        "source": "SESSION_v37_FMV_SKIP",
        "rom_tag": "FRANK_v37",
        "lba": 146621,
    },
    {
        "event": "v12 black",
        "context_pc": None,
        "effect": "Unmatched ABS pointers to wrong data",
        "origin": "remap_pointers_to_dw7_preserved",
        "source": "GLM_BOOT_FAILURE_ANALYSIS",
        "rom_tag": "FRANK_v12",
    },
    {
        "event": "v19 black",
        "context_pc": None,
        "effect": "BSS expansion zeroing data",
        "origin": "CD-ROM streaming infinite",
        "source": "DEFINITIVE_BLUEPRINT",
        "rom_tag": "FRANK_v19",
    },
]

# ── Collision Zones ───────────────────────────────────────────────────────────

COLLISION_ZONES = [
    {
        "address": 0x800F4930,
        "name": "DMA_BUFFER",
        "desc": "Game writes here during init; v32 tree was here",
        "collides_with": ["FRANK_v32"],
    },
    {
        "address": 0x800F4950,
        "name": "GAME_INIT_WRITE",
        "desc": "Game data section writes",
        "collides_with": ["FRANK_v32"],
    },
    {
        "address": 0x800D9E80,
        "name": "THREAD_ENTRY",
        "desc": "BSS clear zeros thread entry, causing idle loop",
        "collides_with": ["DW7_711MB", "FRANK_v38b", "FRANK_v34"],
    },
    {
        "address_range": (0x800BC668, 0x800F4980),
        "name": "BSS_CLEAR_RANGE",
        "desc": "BSS clear range; any injected code here is destroyed",
        "collides_with": ["FRANK_v32", "FRANK_v35"],
    },
    {
        "address": 0x800EF1C8,
        "name": "DW7_GLOBAL_TREE",
        "desc": "DW7 original global tree (outside loaded EXE, runtime-copied)",
        "collides_with": [],
    },
]

# ── ROM Tag Classification ────────────────────────────────────────────────────

def classify_rom_tag(profile_name: str, disc_path: str) -> str:
    """Classify a telemetry file into DQ4_365MB / DW7_711MB / FRANK_vXX."""
    name = (profile_name or "").lower()
    path = (disc_path or "").lower()

    if "baseline" in name or "dw7" in name or "native" in name:
        if "dq4" in name:
            return "DQ4_365MB"
        return "DW7_711MB"
    if "dq4" in name and "frank" not in name:
        return "DQ4_365MB"
    if "rc2" in name:
        return "DQ4_365MB"
    if "frank" in name or name.startswith("v") or "v33" in name or "v34" in name or "v38" in name:
        return f"FRANK_{profile_name}"
    if "dq4" in path and "frank" not in path:
        return "DQ4_365MB"
    return f"FRANK_{profile_name}"


def parse_hex(val) -> Optional[int]:
    """Parse a hex string or int to int. Returns None if invalid."""
    if val is None:
        return None
    if isinstance(val, int):
        return val
    if isinstance(val, str):
        s = val.strip()
        if not s:
            return None
        try:
            return int(s, 16) if s.startswith("0x") or s.startswith("0X") else int(s)
        except ValueError:
            return None
    return None


def is_kseg0(addr: Optional[int]) -> bool:
    """Check if address is in KSEG0 range (0x80000000-0x801FFFFF)."""
    return addr is not None and 0x80000000 <= addr <= 0x801FFFFF


# ── TTY Trace Parser ──────────────────────────────────────────────────────────

TTY_PC_RE = re.compile(r'PC=(0x[0-9A-Fa-f]+)')
TTY_REG_RE = re.compile(r'\$(\w+)=0x([0-9A-Fa-f]+)')

def parse_tty_trace(tty_text: str) -> List[Dict]:
    """Parse TTY tail trace into structured instruction entries."""
    entries = []
    for line in tty_text.split('\n'):
        line = line.strip()
        if not line or not line.startswith('#'):
            continue
        pc_match = TTY_PC_RE.search(line)
        if not pc_match:
            continue
        pc = int(pc_match.group(1), 16)
        # Extract instruction mnemonic
        parts = line.split(None, 4)
        mnemonic = parts[3] if len(parts) > 3 else ""
        # Extract register values if present
        regs = {}
        for m in TTY_REG_RE.finditer(line):
            regs[m.group(1)] = int(m.group(2), 16)
        entries.append({
            "pc": pc,
            "mnemonic": mnemonic,
            "regs": regs,
            "raw": line[:200],
        })
    return entries


# ── Vector Node ───────────────────────────────────────────────────────────────

class VectorNode:
    """Vector Allocation Node — ingests telemetry and provides query API."""

    def __init__(self):
        self.address_index: Dict[int, List[Dict]] = {}   # addr -> [entries]
        self.telemetry_summaries: List[Dict] = []
        self.crash_vectors: List[Dict] = []
        self.bios_call_map: List[Dict] = []
        self.collision_zones: List[Dict] = []
        self.pointer_entries: List[Dict] = []
        self.patch_sites: Dict[int, Dict] = {}
        self.rom_tags_seen: set = set()
        self._tty_traces: Dict[str, List[Dict]] = {}

    # ── Ingestion ─────────────────────────────────────────────────────────────

    def ingest_telemetry_dir(self, dir_path: str = TELEMETRY_DIR) -> int:
        """Scan and ingest all telemetry JSON files. Returns count ingested."""
        files = sorted(glob.glob(os.path.join(dir_path, "*.json")))
        count = 0
        for fpath in files:
            try:
                self.ingest_telemetry_file(fpath)
                count += 1
            except Exception as e:
                print(f"  WARN: Failed to ingest {os.path.basename(fpath)}: {e}")
        print(f"  Ingested {count} telemetry files, {len(self.address_index)} addresses indexed")
        return count

    def ingest_telemetry_file(self, fpath: str):
        """Ingest a single telemetry JSON file."""
        with open(fpath, "r", encoding="utf-8", errors="replace") as f:
            raw = json.load(f)

        fname = os.path.basename(fpath)
        profile = raw.get("Profile_Name", fname.replace(".json", ""))
        disc_path = raw.get("Disc_Path", "")
        rom_tag = classify_rom_tag(profile, disc_path)
        self.rom_tags_seen.add(rom_tag)

        # Build summary
        summary = {
            "file": fname,
            "profile": profile,
            "rom_tag": rom_tag,
            "pass_status": raw.get("Pass_Status", "UNKNOWN"),
            "instructions": raw.get("Instructions_Executed", 0),
            "vblanks": raw.get("VBlank_Count", 0),
            "wall_clock_ms": raw.get("Wall_Clock_MS", 0),
            "crashed": raw.get("Crashed", False),
            "frozen": raw.get("Frozen", False),
            "crash_reason": raw.get("Crash_Reason", ""),
            "last_pc": parse_hex(raw.get("Last_Known_PC")),
        }
        self.telemetry_summaries.append(summary)

        # ── Index Register Dump ──────────────────────────────────────────────
        reg_dump = raw.get("Register_Dump", {})
        for reg_name, reg_val in reg_dump.items():
            addr = parse_hex(reg_val)
            if is_kseg0(addr):
                self._index_address(addr, {
                    "type": "REGISTER",
                    "reg": reg_name,
                    "value": addr,
                    "rom_tag": rom_tag,
                    "source": fname,
                    "profile": profile,
                })

        # ── Index BIOS Call Log ──────────────────────────────────────────────
        bios_log = raw.get("BIOS_Call_Log", [])
        for call in bios_log:
            entry = {
                "type": "BIOS_CALL",
                "table": call.get("table", ""),
                "fn": call.get("fn", 0),
                "instr_count": call.get("instr", 0),
                "ra": parse_hex(call.get("ra")),
                "a0": parse_hex(call.get("a0")),
                "a1": parse_hex(call.get("a1")),
                "a2": parse_hex(call.get("a2")),
                "a3": parse_hex(call.get("a3")),
                "rom_tag": rom_tag,
                "source": fname,
                "profile": profile,
            }
            self.bios_call_map.append(entry)
            for reg_key in ("ra", "a0", "a1", "a2", "a3"):
                addr = entry[reg_key]
                if is_kseg0(addr):
                    self._index_address(addr, {
                        "type": "BIOS_CALL_ARG",
                        "arg": reg_key,
                        "table": entry["table"],
                        "fn": entry["fn"],
                        "instr_count": entry["instr_count"],
                        "rom_tag": rom_tag,
                        "source": fname,
                    })

        # ── Index Error Signatures ───────────────────────────────────────────
        errors = raw.get("Error_Signature", [])
        for err in errors:
            pc = parse_hex(err.get("pc"))
            entry = {
                "type": "ERROR_SIGNATURE",
                "category": err.get("category", ""),
                "signature": err.get("signature", ""),
                "pc": pc,
                "instr_count": err.get("instr_count", 0),
                "rom_tag": rom_tag,
                "source": fname,
            }
            self.crash_vectors.append(entry)
            if is_kseg0(pc):
                self._index_address(pc, {
                    "type": "ERROR_PC",
                    "category": err.get("category", ""),
                    "signature": err.get("signature", ""),
                    "rom_tag": rom_tag,
                    "source": fname,
                })

        # ── Index Asset Load History ─────────────────────────────────────────
        for asset in raw.get("Asset_Load_History", []):
            calling_pc = parse_hex(asset.get("calling_pc"))
            lba = asset.get("lba", 0)
            entry = {
                "type": "ASSET_LOAD",
                "resource_id": asset.get("resource_id", ""),
                "lba": lba,
                "size": asset.get("size", 0),
                "resolved": asset.get("resolved", False),
                "calling_pc": calling_pc,
                "instr_count": asset.get("instr_count", 0),
                "error": asset.get("error", ""),
                "rom_tag": rom_tag,
                "source": fname,
            }
            self.pointer_entries.append(entry)
            if is_kseg0(calling_pc):
                self._index_address(calling_pc, {
                    "type": "ASSET_LOAD_PC",
                    "resource_id": asset.get("resource_id", ""),
                    "lba": lba,
                    "rom_tag": rom_tag,
                    "source": fname,
                })

        # ── Index Memory Dump ────────────────────────────────────────────────
        mem_dump = raw.get("Memory_Dump", {})
        if mem_dump:
            base = parse_hex(mem_dump.get("base_addr"))
            if is_kseg0(base):
                self._index_address(base, {
                    "type": "MEMORY_DUMP_BASE",
                    "length": mem_dump.get("length", 0),
                    "rom_tag": rom_tag,
                    "source": fname,
                })

        # ── Index HW State ───────────────────────────────────────────────────
        hw = raw.get("HW_State", {})
        if hw:
            pad_addr = parse_hex(hw.get("pad_buf1_addr"))
            if is_kseg0(pad_addr):
                self._index_address(pad_addr, {
                    "type": "PAD_BUFFER",
                    "rom_tag": rom_tag,
                    "source": fname,
                })

        # ── Parse and index TTY Trace ────────────────────────────────────────
        tty = raw.get("TTY_Tail", "")
        if tty:
            trace = parse_tty_trace(tty)
            self._tty_traces[fname] = trace
            for instr in trace:
                pc = instr["pc"]
                if is_kseg0(pc):
                    self._index_address(pc, {
                        "type": "TTY_INSTRUCTION",
                        "mnemonic": instr["mnemonic"],
                        "rom_tag": rom_tag,
                        "source": fname,
                    })
                for reg_name, reg_val in instr["regs"].items():
                    if is_kseg0(reg_val):
                        self._index_address(reg_val, {
                            "type": "TTY_REGISTER",
                            "reg": reg_name,
                            "value": reg_val,
                            "at_pc": pc,
                            "rom_tag": rom_tag,
                            "source": fname,
                        })

    def _index_address(self, addr: int, entry: Dict):
        """Add an entry to the address index."""
        if addr not in self.address_index:
            self.address_index[addr] = []
        self.address_index[addr].append(entry)

    # ── Memory Map Ingestion ─────────────────────────────────────────────────

    def ingest_memory_map(self):
        """Ingest the proven RAM layout into the address index."""
        for addr, (name, desc, rom_tag) in MEMORY_MAP.items():
            self._index_address(addr, {
                "type": "MEMORY_MAP",
                "name": name,
                "desc": desc,
                "rom_tag": rom_tag,
                "source": "UNIFIED_BLUEPRINT",
            })

    def ingest_patch_sites(self):
        """Ingest EXE patch sites into the index."""
        for exe_off, info in EXE_PATCH_SITES.items():
            self.patch_sites[exe_off] = info
            ram = info["ram"]
            if is_kseg0(ram):
                self._index_address(ram, {
                    "type": "PATCH_SITE",
                    "exe_offset": exe_off,
                    "patch": info["patch"],
                    "desc": info["desc"],
                    "rom_tag": "FRANK_v34",
                    "source": "UNIFIED_BLUEPRINT",
                })

    def ingest_crash_events(self):
        """Ingest known crash/stall events as crash vector triples."""
        for evt in KNOWN_CRASH_EVENTS:
            self.crash_vectors.append({
                "type": "CRASH_VECTOR_TRIPLE",
                "event": evt["event"],
                "context_pc": evt["context_pc"],
                "effect": evt["effect"],
                "origin": evt["origin"],
                "source": evt["source"],
                "rom_tag": evt["rom_tag"],
                "lba": evt.get("lba"),
            })
            pc = evt["context_pc"]
            if is_kseg0(pc):
                self._index_address(pc, {
                    "type": "CRASH_CONTEXT",
                    "event": evt["event"],
                    "effect": evt["effect"],
                    "origin": evt["origin"],
                    "rom_tag": evt["rom_tag"],
                    "source": evt["source"],
                })

    def ingest_collision_zones(self):
        """Ingest collision zones into the index."""
        for zone in COLLISION_ZONES:
            self.collision_zones.append(zone)
            if "address" in zone:
                self._index_address(zone["address"], {
                    "type": "COLLISION_ZONE",
                    "name": zone["name"],
                    "desc": zone["desc"],
                    "collides_with": zone["collides_with"],
                    "source": "UNIFIED_BLUEPRINT",
                })
            elif "address_range" in zone:
                start, end = zone["address_range"]
                self._index_address(start, {
                    "type": "COLLISION_ZONE_START",
                    "name": zone["name"],
                    "desc": zone["desc"],
                    "range_end": end,
                    "collides_with": zone["collides_with"],
                    "source": "UNIFIED_BLUEPRINT",
                })
                self._index_address(end, {
                    "type": "COLLISION_ZONE_END",
                    "name": zone["name"],
                    "desc": zone["desc"],
                    "range_start": start,
                    "collides_with": zone["collides_with"],
                    "source": "UNIFIED_BLUEPRINT",
                })

    # ── Query API ─────────────────────────────────────────────────────────────

    def query_address(self, addr: int) -> Dict:
        """
        Query: 'What is at 0x800D9E80?'
        Returns all indexed entries for that address.
        """
        addr = parse_hex(addr) if isinstance(addr, str) else addr
        entries = self.address_index.get(addr, [])

        # Check memory map
        mm_entry = MEMORY_MAP.get(addr)
        map_info = None
        if mm_entry:
            map_info = {"name": mm_entry[0], "desc": mm_entry[1], "rom_tag": mm_entry[2]}

        # Check collision zones
        collisions = []
        for zone in self.collision_zones:
            if "address" in zone and zone["address"] == addr:
                collisions.append(zone)
            elif "address_range" in zone:
                start, end = zone["address_range"]
                if start <= addr <= end:
                    collisions.append(zone)

        # Check patch sites
        patches = []
        for exe_off, info in EXE_PATCH_SITES.items():
            if info["ram"] == addr:
                patches.append({"exe_offset": exe_off, **info})

        # Group entries by type
        by_type: Dict[str, List] = {}
        for e in entries:
            t = e.get("type", "UNKNOWN")
            by_type.setdefault(t, []).append(e)

        return {
            "address": f"0x{addr:08X}",
            "map_info": map_info,
            "collisions": collisions,
            "patch_sites": patches,
            "entries_by_type": by_type,
            "total_entries": len(entries),
            "rom_tags": sorted(set(e.get("rom_tag", "?") for e in entries)),
        }

    def query_crash(self, symptom: str) -> List[Dict]:
        """
        Query: 'Why does GPU stay at 0.00?'
        Searches crash vectors and error signatures for matching symptoms.
        """
        symptom_lower = symptom.lower()
        results = []

        for cv in self.crash_vectors:
            text = f"{cv.get('effect', '')} {cv.get('origin', '')} {cv.get('event', '')} {cv.get('signature', '')} {cv.get('category', '')}".lower()
            if symptom_lower in text or any(w in text for w in symptom_lower.split()):
                results.append(cv)

        # Also check telemetry summaries for matching crash reasons
        for ts in self.telemetry_summaries:
            if ts["crashed"] or ts["frozen"]:
                text = f"{ts.get('crash_reason', '')} {ts.get('pass_status', '')}".lower()
                if symptom_lower in text or any(w in text for w in symptom_lower.split()):
                    results.append({"type": "TELEMETRY_SUMMARY", **ts})

        return results

    def query_pointer_chain(self, addr: int) -> Dict:
        """
        Query: 'What depends on address X?'
        Returns full dependency chain: who writes, who reads, what BIOS calls reference it.
        """
        addr = parse_hex(addr) if isinstance(addr, str) else addr
        entries = self.address_index.get(addr, [])

        writers = [e for e in entries if e.get("type") in ("TTY_REGISTER", "MEMORY_MAP", "PATCH_SITE")]
        readers = [e for e in entries if e.get("type") in ("TTY_INSTRUCTION", "REGISTER", "BIOS_CALL_ARG")]
        bios_refs = [e for e in entries if e.get("type") in ("BIOS_CALL_ARG",)]
        crash_refs = [e for e in entries if e.get("type") in ("CRASH_CONTEXT", "ERROR_PC")]
        collision_refs = [e for e in entries if e.get("type", "").startswith("COLLISION")]

        # Build chain
        chain = []
        mm = MEMORY_MAP.get(addr)
        if mm:
            chain.append({"step": 0, "node": mm[0], "desc": mm[1], "rom_tag": mm[2]})

        for c in collision_refs:
            chain.append({"step": len(chain), "node": "COLLISION", "desc": c.get("desc", ""), "name": c.get("name", "")})

        for w in writers:
            chain.append({"step": len(chain), "node": "WRITE", "source": w.get("source", ""), "rom_tag": w.get("rom_tag", "")})

        for r in readers:
            chain.append({"step": len(chain), "node": "READ", "source": r.get("source", ""), "rom_tag": r.get("rom_tag", "")})

        for c in crash_refs:
            chain.append({"step": len(chain), "node": "CRASH", "event": c.get("event", ""), "effect": c.get("effect", ""), "origin": c.get("origin", "")})

        return {
            "address": f"0x{addr:08X}",
            "chain": chain,
            "total_refs": len(entries),
            "writers": len(writers),
            "readers": len(readers),
            "bios_refs": len(bios_refs),
            "crash_refs": len(crash_refs),
        }

    def query_collisions(self, rom_a: str, rom_b: str) -> List[Dict]:
        """
        Query: 'Where does DQ4 pointer allocation overlap DW7 character subroutine?'
        Returns addresses indexed under both ROM tags.
        """
        results = []
        for addr, entries in self.address_index.items():
            tags = set(e.get("rom_tag", "") for e in entries)
            # Match partial — e.g., "FRANK" matches "FRANK_v34"
            match_a = any(rom_a.lower() in t.lower() for t in tags)
            match_b = any(rom_b.lower() in t.lower() for t in tags)
            if match_a and match_b:
                mm = MEMORY_MAP.get(addr)
                results.append({
                    "address": f"0x{addr:08X}",
                    "name": mm[0] if mm else None,
                    "desc": mm[1] if mm else None,
                    "rom_tags": sorted(tags),
                    "entry_count": len(entries),
                })
        return results

    def query_patch_impact(self, exe_offset: int) -> Dict:
        """
        Query: 'What does patching 0x76B88 affect?'
        Returns what the patch changes and what is impacted.
        """
        exe_offset = parse_hex(exe_offset) if isinstance(exe_offset, str) else exe_offset
        info = self.patch_sites.get(exe_offset)
        if not info:
            return {"error": f"No patch site at EXE offset 0x{exe_offset:X}"}

        ram = info["ram"]
        addr_query = self.query_address(ram)

        # Special analysis for BSS patch
        if exe_offset == 0x76B88:
            return {
                "exe_offset": f"0x{exe_offset:X}",
                "patch": info["patch"],
                "desc": info["desc"],
                "ram_address": f"0x{ram:08X}",
                "impact": {
                    "original_bss_end": f"0x{BSS_CLEAR_END:08X}",
                    "patched_bss_end": "0x800BCCC8",
                    "range_removed": f"0x{BSS_CLEAR_START:08X}–0x800BCCC8 (only 0x600 bytes cleared vs original 0x38318)",
                    "thread_entry_preserved": f"0x{THREAD_ENTRY:08X} is NO LONGER zeroed",
                    "side_effect": "All BSS variables in 0x800BCCC8–0x800F4980 retain their on-disc values instead of being zeroed",
                },
                "address_query": addr_query,
            }

        return {
            "exe_offset": f"0x{exe_offset:X}",
            "patch": info["patch"],
            "desc": info["desc"],
            "ram_address": f"0x{ram:08X}",
            "address_query": addr_query,
        }

    # ── BIOS Relationship Layer ───────────────────────────────────────────────

    def build_bios_relationship_layer(self) -> List[Dict]:
        """Map BIOS calls to RAM addresses and detect collisions with hybrid code."""
        relationships = []
        for call in self.bios_call_map:
            for arg_key in ("a0", "a1", "a2", "a3"):
                addr = call.get(arg_key)
                if is_kseg0(addr):
                    # Check if this address is in a collision zone
                    in_collision = False
                    collision_name = ""
                    for zone in self.collision_zones:
                        if "address" in zone and zone["address"] == addr:
                            in_collision = True
                            collision_name = zone["name"]
                        elif "address_range" in zone:
                            start, end = zone["address_range"]
                            if start <= addr <= end:
                                in_collision = True
                                collision_name = zone["name"]

                    mm = MEMORY_MAP.get(addr)
                    relationships.append({
                        "bios_call": f"{call['table']}:{call['fn']}",
                        "arg": arg_key,
                        "address": f"0x{addr:08X}",
                        "map_name": mm[0] if mm else None,
                        "in_collision_zone": in_collision,
                        "collision_name": collision_name if in_collision else "",
                        "rom_tag": call["rom_tag"],
                        "source": call["source"],
                        "instr_count": call["instr_count"],
                    })
        return relationships

    # ── Build Index ───────────────────────────────────────────────────────────

    def build_index(self, telemetry_dir: str = TELEMETRY_DIR) -> Dict:
        """Full ingestion + index build. Returns the index dict."""
        print("VA-1: Ingesting telemetry files...")
        self.ingest_telemetry_dir(telemetry_dir)

        print("VA-1: Ingesting memory map...")
        self.ingest_memory_map()

        print("VA-1: Ingesting patch sites...")
        self.ingest_patch_sites()

        print("VA-1: Ingesting crash events...")
        self.ingest_crash_events()

        print("VA-1: Ingesting collision zones...")
        self.ingest_collision_zones()

        print("VA-2: Building BIOS relationship layer...")
        bios_relations = self.build_bios_relationship_layer()

        index = {
            "version": "1.0",
            "generated_by": "Agent-VA (Vector Analyst)",
            "address_count": len(self.address_index),
            "telemetry_count": len(self.telemetry_summaries),
            "crash_vector_count": len(self.crash_vectors),
            "bios_call_count": len(self.bios_call_map),
            "bios_relation_count": len(bios_relations),
            "collision_zone_count": len(self.collision_zones),
            "patch_site_count": len(self.patch_sites),
            "rom_tags": sorted(self.rom_tags_seen),
            "memory_map": {f"0x{k:08X}": {"name": v[0], "desc": v[1], "rom_tag": v[2]} for k, v in MEMORY_MAP.items()},
            "patch_sites": {f"0x{k:X}": v for k, v in EXE_PATCH_SITES.items()},
            "collision_zones": self.collision_zones,
            "crash_vectors": self.crash_vectors,
            "bios_relationships": bios_relations,
            "telemetry_summaries": self.telemetry_summaries,
            "pointer_entries": self.pointer_entries,
        }
        return index

    def save_index(self, index: Dict, path: str = INDEX_PATH):
        """Save the index to JSON."""
        with open(path, "w", encoding="utf-8") as f:
            json.dump(index, f, indent=2, ensure_ascii=False)
        size_kb = os.path.getsize(path) / 1024
        print(f"  Index saved: {path} ({size_kb:.1f} KB)")

    def load_index(self, path: str = INDEX_PATH) -> Dict:
        """Load a previously saved index."""
        with open(path, "r", encoding="utf-8") as f:
            return json.load(f)


# ── CLI ───────────────────────────────────────────────────────────────────────

def main():
    import argparse
    parser = argparse.ArgumentParser(description="Vector Allocation Node — Agent-VA")
    parser.add_argument("--build", action="store_true", help="Build vector index from telemetry")
    parser.add_argument("--query-addr", type=str, help="Query an address (hex)")
    parser.add_argument("--query-crash", type=str, help="Query crash symptom")
    parser.add_argument("--query-chain", type=str, help="Query pointer dependency chain for address")
    parser.add_argument("--query-collisions", nargs=2, metavar=("ROM_A", "ROM_B"), help="Query cross-ROM collisions")
    parser.add_argument("--query-patch", type=str, help="Query patch impact for EXE offset (hex)")
    parser.add_argument("--report", action="store_true", help="Generate VECTOR_ANALYSIS_REPORT.md")
    args = parser.parse_args()

    node = VectorNode()

    if args.build:
        index = node.build_index()
        node.save_index(index)
        print(f"\nVA-1 COMPLETE: {index['address_count']} addresses, {index['crash_vector_count']} crash vectors")
        print(f"  ROM tags: {', '.join(index['rom_tags'])}")

    if args.query_addr:
        node.build_index()
        result = node.query_address(args.query_addr)
        print(json.dumps(result, indent=2, default=str))

    if args.query_crash:
        node.build_index()
        results = node.query_crash(args.query_crash)
        print(json.dumps(results, indent=2, default=str))

    if args.query_chain:
        node.build_index()
        result = node.query_pointer_chain(args.query_chain)
        print(json.dumps(result, indent=2, default=str))

    if args.query_collisions:
        node.build_index()
        results = node.query_collisions(args.query_collisions[0], args.query_collisions[1])
        print(json.dumps(results, indent=2, default=str))

    if args.query_patch:
        node.build_index()
        result = node.query_patch_impact(args.query_patch)
        print(json.dumps(result, indent=2, default=str))

    if args.report:
        node.build_index()
        generate_report(node)


def generate_report(node: VectorNode):
    """Generate VECTOR_ANALYSIS_REPORT.md for Agent-CB sync."""
    report_path = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
                               "study", "VECTOR_ANALYSIS_REPORT.md")

    # Run key analyses
    thread_chain = node.query_pointer_chain(THREAD_ENTRY)
    bss_patch = node.query_patch_impact(0x76B88)
    gpu_crash = node.query_crash("GPU 0.00")
    vblank_crash = node.query_crash("VBlank stall")
    bss_collision = node.query_collisions("DW7", "FRANK")

    # Find secondary collisions
    secondary = []
    for zone in node.collision_zones:
        if zone.get("collides_with"):
            secondary.append(zone)

    report = f"""# Vector Analysis Report — Agent-VA Sync Deliverable

**Date:** Jul 19, 2026 | **Agent:** VA (Vector Analyst) | **Sync Target:** Agent-CB

---

## 1. Confirmed Root Cause: BSS Clear vs Thread Entry

**Address:** 0x{THREAD_ENTRY:08X}
**Collision:** BSS clear at 0x8008E284 zeros 0x{BSS_CLEAR_START:08X}–0x{BSS_CLEAR_END:08X}, which includes the CD-ROM thread entry at 0x{THREAD_ENTRY:08X}.

**Dependency Chain:**
"""
    for step in thread_chain["chain"]:
        report += f"  Step {step['step']}: {step.get('node', '?')} — {step.get('desc', step.get('event', ''))}\n"

    report += f"""
**Effect:** CD-ROM thread never starts → game loops in VBlank wait at 0x800986D0 → no display data loaded → GPU stays at 0.00.

**Evidence:** Identical behavior in baseline DW7 and all Frank builds (v38a, v38b, v34).

---

## 2. Recommended Fix: Post-BSS-Clear Injection (Option B)

Use the proven v34 copy routine pattern:
1. Append thread entry code + trampoline to end of EXE (within t_size)
2. Extend the copy routine at PC0 (0x{COPY_ROUTINE_RAM:08X}) to also inject thread code to 0x{THREAD_ENTRY:08X} AFTER BSS clear runs
3. Copy routine already runs before BSS clear — extend it to copy thread code to a safe location, then have BSS clear run, then the thread code gets copied to 0x{THREAD_ENTRY:08X}

**Alternative:** Narrow BSS clear range by patching 0x76B88 (addiu $v0, 0xC668 → 0xCCC8) to stop BSS at 0x800BCCC8 instead of 0x{BSS_CLEAR_END:08X}. This preserves thread entry but leaves BSS variables uninitialized.

**Patch Impact Analysis (0x76B88):**
- Original BSS end: 0x{BSS_CLEAR_END:08X}
- Patched BSS end: 0x800BCCC8
- Range no longer cleared: 0x800BCCC8–0x{BSS_CLEAR_END:08X} ({0x800F4980 - 0x800BCCC8:,} bytes)
- Thread entry 0x{THREAD_ENTRY:08X} PRESERVED
- Risk: BSS variables in skipped range retain on-disc values

---

## 3. Crash Vector Summary

**Total crash vectors indexed:** {len(node.crash_vectors)}

| Event | Context PC | Effect | Origin |
|-------|-----------|--------|--------|
"""
    for cv in node.crash_vectors:
        if cv.get("type") == "CRASH_VECTOR_TRIPLE":
            pc = cv.get("context_pc")
            pc_str = f"0x{pc:08X}" if pc else "—"
            report += f"| {cv['event']} | {pc_str} | {cv['effect']} | {cv['origin']} |\n"

    report += f"""
---

## 4. Collision Zones

"""
    for zone in node.collision_zones:
        if "address" in zone:
            report += f"- **0x{zone['address']:08X}** ({zone['name']}): {zone['desc']} — Collides: {', '.join(zone['collides_with']) or 'none'}\n"
        elif "address_range" in zone:
            s, e = zone["address_range"]
            report += f"- **0x{s:08X}–0x{e:08X}** ({zone['name']}): {zone['desc']} — Collides: {', '.join(zone['collides_with']) or 'none'}\n"

    report += f"""
---

## 5. Cross-ROM Collisions (DW7 vs FRANK)

**Collision addresses:** {len(bss_collision)} addresses indexed under both DW7 and FRANK tags.

Key collisions:
"""
    for c in bss_collision[:10]:
        report += f"- 0x{int(c['address'], 16):08X} — {c.get('name', 'unnamed')}: {c.get('desc', '')}\n"

    report += f"""
---

## 6. BIOS Call Relationship Layer

**Total BIOS calls indexed:** {len(node.bios_call_map)}
**Total relationship mappings:** {len(node.build_bios_relationship_layer())}

Key BIOS calls hitting collision zones:
"""
    bios_rels = node.build_bios_relationship_layer()
    for r in bios_rels:
        if r["in_collision_zone"]:
            report += f"- {r['bios_call']} {r['arg']}=0x{int(r['address'], 16):08X} → COLLISION: {r['collision_name']} ({r['rom_tag']})\n"

    report += f"""
---

## 7. Secondary Collisions Discovered

"""
    # Check for any addresses indexed under multiple FRANK tags that aren't in known collision zones
    multi_tag_addrs = []
    for addr, entries in node.address_index.items():
        tags = set(e.get("rom_tag", "") for e in entries)
        frank_tags = [t for t in tags if t.startswith("FRANK")]
        if len(frank_tags) > 2:
            mm = MEMORY_MAP.get(addr)
            multi_tag_addrs.append((addr, frank_tags, mm))

    if multi_tag_addrs:
        for addr, tags, mm in multi_tag_addrs[:15]:
            name = mm[0] if mm else "unnamed"
            report += f"- 0x{addr:08X} ({name}): seen in {', '.join(sorted(tags))}\n"
    else:
        report += "No unexpected secondary collisions found.\n"

    report += f"""
---

## 8. Index Statistics

- **Addresses indexed:** {len(node.address_index)}
- **Telemetry files:** {len(node.telemetry_summaries)}
- **Crash vectors:** {len(node.crash_vectors)}
- **BIOS calls:** {len(node.bios_call_map)}
- **Collision zones:** {len(node.collision_zones)}
- **Patch sites:** {len(node.patch_sites)}
- **ROM tags:** {', '.join(sorted(node.rom_tags_seen))}

---

## 9. Deliverables for Agent-CB

1. **Primary fix needed:** Post-BSS-clear injection of thread entry code to 0x{THREAD_ENTRY:08X}
   - Use v34 copy routine pattern (proven working)
   - Extend copy routine to copy thread entry stub AFTER BSS clear completes
   - Or: patch BSS clear end at EXE 0x76B88 to stop before 0x{THREAD_ENTRY:08X}

2. **No additional EXE patches needed** — v38 bisection proved all current engine patches are clean

3. **HBD re-encoder still needed** — zero-length tree handling (Agent-CB's track)

4. **Disc extension sectors** — fixed (MODE2 Form1), v36 rebuild required

---

*Generated by Agent-VA (Vector Analyst) — Path A of UNIFIED_BLUEPRINT_Jul19_2026.md*
"""

    with open(report_path, "w", encoding="utf-8") as f:
        f.write(report)
    print(f"\nVA-5: Report saved: {report_path}")


if __name__ == "__main__":
    main()
