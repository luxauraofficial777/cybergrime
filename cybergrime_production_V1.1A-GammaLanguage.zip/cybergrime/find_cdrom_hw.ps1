# The trampoline at 0x800A20F8 is NOT the Setloc BIOS call.
# It does: li t2, 0xB0; jr t2; li t1, 7
# But 0xB0 is the BIOS B0 function table address, and t1=7 is the function number.
# The BIOS B0 table is at address 0x000000B0... that's not right.
# Actually in PSX, the BIOS calls work differently:
# - A0 table at 0xA0, B0 table at 0xB0, C0 table at 0xC0
# These are actual memory addresses in KSEG0 (0x80000000+)
# So jr 0xB0 would jump to address 0x000000B0 which is wrong.
# 
# Actually, the PSX BIOS function tables are at:
# 0xA0 = function pointer table at RAM 0x000000A0 (but this is in the exception vector area)
# No - the convention is:
# - The BIOS function dispatch tables are at fixed RAM addresses
# - A0 table: functions called via jal 0xA0 (which is RAM 0x000000A0)
# - B0 table: functions called via jal 0xB0 (which is RAM 0x000000B0)  
# - C0 table: functions called via jal 0xC0 (which is RAM 0x000000C0)
# The function number is in $t1, and the table at that address has a jump table.
#
# So the trampoline at 0x800A20F8 does:
#   li t2, 0xB0      # B0 function table address
#   jr t2             # jump to 0xB0 (BIOS B0 dispatch)
#   li t1, 7          # function 7 = CDROM_Setloc (delay slot)
#
# But wait - the callers set a0 to things like 0xF0000009 or 0xF4000002
# These are NOT MSF pointers. These look like they're writing to hardware registers.
# 
# Let me re-examine. Maybe 0x800A20F8 is NOT the Setloc trampoline.
# Let me look at what's actually at 0x800A20F8 more carefully.

$exePath = 'c:\LuxAura\VoidWalkers_Project\DQLOSTTRANSLATION\translation\SLUSP012.06'
$bytes = [System.IO.File]::ReadAllBytes($exePath)
$loadAddr = 0x80017F00

# The trampoline at 0x800A20F8:
# 0x800A20F8: li t2, 0xB0    (0x240A00B0)
# 0x800A20FC: jr t2           (0x01400008)
# 0x800A2100: li t1, 7        (0x24090007)  <- delay slot
#
# This jumps to address 0x000000B0. In PSX, the BIOS B0 handler is at 0x000000B0
# in the exception vector area. The function number in t1 selects which B0 function.
# B0 function 7 IS CDROM_Setloc.
#
# BUT the callers set a0 to 0xF0000009, 0xF4000002, etc.
# For CDROM_Setloc, a0 should be a pointer to a 3-byte MSF buffer.
# 0xF0000009 and 0xF4000002 are NOT valid RAM pointers.
#
# Wait - maybe these aren't calling Setloc at all. Maybe the trampoline
# at 0x800A20F8 is used for a DIFFERENT purpose, and the t1=7 is just
# the delay slot value that gets overwritten.
#
# Actually, looking more carefully at the callers:
# Caller at 0x80091C78: ori a0, a0, 0x0009  (a0 was 0xF0000000 from lui)
# Then jal 0x800A20F8 with a1=0x20 (32)
# This looks like it's writing to hardware register 0xF0000009 with value 0x20
# That's NOT a Setloc call.
#
# The trampolines at 0x800A20xx are a BIOS call dispatch table.
# Let me check: is 0x800A20F8 really the Setloc entry?
# The pattern is: li t2, 0xB0; jr t2; li t1, N
# where N is the B0 function number.
# 
# But the callers don't match Setloc semantics.
# Maybe the game doesn't use BIOS B0 for Setloc at all.
# Maybe it writes directly to CDROM hardware registers.
#
# Let me search for writes to 0x1F801AD0-0x1F801AD3 (CDROM registers)
# These would be: sb $rt, offset($rs) where $rs = 0x1F801xxx

# Search for lui $rt, 0x1F80 followed by addiu $rt, $rt, 0x1AD0
Write-Host "=== lui 0x1F80 + addiu 0x1AD0 (CDROM param reg 0) ==="
for ($i = 0x800; $i -lt $bytes.Length - 7; $i += 4) {
    $insn1 = [BitConverter]::ToUInt32($bytes, $i)
    $insn2 = [BitConverter]::ToUInt32($bytes, $i + 4)
    if (($insn1 -shr 26) -eq 0x0F -and ($insn1 -band 0x0000FFFF) -eq 0x1F80) {
        if (($insn2 -band 0x0000FFFF) -eq 0x1AD0 -and (($insn2 -shr 26) -eq 0x09)) {
            $ram = $loadAddr + $i - 0x800
            $rt1 = ($insn1 -shr 16) -band 0x1F
            Write-Host ("  RAM 0x{0:X8}: lui {1},0x1F80 + addiu 0x1AD0" -f $ram, $rn[$rt1])
            # Show next 8 instructions
            for ($k = 2; $k -lt 10; $k++) {
                $off2 = $i + $k * 4
                $val2 = [BitConverter]::ToUInt32($bytes, $off2)
                $ram2 = $loadAddr + $off2 - 0x800
                $op2 = $val2 -shr 26
                $imm2 = $val2 -band 0xFFFF
                $rs2 = ($val2 -shr 21) -band 0x1F; $rt2 = ($val2 -shr 16) -band 0x1F
                $d2 = ''
                if ($val2 -eq 0) { $d2 = 'nop' }
                elseif ($op2 -eq 0x28) { $d2 = "sb $($rn[$rt2]),0x$($imm2.ToString('X4'))($($rn[$rs2]))" }
                elseif ($op2 -eq 0x09) { $d2 = "addiu $($rn[$rt2]),$($rn[$rs2]),$($imm2 -band 0xFFFF)" }
                elseif ($op2 -eq 0x0F) { $d2 = "lui $($rn[$rt2]),0x$($imm2.ToString('X4'))" }
                elseif ($op2 -eq 0x23) { $d2 = "lw $($rn[$rt2]),0x$($imm2.ToString('X4'))($($rn[$rs2]))" }
                elseif ($op2 -eq 0x24) { $d2 = "lbu $($rn[$rt2]),0x$($imm2.ToString('X4'))($($rn[$rs2]))" }
                else { $d2 = "op=0x$($op2.ToString('X2'))" }
                Write-Host ("    0x{0:X8}: 0x{1:X8}  {2}" -f $ram2, $val2, $d2)
            }
        }
    }
}

# Also search for lui 0xBF80 (alternate CDROM base) + addiu 0x1AD0
Write-Host ""
Write-Host "=== lui 0xBF80 + addiu 0x1AD0 ==="
for ($i = 0x800; $i -lt $bytes.Length - 7; $i += 4) {
    $insn1 = [BitConverter]::ToUInt32($bytes, $i)
    $insn2 = [BitConverter]::ToUInt32($bytes, $i + 4)
    if (($insn1 -shr 26) -eq 0x0F -and ($insn1 -band 0x0000FFFF) -eq 0xBF80) {
        if (($insn2 -band 0x0000FFFF) -eq 0x1AD0 -and (($insn2 -shr 26) -eq 0x09)) {
            $ram = $loadAddr + $i - 0x800
            Write-Host ("  RAM 0x{0:X8}: lui 0xBF80 + addiu 0x1AD0" -f $ram)
        }
    }
}

# Search for sb to 0x1AD0-0x1AD3 using any base register
# sb $rt, 0x1AD0($rs) where $rs contains 0x1F801xxx or 0xBF801xxx
# The offset 0x1AD0 is 6864 decimal, fits in 16-bit signed
Write-Host ""
Write-Host "=== sb/sh with offset 0x1AD0-0x1AD3 ==="
for ($i = 0x800; $i -lt $bytes.Length - 3; $i += 4) {
    $insn = [BitConverter]::ToUInt32($bytes, $i)
    $op = $insn -shr 26
    $imm = $insn -band 0xFFFF
    if (($op -eq 0x28 -or $op -eq 0x29) -and $imm -ge 0x1AD0 -and $imm -le 0x1AD3) {
        $ram = $loadAddr + $i - 0x800
        $rs = ($insn -shr 21) -band 0x1F; $rt = ($insn -shr 16) -band 0x1F
        $type = if ($op -eq 0x28) { 'sb' } else { 'sh' }
        # Check if previous instruction loads 0x1F80 into $rs
        $prev = [BitConverter]::ToUInt32($bytes, $i - 4)
        $prevImm = $prev -band 0xFFFF
        if (($prev -shr 26) -eq 0x0F -and ($prevImm -eq 0x1F80 -or $prevImm -eq 0xBF80)) {
            Write-Host ("  RAM 0x{0:X8}: {1} {2},0x{3:X4}({4}) [base=0x{5:X4}]" -f $ram, $type, $rn[$rt], $imm, $rn[$rs], $prevImm)
        }
    }
}
