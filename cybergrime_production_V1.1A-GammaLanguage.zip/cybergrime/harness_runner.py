#!/usr/bin/env python3
"""
harness_runner.py — Python Orchestration Wrapper for PSX Agent Test Harness

Launches psx_agent_runner.exe, captures output, parses telemetry JSON
and emulator_triage.log, and prints a structured JSON summary for Cascade.

Usage:
  # Single test
  python harness_runner.py --disc path/to/iso.bin --profile test_name --max-instrs 200000000

  # Batch mode
  python harness_runner.py --batch profiles.json

  # Compare two runs
  python harness_runner.py --compare telemetry_old.json telemetry_new.json

  # With breakpoints
  python harness_runner.py --disc iso.bin --profile test --bp 0x80078FF4 --bp 0x80078EA4

  # Custom triage log path
  python harness_runner.py --disc iso.bin --profile test --triage custom_triage.log
"""

import argparse
import json
import os
import re
import subprocess
import sys
import time
from pathlib import Path
from typing import Dict, List, Optional, Any


# ── Constants ──────────────────────────────────────────────────────────────────

BASE_DIR = Path(__file__).parent
RUNNER_EXE = BASE_DIR / "psx_agent_runner.exe"
TELEMETRY_DIR = BASE_DIR / "telemetry"
TRIAGE_DIR = BASE_DIR

# DW7 key addresses for memory snapshot interpretation
DW7_KEY_ADDRS = {
    0x800B63D8: "vblank_cnt",
    0x800B5312: "disp_flag",
    0x800B679C: "evt_flag",
    0x800BA294: "vsync_tick",
    0x80026D00: "disc1_name",
    0x80026D10: "disc2_name",
    0x800B91CE: "cd_status",
}

# Freeze type names
FREEZE_TYPES = {
    0: "NONE",
    1: "PC_STUCK",
    2: "TIGHT_LOOP",
    3: "VBLANK_STALL",
}

PASS_STATUSES = {
    0: "RUNNING",
    1: "COMPLETE",
    2: "CRASH",
    3: "FREEZE",
    4: "BOOT_FAIL",
    5: "TIMEOUT",
}


# ── Triage Log Parser ──────────────────────────────────────────────────────────

def parse_triage_log(triage_path: str) -> Dict[str, Any]:
    """Parse emulator_triage.log into a structured dict."""
    result = {
        "triage_file": triage_path,
        "profile": "",
        "disc": "",
        "freeze_type": "UNKNOWN",
        "instruction_count": 0,
        "vblank_count": 0,
        "wall_clock_ms": 0,
        "loop_body": [],
        "registers": {},
        "bios_calls": [],
        "vfs_accesses": [],
        "memory_snapshot": {},
        "console_tail": "",
    }

    if not os.path.exists(triage_path):
        result["error"] = f"Triage log not found: {triage_path}"
        return result

    with open(triage_path, "r", encoding="utf-8", errors="replace") as f:
        content = f.read()

    # Parse header
    result["profile"] = _extract_field(content, r"Profile:\s*(.+)")
    result["disc"] = _extract_field(content, r"Disc:\s*(.+)")
    result["freeze_type"] = _extract_field(content, r"Freeze Type:\s*(\w+)", "UNKNOWN")
    result["instruction_count"] = _extract_int(content, r"Instruction count:\s*(\d+)")
    result["vblank_count"] = _extract_int(content, r"VBlank count:\s*(\d+)")
    result["wall_clock_ms"] = _extract_int(content, r"Wall-clock time:\s*(\d+)")

    # Parse loop body
    loop_section = _extract_section(content, "=== FREEZE DETECTION ===", "\n\n")
    if loop_section:
        for match in re.finditer(
            r"(0x[0-9A-Fa-f]+):\s+([0-9A-Fa-f]{8})\s+(.+)", loop_section
        ):
            result["loop_body"].append({
                "pc": match.group(1),
                "raw": match.group(2),
                "instruction": match.group(3).strip(),
            })

    # Parse registers
    reg_section = _extract_section(content, "=== REGISTER DUMP ===", "\n\n")
    if reg_section:
        for match in re.finditer(
            r"\$(\w+):\s*(0x[0-9A-Fa-f]+)", reg_section
        ):
            result["registers"][match.group(1)] = match.group(2)
        # Also catch PC, CP0
        for match in re.finditer(
            r"(PC|CP0 Status|Cause|EPC):\s*(0x[0-9A-Fa-f]+)", reg_section
        ):
            result["registers"][match.group(1).replace(" ", "_")] = match.group(2)

    # Parse BIOS calls
    bios_section = _extract_section(content, "=== LAST BIOS CALLS ===", "\n\n")
    if bios_section:
        for match in re.finditer(
            r"#(\d+)\s+([ABC]):(0x[0-9A-Fa-f]+)\s+\$ra=(0x[0-9A-Fa-f]+)"
            r"\s+a0=(0x[0-9A-Fa-f]+)\s+a1=(0x[0-9A-Fa-f]+)"
            r"\s+a2=(0x[0-9A-Fa-f]+)\s+a3=(0x[0-9A-Fa-f]+)",
            bios_section,
        ):
            result["bios_calls"].append({
                "instr_count": int(match.group(1)),
                "table": match.group(2),
                "function": match.group(3),
                "ra": match.group(4),
                "a0": match.group(5),
                "a1": match.group(6),
                "a2": match.group(7),
                "a3": match.group(8),
            })

    # Parse VFS accesses
    vfs_section = _extract_section(content, "=== VFS ACCESSES", "\n\n")
    if vfs_section:
        for match in re.finditer(
            r"\[(\d+)\]\s+(\S+)\s+LBA=(\d+)\s+size=(\d+)\s+resolved=(\w+)"
            r"\s+pc=(0x[0-9A-Fa-f]+)",
            vfs_section,
        ):
            result["vfs_accesses"].append({
                "index": int(match.group(1)),
                "resource": match.group(2),
                "lba": int(match.group(3)),
                "size": int(match.group(4)),
                "resolved": match.group(5) == "YES",
                "pc": match.group(6),
            })

    # Parse memory snapshot
    mem_section = _extract_section(content, "=== MEMORY SNAPSHOT", "\n\n")
    if mem_section:
        for match in re.finditer(
            r"(0x[0-9A-Fa-f]+)\s+\((\w+)\):\s+([0-9A-Fa-f ]+)\s+\"([^\"]*)\"",
            mem_section,
        ):
            result["memory_snapshot"][match.group(2)] = {
                "addr": match.group(1),
                "hex": match.group(3).strip(),
                "ascii": match.group(4),
            }

    # Parse console tail
    console_section = _extract_section(content, "=== CONSOLE OUTPUT", "=== END TRIAGE")
    if console_section:
        result["console_tail"] = console_section.strip()

    return result


def _extract_field(content: str, pattern: str, default: str = "") -> str:
    match = re.search(pattern, content)
    return match.group(1).strip() if match else default


def _extract_int(content: str, pattern: str) -> int:
    match = re.search(pattern, content)
    return int(match.group(1)) if match else 0


def _extract_section(content: str, start_marker: str, end_marker: str) -> str:
    start_idx = content.find(start_marker)
    if start_idx == -1:
        return ""
    start_idx += len(start_marker)
    end_idx = content.find(end_marker, start_idx)
    if end_idx == -1:
        end_idx = len(content)
    return content[start_idx:end_idx]


# ── Telemetry JSON Parser ──────────────────────────────────────────────────────

def parse_telemetry(json_path: str) -> Dict[str, Any]:
    """Parse telemetry JSON file."""
    if not os.path.exists(json_path):
        return {"error": f"Telemetry file not found: {json_path}"}

    with open(json_path, "r", encoding="utf-8", errors="replace") as f:
        return json.load(f)


# ── Patch Verification ─────────────────────────────────────────────────────────

def verify_patches(disc_path: str, patch_spec_path: str) -> Dict[str, Any]:
    """Verify that expected patch bytes are at the correct offsets in the ISO."""
    result = {"verified": 0, "failed": 0, "details": []}

    if not os.path.exists(patch_spec_path):
        result["error"] = f"Patch spec not found: {patch_spec_path}"
        return result

    with open(patch_spec_path, "r") as f:
        spec = json.load(f)

    if not os.path.exists(disc_path):
        result["error"] = f"Disc not found: {disc_path}"
        return result

    with open(disc_path, "rb") as f:
        disc_data = f.read()

    patches = spec.get("patches", spec) if isinstance(spec, dict) else spec
    if isinstance(patches, dict):
        patches = patches.get("patches", [])

    for patch in patches:
        offset = patch.get("offset", patch.get("exe_offset", 0))
        expected = patch.get("patched_bytes", patch.get("bytes", ""))
        desc = patch.get("description", patch.get("name", f"offset_{offset}"))

        if isinstance(expected, str):
            expected_bytes = bytes.fromhex(expected.replace(" ", ""))
        elif isinstance(expected, list):
            expected_bytes = bytes(expected)
        else:
            continue

        actual = disc_data[offset:offset + len(expected_bytes)]
        match = actual == expected_bytes

        result["details"].append({
            "name": desc,
            "offset": f"0x{offset:X}",
            "expected": expected_bytes.hex(),
            "actual": actual.hex(),
            "match": match,
        })

        if match:
            result["verified"] += 1
        else:
            result["failed"] += 1

    return result


# ── Telemetry Diff ─────────────────────────────────────────────────────────────

def diff_telemetry(old_path: str, new_path: str) -> Dict[str, Any]:
    """Compare two telemetry JSON files to identify what changed."""
    old = parse_telemetry(old_path)
    new = parse_telemetry(new_path)

    diff = {
        "old_profile": old.get("Profile_Name", ""),
        "new_profile": new.get("Profile_Name", ""),
        "changes": [],
        "unchanged": [],
    }

    # Compare key fields
    fields_to_compare = [
        "Pass_Status", "Instructions_Executed", "VBlank_Count",
        "Last_Known_PC", "Crashed", "Frozen", "Crash_Reason",
    ]

    for field in fields_to_compare:
        old_val = old.get(field)
        new_val = new.get(field)
        if old_val != new_val:
            diff["changes"].append({
                "field": field,
                "old": old_val,
                "new": new_val,
            })
        else:
            diff["unchanged"].append(field)

    # Compare register dumps
    old_regs = old.get("Register_Dump", {})
    new_regs = new.get("Register_Dump", {})
    for reg in ["PC", "v0", "v1", "a0", "a1", "ra", "sp"]:
        old_val = old_regs.get(reg)
        new_val = new_regs.get(reg)
        if old_val and new_val and old_val != new_val:
            diff["changes"].append({
                "field": f"Register_{reg}",
                "old": old_val,
                "new": new_val,
            })

    # Compare VFS access counts
    old_vfs = old.get("Asset_Load_History", [])
    new_vfs = new.get("Asset_Load_History", [])
    if len(old_vfs) != len(new_vfs):
        diff["changes"].append({
            "field": "VFS_Access_Count",
            "old": len(old_vfs),
            "new": len(new_vfs),
        })

    # Check for new VFS accesses
    old_resources = {v.get("resource_id") for v in old_vfs}
    new_resources = {v.get("resource_id") for v in new_vfs}
    new_only = new_resources - old_resources
    if new_only:
        diff["changes"].append({
            "field": "New_VFS_Accesses",
            "old": [],
            "new": list(new_only),
        })

    # Compare error signatures
    old_errors = old.get("Error_Signature", [])
    new_errors = new.get("Error_Signature", [])
    if len(old_errors) != len(new_errors):
        diff["changes"].append({
            "field": "Error_Count",
            "old": len(old_errors),
            "new": len(new_errors),
        })

    return diff


# ── Single Test Runner ─────────────────────────────────────────────────────────

def run_single_test(
    disc: str,
    profile: str,
    max_instrs: int = 200000000,
    wallclock_ms: int = 0,
    breakpoints: List[str] = None,
    triage_path: str = None,
    json_path: str = None,
    patch_spec: str = None,
    trace_from: str = None,
    trace_to: str = None,
    huffman_trace: bool = False,
) -> Dict[str, Any]:
    """Run a single emulator test and return structured results."""

    # Ensure directories exist
    TELEMETRY_DIR.mkdir(exist_ok=True)

    # Set default paths
    if not json_path:
        json_path = str(TELEMETRY_DIR / f"telemetry_{profile}.json")
    if not triage_path:
        triage_path = str(TRIAGE_DIR / f"emulator_triage_{profile}.log")

    # Pre-test: verify patches if spec provided
    patch_result = None
    if patch_spec:
        patch_result = verify_patches(disc, patch_spec)

    # Build command
    cmd = [str(RUNNER_EXE), disc, profile, str(max_instrs), json_path]
    if wallclock_ms > 0:
        cmd.append(str(wallclock_ms))
    else:
        cmd.append("0")

    # Add triage path
    cmd.extend(["--triage", triage_path])

    # Add breakpoints
    if breakpoints:
        for bp in breakpoints:
            cmd.extend(["--bp", bp])

    # Add trace flags
    if trace_from:
        cmd.extend(["--trace-from", trace_from])
    if trace_to:
        cmd.extend(["--trace-to", trace_to])
    if huffman_trace:
        cmd.append("--huffman-trace")

    print(f"[HARNESS] Launching: {' '.join(cmd)}")
    print(f"[HARNESS] Disc: {disc}")
    print(f"[HARNESS] Profile: {profile}")
    print(f"[HARNESS] Max instrs: {max_instrs}")
    print(f"[HARNESS] Triage log: {triage_path}")
    print(f"[HARNESS] Telemetry: {json_path}")
    if patch_result:
        print(f"[HARNESS] Patches: {patch_result['verified']} verified, {patch_result['failed']} failed")
    print()

    # Run emulator
    start_time = time.time()
    try:
        proc = subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            timeout=600 if wallclock_ms == 0 else (wallclock_ms // 1000) + 120,
        )
        stdout = proc.stdout
        stderr = proc.stderr
        exit_code = proc.returncode
    except subprocess.TimeoutExpired as e:
        stdout = e.stdout or "" if isinstance(e.stdout, str) else ""
        stderr = e.stderr or "" if isinstance(e.stderr, str) else ""
        exit_code = -1
    elapsed = time.time() - start_time

    print(f"[HARNESS] Emulator exited with code {exit_code} ({elapsed:.1f}s)")
    if stderr:
        print(f"[HARNESS] stderr: {stderr[:500]}")

    # Parse outputs
    triage = parse_triage_log(triage_path)
    telemetry = parse_telemetry(json_path)

    # Parse assertions from telemetry
    assertions = telemetry.get("Assertions", [])
    assert_fail = telemetry.get("Assert_Fail", False)
    assert_count = telemetry.get("Assert_Count", 0)
    assert_fail_count = telemetry.get("Assert_Fail_Count", 0)
    hw_state = telemetry.get("HW_State", {})

    # Build structured summary for Cascade
    summary = {
        "profile": profile,
        "disc": disc,
        "exit_code": exit_code,
        "elapsed_seconds": round(elapsed, 1),
        "status": telemetry.get("Pass_Status", "UNKNOWN"),
        "frozen": telemetry.get("Frozen", False),
        "crashed": telemetry.get("Crashed", False),
        "instruction_count": telemetry.get("Instructions_Executed", 0),
        "vblank_count": telemetry.get("VBlank_Count", 0),
        "last_pc": telemetry.get("Last_Known_PC", "0x00000000"),
        "freeze_type": triage.get("freeze_type", "NONE"),
        "freeze_pc": triage.get("registers", {}).get("PC", ""),
        "v0_at_freeze": triage.get("registers", {}).get("v0", ""),
        "v1_at_freeze": triage.get("registers", {}).get("v1", ""),
        "loop_body": triage.get("loop_body", []),
        "bios_calls_count": len(triage.get("bios_calls", [])),
        "vfs_accesses_count": len(triage.get("vfs_accesses", [])),
        "triage_log": triage_path,
        "telemetry_json": json_path,
        # QA-Master assertion fields
        "assert_fail": assert_fail,
        "assert_count": assert_count,
        "assert_fail_count": assert_fail_count,
        "assertions": assertions,
        # HW state for CD-ROM pipeline checks
        "cdrom_reading": hw_state.get("cdrom_reading", False),
        "cdrom_sectors_read": hw_state.get("cdrom_sectors_read", 0),
        "cdrom_cur_lba": hw_state.get("cdrom_cur_lba", 0),
        "cdrom_data_ready": hw_state.get("cdrom_data_ready", False),
    }

    if patch_result:
        summary["patch_verification"] = {
            "verified": patch_result["verified"],
            "failed": patch_result["failed"],
        }

    # Print assertion summary if any fired
    if assertions:
        print(f"\n[HARNESS] Assertions: {assert_count} total, {assert_fail_count} failures")
        for a in assertions:
            sev = a.get("severity", "?")
            name = a.get("name", "?")
            detail = a.get("detail", "")
            marker = " *** FAIL ***" if sev in ("FAIL", "PARITY") else ""
            print(f"  [{sev}] {name}: {detail}{marker}")

    # Print JSON summary
    print("\n" + "=" * 60)
    print("HARNESS SUMMARY (JSON for Cascade)")
    print("=" * 60)
    print(json.dumps(summary, indent=2))
    print("=" * 60)

    return summary


# ── Batch Runner ───────────────────────────────────────────────────────────────

def run_batch(batch_path: str, max_instrs: int = 200000000, wallclock_ms: int = 300000) -> List[Dict]:
    """Run multiple test profiles from a JSON config file."""
    with open(batch_path, "r") as f:
        config = json.load(f)

    profiles = config.get("profiles", [])
    results = []

    print(f"[HARNESS] Batch mode: {len(profiles)} profiles")
    print()

    for i, profile in enumerate(profiles):
        name = profile.get("name", f"test_{i}")
        disc = profile.get("disc", "")
        bp = profile.get("breakpoints", [])
        patch = profile.get("patch_spec", None)

        if not os.path.exists(disc):
            print(f"[{i+1}/{len(profiles)}] SKIP: {name} — disc not found: {disc}")
            results.append({"profile": name, "status": "SKIP", "reason": "disc not found"})
            continue

        print(f"[{i+1}/{len(profiles)}] Running: {name}")
        result = run_single_test(
            disc=disc,
            profile=name,
            max_instrs=profile.get("max_instrs", max_instrs),
            wallclock_ms=profile.get("wallclock_ms", wallclock_ms),
            breakpoints=bp,
            patch_spec=patch,
        )
        results.append(result)
        print()

    # Print batch summary
    print("\n" + "=" * 60)
    print("BATCH SUMMARY")
    print("=" * 60)
    for r in results:
        status = r.get("status", "UNKNOWN")
        pc = r.get("last_pc", "")
        vb = r.get("vblank_count", 0)
        ic = r.get("instruction_count", 0)
        ft = r.get("freeze_type", "")
        print(f"  {r['profile']:20s} | {status:10s} | PC={pc} | VB={vb} | instr={ic} | {ft}")
    print("=" * 60)

    return results


# ── Manifest-Driven Test Runner (QA-Master) ────────────────────────────────────

def validate_test_result(result: Dict, expected: Dict) -> Dict[str, Any]:
    """Validate a test result against expected outcomes from the manifest."""
    issues = []
    passed = []

    # Check pass status
    expected_status = expected.get("pass_status", "COMPLETE")
    if isinstance(expected_status, str):
        expected_status = [expected_status]
    actual_status = result.get("status", "UNKNOWN")
    if actual_status not in expected_status:
        issues.append(f"PASS_STATUS mismatch: expected {expected_status}, got {actual_status}")
    else:
        passed.append(f"PASS_STATUS={actual_status}")

    # Check min VBlanks
    min_vb = expected.get("min_vblanks", 0)
    actual_vb = result.get("vblank_count", 0)
    if actual_vb < min_vb:
        issues.append(f"VBlank count too low: expected >={min_vb}, got {actual_vb}")
    else:
        passed.append(f"VBlanks={actual_vb}>={min_vb}")

    # Check assertion failures
    if expected.get("assert_fail", False) is False:
        if result.get("assert_fail", False):
            issues.append(f"ASSERT_FAIL: {result.get('assert_fail_count', 0)} assertion failures detected")
        else:
            passed.append("No assertion failures")

    # Check required assertions fired
    required = expected.get("required_assertions", [])
    assertion_names = {a.get("name", "") for a in result.get("assertions", [])}
    for req in required:
        if req not in assertion_names:
            issues.append(f"Required assertion not fired: {req}")
        else:
            passed.append(f"Required assertion fired: {req}")

    # Check forbidden assertions did NOT fire
    forbidden = expected.get("forbidden_assertions", [])
    for forb in forbidden:
        if forb in assertion_names:
            issues.append(f"Forbidden assertion fired: {forb}")

    # Check min CD-ROM sectors read
    min_sectors = expected.get("min_cdrom_sectors_read", 0)
    actual_sectors = result.get("cdrom_sectors_read", 0)
    if min_sectors > 0 and actual_sectors < min_sectors:
        issues.append(f"CD-ROM sectors read too low: expected >={min_sectors}, got {actual_sectors}")
    elif min_sectors > 0:
        passed.append(f"CD-ROM sectors={actual_sectors}>={min_sectors}")

    return {
        "passed": passed,
        "issues": issues,
        "verdict": "PASS" if not issues else "FAIL",
    }


def run_manifest(manifest_path: str, phase_filter: int = None) -> Dict[str, Any]:
    """Run the full QA-Master test manifest with automated validation."""
    with open(manifest_path, "r") as f:
        manifest = json.load(f)

    global_settings = manifest.get("global_settings", {})
    abort_on_fail = global_settings.get("abort_on_first_fail", True)

    phases = manifest.get("phases", [])
    all_results = []
    all_verdicts = []

    print(f"\n{'='*60}")
    print(f"QA-MASTER: Running test manifest: {manifest_path}")
    print(f"Phases: {len(phases)}, Abort on fail: {abort_on_fail}")
    print(f"{'='*60}\n")

    for phase in phases:
        phase_num = phase.get("phase", 0)
        phase_name = phase.get("name", f"Phase {phase_num}")

        if phase_filter is not None and phase_num != phase_filter:
            continue

        print(f"\n--- Phase {phase_num}: {phase_name} ---")
        print(f"    {phase.get('description', '')}\n")

        tests = phase.get("tests", [])
        for i, test in enumerate(tests):
            name = test.get("name", f"test_{i}")
            disc = test.get("disc", "")

            if not os.path.exists(disc):
                print(f"  [{i+1}/{len(tests)}] SKIP: {name} — disc not found")
                all_results.append({"profile": name, "status": "SKIP", "reason": "disc not found"})
                continue

            print(f"  [{i+1}/{len(tests)}] Running: {name}")

            result = run_single_test(
                disc=disc,
                profile=name,
                max_instrs=test.get("max_instrs", 200000000),
                wallclock_ms=test.get("wallclock_ms", global_settings.get("wallclock_ms", 300000)),
                breakpoints=test.get("breakpoints", []),
            )

            # Validate against expected outcomes
            expected = test.get("expected", {})
            validation = validate_test_result(result, expected)

            result["validation"] = validation
            result["phase"] = phase_num
            result["phase_name"] = phase_name
            all_results.append(result)
            all_verdicts.append(validation["verdict"])

            # Print validation
            if validation["verdict"] == "PASS":
                print(f"  VERDICT: PASS")
                for p in validation["passed"]:
                    print(f"    + {p}")
            else:
                print(f"  VERDICT: *** FAIL ***")
                for issue in validation["issues"]:
                    print(f"    ! {issue}")
                for p in validation["passed"]:
                    print(f"    + {p}")

                if abort_on_fail:
                    print(f"\n  *** ABORTING: abort_on_first_fail=True ***")
                    print(f"  Failed test: {name}")
                    print(f"  Telemetry: {result.get('telemetry_json', '')}")
                    print(f"  Triage: {result.get('triage_log', '')}")
                    if result.get("assertions"):
                        print(f"  Assertions:")
                        for a in result["assertions"]:
                            print(f"    [{a.get('severity')}] {a.get('name')}: {a.get('detail')}")
                    return {"results": all_results, "aborted": True, "failed_test": name}

            print()

    # Final summary
    pass_count = sum(1 for v in all_verdicts if v == "PASS")
    fail_count = sum(1 for v in all_verdicts if v == "FAIL")
    skip_count = sum(1 for r in all_results if r.get("status") == "SKIP")

    print(f"\n{'='*60}")
    print(f"QA-MASTER FINAL SUMMARY")
    print(f"{'='*60}")
    print(f"  Total tests: {len(all_results)}")
    print(f"  PASS: {pass_count}  FAIL: {fail_count}  SKIP: {skip_count}")
    print(f"  Verdict: {'ALL PASS' if fail_count == 0 else 'HAS FAILURES'}")
    print()
    for r in all_results:
        v = r.get("validation", {}).get("verdict", "?")
        status = r.get("status", "?")
        name = r.get("profile", "?")
        phase = r.get("phase", "?")
        marker = "" if v == "PASS" else " *** FAIL ***"
        print(f"  Phase {phase} | {name:25s} | {status:10s} | {v}{marker}")
    print(f"{'='*60}")

    return {"results": all_results, "aborted": False, "pass": pass_count, "fail": fail_count, "skip": skip_count}


# ── Main ───────────────────────────────────────────────────────────────────────

def main():
    parser = argparse.ArgumentParser(
        description="PSX Agent Test Harness — Python Orchestration Wrapper"
    )

    # Single test mode
    parser.add_argument("--disc", help="Path to ISO .bin file")
    parser.add_argument("--profile", help="Test profile name")
    parser.add_argument("--max-instrs", type=int, default=200000000, help="Max instructions (default: 200M)")
    parser.add_argument("--wallclock", type=int, default=0, help="Wall-clock timeout in ms (0=none)")
    parser.add_argument("--bp", action="append", help="Breakpoint address (can repeat)")
    parser.add_argument("--triage", help="Custom triage log path")
    parser.add_argument("--json", help="Custom telemetry JSON path")
    parser.add_argument("--patch-spec", help="Patch spec JSON for pre-test verification")

    # Batch mode
    parser.add_argument("--batch", help="Batch config JSON file")

    # QA-Master manifest mode
    parser.add_argument("--manifest", help="QA-Master test manifest JSON file")
    parser.add_argument("--phase", type=int, default=None, help="Run only a specific phase from the manifest")

    # Trace flags
    parser.add_argument("--trace-from", help="Start instruction trace at this PC address")
    parser.add_argument("--trace-to", help="Output file for instruction trace")
    parser.add_argument("--huffman-trace", action="store_true", help="Enable Huffman decompression trace (breakpoints at 0x80073670, 0x80084BF0)")

    # Compare mode
    parser.add_argument("--compare", nargs=2, metavar=("OLD", "NEW"), help="Compare two telemetry JSON files")

    args = parser.parse_args()

    # Compare mode
    if args.compare:
        diff = diff_telemetry(args.compare[0], args.compare[1])
        print(json.dumps(diff, indent=2))
        return

    # QA-Master manifest mode
    if args.manifest:
        results = run_manifest(args.manifest, args.phase)
        sys.exit(0 if results.get("fail", 0) == 0 and not results.get("aborted") else 1)
        return

    # Batch mode
    if args.batch:
        run_batch(args.batch, args.max_instrs, args.wallclock)
        return

    # Single test mode
    if not args.disc or not args.profile:
        parser.error("--disc and --profile are required for single test mode")

    run_single_test(
        disc=args.disc,
        profile=args.profile,
        max_instrs=args.max_instrs,
        wallclock_ms=args.wallclock,
        breakpoints=args.bp,
        triage_path=args.triage,
        json_path=args.json,
        patch_spec=args.patch_spec,
        trace_from=args.trace_from,
        trace_to=args.trace_to,
        huffman_trace=args.huffman_trace,
    )


if __name__ == "__main__":
    main()
