#!/usr/bin/env python3
"""Verify FMV stubs in disc EXE by reading sector-by-sector."""
import struct, sys

SECTOR_SIZE = 2352
DATA_OFFSET = 24
USER_SIZE = 2048

def read_sector_user(f, lba):
    f.seek(lba * SECTOR_SIZE + DATA_OFFSET)
    return f.read(USER_SIZE)

def main():
    disc = sys.argv[1] if len(sys.argv) > 1 else r"C:\LuxAura\VoidWalkers_Project\DQLOSTTRANSLATION\build_staging\dq4_reverse_a.bin"
    exe_lba = 24
    exe_size = 678496
    
    with open(disc, 'rb') as f:
        # Read EXE sector by sector
        exe_data = bytearray()
        sectors_needed = (exe_size + USER_SIZE - 1) // USER_SIZE
        for i in range(sectors_needed):
            chunk = read_sector_user(f, exe_lba + i)
            exe_data.extend(chunk)
        exe_data = exe_data[:exe_size]
        
        # Parse header
        magic = exe_data[0:8]
        load_addr = struct.unpack_from('<I', exe_data, 0x18)[0]
        pc0 = struct.unpack_from('<I', exe_data, 0x10)[0]
        text_sz = struct.unpack_from('<I', exe_data, 0x1C)[0]
        print(f"EXE: magic={magic} load_addr=0x{load_addr:08X} pc0=0x{pc0:08X} text_sz=0x{text_sz:08X}")
        print(f"EXE size on disc: {len(exe_data)} bytes")
        
        # Check FMV stubs
        stubs = [(0x8008AEF4, "fmv1"), (0x8008CAD0, "fmv2")]
        expected = (0x24020000, 0x03E00008, 0x00000000)
        for ram, name in stubs:
            off = ram - load_addr + 0x800
            if off + 12 <= len(exe_data):
                words = struct.unpack_from('<III', exe_data, off)
                match = words == expected
                print(f"  {name} at RAM 0x{ram:08X} (offset 0x{off:X}): {'STUB OK' if match else 'NOT STUBBED'}")
                print(f"    words: 0x{words[0]:08X} 0x{words[1]:08X} 0x{words[2]:08X}")
                if not match:
                    print(f"    expected: 0x{expected[0]:08X} 0x{expected[1]:08X} 0x{expected[2]:08X}")
            else:
                print(f"  {name}: offset 0x{off:X} beyond EXE")
        
        # Also check what the original EXE has at these addresses
        print(f"\n  For reference, original DW7 EXE:")
        orig_path = r"C:\LuxAura\VoidWalkers_Project\DQLOSTTRANSLATION\translation\SLUSP012.06_clean.bin"
        with open(orig_path, 'rb') as fo:
            orig = fo.read()
            orig_load = struct.unpack_from('<I', orig, 0x18)[0]
            for ram, name in stubs:
                off = ram - orig_load + 0x800
                words = struct.unpack_from('<III', orig, off)
                print(f"    {name}: 0x{words[0]:08X} 0x{words[1]:08X} 0x{words[2]:08X}")

if __name__ == '__main__':
    main()
