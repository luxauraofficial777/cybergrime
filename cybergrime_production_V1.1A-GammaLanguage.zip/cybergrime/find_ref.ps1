# Search for code that references address 0x800AA036 (where the BCD MSF is)
# Pattern 1: lui $rt, 0x800B; addiu $rt, $rs, 0xA036
#   lui: 0x3C??000B  (?? = register * 256, e.g. 08=t0, 09=t1, 0A=t2...)
#   addiu: 0x24/25/26/27/28/29/2A/2B...A036 (opcode 0x09 = addiu, rs field varies)
# Pattern 2: lui $rt, 0x800A; ori $rt, $rt, 0xA036
#   lui: 0x3C??000A
#   ori: 0x34/35/36...A036 (opcode 0x0D = ori)

$exePath = 'c:\LuxAura\VoidWalkers_Project\DQLOSTTRANSLATION\translation\SLUSP012.06'
$bytes = [System.IO.File]::ReadAllBytes($exePath)
$loadAddr = 0x80017F00

Write-Host "=== Search for lui \$rt, 0x800B followed by addiu \$rt, \$rs, 0xA036 ==="
for ($i = 0x800; $i -lt $bytes.Length - 7; $i += 4) {
    $insn1 = [BitConverter]::ToUInt32($bytes, $i)
    $insn2 = [BitConverter]::ToUInt32($bytes, $i + 4)
    
    # lui $rt, 0x800B: opcode=0x0F, immediate=0x800B
    # 0x3C??000B where ?? = rt << 16
    if (($insn1 -band 0xFFFF0000) -eq 0x3C00000B -or
        (($insn1 -band 0xFFE0FFFF) -eq 0x3C00000B)) {
        # Check if next instruction is addiu with immediate 0xA036
        if (($insn2 -band 0x0000FFFF) -eq 0x0000A036 -and
            (($insn2 -shr 26) -eq 0x09)) {
            $rt1 = ($insn1 -shr 16) -band 0x1F
            $rt2 = ($insn2 -shr 16) -band 0x1F
            $rs2 = ($insn2 -shr 21) -band 0x1F
            $ram = $loadAddr + $i - 0x800
            Write-Host ("  FOUND at RAM 0x{0:X8}: lui ${rt1},0x800B (0x{1:X8}) + addiu ${rt2},${rs2},0xA036 (0x{2:X8})" -f $ram, $insn1, $insn2)
        }
    }
}

Write-Host ""
Write-Host "=== Search for lui \$rt, 0x800A followed by ori \$rt, \$rt, 0xA036 ==="
for ($i = 0x800; $i -lt $bytes.Length - 7; $i += 4) {
    $insn1 = [BitConverter]::ToUInt32($bytes, $i)
    $insn2 = [BitConverter]::ToUInt32($bytes, $i + 4)
    
    if (($insn1 -band 0xFFE0FFFF) -eq 0x3C00000A) {
        if (($insn2 -band 0x0000FFFF) -eq 0x0000A036 -and
            (($insn2 -shr 26) -eq 0x0D)) {
            $rt1 = ($insn1 -shr 16) -band 0x1F
            $rt2 = ($insn2 -shr 16) -band 0x1F
            $rs2 = ($insn2 -shr 21) -band 0x1F
            $ram = $loadAddr + $i - 0x800
            Write-Host ("  FOUND at RAM 0x{0:X8}: lui ${rt1},0x800A (0x{1:X8}) + ori ${rt2},${rs2},0xA036 (0x{2:X8})" -f $ram, $insn1, $insn2)
        }
    }
}

# Also search for the immediate value 0xA036 in any addiu/ori (regardless of preceding lui)
Write-Host ""
Write-Host "=== All instructions with immediate 0xA036 ==="
for ($i = 0x800; $i -lt $bytes.Length - 3; $i += 4) {
    $insn = [BitConverter]::ToUInt32($bytes, $i)
    if (($insn -band 0x0000FFFF) -eq 0x0000A036) {
        $ram = $loadAddr + $i - 0x800
        $prev = [BitConverter]::ToUInt32($bytes, $i - 4)
        Write-Host ("  RAM 0x{0:X8}: 0x{1:X8} (prev=0x{2:X8})" -f $ram, $insn, $prev)
    }
}

# Also search for 0x800B in lui (to find nearby table references)
Write-Host ""
Write-Host "=== All lui with immediate 0x800B near offset 0x92936 (±512) ==="
$center = 0x92936
for ($i = $center - 512; $i -le $center + 512; $i += 4) {
    if ($i -lt 0x800 -or $i -ge $bytes.Length - 3) { continue }
    $insn = [BitConverter]::ToUInt32($bytes, $i)
    if (($insn -band 0xFFFF0000) -eq 0x3C00000B -or
        (($insn -shr 26) -eq 0x0F -and ($insn -band 0x0000FFFF) -eq 0x800B)) {
        $rt = ($insn -shr 16) -band 0x1F
        $ram = $loadAddr + $i - 0x800
        $next = [BitConverter]::ToUInt32($bytes, $i + 4)
        Write-Host ("  RAM 0x{0:X8}: lui ${rt},0x800B (0x{1:X8}) next=0x{2:X8}" -f $ram, $insn, $next)
    }
}
