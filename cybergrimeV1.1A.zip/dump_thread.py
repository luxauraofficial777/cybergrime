import struct

addr_base = 0x800D9E80
target = 0x800D9F34
f = open('thread_code_blob.bin', 'rb')
data = f.read()
f.close()

off = target - addr_base
start = max(0, off - 16)
end = min(len(data) - 4, off + 32)

for i in range(start, end, 4):
    val = struct.unpack_from('<I', data, i)[0]
    addr = addr_base + i
    print(f"0x{addr:08X}: 0x{val:08X}")
