#include "agent_harness.h"
#include "psx_test_station.h"
#include "txrt_hle.h"
#include "orchestration_engine.h"
#include "psx_reference_integrations.h"
#include "psx_spu.h"
#include "psx_mdec.h"
#include "psx_xa.h"
#include "psx_savestate.h"
#include "psx_debugger.h"
#include "psx_timeline.h"

// Global pointers (extern in header, defined here)
PSX_Memory* g_mem = nullptr;
MIPS_CPU*   g_cpu = nullptr;

// Verbose logging flag — set via --verbose CLI flag
bool g_verbose = false;

// Orchestration Engine global instance
OrchestrationEngine g_orch;

// SPU, MDEC, XA-ADPCM, and Debugger global instances
PSX_SPU g_spu;
PSX_MDEC g_mdec;
PSX_XA g_xa;
PSXDebugger g_debugger;
PSXTimeline g_timeline;
CdromTracer g_cdrom_tracer;
ExeDisassembler g_disasm;

// Dedicated CD-ROM trace log file — avoids TTY buffer overflow
FILE* g_cdlog = nullptr;

// Dedicated diagnostic log file — bypasses harness stdout pipe
FILE* g_diaglog = nullptr;

// Thread code blob for Direct RAM Injection
// The game's CD loading thread at 0x800D9E80 is zero-filled because the
// HBD format incompatibility prevents the game from loading it via CD-ROM.
// We inject the extracted blob (from HBD scan) directly into RAM.
static uint8_t g_thread_blob[2048];
static int g_thread_blob_size = 0;
static bool g_thread_blob_loaded = false;
static bool g_thread_injected = false;
static bool g_blob_completed = false; // Set when blob finishes all 499 entries
static const uint32_t THREAD_ENTRY_ADDR = 0x800D9E80;

void load_thread_blob() {
    FILE* f = fopen("thread_code_blob.bin", "rb");
    if (!f) f = fopen("cybergrime/thread_code_blob.bin", "rb");
    if (!f) {
        printf("[INJECT] WARNING: thread_code_blob.bin not found\n");
        return;
    }
    g_thread_blob_size = (int)fread(g_thread_blob, 1, sizeof(g_thread_blob), f);
    fclose(f);
    g_thread_blob_loaded = true;
    printf("[INJECT] Loaded thread_code_blob.bin (%d bytes)\n", g_thread_blob_size);
}

int get_thread_blob(uint8_t* out, int max_size) {
    if (!g_thread_blob_loaded) return 0;
    int n = g_thread_blob_size;
    if (n > max_size) n = max_size;
    if (out && n > 0) memcpy(out, g_thread_blob, n);
    return n;
}
int g_cdlog_count = 0;
#define CDLOG_MAX 20000
#define CDLOG(fmt, ...) do { \
    if (g_verbose) { \
    if (!g_cdlog) g_cdlog = fopen("cdrom_trace.log", "w"); \
    if (g_cdlog && g_cdlog_count < CDLOG_MAX) { \
        fprintf(g_cdlog, fmt, ##__VA_ARGS__); \
        g_cdlog_count++; \
        if (g_cdlog_count % 100 == 0) fflush(g_cdlog); \
    } \
    } \
} while(0)

// ============================================================================
// MIPS R3000A CPU — Instruction Execution
// ============================================================================

bool MIPS_CPU::step() {
    if (crashed) return false;
    if (instructions >= 2000000000) { // 2B instruction limit
        crashed = true;
        snprintf(crash_reason, 255, "Instruction limit reached (%llu)", instructions);
        return false;
    }

    // CD-ROM interrupt delay is handled by cdrom_tick() in tick() — no duplicate here

    // Deliver pending interrupt if:
    // - interrupt_pending flag is set
    // - IEc (bit 0) is set in CP0 Status (interrupts enabled)
    // - EXL (bit 2) is not set (not already in exception handler)
    // - At least one pending interrupt matches enabled IM bits in CP0 Status
    if (interrupt_pending && (cp0_status & 0x01) && !(cp0_status & 0x04)) {
        uint32_t pending = g_mem ? (g_mem->intc_stat & g_mem->intc_mask) : 0;
        uint32_t im_bits = (cp0_status >> 8) & 0xFF;
        if (pending & im_bits) {
        interrupt_pending = false;
        // Save return PC (account for branch delay slot)
        cp0_epc = pc;
        uint32_t cause_val = 0;
        if (in_branch_delay) {
            cp0_epc = pc - 4;  // Return to the branch instruction
            cause_val |= 0x80000000;  // BD bit
        }
        // Push interrupt stack: IEc->IEp, IEp->IEo
        uint32_t old_low6 = cp0_status & 0x3F;
        cp0_status = (cp0_status & ~0x3F) | ((old_low6 << 2) & 0x3C) | (old_low6 & 0x01);
        // Cause register: ExcCode = 0 (Interrupt), IP bits from I_STAT & I_MASK
        uint32_t ip_bits = (g_mem ? (g_mem->intc_stat & g_mem->intc_mask) : 0);
        cause_val |= (ip_bits & 0xFF) << 8;  // IP bits 8-15
        cp0_cause = (cp0_cause & ~0x8000FF00) | cause_val;
        // Jump to general exception vector (BEV=0 -> 0x80000080)
        pc = 0x80000080;
        in_branch_delay = false;
        pending_branch = false;
        if (log_enabled) {
            char idesc[80];
            snprintf(idesc, 79, "VBLANK IRQ -> 0x80000080 (EPC=0x%08X SR=0x%08X)", cp0_epc, cp0_status);
            add_log(cp0_epc, 0, idesc);
        }
        trace_ring_push(cp0_epc, 0, "IRQ -> 0x80000080", false, true);
        return true;
        }
    }

    uint32_t cur_pc = pc;

    // === ORCHESTRATION ENGINE: Pre-exec hooks + register watches + telemetry ===
    if (g_orch.enabled) {
        g_orch.sample_registers(*this, cur_pc);
        int hook_result = g_orch.run_hooks(*this, *g_mem, true);
        if (hook_result == 1) { instructions++; return true; }  // HOOK_SKIP
        if (hook_result == 2) { instructions++; return true; }  // HOOK_REDIRECT
        cur_pc = pc;  // May have changed by redirect
        g_orch.dump_telemetry(*this, *g_mem, instructions);
    }

    // === HBD TERRITORY GUARD ===
    // If PC enters the HBD data zone (0x80120000-0x80130000), the game is
    // attempting to execute unloaded data as code. Redirect back to the last
    // known safe instruction in the main EXE to prevent crash/corruption.
    if (cur_pc >= 0x80120000 && cur_pc < 0x80130000) {
        if (g_orch.enabled) {
            g_orch.audit_write(instructions, cur_pc, 0x80096A84, 0, 0,
                              "HBD territory guard: redirect to safe EXE");
        }
        if (g_verbose) printf("[GUARD] PC=0x%08X in HBD territory — redirecting to 0x80096A84 (instr #%llu)\n",
               cur_pc, instructions);
        pc = 0x80096A84;
        in_branch_delay = false;
        pending_branch = false;
        return true;
    }

    // === TXRT HLE: Surgical Bypass — intercept at decompression ENTRY ===
    // When PC hits a Huffman decompression function entry point, bypass the
    // entire function: inject translated text directly, then jump to $ra.
    // This prevents the engine from ever touching the incompatible tree.
    if (g_mem && (cur_pc == DECOMP_FUNC_PRIMARY || cur_pc == DECOMP_FUNC_SECONDARY)) {
        if (txrt_bypass_decompression_entry(*this, *g_mem, cur_pc)) {
            return true;  // PC redirected to $ra — skip this instruction entirely
        }
    }

    // === TXRT HLE: Fallback — post-decompression text swap ===
    // Only fires in BYPASS_POST_DECOMP mode. Lets decompression run, then
    // overwrites the output buffer with translated text.
    if (cur_pc == DECOMP_RETURN_PC && g_mem) {
        txrt_intercept_decompression_return(*this, *g_mem);
    }

    // === DIVERGENCE DETECTION ===
    // Valid PSX memory ranges for PC:
    //   0x00000000-0x00200000 (RAM mirror)
    //   0x80000000-0x80200000 (cached RAM)
    //   0xA0000000-0xA0200000 (uncached RAM)
    //   0x1FC00000-0x1FC80000 (BIOS ROM)
    //   0xA0/0xB0/0xC0 (BIOS call vectors)
    //   0x80000080 (exception vector)
    bool pc_valid = (cur_pc < 0x00200000) ||
                    (cur_pc >= 0x80000000 && cur_pc < 0x80200000) ||
                    (cur_pc >= 0xA0000000 && cur_pc < 0xA0200000) ||
                    (cur_pc >= 0x1FC00000 && cur_pc < 0x1FC80000) ||
                    (cur_pc >= 0xBFC00000 && cur_pc < 0xBFC80000) ||
                    cur_pc == 0xA0 || cur_pc == 0xB0 || cur_pc == 0xC0 ||
                    cur_pc == 0x80000080;
    if (!pc_valid) {
        // === ORCHESTRATION ENGINE: Auto-correct before crashing ===
        if (g_orch.enabled && g_orch.auto_correct(*this, cur_pc, "PC outside valid range")) {
            return true;  // Corrected — continue execution
        }
        dump_trace_ring("PC OUTSIDE VALID MEMORY RANGE");
        crashed = true;
        snprintf(crash_reason, 255,
                 "DIVERGENCE: PC=0x%08X outside valid PSX memory at instr #%llu",
                 cur_pc, instructions);
        return false;
    }
    // ── BIOS danger zone trap ──────────────────────────────────────
    // PC in 0x80000000-0x8000007C is the BIOS exception vector area.
    // Only 0x80000080 is a valid exception entry point. If PC lands
    // below that, context is corrupted (e.g. ra=1 from v0=1 confusion).
    if (cur_pc >= 0x80000000 && cur_pc < 0x80000080) {
        if (g_diaglog) {
        fprintf(g_diaglog, "[DANGER] PC=0x%08X in BIOS danger zone at instr #%llu\n"
               "         ra=0x%08X sp=0x%08X v0=0x%08X epc=0x%08X cause=0x%08X status=0x%08X\n",
               cur_pc, instructions, get_reg(31), get_reg(29), get_reg(2),
               cp0_epc, cp0_cause, cp0_status);
        fprintf(g_diaglog, "         regs: ");
        for (int i = 0; i < 32; i++) fprintf(g_diaglog, "$%d=0x%08X ", i, get_reg(i));
        fprintf(g_diaglog, "\n");
        fflush(g_diaglog);
        }
        dump_trace_ring("BIOS DANGER ZONE");
        crashed = true;
        snprintf(crash_reason, 255,
                 "BIOS DANGER ZONE: PC=0x%08X at instr #%llu (ra=0x%08X epc=0x%08X)",
                 cur_pc, instructions, get_reg(31), cp0_epc);
        return false;
    }

    // Check for unaligned PC — MIPS requires 4-byte alignment
    if ((cur_pc & 3) != 0 && cur_pc != 0xA0 && cur_pc != 0xB0 && cur_pc != 0xC0) {
        printf("[ALIGN] Unaligned PC=0x%08X at instr #%llu (epc=0x%08X cause=0x%08X status=0x%08X ra=0x%08X)\n",
               cur_pc, instructions, cp0_epc, cp0_cause, cp0_status, get_reg(31));
        dump_trace_ring("UNALIGNED PC");
        // Try auto-correct: align to nearest word and remap to cached RAM
        uint32_t fixed = (cur_pc & 0x1FFFFF & ~3) | 0x80000000;
        printf("[ALIGN] Attempting fix: 0x%08X -> 0x%08X\n", cur_pc, fixed);
        pc = fixed;
        next_pc = fixed + 4;
        in_branch_delay = false;
        pending_branch = false;
        return true;
    }

    // Exception vector intercept: when PC arrives at 0x80000080 (general exception
    // vector), handle it in C++ — acknowledge VBlank in I_STAT, deliver events,
    // and ReturnFromException to EPC. This is the HLE BIOS approach.
    // The MIPS fallback handler at 0x80000080 (installed by install_mips_exception_handler)
    // will be used if handle_exception returns false.
    // SKIP when use_real_bios — let the real BIOS exception handler run.
    if (cur_pc == 0x80000080 && !(g_mem && g_mem->use_real_bios)) {
        uint32_t exc_instr = read32(cur_pc, mem_ctx);
        // Check if 0x80000080 has real MIPS code (non-zero) — if so, let it execute
        // as native MIPS (fallback handler). Otherwise, intercept in C++.
        if (exc_instr == 0x00000000 && g_mem && g_mem->handle_exception(*this)) {
            trace_ring_push(cur_pc, 0, "EXCEPTION HLE", false, true);
            // handle_exception already set pc = cp0_epc and did RFE
            return true;
        }
        // If there's real MIPS code at 0x80000080, fall through to normal execution
    }

    // BIOS call interception: when PC arrives at 0xA0/0xB0/0xC0, $t1 has been
    // set by the delay slot of the preceding jr/jal instruction. Handle the
    // BIOS function and redirect to $ra (return address).
    // SKIP when use_real_bios — let the real BIOS syscall tables execute.
    if ((cur_pc == 0xA0 || cur_pc == 0xB0 || cur_pc == 0xC0) && !(g_mem && g_mem->use_real_bios)) {
        instructions++;
        if (g_mem) g_mem->tick();
        uint32_t fn = get_reg(9) & 0xFF;
        // Log all BIOS calls to CD-ROM trace file for early boot analysis
        {
            char table = cur_pc == 0xA0 ? 'A' : (cur_pc == 0xB0 ? 'B' : 'C');
            uint32_t a0v = get_reg(4), a1v = get_reg(5), a2v = get_reg(6), a3v = get_reg(7);
            CDLOG("[BIOS] %c:0x%02X a0=0x%08X a1=0x%08X a2=0x%08X a3=0x%08X instr #%llu\n",
                   table, fn, a0v, a1v, a2v, a3v, instructions);
        }
        char bdesc[80];
        if (g_mem && g_mem->handle_bios_call(cur_pc, *this)) {
            char bios_desc[80];
            snprintf(bios_desc, 79, "BIOS %c:0x%02X",
                cur_pc == 0xA0 ? 'A' : (cur_pc == 0xB0 ? 'B' : 'C'), fn);
            trace_ring_push(cur_pc, 0, bios_desc, true, false);
            if (!bios_set_pc) {
                uint32_t ret = get_reg(31);
                snprintf(bdesc, 79, "BIOS %c:0x%02X ret -> 0x%08X",
                    cur_pc == 0xA0 ? 'A' : (cur_pc == 0xB0 ? 'B' : 'C'), fn, ret);
                if (log_enabled) add_log(cur_pc, 0, bdesc);
                pc = ret;
            } else {
                bios_set_pc = false;  // Reset flag
                snprintf(bdesc, 79, "BIOS %c:0x%02X (PC set by handler -> 0x%08X)",
                    cur_pc == 0xA0 ? 'A' : (cur_pc == 0xB0 ? 'B' : 'C'), fn, pc);
                if (log_enabled) add_log(cur_pc, 0, bdesc);
            }
            return true;
        } else {
            crashed = true;
            snprintf(crash_reason, 255, "Unhandled BIOS call %c:0x%02X (instr #%llu)",
                     cur_pc == 0xA0 ? 'A' : (cur_pc == 0xB0 ? 'B' : 'C'), fn, instructions);
            return false;
        }
    }

    uint32_t instr = read32(cur_pc, mem_ctx);
    instructions++;

    // PC sampling during VSync wait window
    if (g_verbose && instructions >= 520000 && instructions <= 980000 && (instructions % 50000) == 0) {
        printf("[PCSAMPLE] instr #%llu PC=0x%08X\n", instructions, cur_pc);
    }
    // PC sampling after CD_init (stuck loop investigation)
    if (g_verbose && instructions >= 2400000 && instructions <= 3000000 && (instructions % 100000) == 0) {
        printf("[PCSAMPLE2] instr #%llu PC=0x%08X\n", instructions, cur_pc);
    }
    // Broader PC sampling to track progression past VSync
    if (g_verbose && instructions >= 3000000 && instructions <= 20000000 && (instructions % 1000000) == 0) {
        printf("[PCSAMPLE3] instr #%llu PC=0x%08X\n", instructions, cur_pc);
    }
    // One-time timer mode dump
    if (g_verbose && instructions == 500000 && g_mem) {
        printf("\n=== TIMER MODE DUMP at instr #%llu ===\n", instructions);
        for (int t = 0; t < 3; t++) {
            uint32_t mode = g_mem->timer_mode[t];
            uint32_t src = (mode >> 8) & 3;
            printf("  Timer %d: mode=0x%04X count=%u target=%u src=%u active=%d\n",
                   t, mode, g_mem->timer_count[t], g_mem->timer_target[t],
                   src, g_mem->rcnt_active[t]);
        }
        printf("=== END TIMER MODE DUMP ===\n\n");
    }
    // Periodic memory state dump during CD_init loop
    if (g_verbose && g_mem && (instructions == 2500000 || instructions == 5000000 || instructions == 10000000 || instructions == 20000000 || instructions == 50000000) && instructions > 2400000) {
        printf("\n=== MEMDUMP at instr #%llu PC=0x%08X ===\n", instructions, cur_pc);
        uint32_t addrs[] = {0x800B9164, 0x800BA65C, 0x800BA294, 0x800B63D8, 0x800B5312, 0x800B679C, 0x800B915C, 0x800B9160, 0x800B9168};
        const char* names[] = {"CD_STAT", "CD_INIT_PARAM", "VBC2", "VBC1", "DISP_FLAG", "EVT_FLAG", "CD_PTR", "T0_PTR", "VBC_SAVE"};
        for (int i = 0; i < 9; i++) {
            uint32_t v = g_mem->read32(addrs[i]);
            printf("  [%s] 0x%08X = 0x%08X\n", names[i], addrs[i], v);
            // If it's a pointer, dereference it
            if ((i == 6 || i == 7) && v >= 0x80000000 && v < 0x80200000) {
                uint32_t deref = g_mem->read32(v);
                printf("    *0x%08X = 0x%08X\n", v, deref);
            }
        }
        // Dump registers
        printf("  $a0=0x%08X $a1=0x%08X $v0=0x%08X $v1=0x%08X $s0=0x%08X $s1=0x%08X $sp=0x%08X\n",
               get_reg(4), get_reg(5), get_reg(2), get_reg(3), get_reg(16), get_reg(17), get_reg(29));
        // Stack value at sp+0x10
        uint32_t sp = get_reg(29);
        uint32_t stack10 = g_mem->read32(sp + 0x10);
        printf("  [sp+0x10]=0x%08X (CD target timestamp?)\n", stack10);
        // Extended game state dump
        uint32_t extra_addrs[] = {0x800BF444, 0x800B679C, 0x800B5312, 0x800B91CC, 0x800B91CE,
                                  0x80100750, 0x80100754, 0x800BA294, 0x800B63D8, 0x800B5310,
                                  0x800B9204, 0x800DB740, 0x800DB3E8, 0x800DB744};
        const char* extra_names[] = {"TIMEOUT_VAL", "EVT_FLAG", "DISP_FLAG", "CD_INIT_DONE", "CD_READY",
                                     "FRAME_CNT_750", "FRAME_CNT_754", "VBC2", "VBC1", "DISP_AREA",
                                     "HOOK_ENTRY_BLK", "THREAD_CTX_A", "THREAD_CTX_B", "THREAD_CTX_C"};
        for (int i = 0; i < 14; i++) {
            uint32_t v = g_mem->read32(extra_addrs[i]);
            printf("  [%s] 0x%08X = 0x%08X\n", extra_names[i], extra_addrs[i], v);
        }
        // Dump event table status
        printf("  Event Table:\n");
        for (int i = 0; i < 16 && g_mem; i++) {
            uint32_t st = g_mem->events[i].status;
            if (st != 0) {
                printf("    ev[%d]: status=%u class=0x%08X spec=0x%08X handler=0x%08X\n",
                       i, st, g_mem->events[i].ev_class, g_mem->events[i].ev_spec, g_mem->events[i].fhandler);
            }
        }
        printf("=== END MEMDUMP ===\n\n");
    }

    // One-time code dump of the CD_init loop at instr 2400001
    if (g_verbose && instructions == 2400001 && g_mem) {
        printf("\n=== CD_INIT ENTRY REGISTERS ===\n");
        printf("$a0=0x%08X $a1=0x%08X $a2=0x%08X $v0=0x%08X $v1=0x%08X $s0=0x%08X $sp=0x%08X\n",
               get_reg(4), get_reg(5), get_reg(6), get_reg(2), get_reg(3), get_reg(16), get_reg(29));
        if (g_mem) {
            uint32_t a1 = get_reg(5);
            uint32_t val1 = g_mem->read32(a1);
            printf("*$a1 (0x%08X) = 0x%08X\n", a1, val1);
            uint32_t val2 = g_mem->read32(0x800B9164);
            printf("[0x800B9164] = 0x%08X (CD status?)\n", val2);
        }
        printf("=== END CD_INIT REGISTERS ===\n\n");
        // Dump stack values
        uint32_t sp = get_reg(29);
        for (int i = 0; i < 8; i++) {
            uint32_t sv = g_mem->read32(sp + i*4);
            printf("[STACK] sp+0x%02X = 0x%08X\n", i*4, sv);
        }
        printf("\n=== CD_INIT LOOP CODE DUMP (0x80099D80-0x80099FB0) ===\n");
        for (uint32_t a = 0x80099D80; a <= 0x80099FB0; a += 4) {
            uint32_t code = g_mem->read32(a);
            uint32_t op = (code >> 26) & 0x3F;
            uint32_t rs = (code >> 21) & 0x1F;
            uint32_t rt = (code >> 16) & 0x1F;
            uint32_t rd = (code >> 11) & 0x1F;
            uint32_t shamt = (code >> 6) & 0x1F;
            uint32_t funct = code & 0x3F;
            int16_t simm = (int16_t)(code & 0xFFFF);
            uint32_t target = (code & 0x3FFFFFF) << 2;
            const char* rn[] = {"$0","$at","$v0","$v1","$a0","$a1","$a2","$a3",
                               "$t0","$t1","$t2","$t3","$t4","$t5","$t6","$t7",
                               "$s0","$s1","$s2","$s3","$s4","$s5","$s6","$s7",
                               "$t8","$t9","$k0","$k1","$gp","$sp","$fp","$ra"};
            printf("0x%08X: 0x%08X  ", a, code);
            if (code == 0) printf("nop");
            else if (op == 0) {
                if (funct == 8) printf("jr %s", rn[rs]);
                else if (funct == 9) printf("jalr %s,%s", rn[rd], rn[rs]);
                else if (funct == 12) printf("syscall");
                else if (funct == 0x10) printf("mfhi %s", rn[rd]);
                else if (funct == 0x12) printf("mflo %s", rn[rd]);
                else if (funct == 0x20) printf("add %s,%s,%s", rn[rd], rn[rs], rn[rt]);
                else if (funct == 0x21) printf("addu %s,%s,%s", rn[rd], rn[rs], rn[rt]);
                else if (funct == 0x22) printf("sub %s,%s,%s", rn[rd], rn[rs], rn[rt]);
                else if (funct == 0x23) printf("subu %s,%s,%s", rn[rd], rn[rs], rn[rt]);
                else if (funct == 0x24) printf("and %s,%s,%s", rn[rd], rn[rs], rn[rt]);
                else if (funct == 0x25) printf("or %s,%s,%s", rn[rd], rn[rs], rn[rt]);
                else if (funct == 0x26) printf("xor %s,%s,%s", rn[rd], rn[rs], rn[rt]);
                else if (funct == 0x27) printf("nor %s,%s,%s", rn[rd], rn[rs], rn[rt]);
                else if (funct == 0x2A) printf("slt %s,%s,%s", rn[rd], rn[rs], rn[rt]);
                else if (funct == 0x2B) printf("sltu %s,%s,%s", rn[rd], rn[rs], rn[rt]);
                else if (funct == 0x00) printf("sll %s,%s,%d", rn[rd], rn[rt], shamt);
                else if (funct == 0x02) printf("srl %s,%s,%d", rn[rd], rn[rt], shamt);
                else if (funct == 0x03) printf("sra %s,%s,%d", rn[rd], rn[rt], shamt);
                else printf("special 0x%02X", funct);
            }
            else if (op == 0x02) printf("j 0x%08X", target | 0x80000000);
            else if (op == 0x03) printf("jal 0x%08X", target | 0x80000000);
            else if (op == 0x04) printf("beq %s,%s,0x%08X", rn[rs], rn[rt], a+4+(simm<<2));
            else if (op == 0x05) printf("bne %s,%s,0x%08X", rn[rs], rn[rt], a+4+(simm<<2));
            else if (op == 0x06) printf("blez %s,0x%08X", rn[rs], a+4+(simm<<2));
            else if (op == 0x07) printf("bgtz %s,0x%08X", rn[rs], a+4+(simm<<2));
            else if (op == 0x08) printf("addi %s,%s,%d", rn[rt], rn[rs], simm);
            else if (op == 0x09) printf("addiu %s,%s,%d", rn[rt], rn[rs], simm);
            else if (op == 0x0A) printf("slti %s,%s,%d", rn[rt], rn[rs], simm);
            else if (op == 0x0B) printf("sltiu %s,%s,%d", rn[rt], rn[rs], simm);
            else if (op == 0x0C) printf("andi %s,%s,0x%04X", rn[rt], rn[rs], (uint16_t)simm);
            else if (op == 0x0D) printf("ori %s,%s,0x%04X", rn[rt], rn[rs], (uint16_t)simm);
            else if (op == 0x0E) printf("xori %s,%s,0x%04X", rn[rt], rn[rs], (uint16_t)simm);
            else if (op == 0x0F) printf("lui %s,0x%04X", rn[rt], (uint16_t)simm);
            else if (op == 0x10) printf("mfc0 %s,$%d", rn[rt], rd);
            else if (op == 0x12) printf("mtc0 %s,$%d", rn[rt], rd);
            else if (op == 0x20) printf("lb %s,0x%04X(%s)", rn[rt], (uint16_t)simm, rn[rs]);
            else if (op == 0x21) printf("lh %s,0x%04X(%s)", rn[rt], (uint16_t)simm, rn[rs]);
            else if (op == 0x23) printf("lw %s,0x%04X(%s)", rn[rt], (uint16_t)simm, rn[rs]);
            else if (op == 0x24) printf("lbu %s,0x%04X(%s)", rn[rt], (uint16_t)simm, rn[rs]);
            else if (op == 0x25) printf("lhu %s,0x%04X(%s)", rn[rt], (uint16_t)simm, rn[rs]);
            else if (op == 0x28) printf("sb %s,0x%04X(%s)", rn[rt], (uint16_t)simm, rn[rs]);
            else if (op == 0x29) printf("sh %s,0x%04X(%s)", rn[rt], (uint16_t)simm, rn[rs]);
            else if (op == 0x2B) printf("sw %s,0x%04X(%s)", rn[rt], (uint16_t)simm, rn[rs]);
            else printf("op=0x%02X", op);
            printf("\n");
        }
        printf("=== END CD_INIT LOOP DUMP ===\n\n");
        // Also dump 0x80099F00-0x80099F40 (VSync area)
        printf("\n=== VSYNC AREA DUMP (0x80099F00-0x80099F40) ===\n");
        for (uint32_t a = 0x80099F00; a <= 0x80099F40; a += 4) {
            uint32_t code = g_mem->read32(a);
            printf("0x%08X: 0x%08X\n", a, code);
        }
        printf("=== END VSYNC AREA DUMP ===\n\n");
        // Dump game's main loop code
        printf("\n=== MAIN LOOP DUMP (0x8009B700-0x8009BF00) ===\n");
        for (uint32_t a = 0x8009B700; a <= 0x8009BF00; a += 4) {
            uint32_t code = g_mem->read32(a);
            uint32_t op = (code >> 26) & 0x3F;
            uint32_t rs = (code >> 21) & 0x1F;
            uint32_t rt = (code >> 16) & 0x1F;
            uint32_t rd = (code >> 11) & 0x1F;
            uint32_t shamt = (code >> 6) & 0x1F;
            uint32_t funct = code & 0x3F;
            int16_t simm = (int16_t)(code & 0xFFFF);
            uint32_t target = (code & 0x3FFFFFF) << 2;
            const char* rn[] = {"$0","$at","$v0","$v1","$a0","$a1","$a2","$a3",
                               "$t0","$t1","$t2","$t3","$t4","$t5","$t6","$t7",
                               "$s0","$s1","$s2","$s3","$s4","$s5","$s6","$s7",
                               "$t8","$t9","$k0","$k1","$gp","$sp","$fp","$ra"};
            printf("0x%08X: 0x%08X  ", a, code);
            if (code == 0) printf("nop");
            else if (op == 0) {
                if (funct == 8) printf("jr %s", rn[rs]);
                else if (funct == 9) printf("jalr %s,%s", rn[rd], rn[rs]);
                else if (funct == 12) printf("syscall");
                else if (funct == 0x10) printf("mfhi %s", rn[rd]);
                else if (funct == 0x12) printf("mflo %s", rn[rd]);
                else if (funct == 0x20) printf("add %s,%s,%s", rn[rd], rn[rs], rn[rt]);
                else if (funct == 0x21) printf("addu %s,%s,%s", rn[rd], rn[rs], rn[rt]);
                else if (funct == 0x22) printf("sub %s,%s,%s", rn[rd], rn[rs], rn[rt]);
                else if (funct == 0x23) printf("subu %s,%s,%s", rn[rd], rn[rs], rn[rt]);
                else if (funct == 0x24) printf("and %s,%s,%s", rn[rd], rn[rs], rn[rt]);
                else if (funct == 0x25) printf("or %s,%s,%s", rn[rd], rn[rs], rn[rt]);
                else if (funct == 0x26) printf("xor %s,%s,%s", rn[rd], rn[rs], rn[rt]);
                else if (funct == 0x27) printf("nor %s,%s,%s", rn[rd], rn[rs], rn[rt]);
                else if (funct == 0x2A) printf("slt %s,%s,%s", rn[rd], rn[rs], rn[rt]);
                else if (funct == 0x2B) printf("sltu %s,%s,%s", rn[rd], rn[rs], rn[rt]);
                else if (funct == 0x00) printf("sll %s,%s,%d", rn[rd], rn[rt], shamt);
                else if (funct == 0x02) printf("srl %s,%s,%d", rn[rd], rn[rt], shamt);
                else if (funct == 0x03) printf("sra %s,%s,%d", rn[rd], rn[rt], shamt);
                else printf("special 0x%02X", funct);
            }
            else if (op == 0x02) printf("j 0x%08X", target | 0x80000000);
            else if (op == 0x03) printf("jal 0x%08X", target | 0x80000000);
            else if (op == 0x04) printf("beq %s,%s,0x%08X", rn[rs], rn[rt], a+4+(simm<<2));
            else if (op == 0x05) printf("bne %s,%s,0x%08X", rn[rs], rn[rt], a+4+(simm<<2));
            else if (op == 0x06) printf("blez %s,0x%08X", rn[rs], a+4+(simm<<2));
            else if (op == 0x07) printf("bgtz %s,0x%08X", rn[rs], a+4+(simm<<2));
            else if (op == 0x08) printf("addi %s,%s,%d", rn[rt], rn[rs], simm);
            else if (op == 0x09) printf("addiu %s,%s,%d", rn[rt], rn[rs], simm);
            else if (op == 0x0A) printf("slti %s,%s,%d", rn[rt], rn[rs], simm);
            else if (op == 0x0B) printf("sltiu %s,%s,%d", rn[rt], rn[rs], simm);
            else if (op == 0x0C) printf("andi %s,%s,0x%04X", rn[rt], rn[rs], (uint16_t)simm);
            else if (op == 0x0D) printf("ori %s,%s,0x%04X", rn[rt], rn[rs], (uint16_t)simm);
            else if (op == 0x0E) printf("xori %s,%s,0x%04X", rn[rt], rn[rs], (uint16_t)simm);
            else if (op == 0x0F) printf("lui %s,0x%04X", rn[rt], (uint16_t)simm);
            else if (op == 0x10) printf("mfc0 %s,$%d", rn[rt], rd);
            else if (op == 0x12) printf("mtc0 %s,$%d", rn[rt], rd);
            else if (op == 0x20) printf("lb %s,0x%04X(%s)", rn[rt], (uint16_t)simm, rn[rs]);
            else if (op == 0x21) printf("lh %s,0x%04X(%s)", rn[rt], (uint16_t)simm, rn[rs]);
            else if (op == 0x23) printf("lw %s,0x%04X(%s)", rn[rt], (uint16_t)simm, rn[rs]);
            else if (op == 0x24) printf("lbu %s,0x%04X(%s)", rn[rt], (uint16_t)simm, rn[rs]);
            else if (op == 0x25) printf("lhu %s,0x%04X(%s)", rn[rt], (uint16_t)simm, rn[rs]);
            else if (op == 0x28) printf("sb %s,0x%04X(%s)", rn[rt], (uint16_t)simm, rn[rs]);
            else if (op == 0x29) printf("sh %s,0x%04X(%s)", rn[rt], (uint16_t)simm, rn[rs]);
            else if (op == 0x2B) printf("sw %s,0x%04X(%s)", rn[rt], (uint16_t)simm, rn[rs]);
            else printf("op=0x%02X", op);
            printf("\n");
        }
        printf("=== END MAIN LOOP DUMP ===\n\n");
        // Dump CD status check function
        printf("\n=== CD CHECK FUNC (0x8009A100-0x8009A200) ===\n");
        for (uint32_t a = 0x8009A100; a <= 0x8009A200; a += 4) {
            uint32_t code = g_mem->read32(a);
            printf("0x%08X: 0x%08X\n", a, code);
        }
        printf("=== END CD CHECK FUNC ===\n\n");
        // Dump continue-waiting path
        printf("\n=== CONTINUE PATH (0x8009B910-0x8009BA00) ===\n");
        for (uint32_t a = 0x8009B910; a <= 0x8009BA00; a += 4) {
            uint32_t code = g_mem->read32(a);
            printf("0x%08X: 0x%08X\n", a, code);
        }
        printf("=== END CONTINUE PATH ===\n\n");
    }

    // One-time register dump at instr 520001 to see VSync function parameters
    if (instructions == 520001) {
        printf("\n=== VSYNC ENTRY REGISTERS ===\n");
        printf("$a0=%d (0x%08X)  $a1=%d  $v0=%d  $v1=%d  $sp=0x%08X\n",
               get_reg(4), get_reg(4), get_reg(5), get_reg(2), get_reg(3), get_reg(29));
        uint32_t sp = get_reg(29);
        if (g_mem) {
            uint32_t stack_val = g_mem->read32(sp + 0x10);
            printf("stack[0x10]=%d (0x%08X) — timeout counter\n", stack_val, stack_val);
            uint32_t ra_val = g_mem->read32(sp + 0x18);
            printf("stack[0x18]=0x%08X — return address\n", ra_val);
        }
        printf("=== END VSYNC ENTRY REGISTERS ===\n\n");
    }

    // One-time code dump of the VSync loop at instr 550000
    if (instructions == 550001 && g_mem) {
        printf("\n=== VSYNC LOOP CODE DUMP (0x80099F40-0x80099FB0) ===\n");
        for (uint32_t a = 0x80099F40; a <= 0x80099FB0; a += 4) {
            uint32_t code = g_mem->read32(a);
            // Simple MIPS disasm
            uint32_t op = (code >> 26) & 0x3F;
            uint32_t rs = (code >> 21) & 0x1F;
            uint32_t rt = (code >> 16) & 0x1F;
            uint32_t rd = (code >> 11) & 0x1F;
            uint32_t shamt = (code >> 6) & 0x1F;
            uint32_t funct = code & 0x3F;
            int16_t simm = (int16_t)(code & 0xFFFF);
            uint32_t target = (code & 0x3FFFFFF) << 2;
            const char* rn[] = {"$0","$at","$v0","$v1","$a0","$a1","$a2","$a3",
                               "$t0","$t1","$t2","$t3","$t4","$t5","$t6","$t7",
                               "$s0","$s1","$s2","$s3","$s4","$s5","$s6","$s7",
                               "$t8","$t9","$k0","$k1","$gp","$sp","$fp","$ra"};
            printf("0x%08X: 0x%08X  ", a, code);
            if (code == 0) { printf("nop"); }
            else if (op == 0) {
                const char* fn[] = {"sll","?","srl","sra","sllv","?","srlv","srav",
                    "jr","jalr","?","?","syscall","break","?","?",
                    "mfhi","mthi","mflo","mtlo","?","?","?","?",
                    "mult","multu","div","divu","?","?","?","?"};
                if (funct == 8) printf("jr %s", rn[rs]);
                else if (funct == 9) printf("jalr %s,%s", rn[rd], rn[rs]);
                else if (funct == 12) printf("syscall");
                else if (funct == 0x10) printf("mfhi %s", rn[rd]);
                else if (funct == 0x12) printf("mflo %s", rn[rd]);
                else if (funct == 0x18) printf("mult %s,%s", rn[rs], rn[rt]);
                else if (funct == 0x19) printf("multu %s,%s", rn[rs], rn[rt]);
                else if (funct == 0x20) printf("add %s,%s,%s", rn[rd], rn[rs], rn[rt]);
                else if (funct == 0x21) printf("addu %s,%s,%s", rn[rd], rn[rs], rn[rt]);
                else if (funct == 0x22) printf("sub %s,%s,%s", rn[rd], rn[rs], rn[rt]);
                else if (funct == 0x23) printf("subu %s,%s,%s", rn[rd], rn[rs], rn[rt]);
                else if (funct == 0x24) printf("and %s,%s,%s", rn[rd], rn[rs], rn[rt]);
                else if (funct == 0x25) printf("or %s,%s,%s", rn[rd], rn[rs], rn[rt]);
                else if (funct == 0x26) printf("xor %s,%s,%s", rn[rd], rn[rs], rn[rt]);
                else if (funct == 0x27) printf("nor %s,%s,%s", rn[rd], rn[rs], rn[rt]);
                else if (funct == 0x2A) printf("slt %s,%s,%s", rn[rd], rn[rs], rn[rt]);
                else if (funct == 0x2B) printf("sltu %s,%s,%s", rn[rd], rn[rs], rn[rt]);
                else if (funct == 0x00) printf("sll %s,%s,%d", rn[rd], rn[rt], shamt);
                else if (funct == 0x02) printf("srl %s,%s,%d", rn[rd], rn[rt], shamt);
                else if (funct == 0x03) printf("sra %s,%s,%d", rn[rd], rn[rt], shamt);
                else printf("special 0x%02X", funct);
            }
            else if (op == 0x01) printf("regimm %s,%d", rn[rs], rt);
            else if (op == 0x02) printf("j 0x%08X", target | 0x80000000);
            else if (op == 0x03) printf("jal 0x%08X", target | 0x80000000);
            else if (op == 0x04) printf("beq %s,%s,0x%08X", rn[rs], rn[rt], a+4+(simm<<2));
            else if (op == 0x05) printf("bne %s,%s,0x%08X", rn[rs], rn[rt], a+4+(simm<<2));
            else if (op == 0x06) printf("blez %s,0x%08X", rn[rs], a+4+(simm<<2));
            else if (op == 0x07) printf("bgtz %s,0x%08X", rn[rs], a+4+(simm<<2));
            else if (op == 0x08) printf("addi %s,%s,%d", rn[rt], rn[rs], simm);
            else if (op == 0x09) printf("addiu %s,%s,%d", rn[rt], rn[rs], simm);
            else if (op == 0x0A) printf("slti %s,%s,%d", rn[rt], rn[rs], simm);
            else if (op == 0x0B) printf("sltiu %s,%s,%d", rn[rt], rn[rs], simm);
            else if (op == 0x0C) printf("andi %s,%s,0x%04X", rn[rt], rn[rs], (uint16_t)simm);
            else if (op == 0x0D) printf("ori %s,%s,0x%04X", rn[rt], rn[rs], (uint16_t)simm);
            else if (op == 0x0E) printf("xori %s,%s,0x%04X", rn[rt], rn[rs], (uint16_t)simm);
            else if (op == 0x0F) printf("lui %s,0x%04X", rn[rt], (uint16_t)simm);
            else if (op == 0x10) printf("mfc0 %s,$%d", rn[rt], rd);
            else if (op == 0x11) printf("c0 0x%02X", funct);
            else if (op == 0x12) printf("mtc0 %s,$%d", rn[rt], rd);
            else if (op == 0x20) printf("lb %s,0x%04X(%s)", rn[rt], (uint16_t)simm, rn[rs]);
            else if (op == 0x21) printf("lh %s,0x%04X(%s)", rn[rt], (uint16_t)simm, rn[rs]);
            else if (op == 0x23) printf("lw %s,0x%04X(%s)", rn[rt], (uint16_t)simm, rn[rs]);
            else if (op == 0x24) printf("lbu %s,0x%04X(%s)", rn[rt], (uint16_t)simm, rn[rs]);
            else if (op == 0x25) printf("lhu %s,0x%04X(%s)", rn[rt], (uint16_t)simm, rn[rs]);
            else if (op == 0x28) printf("sb %s,0x%04X(%s)", rn[rt], (uint16_t)simm, rn[rs]);
            else if (op == 0x29) printf("sh %s,0x%04X(%s)", rn[rt], (uint16_t)simm, rn[rs]);
            else if (op == 0x2B) printf("sw %s,0x%04X(%s)", rn[rt], (uint16_t)simm, rn[rs]);
            else printf("op=0x%02X", op);
            printf("\n");
        }
        printf("=== END VSYNC LOOP DUMP ===\n\n");
    }

    // Advance hardware state every instruction
    if (g_mem) g_mem->tick();

    // Check breakpoints
    for (int i = 0; i < bp_count; i++) {
        if (cur_pc == breakpoints[i]) {
            hit_breakpoint = true;
            return false;
        }
    }

    uint32_t opcode = (instr >> 26) & 0x3F;
    uint32_t rs = (instr >> 21) & 0x1F;
    uint32_t rt = (instr >> 16) & 0x1F;
    uint32_t rd = (instr >> 11) & 0x1F;
    uint32_t shamt = (instr >> 6) & 0x1F;
    uint32_t funct = instr & 0x3F;
    uint16_t imm = instr & 0xFFFF;
    int32_t simm = sext16(imm);
    uint32_t target = instr & 0x3FFFFFF;

    uint32_t new_pc = cur_pc + 4;
    bool is_branch = false;  // This instruction is a branch/jump
    char desc[80];

    switch (opcode) {
    case 0x00: // SPECIAL
        switch (funct) {
        case 0x00: snprintf(desc,80,"sll $%s,$%s,%u",rn(rd),rn(rt),shamt);
            set_reg(rd, get_reg(rt) << shamt); break;
        case 0x02: snprintf(desc,80,"srl $%s,$%s,%u",rn(rd),rn(rt),shamt);
            set_reg(rd, get_reg(rt) >> shamt); break;
        case 0x03: snprintf(desc,80,"sra $%s,$%s,%u",rn(rd),rn(rt),shamt);
            set_reg(rd, (uint32_t)(s32(get_reg(rt)) >> shamt)); break;
        case 0x04: snprintf(desc,80,"sllv $%s,$%s,$%s",rn(rd),rn(rt),rn(rs));
            set_reg(rd, get_reg(rt) << (get_reg(rs) & 0x1F)); break;
        case 0x06: snprintf(desc,80,"srlv $%s,$%s,$%s",rn(rd),rn(rt),rn(rs));
            set_reg(rd, get_reg(rt) >> (get_reg(rs) & 0x1F)); break;
        case 0x07: snprintf(desc,80,"srav $%s,$%s,$%s",rn(rd),rn(rt),rn(rs));
            set_reg(rd, (uint32_t)(s32(get_reg(rt)) >> (get_reg(rs) & 0x1F))); break;
        case 0x08: snprintf(desc,80,"jr $%s -> 0x%08X",rn(rs),get_reg(rs));
            new_pc = get_reg(rs); is_branch = true;
            // Phase 6: call stack tracking — jr $ra pops
            if (rs == 31 && g_mem) g_mem->pop_call_stack(new_pc);
            break;
        case 0x09: snprintf(desc,80,"jalr $%s,$%s -> 0x%08X",rn(rd?rd:31),rn(rs),get_reg(rs));
            set_reg(rd ? rd : 31, cur_pc + 8); new_pc = get_reg(rs); is_branch = true;
            // Phase 6: call stack tracking
            if (g_mem) g_mem->push_call_stack(cur_pc, new_pc);
            break;
        case 0x0C: { // SYSCALL — PSX BIOS call dispatch
            // PSX BIOS calls: $t1 = function number, jump target = table base
            // Table A: 0xA0, Table B: 0xB0, Table C: 0xC0
            // The actual call mechanism: code jumps to 0xA0/0xB0/0xC0 with $t1 set
            // We intercept SYSCALL here and dispatch based on $t1 and the code that
            // set up the call. But PSX uses jal to 0xA0/0xB0/0xC0, not SYSCALL.
            // For now, handle as no-op (shouldn't normally hit this in PSX EXE)
            snprintf(desc,80,"syscall (t1=0x%02X)", (get_reg(9) & 0xFF));
            // Treat as no-op — PSX games don't use SYSCALL directly
            break; }
        case 0x0D: snprintf(desc,80,"break");
            crashed = true;
            snprintf(crash_reason,255,"BREAK at 0x%08X",cur_pc); break;
        case 0x10: snprintf(desc,80,"mfhi $%s",rn(rd));
            set_reg(rd, hi); break;
        case 0x11: snprintf(desc,80,"mthi $%s",rn(rs));
            hi = get_reg(rs); break;
        case 0x12: snprintf(desc,80,"mflo $%s",rn(rd));
            set_reg(rd, lo); break;
        case 0x13: snprintf(desc,80,"mtlo $%s",rn(rs));
            lo = get_reg(rs); break;
        case 0x18: { snprintf(desc,80,"mult $%s,$%s",rn(rs),rn(rt));
            int64_t r = (int64_t)s32(get_reg(rs)) * (int64_t)s32(get_reg(rt));
            lo = (uint32_t)(r & 0xFFFFFFFF); hi = (uint32_t)((r >> 32) & 0xFFFFFFFF); break; }
        case 0x19: { snprintf(desc,80,"multu $%s,$%s",rn(rs),rn(rt));
            uint64_t r = (uint64_t)get_reg(rs) * (uint64_t)get_reg(rt);
            lo = (uint32_t)(r & 0xFFFFFFFF); hi = (uint32_t)((r >> 32) & 0xFFFFFFFF); break; }
        case 0x1A: { snprintf(desc,80,"div $%s,$%s",rn(rs),rn(rt));
            int32_t a = s32(get_reg(rs)), b = s32(get_reg(rt));
            if (b) { lo = (uint32_t)(a / b); hi = (uint32_t)(a % b); }
            break; }
        case 0x1B: { snprintf(desc,80,"divu $%s,$%s",rn(rs),rn(rt));
            uint32_t a = get_reg(rs), b = get_reg(rt);
            if (b) { lo = a / b; hi = a % b; } break; }
        case 0x20: snprintf(desc,80,"add $%s,$%s,$%s",rn(rd),rn(rs),rn(rt));
            set_reg(rd, (uint32_t)(s32(get_reg(rs)) + s32(get_reg(rt)))); break;
        case 0x21: snprintf(desc,80,"addu $%s,$%s,$%s",rn(rd),rn(rs),rn(rt));
            set_reg(rd, get_reg(rs) + get_reg(rt)); break;
        case 0x22: snprintf(desc,80,"sub $%s,$%s,$%s",rn(rd),rn(rs),rn(rt));
            set_reg(rd, (uint32_t)(s32(get_reg(rs)) - s32(get_reg(rt)))); break;
        case 0x23: snprintf(desc,80,"subu $%s,$%s,$%s",rn(rd),rn(rs),rn(rt));
            set_reg(rd, get_reg(rs) - get_reg(rt)); break;
        case 0x24: snprintf(desc,80,"and $%s,$%s,$%s",rn(rd),rn(rs),rn(rt));
            set_reg(rd, get_reg(rs) & get_reg(rt)); break;
        case 0x25: snprintf(desc,80,"or $%s,$%s,$%s",rn(rd),rn(rs),rn(rt));
            set_reg(rd, get_reg(rs) | get_reg(rt)); break;
        case 0x26: snprintf(desc,80,"xor $%s,$%s,$%s",rn(rd),rn(rs),rn(rt));
            set_reg(rd, get_reg(rs) ^ get_reg(rt)); break;
        case 0x27: snprintf(desc,80,"nor $%s,$%s,$%s",rn(rd),rn(rs),rn(rt));
            set_reg(rd, ~(get_reg(rs) | get_reg(rt))); break;
        case 0x2A: snprintf(desc,80,"slt $%s,$%s,$%s",rn(rd),rn(rs),rn(rt));
            set_reg(rd, s32(get_reg(rs)) < s32(get_reg(rt)) ? 1 : 0); break;
        case 0x2B: snprintf(desc,80,"sltu $%s,$%s,$%s",rn(rd),rn(rs),rn(rt));
            set_reg(rd, get_reg(rs) < get_reg(rt) ? 1 : 0); break;
        default: snprintf(desc,80,"special f=0x%02X",funct); break;
        }
        break;

    case 0x01: // REGIMM
        switch (rt) {
        case 0x00: snprintf(desc,80,"bltz $%s,0x%08X",rn(rs),cur_pc+4+(simm<<2));
            if (s32(get_reg(rs)) < 0) { new_pc = cur_pc + 4 + (simm << 2); is_branch = true; } break;
        case 0x01: snprintf(desc,80,"bgez $%s,0x%08X",rn(rs),cur_pc+4+(simm<<2));
            if (s32(get_reg(rs)) >= 0) { new_pc = cur_pc + 4 + (simm << 2); is_branch = true; } break;
        case 0x10: snprintf(desc,80,"bltzal $%s,0x%08X",rn(rs),cur_pc+4+(simm<<2));
            set_reg(31, cur_pc + 8);
            if (s32(get_reg(rs)) < 0) { new_pc = cur_pc + 4 + (simm << 2); is_branch = true; } break;
        case 0x11: snprintf(desc,80,"bgezal $%s,0x%08X",rn(rs),cur_pc+4+(simm<<2));
            set_reg(31, cur_pc + 8);
            if (s32(get_reg(rs)) >= 0) { new_pc = cur_pc + 4 + (simm << 2); is_branch = true; } break;
        default: snprintf(desc,80,"regimm rt=0x%02X",rt); break;
        }
        break;

    case 0x02: { snprintf(desc,80,"j 0x%08X",(cur_pc&0xF0000000)|(target<<2));
        new_pc = (cur_pc & 0xF0000000) | (target << 2); is_branch = true; break; }
    case 0x03: { snprintf(desc,80,"jal 0x%08X",(cur_pc&0xF0000000)|(target<<2));
        set_reg(31, cur_pc + 8);
        new_pc = (cur_pc & 0xF0000000) | (target << 2); is_branch = true;
        // Phase 6: call stack tracking
        if (g_mem) g_mem->push_call_stack(cur_pc, new_pc);
        break; }
    case 0x04: snprintf(desc,80,"beq $%s,$%s,0x%08X",rn(rs),rn(rt),cur_pc+4+(simm<<2));
        if (get_reg(rs) == get_reg(rt)) { new_pc = cur_pc + 4 + (simm << 2); is_branch = true; } break;
    case 0x05: snprintf(desc,80,"bne $%s,$%s,0x%08X",rn(rs),rn(rt),cur_pc+4+(simm<<2));
        if (get_reg(rs) != get_reg(rt)) { new_pc = cur_pc + 4 + (simm << 2); is_branch = true; } break;
    case 0x06: snprintf(desc,80,"blez $%s,0x%08X",rn(rs),cur_pc+4+(simm<<2));
        if (s32(get_reg(rs)) <= 0) { new_pc = cur_pc + 4 + (simm << 2); is_branch = true; } break;
    case 0x07: snprintf(desc,80,"bgtz $%s,0x%08X",rn(rs),cur_pc+4+(simm<<2));
        if (s32(get_reg(rs)) > 0) { new_pc = cur_pc + 4 + (simm << 2); is_branch = true; } break;
    case 0x08: snprintf(desc,80,"addi $%s,$%s,%d",rn(rt),rn(rs),simm);
        set_reg(rt, (uint32_t)(s32(get_reg(rs)) + simm)); break;
    case 0x09: { uint32_t v = get_reg(rs) + simm;
        snprintf(desc,80,"addiu $%s,$%s,%d (0x%08X)",rn(rt),rn(rs),simm,v);
        set_reg(rt, v); break; }
    case 0x0A: snprintf(desc,80,"slti $%s,$%s,%d",rn(rt),rn(rs),simm);
        set_reg(rt, s32(get_reg(rs)) < simm ? 1 : 0); break;
    case 0x0B: snprintf(desc,80,"sltiu $%s,$%s,%d",rn(rt),rn(rs),simm);
        set_reg(rt, get_reg(rs) < (uint32_t)simm ? 1 : 0); break;
    case 0x0C: snprintf(desc,80,"andi $%s,$%s,0x%04X",rn(rt),rn(rs),imm);
        set_reg(rt, get_reg(rs) & imm); break;
    case 0x0D: snprintf(desc,80,"ori $%s,$%s,0x%04X",rn(rt),rn(rs),imm);
        set_reg(rt, get_reg(rs) | imm); break;
    case 0x0E: snprintf(desc,80,"xori $%s,$%s,0x%04X",rn(rt),rn(rs),imm);
        set_reg(rt, get_reg(rs) ^ imm); break;
    case 0x0F: { uint32_t v = imm << 16;
        snprintf(desc,80,"lui $%s,0x%04X (0x%08X)",rn(rt),imm,v);
        set_reg(rt, v); break; }
    case 0x10: { // COP0 — system control (MFC0/MTC0/RFE)
        uint32_t rs_field = (instr >> 21) & 0x1F;
        uint32_t rd_field = (instr >> 11) & 0x1F;
        if (rs_field == 0x00) { // MFC0 — read CP0 reg to GPR
            uint32_t val = 0;
            switch (rd_field) {
            case 12: val = cp0_status; break;
            case 13: val = cp0_cause; break;
            case 14: val = cp0_epc; break;
            }
            snprintf(desc,80,"mfc0 $%s,$%d (0x%08X)",rn(rt),rd_field,val);
            set_reg(rt, val);
        } else if (rs_field == 0x04) { // MTC0 — write GPR to CP0 reg
            uint32_t val = get_reg(rt);
            switch (rd_field) {
            case 12: cp0_status = val; break;
            case 13: cp0_cause = val; break;
            case 14: cp0_epc = val; break;
            }
            snprintf(desc,80,"mtc0 $%s,$%d (0x%08X)",rn(rt),rd_field,val);
        } else if (rs_field == 0x10) { // COP0 sub-ops (funct in low 6 bits)
            uint32_t cop0_funct = instr & 0x1F;
            if (cop0_funct == 0x10) { // RFE — Restore From Exception
                // Pop interrupt stack: IEp->IEc, IEo->IEp
                // SR = (SR & ~0xF) | ((SR >> 2) & 0xF)
                uint32_t old_low6 = cp0_status & 0x3F;
                uint32_t new_low6 = (old_low6 >> 2) & 0x0F;
                cp0_status = (cp0_status & ~0x0F) | new_low6 | (old_low6 & 0x30);
                snprintf(desc,80,"rfe (Status: 0x%08X)", cp0_status);
            } else {
                snprintf(desc,80,"cop0 funct=0x%02X",cop0_funct);
            }
        } else {
            snprintf(desc,80,"cop0 rs=%d rd=%d",rs_field,rd_field);
        }
        break; }
    case 0x12: { // COP2 — GTE
        uint32_t rs_field = (instr >> 21) & 0x1F;
        uint32_t rd_field = (instr >> 11) & 0x1F;
        if (rs_field == 0x00) { // MFC2
            uint32_t val = g_mem ? g_mem->gte.read_reg(rd_field) : 0;
            snprintf(desc,80,"mfc2 $%s,cr%d (0x%08X)",rn(rt),rd_field,val);
            set_reg(rt, val);
        } else if (rs_field == 0x02) { // CFC2
            uint32_t val = g_mem ? g_mem->gte.read_reg(rd_field + 32) : 0;
            snprintf(desc,80,"cfc2 $%s,ccr%d (0x%08X)",rn(rt),rd_field,val);
            set_reg(rt, val);
        } else if (rs_field == 0x04) { // MTC2
            uint32_t val = get_reg(rt);
            snprintf(desc,80,"mtc2 $%s,cr%d (0x%08X)",rn(rt),rd_field,val);
            if (g_mem) g_mem->gte.write_reg(rd_field, val);
        } else if (rs_field == 0x06) { // CTC2
            uint32_t val = get_reg(rt);
            snprintf(desc,80,"ctc2 $%s,ccr%d (0x%08X)",rn(rt),rd_field,val);
            if (g_mem) g_mem->gte.write_reg(rd_field + 32, val);
        } else if (rs_field == 0x10) { // GTE command
            snprintf(desc,80,"cop2 0x%08X",instr);
            if (g_mem) g_mem->gte.execute(instr);
        } else {
            snprintf(desc,80,"cop2 rs=%d",rs_field);
        }
        break; }
    case 0x32: { // LWC2 — load word to GTE data register
        uint32_t a = get_reg(rs) + simm;
        uint32_t v = read32(a, mem_ctx);
        snprintf(desc,80,"lwc2 cr%d,0x%X($%s) [0x%08X]=0x%08X",rt,simm&0xFFFF,rn(rs),a,v);
        if (g_mem) g_mem->gte.write_reg(rt, v);
        break; }
    case 0x3A: { // SWC2 — store word from GTE data register
        uint32_t a = get_reg(rs) + simm;
        uint32_t v = g_mem ? g_mem->gte.read_reg(rt) : 0;
        snprintf(desc,80,"swc2 cr%d,0x%X($%s) [0x%08X]=0x%08X",rt,simm&0xFFFF,rn(rs),a,v);
        write32(a, v, mem_ctx);
        break; }
    case 0x20: { uint32_t a = get_reg(rs) + simm; int8_t v = (int8_t)read8(a, mem_ctx);
        snprintf(desc,80,"lb $%s,0x%X($%s) [0x%08X]=%d",rn(rt),simm&0xFFFF,rn(rs),a,v);
        set_reg(rt, (uint32_t)(int32_t)v); break; }
    case 0x21: { uint32_t a = get_reg(rs) + simm; int16_t v = (int16_t)read16(a, mem_ctx);
        snprintf(desc,80,"lh $%s,0x%X($%s) [0x%08X]=%d",rn(rt),simm&0xFFFF,rn(rs),a,v);
        set_reg(rt, (uint32_t)(int32_t)v); break; }
    case 0x23: { uint32_t a = get_reg(rs) + simm; uint32_t v = read32(a, mem_ctx);
        snprintf(desc,80,"lw $%s,0x%X($%s) [0x%08X]=0x%08X",rn(rt),simm&0xFFFF,rn(rs),a,v);
        set_reg(rt, v); break; }
    case 0x24: { uint32_t a = get_reg(rs) + simm; uint8_t v = read8(a, mem_ctx);
        snprintf(desc,80,"lbu $%s,0x%X($%s) [0x%08X]=%u",rn(rt),simm&0xFFFF,rn(rs),a,v);
        set_reg(rt, v); break; }
    case 0x25: { uint32_t a = get_reg(rs) + simm; uint16_t v = read16(a, mem_ctx);
        snprintf(desc,80,"lhu $%s,0x%X($%s) [0x%08X]=%u",rn(rt),simm&0xFFFF,rn(rs),a,v);
        set_reg(rt, v); break; }
    case 0x28: { uint32_t a = get_reg(rs) + simm;
        snprintf(desc,80,"sb $%s,0x%X($%s) [0x%08X]=0x%02X",rn(rt),simm&0xFFFF,rn(rs),a,get_reg(rt)&0xFF);
        write8(a, get_reg(rt) & 0xFF, mem_ctx); break; }
    case 0x29: { uint32_t a = get_reg(rs) + simm;
        snprintf(desc,80,"sh $%s,0x%X($%s) [0x%08X]=0x%04X",rn(rt),simm&0xFFFF,rn(rs),a,get_reg(rt)&0xFFFF);
        write16(a, get_reg(rt) & 0xFFFF, mem_ctx); break; }
    case 0x2B: { uint32_t a = get_reg(rs) + simm;
        snprintf(desc,80,"sw $%s,0x%X($%s) [0x%08X]=0x%08X",rn(rt),simm&0xFFFF,rn(rs),a,get_reg(rt));
        write32(a, get_reg(rt), mem_ctx); break; }
    default: snprintf(desc,80,"UNKNOWN op=0x%02X instr=0x%08X",opcode,instr); break;
    }

    if (log_enabled) add_log(cur_pc, instr, desc);

    // Capture meaningful instructions in trace ring (skip NOPs to save space)
    // Also capture branches/jumps since they're the ones that cause divergence
    // Use mips_disasm::disasm_str() from psx_reference_integrations.h for richer disassembly
    if (instr != 0x00000000 || is_branch) {
        std::string disasm = mips_disasm::disasm_str(instr, cur_pc);
        trace_ring_push(cur_pc, instr, disasm.c_str(), false, false);
    }

    // Check for null jump — skip silently (unimplemented callback)
    if (new_pc == 0) {
        // === ORCHESTRATION ENGINE: Auto-correct jump to NULL ===
        if (g_orch.enabled && g_orch.auto_correct(*this, 0, "Jump to NULL")) {
            new_pc = pc;
            pending_branch = false;
            in_branch_delay = false;
            return true;
        }
        // Non-fatal: log and skip the null call
        static int null_skip_count = 0;
        if (null_skip_count < 20) {
            printf("[NULLSKIP] Jump to NULL at PC=0x%08X instr #%llu — skipping\n", cur_pc, instructions);
            null_skip_count++;
        }
        new_pc = pc;
        pending_branch = false;
        in_branch_delay = false;
        return true;
    }

    // Check for jump to unmapped memory (outside valid PSX ranges)
    bool new_pc_valid = (new_pc < 0x00200000) ||
                        (new_pc >= 0x80000000 && new_pc < 0x80200000) ||
                        (new_pc >= 0xA0000000 && new_pc < 0xA0200000) ||
                        (new_pc >= 0x1FC00000 && new_pc < 0x1FC80000) ||
                        (new_pc >= 0xBFC00000 && new_pc < 0xBFC80000) ||
                        new_pc == 0xA0 || new_pc == 0xB0 || new_pc == 0xC0 ||
                        new_pc == 0x80000080;
    if (!new_pc_valid && is_branch) {
        // === ORCHESTRATION ENGINE: Auto-correct branch to unmapped address ===
        if (g_orch.enabled && g_orch.auto_correct(*this, new_pc, "Branch to unmapped")) {
            // Override the branch target with corrected PC
            new_pc = pc;
            pending_branch = false;
            in_branch_delay = false;
            // Don't crash — continue from corrected PC
            return true;
        }
        dump_trace_ring("BRANCH TO UNMAPPED MEMORY");
        crashed = true;
        snprintf(crash_reason, 255,
                 "DIVERGENCE: Branch to unmapped 0x%08X from PC=0x%08X (instr #%llu)",
                 new_pc, cur_pc, instructions);
        return false;
    }

    // MIPS branch delay slot handling:
    // When a branch is taken, the next instruction (delay slot) executes
    // before the jump actually happens.
    if (pending_branch) {
        // We just executed the delay slot instruction
        // Now jump to the branch target
        pc = branch_target;
        pending_branch = false;
        in_branch_delay = false;
    } else if (is_branch) {
        // This was a branch/jump — set up delay slot execution
        branch_target = new_pc;
        pending_branch = true;
        in_branch_delay = true;
        pc = cur_pc + 4;  // Execute delay slot next
    } else {
        pc = new_pc;
    }

    // === ORCHESTRATION ENGINE: Post-exec hooks ===
    if (g_orch.enabled) {
        g_orch.run_hooks(*this, *g_mem, false);
    }

    return true;
}

// ============================================================================
// PSX Memory — Read/Write with hardware register handling
// ============================================================================

uint32_t PSX_Memory::read32(uint32_t addr) {
    // RAM (mirrored at 0x00000000, 0x80000000, 0xA0000000)
    if (is_ram(addr)) {
        uint32_t off = ram_offset(addr);
        // Phase 6: watchpoint check
        if (wp_count > 0) check_watchpoint_read(addr);
        // Trace VBlank counter reads (0x800B63D8) to understand VSync polling
        if (addr == 0x800B63D8 && g_cpu && g_cpu->instructions > 520000) {
            static int vbc_read_count = 0;
            if (vbc_read_count < 30) {
                uint32_t val = ram[off] | (ram[off+1]<<8) | (ram[off+2]<<16) | (ram[off+3]<<24);
                printf("[VBCREAD] #%d at PC=0x%08X instr #%llu val=0x%08X\n",
                       vbc_read_count, g_cpu->pc, g_cpu->instructions, val);
                vbc_read_count++;
            }
        }
        // Trace reads from game's VSync counter at 0x800BA294
        // (lui $v0,0x800C + lw $v0,0xA294($v0) = 0x800C0000 + (int16_t)0xA294 = 0x800BA294)
        if (addr == 0x800BA294 && g_cpu && g_cpu->instructions > 520000) {
            static uint32_t last_val = 0xFFFFFFFF;
            uint32_t val = ram[off] | (ram[off+1]<<8) | (ram[off+2]<<16) | (ram[off+3]<<24);
            if (val != last_val) {
                printf("[VBC2READ] at PC=0x%08X instr #%llu val=0x%08X (changed!)\n",
                       g_cpu->pc, g_cpu->instructions, val);
                last_val = val;
            }
        }
        // Trace reads to GPUSTAT (0x1F801814) after instr 520000
        if (addr == 0x1F801814 && g_cpu && g_cpu->instructions > 520000 && g_cpu->instructions < 980000) {
            static int gpu_read_count = 0;
            if (gpu_read_count < 20) {
                printf("[GPURD] #%d at PC=0x%08X instr #%llu\n",
                       gpu_read_count, g_cpu->pc, g_cpu->instructions);
                gpu_read_count++;
            }
        }
        // Trace reads to I_STAT (0x1F801070) after instr 520000
        if (addr == 0x1F801070 && g_cpu && g_cpu->instructions > 520000 && g_cpu->instructions < 980000) {
            static int istat_read_count = 0;
            if (istat_read_count < 20) {
                printf("[ISTATRD] #%d at PC=0x%08X instr #%llu val=0x%02X\n",
                       istat_read_count, g_cpu->pc, g_cpu->instructions, intc_stat);
                istat_read_count++;
            }
        }
        // Trace reads to Timer0 counter (0x1F801110) after instr 520000
        if (addr == 0x1F801110 && g_cpu && g_cpu->instructions > 520000 && g_cpu->instructions < 980000) {
            static int t0_read_count = 0;
            if (t0_read_count < 20) {
                printf("[T0RD] #%d at PC=0x%08X instr #%llu val=0x%04X\n",
                       t0_read_count, g_cpu->pc, g_cpu->instructions, timer_count[0] & 0xFFFF);
                t0_read_count++;
            }
        }
        // Comprehensive CD-ROM register read tracing (file-based)
        if (addr >= 0x1F801800 && addr <= 0x1F801803 && g_cpu) {
            CDLOG("[CDRD32] 0x%08X at PC=0x%08X instr #%llu\n",
                       addr, g_cpu->pc, g_cpu->instructions);
        }
        // Trace reads from CD status flag 0x800B9164 during main loop
        if (addr == 0x800B9164 && g_cpu && g_cpu->instructions > 2400000) {
            static int cdstat_read_count = 0;
            uint32_t val = ram[off] | (ram[off+1]<<8) | (ram[off+2]<<16) | (ram[off+3]<<24);
            if (cdstat_read_count < 30) {
                if (g_verbose) printf("[CDSTAT] read [0x800B9164]=0x%08X at PC=0x%08X instr #%llu\n",
                       val, g_cpu->pc, g_cpu->instructions);
                cdstat_read_count++;
            }
        }
        // Trace reads from 0x800BA65C (CD_init addr parameter)
        if (addr == 0x800BA65C && g_cpu && g_cpu->instructions > 2400000) {
            static int cdinit_read_count = 0;
            uint32_t val = ram[off] | (ram[off+1]<<8) | (ram[off+2]<<16) | (ram[off+3]<<24);
            if (cdinit_read_count < 10) {
                if (g_verbose) printf("[CDINITMEM] read [0x800BA65C]=0x%08X at PC=0x%08X instr #%llu\n",
                       val, g_cpu->pc, g_cpu->instructions);
                cdinit_read_count++;
            }
        }
        // Trace reads from 0x800B915C (CD status pointer) and 0x800B9160 (Timer0 mirror ptr)
        if (addr == 0x800B915C && g_cpu && g_cpu->instructions > 2400000) {
            static int cdp_read_count = 0;
            uint32_t val = ram[off] | (ram[off+1]<<8) | (ram[off+2]<<16) | (ram[off+3]<<24);
            if (cdp_read_count < 10) {
                if (g_verbose) printf("[CDPTR] read [0x800B915C]=0x%08X at PC=0x%08X instr #%llu\n",
                       val, g_cpu->pc, g_cpu->instructions);
                // Also read what the pointer points to
                if (val >= 0x80000000 && val < 0x80200000) {
                    uint32_t target_val = g_mem->read32(val);
                    if (g_verbose) printf("[CDPTR] *0x%08X = 0x%08X (CD status flags)\n", val, target_val);
                }
                cdp_read_count++;
            }
        }
        if (addr == 0x800B9160 && g_cpu && g_cpu->instructions > 2400000) {
            static int t0ptr_read_count = 0;
            uint32_t val = ram[off] | (ram[off+1]<<8) | (ram[off+2]<<16) | (ram[off+3]<<24);
            if (t0ptr_read_count < 10) {
                if (g_verbose) printf("[T0PTR] read [0x800B9160]=0x%08X at PC=0x%08X instr #%llu\n",
                       val, g_cpu->pc, g_cpu->instructions);
                t0ptr_read_count++;
            }
        }
        // Trace reads from 0x800B9168 (VBlank count save)
        if (addr == 0x800B9168 && g_cpu && g_cpu->instructions > 2400000) {
            static int vbc_save_count = 0;
            uint32_t val = ram[off] | (ram[off+1]<<8) | (ram[off+2]<<16) | (ram[off+3]<<24);
            if (vbc_save_count < 10) {
                if (g_verbose) printf("[VBCSAVE] read [0x800B9168]=0x%08X at PC=0x%08X instr #%llu\n",
                       val, g_cpu->pc, g_cpu->instructions);
                vbc_save_count++;
            }
        }
        // Trace reads from 0x800B91CE (CD ready check flag - main loop polls this)
        if (addr == 0x800B91CE && g_cpu) {
            static int cdready_read_count = 0;
            uint16_t val = ram[off] | (ram[off+1]<<8);
            if (cdready_read_count < 20) {
                if (g_verbose) printf("[CDREADY_RD] read [0x800B91CE]=0x%04X at PC=0x%08X instr #%llu\n",
                       val, g_cpu->pc, g_cpu->instructions);
                cdready_read_count++;
            }
        }
        // Trace reads from 0x800B91CC (CD init done flag)
        if (addr == 0x800B91CC && g_cpu) {
            static int cdinit_done_count = 0;
            uint16_t val = ram[off] | (ram[off+1]<<8);
            if (cdinit_done_count < 20) {
                if (g_verbose) printf("[CDINIT_DONE_RD] read [0x800B91CC]=0x%04X at PC=0x%08X instr #%llu\n",
                       val, g_cpu->pc, g_cpu->instructions);
                cdinit_done_count++;
            }
        }
        return (ram[off] | (ram[off+1]<<8) | (ram[off+2]<<16) | (ram[off+3]<<24));
    }
    
    // Scratchpad (0x1F800000-0x1F800FFF)
    if (addr >= 0x1F800000 && addr < 0x1F801000) {
        uint32_t off = addr & 0xFFF;
        return (scratch[off] | (scratch[off+1]<<8) | (scratch[off+2]<<16) | (scratch[off+3]<<24));
    }

    // Hardware registers (0x1F801000-0x1F802000)
    if (addr >= 0x1F801000 && addr < 0x1F802000) {
        // SIO0 registers (0x1F801000-0x1F80100F) — controller/memory card serial
        if (addr < 0x1F801010) {
            if (addr == 0x1F801000) {
                // Data register: return next byte from RX buffer
                uint32_t val = 0;
                if (sio0_rx_pos < sio0_rx_count) {
                    val = sio0_rx_buf[sio0_rx_pos++];
                }
                return val;
            }
            if (addr == 0x1F801004) {
                // Status: TX ready (bit 0), RX ready (bit 1), CTS (bit 2), IRQ (bit 7)
                uint32_t status = sio0_status | 0x05;  // TX ready + CTS always set
                if (sio0_rx_pos < sio0_rx_count) {
                    status |= 0x02;  // RX ready
                }
                return status;
            }
            if (addr == 0x1F801008) return sio0_control;
            if (addr == 0x1F80100C) return sio0_baud;
            return 0;
        }
        
        // I_STAT (Interrupt Controller Status) at 0x1F801070
        if (addr == 0x1F801070) return intc_stat;
        // I_MASK (Interrupt Controller Mask) at 0x1F801074
        if (addr == 0x1F801074) return intc_mask;
        
        // DMA Registers (0x1F801080-0x1F8010FF)
        // Real PSX layout: per-channel +0=MADR, +4=BCR, +8=CHCR
        // DPCR is global at 0x1F8010F0
        if (addr >= 0x1F801080 && addr < 0x1F8010F0) {
            int d = (addr - 0x1F801080) / 0x10;
            int reg = (addr - 0x1F801080) & 0xF;
            if (reg == 0x0) return dma_madr[d & 7];     // MADR
            if (reg == 0x4) return dma_bcr[d & 7];      // BCR
            if (reg == 0x8) {                            // CHCR
                uint32_t chcr = dma_chcr[d & 7];
                if (dma_done[d & 7]) {
                    chcr &= ~(1 << 24);  // Clear start bit when done
                }
                return chcr;
            }
            return 0;
        }
        // DPCR (global) at 0x1F8010F0
        if (addr == 0x1F8010F0) return dma_ctrl[0];
        if (addr == 0x1F8010F4) return dma_ctrl[1];
        
        // TIMER registers (0x1F801100-0x1F80112F)
        if (addr >= 0x1F801100 && addr < 0x1F801130) {
            int t = (addr - 0x1F801100) / 0x10;
            int reg = (addr - 0x1F801100) & 0xF;
            if (reg == 0) return timer_count[t & 3];        // Counter value
            if (reg == 4) return timer_mode[t & 3] | 0x800; // Mode (reached target bit set)
            if (reg == 8) return timer_target[t & 3];       // Target
            return 0;
        }
        
        // GPU registers (0x1F801810-0x1F801814)
        if (addr == 0x1F801810) {
            if (gpu_xfer_w > 0 && gpu_xfer_is_read) {
                // VRAM→CPU transfer: return current pixel and advance
                uint16_t vx = (gpu_xfer_x + gpu_xfer_cx) & (VRAM_W - 1);
                uint16_t vy = (gpu_xfer_y + gpu_xfer_cy) & (VRAM_H - 1);
                gpu_read_data = vram[vy * VRAM_W + vx];
                gpu_xfer_cx++;
                if (gpu_xfer_cx >= gpu_xfer_w) {
                    gpu_xfer_cx = 0;
                    gpu_xfer_cy++;
                    if (gpu_xfer_cy >= gpu_xfer_h) {
                        gpu_xfer_w = 0;
                        gpu_xfer_h = 0;
                    }
                }
            }
            return gpu_read_data;   // GPUREAD
        }
        if (addr == 0x1F801814) {
            return compute_gpustat();
        }
        
        // CD-ROM registers (0x1F801800-0x1F801803)
        if (addr == 0x1F801800) {
            return cdrom_get_status();
        }
        
        // MDEC registers (0x1F801820-0x1F80182F)
        if (addr >= 0x1F801820 && addr <= 0x1F80182F) {
            return g_mdec.read_reg(addr);
        }

        // SPU registers (0x1F801C00-0x1F801DFF) — 16-bit regs, packed in 32-bit
        if (addr >= 0x1F801C00 && addr < 0x1F801E00) {
            uint16_t lo = g_spu.read_reg(addr);
            uint16_t hi = g_spu.read_reg(addr + 2);
            return lo | (hi << 16);
        }

        // Default: return stored value
        uint32_t off = (addr - 0x1F801000) / 4;
        return hw_regs[off];
    }

    // BIOS ROM area (0xBFC00000+ KSEG1, 0x1FC00000+ KSEG0)
    if (addr >= 0xBFC00000 && addr < 0xBFC80000) {
        uint32_t off = addr - 0xBFC00000;
        return (bios[off] | (bios[off+1]<<8) | (bios[off+2]<<16) | (bios[off+3]<<24));
    }
    if (addr >= 0x1FC00000 && addr < 0x1FC80000) {
        uint32_t off = addr - 0x1FC00000;
        return (bios[off] | (bios[off+1]<<8) | (bios[off+2]<<16) | (bios[off+3]<<24));
    }

    // Cache control / other — return 0
    return 0;
}

uint16_t PSX_Memory::read16(uint32_t addr) {
    if (is_ram(addr)) {
        uint32_t off = ram_offset(addr);
        // Trace display flag and event flag reads during VSync window
        if (g_cpu && g_cpu->instructions > 520000 && g_cpu->instructions < 980000) {
            static int r16_count = 0;
            if (r16_count < 40 && (addr == 0x800B5312 || addr == 0x800B679C || addr == 0x800B5310 || addr == 0x800B5314)) {
                uint16_t val = ram[off] | (ram[off+1] << 8);
                if (g_verbose) printf("[R16] addr=0x%08X val=0x%04X at PC=0x%08X instr #%llu\n",
                       addr, val, g_cpu->pc, g_cpu->instructions);
                r16_count++;
            }
        }
        // Trace and force CD ready flag at 0x800B91CE
        if (addr == 0x800B91CE && g_cpu) {
            static int cdready16_count = 0;
            uint16_t val = ram[off] | (ram[off+1] << 8);
            if (cdready16_count < 30) {
                if (g_verbose) printf("[CDREADY_R16] read 0x800B91CE = 0x%04X at PC=0x%08X instr #%llu\n",
                       val, g_cpu->pc, g_cpu->instructions);
                cdready16_count++;
            }
            // Force return 1 after CD init has started
            if (g_cpu->instructions > 500000) {
                ram[off] = 0x01;
                ram[off+1] = 0x00;
                return 1;
            }
        }
        // Trace CD init done flag at 0x800B91CC
        if (addr == 0x800B91CC && g_cpu) {
            static int cdinit16_count = 0;
            uint16_t val = ram[off] | (ram[off+1] << 8);
            if (cdinit16_count < 20) {
                if (g_verbose) printf("[CDINIT_R16] read 0x800B91CC = 0x%04X at PC=0x%08X instr #%llu\n",
                       val, g_cpu->pc, g_cpu->instructions);
                cdinit16_count++;
            }
            if (g_cpu->instructions > 1200000) {
                ram[off] = 0x01;
                ram[off+1] = 0x00;
                return 1;
            }
        }
        return ram[off] | (ram[off+1] << 8);
    }
    if (addr >= 0x1F800000 && addr < 0x1F801000) {
        return scratch[addr & 0xFFF] | (scratch[(addr & 0xFFF)+1] << 8);
    }
    // SPU registers (0x1F801C00-0x1F801DFF) — 16-bit access
    if (addr >= 0x1F801C00 && addr < 0x1F801E00) {
        return g_spu.read_reg(addr);
    }
    return (uint16_t)(read32(addr & ~3) >> ((addr & 2) * 8));
}

uint8_t PSX_Memory::read8(uint32_t addr) {
    if (is_ram(addr)) {
        // Trace event flag byte reads during VSync window
        if (g_cpu && g_cpu->instructions > 520000 && g_cpu->instructions < 980000) {
            static int r8_count = 0;
            if (r8_count < 40 && (addr == 0x800B679C || addr == 0x800B679D || addr == 0x800B679E)) {
                if (g_verbose) printf("[R8] addr=0x%08X val=0x%02X at PC=0x%08X instr #%llu\n",
                       addr, ram[ram_offset(addr)], g_cpu->pc, g_cpu->instructions);
                r8_count++;
            }
        }
        return ram[ram_offset(addr)];
    }
    if (addr >= 0x1F800000 && addr < 0x1F801000) {
        return scratch[addr & 0xFFF];
    }
    // CD-ROM response register at 0x1F801801 — pops from response FIFO
    if (addr == 0x1F801801) {
        uint8_t v = 0;
        if (cdrom_response_pos < cdrom_response_count) {
            v = cdrom_response_fifo[cdrom_response_pos++];
        }
        if (cdrom_response_pos >= cdrom_response_count) {
            cdrom_response_ready = false;  // FIFO drained
            cdrom_response_count = 0;
            cdrom_response_pos = 0;
        }
        if (g_cpu) {
            CDLOG("[CDRD8] 0x1F801801 = 0x%02X (rpos=%d/%d) at PC=0x%08X instr #%llu\n",
                       v, cdrom_response_pos, cdrom_response_count, g_cpu->pc, g_cpu->instructions);
        }
        return v;
    }
    // CD-ROM data register at 0x1F801802 — reads from sector data buffer
    // PSoXide pop_data_fifo_byte: gated on data_transfer_active (request register bit 7)
    if (addr == 0x1F801802) {
        uint8_t v = 0;
        if (cdrom_data_transfer_active && cdrom_data_sector_pos < 2048) {
            v = cdrom_data_sector[cdrom_data_sector_pos++];
            if (cdrom_data_sector_pos >= 2048) {
                cdrom_data_ready = false;       // FIFO exhausted
                cdrom_data_transfer_active = false; // PSoXide: clear transfer latch
            }
        } else if (!cdrom_data_transfer_active) {
            // PSoXide: stray reads with no transfer armed clear data_fifo_ready
            cdrom_data_ready = false;
        }
        if (g_cpu) {
            CDLOG("[CDRD8] 0x1F801802 = 0x%02X (dpos=%d) at PC=0x%08X instr #%llu\n",
                       v, cdrom_data_sector_pos, g_cpu->pc, g_cpu->instructions);
        }
        return v;
    }
    // CD-ROM status at 0x1F801800 — DuckStation bit layout
    if (addr == 0x1F801800) {
        uint8_t status = cdrom_get_status();
        if (g_cpu) {
            CDLOG("[CDRD8] 0x1F801800 = 0x%02X at PC=0x%08X instr #%llu\n",
                       status, g_cpu->pc, g_cpu->instructions);
        }
        return status;
    }
    // CD-ROM 0x1F801803:
    //   Index 0: Interrupt Enable Register (read)
    //   Index 1: Interrupt Flag Register (read) — bits 0-2 = IRQ code, upper bits always 1
    if (addr == 0x1F801803) {
        uint8_t val;
        if (cdrom_index == 0) {
            // Interrupt Enable Register — upper bits always 1
            val = cdrom_int_enable | 0xE0;
        } else {
            // Interrupt Flag Register: IRQ code in bits 0-2, upper bits always 1
            val = (cdrom_int_flag & 0x07) | 0xF8;
        }
        if (g_cpu) {
            CDLOG("[CDRD8] 0x1F801803 = 0x%02X (index=%d) at PC=0x%08X instr #%llu\n",
                       val, cdrom_index, g_cpu->pc, g_cpu->instructions);
        }
        return val;
    }
    return (uint8_t)(read32(addr & ~3) >> ((addr & 3) * 8));
}

void PSX_Memory::write32(uint32_t addr, uint32_t val) {
    if (is_ram(addr)) {
        // Phase 6: watchpoint check
        if (wp_count > 0) check_watchpoint_write(addr, val);
        // Trace writes to THREAD_ENTRY_ADDR (0x800D9E80) — catch stub overwrite
        if (addr >= 0x800D9E80 && addr < 0x800D9EB0 && g_cpu) {
            fprintf(stderr, "[STUB_W] write 0x%08X = 0x%08X at PC=0x%08X instr #%llu\n",
                   addr, val, g_cpu->pc, g_cpu->instructions);
        }
        // Trace writes to VBlank counter at 0x800BA294
        if (addr == 0x800BA294 && g_cpu) {
            if (g_verbose) printf("[VBC2WRITE] 0x%08X = 0x%08X at PC=0x%08X instr #%llu\n",
                   addr, val, g_cpu->pc, g_cpu->instructions);
        }
        // Trace writes to CD status flag 0x800B9164
        if (addr == 0x800B9164 && g_cpu) {
            if (g_verbose) printf("[CDSTAT_W] write 0x800B9164 = 0x%08X at PC=0x%08X instr #%llu\n",
                   val, g_cpu->pc, g_cpu->instructions);
        }
        // Trace writes to 0x800BA65C (CD_init parameter)
        if (addr == 0x800BA65C && g_cpu) {
            if (g_verbose) printf("[CDINIT_W] write 0x800BA65C = 0x%08X at PC=0x%08X instr #%llu\n",
                   val, g_cpu->pc, g_cpu->instructions);
        }
        // Trace writes to 0x800B91CE (CD ready check flag)
        if (addr == 0x800B91CE && g_cpu) {
            if (g_verbose) printf("[CDREADY_W] write 0x800B91CE = 0x%08X at PC=0x%08X instr #%llu\n",
                   val, g_cpu->pc, g_cpu->instructions);
        }
        // Trace writes to 0x800B91CC (CD init done flag)
        if (addr == 0x800B91CC && g_cpu) {
            if (g_verbose) printf("[CDINIT_DONE_W] write 0x800B91CC = 0x%08X at PC=0x%08X instr #%llu\n",
                   val, g_cpu->pc, g_cpu->instructions);
        }
        // Trace writes to 0x800BA658 (CD state byte)
        if (addr == 0x800BA658 && g_cpu) {
            if (g_verbose) printf("[CDSTATE_W] write 0x800BA658 = 0x%08X at PC=0x%08X instr #%llu\n",
                   val, g_cpu->pc, g_cpu->instructions);
        }
        // Trace writes to display flag area (0x800B5312) and event flag (0x800B679C)
        if (addr >= 0x800B5310 && addr <= 0x800B5316 && g_cpu) {
            if (g_verbose) printf("[WPT] write32 0x%08X = 0x%08X at PC=0x%08X instr #%llu\n",
                   addr, val, g_cpu->pc, g_cpu->instructions);
        }
        if (addr >= 0x800B6798 && addr <= 0x800B67A0 && g_cpu) {
            if (g_verbose) printf("[WPT] write32 evt 0x%08X = 0x%08X at PC=0x%08X instr #%llu\n",
                   addr, val, g_cpu->pc, g_cpu->instructions);
        }
        // Trace writes to GPU init flag area (0x800B52A8)
        if (addr >= 0x800B52A0 && addr <= 0x800B52B0 && g_cpu) {
            if (g_verbose) printf("[WPT] write32 0x800B52A8 area 0x%08X = 0x%08X at PC=0x%08X instr #%llu\n",
                   addr, val, g_cpu->pc, g_cpu->instructions);
        }
        uint32_t off = ram_offset(addr);
        ram[off] = val & 0xFF;
        ram[off+1] = (val >> 8) & 0xFF;
        ram[off+2] = (val >> 16) & 0xFF;
        ram[off+3] = (val >> 24) & 0xFF;
        return;
    }
    if (addr >= 0x1F800000 && addr < 0x1F801000) {
        uint32_t off = addr & 0xFFF;
        scratch[off] = val & 0xFF;
        scratch[off+1] = (val >> 8) & 0xFF;
        scratch[off+2] = (val >> 16) & 0xFF;
        scratch[off+3] = (val >> 24) & 0xFF;
        return;
    }
    if (addr >= 0x1F801000 && addr < 0x1F802000) {
        // SIO0 registers (0x1F801000-0x1F80100F)
        if (addr < 0x1F801010) {
            if (addr == 0x1F801000) {
                // Data write: controller/memory card command byte
                sio0_data = val & 0xFF;
                // Simulate standard digital controller response
                // Controller poll: send 0x01, get 0x41 (digital) or 0x73 (analog)
                // Then send 0x42 (read data), get 0x5A (good) + 2 bytes buttons + 2 bytes stick
                if ((val & 0xFF) == 0x01) {
                    // Controller type query: respond with digital controller ID
                    sio0_rx_buf[0] = 0x41;  // Digital controller
                    sio0_rx_buf[1] = 0x5A;  // Good response
                    sio0_rx_buf[2] = 0xFF;  // All buttons unpressed
                    sio0_rx_buf[3] = 0xFF;
                    sio0_rx_buf[4] = 0x00;
                    sio0_rx_buf[5] = 0x00;
                    sio0_rx_count = 6;
                    sio0_rx_pos = 0;
                } else {
                    // Generic: echo back with idle response
                    sio0_rx_buf[0] = 0xFF;
                    sio0_rx_count = 1;
                    sio0_rx_pos = 0;
                }
            }
            if (addr == 0x1F801004) sio0_status = val;
            if (addr == 0x1F801008) {
                sio0_control = val;
                // Bit 0: TX enable, bit 1: RX enable, bit 2: ACK enable
                // Bit 4: controller select, bit 6: memory card select
                // When transfer starts (bit 0 set), prepare response
                if ((val & 0x01) && g_cpu) {
                    if (g_verbose) printf("[SIO0] Transfer start: ctrl=0x%08X data=0x%02X at PC=0x%08X instr #%llu\n",
                           val, sio0_data, g_cpu->pc, g_cpu->instructions);
                }
            }
            if (addr == 0x1F80100C) sio0_baud = val;
            return;
        }
        
        uint32_t off = (addr - 0x1F801000) / 4;
        hw_regs[off] = val;
        
        if (addr == 0x1F801070) {
            intc_stat = val;
            if (g_cpu && g_verbose) printf("[HWREG] I_STAT write = 0x%08X at PC=0x%08X instr #%llu\n",
                   val, g_cpu->pc, g_cpu->instructions);
        }
        if (addr == 0x1F801074) {
            intc_mask = val;
            if (g_cpu && g_verbose) printf("[HWREG] I_MASK write = 0x%08X at PC=0x%08X instr #%llu\n",
                   val, g_cpu->pc, g_cpu->instructions);
        }
        
        // DMA Registers (real PSX layout: +0=MADR, +4=BCR, +8=CHCR)
        if (addr >= 0x1F801080 && addr < 0x1F8010F0) {
            int d = (addr - 0x1F801080) / 0x10;
            int reg = (addr - 0x1F801080) & 0xF;
            if (reg == 0x0) { dma_madr[d & 7] = val; }     // MADR
            else if (reg == 0x4) { dma_bcr[d & 7] = val; }      // BCR
            else if (reg == 0x8) {                                // CHCR
                dma_chcr[d & 7] = val;
                if ((val >> 24) & 1) {
                    // DMA transfer started
                    uint32_t madr = dma_madr[d & 7] & 0x00FFFFFF;
                    uint32_t bcr = dma_bcr[d & 7];
                    uint32_t block_size = bcr & 0xFFFF;
                    uint32_t block_count = (bcr >> 16) & 0xFFFF;
                    uint32_t total_words = block_size * block_count;
                    int ch = d & 7;
                    
                    if (ch == 3) {
                        // CD-ROM DMA — transfer data from cdrom_data_sector buffer to RAM
                        // PSoXide: DMA ch3 drains the data FIFO via pop_dma_data_byte(),
                        // gated on data_fifo_ready (not the request-register transfer latch).
                        // The state machine (cdrom_tick) already read the sector into cdrom_data_sector
                        uint32_t sectors_to_read = total_words / 512;
                        if (sectors_to_read == 0) sectors_to_read = 1;
                        uint32_t ram_pos = madr;
                        uint8_t sector_buf[2048]; // For fallback direct read
                        ASSERT_STATE("CDROM_DMA_CH3_START", cdrom_reading || cdrom_data_ready,
                                     "DMA ch3 triggered but CD-ROM not reading and no data ready",
                                     1, (cdrom_reading ? 2 : 0) | (cdrom_data_ready ? 1 : 0));
                        for (uint32_t s = 0; s < sectors_to_read; s++) {
                            // PSoXide: DMA reads from data FIFO when data_fifo_ready is set.
                            // Our data FIFO is cdrom_data_sector, gated by cdrom_data_ready.
                            if (cdrom_data_ready) {
                                for (int w = 0; w < 512 && ram_pos + 3 < RAM_SIZE; w++) {
                                    uint32_t word = cdrom_data_sector[w*4] | (cdrom_data_sector[w*4+1] << 8) |
                                                    (cdrom_data_sector[w*4+2] << 16) | (cdrom_data_sector[w*4+3] << 24);
                                    ram[ram_offset(ram_pos)] = word & 0xFF;
                                    ram[ram_offset(ram_pos+1)] = (word >> 8) & 0xFF;
                                    ram[ram_offset(ram_pos+2)] = (word >> 16) & 0xFF;
                                    ram[ram_offset(ram_pos+3)] = (word >> 24) & 0xFF;
                                    ram_pos += 4;
                                }
                                if (g_verbose) printf("[DMA] CD-ROM sector -> RAM 0x%08X (%d bytes) instr #%llu\n",
                                       madr + s * 2048, 2048,
                                       g_cpu ? g_cpu->instructions : 0);
                                // PSoXide: when FIFO empties, clear data_fifo_ready and data_transfer_active
                                cdrom_data_ready = false; // Consumed
                                cdrom_data_transfer_active = false;
                                // If reading continuously, cdrom_tick will load the next sector
                            } else if (read_cd_sector(cdrom_cur_lba + s, sector_buf)) {
                                // Fallback: read directly if state machine hasn't loaded yet
                                for (int w = 0; w < 512 && ram_pos + 3 < RAM_SIZE; w++) {
                                    uint32_t word = sector_buf[w*4] | (sector_buf[w*4+1] << 8) |
                                                    (sector_buf[w*4+2] << 16) | (sector_buf[w*4+3] << 24);
                                    ram[ram_offset(ram_pos)] = word & 0xFF;
                                    ram[ram_offset(ram_pos+1)] = (word >> 8) & 0xFF;
                                    ram[ram_offset(ram_pos+2)] = (word >> 16) & 0xFF;
                                    ram[ram_offset(ram_pos+3)] = (word >> 24) & 0xFF;
                                    ram_pos += 4;
                                }
                                if (g_verbose) printf("[DMA] CD-ROM sector %u (fallback) -> RAM 0x%08X instr #%llu\n",
                                       cdrom_cur_lba + s, madr + s * 2048,
                                       g_cpu ? g_cpu->instructions : 0);
                            } else {
                                if (g_verbose) printf("[DMA] CD-ROM sector %u READ FAILED instr #%llu\n",
                                       cdrom_cur_lba + s, g_cpu ? g_cpu->instructions : 0);
                            }
                        }
                        // Mark DMA channel 3 as done so CHCR bit 24 clears on read
                        dma_done[3] = true;
                        // Fire CD-ROM DMA completion interrupt — handle_exception()
                        // will deliver the CD-ROM event when this IRQ is processed.
                        // Do NOT call deliver_event here — it causes double-delivery.
                        intc_stat |= 0x04; // CD-ROM IRQ (bit 2)
                        // Don't stop cdrom_reading — state machine handles continuous reads
                    } else if (ch == 2) {
                        // GPU DMA — direction depends on GP1(0x04)
                        if (g_verbose) printf("[DMA] GPU Ch2 start: MADR=0x%08X BCR=0x%08X dir=%d instr #%llu\n",
                               madr, bcr, gpu_dma_dir, g_cpu ? g_cpu->instructions : 0);
                        if (gpu_dma_dir == 3) {
                            // Linked list mode: CPU→GP0
                            // Each header word: [length(8) | next_addr(24)]
                            // Followed by 'length' data words fed to gpu_gp0()
                            uint32_t addr = madr & 0x00FFFFFF;
                            int safety = 0;
                            while (safety < 10000) {
                                uint32_t off = ram_offset(addr | 0x80000000);
                                uint32_t header = ram[off] | (ram[off+1]<<8) | (ram[off+2]<<16) | (ram[off+3]<<24);
                                uint32_t num_words = header >> 24;
                                uint32_t next_addr = header & 0x00FFFFFF;
                                // Feed data words to GPU as GP0 commands
                                for (uint32_t i = 0; i < num_words; i++) {
                                    uint32_t doff = ram_offset((addr + 4 + i*4) | 0x80000000);
                                    uint32_t cmd = ram[doff] | (ram[doff+1]<<8) | (ram[doff+2]<<16) | (ram[doff+3]<<24);
                                    gpu_gp0(cmd);
                                }
                                if (next_addr == 0x00FFFFFF || num_words == 0) break;
                                addr = next_addr;
                                safety++;
                            }
                            fb_dirty = true;
                        } else if (gpu_dma_dir == 1) {
                            // CPU→VRAM: read words from RAM at madr, feed as GP0 pixel data
                            uint32_t ram_off = ram_offset(madr);
                            for (uint32_t i = 0; i < total_words; i++) {
                                uint32_t word = ram[ram_off] | (ram[ram_off+1]<<8) | 
                                               (ram[ram_off+2]<<16) | (ram[ram_off+3]<<24);
                                ram_off = (ram_off + 4) & (RAM_SIZE - 1);
                                // Feed to GPU as if it were GP0 pixel data
                                if (gpu_xfer_w > 0 && !gpu_xfer_is_read) {
                                    // Write two 16-bit pixels to VRAM
                                    uint16_t p1 = word & 0xFFFF;
                                    uint16_t p2 = (word >> 16) & 0xFFFF;
                                    uint16_t vx = (gpu_xfer_x + gpu_xfer_cx) & (VRAM_W - 1);
                                    uint16_t vy = (gpu_xfer_y + gpu_xfer_cy) & (VRAM_H - 1);
                                    vram[vy * VRAM_W + vx] = p1;
                                    gpu_xfer_cx++;
                                    if (gpu_xfer_cx >= gpu_xfer_w) {
                                        gpu_xfer_cx = 0;
                                        gpu_xfer_cy++;
                                        if (gpu_xfer_cy >= gpu_xfer_h) {
                                            gpu_xfer_w = 0; gpu_xfer_h = 0;
                                            fb_dirty = true;
                                            break;
                                        }
                                    }
                                    if (gpu_xfer_w > 0) {
                                        vx = (gpu_xfer_x + gpu_xfer_cx) & (VRAM_W - 1);
                                        vy = (gpu_xfer_y + gpu_xfer_cy) & (VRAM_H - 1);
                                        vram[vy * VRAM_W + vx] = p2;
                                        gpu_xfer_cx++;
                                        if (gpu_xfer_cx >= gpu_xfer_w) {
                                            gpu_xfer_cx = 0;
                                            gpu_xfer_cy++;
                                            if (gpu_xfer_cy >= gpu_xfer_h) {
                                                gpu_xfer_w = 0; gpu_xfer_h = 0;
                                                fb_dirty = true;
                                                break;
                                            }
                                        }
                                    }
                                }
                            }
                            fb_dirty = true;
                        }
                    } else if (ch == 6) {
                        // OTC (reverse clear) — clear GPU ordering table
                        if (g_verbose) printf("[DMA] OTC Ch6: MADR=0x%08X words=%d instr #%llu\n",
                               madr, total_words, g_cpu ? g_cpu->instructions : 0);
                    } else if (ch == 0) {
                        // MDEC decode — RAM→MDEC input FIFO
                        uint32_t ram_off = ram_offset(madr);
                        for (uint32_t i = 0; i < total_words && ram_off + 3 < RAM_SIZE; i++) {
                            uint32_t word = ram[ram_off] | (ram[ram_off+1]<<8) | (ram[ram_off+2]<<16) | (ram[ram_off+3]<<24);
                            g_mdec.write_reg(0x1F801820, word);
                            ram_off = (ram_off + 4) & (RAM_SIZE - 1);
                        }
                        if (g_verbose) printf("[DMA] MDEC Ch0: MADR=0x%08X words=%d instr #%llu\n",
                               madr, total_words, g_cpu ? g_cpu->instructions : 0);
                    } else if (ch == 1) {
                        // MDEC output — MDEC→RAM
                        uint32_t ram_off = ram_offset(madr);
                        for (uint32_t i = 0; i < total_words && ram_off + 3 < RAM_SIZE; i++) {
                            uint32_t word = g_mdec.read_dma();
                            ram[ram_off] = word & 0xFF;
                            ram[ram_off+1] = (word >> 8) & 0xFF;
                            ram[ram_off+2] = (word >> 16) & 0xFF;
                            ram[ram_off+3] = (word >> 24) & 0xFF;
                            ram_off = (ram_off + 4) & (RAM_SIZE - 1);
                        }
                        if (g_verbose) printf("[DMA] MDEC Ch1: MADR=0x%08X words=%d instr #%llu\n",
                               madr, total_words, g_cpu ? g_cpu->instructions : 0);
                    } else if (ch == 4) {
                        // SPU data write — RAM→SPU RAM
                        uint32_t ram_off = ram_offset(madr);
                        g_spu.dma_write(madr & 0x7FFFF, &ram[ram_off], total_words * 4);
                        if (g_verbose) printf("[DMA] SPU Ch4: MADR=0x%08X words=%d instr #%llu\n",
                               madr, total_words, g_cpu ? g_cpu->instructions : 0);
                    } else if (ch == 5) {
                        // SPU data read — SPU RAM→RAM
                        uint32_t ram_off = ram_offset(madr);
                        g_spu.dma_read(madr & 0x7FFFF, &ram[ram_off], total_words * 4);
                        if (g_verbose) printf("[DMA] SPU Ch5: MADR=0x%08X words=%d instr #%llu\n",
                               madr, total_words, g_cpu ? g_cpu->instructions : 0);
                    } else {
                        if (g_verbose) printf("[DMA] Ch%d start: MADR=0x%08X BCR=0x%08X (bs=%d bc=%d words=%d) instr #%llu\n",
                               ch, madr, bcr, block_size, block_count, total_words,
                               g_cpu ? g_cpu->instructions : 0);
                    }
                    // Mark transfer as complete immediately
                    dma_done[ch] = true;
                }
            }
        }
        
        // Timer registers — log all mode writes (clock source changes are critical)
        if (addr >= 0x1F801100 && addr < 0x1F801130) {
            int t = (addr - 0x1F801100) / 0x10;
            int reg = (addr - 0x1F801100) & 0xF;
            if (reg == 0) {
                timer_count[t & 3] = val & 0xFFFF;
                if (g_cpu && g_verbose) printf("[HWREG] Timer%d count write = 0x%04X at PC=0x%08X instr #%llu\n",
                       t & 3, val & 0xFFFF, g_cpu->pc, g_cpu->instructions);
            }
            if (reg == 4) {
                uint32_t old_mode = timer_mode[t & 3];
                timer_mode[t & 3] = val & 0xFFFF;
                uint32_t src = (val >> 8) & 3;
                if (g_cpu && g_verbose) printf("[HWREG] Timer%d mode write = 0x%04X (src=%d target=%d) at PC=0x%08X instr #%llu (was 0x%04X)\n",
                       t & 3, val & 0xFFFF, src, val & 0xFFFF, g_cpu->pc, g_cpu->instructions, old_mode);
            }
            if (reg == 8) {
                timer_target[t & 3] = val & 0xFFFF;
                if (g_cpu && g_verbose) printf("[HWREG] Timer%d target write = 0x%04X at PC=0x%08X instr #%llu\n",
                       t & 3, val & 0xFFFF, g_cpu->pc, g_cpu->instructions);
            }
        }
        
        // CD-ROM registers (0x1F801800-0x1F801803)
        if (addr >= 0x1F801800 && addr <= 0x1F801803) {
            if (g_cpu && g_verbose) printf("[HWREG] CD-ROM write32 0x%08X = 0x%08X at PC=0x%08X instr #%llu\n",
                   addr, val, g_cpu->pc, g_cpu->instructions);
        }
        
        // GPU registers
        if (addr == 0x1F801810) {
            // GP0 command — route to GPU command processor
            static int gp0_log_count = 0;
            if (g_cpu && gp0_log_count < 50) {
                fprintf(stderr, "[GP0WR] 0x%08X at PC=0x%08X instr #%llu\n", val, g_cpu->pc, (unsigned long long)g_cpu->instructions);
                gp0_log_count++;
            }
            gpu_gp0(val);
        }
        if (addr == 0x1F801814) {
            // GP1 command — route to GPU command processor
            static int gp1_log_count = 0;
            if (g_cpu && gp1_log_count < 50) {
                fprintf(stderr, "[GP1WR] 0x%08X at PC=0x%08X instr #%llu\n", val, g_cpu->pc, (unsigned long long)g_cpu->instructions);
                gp1_log_count++;
            }
            gpu_gp1(val);
        }
        
        // MDEC registers (0x1F801820-0x1F80182F)
        if (addr >= 0x1F801820 && addr <= 0x1F80182F) {
            g_mdec.write_reg(addr, val);
        }
        
        // SPU registers (0x1F801C00-0x1F801DFF) — 16-bit regs, packed in 32-bit
        if (addr >= 0x1F801C00 && addr < 0x1F801E00) {
            g_spu.write_reg(addr, val & 0xFFFF);
            g_spu.write_reg(addr + 2, (val >> 16) & 0xFFFF);
        }
        
        return;
    }
    // Ignore writes to unmapped areas
}

void PSX_Memory::write16(uint32_t addr, uint16_t val) {
    if (is_ram(addr)) {
        // Trace writes to VBlank counter at 0x800BA294
        if (addr >= 0x800BA292 && addr <= 0x800BA298 && g_cpu) {
            if (g_verbose) printf("[VBC2W16] 0x%08X = 0x%04X at PC=0x%08X instr #%llu\n",
                   addr, val, g_cpu->pc, g_cpu->instructions);
        }
        // Trace writes to 0x800B91CE (CD ready flag) and 0x800B91CC (CD init done)
        if (addr == 0x800B91CE && g_cpu) {
            if (g_verbose) printf("[CDREADY_W16] write 0x800B91CE = 0x%04X at PC=0x%08X instr #%llu\n",
                   val, g_cpu->pc, g_cpu->instructions);
        }
        if (addr == 0x800B91CC && g_cpu) {
            if (g_verbose) printf("[CDINIT_W16] write 0x800B91CC = 0x%04X at PC=0x%08X instr #%llu\n",
                   val, g_cpu->pc, g_cpu->instructions);
        }
        // Trace writes to display flag (0x800B5312) and event flag (0x800B679C)
        if (addr >= 0x800B5310 && addr <= 0x800B5316 && g_cpu) {
            if (g_verbose) printf("[WPT] write16 0x%08X = 0x%04X at PC=0x%08X instr #%llu\n",
                   addr, val, g_cpu->pc, g_cpu->instructions);
        }
        if (addr >= 0x800B6798 && addr <= 0x800B67A0 && g_cpu) {
            if (g_verbose) printf("[WPT] write16 evt 0x%08X = 0x%04X at PC=0x%08X instr #%llu\n",
                   addr, val, g_cpu->pc, g_cpu->instructions);
        }
        if (addr >= 0x800B52A0 && addr <= 0x800B52B0 && g_cpu) {
            if (g_verbose) printf("[WPT] write16 0x800B52A8 area 0x%08X = 0x%04X at PC=0x%08X instr #%llu\n",
                   addr, val, g_cpu->pc, g_cpu->instructions);
        }
        uint32_t off = ram_offset(addr);
        ram[off] = val & 0xFF;
        ram[off+1] = (val >> 8) & 0xFF;
        return;
    }
    if (addr >= 0x1F800000 && addr < 0x1F801000) {
        scratch[addr & 0xFFF] = val & 0xFF;
        scratch[(addr & 0xFFF)+1] = (val >> 8) & 0xFF;
        return;
    }
    // SPU registers (0x1F801C00-0x1F801DFF) — 16-bit access
    if (addr >= 0x1F801C00 && addr < 0x1F801E00) {
        g_spu.write_reg(addr, val);
        return;
    }
}

void PSX_Memory::write8(uint32_t addr, uint8_t val) {
    if (is_ram(addr)) {
        // Trace writes to VBlank counter at 0x800BA294
        if (addr >= 0x800BA292 && addr <= 0x800BA298 && g_cpu) {
            if (g_verbose) printf("[VBC2W8] 0x%08X = 0x%02X at PC=0x%08X instr #%llu\n",
                   addr, val, g_cpu->pc, g_cpu->instructions);
        }
        // Trace writes to event flag (0x800B679C)
        if (addr >= 0x800B6798 && addr <= 0x800B67A0 && g_cpu) {
            if (g_verbose) printf("[WPT] write8 evt 0x%08X = 0x%02X at PC=0x%08X instr #%llu\n",
                   addr, val, g_cpu->pc, g_cpu->instructions);
        }
        // Trace writes to GPU init flag area (0x800B52A8)
        if (addr >= 0x800B52A0 && addr <= 0x800B52B0 && g_cpu) {
            if (g_verbose) printf("[WPT] write8 0x800B52A8 area 0x%08X = 0x%02X at PC=0x%08X instr #%llu\n",
                   addr, val, g_cpu->pc, g_cpu->instructions);
        }
        ram[ram_offset(addr)] = val;
        return;
    }
    if (addr >= 0x1F800000 && addr < 0x1F801000) {
        scratch[addr & 0xFFF] = val;
        return;
    }
    // CD-ROM index register at 0x1F801800 — bits 0-1 select sub-register index
    if (addr == 0x1F801800) {
        cdrom_index = val & 0x03;
        if (g_cpu) {
            CDLOG("[CDWR] 0x1F801800 = 0x%02X (index=%d) at PC=0x%08X instr #%llu\n",
                       val, cdrom_index, g_cpu->pc, g_cpu->instructions);
        }
        return;
    }
    // CD-ROM command register at 0x1F801801 (index=0: command, index=1: int enable)
    if (addr == 0x1F801801) {
        if (g_cpu) {
            CDLOG("[CDWR] 0x1F801801 = 0x%02X (index=%d) at PC=0x%08X instr #%llu\n",
                       val, cdrom_index, g_cpu->pc, g_cpu->instructions);
        }
        if (cdrom_index == 0) {
        if (g_verbose) printf("[CDDBG] entering cmd processing: cmd=0x%02X at instr #%llu\n", val, g_cpu ? g_cpu->instructions : 0);
        uint8_t cmd = val;
        // Clear response FIFO and prepare for new command
        cdrom_response_pos = 0;
        cdrom_response_count = 0;
        cdrom_response_ready = false;
        // Real PSX: receiving a new command auto-acknowledges any pending interrupt
        intc_stat &= ~0x04;
        cdrom_irq_code = 0;
        cdrom_irq_delay = 0;  // Cancel any pending delayed IRQ
        cdrom_int_flag = 0;
        // Set BUSYSTS — command is now pending
        cdrom_command_busy = true;
        
        // Helper lambda to push stat byte as first response byte (PSoXide stat_byte())
        auto sendACKAndStat = [&]() {
            cdrom_push_response(cdrom_stat_byte());
        };

        switch (cmd) {
            case 0x01: // GetStat — return secondary status
                sendACKAndStat();
                cdrom_set_interrupt(3);  // INT3
                break;
            case 0x02: { // Setloc — convert BCD params to LBA, set pending
                uint8_t min = cdrom_param_fifo[0];
                uint8_t sec = cdrom_param_fifo[1];
                uint8_t sect = cdrom_param_fifo[2];
                uint8_t m = (min >> 4) * 10 + (min & 0xF);
                uint8_t s = (sec >> 4) * 10 + (sec & 0xF);
                uint8_t f = (sect >> 4) * 10 + (sect & 0xF);
                uint32_t new_lba = (uint32_t)(m * 60 + s) * 75 + f - 150;
                // PSoXide: if jump > 16 sectors, reset seek_done
                uint32_t current_lba = (cdrom_cur_lba != 0) ? cdrom_cur_lba : cdrom_setloc_lba;
                if (new_lba > current_lba ? (new_lba - current_lba > 16) : (current_lba - new_lba > 16)) {
                    cdrom_seek_done = false;
                }
                cdrom_setloc_lba = new_lba;
                cdrom_setloc_pending = true;
                if (g_verbose) printf("[CDROM] Setloc LBA=%u (pending)\n", cdrom_setloc_lba);
                sendACKAndStat();
                cdrom_set_interrupt(3);
                break;
            }
            case 0x06: { // ReadN — start reading data (PSoXide cmd_read)
                cdrom_read_pending = false;
                cdrom_read_rescheduled = false;
                cdrom_pause_requested = false;
                cdrom_data_ready = false;
                cdrom_secondary_status &= ~cdrom_constants::STAT_PLAYING;
                cdrom_reading = true;
                cdrom_read_mode = 0;
                cdrom_sectors_read = 0;
                cdrom_read_start_lba = cdrom_cur_lba;
                cdrom_seek_done = true;
                // Apply pending setloc (PSoXide: setloc_pending → read_lba, location_changed)
                if (cdrom_setloc_pending) {
                    cdrom_cur_lba = cdrom_setloc_lba;
                    cdrom_setloc_pending = false;
                    cdrom_location_changed = true;
                }
                cdrom_secondary_status |= cdrom_constants::STAT_READING; // 0x20 reading bit
                sendACKAndStat();
                cdrom_set_interrupt(3);
                if (g_verbose) printf("[CDROM] ReadN started at LBA=%u (state machine)\n", cdrom_cur_lba);
                ASSERT_INFO_STATE("CDROM_READN_START", "ReadN started", cdrom_cur_lba, cdrom_cur_lba);
                break;
            }
            case 0x08: { // Stop — stop motor → INT3 then INT2 (PSoXide cmd_stop)
                cdrom_pause_requested = true;
                cdrom_reading = false;
                cdrom_read_pending = false;
                cdrom_location_changed = false;
                cdrom_read_rescheduled = false;
                cdrom_secondary_status &= ~cdrom_constants::STAT_READING; // clear reading bit
                cdrom_motor_on = false;
                cdrom_secondary_status &= ~cdrom_constants::STAT_MOTOR_ON; // clear motor bit
                sendACKAndStat();
                cdrom_set_interrupt(3);
                // PSoXide uses SEEK_SECOND_RESPONSE_CYCLES for stop completion
                cdrom_schedule_int2((int)cdrom_constants::SEEK_SECOND_RESPONSE_CYCLES, nullptr, 0);
                CDLOG("[CDROM] Stop + INT2 scheduled at instr #%llu\n", g_cpu ? g_cpu->instructions : 0);
                break;
            }
            case 0x09: { // Pause — abort reading → INT3 then INT2 (PSoXide cmd_pause)
                cdrom_pause_requested = true;
                cdrom_reading = false;
                cdrom_read_pending = false;
                cdrom_location_changed = false;
                cdrom_read_rescheduled = false;
                cdrom_secondary_status &= ~cdrom_constants::STAT_READING; // clear reading bit
                sendACKAndStat();
                cdrom_set_interrupt(3);
                // PSoXide: short delay if motor on (standby), long if stopped
                int delay = cdrom_motor_on ?
                    (int)cdrom_constants::PAUSE_COMPLETE_CYCLES_STANDBY :
                    (int)cdrom_constants::PAUSE_COMPLETE_CYCLES_ACTIVE;
                cdrom_schedule_int2(delay, nullptr, 0);
                CDLOG("[CDROM] Pause + INT2 scheduled at instr #%llu\n", g_cpu ? g_cpu->instructions : 0);
                break;
            }
            case 0x0A: { // Reset — soft reset CD-ROM → INT3 then INT2 (PSoXide cmd_reset)
                cdrom_reading = false;
                cdrom_read_pending = false;
                cdrom_pause_requested = false;
                cdrom_location_changed = false;
                cdrom_read_rescheduled = false;
                cdrom_seek_done = true;
                cdrom_setloc_pending = false;
                cdrom_secondary_status = 0; // clear all drive status
                cdrom_secondary_status |= cdrom_constants::STAT_MOTOR_ON; // motor on
                cdrom_motor_on = true;
                cdrom_mode = 0x20; // PSoXide: mode = 0x20 after reset
                cdrom_muted = false;
                cdrom_filter_file = 0;
                cdrom_filter_channel = 0;
                sendACKAndStat();
                cdrom_set_interrupt(3);
                cdrom_schedule_int2((int)cdrom_constants::RESET_SECOND_RESPONSE_CYCLES, nullptr, 0);
                CDLOG("[CDROM] Reset + INT2 scheduled at instr #%llu\n", g_cpu ? g_cpu->instructions : 0);
                break;
            }
            // 0x0B (Mute), 0x0C (Demute), 0x0D (Setfilter) handled by new cases below
            case 0x0E: { // Setmode — set CD-ROM mode → INT3 only (no INT2)
                cdrom_mode = cdrom_param_fifo[0];
                // Sector delay is now computed dynamically in cdrom_tick based on mode
                sendACKAndStat();
                cdrom_set_interrupt(3);
                CDLOG("[CDROM] Setmode=0x%02X (speed=%s) at instr #%llu\n",
                       cdrom_mode, (cdrom_mode & 0x80) ? "2x" : "1x", g_cpu ? g_cpu->instructions : 0);
                break;
            }
            case 0x0F: { // Getparam (Getmode) — return stat + mode + filter (PSoXide cmd_get_param)
                // PSoXide: 5-byte response [stat, mode, 0, filter_file, filter_channel]
                sendACKAndStat();
                cdrom_push_response(cdrom_mode);
                cdrom_push_response(0x00);
                cdrom_push_response(cdrom_filter_file);
                cdrom_push_response(cdrom_filter_channel);
                cdrom_set_interrupt(3);
                break;
            }
            case 0x14: { // GetTD — get track descriptor (corrected from 0x0D)
                cdrom_push_response(0x00);
                cdrom_push_response(0x02);
                cdrom_push_response(0x00);
                cdrom_set_interrupt(3);
                break;
            }
            case 0x1A: { // GetID — INT3 first, then INT2 with disc ID (PSoXide cmd_getid)
                sendACKAndStat();
                cdrom_set_interrupt(3);
                // PSoXide: stat, 0x00, 0x00, 0x00, 'P','C','S','X'
                uint8_t id_resp[] = {0x00, 0x00, 0x00, 'P', 'C', 'S', 'X'};
                cdrom_schedule_int2((int)cdrom_constants::GETID_SECOND_RESPONSE_CYCLES, id_resp, 7);
                CDLOG("[CDROM] GetID + INT2 scheduled at instr #%llu\n", g_cpu ? g_cpu->instructions : 0);
                break;
            }
            case 0x1D: // GetQ (corrected from 0x13)
                cdrom_push_response(0x00);
                cdrom_set_interrupt(3);
                break;
            case 0x19: { // Test — subcommand in param[0] (PSoXide cmd_test)
                uint8_t subcmd = cdrom_param_fifo[0];
                if (subcmd == 0x20) { // GetRegion — PSoXide: 0x98, 0x06, 0x10, 0xC3
                    cdrom_push_response(0x98);
                    cdrom_push_response(0x06);
                    cdrom_push_response(0x10);
                    cdrom_push_response(0xC3);
                    cdrom_set_interrupt(3);
                } else {
                    sendACKAndStat();
                    cdrom_set_interrupt(3);
                }
                break;
            }
            case 0x1B: { // ReadS — start continuous reading (no retry) (PSoXide cmd_read)
                cdrom_read_pending = false;
                cdrom_read_rescheduled = false;
                cdrom_pause_requested = false;
                cdrom_data_ready = false;
                cdrom_secondary_status &= ~cdrom_constants::STAT_PLAYING;
                cdrom_reading = true;
                cdrom_read_mode = 1;
                cdrom_sectors_read = 0;
                cdrom_read_start_lba = cdrom_cur_lba;
                cdrom_seek_done = true;
                // Apply pending setloc (PSoXide: setloc_pending → read_lba, location_changed)
                if (cdrom_setloc_pending) {
                    cdrom_cur_lba = cdrom_setloc_lba;
                    cdrom_setloc_pending = false;
                    cdrom_location_changed = true;
                }
                cdrom_secondary_status |= cdrom_constants::STAT_READING; // 0x20 reading bit
                sendACKAndStat();
                cdrom_set_interrupt(3);
                CDLOG("[CDROM] ReadS started at LBA=%u at instr #%llu\n", cdrom_cur_lba, g_cpu ? g_cpu->instructions : 0);
                ASSERT_INFO_STATE("CDROM_READS_START", "ReadS started", cdrom_cur_lba, cdrom_cur_lba);
                break;
            }
            case 0x07: { // MotorOn — spin up motor → INT3 (PSoXide cmd_motor_on)
                cdrom_motor_on = true;
                cdrom_secondary_status |= cdrom_constants::STAT_MOTOR_ON;
                sendACKAndStat();
                cdrom_set_interrupt(3);
                CDLOG("[CDROM] MotorOn at instr #%llu\n", g_cpu ? g_cpu->instructions : 0);
                break;
            }
            case 0x0B: { // Mute — mute audio → INT3
                cdrom_muted = true;
                sendACKAndStat();
                cdrom_set_interrupt(3);
                CDLOG("[CDROM] Mute at instr #%llu\n", g_cpu ? g_cpu->instructions : 0);
                break;
            }
            case 0x0C: { // Demute — unmute audio → INT3
                cdrom_muted = false;
                sendACKAndStat();
                cdrom_set_interrupt(3);
                CDLOG("[CDROM] Demute at instr #%llu\n", g_cpu ? g_cpu->instructions : 0);
                break;
            }
            case 0x0D: { // Setfilter — set file/channel filter → INT3
                cdrom_filter_file = cdrom_param_fifo[0];
                cdrom_filter_channel = cdrom_param_fifo[1];
                sendACKAndStat();
                cdrom_set_interrupt(3);
                CDLOG("[CDROM] Setfilter file=%d channel=%d at instr #%llu\n",
                       cdrom_filter_file, cdrom_filter_channel, g_cpu ? g_cpu->instructions : 0);
                break;
            }
            case 0x10: { // GetlocL — return current logical position → INT3
                // Return 8 bytes: minute, second, frame, file, channel, mode, ...
                cdrom_push_response(0x00); // minute
                cdrom_push_response(0x00); // second
                cdrom_push_response(0x00); // frame
                cdrom_push_response(0x01); // file
                cdrom_push_response(0x00); // channel
                cdrom_push_response(0x01); // mode
                cdrom_push_response(0x00); // padding
                cdrom_push_response(0x00); // padding
                cdrom_set_interrupt(3);
                break;
            }
            case 0x11: { // GetlocP — return current physical play position → INT3
                cdrom_push_response(0x01); // track
                cdrom_push_response(0x00); // index
                cdrom_push_response(0x02); // track number
                cdrom_push_response(0x01); // minute
                cdrom_push_response(0x01); // second
                cdrom_push_response(0x01); // frame
                cdrom_push_response(0x00); // reserved
                cdrom_push_response(0x02); // reserved
                cdrom_set_interrupt(3);
                break;
            }
            case 0x13: { // GetTN — get track number → INT3
                cdrom_push_response(0x01); // first track
                cdrom_push_response(0x01); // last track
                cdrom_set_interrupt(3);
                break;
            }
            case 0x12: { // Setsession — set session number → INT3 then INT2
                sendACKAndStat();
                cdrom_set_interrupt(3);
                cdrom_schedule_int2(200, nullptr, 0);
                CDLOG("[CDROM] Setsession + INT2 scheduled at instr #%llu\n", g_cpu ? g_cpu->instructions : 0);
                break;
            }
            case 0x15: { // SeekL — logical seek to Setloc position → INT3 then INT2 (PSoXide cmd_seek)
                if (cdrom_setloc_pending) {
                    cdrom_cur_lba = cdrom_setloc_lba;
                    cdrom_setloc_pending = false;
                }
                cdrom_reading = false;
                cdrom_read_pending = false;
                cdrom_location_changed = false;
                cdrom_read_rescheduled = false;
                cdrom_secondary_status &= ~cdrom_constants::STAT_PLAYING;
                sendACKAndStat();
                cdrom_set_interrupt(3);
                // PSoXide: short 0x800 delay if seek_done, long SEEK_SECOND_RESPONSE_CYCLES otherwise
                int delay = cdrom_seek_done ? 0x800 : (int)cdrom_constants::SEEK_SECOND_RESPONSE_CYCLES;
                cdrom_schedule_int2(delay, nullptr, 0);
                cdrom_seek_done = true;
                CDLOG("[CDROM] SeekL to LBA=%u + INT2 scheduled (delay=%d) at instr #%llu\n",
                       cdrom_cur_lba, delay, g_cpu ? g_cpu->instructions : 0);
                break;
            }
            case 0x16: { // SeekP — physical seek → INT3 then INT2 (PSoXide cmd_seek)
                cdrom_reading = false;
                cdrom_read_pending = false;
                cdrom_location_changed = false;
                cdrom_read_rescheduled = false;
                cdrom_secondary_status &= ~cdrom_constants::STAT_PLAYING;
                sendACKAndStat();
                cdrom_set_interrupt(3);
                // PSoXide: short 0x800 delay if seek_done, long SEEK_SECOND_RESPONSE_CYCLES otherwise
                int delay = cdrom_seek_done ? 0x800 : (int)cdrom_constants::SEEK_SECOND_RESPONSE_CYCLES;
                cdrom_schedule_int2(delay, nullptr, 0);
                cdrom_seek_done = true;
                CDLOG("[CDROM] SeekP + INT2 scheduled (delay=%d) at instr #%llu\n",
                       delay, g_cpu ? g_cpu->instructions : 0);
                break;
            }
            case 0x1C: { // Init — lid/rescan state machine → INT3 (PSoXide cmd_init)
                cdrom_reading = false;
                cdrom_read_pending = false;
                cdrom_pause_requested = false;
                cdrom_location_changed = false;
                cdrom_read_rescheduled = false;
                cdrom_secondary_status &= ~cdrom_constants::STAT_PLAYING;
                cdrom_secondary_status |= cdrom_constants::STAT_MOTOR_ON;
                cdrom_motor_on = true;
                cdrom_seek_done = true;
                cdrom_muted = false;
                sendACKAndStat();
                cdrom_set_interrupt(3);
                // PSoXide: Init returns only ACK, no INT2 (lid state machine handles the rest)
                CDLOG("[CDROM] Init at instr #%llu\n", g_cpu ? g_cpu->instructions : 0);
                break;
            }
            case 0x1E: { // ReadTOC → INT3 then INT2 (PSoXide cmd_read_toc)
                sendACKAndStat();
                cdrom_set_interrupt(3);
                // PSoXide: cdReadTime * 180 / 4 = 20,321,280 cycles
                cdrom_schedule_int2((int)(cdrom_constants::CD_READ_TIME * 180 / 4), nullptr, 0);
                CDLOG("[CDROM] ReadTOC + INT2 scheduled at instr #%llu\n", g_cpu ? g_cpu->instructions : 0);
                break;
            }
            default:
                sendACKAndStat();
                cdrom_set_interrupt(3);
                break;
        }
        // Trace command for diagnostics
        if (g_cpu) {
            uint32_t ra = g_cpu->regs[31];
            int param_count = cdrom_param_pos;
            int result = 0;
            // Detect Setloc param overflow
            if (cmd == 0x02 && param_count != 3) result = param_count;
            uint32_t prev_lba = g_cdrom_tracer.last_progress_lba;
            g_cdrom_tracer.log_command(cmd, cdrom_param_fifo, param_count,
                                       g_cpu->pc, ra, result);
            g_cdrom_tracer.commands.back().instruction_count = g_cpu->instructions;
            if (g_cdrom_tracer.last_progress_lba != prev_lba) {
                g_cdrom_tracer.instructions_at_last_progress = g_cpu->instructions;
            }
            // Section 5.2: Fire error breakpoint on CD-ROM parameter overflow
            if (result != 0) {
                g_cdrom_tracer.fire_error_breakpoint(cmd, cdrom_param_fifo,
                    param_count, g_cpu->pc, ra);
            }
        }
        // Clear param FIFO (EndCommand) — but do NOT clear BUSYSTS here.
        // PSoXide: command_busy stays set until the first response IRQ fires.
        cdrom_param_pos = 0;
        memset(cdrom_param_fifo, 0, sizeof(cdrom_param_fifo));
        } // end index==0
        return;
    }
    if (addr == 0x1F801802) {
        if (g_cpu) {
            CDLOG("[CDWR] 0x1F801802 = 0x%02X (index=%d) at PC=0x%08X instr #%llu\n",
                       val, cdrom_index, g_cpu->pc, g_cpu->instructions);
        }
        if (cdrom_index == 0) {
            // Index 0: Parameter register — collect params for next command
            if (cdrom_param_pos < 16) {
                cdrom_param_fifo[cdrom_param_pos++] = val;
            }
        } else if (cdrom_index == 1) {
            // Index 1: Interrupt Enable Register
            cdrom_int_enable = val;
        }
        return;
    }
    if (addr == 0x1F801803) {
        if (g_cpu) {
            CDLOG("[CDWR] 0x1F801803 = 0x%02X (index=%d) at PC=0x%08X instr #%llu\n",
                       val, cdrom_index, g_cpu->pc, g_cpu->instructions);
        }
        if (cdrom_index == 0) {
            // Index 0: Request Register (PSoXide write8_at 0x1F801803 idx=0)
            // Bit 6: BFRD reset — clear parameter FIFO
            if (val & 0x40) {
                cdrom_param_pos = 0;
                memset(cdrom_param_fifo, 0, sizeof(cdrom_param_fifo));
            }
            // Bit 7: data transfer arm — enables MMIO data FIFO reads
            if (val & 0x80) {
                cdrom_data_transfer_active = true;
                cdrom_bfrd = true;
            } else {
                cdrom_data_transfer_active = false;
                cdrom_bfrd = false;
                cdrom_data_sector_pos = 0;
            }
        } else if (cdrom_index == 1) {
            // Index 1: Interrupt Flag Register (write) — acknowledge interrupts
            // Bits 0-5 acknowledge specific interrupts, bit 6 clears parameter FIFO
            if (val & 0x07) {
                // Clear the acknowledged interrupt flags
                cdrom_int_flag &= ~(val & 0x07);
                if (cdrom_int_flag == 0) {
                    intc_stat &= ~0x04;  // Deassert IRQ line
                    cdrom_irq_code = 0;
                }
            }
            if (val & 0x40) {
                // Bit 6 clears the parameter FIFO
                cdrom_param_pos = 0;
                memset(cdrom_param_fifo, 0, sizeof(cdrom_param_fifo));
            }
        }
        return;
    }
}

// ============================================================================
// BIOS Call Handler — Stub PSX BIOS functions
// ============================================================================
// PSX BIOS calls use: jal to 0xA0/0xB0/0xC0 with $t1 = function number
// The game code typically does:
//   lui $t2, 0xA0/B0/C0
//   addiu $t1, $zero, fn_number
//   jr $t2
//   nop  (delay slot)
// We intercept when new_pc == 0xA0/0xB0/0xC0 and dispatch on $t1

// ── Approach 1: HLE C++ Exception Handler ──────────────────────────────────
// When PC lands at 0x80000080 and there's no MIPS code there, we handle the
// exception entirely in C++: acknowledge VBlank in I_STAT, deliver events
// through the HLE event system, then ReturnFromException to EPC.
bool PSX_Memory::handle_exception(MIPS_CPU& cpu) {
    uint32_t cause = cpu.cp0_cause;
    uint32_t ip_bits = (cause >> 8) & 0xFF;

    // Process all pending interrupts: deliver events and acknowledge I_STAT
    // This mirrors what the real PSX BIOS does before calling HookEntryInt.
    // The game's HookEntryInt handler expects interrupts to be acknowledged
    // and events to be delivered — it only does game-specific processing.

    // Handle VBlank interrupt (I_STAT bit 0) — always clear to prevent re-entry
    if (ip_bits & 0x01) {
        intc_stat &= ~0x01;
        // Only deliver VBlank-class events (RcEV[3], VBlank).
        // Do NOT deliver CD-ROM or other events on VBlank —
        // PCSX-R only delivers RcEV[3][1] on VSync.
        deliver_vblank_events();
    }

    // Handle CD-ROM interrupt (I_STAT bit 2)
    if (ip_bits & 0x04) {
        // Clear I_STAT bit 2 to prevent infinite exception re-entry.
        intc_stat &= ~0x04;
        // Deliver CD-ROM events only when CD-ROM IRQ actually fires.
        // This is the ONLY place CD-ROM events should be delivered.
        deliver_event(0xF2000002, 0x02);
        deliver_event(0xF0000009, 0x20);
        // NOTE: Do NOT clear cdrom_int_flag here — the game's HookEntryInt
        // reads it from 0x1F801803 index 1 to determine the IRQ type.
        // The game acknowledges it by writing to 0x1F801803 index 1.
        CDLOG("[CDIRQ] CD-ROM IRQ exception at instr #%llu (int_flag=%d, intc_stat=0x%08X)\n",
               g_cpu ? g_cpu->instructions : 0, cdrom_int_flag, intc_stat);
    }

    // Handle timer interrupts (I_STAT bits 4,5,6 = timers 0,1,2)
    for (int t = 0; t < 3; t++) {
        if (ip_bits & (1 << (t + 4))) {
            intc_stat &= ~(1 << (t + 4));
            deliver_rcnt_event(t, 0);
        }
    }

    // Do NOT unconditionally set 0x800B679C (event queue ready flag).
    // The game checks this flag at 0x800986A8:
    //   If non-zero → enters copy loop at 0x80098848 → STUCK (reads BIOS event
    //     table from RAM, which our HLE BIOS doesn't maintain)
    //   If zero → falls through to TestEvent polling at 0x800986B0 → WORKS
    //   (TestEvent checks our C++ event array and returns correct results)
    // The game's HookEntryInt handler should set this flag itself if needed.
    //
    // Keep CD-ROM status flags for game init progress.
    ram[ram_offset(0x800B91CC)] = 0x01;  // CD init done
    ram[ram_offset(0x800B91CE)] = 0x01;  // CD ready

    if (hook_entry_int_set && hook_entry_int_addr) {
        // SAVE the interrupted context first — ReturnFromException will restore it
        // Must save ALL GPRs because the game's interrupt handler can modify any register.
        for (int i = 0; i < 32; i++)
            saved_ctx.regs[i] = cpu.get_reg(i);
        saved_ctx.hi = cpu.hi;
        saved_ctx.lo = cpu.lo;
        saved_ctx.valid = true;
        if (g_diaglog) { fprintf(g_diaglog, "[EXC] Saved ctx: ra=0x%08X sp=0x%08X v0=0x%08X v1=0x%08X a0=0x%08X a1=0x%08X epc=0x%08X instr #%llu\n",
               saved_ctx.regs[31], saved_ctx.regs[29], saved_ctx.regs[2], saved_ctx.regs[3],
               saved_ctx.regs[4], saved_ctx.regs[5], cpu.cp0_epc,
               (unsigned long long)cpu.instructions); fflush(g_diaglog); }

        // Read handler register block from RAM (12 uint32s: ra,sp,fp,s0-s7,gp)
        uint32_t bo = ram_offset(hook_entry_int_addr);
        auto read_blk = [&](int idx) -> uint32_t {
            uint32_t o = bo + idx * 4;
            return ram[o] | (ram[o+1]<<8) | (ram[o+2]<<16) | (ram[o+3]<<24);
        };
        uint32_t handler_ra = read_blk(0);
        if (handler_ra == 0) {
            // Handler register block not yet initialized by game.
            // Fall through to HLE path instead of jumping to NULL.
            saved_ctx.valid = false;
        } else {
        cpu.set_reg(31, handler_ra);   // ra = handler entry point
        cpu.set_reg(29, read_blk(1));   // sp = handler stack
        cpu.set_reg(30, read_blk(2));   // fp
        for (int i = 0; i < 8; i++)
            cpu.set_reg(16 + i, read_blk(3 + i));  // s0-s7
        cpu.set_reg(28, read_blk(11));  // gp
        cpu.set_reg(2, 1);              // v0 = 1 (indicates interrupt)

        // Validate handler_ra is in valid executable range
        if ((handler_ra & 3) != 0 || (handler_ra < 0x80000000 || handler_ra >= 0x80200000)) {
            if (g_diaglog) { fprintf(g_diaglog, "[EXC] Bad handler_ra=0x%08X at instr #%llu (epc=0x%08X) — using HLE path instead\n",
                   handler_ra, (unsigned long long)cpu.instructions, cpu.cp0_epc); fflush(g_diaglog); }
            saved_ctx.valid = false;
            // Fall through to HLE path
        } else {
            printf("[EXC] HookEntryInt -> handler_ra=0x%08X at instr #%llu (epc=0x%08X ip=0x%02X)\n",
                   handler_ra, (unsigned long long)cpu.instructions, cpu.cp0_epc, ip_bits);
            // Jump to handler ra — game's interrupt handler
            cpu.pc = handler_ra;
            cpu.in_branch_delay = false;
            cpu.pending_branch = false;
            // DON'T do RFE — game will call ReturnFromException (B:0x17)
            return true;
        }
        } // end else (handler_ra != 0)
    }

    // No HookEntryInt — HLE path: events already delivered above, just return

    // RFE: pop interrupt stack IEc=IEp, IEp=IEo
    uint32_t s = cpu.cp0_status;
    uint32_t old = s & 0x3F;
    uint32_t new_low6 = (old & ~0x0F) | ((old >> 2) & 0x0F);
    cpu.cp0_status = (s & ~0x3F) | new_low6;

    cpu.pc = cpu.cp0_epc;
    cpu.in_branch_delay = false;
    cpu.pending_branch = false;
    return true;
}

// ── Approach 2: MIPS Fallback Exception Handler ────────────────────────────
// Installs real MIPS code at 0x80000080 that acknowledges VBlank and returns.
// This is used as a fallback when the C++ intercept is disabled or when
// the game's own exception handler needs to run.
// The C++ intercept checks if 0x80000080 is zero — if so, it handles in C++.
// If this MIPS handler is installed (non-zero), it will execute instead.
void PSX_Memory::install_mips_exception_handler() {
    // MIPS exception handler at 0x80000080:
    //
    // This handler:
    // 1. Reads I_STAT to check if VBlank is pending
    // 2. If VBlank: clears I_STAT bit 0, sets event flag at 0x800B679C
    // 3. Reads EPC from CP0 register 14
    // 4. Jumps to EPC (return from exception)
    // 5. RFE in delay slot to restore interrupt state
    //
    // Register usage:
    //   $t0 = 0x1F800000 (hw register base)
    //   $t1 = I_STAT value
    //   $t2 = VBlank bit test
    //   $t3 = 0x800B0000 (event flag base)
    //   $t4 = 1 (constant for clearing/setting)
    //   $k0 = scratch for sw instruction
    //   $k1 = EPC value

    auto write_mips = [this](uint32_t addr, uint32_t instr) {
        uint32_t off = ram_offset(addr);
        ram[off]     = instr & 0xFF;
        ram[off + 1] = (instr >> 8) & 0xFF;
        ram[off + 2] = (instr >> 16) & 0xFF;
        ram[off + 3] = (instr >> 24) & 0xFF;
    };

    // Instruction 0: lui  $t0, 0x1F80       ; $t0 = 0x1F800000
    write_mips(0x80000080, 0x3C081F80);

    // Instruction 1: lw   $t1, 0x1070($t0)  ; $t1 = I_STAT
    write_mips(0x80000084, 0x8D091070);

    // Instruction 2: andi $t2, $t1, 0x01    ; $t2 = VBlank bit
    write_mips(0x80000088, 0x312A0001);

    // Instruction 3: beq  $t2, $zero, +6    ; if not VBlank, skip to instr 10 (0x8000009C)
    //   beq offset: target = (PC + 4) + (offset << 2)
    //   We want target = 0x8000009C, PC+4 = 0x8000008C
    //   offset = (0x8000009C - 0x8000008C) >> 2 = 0x10 >> 2 = 4
    write_mips(0x8000008C, 0x11400004);

    // Instruction 4: nop                     ; delay slot
    write_mips(0x80000090, 0x00000000);

    // --- VBlank handling ---
    // Instruction 5: addiu $t4, $zero, 1    ; $t4 = 1
    write_mips(0x80000094, 0x240C0001);

    // Instruction 6: sw   $t4, 0x1070($t0)  ; Write 1 to I_STAT to ack VBlank
    write_mips(0x80000098, 0xAD0C1070);

    // --- Common return path (instr 10+) ---
    // Instruction 10: mfc0 $k0, $14         ; $k0 = EPC
    //   mfc0 rt, rd:  opcode=0x40, rs=0x00 (MFC0), rt=$k0(26), rd=14, rest=0
    //   Encoding: 0x40000000 | (0x00 << 21) | (26 << 16) | (14 << 11)
    //   = 0x40000000 | 0x00000000 | 0x01A00000 | 0x00007000
    //   = 0x401A7000
    write_mips(0x8000009C, 0x401A7000);

    // Instruction 11: jr   $k0              ; jump to EPC
    //   jr rs: opcode=0x00, rs=$k0(26), funct=0x08
    //   = (26 << 21) | 0x08 = 0x03400008
    write_mips(0x800000A0, 0x03400008);

    // Instruction 12: rfe                    ; restore from exception (delay slot)
    //   rfe: opcode=0x42, funct=0x10
    //   = 0x42000010
    write_mips(0x800000A4, 0x42000010);

    // NOP padding
    for (uint32_t addr = 0x800000A8; addr < 0x800000C0; addr += 4) {
        write_mips(addr, 0x00000000);
    }
}

bool PSX_Memory::handle_bios_call(uint32_t call_pc, MIPS_CPU& cpu) {
    uint32_t fn = cpu.get_reg(9) & 0xFF;  // $t1 = function number
    uint32_t a0 = cpu.get_reg(4);
    uint32_t a1 = cpu.get_reg(5);
    uint32_t a2 = cpu.get_reg(6);
    uint32_t a3 = cpu.get_reg(7);
    uint32_t ra = cpu.get_reg(31);

    // BIOS call logging — uses bios_syscalls lookup from psx_reference_integrations.h
    // (sourced from PSn00bSDK stubs.json — authoritative A/B/C table mapping)
    {
        char table = (call_pc == 0xA0) ? 'A' : (call_pc == 0xB0) ? 'B' : 'C';
        const char* desc;
        switch (call_pc) {
        case 0xA0: desc = bios_syscalls::A_name((uint8_t)fn); break;
        case 0xB0: desc = bios_syscalls::B_name((uint8_t)fn); break;
        case 0xC0: desc = bios_syscalls::C_name((uint8_t)fn); break;
        default:   desc = "unknown"; break;
        }

        // For file paths, read the string
        if ((table == 'A' && fn == 0x00) || (table == 'B' && fn == 0x32) ||
            (table == 'B' && fn == 0x7B)) {
            char path[256];
            for (int i = 0; i < 255; i++) {
                path[i] = (char)read8(a0 + i);
                if (path[i] == 0) break;
            }
            path[255] = 0;
            printf("[SYSCALL] %c:0x%02X %s(\"%s\", 0x%X) instr #%llu ra=0x%08X\n",
                   table, fn, desc, path, a1, cpu.instructions, ra);
        } else {
            printf("[SYSCALL] %c:0x%02X %s(0x%X, 0x%X, 0x%X, 0x%X) instr #%llu ra=0x%08X\n",
                   table, fn, desc, a0, a1, a2, a3, cpu.instructions, ra);
        }
        // Log syscalls to diag file after 5M instructions to capture stuck loop
        if (g_diaglog && cpu.instructions > 5000000 && cpu.instructions < 7000000) {
            fprintf(g_diaglog, "[SCALL] %c:0x%02X %s(0x%X,0x%X,0x%X,0x%X) instr #%llu ra=0x%08X\n",
                    table, fn, desc, a0, a1, a2, a3, (unsigned long long)cpu.instructions, ra);
            fflush(g_diaglog);
        }
    }

    // Table A (0xA0) — stdio, string, file operations, GPU
    if (call_pc == 0xA0) {
        switch (fn) {
        case 0x00: { // open(path, mode) — A table
            // Read path string from RAM
            char path[256];
            for (int i = 0; i < 255; i++) {
                path[i] = (char)read8(a0 + i);
                if (path[i] == 0) break;
            }
            path[255] = 0;
            // Check for memory card paths
            if (strncmp(path, "bu00", 4) == 0 || strncmp(path, "bu10", 4) == 0) {
                if (!memcard_initialized) memcard_init();
                int fd = -1;
                for (int i = 0; i < 4; i++) {
                    if (!memcard_fds[i].in_use) { fd = i; break; }
                }
                if (fd >= 0) {
                    memcard_fds[fd].in_use = true;
                    memcard_fds[fd].block = 1;
                    memcard_fds[fd].num_blocks = 1;
                    memcard_fds[fd].offset = 0;
                    strncpy(memcard_fds[fd].name, path, 31);
                    memcard_fds[fd].name[31] = 0;
                    strncpy(memcard_last_filename, path, 31);
                    memcard_last_filename[31] = 0;
                    memcard_fd_count++;
                    printf("[MEMCARD] B-open: %s -> fd=%d\n", path, fd);
                    cpu.set_reg(2, fd);
                } else {
                    cpu.set_reg(2, -1);
                }
                return true;
            }
            // CD-ROM file
            uint32_t file_lba, file_size;
            if (find_cd_file(path, file_lba, file_size) >= 0) {
                int fd = alloc_fdesc();
                if (fd >= 0) {
                    strncpy(fdescs[fd].name, path, 31);
                    fdescs[fd].mode = a1;
                    fdescs[fd].offset = 0;
                    fdescs[fd].size = file_size;
                    fdescs[fd].lba = file_lba;
                    cpu.set_reg(2, fd);
                } else {
                    cpu.set_reg(2, -1);
                }
            } else {
                cpu.set_reg(2, -1);
            }
            return true;
        }
        case 0x01: { // lseek(fd, offset, whence) — A table
            if (a0 >= 0 && a0 < (uint32_t)MAX_FDESCS && fdescs[a0].in_use) {
                switch (a2) {
                    case 0: // SEEK_SET
                        fdescs[a0].offset = a1;
                        break;
                    case 1: // SEEK_CUR
                        fdescs[a0].offset += a1;
                        break;
                    case 2: // SEEK_END
                        fdescs[a0].offset = fdescs[a0].size + a1;
                        break;
                }
                cpu.set_reg(2, fdescs[a0].offset);
            } else {
                cpu.set_reg(2, -1);
            }
            return true;
        }
        case 0x02: { // read(fd, buf, nbytes) — A table
            int bytes = cd_read(a0, a1, a2);
            cpu.set_reg(2, bytes < 0 ? -1 : bytes);
            return true;
        }
        case 0x03: { // write(fd, buf, nbytes) — A table
            if (a0 == 1 || a0 == 2) { // stdout/stderr
                cpu.set_reg(2, a2);
            } else {
                cpu.set_reg(2, a2);
            }
            return true;
        }
        case 0x04: { // close(fd) — A table
            if (a0 >= 0 && a0 < (uint32_t)MAX_FDESCS) {
                fdescs[a0].in_use = false;
            }
            return true;
        }
        case 0x05:  // ioctl
            return true;
        case 0x06:  // exit
            cpu.crashed = true;
            snprintf(cpu.crash_reason, 255, "BIOS A:0x06 exit() at instr #%llu", cpu.instructions);
            return false;
        case 0x07:  // isdigit
            cpu.set_reg(2, (a0 >= '0' && a0 <= '9') ? 1 : 0);
            return true;
        case 0x08:  // isalpha
            cpu.set_reg(2, ((a0 >= 'A' && a0 <= 'Z') || (a0 >= 'a' && a0 <= 'z')) ? 1 : 0);
            return true;
        case 0x09:  // malloc
            cpu.set_reg(2, 0x80100000);
            return true;
        case 0x0A:  // free
            return true;
        case 0x0B: { // strchr(s, c)
            if (a0) {
                uint32_t addr = a0;
                while (true) {
                    uint8_t ch = read8(addr);
                    if (ch == (a1 & 0xFF)) { cpu.set_reg(2, addr); return true; }
                    if (ch == 0) break;
                    addr++;
                }
            }
            cpu.set_reg(2, 0);
            return true;
        }
        case 0x0C: { // strrchr(s, c)
            if (a0) {
                uint32_t addr = a0, found = 0;
                while (true) {
                    uint8_t ch = read8(addr);
                    if (ch == (a1 & 0xFF)) found = addr;
                    if (ch == 0) break;
                    addr++;
                }
                cpu.set_reg(2, found);
            } else {
                cpu.set_reg(2, 0);
            }
            return true;
        }
        case 0x0D: { // strcpy(dst, src) — standard PSX position
            if (a0 && a1) {
                uint32_t s = a1, d = a0;
                while (true) {
                    uint8_t c = read8(s++);
                    write8(d++, c);
                    if (c == 0) break;
                }
            }
            cpu.set_reg(2, a0);
            return true;
        }
        case 0x0E:  // abs
            cpu.set_reg(2, (a0 & 0x80000000) ? (~a0 + 1) : a0);
            return true;
        case 0x10: { // atoi(s) — parse integer from string
            if (a0) {
                uint32_t addr = a0;
                int sign = 1, result = 0;
                uint8_t c = read8(addr);
                while (c == ' ' || c == '\t') { addr++; c = read8(addr); }
                if (c == '-') { sign = -1; addr++; c = read8(addr); }
                else if (c == '+') { addr++; c = read8(addr); }
                while (c >= '0' && c <= '9') {
                    result = result * 10 + (c - '0');
                    addr++; c = read8(addr);
                }
                cpu.set_reg(2, (uint32_t)(result * sign));
            } else {
                cpu.set_reg(2, 0);
            }
            return true;
        }
        case 0x0F: { // strcat(dst, src)
            if (a0 && a1) {
                uint32_t d = a0;
                while (read8(d) != 0) d++;
                uint32_t s = a1;
                while (true) {
                    uint8_t c = read8(s++);
                    write8(d++, c);
                    if (c == 0) break;
                }
            }
            cpu.set_reg(2, a0);
            return true;
        }
        case 0x11: { // memcmp(s1, s2, n) — standard position
            if (a0 && a1) {
                for (uint32_t i = 0; i < a2; i++) {
                    uint8_t b1 = read8(a0 + i), b2 = read8(a1 + i);
                    if (b1 != b2) { cpu.set_reg(2, (int)b1 - (int)b2); return true; }
                }
            }
            cpu.set_reg(2, 0);
            return true;
        }
        case 0x13: { // memcpy(dst, src, n) — standard position
            if (a0 && a1) {
                for (uint32_t i = 0; i < a2; i++)
                    write8(a0 + i, read8(a1 + i));
            }
            cpu.set_reg(2, a0);
            return true;
        }
        case 0x14: { // memset(dst, c, n) — standard position
            if (a0) {
                for (uint32_t i = 0; i < a2; i++)
                    write8(a0 + i, (uint8_t)(a1 & 0xFF));
            }
            cpu.set_reg(2, a0);
            return true;
        }
        case 0x15:  // tolower
            cpu.set_reg(2, (a0 >= 'A' && a0 <= 'Z') ? a0 + 32 : a0);
            return true;
        case 0x16:  // toupper
            cpu.set_reg(2, (a0 >= 'a' && a0 <= 'z') ? a0 - 32 : a0);
            return true;
        case 0x18: { // strstr(s, substr)
            if (a0 && a1) {
                uint32_t s = a0;
                while (read8(s) != 0) {
                    uint32_t p = s, q = a1;
                    while (read8(q) != 0 && read8(p) == read8(q)) { p++; q++; }
                    if (read8(q) == 0) { cpu.set_reg(2, s); return true; }
                    s++;
                }
            }
            cpu.set_reg(2, 0);
            return true;
        }
        case 0x19:  // strcpy
            if (a0 && a1) {
                uint32_t s = a1, d = a0;
                while (true) {
                    uint8_t c = read8(s++);
                    write8(d++, c);
                    if (c == 0) break;
                }
            }
            cpu.set_reg(2, a0);
            return true;
        case 0x1C:  // strlen
            if (a0) {
                uint32_t len = 0;
                while (read8(a0 + len) != 0) len++;
                cpu.set_reg(2, len);
            } else {
                cpu.set_reg(2, 0);
            }
            return true;
        case 0x1E:  // calloc(n, size)
            cpu.set_reg(2, 0x80100000);
            return true;
        case 0x1F:  // realloc(ptr, size)
            cpu.set_reg(2, a0 ? a0 : 0x80100000);
            return true;
        case 0x20: { // strcmp(s1, s2)
            if (a0 && a1) {
                uint32_t p = a0, q = a1;
                while (true) {
                    uint8_t c1 = read8(p), c2 = read8(q);
                    if (c1 != c2) { cpu.set_reg(2, (int)c1 - (int)c2); return true; }
                    if (c1 == 0) break;
                    p++; q++;
                }
            }
            cpu.set_reg(2, 0);
            return true;
        }
        case 0x21: { // strncmp(s1, s2, n)
            if (a0 && a1) {
                for (uint32_t i = 0; i < a2; i++) {
                    uint8_t c1 = read8(a0 + i), c2 = read8(a1 + i);
                    if (c1 != c2) { cpu.set_reg(2, (int)c1 - (int)c2); return true; }
                    if (c1 == 0) break;
                }
            }
            cpu.set_reg(2, 0);
            return true;
        }
        case 0x22: { // strncpy(dst, src, n)
            if (a0 && a1) {
                for (uint32_t i = 0; i < a2; i++) {
                    uint8_t c = read8(a1 + i);
                    write8(a0 + i, c);
                    if (c == 0) { for (uint32_t j = i + 1; j < a2; j++) write8(a0 + j, 0); break; }
                }
            }
            cpu.set_reg(2, a0);
            return true;
        }
        case 0x23: { // strncat(dst, src, n)
            if (a0 && a1) {
                uint32_t d = a0;
                while (read8(d) != 0) d++;
                for (uint32_t i = 0; i < a2; i++) {
                    uint8_t c = read8(a1 + i);
                    if (c == 0) break;
                    write8(d++, c);
                }
                write8(d, 0);
            }
            cpu.set_reg(2, a0);
            return true;
        }
        case 0x29: { // rand()
            static uint32_t rng_state = 0x12345678;
            rng_state = rng_state * 1103515245 + 12345;
            cpu.set_reg(2, (rng_state >> 16) & 0x7FFF);
            return true;
        }
        case 0x2A:  // memcpy
            if (a0 && a1) {
                for (uint32_t i = 0; i < a2; i++)
                    write8(a0 + i, read8(a1 + i));
            }
            cpu.set_reg(2, a0);
            return true;
        case 0x2B:  // memset
            if (a0) {
                for (uint32_t i = 0; i < a2; i++)
                    write8(a0 + i, (uint8_t)(a1 & 0xFF));
            }
            cpu.set_reg(2, a0);
            return true;
        case 0x2E:  // memcmp
            cpu.set_reg(2, 0);
            return true;
        case 0x30: { // srand(seed)
            // Set RNG seed (simplified)
            return true;
        }
        case 0x31:  // qsort
            return true;
        case 0x32: { // rand (alt position)
            static uint32_t rng_state2 = 0xDEADBEEF;
            rng_state2 = rng_state2 * 1103515245 + 12345;
            cpu.set_reg(2, (rng_state2 >> 16) & 0x7FFF);
            return true;
        }
        case 0x33:  // malloc (alt)
            cpu.set_reg(2, 0x80100000);
            return true;
        case 0x34:  // free (alt)
            return true;
        case 0x39:  // InitHeap
            return true;
        case 0x3C: { // printf(fmt, ...) — format and print to TTY
            if (a0) {
                char fmt[256];
                for (int i = 0; i < 255; i++) {
                    fmt[i] = (char)read8(a0 + i);
                    if (fmt[i] == 0) break;
                }
                fmt[255] = 0;
                // Simple printf: just print the format string (args ignored for simplicity)
                // Real games mostly use printf for debug, so this is sufficient
                printf("[GAME_PRINTF] %s\n", fmt);
            }
            cpu.set_reg(2, 0);
            return true;
        }
        case 0x3F: { // Sprintf(dst, fmt, ...) — format string to buffer
            if (a0 && a1) {
                // Read format string
                char fmt[256];
                for (int i = 0; i < 255; i++) {
                    fmt[i] = (char)read8(a1 + i);
                    if (fmt[i] == 0) break;
                }
                fmt[255] = 0;
                // Simple: copy format string to dest (no arg substitution yet)
                // TODO: handle %d, %s, %x, %c with args from stack
                uint32_t arg_ptr = a1 + strlen(fmt) + 1;
                uint32_t dst = a0;
                for (int i = 0; fmt[i]; i++) {
                    if (fmt[i] == '%' && fmt[i+1]) {
                        char spec = fmt[i+1];
                        if (spec == 's') {
                            uint32_t str_addr = read32(arg_ptr); arg_ptr += 4;
                            if (str_addr) {
                                uint32_t sa = str_addr;
                                while (true) {
                                    uint8_t c = read8(sa++);
                                    if (c == 0) break;
                                    write8(dst++, c);
                                }
                            }
                            i++; // skip spec char
                        } else if (spec == 'd') {
                            int32_t val = (int32_t)read32(arg_ptr); arg_ptr += 4;
                            char num[16];
                            snprintf(num, 16, "%d", val);
                            for (int j = 0; num[j]; j++) write8(dst++, num[j]);
                            i++;
                        } else if (spec == 'x' || spec == 'X') {
                            uint32_t val = read32(arg_ptr); arg_ptr += 4;
                            char num[16];
                            snprintf(num, 16, spec == 'x' ? "%x" : "%X", val);
                            for (int j = 0; num[j]; j++) write8(dst++, num[j]);
                            i++;
                        } else if (spec == 'c') {
                            uint8_t val = read8(arg_ptr); arg_ptr += 4;
                            write8(dst++, val);
                            i++;
                        } else if (spec == '%') {
                            write8(dst++, '%');
                            i++;
                        } else {
                            write8(dst++, fmt[i]);
                        }
                    } else {
                        write8(dst++, fmt[i]);
                    }
                }
                write8(dst, 0);
                cpu.set_reg(2, dst - a0); // Return length written
            } else {
                cpu.set_reg(2, 0);
            }
            return true;
        }
        case 0x44:  // FlushCache
            return true;
        case 0x45:  // InstallInterruptHandler
            return true;
        case 0x46:  // GPU_dw
            return true;
        case 0x47:  // mem2vram
            return true;
        case 0x48:  // SendGPUStatus
            return true;
        case 0x49: { // GPU_cw(cmd) — send GPU command word via GP0
            gpu_gp0(a0);
            // Set display flag at 0x800B5312 when GPU is initialized
            if (gpu_display_enabled) {
                uint32_t off = ram_offset(0x800B5312);
                ram[off] = 0x01;
                ram[off+1] = 0x00;
            }
            return true;
        }
        case 0x4A:  // GPU_cwb
            return true;
        case 0x4B:  // SendPackets
            return true;
        case 0x4D: { // GetGPUStatus(gpu_cmd)
            cpu.set_reg(2, compute_gpustat());
            return true;
        }
        case 0x4E:  // GPU_sync
            return true;
        case 0x52:  // GetSysSp
            cpu.set_reg(2, 0x801FFFF0);
            return true;
        case 0x55:  // _96_init
            return true;
        case 0x56:  // _bu_init
            return true;
        case 0x57:  // _96_remove
            return true;
        // A:0x60-0x6F: CD-ROM BIOS functions (PCSX-Reloaded mapping)
        case 0x60: { // CdInit — same as B:0x5B
            intc_mask |= 0x04;
            cpu.cp0_status |= 0x400;
            cdrom_int_enable = 0x1F;
            if (!events_initialized) init_events();
            int handle = compute_handle(0xF2000002, 0x02);
            if (handle >= 0 && handle < EV_TABLE_SIZE) {
                events[handle].status = EvStACTIVE;
                events[handle].mode = 0x1000;
                events[handle].fhandler = 0;
                events[handle].ev_class = 0xF2000002;
                events[handle].ev_spec = 0x02;
                events[handle].used = true;
                cdrom_event_id = handle;
            }
            cpu.set_reg(2, 1);
            if (g_verbose) printf("[BIOS] A:0x60 CdInit at instr #%llu\n", g_cpu ? g_cpu->instructions : 0);
            return true;
        }
        case 0x61: { // CdReadSector — read N sectors starting at current LBA
            // a0 = sector count, a1 = dest buffer addr, a2 = mode addr
            uint32_t sectors = a0;
            uint32_t dest = a1;
            // Set up DMA-like transfer: read sectors from current LBA to RAM
            for (uint32_t s = 0; s < sectors; s++) {
                uint8_t sector_buf[2048];
                if (read_cd_sector(cdrom_cur_lba + s, sector_buf)) {
                    uint32_t ram_pos = dest + s * 2048;
                    for (int w = 0; w < 512 && ram_pos + 3 < RAM_SIZE; w++) {
                        uint32_t word = sector_buf[w*4] | (sector_buf[w*4+1] << 8) |
                                        (sector_buf[w*4+2] << 16) | (sector_buf[w*4+3] << 24);
                        ram[ram_offset(ram_pos)] = word & 0xFF;
                        ram[ram_offset(ram_pos+1)] = (word >> 8) & 0xFF;
                        ram[ram_offset(ram_pos+2)] = (word >> 16) & 0xFF;
                        ram[ram_offset(ram_pos+3)] = (word >> 24) & 0xFF;
                        ram_pos += 4;
                    }
                }
            }
            cdrom_cur_lba += sectors;
            cpu.set_reg(2, sectors);
            if (g_verbose) printf("[BIOS] A:0x61 CdReadSector: %u sectors at LBA=%u -> 0x%08X\n",
                   sectors, cdrom_cur_lba - sectors, dest);
            return true;
        }
        case 0x62:  // CdGetStatus — return current CD-ROM status
            cpu.set_reg(2, cdrom_status);
            return true;
        case 0x63:  // CdSend — send raw CD command
            // a0 = command byte, a1 = param buffer, a2 = param count
            cpu.set_reg(2, 1);
            return true;
        case 0x64:  // CdSync — same as B:0x5E
            {
                int handle = cdrom_event_id;
                if (handle >= 0 && handle < EV_TABLE_SIZE && events[handle].used) {
                    if (events[handle].status == EvStALREADY) {
                        events[handle].status = EvStACTIVE;
                        cpu.set_reg(2, 1);
                    } else {
                        cpu.set_reg(2, 0);
                    }
                } else {
                    cpu.set_reg(2, 0);
                }
                return true;
            }
        case 0x65:  // CdReady — check if data sector is ready
            cpu.set_reg(2, cdrom_data_ready ? 1 : 0);
            return true;
        case 0x66:  // CdSeekL — seek to LBA
            cdrom_cur_lba = a0;
            cpu.set_reg(2, 1);
            if (g_verbose) printf("[BIOS] A:0x66 CdSeekL LBA=%u\n", a0);
            return true;
        case 0x67:  // CdSeekP — seek to MSF
            {
                uint8_t m = (a0 >> 16) & 0xFF;
                uint8_t s = (a0 >> 8) & 0xFF;
                uint8_t f = a0 & 0xFF;
                uint8_t dm = (m >> 4) * 10 + (m & 0xF);
                uint8_t ds = (s >> 4) * 10 + (s & 0xF);
                uint8_t df = (f >> 4) * 10 + (f & 0xF);
                cdrom_cur_lba = (uint32_t)(dm * 60 + ds) * 75 + df - 150;
                cpu.set_reg(2, 1);
                if (g_verbose) printf("[BIOS] A:0x67 CdSeekP MSF=%02X%02X%02X LBA=%u\n", m, s, f, cdrom_cur_lba);
                return true;
            }
        case 0x68:  // CdRead — start reading at current LBA (async)
            // a0 = sector count, a1 = dest buffer, a2 = mode
            cdrom_reading = true;
            cdrom_read_pending = false;
            cdrom_read_mode = 0;
            cdrom_sectors_read = 0;
            cdrom_read_start_lba = cdrom_cur_lba;
            cdrom_read_sectors_requested = a0;
            cdrom_read_dest = a1;
            cdrom_pause_requested = false;
            cdrom_data_ready = false;
            // Synchronous delivery: read sectors immediately into dest buffer
            // This is needed because the thread blob calls CdReadSync immediately
            // after CdRead with no step() calls in between for cdrom_tick to fire.
            for (uint32_t s = 0; s < a0; s++) {
                uint8_t sector_buf[2048];
                if (read_cd_sector(cdrom_cur_lba + s, sector_buf)) {
                    for (uint32_t b = 0; b < 2048; b++) {
                        write8(a1 + s * 2048 + b, sector_buf[b]);
                    }
                    cdrom_sectors_read++;
                }
            }
            cdrom_cur_lba += a0;
            cdrom_reading = false;
            cpu.set_reg(2, 1);
            if (g_verbose) printf("[BIOS] A:0x68 CdRead: %u sectors at LBA=%u -> 0x%08X (sync)\n",
                   a0, cdrom_read_start_lba, a1);
            return true;
        case 0x69:  // CdReadSync — wait for CdRead completion
            {
                // Return done based on sector count directly — event status may not
                // transition if blob thread doesn't have CP0 interrupts enabled.
                if (cdrom_read_sectors_requested > 0 &&
                    cdrom_sectors_read >= (int)cdrom_read_sectors_requested) {
                    cpu.set_reg(2, 1); // Done
                    int handle = cdrom_event_id;
                    if (handle >= 0 && handle < EV_TABLE_SIZE && events[handle].used) {
                        events[handle].status = EvStALREADY;
                    }
                } else if (!cdrom_reading) {
                    cpu.set_reg(2, 1); // Not reading = done
                } else {
                    cpu.set_reg(2, 0); // Still reading
                }
                return true;
            }
        case 0x6A:  // CdReadFile — read file by name into buffer (sync)
            {
                // a0 = filename, a1 = dest buffer, a2 = max bytes
                char path[256];
                for (int i = 0; i < 255; i++) {
                    path[i] = (char)read8(a0 + i);
                    if (path[i] == 0) break;
                }
                path[255] = 0;
                uint32_t file_lba, file_size;
                if (find_cd_file(path, file_lba, file_size) >= 0) {
                    uint32_t bytes_to_read = a2;
                    if (bytes_to_read > file_size) bytes_to_read = file_size;
                    uint32_t sectors = (bytes_to_read + 2047) / 2048;
                    for (uint32_t s = 0; s < sectors; s++) {
                        uint8_t sector_buf[2048];
                        if (read_cd_sector(file_lba + s, sector_buf)) {
                            uint32_t copy_bytes = 2048;
                            if (s * 2048 + copy_bytes > bytes_to_read)
                                copy_bytes = bytes_to_read - s * 2048;
                            for (uint32_t b = 0; b < copy_bytes; b++) {
                                write8(a1 + s * 2048 + b, sector_buf[b]);
                            }
                        }
                    }
                    cpu.set_reg(2, bytes_to_read);
                    if (g_verbose) printf("[BIOS] A:0x6A CdReadFile: '%s' %u bytes -> 0x%08X\n",
                           path, bytes_to_read, a1);
                } else {
                    cpu.set_reg(2, 0); // File not found
                    if (g_verbose) printf("[BIOS] A:0x6A CdReadFile: '%s' NOT FOUND\n", path);
                }
                return true;
            }
        case 0x6B:  // CdReadFile2 — variant
            {
                // Same as 0x6A but with different parameter order
                char path[256];
                for (int i = 0; i < 255; i++) {
                    path[i] = (char)read8(a0 + i);
                    if (path[i] == 0) break;
                }
                path[255] = 0;
                uint32_t file_lba, file_size;
                if (find_cd_file(path, file_lba, file_size) >= 0) {
                    uint32_t bytes_to_read = a2;
                    if (bytes_to_read > file_size) bytes_to_read = file_size;
                    uint32_t sectors = (bytes_to_read + 2047) / 2048;
                    for (uint32_t s = 0; s < sectors; s++) {
                        uint8_t sector_buf[2048];
                        if (read_cd_sector(file_lba + s, sector_buf)) {
                            uint32_t copy_bytes = 2048;
                            if (s * 2048 + copy_bytes > bytes_to_read)
                                copy_bytes = bytes_to_read - s * 2048;
                            for (uint32_t b = 0; b < copy_bytes; b++) {
                                write8(a1 + s * 2048 + b, sector_buf[b]);
                            }
                        }
                    }
                    cpu.set_reg(2, bytes_to_read);
                } else {
                    cpu.set_reg(2, 0);
                }
                return true;
            }
        case 0x6C:  // CdGetStatusL — return status with position
            cpu.set_reg(2, cdrom_status);
            return true;
        case 0x6D:  // CdGetStatusM — return motor status
            cpu.set_reg(2, 0x02); // Motor on, reading
            return true;
        case 0x6E:  // CdGetSector — read data sector to buffer
            if (cdrom_data_ready) {
                uint32_t ram_pos = a0;
                for (int w = 0; w < 512 && ram_pos + 3 < RAM_SIZE; w++) {
                    uint32_t word = cdrom_data_sector[w*4] | (cdrom_data_sector[w*4+1] << 8) |
                                    (cdrom_data_sector[w*4+2] << 16) | (cdrom_data_sector[w*4+3] << 24);
                    ram[ram_offset(ram_pos)] = word & 0xFF;
                    ram[ram_offset(ram_pos+1)] = (word >> 8) & 0xFF;
                    ram[ram_offset(ram_pos+2)] = (word >> 16) & 0xFF;
                    ram[ram_offset(ram_pos+3)] = (word >> 24) & 0xFF;
                    ram_pos += 4;
                }
                cdrom_data_ready = false;
                cpu.set_reg(2, 1);
            } else {
                cpu.set_reg(2, 0);
            }
            return true;
        case 0x6F:  // CdGetSectorS — read sector with size
            if (cdrom_data_ready) {
                uint32_t ram_pos = a0;
                uint32_t copy = a1 < 2048 ? a1 : 2048;
                for (uint32_t b = 0; b < copy; b++) {
                    write8(ram_pos + b, cdrom_data_sector[b]);
                }
                cdrom_data_ready = false;
                cpu.set_reg(2, copy);
            } else {
                cpu.set_reg(2, 0);
            }
            return true;
        default:
            cpu.set_reg(2, 0);
            return true;
        }
    }

    // Table B (0xB0) — events, threads, file I/O, PAD
    // Correct mapping from PCSX-Reloaded psxbios.c
    if (call_pc == 0xB0) {
        switch (fn) {
        case 0x00:  // SysMalloc
            cpu.set_reg(2, 0x80100000);
            return true;
        // 0x02-0x06: timer functions (SetRCnt, GetRCnt, StartRCnt, StopRCnt, ResetRCnt)
        // Confirmed in PCSX-Reloaded: biosB0[0x02]=SetRCnt, [0x03]=GetRCnt, etc.
        case 0x02: { // SetRCnt(counter, mode, target)
            int t = a0 & 3;
            timer_mode[t] = a1 & 0xFFFF;
            timer_target[t] = a2 & 0xFFFF;
            if (t < 3) {
                rcnt_active[t] = false;
                timer_count[t] = 0;
            }
            return true;
        }
        case 0x03: { // GetRCnt(counter)
            int t = a0 & 3;
            if (t == 3) {
                cpu.set_reg(2, vblank_counter & 0xFFFF);
            } else {
                cpu.set_reg(2, timer_count[t]);
            }
            return true;
        }
        case 0x04: { // StartRCnt(counter)
            int t = a0 & 3;
            rcnt_active[t] = true;
            if (t < 3) {
                intc_mask |= (1 << (t + 4));
            }
            cpu.set_reg(2, 1);
            return true;
        }
        case 0x05: { // StopRCnt(counter)
            int t = a0 & 3;
            rcnt_active[t] = false;
            if (t < 3) intc_mask &= ~(1 << (t + 4));
            return true;
        }
        case 0x06: { // ResetRCnt(counter)
            int t = a0 & 3;
            timer_count[t] = 0;
            return true;
        }
        // 0x07-0x0D: Event system (THE KEY FUNCTIONS)
        case 0x07: { // DeliverEvent(ev_class, spec)
            // Called by game code to manually deliver events
            if (g_diaglog) { fprintf(g_diaglog, "[EVT] DeliverEvent class=0x%08X spec=0x%08X instr #%llu\n",
                     a0, a1, (unsigned long long)(g_cpu ? g_cpu->instructions : 0)); fflush(g_diaglog); }
            deliver_event(a0, a1);
            return true;
        }
        case 0x08: { // OpenEvent(class, spec, mode, handler)
            if (!events_initialized) init_events();
            int handle = compute_handle(a0, a1);
            if (handle >= 0 && handle < EV_TABLE_SIZE) {
                events[handle].status = EvStWAIT;
                events[handle].mode = a2;
                events[handle].fhandler = a3;
                events[handle].ev_class = a0;
                events[handle].ev_spec = a1;
                events[handle].used = true;
                cpu.set_reg(2, handle);
                if (g_diaglog) { fprintf(g_diaglog, "[EVT] OpenEvent class=0x%08X spec=0x%08X mode=0x%08X handler=0x%08X handle=%d instr #%llu\n",
                         a0, a1, a2, a3, handle, (unsigned long long)(g_cpu ? g_cpu->instructions : 0)); fflush(g_diaglog); }
                if (a0 == 0xF2000002) {
                    cdrom_event_id = handle;
                }
            } else {
                cpu.set_reg(2, 0xFFFFFFFF);
                if (g_diaglog) { fprintf(g_diaglog, "[EVT] OpenEvent FAILED class=0x%08X spec=0x%08X handle=-1 instr #%llu\n",
                         a0, a1, (unsigned long long)(g_cpu ? g_cpu->instructions : 0)); fflush(g_diaglog); }
            }
            return true;
        }
        case 0x09: { // CloseEvent(event_id)
            int handle = a0 & 0xFFFF;
            if (handle >= 0 && handle < EV_TABLE_SIZE) {
                events[handle].status = EvStUNUSED;
                events[handle].used = false;
            }
            cpu.set_reg(2, 1);
            return true;
        }
        case 0x0A: { // WaitEvent(event_id)
            // PSX WaitEvent blocks until event is delivered.
            // Since we don't have threads, return 1 if already delivered (ALREADY),
            // return 0 if not yet delivered. The game will poll in a loop until
            // the interrupt handler delivers the event and sets ALREADY.
            int handle = a0 & 0xFFFF;
            if (handle >= 0 && handle < EV_TABLE_SIZE && events[handle].used) {
                // Debug: log WaitEvent status for CD-ROM events
                if (handle == 0x509 || handle == 0x102) {
                    printf("[WAITDBG] WaitEvent(0x%04X) status=%d used=%d instr #%llu\n",
                           handle, events[handle].status, events[handle].used,
                           g_cpu ? g_cpu->instructions : 0);
                }
                // Trace event wait
                g_cdrom_tracer.log_event(handle, events[handle].ev_class,
                                         events[handle].ev_spec, events[handle].status,
                                         "wait");
                if (!g_cdrom_tracer.events.empty())
                    g_cdrom_tracer.events.back().instruction_count = g_cpu->instructions;
                if (events[handle].status == EvStALREADY) {
                    // Event was delivered by interrupt handler — consume it
                    events[handle].status = EvStACTIVE;  // Reset for next delivery
                    cpu.set_reg(2, 1);  // Ready
                } else {
                    cpu.set_reg(2, 0);  // Not ready yet — game will retry
                }
            } else {
                cpu.set_reg(2, 0);
            }
            return true;
        }
        case 0x0B: { // TestEvent(event_id)
            int handle = a0 & 0xFFFF;
            int result = 0;
            if (handle >= 0 && handle < EV_TABLE_SIZE && events[handle].used) {
                if (events[handle].status == EvStALREADY) {
                    events[handle].status = EvStACTIVE;
                    result = 1;  // Event ready!
                } else {
                    result = 0;  // Not ready
                }
            } else {
                result = 0;
            }
            // Log TestEvent calls after 20M instructions (when game is in polling loop)
            if (g_diaglog && g_cpu && g_cpu->instructions > 20000000) {
                const char* stname = "?";
                if (handle >= 0 && handle < EV_TABLE_SIZE && events[handle].used) {
                    switch (events[handle].status) {
                        case EvStUNUSED: stname = "UNUSED"; break;
                        case EvStWAIT: stname = "WAIT"; break;
                        case EvStACTIVE: stname = "ACTIVE"; break;
                        case EvStALREADY: stname = "ALREADY"; break;
                    }
                    fprintf(g_diaglog, "[EVT] TestEvent handle=%d class=0x%08X spec=0x%08X status=%s => %d instr #%llu\n",
                            handle, events[handle].ev_class, events[handle].ev_spec, stname, result,
                            (unsigned long long)g_cpu->instructions);
                } else {
                    fprintf(g_diaglog, "[EVT] TestEvent handle=%d (invalid/unused) => 0 instr #%llu\n",
                            handle, (unsigned long long)g_cpu->instructions);
                }
                fflush(g_diaglog);
            }
            // Trace event test
            if (handle >= 0 && handle < EV_TABLE_SIZE && events[handle].used) {
                g_cdrom_tracer.log_event(handle, events[handle].ev_class,
                                         events[handle].ev_spec, events[handle].status,
                                         "test", result);
                if (!g_cdrom_tracer.events.empty())
                    g_cdrom_tracer.events.back().instruction_count = g_cpu->instructions;
            }
            cpu.set_reg(2, result);
            return true;
        }
        case 0x0C: { // EnableEvent(event_id)
            int handle = a0 & 0xFFFF;
            if (handle >= 0 && handle < EV_TABLE_SIZE && events[handle].used) {
                events[handle].status = EvStACTIVE;
                if (g_diaglog) { fprintf(g_diaglog, "[EVT] EnableEvent handle=%d class=0x%08X spec=0x%08X instr #%llu\n",
                         handle, events[handle].ev_class, events[handle].ev_spec,
                         (unsigned long long)(g_cpu ? g_cpu->instructions : 0)); fflush(g_diaglog); }
                // Trace event enable
                g_cdrom_tracer.log_event(handle, events[handle].ev_class,
                                         events[handle].ev_spec, events[handle].status,
                                         "enable");
                if (!g_cdrom_tracer.events.empty())
                    g_cdrom_tracer.events.back().instruction_count = g_cpu->instructions;
                // If this is the CD-ROM event, deliver it now — the CD-ROM init
                // INT2 fired before the event was opened, so the handler was never
                // called. Delivering it here kicks the game's CD-ROM state machine.
                if (events[handle].ev_class == 0xF2000002 &&
                    events[handle].ev_spec == 0x02 &&
                    events[handle].fhandler != 0) {
                    // Set CD-ROM interrupt flag to INT2 (Complete) so the handler
                    // sees a pending interrupt and advances the state machine
                    cdrom_int_flag = 2;  // INT2 = Complete
                    if (cdrom_int_enable & cdrom_int_flag) {
                        intc_stat |= 0x04;
                    }
                    if (g_verbose) printf("[BIOS] EnableEvent: delivering pending CD-ROM INT2 event to handler 0x%08X instr #%llu\n",
                           events[handle].fhandler, g_cpu ? g_cpu->instructions : 0);
                    deliver_event(0xF2000002, 0x02);
                }
                // CD-ROM ready event (0xF0000009): CD_init fired INT3 before
                // the event was opened. Deliver it now so WaitEvent sees ALREADY.
                if (events[handle].ev_class == 0xF0000009 &&
                    events[handle].ev_spec == 0x20) {
                    if (g_verbose) printf("[BIOS] EnableEvent: delivering CD-ROM ready event (0xF0000009) instr #%llu\n",
                           g_cpu ? g_cpu->instructions : 0);
                    deliver_event(0xF0000009, 0x20);
                }
            }
            cpu.set_reg(2, 1);
            return true;
        }
        case 0x0D: { // DisableEvent(event_id)
            int handle = a0 & 0xFFFF;
            if (handle >= 0 && handle < EV_TABLE_SIZE && events[handle].used) {
                events[handle].status = EvStWAIT;
            }
            cpu.set_reg(2, 1);
            return true;
        }
        case 0x0E: { // OpenTh(regbuf, entry, sp, gp)
            // a0 = register buffer address, a1 = entry point, a2 = stack ptr, a3 = gp
            // PUPPETEER FINAL GRAFT: Protect GP zone from being clobbered by thread SP
            if (a2 >= 0x800C0000 && a2 <= 0x800C0600) {
                printf("[PUPPETEER] CRITICAL: OpenTh sp=0x%08X clobbers GP zone. Redirecting to 0x801F0000\n", a2);
                a2 = 0x801F0000;
            }
            // PUPPETEER FINAL GRAFT: Fix invalid GP — use current CPU $gp if a3 is garbage
            if (a3 < 0x80000000 || a3 >= 0x80200000) {
                uint32_t cur_gp = cpu.get_reg(28);
                printf("[PUPPETEER] CRITICAL: OpenTh gp=0x%08X is invalid. Using current $gp=0x%08X\n", a3, cur_gp);
                a3 = cur_gp;
            }
            // PUPPETEER: Log if entry point is in HBD data zone (may be zero-filled)
            if (a1 >= 0x800D0000 && a1 < 0x800F0000) {
                printf("[PUPPETEER] WARNING: OpenTh entry=0x%08X is in HBD data zone\n", a1);
            }
            int tid = -1;
            // Reserve tid=0 for the main thread — PSX BIOS implicitly has
            // the main thread as tid=0. Start assigning from tid=1.
            // Ensure main thread is registered as active with current context.
            if (!threads[0].active) {
                threads[0].active = true;
                threads[0].pc = cpu.pc;
                threads[0].ra = cpu.pc;
                threads[0].sp = cpu.get_reg(29);
                threads[0].fp = cpu.get_reg(30);
                threads[0].gp = cpu.get_reg(28);
                memset(threads[0].s, 0, sizeof(threads[0].s));
                if (current_thread < 0) current_thread = 0;
            }
            for (int i = 1; i < MAX_THREADS; i++) {
                if (!threads[i].active) { tid = i; break; }
            }
            if (tid >= 0) {
                threads[tid].pc = a1;
                threads[tid].sp = a2;
                threads[tid].gp = a3;
                threads[tid].ra = a1; // return to entry point
                threads[tid].fp = a2;
                memset(threads[tid].s, 0, sizeof(threads[tid].s));
                threads[tid].active = true;
                fprintf(stderr, "[BIOS] OpenTh: tid=%d entry=0x%08X sp=0x%08X gp=0x%08X instr #%llu\n",
                       tid, a1, a2, a3, g_cpu ? g_cpu->instructions : 0);
            }
            cpu.set_reg(2, tid);
            return true;
        }
        case 0x0F:  // CloseTh
            cpu.set_reg(2, 1);
            return true;
        case 0x10: { // ChangeTh(thread_id) — save current, switch to new
            int new_tid = (int)a0;
            // If blob already completed and game wants to switch to blob thread,
            // deliver CD-ROM events but still allow the thread switch to proceed.
            // The bubblegum stub will re-execute (set flags + ChangeTh(0)) as a
            // harmless round-trip, letting the game's main loop progress.
            if (g_blob_completed && new_tid != 0 &&
                new_tid >= 0 && new_tid < MAX_THREADS && threads[new_tid].active &&
                threads[new_tid].pc == THREAD_ENTRY_ADDR) {
                if (g_verbose) printf("[BIOS] ChangeTh(%d): blob completed — delivering events, allowing switch (instr #%llu)\n",
                       new_tid, g_cpu ? g_cpu->instructions : 0);
                deliver_event(0xF2000002, 0x02);
                deliver_event(0xF0000009, 0x20);
                // Fall through to normal thread switch below
            }
            // Detect blob completion: blob calls ChangeTh(0) when done with all 499 entries
            if (new_tid == 0 && current_thread != 0 &&
                current_thread >= 0 && current_thread < MAX_THREADS &&
                threads[current_thread].pc == THREAD_ENTRY_ADDR) {
                g_blob_completed = true;
                if (g_verbose) printf("[BIOS] ChangeTh(0): blob thread completed — setting g_blob_completed, delivering CD-ROM events (instr #%llu)\n",
                       g_cpu ? g_cpu->instructions : 0);
                // Deliver CD-ROM completion events
                deliver_event(0xF2000002, 0x02);
                deliver_event(0xF0000009, 0x20);
                // Set loading complete flag so game's main loop (0x80096700) sees data is loaded
                write32(0x800D5190, 1);
                if (g_verbose) printf("[BIOS] Set 0x800D5190=1 (loading complete flag)\n");
                // Stub zero-filled game functions at 0x80118E08 and 0x80118F20
                // These are in BSS (beyond EXE range, not covered by pointer table).
                // 0x80118E08: loading check — return 0 (complete) to skip VBC1 wait
                // MIPS: jr $ra; move $v0, $zero  =  0x03E00008  0x00001021
                if (read32(0x80118E08) == 0) {
                    write32(0x80118E08, 0x03E00008);  // jr $ra
                    write32(0x80118E0C, 0x00001021);  // move $v0, $zero (addu $v0,$zero,$zero)
                    if (g_verbose) printf("[BIOS] Stubbed 0x80118E08 (loading check) -> return 0\n");
                }
                // 0x80118F20: post-load processing — just return
                if (read32(0x80118F20) == 0) {
                    write32(0x80118F20, 0x03E00008);  // jr $ra
                    write32(0x80118F24, 0x00001021);  // move $v0, $zero
                    if (g_verbose) printf("[BIOS] Stubbed 0x80118F20 (post-load) -> return 0\n");
                }
            }
            // Direct RAM Injection: if switching to a thread whose entry is at
            // 0x800D9E80 and that region is zero-filled, inject the thread code
            // blob extracted from the HBD scan. This bypasses the broken CD-ROM
            // thread-loading pipeline.
            if (!g_thread_injected &&
                new_tid >= 0 && new_tid < MAX_THREADS && threads[new_tid].active &&
                threads[new_tid].pc == THREAD_ENTRY_ADDR) {
                uint32_t off = ram_offset(THREAD_ENTRY_ADDR);
                bool is_zero = true;
                for (int i = 0; i < 16; i++) {
                    if (ram[off + i] != 0) { is_zero = false; break; }
                }
                if (is_zero) {
                    g_thread_injected = true;
                    if (g_thread_blob_loaded && g_thread_blob_size > 0) {
                        // Inject real blob into RAM
                        memcpy(&ram[off], g_thread_blob, g_thread_blob_size);
                        fprintf(stderr, "[INJECT] Injected %d bytes at 0x%08X before ChangeTh (instr #%llu)\n",
                               g_thread_blob_size, THREAD_ENTRY_ADDR,
                               g_cpu ? g_cpu->instructions : 0);

                        // Verify injected code is valid MIPS
                        bool blob_valid = g_orch.enabled
                            ? g_orch.verify_injected_code(*this, THREAD_ENTRY_ADDR, g_thread_blob_size)
                            : true;
                        if (!blob_valid) {
                            fprintf(stderr, "[INJECT] Blob invalid — writing bubblegum stub\n");
                            g_orch.write_bubblegum_stub(*this, THREAD_ENTRY_ADDR);
                        }
                    } else {
                        // No blob available — write bubblegum stub directly.
                        // The stub sets CD-ready flags and calls ChangeTh(0) via BIOS B-table.
                        fprintf(stderr, "[INJECT] No blob (size=%d loaded=%d) — writing bubblegum stub at 0x%08X (instr #%llu)\n",
                               g_thread_blob_size, (int)g_thread_blob_loaded,
                               THREAD_ENTRY_ADDR, g_cpu ? g_cpu->instructions : 0);
                        // Write stub inline (don't depend on orch)
                        static const uint32_t stub[] = {
                            0x3C08800B,  // lui   $t0, 0x800B
                            0x340991CC,  // ori   $t1, $zero, 0x91CC
                            0x01094020,  // addu  $t0, $t0, $t1       -> t0 = 0x800B91CC
                            0x24090001,  // addiu $t1, $zero, 1
                            0xA1020000,  // sb    $t1, 0($t0)         -> *0x800B91CC = 1
                            0xA1020002,  // sb    $t1, 2($t0)         -> *0x800B91CE = 1
                            0x24090002,  // addiu $t1, $zero, 2
                            0xA109FF98,  // sb    $t1, -0x68($t0)     -> *0x800B9164 = 2
                            0x24040000,  // addiu $a0, $zero, 0       -> a0 = 0
                            0x24090010,  // addiu $t1, $zero, 0x10    -> t1 = ChangeTh
                            0x240A00B0,  // addiu $t2, $zero, 0xB0    -> t2 = BIOS B-table
                            0x01400008,  // jr    $t2                 -> jump to 0xB0
                            0x00000000,  // nop                       -> delay slot
                        };
                        for (int i = 0; i < 13; i++)
                            write32(THREAD_ENTRY_ADDR + i * 4, stub[i]);
                    }

                    if (g_cdlog && g_cdlog_count < 20000) {
                        fprintf(g_cdlog, "[INJECT] Thread code injected at 0x%08X instr #%llu\n",
                                THREAD_ENTRY_ADDR,
                                g_cpu ? (unsigned long long)g_cpu->instructions : 0);
                        g_cdlog_count++;
                    }
                }
            }
            // Save current thread context
            if (current_thread >= 0 && current_thread < MAX_THREADS) {
                threads[current_thread].ra = cpu.get_reg(31);
                threads[current_thread].sp = cpu.get_reg(29);
                threads[current_thread].fp = cpu.get_reg(30);
                threads[current_thread].gp = cpu.get_reg(28);
                for (int i = 0; i < 8; i++)
                    threads[current_thread].s[i] = cpu.get_reg(16 + i);
            }
            // If blob already completed and game tries to switch back to blob thread,
            // don't switch — the blob's post-loop code is an infinite yield loop.
            // Just return success and keep running the current thread.
            if (g_blob_completed && new_tid != 0 &&
                new_tid >= 0 && new_tid < MAX_THREADS &&
                threads[new_tid].pc == THREAD_ENTRY_ADDR) {
                if (g_verbose) printf("[BIOS] ChangeTh(%d): blob completed — ignoring switch, staying on tid=%d (instr #%llu)\n",
                       new_tid, current_thread, g_cpu ? g_cpu->instructions : 0);
                cpu.set_reg(2, 1);
                return true;
            }
            // Switch to new thread
            if (new_tid >= 0 && new_tid < MAX_THREADS && threads[new_tid].active) {
                cpu.set_reg(31, threads[new_tid].ra);
                cpu.set_reg(29, threads[new_tid].sp);
                cpu.set_reg(30, threads[new_tid].fp);
                cpu.set_reg(28, threads[new_tid].gp);
                for (int i = 0; i < 8; i++)
                    cpu.set_reg(16 + i, threads[new_tid].s[i]);
                // If thread is the CD-ROM loader blob, restart from entry on first run
                if (threads[new_tid].pc == THREAD_ENTRY_ADDR && !g_blob_completed) {
                    cpu.pc = THREAD_ENTRY_ADDR;
                    // Reset saved registers so blob starts fresh
                    threads[new_tid].ra = THREAD_ENTRY_ADDR;
                    for (int i = 0; i < 8; i++)
                        threads[new_tid].s[i] = 0;
                } else if (threads[new_tid].ra != threads[new_tid].pc) {
                    cpu.pc = threads[new_tid].ra;
                } else {
                    cpu.pc = threads[new_tid].pc;
                }
                cpu.in_branch_delay = false;
                cpu.pending_branch = false;
                current_thread = new_tid;
                fprintf(stderr, "[BIOS] ChangeTh: switched to tid=%d PC=0x%08X SP=0x%08X ra=0x%08X t.pc=0x%08X t.ra=0x%08X blob_done=%d instr #%llu\n",
                       new_tid, cpu.pc, threads[new_tid].sp, threads[new_tid].ra,
                       threads[new_tid].pc, threads[new_tid].ra,
                       (int)g_blob_completed,
                       g_cpu ? g_cpu->instructions : 0);
                if (new_tid == 0 && g_blob_completed) {
                    fprintf(stderr, "[BIOS] ChangeTh: main thread resumed at PC=0x%08X after blob completion (instr #%llu)\n",
                           cpu.pc, g_cpu ? g_cpu->instructions : 0);
                    // Dump a few instructions at the main thread's PC
                    for (int i = -2; i < 6; i++) {
                        uint32_t a = cpu.pc + i * 4;
                        uint32_t v = read32(a);
                        fprintf(stderr, "[BIOS]   0x%08X: 0x%08X\n", a, v);
                    }
                }
                if (new_tid != 0 && threads[new_tid].pc == THREAD_ENTRY_ADDR) {
                    uint32_t stub0 = read32(THREAD_ENTRY_ADDR);
                    uint32_t stub12 = read32(THREAD_ENTRY_ADDR + 0x30);
                    fprintf(stderr, "[BIOS] ChangeTh: stub check [0]=0x%08X [0x30]=0x%08X (expect 0x3C08800B / 0x01400008)\n",
                           stub0, stub12);
                }
                cpu.bios_set_pc = true;  // Don't let step() override PC with $ra
            }
            cpu.set_reg(2, 1);
            return true;
        }
        case 0x12: { // InitPAD(buf1, len1, buf2, len2) — Phase 5
            pad_buf1_addr = a0;
            pad_buf1_len = a1;
            pad_buf2_addr = a2;
            pad_buf2_len = a3;
            cpu.set_reg(2, 1);
            return true;
        }
        case 0x13: { // StartPAD — Phase 5
            pad_started = true;
            intc_mask |= 0x01;
            cpu.cp0_status |= 0x401;
            return true;
        }
        case 0x14: { // StopPAD — Phase 5
            pad_started = false;
            pad_buf1_addr = 0;
            pad_buf2_addr = 0;
            return true;
        }
        case 0x15: { // PAD_init(type, buf) — Phase 5
            intc_mask |= 0x01;
            pad_buf_addr = a1;
            if (pad_buf_addr) {
                uint32_t off = ram_offset(pad_buf_addr);
                ram[off] = 0xFF; ram[off+1] = 0xFF; ram[off+2] = 0xFF; ram[off+3] = 0xFF;
            }
            cpu.cp0_status |= 0x401;
            return true;
        }
        case 0x16: { // PAD_dr — Phase 5
            cpu.set_reg(2, -1);
            return true;
        }
        case 0x17:  // ReturnFromException
            // Clear CD-ROM interrupt flag — the game's HookEntryInt should have
            // processed it. If it didn't acknowledge via 0x1F801803, clear it here
            // so INT2 and subsequent interrupts can fire.
            cdrom_int_flag = 0;
            cdrom_irq_code = 0;
            // Restore CP0 status (pop interrupt stack: IEo->IEc, IEp->IEo)
            {
                uint32_t s = cpu.cp0_status;
                uint32_t old = s & 0x3F;
                uint32_t new_low6 = (old & ~0x0F) | ((old >> 2) & 0x0F);
                cpu.cp0_status = (s & ~0x3F) | new_low6;
                printf("[RFE] status 0x%08X -> 0x%08X (IEc=%d EXL=%d IM0=%d) PC->0x%08X\n",
                       s, cpu.cp0_status,
                       (cpu.cp0_status & 0x01) ? 1:0,
                       (cpu.cp0_status & 0x04) ? 1:0,
                       (cpu.cp0_status & 0x100) ? 1:0,
                       cpu.cp0_epc);
            }
            // Restore saved register context from HookEntryInt dispatch
            if (saved_ctx.valid) {
                if (g_diaglog) { fprintf(g_diaglog, "[RFE] Restoring saved_ctx: ra=0x%08X sp=0x%08X v0=0x%08X v1=0x%08X a0=0x%08X a1=0x%08X epc=0x%08X instr #%llu\n",
                       saved_ctx.regs[31], saved_ctx.regs[29], saved_ctx.regs[2], saved_ctx.regs[3],
                       saved_ctx.regs[4], saved_ctx.regs[5], cpu.cp0_epc,
                       (unsigned long long)cpu.instructions); fflush(g_diaglog); }
                if (saved_ctx.regs[31] < 0x80000000 || saved_ctx.regs[31] >= 0x80200000) {
                    if (g_diaglog) { fprintf(g_diaglog, "[RFE] *** SUSPICIOUS ra=0x%08X — would cause danger zone entry! Aborting restore.\n",
                           saved_ctx.regs[31]); fflush(g_diaglog); }
                    saved_ctx.valid = false;
                    // Don't restore — just return to EPC with current regs
                } else {
                // Restore ALL GPRs — real BIOS restores all from exception frame.
                for (int i = 1; i < 32; i++)
                    cpu.set_reg(i, saved_ctx.regs[i]);
                cpu.hi = saved_ctx.hi;
                cpu.lo = saved_ctx.lo;
                saved_ctx.valid = false;
                // Clear the event queue ready flag (0x800B679C). The game's
                // interrupt handler sets this to signal events are queued,
                // but the main loop's copy path at 0x80098848 reads the BIOS
                // event table from RAM, which our HLE BIOS doesn't maintain.
                // Clearing it forces the main loop to fall through to TestEvent
                // polling, which works correctly with our C++ event array.
                ram[ram_offset(0x800B679C)] = 0;
                }
            }
            // Return to EPC
            cpu.pc = cpu.cp0_epc;
            cpu.in_branch_delay = false;
            cpu.pending_branch = false;
            cpu.bios_set_pc = true;  // Signal step() not to override PC
            // Re-check for pending interrupts after returning
            if (g_mem && (g_mem->intc_stat & g_mem->intc_mask)) {
                cpu.interrupt_pending = true;
            }
            return true;
        case 0x18:  // ResetEntryInt — clear HookEntryInt
            hook_entry_int_set = false;
            hook_entry_int_addr = 0;
            return true;
        case 0x19: { // HookEntryInt(addr) — store game's interrupt entry point
            hook_entry_int_addr = a0;
            hook_entry_int_set = true;
            return true;
        }
        case 0x20: { // UnDeliverEvent(ev_class, spec)
            int handle = compute_handle(a0, a1);
            if (handle >= 0 && handle < EV_TABLE_SIZE && events[handle].used) {
                if (events[handle].status == EvStALREADY &&
                    events[handle].mode == EvMdNOINTR) {
                    events[handle].status = EvStACTIVE;
                }
            }
            return true;
        }
        // 0x32-0x38: file I/O (B table variant) — Phase 4
        case 0x32: { // open(path, mode) — B table
            char path[256];
            for (int i = 0; i < 255; i++) {
                path[i] = (char)read8(a0 + i);
                if (path[i] == 0) break;
            }
            path[255] = 0;
            if (strncmp(path, "bu00", 4) == 0 || strncmp(path, "bu10", 4) == 0) {
                if (!memcard_initialized) memcard_init();
                int fd = -1;
                for (int i = 0; i < 4; i++) {
                    if (!memcard_fds[i].in_use) { fd = i; break; }
                }
                if (fd >= 0) {
                    memcard_fds[fd].in_use = true;
                    memcard_fds[fd].block = 1;
                    memcard_fds[fd].num_blocks = 1;
                    memcard_fds[fd].offset = 0;
                    strncpy(memcard_fds[fd].name, path, 31);
                    memcard_fds[fd].name[31] = 0;
                    strncpy(memcard_last_filename, path, 31);
                    memcard_last_filename[31] = 0;
                    memcard_fd_count++;
                    printf("[MEMCARD] B-open2: %s -> fd=%d\n", path, fd);
                    cpu.set_reg(2, fd);
                } else {
                    cpu.set_reg(2, -1);
                }
                return true;
            }
            uint32_t file_lba, file_size;
            if (find_cd_file(path, file_lba, file_size) >= 0) {
                int fd = alloc_fdesc();
                if (fd >= 0) {
                    strncpy(fdescs[fd].name, path, 31);
                    fdescs[fd].mode = a1;
                    fdescs[fd].offset = 0;
                    fdescs[fd].size = file_size;
                    fdescs[fd].lba = file_lba;
                    cpu.set_reg(2, fd);
                } else {
                    cpu.set_reg(2, -1);
                }
            } else {
                cpu.set_reg(2, -1);
            }
            return true;
        }
        case 0x33: { // lseek(fd, offset, whence) — B table
            if (a0 >= 0 && a0 < (uint32_t)MAX_FDESCS && fdescs[a0].in_use) {
                switch (a2) {
                    case 0: fdescs[a0].offset = a1; break;
                    case 1: fdescs[a0].offset += a1; break;
                    case 2: fdescs[a0].offset = fdescs[a0].size + a1; break;
                }
                cpu.set_reg(2, fdescs[a0].offset);
            } else {
                cpu.set_reg(2, -1);
            }
            return true;
        }
        case 0x34: { // read(fd, buf, nbytes) — B table
            int bytes = cd_read(a0, a1, a2);
            cpu.set_reg(2, bytes < 0 ? -1 : bytes);
            return true;
        }
        case 0x35: { // write(fd, buf, nbytes) — B table
            if (a0 == 1 || a0 == 2) { // stdout/stderr
                // Print the actual string content
                if (a2 > 0 && a2 < 256) {
                    char buf[256];
                    for (int i = 0; i < (int)a2 && i < 255; i++) {
                        uint8_t c = read8(a1 + i);
                        buf[i] = (c >= 0x20 && c < 0x7F) ? (char)c : '.';
                    }
                    buf[a2 < 255 ? a2 : 255] = 0;
                    printf("[STDOUT] %s\n", buf);
                }
                cpu.set_reg(2, a2);
            } else {
                cpu.set_reg(2, a2);
            }
            return true;
        }
        case 0x36: { // close(fd) — B table
            if (a0 >= 0 && a0 < (uint32_t)MAX_FDESCS) {
                fdescs[a0].in_use = false;
            }
            return true;
        }
        case 0x37:  // ioctl
            return true;
        case 0x38:  // exit
            cpu.crashed = true;
            snprintf(cpu.crash_reason, 255, "BIOS exit() called at instr #%llu", cpu.instructions);
            return false;
        case 0x3C:  // puts
            cpu.set_reg(2, 0);
            return true;
        case 0x3E:  // printf
            cpu.set_reg(2, 0);
            return true;
        case 0x42:  // cd(path) — change directory
            return true;
        case 0x44: { // firstfile(pattern, dir_entry) — B:0x44
            // Write first directory entry to the DIRENTRY struct in RAM
            // DIRENTRY: name[20], attr[4], size[4], next[4], head[4], system[4]
            if (!dir_cached) parse_iso_directory();
            if (dir_entry_count > 0) {
                DirEntry& de = dir_entries[0];
                uint32_t d = a1;
                // Write name
                for (int i = 0; i < 20; i++) {
                    write8(d + i, i < (int)strlen(de.name) ? de.name[i] : 0);
                }
                write32(d + 20, de.is_dir ? 0x10 : 0x00);  // attr
                write32(d + 24, de.size);                   // size
                write32(d + 28, dir_entry_count > 1 ? 1 : 0); // next
                write32(d + 32, de.lba);                    // head (LBA)
                cpu.set_reg(2, a1);
            } else {
                cpu.set_reg(2, 0);
            }
            return true;
        }
        case 0x45: { // nextfile(dir_entry) — B:0x45
            // Read 'next' index from the dir_entry struct
            uint32_t next_idx = read32(a0 + 28);
            if (next_idx > 0 && next_idx < (uint32_t)dir_entry_count) {
                DirEntry& de = dir_entries[next_idx];
                uint32_t d = a0;
                for (int i = 0; i < 20; i++) {
                    write8(d + i, i < (int)strlen(de.name) ? de.name[i] : 0);
                }
                write32(d + 20, de.is_dir ? 0x10 : 0x00);
                write32(d + 24, de.size);
                write32(d + 28, next_idx + 1 < (uint32_t)dir_entry_count ? next_idx + 1 : 0);
                write32(d + 32, de.lba);
                cpu.set_reg(2, a0);
            } else {
                cpu.set_reg(2, 0);
            }
            return true;
        }
        case 0x48:  // InitCARD
            if (!memcard_initialized) memcard_init();
            return true;
        case 0x49:  // StartCARD
            return true;
        case 0x4A:  // StopCARD
            return true;
        case 0x4B: { // _card_info(port) — get memory card info
            if (!memcard_initialized) memcard_init();
            cpu.set_reg(2, 1); // Card present
            return true;
        }
        case 0x4C: { // _card_load(port) — load memory card
            if (!memcard_initialized) memcard_init();
            cpu.set_reg(2, 1); // Success
            return true;
        }
        case 0x4D: { // _card_auto(port, func) — auto card detection
            if (!memcard_initialized) memcard_init();
            cpu.set_reg(2, 1);
            return true;
        }
        case 0x4E: { // bu00/bu10 open — memory card file open (B table)
            char path[256];
            for (int i = 0; i < 255; i++) {
                path[i] = (char)read8(a0 + i);
                if (path[i] == 0) break;
            }
            path[255] = 0;
            if (!memcard_initialized) memcard_init();
            // Find or allocate a file descriptor
            int fd = -1;
            for (int i = 0; i < 4; i++) {
                if (!memcard_fds[i].in_use) { fd = i; break; }
            }
            if (fd >= 0) {
                memcard_fds[fd].in_use = true;
                memcard_fds[fd].block = 1; // Start at block 1 (block 0 = directory)
                memcard_fds[fd].num_blocks = 1;
                memcard_fds[fd].offset = 0;
                strncpy(memcard_fds[fd].name, path, 31);
                memcard_fds[fd].name[31] = 0;
                strncpy(memcard_last_filename, path, 31);
                memcard_last_filename[31] = 0;
                memcard_fd_count++;
                printf("[MEMCARD] Open file: %s -> fd=%d\n", path, fd);
                cpu.set_reg(2, fd);
            } else {
                cpu.set_reg(2, -1);
            }
            return true;
        }
        case 0x4F: { // _card_read(fd, buf) — read 128-byte frame from memory card
            int fd = (int)a0;
            uint32_t buf = a1;
            if (fd < 0 || fd >= 4 || !memcard_fds[fd].in_use) {
                cpu.set_reg(2, -1);
                return true;
            }
            // Read one 128-byte frame from the card data
            int card_offset = memcard_fds[fd].block * 8192 + memcard_fds[fd].offset;
            if (card_offset + 128 > (int)MEMCARD_SIZE) {
                cpu.set_reg(2, -1);
                return true;
            }
            for (int i = 0; i < 128; i++) {
                write8(buf + i, memcard_data[card_offset + i]);
            }
            memcard_fds[fd].offset += 128;
            memcard_read_count++;
            cpu.set_reg(2, 128); // Return bytes read
            return true;
        }
        case 0x50: { // _card_write(fd, buf, nbytes) — write to memory card
            int fd = (int)a0;
            uint32_t buf = a1;
            int nbytes = (int)a2;
            if (fd < 0 || fd >= 4 || !memcard_fds[fd].in_use) {
                cpu.set_reg(2, -1);
                return true;
            }
            // Write data from RAM buffer to memory card
            int card_offset = memcard_fds[fd].block * 8192 + memcard_fds[fd].offset;
            if (card_offset + nbytes > (int)MEMCARD_SIZE) {
                cpu.set_reg(2, -1);
                return true;
            }
            for (int i = 0; i < nbytes; i++) {
                memcard_data[card_offset + i] = read8(buf + i);
            }
            memcard_fds[fd].offset += nbytes;
            memcard_dirty = true;
            memcard_write_count++;
            memcard_last_write_addr = buf;
            memcard_last_write_size = nbytes;
            printf("[MEMCARD] Write fd=%d buf=0x%08X nbytes=%d card_off=0x%04X\n",
                   fd, buf, nbytes, card_offset);
            cpu.set_reg(2, nbytes); // Return bytes written
            return true;
        }
        case 0x51: { // _card_create(port, name, size) — create file on memory card
            char name[32];
            for (int i = 0; i < 31; i++) {
                name[i] = (char)read8(a1 + i);
                if (name[i] == 0) break;
            }
            name[31] = 0;
            if (!memcard_initialized) memcard_init();
            // Find a free file descriptor
            int fd = -1;
            for (int i = 0; i < 4; i++) {
                if (!memcard_fds[i].in_use) { fd = i; break; }
            }
            if (fd >= 0) {
                memcard_fds[fd].in_use = true;
                memcard_fds[fd].block = 1; // Allocate at block 1 for now
                memcard_fds[fd].num_blocks = 1;
                memcard_fds[fd].offset = 0;
                strncpy(memcard_fds[fd].name, name, 31);
                memcard_fds[fd].name[31] = 0;
                strncpy(memcard_last_filename, name, 31);
                memcard_last_filename[31] = 0;
                memcard_create_count++;
                memcard_fd_count++;
                printf("[MEMCARD] Create file: %s (port=%d) -> fd=%d\n", name, (int)a0, fd);
                cpu.set_reg(2, fd);
            } else {
                cpu.set_reg(2, -1);
            }
            return true;
        }
        case 0x52: { // _card_delete(port, name) — delete file on memory card
            cpu.set_reg(2, 1); // Success
            return true;
        }
        case 0x53: { // _card_get_status(port) — get card status
            cpu.set_reg(2, 0); // No errors
            return true;
        }
        case 0x54: { // _card_set_status(port, status) — set card status
            cpu.set_reg(2, 1);
            return true;
        }
        case 0x56:  // GetC0Table
            cpu.set_reg(2, 0x674);
            return true;
        case 0x57:  // GetB0Table
            cpu.set_reg(2, 0x874);
            return true;
        case 0x5A: { // ChangeClearPAD — Phase 5
            // Controls whether PAD interrupt auto-clears
            return true;
        }
        case 0x5B:  // CD_init (CdInit) — initialize CD-ROM subsystem
            intc_mask |= 0x04;  // Enable CD-ROM IRQ (bit 2) in I_MASK
            cpu.cp0_status |= 0x400;  // Enable IM2 (CD-ROM) in CP0 Status
            // Enable CD-ROM hardware interrupts — interrupt enable register is
            // at 0x1F801803 index=0. The game reads this to check if CD-ROM
            // IRQs are enabled. Real PSX BIOS CdInit writes 0x1F to enable all
            // CD-ROM interrupt types (INT1-INT5).
            cdrom_int_enable = 0x1F;
            // Open and enable CD-ROM event (like real PSX BIOS CdInit does)
            if (!events_initialized) init_events();
            {
                int handle = compute_handle(0xF2000002, 0x02);
                if (handle >= 0 && handle < EV_TABLE_SIZE) {
                    events[handle].status = EvStACTIVE;
                    events[handle].mode = 0x1000;  // EvMdINTR
                    events[handle].fhandler = 0;
                    events[handle].ev_class = 0xF2000002;
                    events[handle].ev_spec = 0x02;
                    events[handle].used = true;
                    cdrom_event_id = handle;
                    printf("[BIOS] CD_init: opened CD-ROM event handle=%d\n", handle);
                }
            }
            // Reset CD-ROM ready event (0xF0000009) to ACTIVE so INT3 delivery
            // can set it to ALREADY. On second CD_init call, the event may still
            // be ALREADY from the first delivery, which blocks deliver_event.
            {
                int ready_handle = compute_handle(0xF0000009, 0x20);
                if (ready_handle >= 0 && ready_handle < EV_TABLE_SIZE &&
                    events[ready_handle].used) {
                    events[ready_handle].status = EvStACTIVE;
                }
            }
            // Fire CD-ROM INT3 (first response) then INT2 (complete) to match
            // real PSX CD-ROM Init command sequence.
            // INT3: command received → exception handler delivers events, calls HookEntryInt
            // INT2: init complete with response data (stat + region) → HookEntryInt sets CD ready flag
            // Push stat byte as response for INT3 so game can read it from response FIFO
            cdrom_response_pos = 0;
            cdrom_response_count = 0;
            memset(cdrom_response_fifo, 0, sizeof(cdrom_response_fifo));
            cdrom_push_response(cdrom_stat_byte());
            cdrom_set_interrupt(3);
            // Schedule INT2 with Init response: region byte 0x00 (Japan)
            // Delay = FIRST_RESPONSE_CYCLES + INT2_GAP (approx 4M cycles for Init complete)
            {
                uint8_t init_resp[] = { 0x00 };  // Region: Japan
                cdrom_schedule_int2(160000, init_resp, 1);
            }
            printf("[BIOS] CD_init: scheduled CD-ROM INT3 + INT2 (init complete)\n");
            cpu.set_reg(2, 1);
            return true;
        case 0x5C:  // _card_wait
            cpu.set_reg(2, 1);
            return true;
        case 0x5E: { // CD_sync — check if CD-ROM command completed
            // Check CD-ROM event status (like TestEvent)
            int handle = cdrom_event_id;
            if (handle >= 0 && handle < EV_TABLE_SIZE && events[handle].used) {
                if (events[handle].status == EvStALREADY) {
                    events[handle].status = EvStACTIVE;  // Reset for next command
                    cpu.set_reg(2, 1);  // Ready / command done
                } else {
                    cpu.set_reg(2, 0);  // NoIntr / still waiting
                }
            } else {
                cpu.set_reg(2, 0);
            }
            return true;
        }
        default:
            cpu.set_reg(2, 0);
            return true;
        }
    }

    // Table C (0xC0) — kernel, interrupts, memory
    // Correct mapping from PCSX-Reloaded psxbios.c
    if (call_pc == 0xC0) {
        switch (fn) {
        case 0x00: { // InitRCnt — initialize root counter system
            for (int t = 0; t < 4; t++) {
                timer_count[t] = 0;
                timer_mode[t] = 0;
                timer_target[t] = 0;
                rcnt_active[t] = false;
                rcnt_target_irq[t] = false;
                rcnt_overflow_irq[t] = false;
            }
            return true;
        }
        case 0x01:  // InitException
            if (!events_initialized) init_events();
            return true;
        case 0x02:  // SysEnqIntRP(index, queue)
            return true;
        case 0x03:  // SysDeqIntRP(index, queue)
            return true;
        case 0x04:  // get_free_EvCB_slot
            cpu.set_reg(2, 0);
            return true;
        case 0x05:  // get_free_TCB_slot
            cpu.set_reg(2, 0);
            return true;
        case 0x06: { // ExceptionHandler — install custom exception handler
            // a0 = handler address
            // Store the handler address for use by handle_exception
            printf("[BIOS] C:0x06 ExceptionHandler(0x%08X) at instr #%llu\n",
                   a0, g_cpu ? g_cpu->instructions : 0);
            return true;
        }
        case 0x07: { // InstallExceptionHandler — set the exception dispatch
            // a0 = handler function address
            printf("[BIOS] C:0x07 InstallExceptionHandler(0x%08X) at instr #%llu\n",
                   a0, g_cpu ? g_cpu->instructions : 0);
            return true;
        }
        case 0x08: { // SysInitMemory — initialize system memory pool
            // a0 = memory start, a1 = size
            return true;
        }
        case 0x09:  // SysInitKMem
            return true;
        case 0x0A: { // ChangeClearRCnt(counter, value)
            // Controls whether root counter IRQ auto-clears
            // value: 0 = clear on IRQ, 1 = don't clear
            int t = a0 & 3;
            // We just track this — in our simplified timer model,
            // target IRQs always auto-clear via the tick() handler
            return true;
        }
        case 0x0B: { // SystemError — unrecoverable error
            printf("[BIOS] C:0x0B SystemError at instr #%llu PC=0x%08X\n",
                   g_cpu ? g_cpu->instructions : 0, cpu.pc);
            cpu.crashed = true;
            snprintf(cpu.crash_reason, 255, "BIOS SystemError at instr #%llu", cpu.instructions);
            return false;
        }
        case 0x0C: { // InitDefInt — initialize default interrupt handling
            // This sets up VBlank interrupt delivery and enables interrupts
            if (!events_initialized) init_events();
            // Enable VBlank in I_MASK
            intc_mask |= 0x01;
            // Enable CPU interrupts (IEc=0, IM0 set)
            cpu.cp0_status |= 0x401; // IE | IM0
            printf("[BIOS] C:0x0C InitDefInt: VBlank enabled, CP0 status=0x%08X at instr #%llu\n",
                   cpu.cp0_status, g_cpu ? g_cpu->instructions : 0);
            return true;
        }
        case 0x10: { // _96_init — GPU/CD-ROM init (C table variant)
            return true;
        }
        case 0x11: { // _96_remove — cleanup (C table variant)
            return true;
        }
        case 0x12:  // InstallDevices
            return true;
        case 0x13:  // FlushStfInOutPut
            return true;
        case 0x14: { // GPU_cw (C table variant) — send GPU command
            gpu_gp0(a0);
            return true;
        }
        case 0x15: { // GPU_cwb (C table variant) — send GPU command block
            return true;
        }
        case 0x16: { // GPU_sendPackets (C table variant)
            return true;
        }
        case 0x17: { // GPU_sync (C table variant)
            return true;
        }
        case 0x18: { // GPU_get_status (C table variant)
            uint32_t status = 0x1C000000;
            if (gpu_display_enabled) status |= (1 << 23);
            status |= (gpu_dma_dir & 0x03) << 24;
            if (gpu_dma_dir != 0) status |= (1 << 25);
            cpu.set_reg(2, status);
            return true;
        }
        case 0x19: { // GPU_get_status2 (C table variant)
            cpu.set_reg(2, 0x1C000000);
            return true;
        }
        case 0x1A: { // GPU_dma_control (C table variant)
            return true;
        }
        case 0x1B:  // KernelRedirect
            return true;
        case 0x1C:  // PatchAOTable
            return true;
        default:
            cpu.set_reg(2, 0);
            return true;
        }
    }

    // Unknown table — stub return 0
    cpu.set_reg(2, 0);
    return true;
}

// ============================================================================
// Phase 4: CD-ROM ISO9660 Directory Parsing
// ============================================================================

bool PSX_Memory::parse_iso_directory() {
    if (dir_cached) return true;
    if (!cd_file) return false;

    // ISO9660 Primary Volume Descriptor is at LBA 16
    uint8_t pvd[2048];
    if (!read_cd_sector(16, pvd)) return false;
    if (pvd[0] != 0x01) return false;  // PVD type = 1

    // Root directory record is at offset 156 in PVD
    // Directory record: len(1), ext_len(1), lba(8LE), size(8LE), flags(1), name(var)
    uint8_t* root_rec = pvd + 156;
    uint32_t root_lba = root_rec[2] | (root_rec[3] << 8) | (root_rec[4] << 16) | (root_rec[5] << 24);
    uint32_t root_size = root_rec[10] | (root_rec[11] << 8) | (root_rec[12] << 16) | (root_rec[13] << 24);

    // Read root directory sectors
    uint32_t root_sectors = (root_size + 2047) / 2048;
    uint8_t* dir_buf = new uint8_t[root_sectors * 2048];
    for (uint32_t s = 0; s < root_sectors; s++) {
        if (!read_cd_sector(root_lba + s, dir_buf + s * 2048)) {
            delete[] dir_buf;
            return false;
        }
    }

    // Parse directory records
    dir_entry_count = 0;
    uint32_t pos = 0;
    while (pos < root_size && dir_entry_count < MAX_DIR_ENTRIES) {
        uint8_t rec_len = dir_buf[pos];
        if (rec_len == 0) {
            // Padding to sector boundary — skip to next sector
            pos = (pos / 2048 + 1) * 2048;
            continue;
        }
        uint32_t file_lba = dir_buf[pos+2] | (dir_buf[pos+3]<<8) | (dir_buf[pos+4]<<16) | (dir_buf[pos+5]<<24);
        uint32_t file_size = dir_buf[pos+10] | (dir_buf[pos+11]<<8) | (dir_buf[pos+12]<<16) | (dir_buf[pos+13]<<24);
        uint8_t flags = dir_buf[pos+25];
        uint8_t name_len = dir_buf[pos+32];
        bool is_dir = (flags & 0x02) != 0;

        // Skip "." and ".." entries
        if (name_len == 1 && (dir_buf[pos+33] == 0x00 || dir_buf[pos+33] == 0x01)) {
            pos += rec_len;
            continue;
        }

        // Copy name (strip ;1 version suffix)
        char name[32];
        int nlen = name_len < 31 ? name_len : 31;
        memcpy(name, dir_buf + pos + 33, nlen);
        name[nlen] = 0;
        // Strip ;1 version
        char* semi = strchr(name, ';');
        if (semi) *semi = 0;

        DirEntry& de = dir_entries[dir_entry_count++];
        strncpy(de.name, name, 31);
        de.name[31] = 0;
        de.lba = file_lba;
        de.size = file_size;
        de.is_dir = is_dir;

        pos += rec_len;
    }

    delete[] dir_buf;
    dir_cached = true;
    printf("[CD] ISO9660 directory parsed: %d entries\n", dir_entry_count);
    for (int i = 0; i < dir_entry_count && i < 20; i++) {
        printf("  [%d] %-32s LBA=%u size=%u %s\n", i, dir_entries[i].name,
               dir_entries[i].lba, dir_entries[i].size,
               dir_entries[i].is_dir ? "(dir)" : "");
    }

    // Build LBA ownership map for conflict detection
    build_lba_file_map();
    return true;
}

void PSX_Memory::build_lba_file_map() {
    lba_range_count = 0;
    // Add PVD boot sectors (0-23) and ISO directory region
    // These are synthetic ranges for diagnostics only.
    for (int i = 0; i < dir_entry_count && lba_range_count < MAX_LBA_RANGES; i++) {
        const DirEntry& de = dir_entries[i];
        uint32_t sectors = (de.size + 2047) / 2048;
        if (sectors == 0) sectors = 1;
        LbaFileRange& r = lba_ranges[lba_range_count++];
        r.start_lba = de.lba;
        r.end_lba = de.lba + sectors;
        strncpy(r.name, de.name, 31);
        r.name[31] = 0;
    }
}

const char* PSX_Memory::get_lba_owner(uint32_t lba) const {
    for (int i = 0; i < lba_range_count; i++) {
        if (lba >= lba_ranges[i].start_lba && lba < lba_ranges[i].end_lba) {
            return lba_ranges[i].name;
        }
    }
    return "unmapped";
}

int PSX_Memory::find_cd_file(const char* path, uint32_t& out_lba, uint32_t& out_size) {
    if (!dir_cached) parse_iso_directory();

    // Strip "cdrom:" prefix if present
    const char* fname = path;
    if (strncmp(fname, "cdrom:", 6) == 0) fname += 6;
    // Strip leading slash
    if (fname[0] == '\\' || fname[0] == '/') fname++;

    // Strip ;1 version suffix
    char clean_name[32];
    strncpy(clean_name, fname, 31);
    clean_name[31] = 0;
    char* semi = strchr(clean_name, ';');
    if (semi) *semi = 0;

    for (int i = 0; i < dir_entry_count; i++) {
        if (_stricmp(dir_entries[i].name, clean_name) == 0) {
            out_lba = dir_entries[i].lba;
            out_size = dir_entries[i].size;
            if (_stricmp(clean_name, "hbd1ps1d.w71") == 0 || _stricmp(clean_name, "hbd1ps1d.q41") == 0) {
                ASSERT_INFO_STATE("HBD_FILE_RESOLVED", "HBD file found in ISO dir",
                                  dir_entries[i].lba, dir_entries[i].size);
            }
            return i;
        }
    }
    if (_stricmp(clean_name, "hbd1ps1d.w71") == 0 || _stricmp(clean_name, "hbd1ps1d.q41") == 0) {
        ASSERT_STATE("HBD_FILE_NOT_FOUND", false, "HBD file not found in ISO9660 directory",
                     0, dir_entry_count);
    }
    return -1;
}

int PSX_Memory::alloc_fdesc() {
    for (int i = 5; i < MAX_FDESCS; i++) {  // 0-4 reserved for stdin/stdout/etc
        if (!fdescs[i].in_use) {
            fdescs[i].in_use = true;
            fdescs[i].offset = 0;
            return i;
        }
    }
    return -1;
}

int PSX_Memory::cd_read(int fd, uint32_t ram_buf, int nbytes) {
    if (fd < 0 || fd >= MAX_FDESCS || !fdescs[fd].in_use) return -1;

    FileDesc& fd_ref = fdescs[fd];
    uint32_t remaining = fd_ref.size - fd_ref.offset;
    if (remaining == 0) return 0;
    int to_read = nbytes < (int)remaining ? nbytes : (int)remaining;

    // Read from CD in sector-sized chunks
    uint32_t sec_offset = fd_ref.offset / 2048;
    uint32_t byte_offset = fd_ref.offset % 2048;
    int bytes_read = 0;

    uint8_t sec_buf[2048];
    while (bytes_read < to_read) {
        if (!read_cd_sector(fd_ref.lba + sec_offset, sec_buf)) break;
        int chunk = 2048 - byte_offset;
        if (chunk > to_read - bytes_read) chunk = to_read - bytes_read;
        for (int i = 0; i < chunk; i++) {
            write8(ram_buf + bytes_read, sec_buf[byte_offset + i]);
        }
        bytes_read += chunk;
        sec_offset++;
        byte_offset = 0;
    }

    fd_ref.offset += bytes_read;

    // Deliver file I/O completion events
    deliver_event(0xF0000011, 0x04);  // EvEV file I/O
    deliver_event(0xF4000001, 0x04);  // UeEV

    return bytes_read;
}

// ============================================================================
// Phase 5: Controller Input (PAD)
// ============================================================================

void PSX_Memory::write_pad_buffer(uint32_t buf_addr, uint16_t buttons,
                                   uint8_t rx, uint8_t ry) {
    if (!buf_addr) return;
    // Standard digital pad: 2 bytes header + 2 bytes buttons
    // Bit layout: bit=0 means pressed
    // Byte 0: 0x00 (no config), Byte 1: 0x41 (digital pad ID)
    // Byte 2: button low, Byte 3: button high
    write8(buf_addr, 0x00);
    write8(buf_addr + 1, 0x41);
    write8(buf_addr + 2, buttons & 0xFF);
    write8(buf_addr + 3, (buttons >> 8) & 0xFF);
    // Bytes 4-7: analog right stick (rx, ry) + left stick (lx, ly)
    write8(buf_addr + 4, rx);
    write8(buf_addr + 5, ry);
    write8(buf_addr + 6, pad1_lx);
    write8(buf_addr + 7, pad1_ly);
}

void PSX_Memory::update_pad() {
    if (!pad_started) return;

    // Write pad 1 data
    if (pad_buf1_addr) {
        write_pad_buffer(pad_buf1_addr, pad1_buttons, pad1_rx, pad1_ry);
    }
    // Write pad 2 data
    if (pad_buf2_addr) {
        write_pad_buffer(pad_buf2_addr, pad2_buttons, pad2_rx, pad2_ry);
    }
    // Write PAD_init interrupt buffer
    if (pad_buf_addr) {
        uint32_t off = ram_offset(pad_buf_addr);
        uint32_t val = (uint32_t)pad1_buttons | ((uint32_t)pad2_buttons << 16);
        ram[off] = val & 0xFF;
        ram[off+1] = (val >> 8) & 0xFF;
        ram[off+2] = (val >> 16) & 0xFF;
        ram[off+3] = (val >> 24) & 0xFF;
    }
}

void PSX_Memory::process_input_queue() {
    for (int i = 0; i < input_queue_count; i++) {
        if (input_queue[i].at_vblank == vblank_counter) {
            if (input_queue[i].press) {
                pad1_buttons &= ~input_queue[i].buttons;  // Press = clear bit
            } else {
                pad1_buttons |= input_queue[i].buttons;   // Release = set bit
            }
            // Remove from queue by shifting
            for (int j = i; j < input_queue_count - 1; j++) {
                input_queue[j] = input_queue[j + 1];
            }
            input_queue_count--;
            i--;
        }
    }
}

void PSX_Memory::queue_input(uint64_t at_vblank, uint16_t buttons, bool press) {
    if (input_queue_count < MAX_INPUT_QUEUE) {
        input_queue[input_queue_count].at_vblank = at_vblank;
        input_queue[input_queue_count].buttons = buttons;
        input_queue[input_queue_count].press = press;
        input_queue_count++;
    }
}

// ============================================================================
// Virtual Memory Card
// ============================================================================

void PSX_Memory::memcard_init() {
    if (memcard_initialized) return;
    memset(memcard_data, 0, MEMCARD_SIZE);
    // Initialize directory frame (block 0) with standard PSX format
    // Header frame: "MC" magic at offset 0
    memcard_data[0] = 'M';
    memcard_data[1] = 'C';
    // Rest of directory is zeroed (no files yet)
    memcard_initialized = true;
    memcard_dirty = false;
    printf("[MEMCARD] Initialized (128KB, 16 blocks)\n");
}

void PSX_Memory::memcard_save_to_file(const char* path) {
    FILE* f = fopen(path, "wb");
    if (!f) {
        printf("[MEMCARD] ERROR: Cannot save to %s\n", path);
        return;
    }
    fwrite(memcard_data, 1, MEMCARD_SIZE, f);
    fclose(f);
    printf("[MEMCARD] Saved %d bytes to %s\n", MEMCARD_SIZE, path);
}

bool PSX_Memory::memcard_load_from_file(const char* path) {
    FILE* f = fopen(path, "rb");
    if (!f) return false;
    size_t read = fread(memcard_data, 1, MEMCARD_SIZE, f);
    fclose(f);
    if (read == MEMCARD_SIZE) {
        memcard_initialized = true;
        printf("[MEMCARD] Loaded %d bytes from %s\n", (int)read, path);
        return true;
    }
    printf("[MEMCARD] Load failed: read %d bytes (expected %d)\n", (int)read, MEMCARD_SIZE);
    return false;
}

void PSX_Memory::dump_memcard_state() {
    printf("\n--- Memory Card State ---\n");
    printf("Initialized: %s\n", memcard_initialized ? "YES" : "NO");
    printf("Dirty: %s\n", memcard_dirty ? "YES" : "NO");
    printf("Write calls: %d\n", memcard_write_count);
    printf("Read calls: %d\n", memcard_read_count);
    printf("Create calls: %d\n", memcard_create_count);
    printf("Open FDs: %d\n", memcard_fd_count);
    printf("Last filename: %s\n", memcard_last_filename);
    printf("Last write addr: 0x%08X size: %d\n", memcard_last_write_addr, memcard_last_write_size);

    // Check first 64 bytes of card data (directory header)
    if (memcard_initialized) {
        printf("Card header: ");
        for (int i = 0; i < 16; i++) printf("%02X ", memcard_data[i]);
        printf("\n");

        // Count non-zero bytes in data area (blocks 1-15)
        int nonzero = 0;
        for (uint32_t i = 8192; i < MEMCARD_SIZE; i++) {
            if (memcard_data[i] != 0) nonzero++;
        }
        printf("Non-zero bytes in data area: %d / %d\n", nonzero, MEMCARD_SIZE - 8192);

        if (memcard_dirty) {
            printf("Save data written: YES\n");
            // Dump first 128 bytes of save data (block 1)
            printf("Save data (block 1, first 128 bytes):\n");
            for (int row = 0; row < 8; row++) {
                printf("  %04X: ", row * 16);
                for (int col = 0; col < 16; col++) {
                    printf("%02X ", memcard_data[8192 + row * 16 + col]);
                }
                printf(" |");
                for (int col = 0; col < 16; col++) {
                    uint8_t c = memcard_data[8192 + row * 16 + col];
                    printf("%c", (c >= 0x20 && c < 0x7F) ? c : '.');
                }
                printf("|\n");
            }
        } else {
            printf("Save data written: NO\n");
        }
    }
}

void PSX_Memory::dump_save_buffer(uint32_t ram_addr, uint32_t size) {
    if (size == 0) size = memcard_last_write_size;
    if (size == 0 || ram_addr == 0) {
        printf("[SAVE_DUMP] No save buffer to dump\n");
        return;
    }
    uint32_t off = ram_offset(ram_addr);
    if (off + size > RAM_SIZE) {
        printf("[SAVE_DUMP] Save buffer out of range: 0x%08X + %d\n", ram_addr, size);
        return;
    }
    printf("\n--- Save Buffer Dump (RAM 0x%08X, %d bytes) ---\n", ram_addr, size);
    for (uint32_t row = 0; row < size; row += 16) {
        printf("  %04X: ", row);
        for (uint32_t col = 0; col < 16 && row + col < size; col++) {
            printf("%02X ", ram[off + row + col]);
        }
        printf(" |");
        for (uint32_t col = 0; col < 16 && row + col < size; col++) {
            uint8_t c = ram[off + row + col];
            printf("%c", (c >= 0x20 && c < 0x7F) ? c : '.');
        }
        printf("|\n");
    }
    printf("--- End Save Buffer Dump ---\n");
}

bool PSX_Memory::verify_save_data() {
    if (!memcard_initialized) {
        printf("[SAVE_VERIFY] Memory card not initialized\n");
        return false;
    }
    if (!memcard_dirty) {
        printf("[SAVE_VERIFY] No save data written (card not dirty)\n");
        return false;
    }
    if (memcard_write_count == 0) {
        printf("[SAVE_VERIFY] No _card_write calls detected\n");
        return false;
    }

    // Check 1: Card header must have "MC" magic
    if (memcard_data[0] != 'M' || memcard_data[1] != 'C') {
        printf("[SAVE_VERIFY] FAIL: Card header missing 'MC' magic (got %02X%02X)\n",
               memcard_data[0], memcard_data[1]);
        return false;
    }

    // Check 2: Data area (block 1+) must have non-zero content
    int nonzero = 0;
    for (uint32_t i = 8192; i < MEMCARD_SIZE; i++) {
        if (memcard_data[i] != 0) nonzero++;
    }
    if (nonzero == 0) {
        printf("[SAVE_VERIFY] FAIL: Save data area is all zeros (0KB effective)\n");
        return false;
    }
    printf("[SAVE_VERIFY] Save data area: %d non-zero bytes\n", nonzero);

    // Check 3: If we have a last write address, verify the RAM buffer matches card data
    if (memcard_last_write_addr && memcard_last_write_size > 0) {
        uint32_t off = ram_offset(memcard_last_write_addr);
        int card_off = 8192; // Block 1 start
        int mismatches = 0;
        int check_size = memcard_last_write_size;
        if (check_size > 1024) check_size = 1024; // Limit check
        for (int i = 0; i < check_size; i++) {
            if (ram[off + i] != memcard_data[card_off + i]) {
                mismatches++;
            }
        }
        if (mismatches > 0) {
            printf("[SAVE_VERIFY] WARN: %d/%d bytes differ between RAM buffer and card data\n",
                   mismatches, check_size);
        } else {
            printf("[SAVE_VERIFY] RAM buffer matches card data (%d bytes verified)\n", check_size);
        }
    }

    // Check 4: Detect common corruption patterns
    // All-0xFF = unwritten/erased flash
    int ff_count = 0;
    for (uint32_t i = 8192; i < 16384; i++) { // Check first block of data
        if (memcard_data[i] == 0xFF) ff_count++;
    }
    if (ff_count == 8192) {
        printf("[SAVE_VERIFY] FAIL: Save block is all 0xFF (erased/empty)\n");
        return false;
    }

    printf("[SAVE_VERIFY] PASS: Save data appears valid (%d bytes, %d writes)\n",
           nonzero, memcard_write_count);
    return true;
}

// ============================================================================
// Phase 6: Interactive Debugging
// ============================================================================

void PSX_Memory::add_watchpoint(uint32_t addr, uint32_t mask, bool on_read, bool on_write) {
    if (wp_count < MAX_WATCHPOINTS) {
        watchpoints[wp_count].addr = addr;
        watchpoints[wp_count].mask = mask;
        watchpoints[wp_count].on_read = on_read;
        watchpoints[wp_count].on_write = on_write;
        watchpoints[wp_count].hit = false;
        wp_count++;
    }
}

bool PSX_Memory::check_watchpoint_read(uint32_t addr) {
    bool hit = false;
    for (int i = 0; i < wp_count; i++) {
        if (watchpoints[i].on_read && ((addr & watchpoints[i].mask) == (watchpoints[i].addr & watchpoints[i].mask))) {
            watchpoints[i].hit = true;
            hit = true;
            printf("[WP] READ hit at 0x%08X (wp=%d addr=0x%08X) instr #%llu\n",
                   addr, i, watchpoints[i].addr, g_cpu ? g_cpu->instructions : 0);
        }
    }
    return hit;
}

bool PSX_Memory::check_watchpoint_write(uint32_t addr, uint32_t val) {
    bool hit = false;
    for (int i = 0; i < wp_count; i++) {
        if (watchpoints[i].on_write && ((addr & watchpoints[i].mask) == (watchpoints[i].addr & watchpoints[i].mask))) {
            watchpoints[i].hit = true;
            hit = true;
            printf("[WP] WRITE hit at 0x%08X val=0x%08X (wp=%d) instr #%llu\n",
                   addr, val, i, g_cpu ? g_cpu->instructions : 0);
        }
    }
    return hit;
}

void PSX_Memory::tick_timers() {
    // PSX timers count based on their clock source:
    // Clock source is in bits 8-9 of the mode register (NOT bits 0-1).
    // - Timer 0 source 1/3 → dot clock (~5.3 MHz at 320px)
    // - Timer 1 source 1/3 → HBlank (~15.7 kHz)
    // - Timer 2 source 2/3 → system clock / 8
    // - Everything else → system clock (1:1 with CPU)
    //
    // The CPU runs at ~33.8 MHz. We call tick_timers() once per instruction.
    // For dot clock mode, Timer0 should only increment every ~5 cycles.
    // This is critical for the VSync spinlock: the game reads Timer0 twice
    // (5 instructions apart) and loops if values differ. With dot clock rate,
    // consecutive reads can return the same value, allowing the loop to exit.
    //
    // Reference: PSoXide timers.rs — dot tick = 7 * pixel_div / 11 sys cycles.
    // At 320-wide, pixel_div=8, so dot tick = 56/11 ≈ 5.09 sys cycles.
    static uint32_t t0_accum = 0;
    static uint32_t t1_accum = 0;
    static uint32_t t2_accum = 0;

    for (int t = 0; t < 3; t++) {
        // Count if mode has been set (non-zero) or if rcnt_active
        if (timer_mode[t] == 0 && !rcnt_active[t]) continue;

        // Timer0 (dot clock) pauses during VBlank
        if (t == 0 && vblank_active) continue;

        // Determine clock source from mode bits 8-9 (NOT bits 0-1)
        uint32_t clock_src = (timer_mode[t] >> 8) & 0x03;
        uint32_t increment = 1;

        if (t == 0) {
            // Timer 0: source 1 or 3 = dot clock
            if (clock_src == 1 || clock_src == 3) {
                // Dot clock: 7*8/11 ≈ 5.09 sys cycles per tick at 320-wide
                // Use accumulator: accum += 11; if accum >= 56, increment
                t0_accum += 11;
                if (t0_accum < 56) continue;
                t0_accum -= 56;
                increment = 1;
            }
        } else if (t == 1) {
            // Timer 1: source 1 or 3 = HBlank (~15.7 kHz)
            if (clock_src == 1 || clock_src == 3) {
                // HBlank: 33,868,800 / 15,734 ≈ 2152 sys cycles per tick
                t1_accum += 1;
                if (t1_accum < 2152) continue;
                t1_accum -= 2152;
                increment = 1;
            }
        }
        // Timer 2: source 2 or 3 = system clock / 8
        if (t == 2 && (clock_src == 2 || clock_src == 3)) {
            t2_accum += 1;
            if (t2_accum < 8) continue;
            t2_accum -= 8;
            increment = 1;
        }

        uint32_t old = timer_count[t];
        timer_count[t] = (timer_count[t] + increment) & 0xFFFF;

        // Check target reached (only deliver IRQ if rcnt_active)
        if (timer_target[t] > 0 && old < timer_target[t] && timer_count[t] >= timer_target[t]) {
            if (timer_mode[t] & 0x40) {  // Repeat mode
                timer_count[t] = 0;
            }
            if (rcnt_active[t]) {
                rcnt_target_irq[t] = true;
                intc_stat |= (1 << (t + 4));
                if (g_cpu) g_cpu->interrupt_pending = true;
                deliver_rcnt_event(t, 0);
            }
        }

        // Check overflow
        if (old > timer_count[t]) {
            if (rcnt_active[t]) {
                rcnt_overflow_irq[t] = true;
                if (timer_mode[t] & 0x20) {
                    intc_stat |= (1 << (t + 4));
                    if (g_cpu) g_cpu->interrupt_pending = true;
                }
            }
        }
    }
}

void PSX_Memory::push_call_stack(uint32_t call_pc, uint32_t target_pc) {
    if (call_stack_depth < MAX_CALL_STACK) {
        call_stack[call_stack_depth].call_pc = call_pc;
        call_stack[call_stack_depth].target_pc = target_pc;
        call_stack[call_stack_depth].instr_count = g_cpu ? g_cpu->instructions : 0;
        call_stack_depth++;
    } else {
        // Shift down to make room
        memmove(call_stack, call_stack + 1, (MAX_CALL_STACK - 1) * sizeof(StackFrame));
        call_stack[MAX_CALL_STACK - 1].call_pc = call_pc;
        call_stack[MAX_CALL_STACK - 1].target_pc = target_pc;
        call_stack[MAX_CALL_STACK - 1].instr_count = g_cpu ? g_cpu->instructions : 0;
    }
}

void PSX_Memory::pop_call_stack(uint32_t ret_pc) {
    if (call_stack_depth > 0) call_stack_depth--;
}

void PSX_Memory::dump_event_table() {
    printf("\n=== EVENT TABLE DUMP ===\n");
    int active_count = 0;
    for (int i = 0; i < EV_TABLE_SIZE; i++) {
        if (events[i].used && events[i].status != EvStUNUSED) {
            const char* st = events[i].status == EvStWAIT ? "WAIT" :
                             events[i].status == EvStACTIVE ? "ACTIVE" :
                             events[i].status == EvStALREADY ? "ALREADY" : "?";
            printf("  handle=0x%04X class=0x%08X spec=0x%08X status=%s mode=0x%X handler=0x%08X\n",
                   i, events[i].ev_class, events[i].ev_spec, st,
                   events[i].mode, events[i].fhandler);
            active_count++;
        }
    }
    printf("Total active events: %d\n", active_count);
    printf("=== END EVENT TABLE ===\n\n");
}

uint32_t PSX_Memory::compute_gpustat() {
    uint32_t status = 0x1C000000;  // Ready for CMDs(28) + VRAM(27) + DMA(26)
    if (gpu_interlace_field) status |= (1 << 31);
    if (gpu_display_enabled) status |= (1 << 23);
    if (vblank_active) status |= (1 << 22);
    status |= (gpu_dma_dir & 0x03) << 24;
    if (gpu_dma_dir != 0) status |= (1 << 25);
    if (dma_done[2]) status |= (1 << 25);
    if (gpu_xfer_w > 0 && gpu_xfer_is_read) status |= (1 << 27);
    if (gpu_tpage_y >= 256) status |= (1 << 17);
    status |= ((gpu_tpage_x / 64) & 0x01) << 16;
    if (gpu_dither) status |= (1 << 15);
    status |= ((uint32_t)(gpu_tex_color_mode & 0x03)) << 10;
    status |= (((gpu_tpage_x / 64) >> 1) & 0x03) << 8;
    status |= ((gpu_tpage_y / 256) & 0x0F) << 4;
    status |= (gpu_display_mode & 0x3F) & 0x0F;
    if (gpu_display_mode & 0x20) status |= 0x01;
    return status;
}

void PSX_Memory::dump_gpu_state() {
    printf("\n=== GPU STATE ===\n");
    printf("  display_enabled: %s\n", gpu_display_enabled ? "true" : "false");
    printf("  display_mode: 0x%02X\n", gpu_display_mode);
    printf("  display_start: (%u, %u)\n", gpu_display_start_x, gpu_display_start_y);
    printf("  resolution: %ux%u\n", gpu_horiz_res, gpu_vert_res);
    printf("  GPUSTAT: 0x%08X\n", compute_gpustat());
    printf("=== END GPU STATE ===\n\n");
}

void PSX_Memory::dump_timer_state() {
    printf("\n=== TIMER STATE ===\n");
    for (int t = 0; t < 4; t++) {
        printf("  Timer %d: count=%u mode=0x%04X target=%u active=%d irq_target=%d\n",
               t, timer_count[t], timer_mode[t], timer_target[t],
               rcnt_active[t], rcnt_target_irq[t]);
    }
    printf("  VBlank counter: %u\n", vblank_counter);
    printf("=== END TIMER STATE ===\n\n");
}

void PSX_Memory::dump_call_stack() {
    printf("\n=== CALL STACK (depth=%d) ===\n", call_stack_depth);
    for (int i = 0; i < call_stack_depth; i++) {
        printf("  [%d] 0x%08X -> 0x%08X (instr #%llu)\n",
               i, call_stack[i].call_pc, call_stack[i].target_pc,
               call_stack[i].instr_count);
    }
    printf("=== END CALL STACK ===\n\n");
}

void PSX_Memory::dump_fdescs() {
    printf("\n=== FILE DESCRIPTORS ===\n");
    for (int i = 0; i < MAX_FDESCS; i++) {
        if (fdescs[i].in_use) {
            printf("  fd=%d name=\"%s\" mode=0x%X offset=%u size=%u lba=%u\n",
                   i, fdescs[i].name, fdescs[i].mode, fdescs[i].offset,
                   fdescs[i].size, fdescs[i].lba);
        }
    }
    printf("=== END FILE DESCRIPTORS ===\n\n");
}

void PSX_Memory::dump_full_state(MIPS_CPU& cpu) {
    printf("\n╔══════════════════════════════════════════╗\n");
    printf("║       CYBERGRIME FULL STATE DUMP         ║\n");
    printf("╚══════════════════════════════════════════╝\n");
    printf("Instructions: %llu  PC: 0x%08X  Crashed: %d\n",
           cpu.instructions, cpu.pc, cpu.crashed);
    printf("CP0: Status=0x%08X Cause=0x%08X EPC=0x%08X\n",
           cpu.cp0_status, cpu.cp0_cause, cpu.cp0_epc);
    printf("Regs: ");
    for (int i = 0; i < 32; i++) {
        if (i % 8 == 0 && i > 0) printf("\n      ");
        printf("%s=0x%08X ", cpu.rn(i), cpu.get_reg(i));
    }
    printf("\nHI=0x%08X LO=0x%08X\n", cpu.hi, cpu.lo);
    printf("I_STAT=0x%08X I_MASK=0x%08X VBlank=%u\n",
           intc_stat, intc_mask, vblank_counter);
    printf("HookEntryInt: set=%d addr=0x%08X\n",
           hook_entry_int_set, hook_entry_int_addr);
    dump_event_table();
    dump_gpu_state();
    dump_timer_state();
    dump_fdescs();
    dump_call_stack();
    cpu.dump_trace_ring("Full State Dump");
    g_cdrom_tracer.dump(stderr);  // stderr avoids pipe deadlock when stdout is redirected
    // Disassemble around crash PC
    if (cpu.crashed && g_mem) {
        printf("\n=== CRASH DISASSEMBLY (around PC=0x%08X) ===\n", cpu.pc);
        // Read EXE from RAM (first 680KB of main RAM)
        uint8_t exe_buf[696320];
        uint32_t exe_size = 696320;
        if (exe_size > 0x800000 + 0x800000) exe_size = 0x800000;
        for (uint32_t i = 0; i < exe_size && i < sizeof(exe_buf); i++) {
            exe_buf[i] = read8(0x80017F00 + i);
        }
        g_disasm.disasm_around_crash(stdout, exe_buf, sizeof(exe_buf), cpu.pc);
    }
}

// ============================================================================
// Load EXE from CD-ROM
// ============================================================================

bool PSX_Memory::find_boot_exe(uint32_t& out_lba, uint32_t& out_sectors,
                                char* out_name, int name_len) {
    if (!cd_loaded) return false;
    if (!dir_cached) parse_iso_directory();

    // Find SYSTEM.CNF in the directory
    uint32_t cnf_lba = 0, cnf_size = 0;
    int cnf_idx = find_cd_file("SYSTEM.CNF", cnf_lba, cnf_size);
    if (cnf_idx < 0) {
        // Try lowercase
        cnf_idx = find_cd_file("system.cnf", cnf_lba, cnf_size);
    }
    if (cnf_idx < 0) {
        printf("[BOOT] SYSTEM.CNF not found in ISO9660 directory\n");
        return false;
    }

    // Read SYSTEM.CNF
    uint32_t cnf_sectors = (cnf_size + 2047) / 2048;
    uint8_t* cnf = new uint8_t[cnf_sectors * 2048];
    for (uint32_t i = 0; i < cnf_sectors; i++) {
        if (!read_cd_sector(cnf_lba + i, cnf + i * 2048)) {
            delete[] cnf;
            return false;
        }
    }

    // Parse BOOT= line
    char boot_path[256] = {0};
    for (uint32_t i = 0; i < cnf_size; i++) {
        if (strncmp((char*)(cnf + i), "BOOT", 4) == 0) {
            // Find '=' sign
            char* eq = strchr((char*)(cnf + i), '=');
            if (eq) {
                eq++; // skip '='
                while (*eq == ' ' || *eq == '\\' || *eq == '/') eq++;
                // Copy until newline or end
                int j = 0;
                while (eq[j] && eq[j] != '\r' && eq[j] != '\n' && j < 255) {
                    boot_path[j] = eq[j];
                    j++;
                }
                boot_path[j] = 0;
                break;
            }
        }
    }
    delete[] cnf;

    if (boot_path[0] == 0) {
        printf("[BOOT] No BOOT= line found in SYSTEM.CNF\n");
        return false;
    }

    // Strip cdrom: prefix
    char* fname = boot_path;
    if (strncmp(fname, "cdrom:", 6) == 0) fname += 6;
    if (fname[0] == '\\' || fname[0] == '/') fname++;

    // Strip ;1 version suffix
    char clean[256];
    strncpy(clean, fname, 255);
    clean[255] = 0;
    char* semi = strchr(clean, ';');
    if (semi) *semi = 0;

    printf("[BOOT] SYSTEM.CNF says BOOT=%s (cleaned: %s)\n", boot_path, clean);

    // Find the EXE in the ISO9660 directory
    uint32_t exe_size = 0;
    int exe_idx = find_cd_file(clean, out_lba, exe_size);
    if (exe_idx < 0) {
        printf("[BOOT] EXE file '%s' not found in ISO9660 directory\n", clean);
        return false;
    }

    out_sectors = (exe_size + 2047) / 2048;
    if (out_name) {
        strncpy(out_name, clean, name_len - 1);
        out_name[name_len - 1] = 0;
    }

    printf("[BOOT] Found EXE: %s at LBA=%u sectors=%u size=%u\n",
           clean, out_lba, out_sectors, exe_size);
    return true;
}

bool PSX_Memory::load_exe_from_cd(uint32_t exe_lba, uint32_t exe_sectors,
                                   uint32_t& out_pc, uint32_t& out_dest, uint32_t& out_size) {
    if (!cd_loaded) return false;

    // Read all EXE sectors
    uint8_t* exe_data = new uint8_t[exe_sectors * 2048];
    for (uint32_t i = 0; i < exe_sectors; i++) {
        if (!read_cd_sector(exe_lba + i, exe_data + i * 2048)) {
            delete[] exe_data;
            return false;
        }
    }

    // Parse PS-X EXE header
    if (memcmp(exe_data, "PS-X EXE", 8) != 0) {
        printf("[EXE] Not a PS-X EXE! First 8 bytes: %02X %02X %02X %02X %02X %02X %02X %02X\n",
               exe_data[0], exe_data[1], exe_data[2], exe_data[3],
               exe_data[4], exe_data[5], exe_data[6], exe_data[7]);
        delete[] exe_data;
        return false;
    }

    out_pc   = *(uint32_t*)(exe_data + 0x10);
    out_dest = *(uint32_t*)(exe_data + 0x18);
    out_size = *(uint32_t*)(exe_data + 0x1C);

    // Also read initial GP and SP from header
    uint32_t init_gp = *(uint32_t*)(exe_data + 0x14);
    uint32_t init_sp = *(uint32_t*)(exe_data + 0x30);
    printf("[EXE] Header: PC=0x%08X GP=0x%08X dest=0x%08X size=0x%X SP=0x%08X\n",
           out_pc, init_gp, out_dest, out_size, init_sp);

    // Store GP and SP for the caller to use
    exe_init_gp = init_gp;
    exe_init_sp = init_sp;

    // Load EXE body into RAM
    uint32_t load_size = out_size;
    if (out_dest + load_size > 0x80200000) {
        load_size = 0x80200000 - out_dest;
    }

    uint32_t ram_off = ram_offset(out_dest);
    memcpy(ram + ram_off, exe_data + 0x800, load_size);

    delete[] exe_data;
    return true;
}

// ============================================================================
// Phase 7: GPU VRAM + Rendering
// ============================================================================

void PSX_Memory::gpu_reset() {
    memset(vram, 0, sizeof(vram));
    gpu_cmd_count = 0;
    gpu_gp0_cmd_total = 0;
    gpu_gp1_cmd_total = 0;
    gpu_vram_write_total = 0;
    gpu_cmd_type = 0;
    gpu_cmd_words_needed = 0;
    gpu_cmd_words_got = 0;
    gpu_display_enabled = true;
    gpu_display_start_x = 0;
    gpu_display_start_y = 0;
    gpu_horiz_res = 320;
    gpu_vert_res = 240;
    gpu_xfer_x = gpu_xfer_y = 0;
    gpu_xfer_w = gpu_xfer_h = 0;
    gpu_xfer_cx = gpu_xfer_cy = 0;
    gpu_xfer_is_read = false;
    gpu_interlace_field = false;  // Start on odd field
    gpu_drawing_busy = false;     // We process commands instantly
    gpu_texpage = 0;
    gpu_texwin = 0;
    gpu_draw_area_tl = 0;
    gpu_draw_area_br = 0;
    gpu_draw_offset = 0;
    gpu_tpage_x = 0; gpu_tpage_y = 0;
    gpu_tex_abr = false;
    gpu_dither = 0;
    gpu_tex_color_mode = 0;
    gpu_semi_trans_mode = 0;
    gpu_off_x = 0; gpu_off_y = 0;
    gpu_draw_x1 = 0; gpu_draw_y1 = 0; gpu_draw_x2 = 1023; gpu_draw_y2 = 511;
    gpu_texwin_mask_x = 0; gpu_texwin_mask_y = 0;
    gpu_texwin_off_x = 0; gpu_texwin_off_y = 0;
    fb_dirty = true;
}

void PSX_Memory::gpu_clear_vram() {
    memset(vram, 0, sizeof(vram));
    fb_dirty = true;
}

// Convert PSX 15-bit color (0xBBBBBGGGGGGRRRRR) to 32-bit ARGB
static inline uint32_t psx_to_argb(uint16_t c) {
    uint8_t r = (c & 0x1F) << 3;
    uint8_t g = ((c >> 5) & 0x1F) << 3;
    uint8_t b = ((c >> 10) & 0x1F) << 3;
    return 0xFF000000 | (r << 16) | (g << 8) | b;
}

void PSX_Memory::gpu_vram_write(uint16_t x, uint16_t y, uint16_t w, uint16_t h, const uint16_t* src) {
    for (uint16_t row = 0; row < h; row++) {
        for (uint16_t col = 0; col < w; col++) {
            uint16_t vx = (x + col) & (VRAM_W - 1);
            uint16_t vy = (y + row) & (VRAM_H - 1);
            vram[vy * VRAM_W + vx] = src[row * w + col];
        }
    }
    fb_dirty = true;
}

void PSX_Memory::gpu_vram_read(uint16_t x, uint16_t y, uint16_t w, uint16_t h, uint16_t* dst) {
    for (uint16_t row = 0; row < h; row++) {
        for (uint16_t col = 0; col < w; col++) {
            uint16_t vx = (x + col) & (VRAM_W - 1);
            uint16_t vy = (y + row) & (VRAM_H - 1);
            dst[row * w + col] = vram[vy * VRAM_W + vx];
        }
    }
}

void PSX_Memory::gpu_draw_rect(int x, int y, int w, int h, uint32_t color) {
    // Draw a filled rectangle to VRAM (for GP0 rectangle commands)
    uint16_t c16 = (uint16_t)(((color >> 3) & 0x1F) | (((color >> 11) & 0x1F) << 5) | (((color >> 19) & 0x1F) << 10));
    for (int row = 0; row < h; row++) {
        for (int col = 0; col < w; col++) {
            uint16_t vx = (x + col) & (VRAM_W - 1);
            uint16_t vy = (y + row) & (VRAM_H - 1);
            vram[vy * VRAM_W + vx] = c16;
        }
    }
    fb_dirty = true;
}

void PSX_Memory::gpu_gp0(uint32_t val) {
    uint8_t cmd = (val >> 24) & 0xFF;
    gpu_gp0_cmd_total++;

    if (gpu_xfer_w > 0 && !gpu_xfer_is_read) {
        // CPU→VRAM transfer: two 16-bit pixels per 32-bit word
        for (int i = 0; i < 2; i++) {
            uint16_t pixel = (i == 0) ? (val & 0xFFFF) : ((val >> 16) & 0xFFFF);
            uint16_t vx = (gpu_xfer_x + gpu_xfer_cx) & (VRAM_W - 1);
            uint16_t vy = (gpu_xfer_y + gpu_xfer_cy) & (VRAM_H - 1);
            vram[vy * VRAM_W + vx] = pixel;
            gpu_xfer_cx++;
            if (gpu_xfer_cx >= gpu_xfer_w) {
                gpu_xfer_cx = 0;
                gpu_xfer_cy++;
                if (gpu_xfer_cy >= gpu_xfer_h) {
                    gpu_xfer_w = 0;
                    gpu_xfer_h = 0;
                    fb_dirty = true;
                    break;
                }
            }
        }
        return;
    }

    // Normal command processing
    if (gpu_cmd_count == 0) {
        gpu_cmd_type = cmd;
        gpu_cmd_fifo[0] = val;
        gpu_cmd_words_got = 1;
        gpu_cmd_words_needed = psx_gpu_cmd_word_count(cmd);
        if (gpu_cmd_words_needed == 1) {
            gpu_process_command();
            gpu_cmd_count = 0;
        } else {
            gpu_cmd_count = 1;
        }
    } else {
        gpu_cmd_fifo[gpu_cmd_count] = val;
        gpu_cmd_count++;
        gpu_cmd_words_got++;
        if (gpu_cmd_words_got >= gpu_cmd_words_needed) {
            gpu_process_command();
            gpu_cmd_count = 0;
        }
    }
}

void PSX_Memory::gpu_gp1(uint32_t val) {
    uint8_t cmd = (val >> 24) & 0xFF;
    gpu_gp1_cmd_total++;

    switch (cmd) {
        case 0x00:  // GPU reset
            gpu_reset();
            break;
        case 0x01:  // Reset command buffer
            gpu_cmd_count = 0;
            gpu_xfer_w = 0;
            break;
        case 0x02:  // Acknowledge GPU interrupt
            break;
        case 0x03:  // Display enable
            gpu_display_enabled = !(val & 1);
            if (gpu_display_enabled) {
                uint32_t off = ram_offset(0x800B5312);
                ram[off] = 0x01; ram[off+1] = 0x00;
            }
            break;
        case 0x04:  // DMA direction
            gpu_dma_dir = val & 0x03;
            break;
        case 0x05:  // Display area start (VRAM)
            gpu_display_start_x = val & 0x3FF;
            gpu_display_start_y = (val >> 10) & 0x1FF;
            fb_dirty = true;
            break;
        case 0x06:  // Horizontal display range
            gpu_display_range_h = val & 0xFFF;
            break;
        case 0x07:  // Vertical display range
            gpu_display_range_v = val & 0xFFF;
            break;
        case 0x08:  // Display mode
            gpu_display_mode = val & 0x3F;
            // Extract resolution
            if (val & 0x40) { gpu_horiz_res = 640; gpu_vert_res = 480; }
            else { gpu_horiz_res = 320; gpu_vert_res = 240; }
            fb_dirty = true;
            break;
        case 0x10: {  // Get GPU info
            uint32_t info = val & 0x0F;
            switch (info) {
                case 0x00:  // Texture page info (from GP0 0xE1)
                    gpu_read_data = gpu_texpage & 0x1FFF;
                    break;
                case 0x02: gpu_read_data = gpu_texwin; break;
                case 0x03: gpu_read_data = gpu_draw_area_tl; break;
                case 0x04: gpu_read_data = gpu_draw_area_br; break;
                case 0x05: gpu_read_data = gpu_draw_offset; break;
                case 0x06: gpu_read_data = 0; break;  // drawing area top-left (unknown)
                case 0x07: gpu_read_data = 0x00000200; break;  // 1MB VRAM
                case 0x08: gpu_read_data = 0; break;  // unknown
                default: gpu_read_data = 0; break;
            }
            break;
        }
        default: break;
    }
}


void PSX_Memory::gpu_render_framebuffer() {
    // Convert VRAM display area to 32-bit framebuffer for Win32 blitting
    // PSX display area starts at (gpu_display_start_x, gpu_display_start_y) in VRAM
    uint32_t dx = gpu_display_start_x;
    uint32_t dy = gpu_display_start_y;

    for (uint32_t y = 0; y < FB_H; y++) {
        for (uint32_t x = 0; x < FB_W; x++) {
            uint32_t vx = (dx + x) & (VRAM_W - 1);
            uint32_t vy = (dy + y) & (VRAM_H - 1);
            uint16_t pixel = vram[vy * VRAM_W + vx];
            framebuffer[y * FB_W + x] = psx_to_argb(pixel);
        }
    }
    fb_dirty = false;
}

// ============================================================================
// ORCHESTRATION ENGINE IMPLEMENTATION
// ============================================================================

// Run hooks for current PC. Returns 0=continue, 1=skip, 2=redirected
int OrchestrationEngine::run_hooks(MIPS_CPU& cpu, PSX_Memory& mem, bool pre_exec) {
    if (!enabled) return 0;

    uint32_t cur_pc = cpu.pc;
    uint32_t flag_check = pre_exec ? HF_PRE_EXEC : HF_POST_EXEC;

    for (int i = 0; i < MAX_HOOKS; i++) {
        HookEntry& h = hooks[i];
        if (!(h.flags & HF_ENABLED) || h.pc != cur_pc) continue;
        if (!(h.flags & flag_check)) continue;
        if (h.max_hits > 0 && h.hit_count >= h.max_hits) continue;

        h.hit_count++;

        if (h.flags & HF_LOG_REGS) {
            printf("[HOOK] \"%s\" PC=0x%08X instr #%llu hits=%d\n",
                   h.label, cur_pc, (unsigned long long)cpu.instructions, h.hit_count);
            printf("  $a0=0x%08X $a1=0x%08X $a2=0x%08X $a3=0x%08X\n",
                   cpu.get_reg(4), cpu.get_reg(5), cpu.get_reg(6), cpu.get_reg(7));
            printf("  $v0=0x%08X $v1=0x%08X $ra=0x%08X $sp=0x%08X $gp=0x%08X\n",
                   cpu.get_reg(2), cpu.get_reg(3), cpu.get_reg(31), cpu.get_reg(29), cpu.get_reg(28));
        }

        switch (h.action) {
            case HOOK_NONE:
                break;
            case HOOK_SKIP:
                cpu.pc = cpu.next_pc;
                cpu.in_branch_delay = false;
                cpu.pending_branch = false;
                if (h.flags & HF_ONESHOT) h.flags &= ~HF_ENABLED;
                return 1;
            case HOOK_REDIRECT:
                cpu.pc = h.redirect_pc;
                cpu.next_pc = h.redirect_pc + 4;
                cpu.in_branch_delay = false;
                cpu.pending_branch = false;
                if (h.flags & HF_ONESHOT) h.flags &= ~HF_ENABLED;
                return 2;
            case HOOK_SET_REG:
                cpu.set_reg(h.set_reg_num, h.set_reg_val);
                break;
            case HOOK_OVERRIDE_INSTR:
                // Handled in step() by replacing the fetched instruction
                break;
            case HOOK_CALL_HANDLER:
                if (h.handler) h.handler(cpu, mem, h);
                break;
        }

        if (h.flags & HF_ONESHOT) h.flags &= ~HF_ENABLED;
    }
    return 0;
}

// Sample registers at a specific PC
void OrchestrationEngine::sample_registers(MIPS_CPU& cpu, uint32_t cur_pc) {
    if (!enabled) return;
    for (int i = 0; i < MAX_WATCHES; i++) {
        RegWatch& w = watches[i];
        if (w.pc == 0 || w.pc != cur_pc) continue;
        if (w.max_samples > 0 && w.sample_count >= w.max_samples) continue;
        w.sample_count++;

        printf("[REGWATCH] \"%s\" PC=0x%08X instr #%llu\n",
               w.label, cur_pc, (unsigned long long)cpu.instructions);
        printf("  $a0=0x%08X $a1=0x%08X $a2=0x%08X $a3=0x%08X\n",
               cpu.get_reg(4), cpu.get_reg(5), cpu.get_reg(6), cpu.get_reg(7));
        printf("  $v0=0x%08X $v1=0x%08X $ra=0x%08X $sp=0x%08X $gp=0x%08X\n",
               cpu.get_reg(2), cpu.get_reg(3), cpu.get_reg(31), cpu.get_reg(29), cpu.get_reg(28));
        printf("  SR=0x%08X EPC=0x%08X Cause=0x%08X\n",
               cpu.cp0_status, cpu.cp0_epc, cpu.cp0_cause);
    }
}

// Rollback last audit entry
bool OrchestrationEngine::audit_rollback_last(PSX_Memory& mem) {
    if (audit_count == 0) return false;
    // Find last non-rolled-back entry
    for (int i = audit_count - 1; i >= 0; i--) {
        if (!audit_log[i].rolled_back) {
            AuditEntry& e = audit_log[i];
            uint32_t off = mem.ram_offset(e.addr);
            if (e.size == 1) mem.ram[off] = e.old_value & 0xFF;
            else if (e.size == 2) { mem.ram[off] = e.old_value & 0xFF; mem.ram[off+1] = (e.old_value >> 8) & 0xFF; }
            else { mem.ram[off] = e.old_value & 0xFF; mem.ram[off+1] = (e.old_value >> 8) & 0xFF; mem.ram[off+2] = (e.old_value >> 16) & 0xFF; mem.ram[off+3] = (e.old_value >> 24) & 0xFF; }
            e.rolled_back = true;
            printf("[AUDIT] Rolled back: addr=0x%08X restored to 0x%08X (was 0x%08X)\n",
                   e.addr, e.old_value, e.new_value);
            return true;
        }
    }
    return false;
}

// Rollback all entries after target_count
int OrchestrationEngine::audit_rollback_to(PSX_Memory& mem, int target_count) {
    int rolled = 0;
    while (audit_count > target_count) {
        if (audit_rollback_last(mem)) rolled++;
        else break;
    }
    printf("[AUDIT] Rolled back %d entries to index %d\n", rolled, target_count);
    return rolled;
}

// Dump full audit log
void OrchestrationEngine::audit_dump(const char* path) {
    FILE* f = fopen(path, "w");
    if (!f) return;
    fprintf(f, "Audit Log — %d entries\n", audit_count);
    fprintf(f, "%-12s %-10s %-12s %-12s %-4s %s\n", "Instr", "Addr", "Old", "New", "Size", "Reason");
    for (int i = 0; i < audit_count; i++) {
        AuditEntry& e = audit_log[i];
        fprintf(f, "%-12llu 0x%08X  0x%08X   0x%08X   %-4d %s%s\n",
                (unsigned long long)e.instr_count, e.addr, e.old_value, e.new_value,
                e.size, e.reason, e.rolled_back ? " [ROLLED BACK]" : "");
    }
    fclose(f);
    printf("[AUDIT] Dumped %d entries to %s\n", audit_count, path);
}

// Verify DQ4 RAM region against DW7 EXE reference
int OrchestrationEngine::verify_region(PSX_Memory& mem, uint32_t dq4_addr, int size) {
    if (!dw7_loaded) return -1;
    uint32_t dw7_a = translate_dq4_to_dw7(dq4_addr);
    if (dw7_a == 0) return -1;
    // DW7 EXE loaded at 0x80017F00, stored in dw7_exe[] starting after header
    uint32_t dw7_off = dw7_a - 0x80017F00;
    if (dw7_off + size > dw7_exe_size) return -1;

    uint32_t dq4_off = mem.ram_offset(dq4_addr);
    int mismatches = 0;
    for (int i = 0; i < size; i++) {
        if (mem.ram[dq4_off + i] != dw7_exe[dw7_off + i]) {
            if (mismatches < 10) {
                printf("[VERIFY] Mismatch at 0x%08X: DQ4=0x%02X DW7=0x%02X\n",
                       dq4_addr + i, mem.ram[dq4_off + i], dw7_exe[dw7_off + i]);
            }
            mismatches++;
        }
    }
    return mismatches;
}

// Bulk opcode search-and-replace in RAM
int OrchestrationEngine::bulk_search_replace(PSX_Memory& mem, uint32_t start, uint32_t end,
                                              const SearchReplace* ops, int num_ops) {
    int replacements = 0;
    uint32_t start_off = mem.ram_offset(start);
    uint32_t end_off = mem.ram_offset(end);

    for (uint32_t off = start_off; off + 4 <= end_off; off += 4) {
        uint32_t instr = mem.ram[off] | (mem.ram[off+1] << 8) |
                         (mem.ram[off+2] << 16) | (mem.ram[off+3] << 24);
        for (int op = 0; op < num_ops; op++) {
            if ((instr & ops[op].mask) == ops[op].pattern) {
                uint32_t addr = start + (off - start_off);
                uint32_t new_instr = ops[op].replacement;
                // Audit the change
                audit_write(g_cpu ? g_cpu->instructions : 0, addr, instr, new_instr, 4, ops[op].reason);
                mem.ram[off] = new_instr & 0xFF;
                mem.ram[off+1] = (new_instr >> 8) & 0xFF;
                mem.ram[off+2] = (new_instr >> 16) & 0xFF;
                mem.ram[off+3] = (new_instr >> 24) & 0xFF;
                replacements++;
                if (replacements <= 20) {
                    printf("[BULK] Replaced at 0x%08X: 0x%08X -> 0x%08X (%s)\n",
                           addr, instr, new_instr, ops[op].reason);
                }
                break;  // One replacement per instruction
            }
        }
    }
    printf("[BULK] %d total replacements in range 0x%08X-0x%08X\n", replacements, start, end);
    return replacements;
}

// PC Auto-Corrector — recover from illegal opcodes / unmapped addresses
bool OrchestrationEngine::auto_correct(MIPS_CPU& cpu, uint32_t bad_pc, const char* reason) {
    if (!auto_correct_enabled || correction_count >= max_corrections) return false;

    // Strategy 1: If PC is in danger zone (HBD data region), rewind to $ra
    if (bad_pc >= danger_zone_start && bad_pc < danger_zone_end) {
        uint32_t ra = cpu.get_reg(31);
        if (ra >= 0x80000000 && ra < 0x80200000 && ra != bad_pc) {
            correction_count++;
            printf("[AUTOCORRECT] #%d: Danger zone PC=0x%08X -> $ra=0x%08X (%s) instr #%llu\n",
                   correction_count, bad_pc, ra, reason,
                   (unsigned long long)cpu.instructions);
            if (g_cdlog && g_cdlog_count < 20000) {
                fprintf(g_cdlog, "[AUTOCORRECT] #%d: 0x%08X -> 0x%08X (%s) instr #%llu\n",
                        correction_count, bad_pc, ra, reason,
                        (unsigned long long)cpu.instructions);
                g_cdlog_count++;
            }
            cpu.pc = ra;
            cpu.next_pc = ra + 4;
            cpu.in_branch_delay = false;
            cpu.pending_branch = false;
            return true;
        }
    }

    // Strategy 2: If PC is in unmapped high region (0x84000000+), mask to valid RAM
    if (bad_pc >= 0x84000000) {
        uint32_t fixed = (bad_pc & 0x1FFFFF) | 0x80000000;
        correction_count++;
        printf("[AUTOCORRECT] #%d: Unmapped PC=0x%08X -> masked to 0x%08X (%s) instr #%llu\n",
               correction_count, bad_pc, fixed, reason,
               (unsigned long long)cpu.instructions);
        if (g_cdlog && g_cdlog_count < 20000) {
            fprintf(g_cdlog, "[AUTOCORRECT] #%d: 0x%08X -> 0x%08X (%s) instr #%llu\n",
                    correction_count, bad_pc, fixed, reason,
                    (unsigned long long)cpu.instructions);
            g_cdlog_count++;
        }
        cpu.pc = fixed;
        cpu.next_pc = fixed + 4;
        cpu.in_branch_delay = false;
        cpu.pending_branch = false;
        return true;
    }

    // Strategy 2b: If PC is in unmapped gap (0x00200000-0x80000000), search trace ring
    if (bad_pc >= 0x00200000 && bad_pc < 0x80000000) {
        for (int i = cpu.trace_ring_count - 1; i >= 0 && i >= cpu.trace_ring_count - 32; i--) {
            int idx = (cpu.trace_ring_head - 1 - (cpu.trace_ring_count - 1 - i) + cpu.TRACE_RING_SIZE) % cpu.TRACE_RING_SIZE;
            uint32_t candidate = cpu.trace_ring[idx].pc;
            if (candidate >= 0x80017F00 && candidate < 0x800BCF00) {
                correction_count++;
                printf("[AUTOCORRECT] #%d: Gap PC=0x%08X -> trace 0x%08X (%s) instr #%llu\n",
                       correction_count, bad_pc, candidate, reason,
                       (unsigned long long)cpu.instructions);
                cpu.pc = candidate;
                cpu.next_pc = candidate + 4;
                cpu.in_branch_delay = false;
                cpu.pending_branch = false;
                return true;
            }
        }
    }

    // Strategy 2c: If PC is in RAM mirror but unaligned, remap to cached RAM
    if (bad_pc < 0x00200000 && (bad_pc & 3) != 0) {
        uint32_t fixed = (bad_pc & 0x1FFFFF) | 0x80000000;
        fixed &= ~3;  // Align to word boundary
        correction_count++;
        printf("[AUTOCORRECT] #%d: Unaligned mirror PC=0x%08X -> 0x%08X (%s) instr #%llu\n",
               correction_count, bad_pc, fixed, reason,
               (unsigned long long)cpu.instructions);
        cpu.pc = fixed;
        cpu.next_pc = fixed + 4;
        cpu.in_branch_delay = false;
        cpu.pending_branch = false;
        return true;
    }

    // Strategy 3: Search trace ring for last valid PC in main EXE range
    for (int i = cpu.trace_ring_count - 1; i >= 0 && i >= cpu.trace_ring_count - 32; i--) {
        int idx = (cpu.trace_ring_head - 1 - (cpu.trace_ring_count - 1 - i) + cpu.TRACE_RING_SIZE) % cpu.TRACE_RING_SIZE;
        uint32_t candidate = cpu.trace_ring[idx].pc;
        if (candidate >= 0x80017F00 && candidate < 0x800BCF00) {
            correction_count++;
            printf("[AUTOCORRECT] #%d: Rewind PC=0x%08X -> trace 0x%08X (%s) instr #%llu\n",
                   correction_count, bad_pc, candidate, reason,
                   (unsigned long long)cpu.instructions);
            cpu.pc = candidate;
            cpu.next_pc = candidate + 4;
            cpu.in_branch_delay = false;
            cpu.pending_branch = false;
            return true;
        }
    }

    return false;  // Uncorrectable
}

// Telemetry dump
void OrchestrationEngine::dump_telemetry(MIPS_CPU& cpu, PSX_Memory& mem, uint64_t instr) {
    if (!telemetry_enabled || !telemetry_file) return;
    if (instr - last_telem_instr < (uint64_t)telemetry_interval) return;
    last_telem_instr = instr;

    fprintf(telemetry_file, "[TELEM] instr #%llu PC=0x%08X\n",
            (unsigned long long)instr, cpu.pc);
    fprintf(telemetry_file, "  $a0=0x%08X $a1=0x%08X $a2=0x%08X $a3=0x%08X\n",
            cpu.get_reg(4), cpu.get_reg(5), cpu.get_reg(6), cpu.get_reg(7));
    fprintf(telemetry_file, "  $v0=0x%08X $v1=0x%08X $ra=0x%08X $sp=0x%08X $gp=0x%08X\n",
            cpu.get_reg(2), cpu.get_reg(3), cpu.get_reg(31), cpu.get_reg(29), cpu.get_reg(28));
    fprintf(telemetry_file, "  SR=0x%08X EPC=0x%08X Cause=0x%08X\n",
            cpu.cp0_status, cpu.cp0_epc, cpu.cp0_cause);
    fprintf(telemetry_file, "  CD-ROM: status=0x%02X int_flag=0x%02X int_enable=0x%02X sectors_read=%d\n",
            mem.cdrom_secondary_status, mem.cdrom_int_flag, mem.cdrom_int_enable,
            mem.cdrom_sectors_read);
    if (instr % (telemetry_interval * 10) == 0) fflush(telemetry_file);
}

// Verify injected code — check for valid MIPS prologue
bool OrchestrationEngine::verify_injected_code(PSX_Memory& mem, uint32_t addr, int size) {
    uint32_t off = mem.ram_offset(addr);
    // Check first instruction for common MIPS prologues:
    //   27BDFFF0 = addiu $sp,$sp,-16
    //   27BDFFE0 = addiu $sp,$sp,-32
    //   27BDFFxx = addiu $sp,$sp,-xx (any negative)
    //   3C1Fxxxx = lui $ra,xxxx (rare but valid)
    uint32_t first_word = mem.ram[off] | (mem.ram[off+1] << 8) |
                          (mem.ram[off+2] << 16) | (mem.ram[off+3] << 24);

    bool is_addiu_sp = (first_word & 0xFFFF0000) == 0x27BD0000 &&
                       (int16_t)(first_word & 0xFFFF) < 0;
    bool is_sw_ra = ((first_word >> 26) == 0x2B) && ((first_word >> 16) & 0x1F) == 0x1F;

    if (is_addiu_sp || is_sw_ra) {
        printf("[VERIFY] Injected code at 0x%08X looks valid (first word=0x%08X)\n", addr, first_word);
        return true;
    }

    printf("[VERIFY] Injected code at 0x%08X looks INVALID (first word=0x%08X)\n", addr, first_word);
    return false;
}

// Write bubblegum stub — minimal MIPS that sets CD-ready flags and
// calls ChangeTh(0) to switch back to the main thread scheduler.
// Without this, jr $ra loops back to the thread entry forever.
void OrchestrationEngine::write_bubblegum_stub(PSX_Memory& mem, uint32_t addr) {
    // MIPS stub (10 instructions = 40 bytes):
    //   lui  $t0, 0x800B         # t0 = 0x800B0000
    //   ori  $t1, $zero, 0x91CC  # t1 = 0x91CC
    //   addu $t0, $t0, $t1       # t0 = 0x800B91CC (CD init done flag)
    //   ori  $t2, $zero, 0x01    # t2 = 1
    //   sb   $t2, 0($t0)         # *0x800B91CC = 1 (CD init done)
    //   ori  $a0, $zero, 0x0000  # a0 = 0 (thread 0 = main thread)
    //   ori  $t3, $zero, 0x00B0  # t3 = 0xB0 (BIOS B-table vector)
    //   jr   $t3                 # jump to 0xB0 (jr uses full register value)
    //   ori  $t1, $zero, 0x0010  # DELAY SLOT: t1 = 0x10 (ChangeTh) — set AFTER any interrupt
    //   nop                     # safety (never reached if ChangeTh succeeds)

    uint32_t stub[BUBBLEGUM_STUB_SIZE / 4] = {
        0x3C08800B,  // lui  $t0, 0x800B
        0x340991CC,  // ori  $t1, $zero, 0x91CC
        0x01094020,  // addu $t0, $t0, $t1   -> t0 = 0x800B91CC
        0x340A0001,  // ori  $t2, $zero, 0x01
        0xA1020000,  // sb   $t2, 0($t0)     -> *0x800B91CC = 1
        0x34040000,  // ori  $a0, $zero, 0x0000  -> a0 = 0
        0x340B00B0,  // ori  $t3, $zero, 0x00B0  -> t3 = 0xB0 (BIOS B-table)
        0x01600008,  // jr   $t3                 -> jump to 0xB0
        0x34090010,  // ori  $t1, $zero, 0x0010  -> DELAY SLOT: t1=0x10 (ChangeTh)
        0x00000000,  // nop                     -> safety (never reached if ChangeTh works)
    };

    uint32_t off = mem.ram_offset(addr);
    for (int i = 0; i < 10; i++) {
        mem.ram[off + i*4]     = stub[i] & 0xFF;
        mem.ram[off + i*4 + 1] = (stub[i] >> 8) & 0xFF;
        mem.ram[off + i*4 + 2] = (stub[i] >> 16) & 0xFF;
        mem.ram[off + i*4 + 3] = (stub[i] >> 24) & 0xFF;
    }

    // Audit the write
    audit_write(g_cpu ? g_cpu->instructions : 0, addr, 0, stub[0], 4, "Bubblegum stub injection");
    printf("[BUBBLEGUM] Wrote 40-byte stub at 0x%08X (CD-ready flag + ChangeTh(0) via BIOS B:0x10)\n", addr);
}
