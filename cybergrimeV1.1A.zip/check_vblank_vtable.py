#!/usr/bin/env python3
"""
Check the VBlank handler vtable pointer at 0x800B6398 in both
Frankenstein and DW7 EXEs to see if it's properly initialized.
Also check all 97 diff locations to see if any are near 0x800B6398.
"""
import struct

def read_sector(disc, lba):
    return disc[lba * 2352 + 24: lba * 2352 + 24 + 2048]

def read_exe_from_disc(disc_path, exe_lba, exe_size):
    with open(disc_path, 'rb') as f:
        disc = f.read()
    exe = bytearray()
    sectors = (exe_size + 2047) // 2048
    for i in range(sectors):
        exe.extend(read_sector(disc, exe_lba + i))
    return bytes(exe[:exe_size])

DISC = r'c:\LuxAura\VoidWalkers_Project\DQLOSTTRANSLATION\dq4_phaseC_build1.bin'
exe = read_exe_from_disc(DISC, 24, 960948)
DW7_DISC = r'c:\LuxAura\VoidWalkers_Project\DQLOSTTRANSLATION\DW7D1\DW7D1.bin'
dw7_exe = read_exe_from_disc(DW7_DISC, 24, 675840)

LOAD_ADDR = 0x80017F00
EXE_HEADER = 0x800

def ram_to_file(ram):
    return ram - LOAD_ADDR + EXE_HEADER

def file_to_ram(foff):
    return foff - EXE_HEADER + LOAD_ADDR

# Key addresses to check
key_addrs = {
    0x800B6398: "VBlank handler vtable ptr",
    0x800B63D8: "VBlank counter",
    0x800B52A0: "Event flag ptr 1",
    0x800B52A4: "Event flag ptr 2",
    0x800B52A8: "Event flag ptr 3",
    0x800B52AC: "Counter value",
    0x800BCCC8: "BSS start",
    0x800BC700: "Hybrid tree start (Frank only)",
}

print("=== KEY MEMORY LOCATIONS IN EXE ===")
for addr, desc in key_addrs.items():
    foff = ram_to_file(addr)
    frank_val = struct.unpack_from('<I', exe, foff)[0] if foff + 4 <= len(exe) else None
    dw7_val = struct.unpack_from('<I', dw7_exe, foff)[0] if foff + 4 <= len(dw7_exe) else None
    print(f"  0x{addr:08X} (file 0x{foff:X}) {desc}:")
    if frank_val is not None:
        print(f"    Frank: 0x{frank_val:08X}")
    else:
        print(f"    Frank: <beyond EXE>")
    if dw7_val is not None:
        print(f"    DW7:   0x{dw7_val:08X}")
    else:
        print(f"    DW7:   <beyond EXE>")
    if frank_val and dw7_val and frank_val != dw7_val:
        print(f"    *** DIFFERENT ***")

# Check what the VBlank wait function at 0x800967F8 reads
# It reads [0x800B6398] then calls [that + 12]
vtable_ptr_foff = ram_to_file(0x800B6398)
vtable_ptr = struct.unpack_from('<I', exe, vtable_ptr_foff)[0]
print(f"\n=== VBLANK VTABLE CHAIN ===")
print(f"  0x800B6398 -> 0x{vtable_ptr:08X}")
if vtable_ptr != 0:
    vtable_foff = ram_to_file(vtable_ptr)
    if vtable_foff + 32 <= len(exe):
        print(f"  Vtable at 0x{vtable_ptr:08X} (file 0x{vtable_foff:X}):")
        for i in range(8):
            val = struct.unpack_from('<I', exe, vtable_foff + i*4)[0]
            print(f"    [{i}] 0x{val:08X}")
        # The function at vtable+12 is the VBlank wait function
        func_ptr = struct.unpack_from('<I', exe, vtable_foff + 12)[0]
        print(f"\n  Vtable+12 -> 0x{func_ptr:08X} (the actual VBlank wait function)")
        if func_ptr != 0:
            func_foff = ram_to_file(func_ptr)
            if func_foff + 32 <= len(exe):
                print(f"  Function code at 0x{func_ptr:08X}:")
                for i in range(8):
                    val = struct.unpack_from('<I', exe, func_foff + i*4)[0]
                    addr = func_ptr + i*4
                    print(f"    0x{addr:08X}: 0x{val:08X}")
    else:
        print(f"  Vtable at 0x{vtable_ptr:08X} is beyond Frank EXE (file 0x{vtable_foff:X})")
        # Check DW7
        if vtable_foff + 32 <= len(dw7_exe):
            print(f"  But within DW7 EXE:")
            for i in range(8):
                val = struct.unpack_from('<I', dw7_exe, vtable_foff + i*4)[0]
                print(f"    [{i}] 0x{val:08X}")

# Check the DW7 vtable too
dw7_vtable_ptr = struct.unpack_from('<I', dw7_exe, vtable_ptr_foff)[0]
print(f"\n=== DW7 VBLANK VTABLE CHAIN ===")
print(f"  0x800B6398 -> 0x{dw7_vtable_ptr:08X}")
if dw7_vtable_ptr != 0:
    dw7_vtable_foff = ram_to_file(dw7_vtable_ptr)
    if dw7_vtable_foff + 32 <= len(dw7_exe):
        print(f"  Vtable at 0x{dw7_vtable_ptr:08X} (file 0x{dw7_vtable_foff:X}):")
        for i in range(8):
            val = struct.unpack_from('<I', dw7_exe, dw7_vtable_foff + i*4)[0]
            print(f"    [{i}] 0x{val:08X}")

# Now check: is 0x800B6398 in the BSS range?
# Frank BSS: 0x800BCCC8 to 0x800E9E80
# DW7 BSS: 0x800BCC68 to 0x800E4980
print(f"\n=== BSS RANGE CHECK ===")
print(f"  0x800B6398 in Frank BSS (0x800BCCC8-0x800E9E80)? {'YES' if 0x800B6398 >= 0x800BCCC8 else 'NO'}")
print(f"  0x800B6398 in DW7 BSS (0x800BCC68-0x800E4980)? {'YES' if 0x800B6398 >= 0x800BCC68 else 'NO'}")

# Check all 97 diffs and see if any are near our key addresses
print(f"\n=== ALL 97 DIFFS — CHECK FOR KEY ADDRESS HITS ===")
key_ranges = [
    (0x800B6398, 0x800B63D8, "VBlank vtable/counter"),
    (0x800B52A0, 0x800B52B0, "Event flags"),
    (0x80096760, 0x80096800, "Stall function"),
    (0x800967F8, 0x80096830, "First VBlank wait"),
]
diff_count = 0
for foff in range(0x800, min(len(exe), len(dw7_exe)), 4):
    if foff + 4 > len(exe) or foff + 4 > len(dw7_exe):
        break
    fw = struct.unpack_from('<I', exe, foff)[0]
    dw = struct.unpack_from('<I', dw7_exe, foff)[0]
    if fw != dw:
        ram = file_to_ram(foff)
        diff_count += 1
        # Check if near any key address
        for start, end, desc in key_ranges:
            if start <= ram <= end:
                print(f"  *** DIFF at 0x{ram:08X} (file 0x{foff:X}) — {desc} ***")
                print(f"    Frank: 0x{fw:08X}")
                print(f"    DW7:   0x{dw:08X}")
        # Print first 20 and last 20 diffs
        if diff_count <= 20 or diff_count > 77:
            ram = file_to_ram(foff)
            print(f"  [{diff_count:3d}] 0x{ram:08X}: Frank=0x{fw:08X} DW7=0x{dw:08X}")
        elif diff_count == 21:
            print(f"  ... ({97-40} more diffs) ...")

print(f"\n  Total diffs: {diff_count}")

# Check the init function at 0x8004F344 more carefully
# The first call is jal 0x8008E2B8 which is jr ra; nop
# In DW7, what was at 0x8008E2B8?
print(f"\n=== INIT FIRST CALL (0x8008E2B8) ===")
foff = ram_to_file(0x8008E2B8)
for i in range(8):
    fw = struct.unpack_from('<I', exe, foff + i*4)[0]
    dw = struct.unpack_from('<I', dw7_exe, foff + i*4)[0] if foff + i*4 + 4 <= len(dw7_exe) else 0
    ram = 0x8008E2B8 + i*4
    marker = " *DIFF*" if fw != dw else ""
    print(f"  0x{ram:08X}: Frank=0x{fw:08X} DW7=0x{dw:08X}{marker}")

# Check 0x8008E2B0 — the bootstrap redirect point
print(f"\n=== BOOTSTRAP REDIRECT (0x8008E2B0) ===")
foff = ram_to_file(0x8008E2B0)
for i in range(8):
    fw = struct.unpack_from('<I', exe, foff + i*4)[0]
    dw = struct.unpack_from('<I', dw7_exe, foff + i*4 + 4)[0] if foff + i*4 + 4 <= len(dw7_exe) else 0
    ram = 0x8008E2B0 + i*4
    marker = " *DIFF*" if fw != dw else ""
    print(f"  0x{ram:08X}: Frank=0x{fw:08X} DW7=0x{dw:08X}{marker}")
