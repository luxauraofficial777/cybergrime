$log = 'C:\LuxAura\VoidWalkers_Project\DuckStation\duckstation.log'
$lines = Get-Content $log
Write-Host "=== Full CDROM activity from DQ4 native boot ==="
$cdromLines = $lines | Where-Object { $_ -match 'CDROM|Setmode|Setloc|ReadN|ReadS|DataSector|Pause|Demute|Init|Play' }
$cdromLines | ForEach-Object { Write-Output $_ }
