#!/usr/bin/env python3
"""Deep analysis of HBD location mechanism in DW7 EXE."""
import struct

exe_path = r'..\translation\SLUSP012.06_disc_extract.bin'
with open(exe_path, 'rb') as f:
    data = f.read()

LOAD_ADDR = 0x80017F00

def f2r(off):
    return LOAD_ADDR + off - 0x800

def r2f(ram):
    return ram - LOAD_ADDR + 0x800

def disasm_mips(insn):
    """Minimal MIPS disassembler for key instructions."""
    op = (insn >> 26) & 0x3F
    rs = (insn >> 21) & 0x1F
    rt = (insn >> 16) & 0x1F
    rd = (insn >> 11) & 0x1F
    shamt = (insn >> 6) & 0x1F
    funct = insn & 0x3F
    imm = insn & 0xFFFF
    simm = imm if imm < 0x8000 else imm - 0x10000
    target = insn & 0x3FFFFFF

    regs = ['zero','at','v0','v1','a0','a1','a2','a3',
            't0','t1','t2','t3','t4','t5','t6','t7',
            's0','s1','s2','s3','s4','s5','s6','s7',
            't8','t9','k0','k1','gp','sp','fp','ra']

    if op == 0:
        if funct == 0x08: return f"jr ${regs[rs]}"
        if funct == 0x09: return f"jalr ${regs[rd]}, ${regs[rs]}"
        if funct == 0x21: return f"addu ${regs[rd]}, ${regs[rs]}, ${regs[rt]}"
        if funct == 0x23: return f"subu ${regs[rd]}, ${regs[rs]}, ${regs[rt]}"
        if funct == 0x24: return f"and ${regs[rd]}, ${regs[rs]}, ${regs[rt]}"
        if funct == 0x25: return f"or ${regs[rd]}, ${regs[rs]}, ${regs[rt]}"
        if funct == 0x2A: return f"slt ${regs[rd]}, ${regs[rs]}, ${regs[rt]}"
        if funct == 0x00: return "nop" if insn == 0 else f"sll ${regs[rd]}, ${regs[rt]}, {shamt}"
        if funct == 0x03: return f"sra ${regs[rd]}, ${regs[rt]}, {shamt}"
        if funct == 0x0C: return f"syscall"
        return f".word 0x{insn:08X}"
    if op == 0x01:
        if rt == 0: return f"bltz ${regs[rs]}, {simm*4+4:#x}"
        if rt == 1: return f"bgez ${regs[rs]}, {simm*4+4:#x}"
        return f".word 0x{insn:08X}"
    if op == 0x02: return f"j 0x{(target<<2):08X}"
    if op == 0x03: return f"jal 0x{(target<<2):08X}"
    if op == 0x04: return f"beq ${regs[rs]}, ${regs[rt]}, {simm*4+4:#x}"
    if op == 0x05: return f"bne ${regs[rs]}, ${regs[rt]}, {simm*4+4:#x}"
    if op == 0x06: return f"blez ${regs[rs]}, {simm*4+4:#x}"
    if op == 0x07: return f"bgtz ${regs[rs]}, {simm*4+4:#x}"
    if op == 0x08: return f"addi ${regs[rt]}, ${regs[rs]}, {simm}"
    if op == 0x09: return f"addiu ${regs[rt]}, ${regs[rs]}, {simm}"
    if op == 0x0A: return f"slti ${regs[rt]}, ${regs[rs]}, {simm}"
    if op == 0x0B: return f"sltiu ${regs[rt]}, ${regs[rs]}, {simm}"
    if op == 0x0C: return f"andi ${regs[rt]}, ${regs[rs]}, 0x{imm:04X}"
    if op == 0x0D: return f"ori ${regs[rt]}, ${regs[rs]}, 0x{imm:04X}"
    if op == 0x0E: return f"xori ${regs[rt]}, ${regs[rs]}, 0x{imm:04X}"
    if op == 0x0F: return f"lui ${regs[rt]}, 0x{imm:04X}"
    if op == 0x20: return f"lb ${regs[rt]}, {simm}(${regs[rs]})"
    if op == 0x21: return f"lh ${regs[rt]}, {simm}(${regs[rs]})"
    if op == 0x23: return f"lw ${regs[rt]}, {simm}(${regs[rs]})"
    if op == 0x24: return f"lbu ${regs[rt]}, {simm}(${regs[rs]})"
    if op == 0x25: return f"lhu ${regs[rt]}, {simm}(${regs[rs]})"
    if op == 0x28: return f"sb ${regs[rt]}, {simm}(${regs[rs]})"
    if op == 0x29: return f"sh ${regs[rt]}, {simm}(${regs[rs]})"
    if op == 0x2B: return f"sw ${regs[rt]}, {simm}(${regs[rs]})"
    return f".word 0x{insn:08X}"

# 1. Dump the LBA table at 0x8001B9DC
print('=== LBA table at 0x8001B9DC ===')
base_off = r2f(0x8001B9DC)
for i in range(0, 80, 4):
    off = base_off + i
    if off + 4 <= len(data):
        val = struct.unpack('<I', data[off:off+4])[0]
        ram = f2r(off)
        # Check if it looks like LBA + pointer pairs
        print(f'  0x{ram:08X}: 0x{val:08X} ({val})')

# 2. Disassemble around the LBA 0x162 location
print('\n=== Disassembly around LBA 0x162 (0x8001B9E4) ===')
# Go back further to find the function that references this
start_off = r2f(0x8001B9C0)
for i in range(0, 120, 4):
    off = start_off + i
    if off + 4 <= len(data):
        insn = struct.unpack('<I', data[off:off+4])[0]
        ram = f2r(off)
        d = disasm_mips(insn)
        marker = ' <-- LBA 0x162' if ram == 0x8001B9E4 else ''
        print(f'  0x{ram:08X}: 0x{insn:08X}  {d}{marker}')

# 3. Search for code that loads from the LBA table address
print('\n=== Xrefs to LBA table region (0x8001B9D0-0x8001BA40) ===')
# Search for lui/addiu that loads addresses in 0x8001B9xx range
target_hi = 0x8001
for i in range(0x800, len(data) - 8, 4):
    insn = struct.unpack('<I', data[i:i+4])[0]
    if (insn >> 26) == 0x0F:  # lui
        imm = insn & 0xFFFF
        if imm == target_hi:
            reg = (insn >> 16) & 0x1F
            # Check next few instructions for addiu/lw with matching low bits
            for j in range(1, 6):
                if i + j*4 + 4 > len(data):
                    break
                next_insn = struct.unpack('<I', data[i+j*4:i+j*4+4])[0]
                if (next_insn >> 26) == 0x09:  # addiu
                    next_imm = next_insn & 0xFFFF
                    next_simm = next_imm if next_imm < 0x8000 else next_imm - 0x10000
                    addr = (imm << 16) + next_simm
                    if 0x8001B9C0 <= addr <= 0x8001BA60:
                        ram = f2r(i)
                        print(f'  lui ${reg}, 0x{imm:04X} + addiu 0x{next_imm:04X} = 0x{addr:08X} at 0x{ram:08X}')
                        # Show context
                        for k in range(0, 8):
                            off2 = i + k*4
                            if off2 + 4 <= len(data):
                                insn2 = struct.unpack('<I', data[off2:off2+4])[0]
                                r2 = f2r(off2)
                                print(f'    0x{r2:08X}: 0x{insn2:08X}  {disasm_mips(insn2)}')
                        print()
                        break

# 4. Check the MSF BCD hit at 0x80074754
print('\n=== Context around MSF BCD 00:04:36 at 0x80074754 ===')
msf_off = r2f(0x80074754)
for i in range(-32, 40, 4):
    off = msf_off + i
    if 0x800 <= off and off + 4 <= len(data):
        insn = struct.unpack('<I', data[off:off+4])[0]
        ram = f2r(off)
        d = disasm_mips(insn)
        # Also show as bytes
        b = data[off:off+4]
        marker = ' <-- MSF' if ram == 0x80074754 else ''
        print(f'  0x{ram:08X}: 0x{insn:08X}  {d}  [{b[0]:02X} {b[1]:02X} {b[2]:02X} {b[3]:02X}]{marker}')

# 5. Search for "cdrom file" string xref
print('\n=== "cdrom file" string at 0x80028F87 ===')
str_off = r2f(0x80028F87)
str_ram = 0x80028F87
# Search for lui/addiu to 0x80028Fxx
for i in range(0x800, len(data) - 8, 4):
    insn = struct.unpack('<I', data[i:i+4])[0]
    if (insn >> 26) == 0x0F:
        imm = insn & 0xFFFF
        if imm == 0x8002:
            reg = (insn >> 16) & 0x1F
            for j in range(1, 6):
                if i + j*4 + 4 > len(data):
                    break
                next_insn = struct.unpack('<I', data[i+j*4:i+j*4+4])[0]
                if (next_insn >> 26) == 0x09:
                    next_imm = next_insn & 0xFFFF
                    next_simm = next_imm if next_imm < 0x8000 else next_imm - 0x10000
                    addr = (imm << 16) + next_simm
                    if 0x80028F80 <= addr <= 0x80029030:
                        ram = f2r(i)
                        print(f'  xref to string at 0x{addr:08X} from 0x{ram:08X}')
                        for k in range(0, 12):
                            off2 = i + k*4
                            if off2 + 4 <= len(data):
                                insn2 = struct.unpack('<I', data[off2:off2+4])[0]
                                r2 = f2r(off2)
                                print(f'    0x{r2:08X}: 0x{insn2:08X}  {disasm_mips(insn2)}')
                        print()
                        break

# 6. Search for the open_thread string xref
print('\n=== "open_thread" string xref at 0x80029000 ===')
for i in range(0x800, len(data) - 8, 4):
    insn = struct.unpack('<I', data[i:i+4])[0]
    if (insn >> 26) == 0x0F:
        imm = insn & 0xFFFF
        if imm == 0x8002:
            reg = (insn >> 16) & 0x1F
            for j in range(1, 6):
                if i + j*4 + 4 > len(data):
                    break
                next_insn = struct.unpack('<I', data[i+j*4:i+j*4+4])[0]
                if (next_insn >> 26) == 0x09:
                    next_imm = next_insn & 0xFFFF
                    next_simm = next_imm if next_imm < 0x8000 else next_imm - 0x10000
                    addr = (imm << 16) + next_simm
                    if 0x80028FF0 <= addr <= 0x80029030:
                        ram = f2r(i)
                        print(f'  xref to open_thread string at 0x{addr:08X} from 0x{ram:08X}')
                        for k in range(0, 16):
                            off2 = i + k*4
                            if off2 + 4 <= len(data):
                                insn2 = struct.unpack('<I', data[off2:off2+4])[0]
                                r2 = f2r(off2)
                                print(f'    0x{r2:08X}: 0x{insn2:08X}  {disasm_mips(insn2)}')
                        print()
                        break

print('\n=== Done ===')
