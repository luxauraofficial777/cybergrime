#!/usr/bin/env python3
"""Verify trampoline bytes on disc and trace the full copy chain for v33."""
import struct

SECTOR_SIZE = 2352
USER_OFFSET = 24
USER_SIZE = 2048
EXE_LBA = 24
T_ADDR = 0x80017F00
T_SIZE = 0xA5000

def read_sector_user(f, lba):
    f.seek(lba * SECTOR_SIZE + USER_OFFSET)
    return f.read(USER_SIZE)

DISC = r'c:\LuxAura\VoidWalkers_Project\DQLOSTTRANSLATION\dq4_frankenstein_v33.bin'

with open(DISC, 'rb') as f:
    # Load full EXE
    exe = bytearray()
    total_sectors = (0x800 + T_SIZE + USER_SIZE - 1) // USER_SIZE
    for i in range(total_sectors):
        exe.extend(read_sector_user(f, EXE_LBA + i))
    exe = exe[:0x800 + T_SIZE]

    print(f"EXE file size: {len(exe)} bytes (0x{len(exe):X})")
    print(f"t_addr: 0x{T_ADDR:08X}, t_size: 0x{T_SIZE:X}")
    print(f"Load range: 0x{T_ADDR:08X} - 0x{T_ADDR + T_SIZE:08X}")
    
    # Tree starts at file offset = original_exe_size = 675840 (0xA5000)
    # But wait, original exe was 675840 bytes total (including 0x800 header)
    # So tree_file_off = 675840, tree_ram = T_ADDR + 675840 - 0x800 = 0x80017F00 + 675072 = 0x800BC700
    
    tree_file_off = 675840  # original exe size
    tree_ram = T_ADDR + tree_file_off - 0x800
    tree_size = 1480  # 0x5C8
    
    tramp_ram = (tree_ram + tree_size + 3) & ~3  # 0x800BCCC8
    tramp_file_off = tramp_ram - T_ADDR + 0x800
    
    copy_ram = tramp_ram + 40  # 10 instructions * 4 bytes
    copy_file_off = copy_ram - T_ADDR + 0x800
    
    print(f"\nTree on disc:     RAM 0x{tree_ram:08X} (file 0x{tree_file_off:05X})")
    print(f"Trampoline disc:  RAM 0x{tramp_ram:08X} (file 0x{tramp_file_off:05X})")
    print(f"Copy routine:     RAM 0x{copy_ram:08X} (file 0x{copy_file_off:05X})")
    
    # Verify tree data
    tree_data = exe[tree_file_off:tree_file_off + tree_size]
    print(f"\nTree data ({len(tree_data)} bytes):")
    print(f"  First 16 bytes: {tree_data[:16].hex()}")
    print(f"  Last 16 bytes:  {tree_data[-16:].hex()}")
    
    # Verify trampoline data
    tramp_data = exe[tramp_file_off:tramp_file_off + 40]
    print(f"\nTrampoline data (40 bytes, 10 instructions):")
    for i in range(10):
        w = struct.unpack_from('<I', tramp_data, i*4)[0]
        print(f"  [{i}] 0x{w:08X}")
    
    # Verify copy routine data
    copy_data = exe[copy_file_off:copy_file_off + 52]
    print(f"\nCopy routine data (52 bytes, 13 instructions):")
    for i in range(13):
        w = struct.unpack_from('<I', copy_data, i*4)[0]
        print(f"  [{i}] 0x{w:08X}")
    
    # Check what the trampoline should look like after copy
    tramp_target = (0x80100000 + tree_size + 3) & ~3
    print(f"\nTrampoline target RAM: 0x{tramp_target:08X}")
    print(f"  = 0x80100000 + {tree_size} + align = 0x{tramp_target:08X}")
    
    # Check CD-ROM intercept
    # Need to find CDROM_CMD_WRITE_OFF and CDROM_BRANCH_OFF
    # These are file offsets in the EXE
    print(f"\nLooking for j 0x{tramp_target:08X} instruction in EXE...")
    j_target = (tramp_target >> 2) & 0x3FFFFFF
    j_insn = (0x02 << 26) | j_target
    print(f"  Expected j instruction: 0x{j_insn:08X}")
    
    found = []
    for off in range(0x800, len(exe) - 3, 4):
        w = struct.unpack_from('<I', exe, off)[0]
        if w == j_insn:
            ram_addr = T_ADDR + off - 0x800
            found.append((off, ram_addr))
            print(f"  FOUND at file 0x{off:05X} (RAM 0x{ram_addr:08X})")
    
    if not found:
        print("  NOT FOUND! Checking if CDROM_CMD_WRITE_OFF has different value...")
        # Try searching for any j instruction to 0x801005C8
        for off in range(0x800, len(exe) - 3, 4):
            w = struct.unpack_from('<I', exe, off)[0]
            op = (w >> 26) & 0x3F
            if op == 0x02:  # j
                target = (w & 0x3FFFFFF) << 2
                target |= 0x80000000  # assume KSEG0
                if 0x80100000 <= target <= 0x80101000:
                    ram_addr = T_ADDR + off - 0x800
                    print(f"  j 0x{target:08X} at file 0x{off:05X} (RAM 0x{ram_addr:08X})")
    
    # Check what's at the trampoline target after copy
    # The copy routine copies from tree_ram (0x800BC700) to 0x80100000
    # The trampoline is at offset tree_size within the payload
    # So after copy, trampoline is at 0x80100000 + tree_size = 0x801005C8
    print(f"\nAfter copy, trampoline should be at 0x{0x80100000 + tree_size:08X}")
    print(f"  Trampoline bytes: {tramp_data.hex()}")
    
    # Check if there's an issue with the payload_size
    payload_size = (tramp_ram + 40) - tree_ram
    print(f"\nPayload size: {payload_size} bytes (0x{payload_size:X})")
    print(f"  Copy routine copies {payload_size} bytes from 0x{tree_ram:08X} to 0x80100000")
    print(f"  Tree: {tree_size} bytes at 0x80100000-0x{0x80100000 + tree_size:08X}")
    print(f"  Tramp: 40 bytes at 0x{0x80100000 + tree_size:08X}-0x{0x80100000 + tree_size + 40:08X}")
    
    # Check if 0x801005C8 is within the copied range
    tramp_end = 0x80100000 + payload_size
    print(f"  Copied range: 0x80100000 - 0x{tramp_end:08X}")
    print(f"  0x801005C8 in range? {0x80100000 <= 0x801005C8 < tramp_end}")
    
    # Check PC0 in header
    pc0 = struct.unpack_from('<I', exe, 0x10)[0]
    print(f"\nPC0 in header: 0x{pc0:08X}")
    print(f"  Should be copy routine: 0x{copy_ram:08X}")
    print(f"  Match: {pc0 == copy_ram}")
