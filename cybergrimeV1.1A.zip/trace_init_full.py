#!/usr/bin/env python3
"""
Trace the full init path from PC0 (0x8008E284) through BSS clear
to the bootstrap redirect at 0x8008E2B0, then into the bootstrap
at 0x8004F344, to understand why VBlank never fires.
"""
import struct

def read_sector(disc, lba):
    return disc[lba * 2352 + 24: lba * 2352 + 24 + 2048]

def read_exe_from_disc(disc_path, exe_lba, exe_size):
    with open(disc_path, 'rb') as f:
        disc = f.read()
    exe = bytearray()
    sectors = (exe_size + 2047) // 2048
    for i in range(sectors):
        exe.extend(read_sector(disc, exe_lba + i))
    return bytes(exe[:exe_size])

DISC = r'c:\LuxAura\VoidWalkers_Project\DQLOSTTRANSLATION\dq4_phaseC_build1.bin'
exe = read_exe_from_disc(DISC, 24, 960948)
DW7_DISC = r'c:\LuxAura\VoidWalkers_Project\DQLOSTTRANSLATION\DW7D1\DW7D1.bin'
dw7_exe = read_exe_from_disc(DW7_DISC, 24, 675840)

LOAD_ADDR = 0x80017F00
EXE_HEADER = 0x800

def ram_to_file(ram):
    return ram - LOAD_ADDR + EXE_HEADER

def read_word(exe_data, ram):
    foff = ram_to_file(ram)
    if foff + 4 <= len(exe_data):
        return struct.unpack_from('<I', exe_data, foff)[0]
    return None

# Simple MIPS disassembler
def disasm(word, pc):
    if word == 0:
        return "nop"
    op = (word >> 26) & 0x3F
    rs = (word >> 21) & 0x1F
    rt = (word >> 16) & 0x1F
    rd = (word >> 11) & 0x1F
    shamt = (word >> 6) & 0x1F
    funct = word & 0x3F
    imm = word & 0xFFFF
    target = word & 0x03FFFFFF
    regs = ['zero','at','v0','v1','a0','a1','a2','a3',
            't0','t1','t2','t3','t4','t5','t6','t7',
            's0','s1','s2','s3','s4','s5','s6','s7',
            't8','t9','k0','k1','gp','sp','fp','ra']

    if op == 0:
        if funct == 0x08: return f"jr {regs[rs]}"
        if funct == 0x09: return f"jalr {regs[rd]}, {regs[rs]}"
        if funct == 0x20: return f"add {regs[rd]}, {regs[rs]}, {regs[rt]}"
        if funct == 0x21: return f"addu {regs[rd]}, {regs[rs]}, {regs[rt]}"
        if funct == 0x23: return f"subu {regs[rd]}, {regs[rs]}, {regs[rt]}"
        if funct == 0x24: return f"and {regs[rd]}, {regs[rs]}, {regs[rt]}"
        if funct == 0x25: return f"or {regs[rd]}, {regs[rs]}, {regs[rt]}"
        if funct == 0x2A: return f"slt {regs[rd]}, {regs[rs]}, {regs[rt]}"
        if funct == 0x2B: return f"sltu {regs[rd]}, {regs[rs]}, {regs[rt]}"
        if funct == 0x00: return f"sll {regs[rd]}, {regs[rt]}, {shamt}"
        if funct == 0x02: return f"srl {regs[rd]}, {regs[rt]}, {shamt}"
        if funct == 0x03: return f"sra {regs[rd]}, {regs[rt]}, {shamt}"
        if funct == 0x04: return f"sllv {regs[rd]}, {regs[rt]}, {regs[rs]}"
        if funct == 0x06: return f"srlv {regs[rd]}, {regs[rt]}, {regs[rs]}"
        if funct == 0x0C: return f"syscall"
        return f"special 0x{funct:02X}"
    if op == 0x01:
        if rt == 0: return f"bltz {regs[rs]}, 0x{pc + 4 + (imm << 2):08X}"
        if rt == 1: return f"bgez {regs[rs]}, 0x{pc + 4 + (imm << 2):08X}"
        return f"regimm {rt}"
    if op == 0x02: return f"j 0x{(pc & 0xF0000000) | (target << 2):08X}"
    if op == 0x03: return f"jal 0x{(pc & 0xF0000000) | (target << 2):08X}"
    if op == 0x04: return f"beq {regs[rs]}, {regs[rt]}, 0x{pc + 4 + (imm << 2):08X}"
    if op == 0x05: return f"bne {regs[rs]}, {regs[rt]}, 0x{pc + 4 + (imm << 2):08X}"
    if op == 0x06: return f"blez {regs[rs]}, 0x{pc + 4 + (imm << 2):08X}"
    if op == 0x07: return f"bgtz {regs[rs]}, 0x{pc + 4 + (imm << 2):08X}"
    if op == 0x08: return f"addi {regs[rt]}, {regs[rs]}, {imm}"
    if op == 0x09: return f"addiu {regs[rt]}, {regs[rs]}, {imm}"
    if op == 0x0A: return f"slti {regs[rt]}, {regs[rs]}, {imm}"
    if op == 0x0B: return f"sltiu {regs[rt]}, {regs[rs]}, {imm}"
    if op == 0x0C: return f"andi {regs[rt]}, {regs[rs]}, 0x{imm:04X}"
    if op == 0x0D: return f"ori {regs[rt]}, {regs[rs]}, 0x{imm:04X}"
    if op == 0x0E: return f"xori {regs[rt]}, {regs[rs]}, 0x{imm:04X}"
    if op == 0x0F: return f"lui {regs[rt]}, 0x{imm:04X}"
    if op == 0x20: return f"lb {regs[rt]}, {imm}({regs[rs]})"
    if op == 0x21: return f"lh {regs[rt]}, {imm}({regs[rs]})"
    if op == 0x23: return f"lw {regs[rt]}, {imm}({regs[rs]})"
    if op == 0x24: return f"lbu {regs[rt]}, {imm}({regs[rs]})"
    if op == 0x25: return f"lhu {regs[rt]}, {imm}({regs[rs]})"
    if op == 0x28: return f"sb {regs[rt]}, {imm}({regs[rs]})"
    if op == 0x29: return f"sh {regs[rt]}, {imm}({regs[rs]})"
    if op == 0x2B: return f"sw {regs[rt]}, {imm}({regs[rs]})"
    return f"op=0x{op:02X} word=0x{word:08X}"

def disasm_range(exe_data, start_ram, count, label=""):
    print(f"\n{'=' * 70}")
    if label:
        print(f"{label}")
        print(f"{'=' * 70}")
    for i in range(count):
        ram = start_ram + i * 4
        w = read_word(exe_data, ram)
        if w is None:
            print(f"  0x{ram:08X}: <beyond EXE>")
            break
        d = disasm(w, ram)
        print(f"  0x{ram:08X}: 0x{w:08X}  {d}")

# 1. PC0 entry point: BSS clear
disasm_range(exe, 0x8008E284, 16, "PC0 ENTRY (0x8008E284) — BSS CLEAR")

# 2. What's after BSS clear? Follow to 0x8008E2B0
disasm_range(exe, 0x8008E2A0, 24, "POST BSS CLEAR → BOOTSTRAP REDIRECT (0x8008E2A0)")

# 3. DW7 same area for comparison
disasm_range(dw7_exe, 0x8008E284, 16, "DW7 PC0 ENTRY (0x8008E284) — BSS CLEAR")
disasm_range(dw7_exe, 0x8008E2A0, 24, "DW7 POST BSS CLEAR (0x8008E2A0)")

# 4. Bootstrap at 0x8004F344
disasm_range(exe, 0x8004F344, 64, "BOOTSTRAP INIT (0x8004F344)")

# 5. DW7 same area — what's there in DW7?
disasm_range(dw7_exe, 0x8004F344, 32, "DW7 SAME AREA (0x8004F344) — for comparison")

# 6. VBlank wait function at 0x800967F8
disasm_range(exe, 0x800967F8, 32, "VBLANK WAIT (0x800967F8)")

# 7. VBlank wait target at 0x8009698C
disasm_range(exe, 0x8009698C, 48, "VBLANK WAIT TARGET (0x8009698C)")

# 8. Check what's at 0x800B5310 (the flag checked by 0x8009698C)
val_5310 = read_word(exe, 0x800B5310)
val_5310_dw7 = read_word(dw7_exe, 0x800B5310)
print(f"\n=== FLAG AT 0x800B5310 ===")
print(f"  Frank: 0x{val_5310:08X}" if val_5310 is not None else "  Frank: <beyond EXE>")
print(f"  DW7:   0x{val_5310_dw7:08X}" if val_5310_dw7 is not None else "  DW7:   <beyond EXE>")

# 9. Check what's at 0x800B5310 in more detail (it's a half-word read)
foff = ram_to_file(0x800B5310)
print(f"  File offset: 0x{foff:X}")
if foff + 16 <= len(exe):
    for i in range(4):
        w = struct.unpack_from('<I', exe, foff + i*4)[0]
        print(f"    0x{0x800B5310 + i*4:08X}: 0x{w:08X}")

# 10. Check what calls 0x8008E2B0 — search for jal 0x8008E2B0
print(f"\n=== SEARCH FOR CALLERS OF 0x8008E2B0 ===")
target_word = 0x0C0238AC  # jal 0x8008E2B0: op=3, target = 0x8008E2B0 >> 2 = 0x020238AC
# Actually: jal target = (0x8008E2B0 & 0x0FFFFFFF) >> 2 = 0x008E2B0 >> 2 = 0x00238AC
# So jal 0x8008E2B0 = 0x0C00238AC... wait
# jal: op=000011, target = (addr & 0x0FFFFFFF) >> 2
# 0x8008E2B0 >> 2 = 0x00238AC
# So the word = (0x03 << 26) | 0x00238AC = 0x0C00238AC... no
# (3 << 26) = 0x0C000000
# 0x0C000000 | 0x00238AC = 0x0C00238AC
# But that's 9 hex digits... 0x0C00238AC is 9 digits = 0x0C00238AC
# Wait, target is 26 bits. 0x8008E2B0 >> 2 = 0x200238AC... no
# 0x8008E2B0 in binary: 1000 0000 0000 1000 1110 0010 1011 0000
# >> 2: 0010 0000 0000 0010 0011 1000 1010 1100 = 0x200238AC
# But target is only 26 bits, so: 0x200238AC & 0x03FFFFFF = 0x000238AC
# So jal word = (3 << 26) | 0x000238AC = 0x0C00238AC... that's 0x0C00238AC
# Hmm, 0x0C000000 | 0x00238AC = 0x0C00238AC
# But that's only 28 bits. The full 32-bit word is 0x0C00238AC... no, that's 9 hex digits.
# Let me recalculate: 0x0C000000 = 0000 1100 0000 0000 0000 0000 0000 0000
# 0x00238AC = 0000 0000 0000 0010 0011 1000 1010 1100
# OR: 0000 1100 0000 0000 0010 0011 1000 1010 1100
# That's 0x0C00238AC which is 33 bits... wrong.
# Wait, 0x0C000000 is 0000 1100 0000 0000 0000 0000 0000 0000 (32 bits)
# 0x00238AC is 0000 0000 0000 0000 0010 0011 1000 1010 1100 (29 bits)
# No, 0x00238AC = 0x000238AC = 0000 0000 0000 0010 0011 1000 1010 1100 (32 bits)
# OR: 0000 1100 0000 0000 0010 0011 1000 1010 1100 = 0x0C00238AC
# That's 36 bits... something is wrong.
# Let me just compute: 3 * 2^26 = 3 * 67108864 = 201326592 = 0x0C000000
# 0x8008E2B0 >> 2 = 0x200238AC (but we only take 26 bits)
# 0x200238AC & 0x03FFFFFF = 0x000238AC
# So: 0x0C000000 | 0x000238AC = 0x0C00238AC
# But 0x0C00238AC is 0x0C00238AC... let me check: 0x0C000000 + 0x238AC = 0x0C0238AC
# Yes! 0x0C0238AC (8 hex digits = 32 bits)
target_word = 0x0C0238AC
print(f"  Searching for jal 0x8008E2B0 = 0x{target_word:08X}")
for foff in range(0x800, len(exe) - 4, 4):
    w = struct.unpack_from('<I', exe, foff)[0]
    if w == target_word:
        ram = foff - EXE_HEADER + LOAD_ADDR
        print(f"  Found at 0x{ram:08X} (file 0x{foff:X})")
        # Show context
        for j in range(-2, 4):
            ctx_ram = ram + j * 4
            ctx_w = read_word(exe, ctx_ram)
            if ctx_w is not None:
                marker = " <<<" if j == 0 else ""
                print(f"    0x{ctx_ram:08X}: 0x{ctx_w:08X}  {disasm(ctx_w, ctx_ram)}{marker}")

# Also search in DW7
print(f"\n  DW7:")
for foff in range(0x800, len(dw7_exe) - 4, 4):
    w = struct.unpack_from('<I', dw7_exe, foff)[0]
    if w == target_word:
        ram = foff - EXE_HEADER + LOAD_ADDR
        print(f"  Found at 0x{ram:08X} (file 0x{foff:X})")
        for j in range(-2, 4):
            ctx_ram = ram + j * 4
            ctx_w = read_word(dw7_exe, ctx_ram)
            if ctx_w is not None:
                marker = " <<<" if j == 0 else ""
                print(f"    0x{ctx_ram:08X}: 0x{ctx_w:08X}  {disasm(ctx_w, ctx_ram)}{marker}")
