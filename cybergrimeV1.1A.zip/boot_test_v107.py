"""Phase 1 boot test: launch DuckStation headless, capture stdout, kill after 30s."""
import subprocess, time, sys, os, threading, struct

PYTHON = r'C:\Users\XFO777\AppData\Local\hermes\hermes-agent\venv\Scripts\python.exe'
DS_EXE = r'c:\LuxAura\VoidWalkers_Project\DQLOSTTRANSLATION\duckstation\duckstation-qt-x64-ReleaseLTCG.exe'
CUE    = r'c:\LuxAura\VoidWalkers_Project\DQLOSTTRANSLATION\build_staging\dq4_frankenstein_v107.cue'
LOG    = r'c:\LuxAura\VoidWalkers_Project\DQLOSTTRANSLATION\build_staging\v107_boot.log'
PORTABLE = r'c:\LuxAura\VoidWalkers_Project\DQLOSTTRANSLATION\duckstation'

env = os.environ.copy()
env["SDL_RAWINPUT"] = "0"

print(f"Launching DuckStation headless for v107...")
proc = subprocess.Popen(
    [DS_EXE, "-earlyconsole", "-fastboot", "-noshadercache", CUE],
    env=env,
    stdout=subprocess.PIPE,
    stderr=subprocess.STDOUT,
    creationflags=subprocess.CREATE_NEW_PROCESS_GROUP,
    cwd=PORTABLE
)
print(f"  PID: {proc.pid}")

lines = []
def reader():
    with open(LOG, 'w', encoding='utf-8', errors='replace') as f:
        while True:
            line = proc.stdout.readline()
            if not line:
                if proc.poll() is not None:
                    break
                time.sleep(0.01)
                continue
            text = line.decode('utf-8', errors='replace').rstrip('\n\r')
            f.write(text + '\n')
            f.flush()
            lines.append(text)

t = threading.Thread(target=reader, daemon=True)
t.start()

print("Waiting 30 seconds...")
time.sleep(30)

if proc.poll() is not None:
    print(f"DuckStation exited early: code={proc.returncode}")
else:
    print("Killing DuckStation...")
    proc.terminate()
    try:
        proc.wait(timeout=5)
    except:
        proc.kill()
        proc.wait()

t.join(timeout=5)

print(f"\n=== Log Analysis ({len(lines)} lines) ===")
for line in lines:
    low = line.lower()
    for kw in ['bios', 'boot path', 'executable', 'ram size', 'memory window',
               'datasector', 'cannot fast boot', 'incompatible', 'fps',
               'cdrom', 'sector', 'xa', 'hbd', 'vblank']:
        if kw in low:
            print(f"  {line}")
            break

ds_count = sum(1 for l in lines if 'DataSector' in l)
print(f"\nDataSector reads: {ds_count}")

ds_lines = [l for l in lines if 'DataSector' in l]
if ds_lines:
    print(f"First 10:")
    for l in ds_lines[:10]:
        print(f"  {l}")
    print(f"Last 10:")
    for l in ds_lines[-10:]:
        print(f"  {l}")

print(f"\nLast 20 log lines:")
for l in lines[-20:]:
    print(f"  {l}")
