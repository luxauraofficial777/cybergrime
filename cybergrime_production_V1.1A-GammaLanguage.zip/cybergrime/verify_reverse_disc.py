#!/usr/bin/env python3
"""verify_reverse_disc.py -- Post-build on-disc verifier for dq4_reverse.bin.

Validates the WRITTEN disc image directly (not the in-memory build image),
using correct MODE2 sector deinterleaving (2048-byte user data at sector+24).

Usage:
    python verify_reverse_disc.py <disc.bin> [--exe-lba 24] [--blob thread_code_blob.bin]
                                   [--tree frozen/dw7_hybrid_tree.bin]

Exit code 0 = all critical checks pass, 1 = failures, 2 = usage/IO error.
Run this after every frankenstein_build reverse build, BEFORE emulator testing.
"""
import struct
import sys

SECTOR = 2352
USER = 2048
LOAD_ADDR = 0x80017F00

PASS, FAIL, WARN = "PASS", "FAIL", "WARN"
results = []


def report(status, name, detail=""):
    results.append((status, name, detail))
    print(f"  [{status}] {name}" + (f" -- {detail}" if detail else ""))


def read_sector(f, lba):
    f.seek(lba * SECTOR + 24)
    return f.read(USER)


def read_file_region(f, lba, size):
    """Read a contiguous file stored at `lba`, deinterleaving MODE2 sectors."""
    out = bytearray()
    n = (size + USER - 1) // USER
    for s in range(n):
        out += read_sector(f, lba + s)
    return bytes(out[:size])


def u32(b, off):
    return struct.unpack_from("<I", b, off)[0]


def main():
    args = sys.argv[1:]
    if not args:
        print(__doc__)
        return 2
    bin_path = args[0]
    exe_lba = 24
    blob_path = None
    tree_path = None
    i = 1
    while i < len(args):
        if args[i] == "--exe-lba" and i + 1 < len(args):
            exe_lba = int(args[i + 1], 0); i += 2
        elif args[i] == "--blob" and i + 1 < len(args):
            blob_path = args[i + 1]; i += 2
        elif args[i] == "--tree" and i + 1 < len(args):
            tree_path = args[i + 1]; i += 2
        else:
            i += 1

    try:
        f = open(bin_path, "rb")
    except OSError as e:
        print(f"ERROR: cannot open {bin_path}: {e}")
        return 2

    print(f"Verifying {bin_path} (EXE LBA {exe_lba})")

    # ---- EXE header (sector 0 of file = first 2048 bytes) ----
    hdr = read_sector(f, exe_lba)
    if hdr[:8] != b"PS-X EXE":
        report(FAIL, "EXE magic", hdr[:8].hex())
        return 1
    pc0, t0, t_size = u32(hdr, 0x10), u32(hdr, 0x14), u32(hdr, 0x1C)
    load = u32(hdr, 0x18)
    report(PASS if load == LOAD_ADDR else FAIL, "load addr", f"0x{load:08X}")

    exe_len = 0x800 + t_size + 0x800  # header + text + slack for payload checks
    exe = read_file_region(f, exe_lba, exe_len)

    # ---- PC0 sanity ----
    if LOAD_ADDR <= pc0 < LOAD_ADDR + t_size:
        report(PASS, "PC0 in text range", f"PC0=0x{pc0:08X} text=0x{t_size:X}")
    else:
        report(FAIL, "PC0 in text range",
               f"PC0=0x{pc0:08X} outside [0x{LOAD_ADDR:08X}, 0x{LOAD_ADDR + t_size:08X})")

    # ---- Stub at PC0 (BSS gap fix: zero-fill first, then blob copy) ----
    # Layout: w[0..3] = zero-fill range, w[4..7] = zero loop, w[8..11] = blob copy src/dst
    stub_off = pc0 - LOAD_ADDR + 0x800
    if 0x800 <= stub_off <= len(exe) - 48:
        w = [u32(exe, stub_off + 4 * k) for k in range(12)]
        ok = (w[0] & 0xFFFF0000) == 0x3C080000 and (w[2] & 0xFFFF0000) == 0x3C090000
        report(PASS if ok else FAIL, "boot stub signature",
               " ".join(f"{x:08X}" for x in w[:4]))
        if ok:
            zst = ((w[0] & 0xFFFF) << 16) + struct.unpack("<h", struct.pack("<H", w[1] & 0xFFFF))[0]
            zen = ((w[2] & 0xFFFF) << 16) + struct.unpack("<h", struct.pack("<H", w[3] & 0xFFFF))[0]
            if zst == 0x800C9E80:
                report(PASS, "stub zero-fill start", f"0x{zst:08X}")
            else:
                report(WARN, "stub zero-fill start", f"0x{zst:08X} (expected 0x800C9E80)")
            if zen == 0x800F4980:
                report(PASS, "stub zero-fill end", f"0x{zen:08X}")
            else:
                report(WARN, "stub zero-fill end", f"0x{zen:08X} (expected 0x800F4980)")
            # Blob copy is at w[8..11] (after zero-fill loop at w[4..7])
            src = ((w[8] & 0xFFFF) << 16) + struct.unpack("<h", struct.pack("<H", w[9] & 0xFFFF))[0]
            dst = ((w[10] & 0xFFFF) << 16) + struct.unpack("<h", struct.pack("<H", w[11] & 0xFFFF))[0]
            if dst == 0x800D9E80:
                report(PASS, "stub blob dest", f"0x{dst:08X}")
            else:
                report(WARN, "stub blob dest", f"0x{dst:08X} (expected 0x800D9E80)")
            blob_off = src - LOAD_ADDR + 0x800
            if blob_path:
                try:
                    blob = open(blob_path, "rb").read()
                    got = exe[blob_off:blob_off + min(len(blob), 64)]
                    report(PASS if got == blob[:len(got)] else FAIL,
                           "thread blob content", f"@file 0x{blob_off:X}")
                except OSError:
                    report(WARN, "thread blob content", f"cannot read {blob_path}")
            else:
                first = u32(exe, blob_off)
                report(PASS if first == 0x27BDFF00 else WARN, "thread blob present",
                       f"first word 0x{first:08X} @file 0x{blob_off:X} (pass --blob for full check)")
    else:
        report(FAIL, "boot stub signature", f"stub off 0x{stub_off:X} out of range")

    # ---- Tree at 0xA5000 ----
    tree = exe[0xA5000:0xA5000 + 1480]
    first5 = struct.unpack_from("<5H", tree, 0)
    ok = first5 == (0x8002, 0x8004, 0x8006, 0x8008, 0x800A)
    report(PASS if ok else FAIL, "hybrid tree header", " ".join(f"{x:04X}" for x in first5))
    if tree_path:
        try:
            ref = open(tree_path, "rb").read()
            same = tree[:len(ref)] == ref[:len(tree)]
            report(PASS if same else WARN, "tree == reference",
                   f"{tree_path} ({'identical' if same else 'DIFFERS -- see audit F8'})")
        except OSError:
            report(WARN, "tree == reference", f"cannot read {tree_path}")

    # ---- Tree pointer variable ----
    tv = u32(exe, 0xA4FF8)
    report(PASS if tv == 0x800BC702 else FAIL, "tree ptr var @0x800BC6F8", f"0x{tv:08X}")

    # ---- Decomp T5/T6 ----
    t5 = u32(exe, 0x572A4)
    report(PASS if (t5 & 0xFFFF) == 0xC702 else FAIL, "decomp T5 (+2)", f"0x{t5:08X}")
    t6 = u32(exe, 0x1AFB8)
    report(PASS if t6 == 0 else FAIL, "decomp T6 (nop)", f"0x{t6:08X}")

    # ---- BSS narrow (start addiu at 0x76B88 -> imm 0xD100 = 0x800BD100) ----
    b = u32(exe, 0x76B88)
    report(PASS if (b & 0xFFFF) == 0xD100 else FAIL, "BSS narrow start", f"0x{b:08X}")

    # ---- Disc check patch site 0 ----
    dc = u32(exe, 0x6192C)
    report(PASS if dc == 0x24020001 else FAIL, "disc-check dc[0]", f"0x{dc:08X}")

    # ---- HBD string ----
    s = exe[0xF600:0xF60C]
    report(PASS if s == b"hbd1ps1d.q41" else FAIL, "HBD string q41", s.decode("ascii", "replace"))

    # ---- CD-ROM dispatch: original vs intercept ----
    d0, d1 = u32(exe, 0x80F08), u32(exe, 0x80F0C)
    if (d0, d1) == (0xA0400000, 0x24620100):
        report(PASS, "CD dispatch", "original (intercept absent)")
    elif (d0 >> 26) == 0x03:  # JAL
        tgt = 0x80000000 | ((d0 & 0x03FFFFFF) << 2)
        toff = tgt - LOAD_ADDR + 0x800
        sig = exe[toff:toff + 8] if 0x800 <= toff < len(exe) - 8 else b""
        ok = sig[:4] in (struct.pack("<I", 0xA0400000),) or struct.unpack_from("<I", sig + b"\0" * 4, 4)[0] == 0x24090002
        report(PASS if ok else FAIL, "CD dispatch intercept",
               f"JAL 0x{tgt:08X}, trampoline {'present' if ok else 'MISSING'}")
    else:
        report(FAIL, "CD dispatch", f"unexpected {d0:08X} {d1:08X}")

    # ---- HBD type trampoline signature ----
    found = False
    for off in range(0xA5000, len(exe) - 8, 4):
        if u32(exe, off) == 0x240A0027 and u32(exe, off + 4) == 0x126A0014:
            found = True
            break
    report(PASS if found else WARN, "HBD type trampoline", "present" if found else "not found")

    # ---- FMV BCD ----
    bcd = exe[0x92936:0x92939]
    if bcd == bytes([0x23, 0x31, 0x15]):
        report(PASS, "FMV BCD", "patched 23:31:15")
    elif bcd == bytes([0x32, 0x34, 0x71]):
        report(WARN, "FMV BCD", "original 32:34:71 (step 11b not applied)")
    else:
        report(FAIL, "FMV BCD", bcd.hex())

    # ---- SYSTEM.CNF (LBA 23) ----
    cnf = read_sector(f, 23)
    report(PASS if b"SLUSP012.06" in cnf else FAIL, "SYSTEM.CNF boot",
           cnf[:48].split(b"\r")[0].split(b"\n")[0].decode("ascii", "replace"))

    # ---- License sector (LBA 4) ----
    lic = read_sector(f, 4)
    lic_norm = lic.replace(b" ", b"")  # license text has irregular spacing ("Amer  ica")
    is_us = b"America" in lic_norm
    report(PASS if is_us else FAIL, "license region",
           "NTSC-U" if is_us else lic[:48].decode("ascii", "replace"))

    # ---- PVD volume ID (LBA 16) ----
    pvd = read_sector(f, 16)
    volid = pvd[40:72].decode("ascii", "replace").rstrip()
    report(PASS if volid.startswith("DRAGONWARRIOR7_1") else WARN, "PVD volid", volid)

    # ---- ISO dir EXE entry (search root dir sectors for SLUSP012.06;1) ----
    found = False
    for lba in range(20, 25):
        sec = read_sector(f, lba)
        pos = sec.find(b"SLUSP012.06;1")
        if pos >= 33:
            rec = pos - 33  # name field starts 33 bytes into the record
            f_lba = u32(sec, rec + 2)
            f_size = u32(sec, rec + 10)
            report(PASS if f_lba == exe_lba else FAIL, "ISO dir EXE entry",
                   f"LBA {f_lba} size {f_size} (dir sector {lba})")
            found = True
            break
    if not found:
        report(FAIL, "ISO dir EXE entry", "SLUSP012.06;1 not found in root dir")

    f.close()
    fails = sum(1 for r in results if r[0] == FAIL)
    warns = sum(1 for r in results if r[0] == WARN)
    print(f"\n{len(results)} checks: {len(results) - fails - warns} PASS, {warns} WARN, {fails} FAIL")
    print("ALL CHECKS PASS" if fails == 0 else "BUILD REJECTED -- fix FAIL items before emulator test")
    return 0 if fails == 0 else 1


if __name__ == "__main__":
    sys.exit(main())
