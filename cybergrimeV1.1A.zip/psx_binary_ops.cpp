#include "psx_binary_ops.h"
#include <cstdarg>
#include "psx_reference_integrations.h"
#include <algorithm>
#include <stdexcept>
#include <cstdlib>
#include <cstdio>
#include <string>
#include <set>
#include <filesystem>

#if defined(_MSC_VER)
#include <intrin.h>
#include <direct.h>
#pragma intrinsic(_byteswap_ulong)
#elif defined(__MINGW32__) || defined(__MINGW64__)
#include <direct.h>
#include <unistd.h>
#else
#include <unistd.h>
#endif

// ===== IsoImage =====
bool IsoImage::open(const char* path){
    file.open(path,std::ios::in|std::ios::out|std::ios::binary);
    if(!file.is_open())return false;
    file.seekg(0,std::ios::end);
    auto sz=file.tellg();
    if(sz%SECTOR_SIZE==0&&sz%USER_SIZE!=0){sector_sz=SECTOR_SIZE;data_off=USER_OFFSET;}
    else if(sz%USER_SIZE==0){sector_sz=USER_SIZE;data_off=0;}
    else{sector_sz=SECTOR_SIZE;data_off=USER_OFFSET;}
    return true;
}
void IsoImage::close(){if(file.is_open())file.close();}
int IsoImage::read_sector(uint32_t lba,void* buf2048){
    if(!file.is_open())return -1;
    file.clear();
    file.seekg((uint64_t)lba*sector_sz+data_off);
    file.read((char*)buf2048,USER_SIZE);
    return file.gcount()==USER_SIZE?0:-2;
}
int IsoImage::write_sector(uint32_t lba,const void* buf2048){
    if(!file.is_open())return -1;
    file.clear();
    if(sector_sz==USER_SIZE){
        file.seekp((uint64_t)lba*USER_SIZE);
        file.write((const char*)buf2048,USER_SIZE);
    }else{
        std::vector<uint8_t> sec(SECTOR_SIZE);
        file.seekg((uint64_t)lba*SECTOR_SIZE);
        file.read((char*)sec.data(),SECTOR_SIZE);
        file.clear();
        std::memcpy(sec.data()+USER_OFFSET,buf2048,USER_SIZE);
        file.seekp((uint64_t)lba*SECTOR_SIZE);
        file.write((const char*)sec.data(),SECTOR_SIZE);
    }
    return file.good()?0:-2;
}
int IsoImage::read_range(uint32_t lba,uint32_t count,void* buf){
    uint8_t* p=(uint8_t*)buf;
    for(uint32_t i=0;i<count;i++){
        if(read_sector(lba+i,p)<0)return -1;
        p+=USER_SIZE;
    }
    return 0;
}
uint32_t IsoImage::file_size()const{
    auto&f=const_cast<std::fstream&>(file);
    f.seekg(0,std::ios::end);
    return(uint32_t)f.tellg();
}

// ===== ExePatcher =====
bool ExePatcher::load(const uint8_t* buf,uint32_t sz){
    if(sz<0x800)return false;
    data.assign(buf,buf+sz);
    load_addr=*(uint32_t*)(data.data()+0x18);
    text_sz=*(uint32_t*)(data.data()+0x1C);
    pc0_val=*(uint32_t*)(data.data()+0x10);
    return true;
}
uint32_t ExePatcher::ram_to_offset(uint32_t ram)const{
    return ram-load_addr+0x800;
}
uint32_t ExePatcher::read32(uint32_t ram)const{
    uint32_t off=ram_to_offset(ram);
    if(off+4>data.size())return 0;
    uint32_t v;std::memcpy(&v,data.data()+off,4);return v;
}
void ExePatcher::write32(uint32_t ram,uint32_t val){
    uint32_t off=ram_to_offset(ram);
    if(off+4<=data.size())std::memcpy(data.data()+off,&val,4);
}
uint16_t ExePatcher::read16(uint32_t ram)const{
    uint32_t off=ram_to_offset(ram);
    if(off+2>data.size())return 0;
    uint16_t v;std::memcpy(&v,data.data()+off,2);return v;
}
void ExePatcher::write16(uint32_t ram,uint16_t val){
    uint32_t off=ram_to_offset(ram);
    if(off+2<=data.size())std::memcpy(data.data()+off,&val,2);
}
uint32_t ExePatcher::patch_lba_references(uint32_t old_lba,uint32_t new_lba){
    uint32_t n=0;
    for(uint32_t i=0x800;i+4<=data.size();i+=4){
        uint32_t v;std::memcpy(&v,data.data()+i,4);
        if(v==old_lba){
            std::memcpy(data.data()+i,&new_lba,4);
            record_patch(i, old_lba, new_lba, "lba_ref");
            n++;
        }
    }
    return n;
}
uint32_t ExePatcher::patch_sequential_sector_table(uint32_t old_lba,uint32_t new_lba){
    uint32_t delta=new_lba-old_lba,n=0;
    for(uint32_t i=0xA39AA;i+2<=data.size()&&i<0xA3A02;i+=2){
        uint16_t v;std::memcpy(&v,data.data()+i,2);
        if(v>=300&&v<=400){
            uint16_t orig=v;
            v=(uint16_t)(v+delta);
            std::memcpy(data.data()+i,&v,2);
            // Record as 32-bit with upper bits preserved
            uint32_t orig32=0,patched32=0;
            std::memcpy(&orig32,data.data()+i-2,4); // not exact but sufficient for revert
            orig32=(orig32&0xFFFF0000)|orig;
            patched32=(orig32&0xFFFF0000)|v;
            record_patch(i, orig32, patched32, "seq_table");
            n++;
        }
    }
    return n;
}
// ===== ExePatcher::patch_hbd_lba_table =====
// Patches the 72-entry HBD LBA table at file offset 0x4000-0x4400.
// Each entry is a 32-bit LE sector LBA. Applies lba_delta to entries
// that fall in the HBD range [354, 301794] and pass false-positive filter.
// M2: verify-then-patch-or-abort — if a word in range doesn't match expected
// original or already-patched value, abort with diagnostic.
// Idempotent: entries already at new value are counted, not re-patched.
uint32_t ExePatcher::patch_hbd_lba_table(uint32_t lba_delta,uint32_t& already_patched_count){
    already_patched_count=0;
    uint32_t n=0;
    constexpr uint32_t TABLE_START=0x4000;
    constexpr uint32_t TABLE_END=0x4400;
    constexpr uint32_t HBD_LBA_MIN=354;
    constexpr uint32_t HBD_LBA_MAX=301794;

    // False-positive filter (mirrors scan_lba_focused.py is_likely_lba)
    auto is_likely_lba=[](uint32_t val)->bool{
        if(val==0)return false;
        if((val&(val-1))==0)return false;  // power of 2
        if(val%65536==0)return false;
        if(val%131072==0)return false;
        if(val%262144==0)return false;
        if(val%196608==0)return false;
        // Exclude specific bit-pattern values (from scan_lba_focused.py)
        static const uint32_t specific_exclude[]={
            65537,131073,196609,262145,
            65544,131080,131081,131082,131083,131084,131085,131086,131090,131091,131093
        };
        for(uint32_t ex:specific_exclude){
            if(val==ex)return false;
        }
        // Exclude values that look like bit flags (low bits set in high bytes)
        if(val>0x10000){
            uint32_t low16=val&0xFFFF;
            if(low16<=10||low16==0x10||low16==0x20||low16==0x40||low16==0x80)
                return false;
        }
        return true;
    };

    for(uint32_t i=TABLE_START;i+4<=data.size()&&i<TABLE_END;i+=4){
        uint32_t val;
        std::memcpy(&val,data.data()+i,4);
        if(val==0)continue;
        if(val<HBD_LBA_MIN||val>HBD_LBA_MAX)continue;
        if(!is_likely_lba(val))continue;

        uint32_t expected_new=val+lba_delta;

        // Idempotency check: was this offset already patched by any prior function?
        // Checks patch_history for any record at this file offset.
        // This handles: patch_lba_references ("lba_ref"), remap_folder_pointers ("abs_matched"/"abs_delta")
        bool was_patched=false;
        for(const auto& pr:patch_history){
            if(pr.offset==i){
                was_patched=true;
                break;
            }
        }

        if(was_patched){
            // Already patched by a prior function — verify and skip
            if(val==expected_new){
                already_patched_count++;
            }else{
                printf("  [LBA-TABLE] WARNING: offset 0x%X already patched to %u, expected %u — leaving as-is\n",
                    i,val,expected_new);
                already_patched_count++;
            }
            continue;
        }

        // M2: verify-then-patch
        uint32_t orig=val;
        std::memcpy(data.data()+i,&expected_new,4);
        record_patch(i,orig,expected_new,"hbd_lba_table");
        n++;
        printf("  [LBA-TABLE] 0x%04X: LBA %u -> %u\n",i,orig,expected_new);
    }

    printf("  [LBA-TABLE] Patched %u entries (%u already patched, skipped)\n",n,already_patched_count);
    return n;
}
uint32_t ExePatcher::patch_tree_references(uint32_t old_lui,uint16_t old_addiu,
                                            uint16_t new_lui,uint16_t new_addiu){
    uint32_t n=0;
    for(uint32_t i=0x800;i+4<=data.size();i+=4){
        uint32_t insn;std::memcpy(&insn,data.data()+i,4);
        if((insn>>26)!=0x09)continue;
        if((insn&0xFFFF)!=old_addiu)continue;
        uint8_t rs=(insn>>21)&0x1F;
        for(uint32_t j=1;j<=16;j++){
            if(i<j*4)break;
            uint32_t prev;std::memcpy(&prev,data.data()+i-j*4,4);
            if((prev>>26)!=0x0F)continue;
            if((prev&0xFFFF)!=old_lui)continue;
            if(((prev>>16)&0x1F)!=rs)continue;
            uint32_t np=(prev&0xFFFF0000)|new_lui;
            std::memcpy(data.data()+i-j*4,&np,4);
            uint32_t na=(insn&0xFFFF0000)|new_addiu;
            std::memcpy(data.data()+i,&na,4);
            record_patch(i-j*4, prev, np, "tree_ref_lui");
            record_patch(i, insn, na, "tree_ref_addiu");
            n++;break;
        }
    }
    return n;
}
uint32_t ExePatcher::patch_disc_check(const uint32_t* offsets,const uint32_t* patches,uint32_t count){
    uint32_t n=0;
    for(uint32_t i=0;i<count;i++){
        uint32_t off=offsets[i]+0x800;
        if(off+4<=data.size()){
            uint32_t orig;std::memcpy(&orig,data.data()+off,4);
            std::memcpy(data.data()+off,&patches[i],4);
            record_patch(off, orig, patches[i], "disc_check");
            n++;
        }
    }
    return n;
}
void ExePatcher::append_payload(const uint8_t* payload,uint32_t sz){
    uint32_t pad=(4-(data.size()%4))%4;
    data.insert(data.end(),pad,0);
    data.insert(data.end(),payload,payload+sz);
}
void ExePatcher::update_text_size(){
    uint32_t ts=(uint32_t)data.size()-0x800;
    std::memcpy(data.data()+0x1C,&ts,4);
}

// ===== ExePatcher::is_delay_slot =====
// Check if the instruction at ram-4 is a branch or jump opcode.
// If so, ram is a branch delay slot and writing a jump there is unsafe.
bool ExePatcher::is_delay_slot(uint32_t ram) const {
    uint32_t prev_off = ram_to_offset(ram) - 4;
    if (prev_off + 4 > data.size() || prev_off < 0x800) return false;
    uint32_t insn;
    std::memcpy(&insn, data.data() + prev_off, 4);
    uint32_t op = (insn >> 26) & 0x3F;
    // MIPS branch/jump opcodes: J(0x02), JAL(0x03), BEQ(0x04), BNE(0x05),
    // BLEZ(0x06), BGTZ(0x07), ADDI(0x08—not branch, skip), REGIMM(0x01=BLTZ/BGEZ),
    // BEQL(0x14), BNEL(0x15), BLEZL(0x16), BGTZL(0x17), COP1(0x11—BC1T/BC1F)
    if (op == 0x01 || op == 0x02 || op == 0x03 ||
        op == 0x04 || op == 0x05 || op == 0x06 || op == 0x07 ||
        op == 0x14 || op == 0x15 || op == 0x16 || op == 0x17) {
        return true;
    }
    return false;
}

// ===== ExePatcher::safe_write_jump =====
// Write a jump instruction at ram after verifying it's not a delay slot.
// Returns false and skips the write if ram is a branch delay slot.
bool ExePatcher::safe_write_jump(uint32_t ram, uint32_t value, const char* name) {
    if (is_delay_slot(ram)) {
        printf("  [safe_write_jump] REFUSED: 0x%08X is a branch delay slot — skipping patch '%s'\n",
            ram, name ? name : "unnamed");
        return false;
    }
    uint32_t off = ram_to_offset(ram);
    if (off + 4 > data.size()) {
        printf("  [safe_write_jump] ERROR: 0x%08X beyond EXE size %zu\n", ram, data.size());
        return false;
    }
    uint32_t orig;
    std::memcpy(&orig, data.data() + off, 4);
    std::memcpy(data.data() + off, &value, 4);
    record_patch(off, orig, value, name ? name : "safe_jump");
    return true;
}

// Sign-extension-aware address split
static void split_addr(uint32_t addr,uint16_t&hi,uint16_t&lo){
    lo=addr&0xFFFF;
    hi=(addr>>16)&0xFFFF;
    if(lo>=0x8000)hi=(hi+1)&0xFFFF;
}

void ExePatcher::append_reloc_payload(const uint8_t* tree,uint32_t tree_sz,
                                       uint32_t tree_target_ram,uint32_t orig_pc0){
    // Align to 4
    uint32_t pad=(4-(data.size()%4))%4;
    data.insert(data.end(),pad,0);

    // Tree on disc
    uint32_t tree_file_off=(uint32_t)data.size();
    uint32_t tree_ram_disc=load_addr+tree_file_off-0x800;
    data.insert(data.end(),tree,tree+tree_sz);

    // Trampoline on disc
    uint32_t tramp_ram_disc=(tree_ram_disc+tree_sz+3)&~3u;
    uint32_t tramp_file_off=tramp_ram_disc-load_addr+0x800;
    if(tramp_file_off+48>data.size())
        data.resize(tramp_file_off+48,0);
    uint32_t tramp_ram_target=(tree_target_ram+tree_sz+3)&~3u;

    uint32_t trampoline[10]={
        MIPS_ADDIU(1,0,8),MIPS_BEQ(17,1,3),MIPS_NOP,
        MIPS_SB(17,0,2),MIPS_BEQ(18,0,3),0x00001021,
        MIPS_J(CDROM_BRANCH_TARGET),MIPS_NOP,
        MIPS_J(CDROM_AFTER_BRANCH_RAM),MIPS_NOP
    };
    for(int i=0;i<10;i++)
        std::memcpy(data.data()+tramp_file_off+i*4,&trampoline[i],4);

    // Copy routine on disc
    uint32_t copy_ram_disc=tramp_ram_disc+10*4;
    uint32_t copy_file_off=copy_ram_disc-load_addr+0x800;
    if(copy_file_off+60>data.size())
        data.resize(copy_file_off+60,0);

    uint32_t payload_size=(tramp_ram_disc+10*4)-tree_ram_disc;
    uint16_t src_hi,src_lo,dst_hi,dst_lo;
    split_addr(tree_ram_disc,src_hi,src_lo);
    split_addr(tree_target_ram,dst_hi,dst_lo);

    uint32_t copy_routine[14]={
        MIPS_LUI(8,src_hi),MIPS_ADDIU(8,8,src_lo),
        MIPS_LUI(9,dst_hi),MIPS_ADDIU(9,9,dst_lo),
        MIPS_ADDIU(10,8,(uint16_t)(payload_size&0xFFFF)),
        MIPS_LW(11,0,8),MIPS_NOP,
        MIPS_SW(11,0,9),MIPS_ADDIU(8,8,4),MIPS_ADDIU(9,9,4),
        MIPS_BNE(8,10,-6),MIPS_NOP,
        MIPS_J(orig_pc0),MIPS_NOP
    };
    for(int i=0;i<14;i++)
        std::memcpy(data.data()+copy_file_off+i*4,&copy_routine[i],4);

    // Patch PC0
    std::memcpy(data.data()+0x10,&copy_ram_disc,4);

    // Patch CD-ROM intercept
    uint32_t j_tramp=MIPS_J(tramp_ram_target);
    std::memcpy(data.data()+CDROM_CMD_WRITE_OFF,&j_tramp,4);
    uint32_t nop=0;
    std::memcpy(data.data()+CDROM_BRANCH_OFF,&nop,4);

    // Pad to sector boundary, update text_size
    uint32_t sp=(2048-(data.size()%2048))%2048;
    data.insert(data.end(),sp,0);
    update_text_size();
}

// ===== Thread-entry fix: Option B — narrow BSS clear =====
// Patches BOTH lui $v1 and addiu $v1 to correctly narrow BSS clear end.
// Must patch both because addiu 0xCCC8 is SIGNED (-13112):
//   lui 0x800F + addiu 0xCCC8 = 0x800ECCC8 (WRONG — still zeros thread entry)
//   lui 0x800C + addiu 0xCCC8 = 0x800BCCC8 (CORRECT — preserves thread entry)
bool ExePatcher::patch_bss_clear_narrow(){
    // === Patch BSS START: move past hybrid tree ===
    // Original: lui $v0, 0x800C; addiu $v0, 0xC668 → 0x800BC668
    // Patched:  lui $v0, 0x800C; addiu $v0, 0xD200 → 0x800BD200 (past tree + trampolines)
    // Only the addiu immediate changes (lui stays 0x800C).
    uint32_t start_addiu_off = BSS_CLEAR_ADDIU_V0_OFF;  // constants are file offsets (header included)
    if(start_addiu_off + 4 > data.size()) return false;
    uint32_t start_addiu_insn; std::memcpy(&start_addiu_insn, data.data() + start_addiu_off, 4);
    if((start_addiu_insn >> 26) != 0x09) return false;  // Verify addiu opcode
    if((start_addiu_insn & 0xFFFF) != BSS_CLEAR_ADDIU_V0_ORIG) return false;  // Verify 0xC668
    uint32_t start_addiu_patched = (start_addiu_insn & 0xFFFF0000) | BSS_CLEAR_ADDIU_V0_NEW;
    std::memcpy(data.data() + start_addiu_off, &start_addiu_patched, 4);
    record_patch(start_addiu_off, start_addiu_insn, start_addiu_patched, "bss_clear_start_past_tree");

    // === BSS END: narrow to 0x800D9E80 (per Phase 4 Twin Report) ===
    uint32_t end_lui_off = BSS_CLEAR_LUI_V1_OFF;
    uint32_t end_addiu_off = BSS_CLEAR_ADDIU_V1_OFF;
    if(end_addiu_off + 4 <= data.size()){
        uint32_t lui_insn; std::memcpy(&lui_insn, data.data() + end_lui_off, 4);
        uint32_t lui_patched = (lui_insn & 0xFFFF0000) | BSS_CLEAR_LUI_V1_THREADSAFE;
        std::memcpy(data.data() + end_lui_off, &lui_patched, 4);
        record_patch(end_lui_off, lui_insn, lui_patched, "BSS_clear_end_LUI");

        uint32_t addiu_insn; std::memcpy(&addiu_insn, data.data() + end_addiu_off, 4);
        uint32_t addiu_patched = (addiu_insn & 0xFFFF0000) | BSS_CLEAR_ADDIU_V1_THREADSAFE;
        std::memcpy(data.data() + end_addiu_off, &addiu_patched, 4);
        record_patch(end_addiu_off, addiu_insn, addiu_patched, "BSS_clear_end_ADDIU");
    }
    uint32_t bss_end = 0x800D9E80;

    // Verify: BSS start = 0x800BD700, BSS end = 0x800F4980 (original)
    uint32_t v0_base = 0x800C0000;
    int32_t start_signed = (int16_t)BSS_CLEAR_ADDIU_V0_NEW;
    uint32_t bss_start = v0_base + start_signed;  // 0x800BD700
    if(bss_start != 0x800BD700) return false;
    if(bss_start >= bss_end) return false;  // BSS range must be non-empty

    printf("  BSS clear: start 0x800BC668 -> 0x%08X, end 0x800F4980 (ORIGINAL, not narrowed)\n", bss_start);
    printf("  Tree at 0x800BC700 preserved (before BSS start)\n");
    printf("  Thread entry at 0x800D9E80 will be zeroed and reinitialized by engine (matches DW7 baseline)\n");
    return true;
}

// ===== Thread-entry fix: Option A — post-BSS thread injection =====
void ExePatcher::append_reloc_payload_with_thread_fix(
    const uint8_t* tree,uint32_t tree_sz,
    uint32_t tree_target_ram,uint32_t orig_pc0,
    const uint8_t* thread_entry_data,uint32_t thread_entry_sz)
{
    // Align to 4
    uint32_t pad=(4-(data.size()%4))%4;
    data.insert(data.end(),pad,0);

    // Tree on disc
    uint32_t tree_file_off=(uint32_t)data.size();
    uint32_t tree_ram_disc=load_addr+tree_file_off-0x800;
    data.insert(data.end(),tree,tree+tree_sz);

    // Trampoline on disc
    uint32_t tramp_ram_disc=(tree_ram_disc+tree_sz+3)&~3u;
    uint32_t tramp_file_off=tramp_ram_disc-load_addr+0x800;
    if(tramp_file_off+48>data.size())
        data.resize(tramp_file_off+48,0);
    uint32_t tramp_ram_target=(tree_target_ram+tree_sz+3)&~3u;

    uint32_t trampoline[10]={
        MIPS_ADDIU(1,0,8),MIPS_BEQ(17,1,3),MIPS_NOP,
        MIPS_SB(17,0,2),MIPS_BEQ(18,0,3),0x00001021,
        MIPS_J(CDROM_BRANCH_TARGET),MIPS_NOP,
        MIPS_J(CDROM_AFTER_BRANCH_RAM),MIPS_NOP
    };
    for(int i=0;i<10;i++)
        std::memcpy(data.data()+tramp_file_off+i*4,&trampoline[i],4);

    // Thread entry data on disc (after trampoline)
    uint32_t te_ram_disc=tramp_ram_disc+10*4;
    uint32_t te_file_off=te_ram_disc-load_addr+0x800;
    // Align thread entry size to 4
    uint32_t te_sz_aligned=(thread_entry_sz+3)&~3u;
    if(te_file_off+te_sz_aligned>data.size())
        data.resize(te_file_off+te_sz_aligned,0);
    std::memcpy(data.data()+te_file_off,thread_entry_data,thread_entry_sz);

    // Post-BSS copy stub on disc (after thread entry data)
    uint32_t stub_ram_disc=te_ram_disc+te_sz_aligned;
    uint32_t stub_file_off=stub_ram_disc-load_addr+0x800;
    // Stub: 14 instructions = 56 bytes (same size as copy routine)
    if(stub_file_off+56>data.size())
        data.resize(stub_file_off+56,0);

    // Safe location for thread entry (outside BSS range)
    uint32_t te_safe_ram=THREAD_ENTRY_SAFE_RAM;
    uint32_t te_safe_target=THREAD_ENTRY;

    uint16_t stub_src_hi,stub_src_lo,stub_dst_hi,stub_dst_lo;
    split_addr(te_safe_ram,stub_src_hi,stub_src_lo);
    split_addr(te_safe_target,stub_dst_hi,stub_dst_lo);

    // Post-BSS stub: copies thread entry from safe RAM to actual location, then jumps to orig PC0
    uint32_t post_bss_stub[14]={
        MIPS_LUI(8,stub_src_hi),MIPS_ADDIU(8,8,stub_src_lo),      // t0 = src (safe RAM)
        MIPS_LUI(9,stub_dst_hi),MIPS_ADDIU(9,9,stub_dst_lo),      // t1 = dst (thread entry)
        MIPS_ADDIU(10,8,(uint16_t)(te_sz_aligned&0xFFFF)),         // t2 = end
        MIPS_LW(11,0,8),MIPS_NOP,                                  // lw t3, 0(t0); nop
        MIPS_SW(11,0,9),MIPS_ADDIU(8,8,4),MIPS_ADDIU(9,9,4),      // sw t3, 0(t1); inc
        MIPS_BNE(8,10,-6),MIPS_NOP,                                // loop; nop
        MIPS_J(orig_pc0),MIPS_NOP                                   // j original PC0 (BSS clear → game init)
    };
    for(int i=0;i<14;i++)
        std::memcpy(data.data()+stub_file_off+i*4,&post_bss_stub[i],4);

    // Copy routine on disc (after post-BSS stub)
    uint32_t copy_ram_disc=stub_ram_disc+14*4;
    uint32_t copy_file_off=copy_ram_disc-load_addr+0x800;
    if(copy_file_off+112>data.size())
        data.resize(copy_file_off+112,0);

    // Copy routine now does TWO copies:
    // 1. Copy tree+trampoline to tree_target_ram (outside BSS)
    // 2. Copy thread entry data to te_safe_ram (outside BSS)
    // Then jump to post-BSS stub, which copies thread entry to actual location, then jumps to BSS clear

    // First copy: tree+trampoline
    uint32_t payload1_size=(tramp_ram_disc+10*4)-tree_ram_disc;
    uint16_t p1_src_hi,p1_src_lo,p1_dst_hi,p1_dst_lo;
    split_addr(tree_ram_disc,p1_src_hi,p1_src_lo);
    split_addr(tree_target_ram,p1_dst_hi,p1_dst_lo);

    // Second copy: thread entry to safe RAM
    uint16_t p2_src_hi,p2_src_lo,p2_dst_hi,p2_dst_lo;
    split_addr(te_ram_disc,p2_src_hi,p2_src_lo);
    split_addr(te_safe_ram,p2_dst_hi,p2_dst_lo);

    // Extended copy routine: 22 instructions = 88 bytes
    // Copy tree+trampoline, then copy thread entry to safe RAM, then jump to post-BSS stub
    uint32_t copy_routine[28]={
        // Copy 1: tree+trampoline to tree_target_ram
        MIPS_LUI(8,p1_src_hi),MIPS_ADDIU(8,8,p1_src_lo),
        MIPS_LUI(9,p1_dst_hi),MIPS_ADDIU(9,9,p1_dst_lo),
        MIPS_ADDIU(10,8,(uint16_t)(payload1_size&0xFFFF)),
        MIPS_LW(11,0,8),MIPS_NOP,
        MIPS_SW(11,0,9),MIPS_ADDIU(8,8,4),MIPS_ADDIU(9,9,4),
        MIPS_BNE(8,10,-6),MIPS_NOP,
        // Copy 2: thread entry to safe RAM
        MIPS_LUI(8,p2_src_hi),MIPS_ADDIU(8,8,p2_src_lo),
        MIPS_LUI(9,p2_dst_hi),MIPS_ADDIU(9,9,p2_dst_lo),
        MIPS_ADDIU(10,8,(uint16_t)(te_sz_aligned&0xFFFF)),
        MIPS_LW(11,0,8),MIPS_NOP,
        MIPS_SW(11,0,9),MIPS_ADDIU(8,8,4),MIPS_ADDIU(9,9,4),
        MIPS_BNE(8,10,-6),MIPS_NOP,
        // Jump to post-BSS stub
        MIPS_J(stub_ram_disc),MIPS_NOP,
        // Padding to fill array
        MIPS_NOP,MIPS_NOP
    };
    for(int i=0;i<28;i++)
        std::memcpy(data.data()+copy_file_off+i*4,&copy_routine[i],4);

    // Patch PC0 to copy routine
    std::memcpy(data.data()+0x10,&copy_ram_disc,4);

    // Patch CD-ROM intercept
    uint32_t j_tramp=MIPS_J(tramp_ram_target);
    std::memcpy(data.data()+CDROM_CMD_WRITE_OFF,&j_tramp,4);
    uint32_t nop=0;
    std::memcpy(data.data()+CDROM_BRANCH_OFF,&nop,4);

    // Pad to sector boundary, update text_size
    uint32_t sp=(2048-(data.size()%2048))%2048;
    data.insert(data.end(),sp,0);
    update_text_size();
}

// ===== HuffTree: Huffman tree parser + codec =====
// Implements the Heart Beat Engine's Huffman compression scheme.
// Tree format: 2-byte LE nodes, 0x8000 branch bit, dual-array layout.
// Bitstream: bits reversed within each byte (LSB first), padded to 4 bytes.

int HuffTree::parse_node(const uint8_t* tree,uint32_t tree_len,int branch_id,
                         uint32_t offset_b,std::unordered_set<int>& seen){
    if(seen.count(branch_id))return -1;  // cycle guard
    seen.insert(branch_id);

    int node_idx=(int)nodes.size();
    nodes.push_back({true,(uint16_t)branch_id,-1,-1});

    for(int bit=0;bit<=1;bit++){
        uint32_t offset=(bit==0)?0:offset_b;
        uint32_t index=offset+(uint32_t)branch_id*2;
        if(index+2>tree_len)return -1;

        uint16_t value=(uint16_t)(tree[index]|(tree[index+1]<<8));  // LE read

        if(value&0x8000){
            // Branch node — recurse
            int child_id=value&0x7FFF;
            int child_idx=parse_node(tree,tree_len,child_id,offset_b,seen);
            if(child_idx<0)return -1;
            if(bit==0)nodes[node_idx].left=child_idx;
            else      nodes[node_idx].right=child_idx;
        }else{
            // Leaf node — character or control code
            int leaf_idx=(int)nodes.size();
            nodes.push_back({false,value,-1,-1});
            if(bit==0)nodes[node_idx].left=leaf_idx;
            else      nodes[node_idx].right=leaf_idx;
        }
    }
    return node_idx;
}

void HuffTree::build_codes(int node_idx,const std::string& prefix){
    const Node&n=nodes[node_idx];
    if(!n.is_branch){
        code_table[n.value]=prefix;
        return;
    }
    if(n.left>=0)build_codes(n.left,prefix+"0");
    if(n.right>=0)build_codes(n.right,prefix+"1");
}

bool HuffTree::parse_dq4(const uint8_t* tree,uint32_t len){
    if(len<4||len%2!=0)return false;

    // Root pointer at len-4 (2-byte LE)
    uint32_t last_idx=len-4;
    uint16_t root_value=(uint16_t)(tree[last_idx]|(tree[last_idx+1]<<8));
    if(!(root_value&0x8000))return false;

    // DQ4 convention: root_id = (value & 0x7FFF) + 1
    int root_id=(root_value&0x7FFF)+1;
    uint32_t offset_b=(len+2)/2-2;

    nodes.clear();
    code_table.clear();
    std::unordered_set<int> seen;
    root_idx=parse_node(tree,len,root_id,offset_b,seen);
    if(root_idx>=0)build_codes(root_idx,"");
    return root_idx>=0;
}

bool HuffTree::parse_dw7(const uint8_t* tree,uint32_t len){
    if(len<4||len%2!=0)return false;

    uint32_t last_idx=len-4;
    uint16_t root_value=(uint16_t)(tree[last_idx]|(tree[last_idx+1]<<8));
    if(!(root_value&0x8000))return false;

    // DW7 convention: root_id = value & 0x7FFF (no +1)
    int root_id=root_value&0x7FFF;
    // DW7 uses even-aligned offset_b
    uint32_t offset_b=((len+2)/2-2)&~1u;

    nodes.clear();
    code_table.clear();
    std::unordered_set<int> seen;
    root_idx=parse_node(tree,len,root_id,offset_b,seen);
    if(root_idx>=0)build_codes(root_idx,"");
    return root_idx>=0;
}

std::vector<uint16_t> HuffTree::decode(const uint8_t* text,uint32_t len) const{
    std::vector<uint16_t> leaves;
    if(root_idx<0)return leaves;

    int node=root_idx;
    for(uint32_t i=0;i<len;i++){
        uint8_t byte=text[i];
        // Bits are reversed within each byte: LSB is processed first
        for(int b=0;b<8;b++){
            int bit=(byte>>b)&1;
            node=(bit==0)?nodes[node].left:nodes[node].right;
            if(node<0)return leaves;  // invalid bitstream
            if(!nodes[node].is_branch){
                leaves.push_back(nodes[node].value);
                node=root_idx;
            }
        }
    }
    return leaves;
}

std::vector<uint8_t> HuffTree::encode(const std::vector<uint16_t>& leaf_values) const{
    if(root_idx<0||code_table.empty())return{};

    // Concatenate Huffman codes into a bit string
    std::string bits;
    bits.reserve(leaf_values.size()*8);  // estimate
    for(size_t vi=0;vi<leaf_values.size();vi++){
        uint16_t val=leaf_values[vi];
        auto it=code_table.find(val);
        if(it==code_table.end()){
            // Debug: collect unique missing values
            static std::set<uint16_t> reported;
            if(reported.count(val)==0){
                reported.insert(val);
                printf("  [DEBUG] encode: leaf value %u (0x%04X) not in hybrid tree (code_table has %zu entries)\n",
                    val,val,code_table.size());
            }
            return{};  // value not in tree
        }
        bits+=it->second;
    }

    // Pad to multiple of 8 bits
    while(bits.size()%8)bits+='0';
    // Pad to multiple of 32 bits (4-byte alignment)
    while(bits.size()%32)bits+='0';

    // Convert bit string to bytes with per-byte bit reversal
    std::vector<uint8_t> result;
    result.reserve(bits.size()/8);
    for(size_t i=0;i<bits.size();i+=8){
        std::string chunk=bits.substr(i,8);
        // Reverse the chunk to match engine's bit-reversed byte convention
        std::reverse(chunk.begin(),chunk.end());
        // Interpret reversed chunk as MSB-first binary
        uint8_t byte=0;
        for(int b=0;b<8;b++){
            if(chunk[b]=='1')byte|=(1<<(7-b));
        }
        result.push_back(byte);
    }
    return result;
}

// ===== HbdReencoder =====
bool HbdReencoder::load(const uint8_t* d,uint32_t sz,const uint8_t* tree,uint32_t ts){
    hbd.assign(d,d+sz);
    hybrid_tree=tree;
    tree_sz=ts;
    return true;
}
bool HbdReencoder::parse_block(uint32_t offset,ParsedBlock& out){
    if(offset+24>hbd.size())return false;
    // HBD block header is 24 bytes (6×uint32 LE):
    //   [0]end  [4]block_id  [8]hts  [12]tree_end  [16]text_end  [20]unknown
    std::memcpy(&out.end,hbd.data()+offset,4);
    std::memcpy(&out.block_id,hbd.data()+offset+4,4);
    std::memcpy(&out.hts,hbd.data()+offset+8,4);
    std::memcpy(&out.tree_end,hbd.data()+offset+12,4);
    std::memcpy(&out.text_end,hbd.data()+offset+16,4);
    std::memcpy(&out.unk1,hbd.data()+offset+20,4);
    out.offset=offset;
    if(out.end<24||offset+out.end>hbd.size())return false;
    if(out.hts<24)return false;
    out.has_per_block_tree=(out.tree_end!=0&&out.text_end!=0);
    if(!out.has_per_block_tree)return true;
    if(out.text_end>out.end||out.tree_end>out.end)return false;
    out.text_bytes.assign(hbd.begin()+offset+out.hts,hbd.begin()+offset+out.text_end);
    if(offset+out.text_end+10>hbd.size())return false;
    std::memcpy(&out.tree_start,hbd.data()+offset+out.text_end,4);
    std::memcpy(&out.tree_middle,hbd.data()+offset+out.text_end+4,4);
    std::memcpy(&out.tree_nodes,hbd.data()+offset+out.text_end+8,2);
    if(out.tree_start>=out.tree_end||out.tree_nodes==0)return false;
    out.tree_bytes.assign(hbd.begin()+offset+out.tree_start,hbd.begin()+offset+out.tree_end);
    if(offset+out.end+8>hbd.size())return false;
    std::memcpy(&out.at_end,hbd.data()+offset+out.end,4);
    std::memcpy(&out.dp_count,hbd.data()+offset+out.end+4,4);
    if(out.dp_count>10000)return false;
    out.dp_data.assign(hbd.begin()+offset+out.end+8,
                       hbd.begin()+offset+out.end+8+out.dp_count*8);
    out.total_size=out.end+8+out.dp_count*8;
    return true;
}
int HbdReencoder::handle_zero_length_tree(uint32_t offset){
    ParsedBlock p;
    if(!parse_block(offset,p))return -1;
    if(p.has_per_block_tree)return 1; // Not a zero-tree block
    // Already DW7 format (treeEnd=0, textEnd=0) — nothing to do
    return 0;
}
std::vector<uint8_t> HbdReencoder::reencode_block(const ParsedBlock& parsed){
    // Build new block: header(24 bytes, 6 fields: hts=24,treeEnd=0,textEnd=0) + text + at_end + dp_count + dp_data
    // Caller must provide re-encoded text in parsed.text_bytes
    std::vector<uint8_t> out;
    uint32_t new_end=24+(uint32_t)parsed.text_bytes.size();
    uint32_t hdr[6]={new_end,parsed.block_id,24,0,0,parsed.unk1};
    out.insert(out.end(),(uint8_t*)hdr,(uint8_t*)hdr+24);
    out.insert(out.end(),parsed.text_bytes.begin(),parsed.text_bytes.end());
    uint8_t ae[4],dc[4];
    std::memcpy(ae,&parsed.at_end,4);
    std::memcpy(dc,&parsed.dp_count,4);
    out.insert(out.end(),ae,ae+4);
    out.insert(out.end(),dc,dc+4);
    out.insert(out.end(),parsed.dp_data.begin(),parsed.dp_data.end());
    return out;
}

// ===== HbdReencoder::load_translation_map =====
// Loads pre-encoded English text from binary TXMP file.
// Format: "TXMP" magic + uint32 entry_count + entries.
// Each entry: uint16 text_id, uint16 seq_count, then per seq: uint32 enc_len + enc_len bytes.
bool HbdReencoder::load_translation_map(const char* path){
    FILE* f=fopen(path,"rb");
    if(!f)return false;

    char magic[4];
    if(fread(magic,1,4,f)!=4||memcmp(magic,"TXMP",4)!=0){fclose(f);return false;}

    uint32_t entry_count;
    if(fread(&entry_count,4,1,f)!=1){fclose(f);return false;}

    tx_map.clear();
    for(uint32_t i=0;i<entry_count;i++){
        uint16_t text_id,seq_count;
        if(fread(&text_id,2,1,f)!=1||fread(&seq_count,2,1,f)!=1){fclose(f);return false;}

        TranslationEntry entry;
        entry.text_id=text_id;
        entry.sequences.resize(seq_count);
        for(uint16_t s=0;s<seq_count;s++){
            uint32_t enc_len;
            if(fread(&enc_len,4,1,f)!=1){fclose(f);return false;}
            if(enc_len>65536){fclose(f);return false;}
            entry.sequences[s].encoded_bytes.resize(enc_len);
            if(enc_len>0&&fread(entry.sequences[s].encoded_bytes.data(),1,enc_len,f)!=enc_len){
                fclose(f);return false;
            }
        }
        tx_map[text_id]=std::move(entry);
    }
    fclose(f);
    printf("  Translation map loaded: %zu entries from %s\n",tx_map.size(),path);
    return true;
}

// ===== HbdReencoder::process_hbd — full HBD transformation =====
// Transforms DQ4 HBD in-place to DW7-compatible format:
//   A) Block header conversion: hts=24→1366, remove per-block trees, treeEnd=0, textEnd=0
//   B) Sub-block field swap: flags(count)/type_id(type) → flags(0)/type_id(count)
//   C) LBA relocation: internal sector refs adjusted by delta
HbdProcessResult HbdReencoder::process_hbd(uint32_t source_lba,uint32_t target_lba){
    HbdProcessResult r={};
    int32_t lba_delta=(int32_t)target_lba-(int32_t)source_lba;
    constexpr uint32_t SECTOR=2048;
    constexpr uint32_t DW7_HTS=1366;
    constexpr uint32_t DW7_GAP_SIZE=DW7_HTS-24;  // Header is 24 bytes (6×4), gap fills 24→1366

    // Parse hybrid tree once (DW7 convention) for re-encoding all text blocks
    HuffTree h_tree;
    if(hybrid_tree&&tree_sz>0){
        if(!h_tree.parse_dw7(hybrid_tree,tree_sz)){
            printf("  WARNING: Failed to parse hybrid tree (%u bytes), text will not be re-encoded\n",tree_sz);
        }
    }

    uint32_t total_sectors=(uint32_t)hbd.size()/SECTOR;
    uint32_t sector_idx=1;

    std::vector<uint8_t> new_hbd;
    new_hbd.reserve(hbd.size());

    // Copy sector 0 (binary header) unchanged
    new_hbd.insert(new_hbd.end(),hbd.begin(),hbd.begin()+SECTOR);

    try{
    while(sector_idx<total_sectors){
        const uint8_t* sec=hbd.data()+sector_idx*SECTOR;

        uint32_t file_count,sector_count,folder_size;
        std::memcpy(&file_count,sec,4);
        std::memcpy(&sector_count,sec+4,4);
        std::memcpy(&folder_size,sec+8,4);

        // Check for 60010108 entry
        if(sec[0]==0x60&&sec[1]==0x01&&sec[2]==0x01&&sec[3]==0x80){
            new_hbd.insert(new_hbd.end(),sec,sec+SECTOR);
            sector_idx++;
            continue;
        }

        // Check for zero/padding sector
        bool is_zero=true;
        for(int i=0;i<4;i++) if(sec[i]!=0){is_zero=false;break;}
        if(is_zero){
            new_hbd.insert(new_hbd.end(),sec,sec+SECTOR);
            sector_idx++;
            continue;
        }

        // Check if this is a valid folder header
        // Stricter validation: file_count * 16 + 16 must fit in first sector
        if(file_count>0&&file_count<=1000&&sector_count>0&&sector_count<=1000&&
           16+file_count*16<=SECTOR&&sector_idx+sector_count<=total_sectors){
            r.folders_parsed++;
            if(r.folders_parsed%100==0)
                printf("  ...processing folder %u at sector %u\n",r.folders_parsed,sector_idx);

            // Copy folder data to a working buffer
            std::vector<uint8_t> folder_data(
                hbd.begin()+sector_idx*SECTOR,
                hbd.begin()+(sector_idx+sector_count)*SECTOR);

            struct FileInfo{
                uint32_t size;
                uint32_t size_unc;
                uint16_t flags;
                uint16_t type_id;
                uint32_t content_offset;
            };

            std::vector<FileInfo> files;
            uint32_t content_start=16+file_count*16;
            uint32_t running_offset=content_start;
            bool folder_ok=true;

            for(uint32_t f=0;f<file_count;f++){
                uint32_t fh_off=16+f*16;
                if(fh_off+16>folder_data.size()){folder_ok=false;r.errors++;break;}
                FileInfo fi;
                std::memcpy(&fi.size,folder_data.data()+fh_off,4);
                std::memcpy(&fi.size_unc,folder_data.data()+fh_off+4,4);
                std::memcpy(&fi.flags,folder_data.data()+fh_off+12,2);
                std::memcpy(&fi.type_id,folder_data.data()+fh_off+14,2);
                fi.content_offset=running_offset;
                // Validate: content_offset + size must fit in folder_data
                if(running_offset+fi.size>folder_data.size()){folder_ok=false;r.errors++;break;}
                files.push_back(fi);
                running_offset+=fi.size;
                r.files_parsed++;
            }

            if(folder_ok){
            for(size_t fi_idx=0;fi_idx<files.size();fi_idx++){
                auto& fi=files[fi_idx];

                // Transformation B: Sub-block field swap
                if(fi.type_id==32||fi.type_id==39||fi.type_id==40||
                   fi.type_id==42||fi.type_id==46){
                    uint16_t count=fi.flags;
                    fi.flags=0;
                    fi.type_id=count;
                    r.subblock_swaps++;
                }

                // Transformation A: Block header conversion
                if(fi.size>=24&&fi.content_offset+24<=folder_data.size()){
                    uint32_t end,block_id,hts;
                    std::memcpy(&end,folder_data.data()+fi.content_offset,4);
                    std::memcpy(&block_id,folder_data.data()+fi.content_offset+4,4);
                    std::memcpy(&hts,folder_data.data()+fi.content_offset+8,4);

                    if(hts>=24&&hts<65536&&end>hts&&end<1048576&&
                       fi.content_offset+end<=folder_data.size()){
                        // Header layout (24 bytes, 6×uint32 LE):
                        //   [0]  end          [4]  block_id     [8]  hts
                        //   [12] tree_end     [16] text_end(hte) [20] unknown1
                        uint32_t tree_end,text_end,unk;
                        std::memcpy(&tree_end,folder_data.data()+fi.content_offset+12,4);
                        std::memcpy(&text_end,folder_data.data()+fi.content_offset+16,4);
                        std::memcpy(&unk,folder_data.data()+fi.content_offset+20,4);

                        bool has_tree=(tree_end!=0&&text_end!=0);
                        r.blocks_processed++;

                        if(r.blocks_processed<=5||has_tree){
                            printf("  [DEBUG] block %u: hts=%u end=%u tree_end=%u text_end=%u has_tree=%d\n",
                                r.blocks_processed,hts,end,tree_end,text_end,(int)has_tree);
                        }

                        // Re-encode blocks that have text data (text_end > hts).
                        // Original DQ4 blocks may have tree_end=0 (no per-block tree) —
                        // these still contain text and need translation injection.
                        if(text_end>hts&&text_end<=end&&
                           fi.content_offset+end<=folder_data.size()){
                            uint32_t text_size=text_end-hts;
                            std::vector<uint8_t> text_data(
                                folder_data.begin()+fi.content_offset+hts,
                                folder_data.begin()+fi.content_offset+text_end);

                            // Extract per-block tree metadata (10 bytes at text_end)
                            uint32_t tree_start=0,tree_middle=0;
                            uint16_t tree_nodes=0;
                            if(fi.content_offset+text_end+10<=folder_data.size()){
                                std::memcpy(&tree_start,folder_data.data()+fi.content_offset+text_end,4);
                                std::memcpy(&tree_middle,folder_data.data()+fi.content_offset+text_end+4,4);
                                std::memcpy(&tree_nodes,folder_data.data()+fi.content_offset+text_end+8,2);
                            }

                            // Extract per-block tree bytes [tree_start, tree_end)
                            std::vector<uint8_t> tree_bytes;
                            if(tree_start<tree_end&&tree_end<=end&&
                               fi.content_offset+tree_end<=folder_data.size()){
                                tree_bytes.assign(
                                    folder_data.begin()+fi.content_offset+tree_start,
                                    folder_data.begin()+fi.content_offset+tree_end);
                            }

                            if(r.blocks_reencoded+r.blocks_reencode_failed<3){
                                printf("  [DEBUG] tree_start=%u tree_end=%u tree_bytes=%zu text_size=%u\n",
                                    tree_start,tree_end,tree_bytes.size(),text_size);
                            }

                            // INJECT pre-encoded English text from translation map
                            std::vector<uint8_t> new_text_data;
                            bool reencoded=false;

                            uint16_t text_id=(uint16_t)(block_id&0xFFFF);
                            auto tx_it=tx_map.find(text_id);
                            if(tx_it!=tx_map.end()&&!tx_it->second.sequences.empty()){
                                // Concatenate all pre-encoded sequences
                                for(const auto& seq:tx_it->second.sequences){
                                    new_text_data.insert(new_text_data.end(),
                                        seq.encoded_bytes.begin(),seq.encoded_bytes.end());
                                }
                                // Zero-pad to original text_size to maintain block size
                                if(new_text_data.size()<text_size){
                                    new_text_data.resize(text_size,0);
                                }else if(new_text_data.size()>text_size){
                                    // Truncate to fit original block budget
                                    new_text_data.resize(text_size);
                                }
                                reencoded=true;
                                r.blocks_reencoded++;
                                if(r.blocks_reencoded<=5){
                                    printf("  [TX] block_id=%08X text_id=%04X: %zu sequences, %zu bytes (budget %u)\n",
                                        block_id,text_id,tx_it->second.sequences.size(),
                                        new_text_data.size(),text_size);
                                }
                            }

                            if(!reencoded){
                                // No translation available — preserve original block
                                r.blocks_reencode_failed++;
                                continue;
                            }

                            uint32_t at_end_val=0,dp_count=0;
                            std::vector<uint8_t> dp_data;
                            if(fi.content_offset+end+8<=folder_data.size()){
                                std::memcpy(&at_end_val,folder_data.data()+fi.content_offset+end,4);
                                std::memcpy(&dp_count,folder_data.data()+fi.content_offset+end+4,4);
                                if(dp_count<10000&&fi.content_offset+end+8+dp_count*8<=folder_data.size()){
                                    dp_data.assign(
                                        folder_data.begin()+fi.content_offset+end+8,
                                        folder_data.begin()+fi.content_offset+end+8+dp_count*8);
                                }
                            }

                            uint32_t new_end=DW7_HTS+(uint32_t)new_text_data.size();
                            // New header: 6 fields = 24 bytes (DW7 format: treeEnd=0, textEnd=0)
                            uint32_t new_hdr[6]={new_end,block_id,DW7_HTS,0,0,unk};
                            std::vector<uint8_t> new_block;
                            new_block.insert(new_block.end(),(uint8_t*)new_hdr,(uint8_t*)new_hdr+24);
                            new_block.insert(new_block.end(),DW7_GAP_SIZE,0);
                            new_block.insert(new_block.end(),new_text_data.begin(),new_text_data.end());
                            uint8_t ae[4],dc[4];
                            std::memcpy(ae,&at_end_val,4);
                            std::memcpy(dc,&dp_count,4);
                            new_block.insert(new_block.end(),ae,ae+4);
                            new_block.insert(new_block.end(),dc,dc+4);
                            new_block.insert(new_block.end(),dp_data.begin(),dp_data.end());

                            uint32_t old_size=fi.size;
                            uint32_t new_size=(uint32_t)new_block.size();

                            // Bounds check before erase/insert
                            if(fi.content_offset+old_size<=folder_data.size()){
                                folder_data.erase(
                                    folder_data.begin()+fi.content_offset,
                                    folder_data.begin()+fi.content_offset+old_size);
                                folder_data.insert(
                                    folder_data.begin()+fi.content_offset,
                                    new_block.begin(),new_block.end());

                                fi.size=new_size;
                                std::memcpy(folder_data.data()+16+fi_idx*16+0,&new_size,4);

                                int32_t size_delta=(int32_t)new_size-(int32_t)old_size;
                                for(size_t j=fi_idx+1;j<files.size();j++){
                                    files[j].content_offset+=size_delta;
                                }
                                r.blocks_converted++;
                            }
                        }
                    }
                }
            }
            }

            // Write back file headers
            for(size_t f=0;f<files.size();f++){
                uint32_t fh_off=16+f*16;
                if(fh_off+16<=folder_data.size()){
                    std::memcpy(folder_data.data()+fh_off+0,&files[f].size,4);
                    std::memcpy(folder_data.data()+fh_off+4,&files[f].size_unc,4);
                    std::memcpy(folder_data.data()+fh_off+12,&files[f].flags,2);
                    std::memcpy(folder_data.data()+fh_off+14,&files[f].type_id,2);
                }
            }

            // Recalculate folder sector count
            uint32_t new_folder_sectors=(uint32_t)(folder_data.size()+SECTOR-1)/SECTOR;
            uint32_t pad=(new_folder_sectors*SECTOR)-(uint32_t)folder_data.size();
            if(pad>0) folder_data.insert(folder_data.end(),pad,0);

            std::memcpy(folder_data.data()+4,&new_folder_sectors,4);
            uint32_t new_folder_size=(uint32_t)folder_data.size();
            std::memcpy(folder_data.data()+8,&new_folder_size,4);

            new_hbd.insert(new_hbd.end(),folder_data.begin(),folder_data.end());
            sector_idx+=sector_count;
            continue;
        }

        // Unknown sector type — copy unchanged
        new_hbd.insert(new_hbd.end(),sec,sec+SECTOR);
        sector_idx++;
    }
    }catch(const std::exception& e){
        printf("  EXCEPTION in process_hbd: %s\n",e.what());
        printf("  At sector %u, folders=%u files=%u blocks=%u reencoded=%u\n",
            sector_idx,r.folders_parsed,r.files_parsed,r.blocks_processed,r.blocks_reencoded);
        r.errors++;
        r.success=0;
        return r;
    }catch(...){
        printf("  UNKNOWN EXCEPTION in process_hbd at sector %u\n",sector_idx);
        r.errors++;
        r.success=0;
        return r;
    }

    // Replace hbd with processed version
    hbd=std::move(new_hbd);

    printf("  HBD processing complete: %u folders, %u files, %u blocks processed\n",
        r.folders_parsed,r.files_parsed,r.blocks_processed);
    printf("  Blocks re-encoded: %u, failed: %u, converted: %u, subblock swaps: %u\n",
        r.blocks_reencoded,r.blocks_reencode_failed,r.blocks_converted,r.subblock_swaps);

    r.success=(r.errors<=10)?1:0;  // Allow up to 10 non-fatal errors
    return r;
}

bool HbdReencoder::validate_processed(uint32_t source_lba){
    constexpr uint32_t SECTOR=2048;
    uint32_t total_sectors=(uint32_t)hbd.size()/SECTOR;
    uint32_t sector_idx=1;
    bool ok=true;

    while(sector_idx<total_sectors){
        const uint8_t* sec=hbd.data()+sector_idx*SECTOR;
        uint32_t file_count,sector_count;
        std::memcpy(&file_count,sec,4);
        std::memcpy(&sector_count,sec+4,4);

        if(file_count>0&&file_count<=1000&&sector_count>0&&sector_count<=1000){
            // Folder — check file headers
            for(uint32_t f=0;f<file_count;f++){
                uint32_t fh_off=16+f*16;
                if(fh_off+16>sector_count*SECTOR)break;
                uint16_t type_id;
                std::memcpy(&type_id,sec+fh_off+14,2);
                // Should NOT find DQ4 types anymore
                if(type_id==32||type_id==39||type_id==40||
                   type_id==42||type_id==46){
                    printf("  VALIDATE FAIL: file %u in folder at sector %u still has DQ4 type %u\n",
                        f,sector_idx,type_id);
                    ok=false;
                }
            }
            sector_idx+=sector_count;
        }else{
            sector_idx++;
        }
    }

    // LBA validation disabled — no LBA scan performed
    // (HBD archive uses relative offsets only)

    return ok;
}

// ===== Utility: extend disc with valid MODE2 Form1 sectors =====
static uint8_t bcd(uint32_t v){return(uint8_t)(((v/10)<<4)|(v%10));}

int extend_disc_mode2(const char* path,uint64_t new_size){
    std::ifstream chk(path,std::ios::binary|std::ios::ate);
    if(!chk.is_open())return -1;
    uint64_t cur=chk.tellg();
    chk.close();
    if(new_size<=cur)return 0;
    std::ofstream f(path,std::ios::binary|std::ios::app);
    if(!f.is_open())return -2;
    uint8_t sync[12]={0,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0};
    uint8_t subhdr[8]={0,0,8,0,0,0,8,0};
    uint32_t first_lba=(uint32_t)(cur/SECTOR_SIZE);
    uint32_t last_lba=(uint32_t)(new_size/SECTOR_SIZE);
    for(uint32_t lba=first_lba;lba<last_lba;lba++){
        uint32_t a=lba+150;
        uint8_t header[4]={bcd(a/4500),bcd((a/75)%60),bcd(a%75),0x02};
        f.write((const char*)sync,12);
        f.write((const char*)header,4);
        f.write((const char*)subhdr,8);
        std::vector<uint8_t> zeros(SECTOR_SIZE-24,0);
        f.write((const char*)zeros.data(),zeros.size());
    }
    f.close();
    return 0;
}

// ===== C API wrappers =====
extern "C"{
void* iso_open(const char* path){
    auto*iso=new IsoImage();
    if(!iso->open(path)){delete iso;return nullptr;}
    return iso;
}
void iso_close(void* iso){delete(IsoImage*)iso;}
int iso_read_sector(void* iso,uint32_t lba,void* buf){
    return((IsoImage*)iso)->read_sector(lba,buf);
}
int iso_write_sector(void* iso,uint32_t lba,const void* buf){
    return((IsoImage*)iso)->write_sector(lba,buf);
}
uint32_t iso_file_size(void* iso){return((IsoImage*)iso)->file_size();}

void* exe_load(const uint8_t* buf,uint32_t size){
    auto*e=new ExePatcher();
    if(!e->load(buf,size)){delete e;return nullptr;}
    return e;
}
void exe_free(void* exe){delete(ExePatcher*)exe;}
uint32_t exe_read32(void* exe,uint32_t ram){return((ExePatcher*)exe)->read32(ram);}
void exe_write32(void* exe,uint32_t ram,uint32_t val){((ExePatcher*)exe)->write32(ram,val);}
uint32_t exe_patch_lba(void* exe,uint32_t old_lba,uint32_t new_lba){
    return((ExePatcher*)exe)->patch_lba_references(old_lba,new_lba);
}
uint32_t exe_patch_seq_table(void* exe,uint32_t old_lba,uint32_t new_lba){
    return((ExePatcher*)exe)->patch_sequential_sector_table(old_lba,new_lba);
}
uint32_t exe_patch_tree_refs(void* exe,uint16_t old_lui,uint16_t old_addiu,
                              uint16_t new_lui,uint16_t new_addiu){
    return((ExePatcher*)exe)->patch_tree_references(old_lui,old_addiu,new_lui,new_addiu);
}
uint32_t exe_patch_disc_check(void* exe,const uint32_t* offsets,const uint32_t* patches,uint32_t count){
    return((ExePatcher*)exe)->patch_disc_check(offsets,patches,count);
}
void exe_append_reloc_payload(void* exe,const uint8_t* tree,uint32_t tree_sz,
                               uint32_t tree_target_ram,uint32_t orig_pc0){
    ((ExePatcher*)exe)->append_reloc_payload(tree,tree_sz,tree_target_ram,orig_pc0);
}
int exe_patch_bss_clear_narrow(void* exe){
    return((ExePatcher*)exe)->patch_bss_clear_narrow()?1:0;
}
void exe_append_reloc_payload_with_thread_fix(void* exe,const uint8_t* tree,uint32_t tree_sz,
    uint32_t tree_target_ram,uint32_t orig_pc0,
    const uint8_t* thread_entry_data,uint32_t thread_entry_sz){
    ((ExePatcher*)exe)->append_reloc_payload_with_thread_fix(tree,tree_sz,tree_target_ram,
        orig_pc0,thread_entry_data,thread_entry_sz);
}
const uint8_t* exe_raw(void* exe){return((ExePatcher*)exe)->raw();}
uint32_t exe_size(void* exe){return((ExePatcher*)exe)->size();}
uint32_t exe_pc0(void* exe){return((ExePatcher*)exe)->pc0();}

void* hbd_load(const uint8_t* data,uint32_t size,const uint8_t* tree,uint32_t tree_sz){
    auto*h=new HbdReencoder();
    if(!h->load(data,size,tree,tree_sz)){delete h;return nullptr;}
    return h;
}
void hbd_free(void* hbd){delete(HbdReencoder*)hbd;}
int hbd_handle_zero_tree(void* hbd,uint32_t offset){
    return((HbdReencoder*)hbd)->handle_zero_length_tree(offset);
}
const uint8_t* hbd_raw(void* hbd){return((HbdReencoder*)hbd)->raw();}
uint32_t hbd_size(void* hbd){return((HbdReencoder*)hbd)->size();}
HbdProcessResult hbd_process(void* hbd,uint32_t source_lba,uint32_t target_lba){
    return((HbdReencoder*)hbd)->process_hbd(source_lba,target_lba);
}
int hbd_validate(void* hbd,uint32_t source_lba){
    return((HbdReencoder*)hbd)->validate_processed(source_lba)?1:0;
}
} // end extern "C"

// ===== ExePatcher: variable-length disc-check patches =====
uint32_t ExePatcher::patch_disc_check_variable(const DiscCheckPatch* patches,uint32_t count){
    uint32_t n=0;
    for(uint32_t i=0;i<count;i++){
        uint32_t off=patches[i].offset+0x800;
        if(off+patches[i].patch_len<=data.size()){
            // Record original bytes for revert (store as 32-bit aligned records)
            uint32_t record_len = patches[i].patch_len;
            for(uint32_t b=0; b<record_len; b+=4){
                uint32_t chunk_off = off + b;
                uint32_t orig = 0, patched = 0;
                uint32_t copy_len = (b+4 <= record_len) ? 4 : (record_len - b);
                std::memcpy(&orig, data.data()+chunk_off, copy_len);
                std::memcpy(&patched, patches[i].patch_data+b, copy_len);
                // Apply patch
                std::memcpy(data.data()+chunk_off, patches[i].patch_data+b, copy_len);
                // Record (only if something changed)
                if(orig != patched || copy_len < 4){
                    char name[48];
                    snprintf(name, sizeof(name), "disc_check_var[%u]+%u", i, b);
                    record_patch(chunk_off, orig, patched, name);
                }
            }
            n++;
        }
    }
    return n;
}

// ===== ExePatcher: folder pointer remapping =====
void ExePatcher::remap_folder_pointers(const FolderMapping* mappings,uint32_t count,
    uint32_t lba_delta,uint32_t dq4_base_sector,
    uint32_t& abs_matched,uint32_t& abs_delta_count,
    uint32_t& rel_matched)
{
    // Build lookup tables: dw7_sector -> new_abs, old_rel -> new_rel
    // dq4_base_sector = absolute sector where DQ4 HBD starts in the output disc
    // (for hybrid approach: HBD_LBA + DW7_HBD_SECTORS; for pure DQ4: HBD_LBA)
    abs_matched=0; abs_delta_count=0; rel_matched=0;

    // --- ABS table ---
    for(uint32_t i=0;i<MAX_TABLE_ENTRIES;i++){
        uint32_t off=ABS_TABLE_START+i*TABLE_ENTRY_SIZE;
        if(off+4>data.size())break;
        uint32_t val; std::memcpy(&val,data.data()+off,4);
        if(val==0)continue;

        // Check if val matches a dw7_sector in mappings
        bool matched=false;
        for(uint32_t j=0;j<count;j++){
            if(mappings[j].dw7_sector==val){
                uint32_t new_abs=mappings[j].dq4_sector+dq4_base_sector;
                std::memcpy(data.data()+off,&new_abs,4);
                record_patch(off,val,new_abs,"abs_matched");
                abs_matched++;
                matched=true;
                break;
            }
        }
        if(!matched){
            // Unmatched: if in HBD range [354, 0x100000), apply LBA delta
            if(val>=354 && val<0x100000){
                uint32_t new_val=val+lba_delta;
                std::memcpy(data.data()+off,&new_val,4);
                record_patch(off,val,new_val,"abs_delta");
                abs_delta_count++;
            }
        }
    }

    // --- REL table ---
    // REL entries are relative to HBD_LBA. Matched entries need to point to
    // DQ4 folder relative offset = dq4_sector + (dq4_base_sector - HBD_LBA)
    uint32_t rel_adjust=dq4_base_sector-HBD_LBA;
    for(uint32_t i=0;i<MAX_TABLE_ENTRIES;i++){
        uint32_t off=REL_TABLE_START+i*TABLE_ENTRY_SIZE;
        if(off+4>data.size())break;
        uint32_t val; std::memcpy(&val,data.data()+off,4);
        if(val==0)continue;

        // Check if val matches an old_rel (dw7_sector - HBD_LBA)
        for(uint32_t j=0;j<count;j++){
            uint32_t old_rel=mappings[j].dw7_sector-HBD_LBA; // old relative = dw7_sector - 354
            if(old_rel==val){
                uint32_t new_rel=mappings[j].dq4_sector+rel_adjust;
                std::memcpy(data.data()+off,&new_rel,4);
                record_patch(off,val,new_rel,"rel_matched");
                rel_matched++;
                break;
            }
        }
        // Unmatched REL entries: leave unchanged (relative offsets within HBD don't shift)
    }
}

// ===== ExePatcher: compute_tree_addr with sign-extension =====
void ExePatcher::compute_tree_addr(uint32_t target_ram,uint16_t& lui,uint16_t& addiu){
    addiu=target_ram&0xFFFF;
    lui=(target_ram>>16)&0xFFFF;
    if(addiu>=0x8000)lui=(lui+1)&0xFFFF;
}

// ===== Helper: read entire file into vector =====
static std::vector<uint8_t> read_file(const char* path){
    std::ifstream f(path,std::ios::binary|std::ios::ate);
    if(!f.is_open())return {};
    auto sz=f.tellg();
    f.seekg(0);
    std::vector<uint8_t> buf(sz);
    f.read((char*)buf.data(),sz);
    return buf;
}

// ===== Helper: write vector to file =====
static bool write_file(const char* path,const std::vector<uint8_t>& data){
    std::ofstream f(path,std::ios::binary);
    if(!f.is_open())return false;
    f.write((const char*)data.data(),data.size());
    return f.good();
}

// ===== Helper: extract HBD from disc (sector-by-sector) =====
static std::vector<uint8_t> extract_hbd_from_disc(const char* disc_path,
    uint32_t start_sector,uint32_t hbd_size)
{
    std::vector<uint8_t> result;
    result.reserve(hbd_size);
    IsoImage iso;
    if(!iso.open(disc_path))return {};

    std::vector<uint8_t> sector(USER_SIZE);
    uint32_t sector_idx=start_sector;
    uint32_t remaining=hbd_size;
    while(remaining>0){
        if(iso.read_sector(sector_idx,sector.data())<0)break;
        uint32_t take=std::min(remaining,USER_SIZE);
        result.insert(result.end(),sector.begin(),sector.begin()+take);
        remaining-=take;
        sector_idx++;
    }
    iso.close();
    result.resize(hbd_size);
    return result;
}

// ===== Helper: write raw data to disc (multi-sector) =====
static void write_raw_data(IsoImage& iso,uint32_t start_lba,const std::vector<uint8_t>& data){
    uint32_t offset=0;
    uint32_t sector=start_lba;
    std::vector<uint8_t> buf(USER_SIZE,0);
    while(offset<data.size()){
        uint32_t chunk=std::min((uint32_t)USER_SIZE,(uint32_t)(data.size()-offset));
        std::memset(buf.data(),0,USER_SIZE);
        std::memcpy(buf.data(),data.data()+offset,chunk);
        iso.write_sector(sector,buf.data());
        offset+=USER_SIZE;
        sector++;
    }
}

// ===== Helper: update ISO directory (sector 22) =====
static void update_iso_dir(IsoImage& iso,uint32_t exe_size,uint32_t hbd_size,uint32_t hbd_lba){
    std::vector<uint8_t> dir(USER_SIZE,0);
    iso.read_sector(22,dir.data());

    uint32_t offset=0;
    while(offset<dir.size()){
        uint8_t rec_len=dir[offset];
        if(rec_len==0)break;
        uint8_t name_len=dir[offset+32];
        // Check for "HBD" in name
        bool has_hbd=false;
        for(uint32_t i=0;i+2<name_len;i++){
            if(dir[offset+33+i]=='H'&&dir[offset+34+i]=='B'&&dir[offset+35+i]=='D'){
                has_hbd=true; break;
            }
        }
        if(has_hbd){
            // LBA at rec+2 (LE) and rec+6 (BE)
            std::memcpy(dir.data()+offset+2,&hbd_lba,4);
            uint32_t hbd_be=_byteswap_ulong(hbd_lba);
            std::memcpy(dir.data()+offset+6,&hbd_be,4);
            // Size at rec+10 (LE) and rec+14 (BE)
            std::memcpy(dir.data()+offset+10,&hbd_size,4);
            uint32_t size_be=_byteswap_ulong(hbd_size);
            std::memcpy(dir.data()+offset+14,&size_be,4);
        }else if(name_len>=2 && dir[offset+33]=='S'&&dir[offset+34]=='L'&&exe_size>0){
            // EXE entry (SLUSP012.06)
            std::memcpy(dir.data()+offset+10,&exe_size,4);
            uint32_t size_be=_byteswap_ulong(exe_size);
            std::memcpy(dir.data()+offset+14,&size_be,4);
        }
        offset+=rec_len;
    }
    iso.write_sector(22,dir.data());
}

// ===== Helper: update license sector (sector 4) =====
// PSX BIOS and DuckStation determine disc region from the license string
// at sector 4 (LBA 4). The NTSC-J string must be replaced with NTSC-U
// to match the US BIOS (SCPH-5501) and avoid region mismatch stalls.
static void update_license_sector(IsoImage& iso){
    std::vector<uint8_t> sec(USER_SIZE,0);
    iso.read_sector(4,sec.data());

    // NTSC-J: "          Licensed  by          Sony Computer Entertainment Inc.\n"  (70 bytes)
    // NTSC-U: "          Licensed  by          Sony Computer Entertainment Amer  ica " (71 bytes)
    static const char ntsc_j[] = "          Licensed  by          Sony Computer Entertainment Inc.\n";
    static const char ntsc_u[] = "          Licensed  by          Sony Computer Entertainment Amer  ica ";

    // Search for NTSC-J string at start of sector data
    if(std::memcmp(sec.data(),ntsc_j,sizeof(ntsc_j)-1)==0){
        // Clear the old string area (71 bytes to cover both strings)
        std::memset(sec.data(),0x00,71);
        // Write NTSC-U string (does not include null terminator)
        std::memcpy(sec.data(),ntsc_u,sizeof(ntsc_u)-1);
        iso.write_sector(4,sec.data());
        printf("  License sector: NTSC-J -> NTSC-U (Sony Computer Entertainment America)\n");
    } else if(std::memcmp(sec.data(),ntsc_u,sizeof(ntsc_u)-1)==0){
        printf("  License sector: already NTSC-U, no change needed\n");
    } else {
        printf("  WARNING: License sector has unrecognized string, forcing NTSC-U\n");
        std::memset(sec.data(),0x00,71);
        std::memcpy(sec.data(),ntsc_u,sizeof(ntsc_u)-1);
        iso.write_sector(4,sec.data());
    }
}

// ===== Helper: update PVD (sector 16) =====
static void update_pvd(IsoImage& iso){
    std::vector<uint8_t> pvd(USER_SIZE,0);
    iso.read_sector(16,pvd.data());
    // Volume ID at offset 40, 32 bytes, padded with spaces
    // Use DW7 US volume ID to match the US disc profile
    const char* vol_id="DRAGONWARRIOR7_1";
    std::memset(pvd.data()+40,' ',32);
    std::memcpy(pvd.data()+40,vol_id,std::min((size_t)16,strlen(vol_id)));
    // Volume Space Size at offset 80, 8 bytes both-endian (LE+BE)
    uint32_t total_sectors=iso.file_size()/iso.sector_size();
    uint32_t le=total_sectors;
    uint32_t be=((total_sectors&0xFF)<<24)|((total_sectors&0xFF00)<<8)|((total_sectors>>8)&0xFF00)|((total_sectors>>24)&0xFF);
    std::memcpy(pvd.data()+80,&le,4);
    std::memcpy(pvd.data()+84,&be,4);
    printf("  PVD: Volume ID='%s', Volume Space Size=%u sectors\n",vol_id,total_sectors);
    iso.write_sector(16,pvd.data());
}

// ===== Helper: write CUE file =====
static void write_cue(const char* cue_path,const char* bin_name){
    std::ofstream f(cue_path);
    if(!f.is_open())return;
    f<<"FILE \""<<bin_name<<"\" BINARY\n";
    f<<"  TRACK 01 MODE2/2352\n";
    f<<"    INDEX 01 00:00:00\n";
}

// ===== Helper: run edcre.exe via system() =====
// F-7 fix: edcre is passed the BIN file (per Pipeline-A), not the CUE.
// Two-phase: (1) edcre <bin> to compute/repair EDC/ECC, (2) edcre -t <bin> to verify.
// Exit 1 from phase 1 is logged but not fatal (sectors were updated).
// Any non-zero from phase 2 is a hard failure (integrity unproven).
static int run_edcre(const char* edcre_path,const char* bin_path){
    if(!edcre_path||!*edcre_path)return 0;
    // Extract directory and filename from bin_path
    std::string bin_dir=bin_path;
    std::string bin_file=bin_path;
    size_t slash=std::string::npos;
    for(size_t i=bin_path?strlen(bin_path):0;i>0;i--){
        if(bin_path[i-1]=='\\'||bin_path[i-1]=='/'){slash=i-1;break;}
    }
    if(slash!=std::string::npos){
        bin_dir=std::string(bin_path,slash);
        bin_file=std::string(bin_path+slash+1);
    }else{
        bin_dir=".";
        bin_file=bin_path;
    }
    // Save current CWD, change to BIN's directory
    char old_cwd[1024]={0};
    _getcwd(old_cwd,sizeof(old_cwd)-1);
    // Convert edcre_path to absolute (it may be relative to old CWD)
    std::string edcre_abs=edcre_path;
    {
        char abs_buf[2048]={0};
        if(_fullpath(abs_buf,edcre_path,sizeof(abs_buf)-1)){
            edcre_abs=abs_buf;
        }
    }
#if defined(_WIN32)
    _chdir(bin_dir.c_str());
#else
    chdir(bin_dir.c_str());
#endif
    // Phase 1: Run edcre on the BIN file (not CUE — Pipeline-A says BIN)
    std::string cmd="cmd /c \"\"";
    cmd+=edcre_abs;
    cmd+="\" \"";//cmd+=cue_file;//cmd+=bin_file;
    cmd+=bin_file;//cmd+=cue_file;
    cmd+="\"\"";
    printf("  EDC/ECC: running edcre in %s on %s (BIN)\n",bin_dir.c_str(),bin_file.c_str());
    int ec=std::system(cmd.c_str());
    printf("  EDC/ECC: edcre exit code = %d\n",ec);
    // edcre: 0 = nothing needed, 1 = sectors updated
    if(ec!=0 && ec!=1){
        printf("  EDC/ECC: FAILED (exit %d)\n",ec);
#if defined(_WIN32)
        _chdir(old_cwd);
#else
        chdir(old_cwd);
#endif
        return ec;
    }
    if(ec==1){
        printf("  EDC/ECC: sectors were updated (exit 1)\n");
    }
    // Phase 2: Verification pass — edcre -t to verify EDC/ECC integrity
    std::string cmd_verify="cmd /c \"\"";
    cmd_verify+=edcre_abs;
    cmd_verify+="\" -t \"";//cmd_verify+=cue_file;//cmd_verify+=bin_file;
    cmd_verify+=bin_file;//cmd_verify+=cue_file;
    cmd_verify+="\"\"";
    printf("  EDC/ECC: running edcre -t (verification pass)\n");
    int ec2=std::system(cmd_verify.c_str());
    printf("  EDC/ECC: edcre -t exit code = %d\n",ec2);
    // Restore CWD
#if defined(_WIN32)
    _chdir(old_cwd);
#else
    chdir(old_cwd);
#endif
    // Verification pass: 0 = all sectors valid, anything else = integrity failure
    if(ec2!=0){
        printf("  EDC/ECC: VERIFICATION FAILED (exit %d) — disc integrity unproven\n",ec2);
        return ec2;
    }
    printf("  EDC/ECC: VERIFIED (all sectors valid)\n");
    return 0;
}

// ===== Helper: parse folder_mapping.json (minimal JSON parser) =====
// We only need dw7_sector and dq4_sector from each mapping entry.
// The JSON format is: {"mappings":[{"dw7_sector":499,"dq4_sector":100841,...},...]}
static std::vector<FolderMapping> parse_folder_mappings(const char* path){
    std::vector<FolderMapping> result;
    std::ifstream f(path);
    if(!f.is_open())return result;
    std::string content((std::istreambuf_iterator<char>(f)),
                         std::istreambuf_iterator<char>());
    // Simple state machine: find "dw7_sector":<num> and "dq4_sector":<num> pairs
    size_t pos=0;
    while(pos<content.size()){
        // Find next "dw7_sector"
        size_t dw7_pos=content.find("\"dw7_sector\"",pos);
        if(dw7_pos==std::string::npos)break;
        // Skip to ':'
        size_t colon=content.find(':',dw7_pos);
        if(colon==std::string::npos)break;
        // Parse number
        uint32_t dw7_sec=0;
        size_t num_start=colon+1;
        while(num_start<content.size()&&(content[num_start]==' '||content[num_start]=='\t'))num_start++;
        while(num_start<content.size()&&content[num_start]>='0'&&content[num_start]<='9'){
            dw7_sec=dw7_sec*10+(content[num_start]-'0');
            num_start++;
        }
        // Find "dq4_sector" after this
        size_t dq4_pos=content.find("\"dq4_sector\"",num_start);
        if(dq4_pos==std::string::npos)break;
        colon=content.find(':',dq4_pos);
        if(colon==std::string::npos)break;
        uint32_t dq4_sec=0;
        num_start=colon+1;
        while(num_start<content.size()&&(content[num_start]==' '||content[num_start]=='\t'))num_start++;
        while(num_start<content.size()&&content[num_start]>='0'&&content[num_start]<='9'){
            dq4_sec=dq4_sec*10+(content[num_start]-'0');
            num_start++;
        }
        result.push_back({dw7_sec,dq4_sec});
        pos=num_start;
    }
    return result;
}

// ===== Semi-surgical disc-check patch data (10 patches, no cd_init) =====
// These are the exact byte sequences from the Python DISC_CHECK_PATCHES
// excluding cd_init_force_success.
static const uint8_t dc_patch1[]={0x01,0x00,0x02,0x24};  // 0x6112C: addiu v0,zero,1 (LE: 0x24020001)
static const uint8_t dc_patch2[]={0x01,0x00,0x02,0x24};  // 0x611D8: addiu v0,zero,1
static const uint8_t dc_patch3[]={0x01,0x00,0x02,0x24};  // 0x613B8: addiu v0,zero,1
static const uint8_t dc_patch4[]={0x00,0x00,0x00,0x00};  // 0x614A4: nop
static const uint8_t dc_patch5[]={0x00,0x00,0x00,0x00};  // 0x614F8: nop
static const uint8_t dc_patch6[]={0x08,0x00,0xE0,0x03,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00}; // 0x387CC: jr ra + nop + nop
static const uint8_t dc_patch7[]={0xE9,0x2B,0x02,0x08};  // 0x7308C: j 0x800A2BE8 (redirect)
static const uint8_t dc_patch8[]={0x0B,0x00,0x00,0x10};  // 0x61424: beq zero,zero (always)
static const uint8_t dc_patch9[]={0x0B,0x00,0x00,0x10};  // 0x61520: beq zero,zero (always)
static const uint8_t dc_patch10[]={0x0A,0x00,0x00,0x10}; // 0x61360: beq zero,zero (always)

static const DiscCheckPatch SEMI_SURGICAL_PATCHES[10]={
    {0x6112C,4,dc_patch1,"disc_check_exit1_return_success"},
    {0x611D8,4,dc_patch2,"disc_check_exit2_return_success"},
    {0x613B8,4,dc_patch3,"disc_check_exit3_return_success"},
    {0x614A4,4,dc_patch4,"nop_timeout_check"},
    {0x614F8,4,dc_patch5,"nop_error_path"},
    {0x387CC,12,dc_patch6,"neutralize_disc_change_handler"},
    {0x7308C,4,dc_patch7,"redirect_disc_trap_to_success"},
    {0x61424,4,dc_patch8,"graft_a_gate1_always_skip_disc_change"},
    {0x61520,4,dc_patch9,"graft_b_gate3_always_skip_disc_change"},
    {0x61360,4,dc_patch10,"graft_c_string_compare_always_match"},
};

// ===== ExePatcher::patch_hbd_type_trampoline =====
// Patches 0x800562E4 to JAL trampoline and appends DQ4 sub-block type handler.
//
// Block loader function at 0x800561B8 (file 0x3EAB8):
//   0x800562B8: lw $s1, 12($s4)        # text sub-block pointer (tree hook site)
//   0x800562C0: beq $s1, $zero, ...    # null check
//   0x800562C8: lw $s3, 0($s1)         # first 32-bit word of sub-block entry
//   0x800562DC: srl $v1, $s3, 16       # $v1 = upper16
//   0x800562E0: andi $s3, $s3, 0xFFFF  # $s3 = lower16
//   0x800562E4: beq $s3, $zero, ...    # ← PATCHED to JAL trampoline
//   0x800562E8: sh $v1, 1336($v0)      # DELAY SLOT — replaced with nop
//
// DW7 semantics: lower16 = count, upper16 = tree index
// DQ4 semantics: lower16 = type (32,39,40,42,46), upper16 = count
//
// Trampoline entry state:
//   $s3 = lower16 (DW7: count, DQ4: type)
//   $v1 = upper16 (DW7: tree index, DQ4: count)
//   $v0 = 0x800E0000 (from lui at 0x800562D8)
//   $ra = 0x800562EC (return point after JAL+delay — not used, trampoline jumps)
//   $sp = already adjusted by parent (-48), MUST NOT BE TOUCHED
//
// Delay slot at 0x800562E8 replaced with nop. Original sh $v1,1336($v0)
// is re-executed in .not_dq4 path. For DQ4 path, store 0 instead.
// Trampoline jumps to 0x8005631C (second-pair processing) — never returns via $ra.
bool ExePatcher::patch_hbd_type_trampoline(){
    uint32_t patch_off=0x800562E4 - load_addr + 0x800;
    if(patch_off+8 > data.size()){
        printf("  ERROR: trampoline patch offset 0x%X beyond EXE size %zu\n",patch_off,data.size());
        return false;
    }

    uint32_t orig=*(uint32_t*)(data.data()+patch_off);
    if(orig!=0x1260000D){
        printf("  ABORT: original at 0x%X is 0x%08X (expected 0x1260000D) — wrong base EXE?\n",patch_off,orig);
        return false;
    }

    // Patch: JAL to trampoline + nop (replaces beq $s3,$zero + delay slot sh)
    uint32_t tramp_ram=tramp_base;
    uint32_t jal_insn=0x0C000000 | ((tramp_ram >> 2) & 0x03FFFFFF);
    *(uint32_t*)(data.data()+patch_off)=jal_insn;
    *(uint32_t*)(data.data()+patch_off+4)=0x00000000;
    printf("  Patched 0x800562E4: jal 0x%08X + nop\n",tramp_ram);

    // Pad to reach trampoline RAM
    uint32_t current_end_ram=load_addr + (uint32_t)data.size() - 0x800;
    if(tramp_ram < current_end_ram){
        printf("  ERROR: trampoline RAM 0x%08X overlaps EXE end 0x%08X\n",tramp_ram,current_end_ram);
        return false;
    }
    uint32_t pad_bytes=tramp_ram - current_end_ram;
    if(pad_bytes>0){
        data.insert(data.end(),pad_bytes,0);
        printf("  Padded %u bytes to trampoline at 0x%08X\n",pad_bytes,tramp_ram);
    }

    // Trampoline: 27 MIPS instructions (108 bytes)
    // Register usage: $t2 = scratch for type compare, $sp PRESERVED
    // No stack push/pop — $sp untouched, $ra already set by JAL
    // $v0 = 0x800E0000 preserved from lui at 0x8005F748
    //
    // CRITICAL: original delay slot (sh $v1,1336($v0)) at 0x8005F758 is
    // replaced by nop. Must re-execute sh in .not_dq4 path for DW7 compat.
    static const uint32_t tramp[]={
        // Type dispatch: check $s3 directly (no memory read needed)
        0x240A0027,  // 0:  addiu $t2, $zero, 39
        0x126A0014,  // 1:  beq  $s3, $t2, .dq4 (+20→idx22)
        0x00000000,  // 2:  nop
        0x240A0028,  // 3:  addiu $t2, $zero, 40
        0x126A0011,  // 4:  beq  $s3, $t2, .dq4 (+17→idx22)
        0x00000000,  // 5:  nop
        0x240A002A,  // 6:  addiu $t2, $zero, 42
        0x126A000E,  // 7:  beq  $s3, $t2, .dq4 (+14→idx22)
        0x00000000,  // 8:  nop
        0x240A002E,  // 9:  addiu $t2, $zero, 46
        0x126A000B,  // 10: beq  $s3, $t2, .dq4 (+11→idx22)
        0x00000000,  // 11: nop
        0x240A0020,  // 12: addiu $t2, $zero, 32
        0x126A0008,  // 13: beq  $s3, $t2, .dq4 (+8→idx22)
        0x00000000,  // 14: nop
        // BAD-5 (Jul 28 2026): the DW7 runtime tree-build store loop must not run
        // on DQ4 directory records. DW7 semantics (lower16=count, upper16=start)
        // do not hold for DQ4: observed "start" values up to ~2978 wrote halfwords
        // past the relocated hybrid tree at 0x800BC700 into THIS trampoline
        // (idx>=1024), the CD intercept (idx>=1152), and live BSS globals
        // 0x800BDAE0/0x800BDE40 (idx 2544/2976). Corrupted trampoline code then
        // branched to 0x800BDE44 and executed the halfword pair [0xC7D0,0x800B]
        // as `lb $t3,-0x3830($zero)` -> invalid read 0xFFFFC7D0 -> hang.
        // Both paths now force count=0 and jump straight to second-pair
        // processing (0x8005631C), preserving the retail seed-slot stores at
        // 0x800E0538/0x800E162C while eliminating every dynamic tree store.
        // The static hybrid tree at 0x800BC700 remains the decompression tree.
        // .not_dq4: re-execute original delay slot (sh $v1, 1336($v0))
        0xA4430538,  // 15: sh   $v1, 1336($v0)    — original DW7 behavior
        0x00009821,  // 16: addu $s3, $zero, $zero — BAD-5: count=0 (no store loop)
        0x00000000,  // 17: nop
        0x080158C7,  // 18: j    0x8005631C        — skip loop 1 to second-pair processing
        0x00000000,  // 19: nop
        // .skip (dead — kept for layout stability):
        0x080158D9,  // 20: j    0x80056364        — unreachable
        0x00000000,  // 21: nop
        // .dq4_handler:
        // Overwrite 0x800E0538 (delay slot stored wrong value), count=0, skip loop.
        0x00009821,  // 22: addu $s3, $zero, $zero — BAD-5: count=0 (no store loop)
        0x00001821,  // 23: addu $v1, $zero, $zero — $v1 = 0 (tree root)
        0xA4400538,  // 24: sh   $zero, 1336($v0)  — store 0 to 0x800E0538
        0x080158C7,  // 25: j    0x8005631C        — skip loop 1 to second-pair processing
        0x00000000,  // 26: nop
    };

    data.insert(data.end(),(const uint8_t*)tramp,(const uint8_t*)tramp+sizeof(tramp));
    printf("  Appended trampoline: %zu bytes at RAM 0x%08X\n",sizeof(tramp),tramp_ram);

    update_text_size();
    return true;
}

// ===== ExePatcher::zero_pre_tree_bss =====
// Zero the 152-byte region 0x800BC668-0x800BC700 that was originally
// cleared by BSS but is now skipped because BSS start moved past the tree.
// This region contains a base pointer at 0x800BC6CC used by the thread
// status polling loop at PC 0x80048004. Non-zero garbage here causes
// the loop to read invalid memory and stall.
void ExePatcher::zero_pre_tree_bss(){
    uint32_t start_off=PRE_TREE_BSS_START - load_addr + 0x800;
    uint32_t end_off=PRE_TREE_BSS_END - load_addr + 0x800;
    if(end_off>data.size()){
        printf("  ERROR: pre-tree BSS region beyond EXE size\n");
        return;
    }
    std::memset(data.data()+start_off,0,PRE_TREE_BSS_LEN);
    printf("  Zeroed pre-tree BSS: 0x%08X-0x%08X (%u bytes)\n",
        PRE_TREE_BSS_START,PRE_TREE_BSS_END,PRE_TREE_BSS_LEN);
}

// ===== Decompressor Target 4: Tree pointer → runtime variable =====
// Patches the two addiu instructions at 0x800562F0 and 0x80056338 that
// load the hardcoded tree base (0x800EF1C8 → 0x800BC700 after tree ref patch).
// Replaces each addiu $v0,$v0,imm with lw $v0,0xC6F8($at) where
// $at ($1) points to the runtime variable at 0x800BC6F8.
// The variable is initialized with the tree address by the copy routine.
//
// Original code at 0x800562EC-0x800562F8:
//   lui $v0,0x800F        ; 0x3C02800F
//   addiu $v0,$v0,-3640   ; 0x2442F1C8  ← patch this
//   sll $v1,$v1,1         ; 0x00031840  ← UNTOUCHED (load-delay slot)
//   addu $s0,$v1,$v0      ; 0x00628021
//
// We replace lui+addiu with:
//   lui $at,0x800C        ; 0x3C01800C  (replaces lui $v0,0x800F)
//   lw $v0,0xC6F8($at)    ; 0x8C02C6F8  (loads from runtime variable)
//   sll $v1,$v1,1         ; 0x00031840  (untouched — natural load-delay slot)
//
// Similarly for site 2 at 0x80056334-0x80056340.
bool ExePatcher::patch_decomp_tree_pointer(){
    // Site 1: 0x800562EC (lui) + 0x800562F0 (addiu) + 0x800562F4 (sll/delay)
    // Site 2: 0x80056334 (lui) + 0x80056338 (addiu) + 0x8005633C (sll/delay)
    //
    // Strategy: Replace the lui+addiu pair that loads the tree base with
    // a sequence that loads from a runtime variable. We use $at ($reg 1)
    // as a scratch since it's not used in these code paths.
    //
    // For each site, we patch 2 consecutive instructions (NOT 3):
    //   lui $reg,0x800F       → lui $at,0x800C        (set up variable addr hi)
    //   addiu $reg,$reg,imm   → lw  $reg,0xC6F8($at)  (load tree base from variable)
    //   (third slot: sll $v1,$v1,1 — UNTOUCHED, fills load-delay slot naturally)
    //
    // This way $reg gets the tree base from memory instead of immediate.
    // The third slot (sll $v1,$v1,1) is NOT clobbered — it serves as the
    // natural load-delay slot for the lw instruction.

    const uint32_t sites[2][2] = {
        // {lui_off, addiu_off}
        {DECOMP_TREE_PTR1_OFF - 4, DECOMP_TREE_PTR1_OFF},  // 0x3EBEC, 0x3EBF0 (RAM 0x800562EC/F0)
        {DECOMP_TREE_PTR2_OFF - 4, DECOMP_TREE_PTR2_OFF},  // 0x3EC34, 0x3EC38 (RAM 0x80056334/38)
    };

    // Runtime variable address: 0x800BC6F8
    // lui $at, 0x800C = 0x3C01800C
    // lw $rt, 0xC6F8($at) — 0xC6F8 as signed 16-bit = -14920
    //   0x800C0000 + (int16_t)0xC6F8 = 0x800C0000 - 0x3908 = 0x800BC6F8
    const uint32_t var_lui  = 0x3C01800C;  // lui $at, 0x800C

    bool ok = true;
    for (int s = 0; s < 2; s++) {
        uint32_t lui_off = sites[s][0];
        uint32_t addiu_off = sites[s][1];

        if (addiu_off + 4 > data.size()) {
            printf("  ERROR: decomp tree ptr site %d beyond EXE size\n", s);
            ok = false; continue;
        }

        // Read original instructions
        uint32_t orig_lui, orig_addiu;
        std::memcpy(&orig_lui, data.data() + lui_off, 4);
        std::memcpy(&orig_addiu, data.data() + addiu_off, 4);

        // Verify: lui opcode (0x0F) and addiu opcode (0x09)
        if ((orig_lui >> 26) != 0x0F || (orig_addiu >> 26) != 0x09) {
            printf("  ERROR: decomp tree ptr site %d: expected lui+addiu, got 0x%08X+0x%08X\n",
                s, orig_lui, orig_addiu);
            ok = false; continue;
        }

        // Get the destination register from the original lui
        uint8_t rt = (orig_lui >> 16) & 0x1F;

        // New instructions (2-instruction form, no third slot clobber):
        // lui $at, 0x800C
        uint32_t new_lui = var_lui;
        // lw $rt, 0xC6F8($at) — load tree base from runtime variable
        uint32_t new_addiu = MIPS_LW(rt, 0xC6F8, 1);  // lw $rt, 0xC6F8($at)

        std::memcpy(data.data() + lui_off, &new_lui, 4);
        std::memcpy(data.data() + addiu_off, &new_addiu, 4);

        record_patch(lui_off, orig_lui, new_lui, "decomp_tree_ptr_lui");
        record_patch(addiu_off, orig_addiu, new_addiu, "decomp_tree_ptr_load");

        printf("  Decompressor tree ptr site %d: lui+lw patched (reg=$%u, var=0x%08X) — 2-instruction form\n",
            s, rt, TREE_PTR_VAR_RAM);
    }

    // The runtime variable at 0x800BC6F8 is initialized by the build function
    // (build_v39 or build_reverse_option_a) AFTER zero_pre_tree_bss() zeros the
    // pre-tree BSS region. The variable stores the RAW tree base address (no +2).
    // Sites 1&2 load from this variable for tree writes (child pointers are
    // already 1-based in DQ4 format, so no +1 offset needed).
    // Site 3 (root lookup) is patched separately by patch_decomp_root_id_plus1()
    // or patch_decomp_root_id_runtime() to add +2 to the tree base immediate,
    // implementing DQ4's root_id = (value & 0x7FFF) + 1 convention.
    // The R-TREEHOOK stub (patch_tree_hook) updates this variable with per-block
    // tree addresses at runtime, also storing raw tree_base (no +2).

    return ok;
}

// ===== Decompressor Target 5: Root ID +1 =====
// DQ4 uses root_id = (value & 0x7FFF) + 1, DW7 uses root_id = value & 0x7FFF.
// At 0x80057FF4: addiu $v1,$v1,imm (tree base low half)
// The tree base is added to root_id: addu $v0,$v0,$v1 at 0x80058000
// Adding +2 to the immediate effectively adds +1 to the root node index
// (since nodes are 2 bytes each).
// NOTE: patch_tree_references may have already changed the immediate from
// 0xF1C8 to 0xC700 (or whatever the new tree address low half is).
// We add +2 to whatever the current immediate is.
bool ExePatcher::patch_decomp_root_id_plus1(){
    uint32_t off = DECOMP_ROOT_ID_OFF;  // 0x408F4 (file offset, RAM 0x80057FF4)
    if (off + 4 > data.size()) {
        printf("  ERROR: root_id patch offset beyond EXE size\n");
        return false;
    }

    uint32_t orig;
    std::memcpy(&orig, data.data() + off, 4);

    // Verify: addiu opcode (0x09)
    if ((orig >> 26) != 0x09) {
        printf("  ERROR: root_id patch: expected addiu, got 0x%08X\n", orig);
        return false;
    }

    uint16_t cur_imm = (uint16_t)(orig & 0xFFFF);
    // Add +2 to the current immediate (handles both pre- and post-tree-ref-patch values)
    uint16_t new_imm = (uint16_t)(cur_imm + 2);

    uint32_t patched = (orig & 0xFFFF0000) | new_imm;
    std::memcpy(data.data() + off, &patched, 4);
    record_patch(off, orig, patched, "decomp_root_id_plus1");

    printf("  Root ID +1: 0x%08X → 0x%08X (addiu immediate 0x%04X → 0x%04X)\n",
        orig, patched, cur_imm, new_imm);
    return true;
}

// ===== Decompressor Target 5R: Root ID +1 (Runtime variant) =====
// Same purpose as Target 5 but loads tree base from runtime variable
// instead of using a hardcoded immediate. This supports per-block trees
// updated by R-TREEHOOK, where the tree address changes at runtime.
//
// CRITICAL: Site 3 has an intervening lhu between lui and addiu:
//   0x80057FEC: lui   $v1, 0x800F        ← PATCHED to JAL stub
//   0x80057FF0: lhu   $v0, 24($sp)      ← JAL delay slot (USEFUL — loads $v0)
//   0x80057FF4: addiu $v1, $v1, -3640   ← PATCHED to nop
//   0x80057FF8: andi  $v0, $v0, 0x7FFF  ← execution resumes here
//   0x80057FFC: sll   $v0, $v0, 1
//   0x80058000: addu  $v0, $v0, $v1     ← uses $v1 from stub (no hazard: 4 instr delay)
//
// The lhu in the delay slot loads $v0 from the stack, which is needed by
// the andi instruction. The stub sets $v1 = tree_base+2 and returns to
// the andi at 0x80057FF8. The andi/sll/addu sequence then uses $v1
// from the stub with sufficient delay (no load-delay hazard).
//
// Stub (6 instructions, 24 bytes):
//   addiu $ra,$ra,4      // $ra = 0x80057FF8 (skip nop, go to andi)
//   lui   $at,0x800C     // $at = 0x800C0000
//   lw    $v1,0xC6FC($at) // $v1 = tree_base+2 from 0x800BC6FC
//   nop                   // load delay slot
//   jr    $ra             // return to 0x80057FF8
//   nop                   // jr delay slot
bool ExePatcher::patch_decomp_root_id_runtime(){
    // Site 3 has intervening lhu: lui at OFF-8, lhu at OFF-4, addiu at OFF
    uint32_t lui_off = DECOMP_ROOT_ID_OFF - 8;   // 0x408EC (RAM 0x80057FEC)
    uint32_t addiu_off = DECOMP_ROOT_ID_OFF;      // 0x408F4 (RAM 0x80057FF4)

    if (addiu_off + 4 > data.size()) {
        printf("  ERROR: root_id runtime patch offset beyond EXE size\n");
        return false;
    }

    // Verify: lui opcode (0x0F) at lui_off and addiu opcode (0x09) at addiu_off
    // Note: there is a lhu at lui_off+4 (delay slot) — we do NOT check it
    uint32_t orig_lui, orig_addiu;
    std::memcpy(&orig_lui, data.data() + lui_off, 4);
    std::memcpy(&orig_addiu, data.data() + addiu_off, 4);

    // Verify: lui opcode (0x0F) and addiu opcode (0x09)
    // NOTE: patch_tree_references may have changed the lui immediate from
    // 0x800F to the new tree address upper half. The opcode is still lui.
    if ((orig_lui >> 26) != 0x0F || (orig_addiu >> 26) != 0x09) {
        printf("  ERROR: root_id runtime: expected lui+addiu, got 0x%08X+0x%08X\n",
            orig_lui, orig_addiu);
        return false;
    }

    // Verify destination register is $v1 (reg 3) — the stub hardcodes $v1
    uint8_t rt = (orig_lui >> 16) & 0x1F;
    if (rt != 3) {
        printf("  ERROR: root_id runtime: expected target reg $v1 (3), got $%u\n", rt);
        return false;
    }

    // Compute stub address: place at tramp_base + 0x200 (outside BSS clear range)
    // CRITICAL: Must NOT append at current end of EXE, because that lands inside
    // the narrowed BSS clear range (0x800BCCC8-0x800D9E80) and gets zeroed at runtime.
    uint32_t stub_ram = tramp_base + ROOT_ID_RUNTIME_TRAMP_OFFSET;
    uint32_t stub_file = stub_ram - load_addr + 0x800;
    uint32_t current_end_ram = load_addr + (uint32_t)data.size() - 0x800;

    // Pad EXE data to reach stub address
    if (stub_ram < current_end_ram) {
        printf("  ERROR: root_id runtime stub RAM 0x%08X overlaps EXE end 0x%08X\n",
            stub_ram, current_end_ram);
        return false;
    }
    uint32_t pad = stub_ram - current_end_ram;
    if (pad > 0) {
        data.insert(data.end(), pad, 0);
    }
    // Ensure data is large enough for the stub (6 instructions = 24 bytes)
    if (stub_file + 24 > data.size()) {
        data.resize(stub_file + 24, 0);
    }

    // Patch site: JAL to stub + nop in delay slot
    uint32_t jal_insn = MIPS_JAL(stub_ram);
    uint32_t nop_insn = MIPS_NOP;

    std::memcpy(data.data() + lui_off, &jal_insn, 4);
    std::memcpy(data.data() + addiu_off, &nop_insn, 4);

    record_patch(lui_off, orig_lui, jal_insn, "decomp_root_id_runtime_jal");
    record_patch(addiu_off, orig_addiu, nop_insn, "decomp_root_id_runtime_nop");

    // Root ID runtime stub: 6 instructions (24 bytes)
    // $ra = 0x80057FF4 (set by JAL, after delay slot lhu at 0x80057FF0)
    // addiu $ra,$ra,4 → $ra = 0x80057FF8 (skip nop, go to andi)
    // The andi/sll/addu sequence at 0x80057FF8-0x80058000 uses $v1 from stub
    // with 4 instructions of delay after lw — no load-delay hazard.
    static const uint32_t stub[] = {
        0x27FF0004,  // 0: addiu $ra,$ra,4       — skip nop at 0x80057FF4, go to andi at 0x80057FF8
        0x3C01800C,  // 1: lui   $at,0x800C      — $at = 0x800C0000
        0x8C23C6FC,  // 2: lw    $v1,0xC6FC($at) — $v1 = tree_base+2 from 0x800BC6FC
        0x00000000,  // 3: nop                    — load delay slot
        0x03E00008,  // 4: jr    $ra              — return to 0x80057FF8 (andi)
        0x00000000,  // 5: nop                    — jr delay slot
    };

    // Write stub at fixed file offset (not append — stub is at tramp_base + 0x200)
    std::memcpy(data.data() + stub_file, stub, sizeof(stub));

    printf("  Root ID +1 (runtime): JAL stub at 0x%08X (file 0x%X, %zu bytes) — load-delay safe, outside BSS\n",
        stub_ram, stub_file, sizeof(stub));

    update_text_size();
    return true;
}

// ===== Decompressor Target 6: Offset_b mask removal =====
// DW7 forces offset_b to be even with: andi $v0,$v0,0xFFFE
// DQ4 requires odd offset_b values. Replace with nop.
bool ExePatcher::patch_decomp_offset_b_mask(){
    uint32_t off = DECOMP_OFFSET_B_OFF;  // 0x7CAA4 (file offset, RAM 0x800941A4)
    if (off + 4 > data.size()) {
        printf("  ERROR: offset_b patch offset beyond EXE size\n");
        return false;
    }

    uint32_t orig;
    std::memcpy(&orig, data.data() + off, 4);

    // Verify: andi instruction (opcode 0x0C = 0b001100) with mask 0xFFFE
    if ((orig >> 26) != 0x0C) {
        printf("  ERROR: offset_b patch: expected andi, got 0x%08X\n", orig);
        return false;
    }
    if ((orig & 0xFFFF) != 0xFFFE) {
        printf("  ERROR: offset_b patch: expected mask 0xFFFE, got 0x%04X\n", orig & 0xFFFF);
        return false;
    }

    // Replace with nop
    uint32_t patched = 0x00000000;
    std::memcpy(data.data() + off, &patched, 4);
    record_patch(off, orig, patched, "decomp_offset_b_mask");

    printf("  Offset_b mask removal: 0x%08X → nop (0x00000000)\n", orig);
    return true;
}

// ===== ExePatcher::patch_tree_hook (R-TREEHOOK / BUG-3) =====
// Hooks the block loader at 0x800562B8 where lw $s1,12($s4) loads the
// text sub-block pointer. Replaces it with JAL to a stub that:
//   1. Executes the original lw $s1,12($s4)
//   2. Reads text_end from block header at $s1+16
//   3. Reads tree_start from $s1+text_end (DQ4 per-block tree metadata)
//   4. Computes tree_addr = $s1 + tree_start
//   5. Stores tree_addr to runtime variable at 0x800BC6F8
// The stub returns to 0x800562C0 (original beq $s1,$zero null check),
// so the rest of the block loader proceeds normally with $s1 set.
// If text_end==0 (DW7 blocks without per-block trees), the stub skips
// the update and leaves the hybrid tree fallback in the variable.
bool ExePatcher::patch_tree_hook(){
    uint32_t patch_off = 0x800562B8 - load_addr + 0x800;  // file 0x3EBB8
    if(patch_off + 4 > data.size()){
        printf("  ERROR: tree hook patch offset 0x%X beyond EXE size %zu\n",patch_off,data.size());
        return false;
    }

    uint32_t orig = *(uint32_t*)(data.data() + patch_off);
    if(orig != 0x8E91000C){
        printf("  ABORT: original at 0x800562B8 is 0x%08X (expected 0x8E91000C = lw s1,12(s4)) — wrong base EXE?\n", orig);
        return false;
    }

    // Stub address: append at current end of EXE data
    uint32_t current_end_ram = load_addr + (uint32_t)data.size() - 0x800;
    uint32_t stub_ram = (current_end_ram + 3) & ~3u;  // align to 4

    // Pad to reach stub_ram if needed
    if(stub_ram > current_end_ram){
        uint32_t pad = stub_ram - current_end_ram;
        data.insert(data.end(), pad, 0);
    }

    // Patch: JAL to stub (delay slot at 0x800562BC is already nop)
    uint32_t jal_insn = 0x0C000000 | ((stub_ram >> 2) & 0x03FFFFFF);
    *(uint32_t*)(data.data() + patch_off) = jal_insn;
    printf("  Patched 0x800562B8: jal 0x%08X (tree hook stub)\n", stub_ram);

    // Tree hook stub: 16 instructions (64 bytes)
    // Register usage: $t0, $t1, $at = scratch (caller-saved)
    // $s1 = set by stub (replaces original lw)
    // $s4 = block structure pointer (read-only, preserved)
    // $ra = return address (set by JAL, points to 0x800562C0)
    //
    // DQ4 block header layout (24 bytes):
    //   [0]  end_marker
    //   [4]  block_id
    //   [8]  hts (text start offset)
    //   [12] tree_end (tree end offset)
    //   [16] text_end (text end offset; tree metadata follows)
    //   [20] unknown
    // Tree metadata at [text_end]:
    //   [text_end+0] tree_start (32-bit offset within block)
    //   [text_end+4] tree_middle
    //   [text_end+8] tree_nodes (16-bit)
    //
    // tree_addr = block_base + tree_start
    static const uint32_t stub[] = {
        0x8E91000C,  // 0:  lw   $s1, 12($s4)       — original instruction
        0x00000000,  // 1:  nop                      — load delay slot
        0x1220000D,  // 2:  beq  $s1, $zero, +13     — if null, skip to .skip (idx 16)
        0x00000000,  // 3:  nop                      — branch delay slot
        0x8E080010,  // 4:  lw   $t0, 16($s1)        — load text_end from block header
        0x00000000,  // 5:  nop                      — load delay slot
        0x11000009,  // 6:  beq  $t0, $zero, +9      — if text_end==0, no per-block tree
        0x00000000,  // 7:  nop                      — branch delay slot
        0x02114021,  // 8:  addu $t0, $s1, $t0       — t0 = block_base + text_end
        0x8D090000,  // 9:  lw   $t1, 0($t0)         — load tree_start from metadata
        0x00000000,  // 10: nop                      — load delay slot
        0x02315021,  // 11: addu $t1, $s1, $t1       — t1 = tree_addr = block_base + tree_start
        0x3C01800C,  // 12: lui  $at, 0x800C         — at = 0x800C0000
        0xAC29C6F8,  // 13: sw   $t1, 0xC6F8($at)    — store tree_addr to 0x800BC6F8 (raw, for Sites 1&2)
        0x25290002,  // 14: addiu $t1, $t1, 2        — t1 = tree_addr + 2 (for root_id +1)
        0xAC29C6FC,  // 15: sw   $t1, 0xC6FC($at)    — store tree_addr+2 to 0x800BC6FC (for Site 3)
        0x03E00008,  // 16: jr   $ra                 — .skip: return to 0x8005F730
        0x00000000,  // 17: nop                      — jr delay slot
    };

    data.insert(data.end(), (const uint8_t*)stub, (const uint8_t*)stub + sizeof(stub));
    printf("  Appended tree hook stub: %zu bytes at RAM 0x%08X\n", sizeof(stub), stub_ram);

    record_patch(patch_off, orig, jal_insn, "tree_hook_jal");

    update_text_size();
    return true;
}

// ===== P2-4: Patch recording helpers =====
void ExePatcher::record_patch(uint32_t file_offset, uint32_t orig, uint32_t patched, const char* name){
    PatchRecord rec;
    rec.offset = file_offset;
    rec.original_value = orig;
    rec.patched_value = patched;
    rec.ram_addr = load_addr + file_offset - 0x800;
    rec.reverted = false;
    if(name){
        std::strncpy(rec.patch_name, name, sizeof(rec.patch_name)-1);
        rec.patch_name[sizeof(rec.patch_name)-1] = 0;
    } else {
        rec.patch_name[0] = 0;
    }
    patch_history.push_back(rec);
}

void ExePatcher::record_patch16(uint32_t file_offset, uint16_t orig16, uint16_t patched16, const char* name){
    // Read the full 32-bit word to preserve upper 16 bits
    uint32_t orig32 = 0, patched32 = 0;
    if(file_offset + 4 <= data.size()){
        std::memcpy(&orig32, data.data() + file_offset, 4);
    }
    // We record AFTER the patch was applied, so data already has patched value.
    // Reconstruct original by replacing lower 16 bits.
    orig32 = (orig32 & 0xFFFF0000) | orig16;
    patched32 = (orig32 & 0xFFFF0000) | patched16;
    record_patch(file_offset, orig32, patched32, name);
}

// ===== Parse and apply hotfixes from file =====
bool ExePatcher::patch_hotfixes(const char* hotfix_file_path) {
    if (!hotfix_file_path || !*hotfix_file_path) return true;
    std::ifstream file(hotfix_file_path);
    if (!file.is_open()) {
        printf("  [HOTFIX] Warning: Cannot open hotfix file %s\n", hotfix_file_path);
        return false;
    }
    std::string line;
    int count = 0;
    while (std::getline(file, line)) {
        // Strip comments and whitespace
        auto comment = line.find('#');
        if (comment != std::string::npos) line = line.substr(0, comment);
        while (!line.empty() && std::isspace(line.back())) line.pop_back();
        size_t start = 0;
        while (start < line.length() && std::isspace(line[start])) start++;
        line = line.substr(start);
        if (line.empty()) continue;

        // Format: 0x80041234:0x24020001:patch_name
        size_t first_colon = line.find(':');
        size_t second_colon = line.find(':', first_colon + 1);
        if (first_colon == std::string::npos || second_colon == std::string::npos) {
            printf("  [HOTFIX] Error: Invalid hotfix format: %s\n", line.c_str());
            continue;
        }

        std::string addr_str = line.substr(0, first_colon);
        std::string val_str = line.substr(first_colon + 1, second_colon - first_colon - 1);
        std::string name = line.substr(second_colon + 1);

        try {
            uint32_t ram = std::stoul(addr_str, nullptr, 16);
            uint32_t val = std::stoul(val_str, nullptr, 16);
            
            uint32_t orig = read32(ram);
            write32(ram, val);
            record_patch(ram_to_offset(ram), orig, val, ("hotfix:" + name).c_str());
            printf("  [HOTFIX] Applied %s: 0x%08X -> 0x%08X (was 0x%08X)\n", name.c_str(), ram, val, orig);
            count++;
        } catch (...) {
            printf("  [HOTFIX] Error parsing hex values in: %s\n", line.c_str());
        }
    }
    printf("  [HOTFIX] Total hotfixes applied: %d\n", count);
    return true;
}

void ExePatcher::disasm_range(uint32_t start_ram, uint32_t end_ram) const {
    printf("  [MIPS DISASM] Dumping 0x%08X - 0x%08X:\n", start_ram, end_ram);
    for (uint32_t ram = start_ram; ram < end_ram; ram += 4) {
        if (ram < load_addr || ram >= load_addr + (uint32_t)data.size()) continue;
        uint32_t off = ram_to_offset(ram);
        if (off + 4 > data.size()) break;
        uint32_t op = *(const uint32_t*)(data.data() + off);
        std::string dis = mips_disasm::disasm_str(op, ram);
        printf("    0x%08X: 0x%08X  %s\n", ram, op, dis.c_str());
    }
}

// ===== P2-4: verify_cdrom_flow =====
// D3: CD-ROM stall bypass was proven dead weight (stale offset, guard prevents
// application, V106 proved bypass doesn't fix Enix freeze). This check is now
// a no-op — the stall bypass patch and its constants have been removed.
bool ExePatcher::verify_cdrom_flow() const {
    printf("  [VERIFY] CD-ROM stall bypass: removed (D3 — dead code)\n");
    return true;
}

// ===== P2-4: verify_integrity =====
bool ExePatcher::verify_integrity() const {
    bool ok = true;
    printf("  [VERIFY] === EXE Integrity Check ===\n");

    // 1. PC0 — accept original OR stub redirect (MISS-1 boot copy stub)
    uint32_t current_pc0 = *(uint32_t*)(data.data() + 0x10);
    if(current_pc0 == ORIGINAL_PC0){
        printf("  [VERIFY] OK: PC0 = 0x%08X (original)\n", current_pc0);
    } else if(current_pc0 >= load_addr && current_pc0 < load_addr + data.size() - 0x800){
        printf("  [VERIFY] OK: PC0 = 0x%08X (boot stub redirect within EXE range)\n", current_pc0);
    } else {
        printf("  [VERIFY] FAIL: PC0 is 0x%08X (expected 0x%08X or within EXE range)\n", current_pc0, ORIGINAL_PC0);
        ok = false;
    }

    // 2. Load address unchanged
    uint32_t current_load = *(uint32_t*)(data.data() + 0x18);
    if(current_load != EXE_LOAD_ADDR){
        printf("  [VERIFY] FAIL: Load address is 0x%08X (expected 0x%08X)\n", current_load, EXE_LOAD_ADDR);
        ok = false;
    } else {
        printf("  [VERIFY] OK: Load address = 0x%08X\n", current_load);
    }

    // 3. Text size reasonable (should be around 0xA5000 for DW7 EXE)
    uint32_t current_text = *(uint32_t*)(data.data() + 0x1C);
    if(current_text < 0x80000 || current_text > 0x200000){
        printf("  [VERIFY] WARNING: Text size is 0x%08X (expected ~0xA5000)\n", current_text);
        // Not a hard failure — payload appends increase text size
    } else {
        printf("  [VERIFY] OK: Text size = 0x%08X\n", current_text);
    }

    // 4. CD-ROM event loop intact
    if(!verify_cdrom_flow()){
        ok = false;
    }

    // 5. No forbidden patches (old fmv_skip only — fmv_stub is allowed)
    for(const auto& rec : patch_history){
        if(rec.reverted) continue;
        if(std::strstr(rec.patch_name, "fmv_skip")){
            printf("  [VERIFY] FAIL: Forbidden patch '%s' is active\n", rec.patch_name);
            ok = false;
        }
    }

    // 6. Check BSS clear patch (should be narrowed, not wide)
    uint32_t bss_lui_off = BSS_CLEAR_LUI_V1_OFF;  // file offset (header included)
    if(bss_lui_off + 4 <= data.size()){
        uint32_t bss_insn = *(uint32_t*)(data.data() + bss_lui_off);
        uint16_t lui_imm = bss_insn & 0xFFFF;
        if(lui_imm == BSS_CLEAR_LUI_V1_ORIG){
            printf("  [VERIFY] WARNING: BSS clear END is wide (lui=0x800F) — thread entry may be zeroed\n");
        } else if(lui_imm == BSS_CLEAR_LUI_V1_THREADSAFE){
            printf("  [VERIFY] OK: BSS clear END is threadsafe (lui=0x800E) — thread entry preserved\n");
        } else if(lui_imm == BSS_CLEAR_LUI_V1_NARROW){
            printf("  [VERIFY] OK: BSS clear END is narrow (lui=0x800C) — thread entry preserved\n");
        } else {
            printf("  [VERIFY] WARNING: BSS clear END lui immediate = 0x%04X (unexpected)\n", lui_imm);
        }
    }

    // 6b. Check BSS clear START (should be moved past tree)
    uint32_t bss_start_off = BSS_CLEAR_ADDIU_V0_OFF;  // file offset (header included)
    if(bss_start_off + 4 <= data.size()){
        uint32_t start_insn = *(uint32_t*)(data.data() + bss_start_off);
        uint16_t start_imm = start_insn & 0xFFFF;
        if(start_imm == BSS_CLEAR_ADDIU_V0_ORIG){
            printf("  [VERIFY] WARNING: BSS clear START is original (addiu=0xC668) — tree may be zeroed\n");
        } else if(start_imm == BSS_CLEAR_ADDIU_V0_NEW){
            printf("  [VERIFY] OK: BSS clear START moved past tree (addiu=0x%04X)\n", BSS_CLEAR_ADDIU_V0_NEW);
        } else {
            printf("  [VERIFY] WARNING: BSS clear START addiu immediate = 0x%04X (unexpected)\n", start_imm);
        }
    }

    // 7. EXE size sanity
    if(data.size() < 0x800 + 0xA5000){
        printf("  [VERIFY] FAIL: EXE size %zu too small (expected >= 0xA5800)\n", data.size());
        ok = false;
    } else {
        printf("  [VERIFY] OK: EXE size = %zu bytes\n", data.size());
    }

    printf("  [VERIFY] === %s ===\n", ok ? "ALL CHECKS PASSED" : "FAILURES DETECTED");
    return ok;
}

// ===== P2-4: revert_patch =====
bool ExePatcher::revert_patch(const char* name){
    if(!name) return false;
    bool found = false;
    for(auto& rec : patch_history){
        if(rec.reverted) continue;
        if(std::strstr(rec.patch_name, name)){
            // Restore original value
            if(rec.offset + 4 <= data.size()){
                std::memcpy(data.data() + rec.offset, &rec.original_value, 4);
            }
            rec.reverted = true;
            printf("  [REVERT] Reverted patch '%s' at offset 0x%X (RAM 0x%08X): 0x%08X -> 0x%08X\n",
                   rec.patch_name, rec.offset, rec.ram_addr, rec.patched_value, rec.original_value);
            found = true;
        }
    }
    if(!found){
        printf("  [REVERT] No active patch matching '%s' found\n", name);
    }
    return found;
}

// ===== P2-4: revert_all_patches =====
void ExePatcher::revert_all_patches(){
    int reverted = 0;
    for(auto& rec : patch_history){
        if(rec.reverted) continue;
        if(rec.offset + 4 <= data.size()){
            std::memcpy(data.data() + rec.offset, &rec.original_value, 4);
        }
        rec.reverted = true;
        reverted++;
    }
    printf("  [REVERT] Reverted %d/%zu patches\n", reverted, patch_history.size());
    // Refresh cached values
    refresh_pc0();
}

// ===== P2-4: list_patches =====
void ExePatcher::list_patches() const {
    printf("  [PATCHES] %zu total patches (%zu active, %zu reverted)\n",
           patch_history.size(),
           std::count_if(patch_history.begin(), patch_history.end(),
                         [](const PatchRecord& r){ return !r.reverted; }),
           std::count_if(patch_history.begin(), patch_history.end(),
                         [](const PatchRecord& r){ return r.reverted; }));
    for(size_t i = 0; i < patch_history.size(); i++){
        const auto& rec = patch_history[i];
        printf("    [%2zu] %s offset=0x%06X RAM=0x%08X 0x%08X->0x%08X %s\n",
               i, rec.patch_name, rec.offset, rec.ram_addr,
               rec.original_value, rec.patched_value,
               rec.reverted ? "(REVERTED)" : "");
    }
}

// ===== P2-4: has_patch =====
bool ExePatcher::has_patch(const char* name) const {
    if(!name) return false;
    for(const auto& rec : patch_history){
        if(rec.reverted) continue;
        if(std::strstr(rec.patch_name, name)) return true;
    }
    return false;
}

// ===== ExePatcher::patch_fmv_stubs — REMOVED Aug 3, 2026 =====
// FMV skip family removed per user directive (see psx_binary_ops.h P3 note).

// ===== P3: ExePatcher::patch_cdrom_cmd_intercept — REMOVED Aug 3, 2026 =====
#if 0
// Intercepts CD-ROM Setloc commands to redirect FMV reads from DW7 LBA to DQ4 LBA.
//
// Intercept point: 0x80098608 (sb $zero, ($v0) — sets CD-ROM index=0)
// This is BEFORE the param write loop (0x80098620-0x8009864C) that copies params
// from the RAM buffer ($s0) to the CD-ROM FIFO (0x1F801802). By intercepting here,
// we can modify the param buffer in RAM before it gets written to hardware.
//
// At intercept point:
//   $s1 = command byte (e.g., 0x02 for Setloc)
//   $s0 = pointer to param buffer in RAM (minute, second, frame in BCD)
//   $v0 = 0x1F801800 (CD-ROM index/status register)
//   $v1 = base for param count table
//
// Trampoline logic:
//   1. Execute original instruction (sb $zero, ($v0)) — set index=0
//   2. Execute original delay slot (addiu $v0, $v1, 0x100) — preserve $v0 for caller
//   3. If $s1 == 0x02 (Setloc) and $s0[0] >= 0x32 (BCD FMV minute):
//      Overwrite $s0[0..2] = {0x23, 0x31, 0x15} (DQ4 FMV MSF 23:31:15)
//   4. Return to 0x80098610 (instruction after delay slot)
//
// No Setmode interception — let 0xA0 (FMV double-speed) pass through normally.
// No FIFO manipulation needed — params are modified in RAM before FIFO write.
//
// Register usage in trampoline (all caller-saved, not live at intercept point):
//   $t0 = scratch for BCD values
//   $t1 = Setloc command constant / comparison threshold
//   $t2 = minute byte from param buffer
//   $t3 = comparison result
//   $ra = return address (set by JAL to 0x80098610)
bool ExePatcher::patch_cdrom_cmd_intercept(){
    uint32_t dispatch_off = CDROM_DISPATCH_OFF;  // 0x80F08
    if(dispatch_off + 8 > data.size()){
        printf("  ERROR: CD-ROM dispatch offset 0x%X beyond EXE size %zu\n",
               dispatch_off, data.size());
        return false;
    }

    // Read original instructions at intercept point (2 instructions: JAL + delay slot)
    uint32_t orig_insn0 = *(uint32_t*)(data.data() + dispatch_off);      // sb $zero, ($v0)
    uint32_t orig_insn1 = *(uint32_t*)(data.data() + dispatch_off + 4);  // addiu $v0, $v1, 0x100
    uint32_t orig_ram = CDROM_DISPATCH_RAM;

    printf("  [P3] CD-ROM command interception at 0x%08X (orig insns=0x%08X, 0x%08X)\n",
           orig_ram, orig_insn0, orig_insn1);

    // Trampoline location: after HBD type trampoline
    uint32_t intercept_ram = tramp_base + 0x100;
    uint32_t jal_insn = 0x0C000000 | ((intercept_ram >> 2) & 0x03FFFFFF);

    // Patch: JAL at intercept point, nop in delay slot
    *(uint32_t*)(data.data() + dispatch_off) = jal_insn;
    *(uint32_t*)(data.data() + dispatch_off + 4) = 0x00000000;

    record_patch(dispatch_off, orig_insn0, jal_insn, "cdrom_cmd_intercept_jal");
    record_patch(dispatch_off + 4, orig_insn1, 0x00000000, "cdrom_cmd_intercept_nop");

    printf("  [P3] Patched 0x%08X: jal 0x%08X + nop\n", orig_ram, intercept_ram);

    // Pad to reach trampoline RAM
    uint32_t current_end_ram = load_addr + (uint32_t)data.size() - 0x800;
    if(intercept_ram < current_end_ram){
        printf("  [P3] ERROR: trampoline RAM 0x%08X overlaps EXE end 0x%08X\n",
               intercept_ram, current_end_ram);
        *(uint32_t*)(data.data() + dispatch_off) = orig_insn0;
        *(uint32_t*)(data.data() + dispatch_off + 4) = orig_insn1;
        return false;
    }
    uint32_t pad_bytes = intercept_ram - current_end_ram;
    if(pad_bytes > 0){
        data.insert(data.end(), pad_bytes, 0);
        printf("  [P3] Padded %u bytes to trampoline at 0x%08X\n",
               pad_bytes, intercept_ram);
    }

    // ===== TRAMPOLINE (18 instructions, 72 bytes) =====
    // Entry via JAL from 0x80098608, $ra = 0x80098610
    // $s1 = command, $s0 = param buffer, $v0 = 0x1F801800, $v1 = param table base
    std::vector<uint32_t> t;

    // 0: Execute original: sb $zero, ($v0) — set CD-ROM index=0
    t.push_back(orig_insn0);
    // 1: Execute original delay slot: addiu $v0, $v1, 0x100 — preserve $v0 for caller
    t.push_back(orig_insn1);
    // 2: addiu $t1, $zero, 0x02 — Setloc command
    t.push_back(0x24090002);
    // 3: bne $s1, $t1, .check_setmode — skip if not Setloc (target idx 10, offset=10-4=6)
    t.push_back(0x16290006);
    // 4: nop
    t.push_back(0x00000000);
    // 5: lbu $t2, 0($s0) — read minute from param buffer
    t.push_back(0x920A0000);
    // 6: addiu $t1, $zero, 0x31 — threshold (0x31, so sltu gives minute >= 0x32)
    t.push_back(0x24090031);
    // 7: sltu $t3, $t1, $t2 — $t3 = (0x31 < minute) = (minute >= 0x32)
    t.push_back(0x012A582B);
    // 8: beq $t3, $zero, .done — if minute < 0x32, not FMV (target idx 17, offset=17-9=8)
    t.push_back(0x11600008);
    // 9: nop
    t.push_back(0x00000000);
    // 10: .check_setmode: addiu $t1, $zero, 0x0E — Setmode command
    t.push_back(0x2409000E);
    // 11: bne $s1, $t1, .done — skip if not Setmode (target idx 17, offset=17-12=5)
    t.push_back(0x16290005);
    // 12: nop
    t.push_back(0x00000000);
    // 13: lbu $t2, 0($s0) — read mode byte from param buffer
    t.push_back(0x920A0000);
    // 14: addiu $t1, $zero, 0xA0 — double-speed ADPCM mode
    t.push_back(0x240900A0);
    // 15: beq $t2, $t1, .patch_mode — if mode == 0xA0, patch it (target idx 18, offset=18-16=2)
    t.push_back(0x11490002);
    // 16: nop — delay slot (must not be jr $ra or it returns before patch)
    t.push_back(0x00000000);
    // 17: .done: jr $ra — return to 0x80098610
    t.push_back(0x03E00008);
    // 18: .patch_mode: sb $zero, 0($s0) — replace 0xA0 with 0x00 (normal speed, no ADPCM)
    t.push_back(0xA0000000);
    // 19: jr $ra — return
    t.push_back(0x03E00008);
    // 20: nop — delay slot
    t.push_back(0x00000000);

    // Append trampoline to EXE
    uint32_t tramp_off = (uint32_t)data.size();
    for(uint32_t insn : t){
        data.insert(data.end(), (uint8_t*)&insn, (uint8_t*)&insn + 4);
    }

    printf("  [P3] Trampoline: %zu instructions (%zu bytes) at RAM 0x%08X\n",
           t.size(), t.size() * 4, intercept_ram);
    printf("  [P3] Intercepts: Setloc(minute>=0x32 → DQ4 FMV 23:31:15), Setmode(0xA0→0x00)\n");

    // Record the trampoline as a patch (for revert tracking)
    for(size_t i = 0; i < t.size(); i++){
        char name[48];
        snprintf(name, sizeof(name), "cdrom_intercept_tramp[%zu]", i);
        if(t[i] != 0x00000000){
            record_patch(tramp_off + (uint32_t)i * 4, 0, t[i], name);
        }
    }

    update_text_size();
    return true;
}
#endif // patch_cdrom_cmd_intercept REMOVED

// ===== ExePatcher::patch_malloc_clamp (P1) =====
// Patches descriptor publish at 0x8007AD74 to jump through a clamp trampoline.
// The trampoline checks if $a2 (descriptor base) >= 0x80800000 (8MB ceiling).
// If so, clamps to 0x80100000 (safe fallback in extended RAM).
// Then executes the original sw + addiu and jumps back to 0x8007AD7C.
//
// Root cause: heap base at 0x80190000 + DQ4 HBD over-allocation (~7.6MB) pushes
// the bump pointer past 0x80800000, generating invalid descriptor base 0x809261C4.
// The crash occurs at 0x800761DC when accessing memory through this invalid base.
bool ExePatcher::patch_malloc_clamp(){
    // 1. Verify original instruction at descriptor publish site
    uint32_t patch_off = DESC_PUBLISH_OFF;
    if(patch_off + 4 > data.size()){
        printf("  [P1] ERROR: descriptor publish offset 0x%X beyond EXE size %zu\n",
            patch_off, data.size());
        return false;
    }
    uint32_t orig;
    std::memcpy(&orig, data.data() + patch_off, 4);
    if(orig != DESC_PUBLISH_ORIG){
        printf("  [P1] WARNING: expected 0x%08X at file 0x%X, found 0x%08X — NOT patching (would corrupt code)\n",
            DESC_PUBLISH_ORIG, patch_off, orig);
        return false;
    }

    // 2. Compute clamp trampoline address
    uint32_t clamp_ram = tramp_base + MALLOC_CLAMP_TRAMP_OFFSET;
    uint32_t clamp_file = clamp_ram - load_addr + 0x800;

    // 3. Patch the sw instruction to j clamp_tramp
    uint32_t j_insn = MIPS_J(clamp_ram);
    *(uint32_t*)(data.data() + patch_off) = j_insn;
    record_patch(patch_off, orig, j_insn, "malloc_clamp_j");
    printf("  [P1] Patched 0x%08X: sw $a2,0x2228($v1) → j 0x%08X\n",
        DESC_PUBLISH_RAM, clamp_ram);

    // 4. Pad EXE data to reach clamp trampoline address
    uint32_t current_end_ram = load_addr + (uint32_t)data.size() - 0x800;
    if(clamp_ram < current_end_ram){
        // Trampoline area already has data (from HBD type trampoline) — write into it
        printf("  [P1] Clamp trampoline at 0x%08X (within existing trampoline area)\n", clamp_ram);
    } else {
        uint32_t pad_bytes = clamp_ram - current_end_ram;
        if(pad_bytes > 0){
            data.insert(data.end(), pad_bytes, 0);
            printf("  [P1] Padded %u bytes to clamp trampoline at 0x%08X\n",
                pad_bytes, clamp_ram);
        }
    }

    // 5. Ensure data is large enough
    if(clamp_file + 36 > data.size()){
        data.resize(clamp_file + 36, 0);
    }

    // 6. Write clamp trampoline (9 instructions = 36 bytes)
    // Entry: $a2 = descriptor base (possibly overflowed)
    //        $v1 = 0x800F (from lui at 0x8007AD70)
    // Scratch: $t0 (not live at this point)
    uint32_t clamp_tramp[9] = {
        0x3C088080,  // 0: lui $t0, 0x8080           — t0 = 0x80800000 (8MB ceiling)
        0x0106402B,  // 1: sltu $t0, $t0, $a2        — t0 = (ceiling < $a2) ? 1 : 0
        0x11000002,  // 2: beq $t0, $zero, +2        — if $a2 <= ceiling, skip clamp
        0x00000000,  // 3: nop (delay slot)
        0x3C068010,  // 4: lui $a2, 0x8010           — clamp $a2 = 0x80100000
        DESC_PUBLISH_ORIG,  // 5: sw $a2, 8744($v1)  — original instruction
        DESC_PUBLISH_NEXT,  // 6: addiu $v1, $v1, 8744 — original next instruction
        MIPS_J(DESC_PUBLISH_CONT_RAM),  // 7: j 0x8007AD7C — continue execution
        0x00000000,  // 8: nop (delay slot)
    };

    for(int i = 0; i < 9; i++){
        std::memcpy(data.data() + clamp_file + i * 4, &clamp_tramp[i], 4);
        char name[48];
        snprintf(name, sizeof(name), "malloc_clamp_tramp[%d]", i);
        record_patch(clamp_file + i * 4, 0, clamp_tramp[i], name);
    }

    printf("  [P1] Clamp trampoline: 9 instructions at RAM 0x%08X (file 0x%X)\n",
        clamp_ram, clamp_file);
    printf("  [P1] Logic: if descriptor_base >= 0x%08X → clamp to 0x%08X\n",
        RAM_CEILING, DESC_CLAMP_VALUE);

    update_text_size();
    return true;
}

// ===== ExePatcher::patch_fmv_skip_xa_stub =====
// Overwrites XA playback init entry at 0x8008B32C with a 6-instruction stub that:
//   1. Sets $v0 = 1 (success return value)
//   2. Sets BIOS event flags at 0x800E2038 and 0x800E3D94 to 1
//      (cures event starvation — these flags are polled by downstream wait loops)
//   3. Returns via jr $ra + nop
// This preserves the call/return protocol: callers still JAL to 0x8008B32C,
// but the function returns $v0=1 (success) without issuing any CD-ROM commands.
// The event flag writes cure the root cause of CP3/CP4/CP5 stalls: the game's
// wait loops poll 0x800E2038 and 0x800E3D94, which were never set because the
// stub bypassed CD-ROM event delivery. The original function body is dead code
// (never reached), so extending from 3 to 6 instructions is safe.
bool ExePatcher::patch_fmv_skip_xa_stub(){
    uint32_t ram_addr = 0x8008B32C;
    uint32_t foff = ram_to_offset(ram_addr);
    if(foff + 24 > data.size()){
        printf("  [fmv_xa_stub] ERROR: 0x%08X beyond EXE size %zu\n", ram_addr, data.size());
        return false;
    }

    // Record original values for revert tracking (6 words now)
    uint32_t orig[6];
    for(int i = 0; i < 6; i++)
        std::memcpy(&orig[i], data.data() + foff + i * 4, 4);

    // 6-instruction flag-setting stub:
    //   li   $v0, 1           (0x24020001)  — return success
    //   lui  $at, 0x800E      (0x3C01800E)  — $at = 0x800E0000
    //   sw   $v0, 0x2038($at) (0xAC222038)  — *0x800E2038 = 1 (event flag 1)
    //   sw   $v0, 0x3D94($at) (0xAC223D94)  — *0x800E3D94 = 1 (event flag 2)
    //   jr   $ra              (0x03E00008)  — return
    //   nop                   (0x00000000)  — delay slot
    static const uint32_t stub[6] = {
        0x24020001,  // li   $v0, 1
        0x3C01800E,  // lui  $at, 0x800E
        0xAC222038,  // sw   $v0, 0x2038($at)  — *0x800E2038 = 1
        0xAC223D94,  // sw   $v0, 0x3D94($at)  — *0x800E3D94 = 1
        0x03E00008,  // jr   $ra
        0x00000000   // nop
    };

    static const char* names[6] = {
        "fmv_xa_stub_li",
        "fmv_xa_stub_lui_at",
        "fmv_xa_stub_sw_2038",
        "fmv_xa_stub_sw_3d94",
        "fmv_xa_stub_jr",
        "fmv_xa_stub_nop"
    };

    for(int i = 0; i < 6; i++){
        write32(ram_addr + i * 4, stub[i]);
        record_patch(foff + i * 4, orig[i], stub[i], names[i]);
    }

    printf("  [fmv_xa_stub] Patched 0x%08X: li $v0,1; lui $at,0x800E; sw $v0,0x2038($at); sw $v0,0x3D94($at); jr $ra; nop\n", ram_addr);
    printf("  [fmv_xa_stub] Event flags 0x800E2038 and 0x800E3D94 will be set to 1 on call — cures event starvation (CP3/CP4/CP5)\n");
    return true;
}

// ===== ExePatcher::patch_vblank_wait_bypass =====
// Patches the VBlank wait function at 0x800965E8 to return immediately.
//
// Root cause: 0x800965E8 is a VBlank timer wait function with 3 spinlock loops:
//   1. 0x80096624: bne v1,v0,0x8009660C — VBlank counter match spinlock
//   2. 0x80096704: beq v0,zero,0x800966F4 — Timer bit 31 wait spinlock
//   3. 0x80096740: bne v1,v0,0x80096724 — Read consistency spinlock
//
// All three spin on memory at 0x800B52A4/0x800B52A8 which is updated by the VBlank
// interrupt handler. In this Frankenstein graft (DW7 EXE on DQ4 disc), the VBlank
// IRQ doesn't update these locations, causing all 35 call sites to block forever.
//
// Fix: Replace the function entry with:
//   jr   $ra              (0x03E00008)  — return immediately
//   move $v0, $zero       (0x00001021)  — return 0 (no VBlanks elapsed)
//   nop                   (0x00000000)  — delay slot padding
//
// This makes the function a no-op for all 35 callers. The FMV XA stub already
// sets event flags 0x800E2038 and 0x800E3D94, so the wait loops that called
// 0x800965E8 for VBlank sync will see the flags set and proceed.
bool ExePatcher::patch_vblank_wait_bypass(){
    uint32_t ram_addr = 0x800965E8;
    uint32_t foff = ram_to_offset(ram_addr);
    if(foff + 12 > data.size()){
        printf("  [vblank_bypass] ERROR: 0x%08X beyond EXE size %zu\n", ram_addr, data.size());
        return false;
    }

    uint32_t orig[3];
    for(int i = 0; i < 3; i++)
        std::memcpy(&orig[i], data.data() + foff + i * 4, 4);

    static const uint32_t patch[3] = {
        0x03E00008,  // jr   $ra
        0x00001021,  // move $v0, $zero   (delay slot — return 0)
        0x00000000   // nop
    };

    static const char* names[3] = {
        "vblank_bypass_jr_ra",
        "vblank_bypass_move_v0_zero",
        "vblank_bypass_nop"
    };

    for(int i = 0; i < 3; i++){
        write32(ram_addr + i * 4, patch[i]);
        record_patch(foff + i * 4, orig[i], patch[i], names[i]);
    }

    printf("  [vblank_bypass] Patched 0x%08X: jr ra; move v0,zero; nop — VBlank wait function now returns immediately (35 call sites unblocked)\n", ram_addr);
    return true;
}

// ===== ExePatcher::patch_fifo_drain =====
// Injects CLRPRM FIFO clear trampoline at CD-ROM command dispatcher (0x8008B65C).
// Per PSX-SPX: when a CD-ROM command fails with INT5, the parameter FIFO is NOT
// cleared, so stale bytes get passed to the next command. Fix: write CLRPRM to HCLRCTL.
//
// Original at 0x8008B65C:
//   0x8008B65C: 0x24040100  li $a0, 0x100      (insn 0)
//   0x8008B660: 0x8C820008  lw $v0, 8($a0)     (insn 1)
//   0x8008B664: 0x00000000  nop                (insn 2)
//   0x8008B668: 0x8C430000  lw $v1, 0($v0)     (insn 3 — continuation)
//
// Patched:
//   0x8008B65C: J trampoline       (insn 0 stays as delay slot)
//   0x8008B660: 0x24040100         (original insn 0, delay slot)
//   Trampoline (uses $t0/$t1 — caller-saved scratch):
//     lui  $t0, 0xBF80            # 0x3C08BF80
//     ori  $t0, $t0, 0x1800       # 0x35081800  t0 = 0xBF801800
//     addiu $t1, $zero, 1         # 0x24090001
//     sb   $t1, 0($t0)            # 0xA1090000  set index = 1
//     addiu $t1, $zero, 0x47      # 0x24090047  CLRPRM | ACK_ALL
//     sb   $t1, 3($t0)            # 0xA1090003  write HCLRCTL: clear FIFO + ack IRQs
//     sb   $zero, 0($t0)          # 0xA0080000  restore index = 0
//     lw   $v0, 8($a0)            # 0x8C820008  original insn 1
//     nop                          # 0x00000000  original insn 2
//     J    0x8008B668             # 0x08022D9A  back to insn 3
//     nop                          # 0x00000000  delay slot
bool ExePatcher::patch_fifo_drain(){
    uint32_t target_ram = 0x8008B65C;
    uint32_t target_off = ram_to_offset(target_ram);

    // Verify original instructions match expected pattern
    uint32_t expected[] = {0x24040100, 0x8C820008, 0x00000000};
    for(int i = 0; i < 3; i++){
        uint32_t actual;
        std::memcpy(&actual, data.data() + target_off + i * 4, 4);
        if(actual != expected[i]){
            printf("  [fifo_drain] SKIP: mismatch at 0x%08X (expected 0x%08X, got 0x%08X)\n",
                target_ram + i * 4, expected[i], actual);
            return false;
        }
    }

    // Build trampoline: CLRPRM + ACK_ALL via HCLRCTL
    uint32_t trampoline[] = {
        0x3C08BF80,  // lui  $t0, 0xBF80
        0x35081800,  // ori  $t0, $t0, 0x1800   — t0 = 0xBF801800
        0x24090001,  // addiu $t1, $zero, 1
        0xA1090000,  // sb   $t1, 0($t0)        — set index = 1
        0x24090047,  // addiu $t1, $zero, 0x47  — CLRPRM(0x40) | ACK_ALL(0x07)
        0xA1090003,  // sb   $t1, 3($t0)        — write HCLRCTL: clear FIFO + ack IRQs
        0xA0080000,  // sb   $zero, 0($t0)      — restore index = 0
        0x8C820008,  // lw   $v0, 8($a0)        — original insn 1
        0x00000000,  // nop                     — original insn 2
        0x08022D9A,  // J    0x8008B668         — back to insn 3
        0x00000000,  // nop                     — delay slot
    };

    // Append trampoline to end of EXE data
    uint32_t tramp_off = (uint32_t)data.size();
    for(uint32_t insn : trampoline){
        data.insert(data.end(), (uint8_t*)&insn, (uint8_t*)&insn + 4);
    }
    uint32_t tramp_ram = load_addr + tramp_off - 0x800;

    // Patch 0x8008B65C: J trampoline (delay slot keeps original insn 0)
    uint32_t orig_j;
    std::memcpy(&orig_j, data.data() + target_off, 4);
    uint32_t j_trampoline = MIPS_J(tramp_ram);
    std::memcpy(data.data() + target_off, &j_trampoline, 4);
    // Delay slot: original insn 0 (already 0x24040100 at target_off+4, keep it)

    record_patch(target_off, orig_j, j_trampoline, "fifo_drain_jump");
    printf("  [fifo_drain] J 0x%08X at 0x%08X, CLRPRM+ACK via HCLRCTL, return to 0x8008B668\n",
        tramp_ram, target_ram);

    return true;
}

// ===== FrankensteinBuilder::build_v39 =====
// tree_mode: 0=no tree (Option C), 1=tree@0x800F4980+copy (Option B), 2=tree@0x80100000+copy (Option A), 3=tree@0x800BC700+BSS narrow (current)
BuildResult FrankensteinBuilder::build_v39(
    const char* dw7_disc_path,
    const char* dw7_exe_path,
    const char* dq4_hbd_disc_path,
    const char* hybrid_tree_path,
    const char* folder_map_path,
    const char* output_bin_path,
    const char* output_cue_path,
    const char* edcre_path,
    int tree_mode,
    uint32_t build_flags,
    const char* translation_map_path,
    uint32_t hbd_lba_override,
    bool no_xa_stub,
    const char* hotfix_file_path,
    bool no_disc_checks,
    const char* disasm_range_str,
    bool safe_boot_stub)
{
    BuildResult r={};
    const char* mode_names[]={"no tree (Option C)","tree@0x800F4980+copy (Option B)","tree@0x80100000+copy (Option A)","tree@0x800BC700+BSS narrow (current)"};
    if(safe_boot_stub) printf("  Safe boot stub: ENABLED (KSEG1 uncached translation)\n");
    printf("\n  Profile: frank_v40 (%s)\n",tree_mode>=0&&tree_mode<=3?mode_names[tree_mode]:"unknown");

    // 1. Load DW7 EXE
    auto exe_buf=read_file(dw7_exe_path);
    if(exe_buf.empty()){printf("  ERROR: Cannot read DW7 EXE: %s\n",dw7_exe_path);return r;}
    printf("  DW7 EXE: %zu bytes\n",exe_buf.size());

    ExePatcher exe;
    if(!exe.load(exe_buf.data(),(uint32_t)exe_buf.size())){
        printf("  ERROR: ExePatcher::load failed\n");return r;
    }
    exe.set_safe_boot_stub(safe_boot_stub);

    // Load hybrid tree
    auto hybrid_tree=read_file(hybrid_tree_path);
    if(hybrid_tree.empty()){printf("  ERROR: Cannot read hybrid tree: %s\n",hybrid_tree_path);return r;}
    printf("  Hybrid tree: %zu bytes\n",hybrid_tree.size());

    // 2. Tree placement strategy depends on tree_mode
    constexpr uint32_t TREE_FILE_OFF=0xA4800;  // Original EXE end = RAM 0x800BC700
    constexpr uint32_t ORIG_PC0=0x8008E284;
    constexpr uint32_t J_ORIG_PC0=0x080238A1;  // j 0x8008E284
    uint32_t TREE_RAM_ADDR=0;       // Where tree ends up in RAM (for patching refs)
    uint32_t tree_actual_ram=0;      // Where tree is stored in EXE (for copy src)

    if(tree_mode==0){
        // Option C: No tree, no patches, original EXE size
        printf("  No tree appended — game uses own tree at 0x800EF1C8\n");
        r.exe_size=exe.size();
        r.new_pc0=ORIG_PC0;
        r.tree_patches=0;
        printf("  PC0: 0x%08X (unchanged), EXE size: %u\n",r.new_pc0,r.exe_size);
    } else if(tree_mode==1||tree_mode==2){
        // Option A/B: Copy routine at 0x800BC700, tree at 0x800BC738
        // Copy routine (14 instructions = 56 bytes) copies tree to destination, then jumps to original PC0
        uint32_t dst_ram=(tree_mode==1)?0x800F4980:0x80100000;
        // KSEG1 uncached translation: 0x80xxxxxx -> 0xA0xxxxxx for cache coherency
        uint32_t dst_ram_uncached = safe_boot_stub ? (dst_ram | 0x20000000) : dst_ram;
        TREE_RAM_ADDR=dst_ram;  // Tree refs patched to point here (KSEG0 for game code)
        tree_actual_ram=0x800BC738;  // Tree stored here in loaded EXE

        // Build copy routine — use uncached destination when safe_boot_stub is enabled
        uint32_t src_hi=0x800C, src_lo=0xC738;  // src = 0x800BC738
        uint32_t dst_hi=(dst_ram_uncached>>16)&0xFFFF;
        uint32_t dst_lo=dst_ram_uncached&0xFFFF;
        // Handle sign extension: if dst_lo >= 0x8000, add 1 to dst_hi
        if(dst_lo>=0x8000){dst_hi++;}
        uint32_t tree_size=(uint32_t)hybrid_tree.size();  // 1480 = 0x5C8

        uint32_t copy_routine[14]={
            0x3C080000|src_hi,       // 0: lui $t0, src_hi
            0x25080000|(src_lo&0xFFFF), // 1: addiu $t0, $t0, src_lo
            0x3C090000|dst_hi,       // 2: lui $t1, dst_hi
            0x25290000|(dst_lo&0xFFFF), // 3: addiu $t1, $t1, dst_lo
            0x250A0000|(tree_size&0xFFFF), // 4: addiu $t2, $t0, tree_size
            0x8D0B0000,              // 5: lw $t3, 0($t0)  ← loop target
            0x00000000,              // 6: nop (load delay)
            0xAD2B0000,              // 7: sw $t3, 0($t1)
            0x25080004,              // 8: addiu $t0, $t0, 4
            0x25290004,              // 9: addiu $t1, $t1, 4
            0x150AFFFA,              // 10: bne $t0, $t2, -6
            0x00000000,              // 11: nop (delay slot)
            J_ORIG_PC0,              // 12: j 0x8008E284
            0x00000000,              // 13: nop
        };

        // Verify src/dst addresses
        uint32_t src_check=(src_hi<<16)+(int32_t)(int16_t)(src_lo&0xFFFF);
        uint32_t dst_check=(dst_hi<<16)+(int32_t)(int16_t)(dst_lo&0xFFFF);
        printf("  Copy routine: src=0x%08X dst=0x%08X size=%u\n",src_check,dst_check,tree_size);
        printf("  src_check==tree_actual_ram: %s\n",src_check==tree_actual_ram?"OK":"FAIL");
        printf("  dst_check==dst_ram: %s\n",dst_check==dst_ram?"OK":"FAIL");

        // Pad to TREE_FILE_OFF if needed
        if(exe.size()<TREE_FILE_OFF){
            exe.append_payload(nullptr,0);
            while(exe.size()<TREE_FILE_OFF)exe.append_payload(nullptr,0);
        }
        // Append copy routine (56 bytes)
        exe.append_payload((const uint8_t*)copy_routine,56);
        // Append tree (1480 bytes)
        exe.append_payload(hybrid_tree.data(),(uint32_t)hybrid_tree.size());
        // Pad to sector boundary
        uint32_t pad=(2048-(exe.size()%2048))%2048;
        if(pad>0){
            std::vector<uint8_t> zeros(pad,0);
            exe.append_payload(zeros.data(),pad);
        }
        exe.update_text_size();
        r.exe_size=exe.size();

        // Set PC0 to copy routine at 0x800BC700 (write to EXE header offset 0x10)
        *(uint32_t*)(exe.raw()+0x10)=0x800BC700;
        r.new_pc0=0x800BC700;
        printf("  Copy routine at RAM 0x800BC700 (PC0), tree at RAM 0x%08X\n",tree_actual_ram);
        printf("  Tree will be copied to 0x%08X before BSS clear, EXE size: %u\n",dst_ram,r.exe_size);

        // Patch tree refs to destination address
        uint16_t new_lui,new_addiu;
        ExePatcher::compute_tree_addr(TREE_RAM_ADDR,new_lui,new_addiu);
        uint32_t verify=(new_lui<<16)+(new_addiu>=0x8000?(int32_t)(int16_t)new_addiu:new_addiu);
        printf("  Tree refs: LUI=0x%04X ADDIU=0x%04X -> 0x%08X (%s)\n",
            new_lui,new_addiu,verify,verify==TREE_RAM_ADDR?"OK":"FAIL");
        r.tree_patches=exe.patch_tree_references(OLD_LUI_IMM,OLD_ADDIU_IMM,new_lui,new_addiu);
        printf("  Tree ref patches: %u\n",r.tree_patches);

        // NO BSS narrow — tree is outside BSS range (0x80100000) or at BSS boundary (0x800F4980)
        printf("  BSS clear: NOT narrowed (tree at 0x%08X, BSS clears 0x800BC668-0x800F4980)\n",dst_ram);
    } else {
        // tree_mode==3: Current behavior — tree at 0x800BC700, BSS narrowed
        TREE_RAM_ADDR=0x800BC700;
        tree_actual_ram=0x800BC700;
        if(exe.size()<TREE_FILE_OFF){
            exe.append_payload(nullptr,0);
            while(exe.size()<TREE_FILE_OFF)exe.append_payload(nullptr,0);
        }
        exe.append_payload(hybrid_tree.data(),(uint32_t)hybrid_tree.size());
        uint32_t pad=(2048-(exe.size()%2048))%2048;
        if(pad>0){
            std::vector<uint8_t> zeros(pad,0);
            exe.append_payload(zeros.data(),pad);
        }
        exe.update_text_size();
        r.exe_size=exe.size();
        printf("  Appended hybrid tree at file offset 0x%X (RAM 0x%08X), EXE size: %u\n",
            TREE_FILE_OFF,TREE_RAM_ADDR,r.exe_size);

        uint16_t new_lui,new_addiu;
        ExePatcher::compute_tree_addr(TREE_RAM_ADDR,new_lui,new_addiu);
        uint32_t verify=(new_lui<<16)+(new_addiu>=0x8000?(int32_t)(int16_t)new_addiu:new_addiu);
        printf("  Tree: LUI=0x%04X ADDIU=0x%04X -> 0x%08X (%s)\n",
            new_lui,new_addiu,verify,verify==TREE_RAM_ADDR?"OK":"FAIL");
        r.tree_patches=exe.patch_tree_references(OLD_LUI_IMM,OLD_ADDIU_IMM,new_lui,new_addiu);
        printf("  Tree ref patches: %u\n",r.tree_patches);

        r.new_pc0=*(uint32_t*)(exe.raw()+0x10);
        printf("  PC0: 0x%08X (unchanged)\n",r.new_pc0);

        if(exe.patch_bss_clear_narrow()){
            printf("  BSS clear patched: START moved past tree, END narrowed to 0x800D9E80\n");
        }else{
            printf("  WARNING: BSS clear patch FAILED — tree and/or thread entry may be zeroed!\n");
        }

        // Zero the pre-tree BSS region (0x800BC668-0x800BC700) in EXE data.
        // This region was originally cleared by BSS but is now skipped (BSS start moved past tree).
        // Contains a base pointer at 0x800BC6CC used by thread status polling loop.
        exe.zero_pre_tree_bss();
    }

    // 3g. Decompressor patches (Targets 4, 5, 6)
    // These patches adapt the DW7 Huffman decompressor for DQ4 tree format.
    // Must be applied AFTER patch_tree_references (which changes immediates)
    // and AFTER zero_pre_tree_bss (which zeros the variable location).
    if(tree_mode!=0){
        // Initialize runtime tree pointer variables at 0x800BC6F8 and 0x800BC6FC
        // (zero_pre_tree_bss just zeroed this region, so we write after)
        uint32_t var_off = TREE_PTR_VAR_OFF;       // 0xA4FF8 (raw tree base, for Sites 1&2)
        uint32_t var_plus2_off = TREE_PTR_VAR_PLUS2_OFF;  // 0xA4FFC (tree base + 2, for Site 3)
        if(var_off+4<=exe.size() && var_plus2_off+4<=exe.size()){
            uint32_t tree_addr = (tree_mode==3) ? 0x800BC700 : TREE_RAM_ADDR;
            uint32_t tree_addr_plus2 = tree_addr + 2;  // root_id +1 offset (nodes are 2 bytes)
            std::memcpy((uint8_t*)exe.raw()+var_off, &tree_addr, 4);
            std::memcpy((uint8_t*)exe.raw()+var_plus2_off, &tree_addr_plus2, 4);
            printf("  Tree ptr variables: 0x%08X = 0x%08X (raw), 0x%08X = 0x%08X (+2)\n",
                TREE_PTR_VAR_RAM, tree_addr, TREE_PTR_VAR_PLUS2_RAM, tree_addr_plus2);
        }

        // Target 4: Tree pointer → runtime variable
        if(exe.patch_decomp_tree_pointer()){
            printf("  Decompressor Target 4 (tree pointer): OK\n");
        }else{
            printf("  WARNING: Decompressor Target 4 (tree pointer) FAILED\n");
        }

        // Target 6: Offset_b mask removal
        if(exe.patch_decomp_offset_b_mask()){
            printf("  Decompressor Target 6 (offset_b mask): OK\n");
        }else{
            printf("  WARNING: Decompressor Target 6 (offset_b mask) FAILED\n");
        }

        // NOTE: Target 5R (root_id runtime) is deferred to after trampoline patches
        // because it places a stub at tramp_base+0x200 which must be allocated AFTER
        // the HBD type trampoline (tramp_base+0x00) and other trampolines are placed.
    }

    // Calculate dynamic HBD_LBA based on actual EXE size (tree+trampolines may grow EXE)
    uint32_t exe_sectors=(r.exe_size+USER_SIZE-1)/USER_SIZE;
    uint32_t dynamic_hbd_lba=EXE_LBA+exe_sectors;
    // Align to next multiple of 4 for clean sector alignment
    dynamic_hbd_lba=(dynamic_hbd_lba+3)&~3u;
    // Apply HBD LBA override if specified (e.g. 160000 to preserve FMV sectors)
    if(hbd_lba_override>0){
        dynamic_hbd_lba=hbd_lba_override;
        printf("  HBD LBA OVERRIDE: %u (preserving FMV sectors up to LBA 146621)\n",dynamic_hbd_lba);
    }
    uint32_t max_exe=dynamic_hbd_lba*USER_SIZE;
    printf("  Dynamic HBD_LBA: %u (EXE=%u bytes = %u sectors, EXE spans LBA %u-%u)\n",
        dynamic_hbd_lba,r.exe_size,exe_sectors,EXE_LBA,EXE_LBA+exe_sectors-1);
    printf("  Max EXE before HBD overlap: %u bytes — %s\n",max_exe,
        r.exe_size<=max_exe?"OK":"OVERLAP!");

    // 4. Folder pointer remapping (REQUIRED — only EXE patch besides tree refs)
    // DQ4 HBD replaces DW7 HBD at dynamic_hbd_lba
    uint32_t DQ4_BASE_SECTOR=dynamic_hbd_lba;
    auto mappings=parse_folder_mappings(folder_map_path);
    printf("  Folder mappings: %zu\n",mappings.size());
    uint32_t lba_delta=dynamic_hbd_lba-354;
    printf("  Patching matched folder pointers (DQ4 base=sector %u) + LBA delta for unmatched...\n",DQ4_BASE_SECTOR);
    exe.remap_folder_pointers(mappings.data(),(uint32_t)mappings.size(),
        lba_delta,DQ4_BASE_SECTOR,
        r.abs_matched,r.abs_delta,r.rel_matched);
    printf("  Matched: abs=%u, rel=%u\n",r.abs_matched,r.rel_matched);
    printf("  LBA delta (unmatched ABS): %u\n",r.abs_delta);

    // 3c. LBA broad scan — patch ALL old HBD LBA references to new dynamic position
    // Must patch 354 (original DW7), 355 (V38a shift), and 356 (old constant) to dynamic_hbd_lba
    r.lba_patches=0;
    r.lba_patches+=exe.patch_lba_references(354,dynamic_hbd_lba);
    r.lba_patches+=exe.patch_lba_references(355,dynamic_hbd_lba);
    r.lba_patches+=exe.patch_lba_references(356,dynamic_hbd_lba);
    printf("  LBA broad scan: %u references patched (354/355/356 -> %u)\n",r.lba_patches,dynamic_hbd_lba);

    // 3d. Sequential sector table — 16-bit table at 0xA39AA, entries in 300-400 range
    r.seq_patches=exe.patch_sequential_sector_table(354,dynamic_hbd_lba);
    printf("  Sequential sector table: %u entries patched\n",r.seq_patches);

    // 3d-b. HBD LBA table patch — REMOVED Aug 4, 2026 (V3: LBA hypothesis FALSIFIED)
    //       See GLM_HANDOFF_BACK_LBA72_FALSIFIED_Aug4_2026.md for evidence.
    r.hbd_table_patches=0;
    printf("  HBD LBA table: SKIPPED (V3 — LBA hypothesis falsified Aug 4)\n");

    // 3e. Disc-check bypass — FULL SUITE (all 9 patches)
    // V38a hit "INSERT DISC / WRONG DISC" at character creation because these
    // were not applied. All 9 patches are safe caller-side returns.
    if (!no_disc_checks) {
        static const uint32_t dc_offsets[]={
            0x6112C,0x611D8,0x613B8,  // exit1, exit2, exit3: force success
            0x614A4,0x614F8,           // nop_timeout, nop_error
            0x7308C,                   // redirect_trap
            0x61424,0x61520,0x61360    // graft_a/b/c skip
        };
        static const uint32_t dc_patches[]={
            0x24020001,0x24020001,0x24020001,  // li $v0, 1 (force success)
            0x00000000,0x00000000,              // nop (skip timeout/error)
            0x08022BE9,                         // j 0x800AFAA4 (redirect)
            0x1000000B,0x1000000B,0x1000000A    // beq $zero,$zero,+N (skip graft checks)
        };
        r.disc_patches=exe.patch_disc_check(dc_offsets,dc_patches,9);
        printf("  Disc-check bypass (FULL 9-patch suite): %u patches applied\n",r.disc_patches);
    } else {
        printf("  Disc-check bypass: SKIPPED (--no-disc-check flag active)\n");
        r.disc_patches = 0;
    }

    // 3f. CD-ROM stall bypass — REMOVED (D3: dead code, stale offset, proven ineffective)
    printf("  CD-ROM stall bypass: REMOVED (D3 — dead code)\n");

    // ===== TRAMPOLINE AREA ALLOCATION (0x800BCF00-0x800BD200) =====
    // All trampolines placed right after tree to minimize padding.
    // Layout:
    //   0x800BCF00 (+0x00): HBD type trampoline (108 bytes)
    //   0x800BCF80 (+0x80): Malloc clamp trampoline (36 bytes)
    //   0x800BD100 (+0x200): Root ID runtime stub (24 bytes)
    //   [end of EXE]:       Tree hook stub (appended)
    // BSS clear starts at 0x800BD200 (past all trampolines)

    // 3h. HBD type trampoline — RE-ENABLED (full patch suite)
    exe.set_tramp_base(0x800BCF00);
    if(exe.patch_hbd_type_trampoline()){
        r.trampoline_patches++;
        printf("  HBD type trampoline: OK\n");
    }else{
        printf("  WARNING: HBD type trampoline FAILED\n");
    }

    // 3h.5 P1: Malloc clamp — RE-ENABLED (full patch suite)
    if(exe.patch_malloc_clamp()){
        printf("  Malloc clamp (P1): OK\n");
    }else{
        printf("  WARNING: Malloc clamp (P1) FAILED\n");
    }

    // 3i/3j. FMV playback — NOT STUBBED (V38a proved FMV plays correctly)
    //     Stubbing fmv_playback broke the build (VBlank wait loop never exits).
    //     FMVs play fine with DQ4 HBD data — the issue was disc-check, not FMV.
    r.fmv_bcd_patches = 0;
    printf("  FMV playback: NOT STUBBED (V38a proved FMV works — disc-check was the issue)\n");

    // 3k. Target 5R: Root ID +1 (runtime) — RE-ENABLED (full patch suite)
    if(exe.patch_decomp_root_id_runtime()){
        printf("  Decompressor Target 5R (root ID runtime): OK\n");
    }else{
        printf("  WARNING: Decompressor Target 5R FAILED\n");
    }

    // 3h.1 R-TREEHOOK — RE-ENABLED (full patch suite)
    if(exe.patch_tree_hook()){
        printf("  R-TREEHOOK: OK\n");
    }else{
        printf("  WARNING: R-TREEHOOK FAILED\n");
    }

    // 3j.5 FMV BCD seek patch: NOT NEEDED — FMVs play natively, no stubs to bypass.
    printf("  FMV BCD seek: SKIPPED (FMVs play natively — no stubs applied)\n");

    // 3k. Update r.exe_size after ALL trampoline patches
    r.exe_size=exe.size();
    printf("  Final EXE size: %u bytes (text_size=0x%X)\n",r.exe_size,(uint32_t)(exe.size()-0x800));
    {
        // Recalculate dynamic HBD_LBA after all trampoline patches may have grown EXE
        exe_sectors=(r.exe_size+USER_SIZE-1)/USER_SIZE;
        if(hbd_lba_override>0){
            // Keep override LBA — don't recompute
            printf("  Final HBD_LBA: %u (override preserved after trampolines)\n",dynamic_hbd_lba);
        } else {
            dynamic_hbd_lba=(EXE_LBA+exe_sectors+3)&~3u;
            printf("  Final dynamic HBD_LBA: %u (recomputed after trampolines)\n",dynamic_hbd_lba);
        }
        max_exe=dynamic_hbd_lba*USER_SIZE;
        printf("  Final EXE overlap check: %u / %u bytes — %s\n",
            r.exe_size,max_exe,r.exe_size<=max_exe?"OK":"OVERLAP!");
        if(r.exe_size>max_exe){
            printf("  ERROR: Final EXE (%u) exceeds available space (%u)\n",r.exe_size,max_exe);
            return r;
        }
    }

    // 8. Extract DQ4 HBD (replaces DW7 HBD entirely)
    printf("  Extracting DQ4 HBD...\n");
    auto dq4_hbd=extract_hbd_from_disc(dq4_hbd_disc_path,DQ4_HBD_DISC_START,DQ4_HBD_SIZE);
    if(dq4_hbd.empty()){printf("  ERROR: Cannot extract DQ4 HBD\n");return r;}
    printf("  DQ4 HBD: %zu bytes\n",dq4_hbd.size());

    // 8c. Process DQ4 HBD — conditional on build_flags bit 2
    HbdProcessResult proc_result={};
    if(build_flags&0x4){
        printf("  Processing DQ4 HBD (HuffTree re-encode + sub-block swaps)...\n");
        HbdReencoder reencoder;
        reencoder.load(dq4_hbd.data(),(uint32_t)dq4_hbd.size(),
                       hybrid_tree.data(),(uint32_t)hybrid_tree.size());
        // Load translation map for text block re-encoding
        if(translation_map_path&&*translation_map_path){
            if(!reencoder.load_translation_map(translation_map_path)){
                printf("  ERROR: Cannot load translation map: %s\n",translation_map_path);
                return r;
            }
        }else{
            printf("  WARNING: No translation map path provided — HBD blocks will not be converted\n");
        }
        proc_result=reencoder.process_hbd(DQ4_HBD_DISC_START,DQ4_BASE_SECTOR);
        printf("  HBD processed: folders=%u files=%u blocks=%u converted=%u reencoded=%u failed=%u swaps=%u errors=%u\n",
            proc_result.folders_parsed,proc_result.files_parsed,
            proc_result.blocks_processed,proc_result.blocks_converted,
            proc_result.blocks_reencoded,proc_result.blocks_reencode_failed,
            proc_result.subblock_swaps,proc_result.errors);
        if(!proc_result.success){
            printf("  ERROR: HBD processing had %u errors — aborting build (V1: no partial re-encode)\n",proc_result.errors);
            return r;
        }
        r.hbd_blocks_processed=proc_result.blocks_processed;
        r.hbd_blocks_converted=proc_result.blocks_converted;
        r.hbd_subblock_swaps=proc_result.subblock_swaps;
        r.hbd_lba_patches=proc_result.lba_patches;

        // Get processed DQ4 HBD data
        uint32_t dq4_processed_size=reencoder.size();
        printf("  Processed DQ4 HBD size: %u bytes (original: %zu)\n",dq4_processed_size,dq4_hbd.size());
        dq4_hbd.assign(reencoder.raw(),reencoder.raw()+dq4_processed_size);
    }else{
        printf("  HBD re-encoding: SKIPPED (raw DQ4 HBD, no re-encoding)\n");
        // Truncate DQ4 HBD to last non-zero sector to preserve DW7 FMV data at LBA 146621
        // V42 fix: only write non-zero sectors, leave DW7 data intact beyond that point
        uint32_t total_dq4_sectors=(uint32_t)dq4_hbd.size()/USER_SIZE;
        uint32_t last_nonzero=0;
        for(uint32_t s=0;s<total_dq4_sectors;s++){
            const uint8_t* p=dq4_hbd.data()+s*USER_SIZE;
            for(uint32_t i=0;i<USER_SIZE;i++){
                if(p[i]!=0){last_nonzero=s;break;}
            }
        }
        uint32_t truncated_sectors=last_nonzero+1;
        uint32_t truncated_size=truncated_sectors*USER_SIZE;
        printf("  HBD truncation: %u sectors (last non-zero at sector %u), %u bytes (was %zu)\n",
            truncated_sectors,last_nonzero,truncated_size,dq4_hbd.size());
        dq4_hbd.resize(truncated_size);
        r.hbd_blocks_processed=0;
        r.hbd_blocks_converted=0;
        r.hbd_subblock_swaps=0;
        r.hbd_lba_patches=0;
    }

    // 8d. Use processed DQ4 HBD as the sole HBD data (replaces DW7 HBD)
    std::vector<uint8_t>& hbd_data=dq4_hbd;
    printf("  HBD data: %zu bytes (DQ4 only, no DW7 concatenation)\n",hbd_data.size());

    // 8.5 Dynamic CLI Hotfixes — apply before writing EXE to disc
    exe.patch_hotfixes(hotfix_file_path);

    // 8.6 MIPS Disassembly Dump (if requested via CLI)
    if(disasm_range_str && *disasm_range_str){
        std::string s(disasm_range_str);
        size_t colon = s.find(':');
        if(colon != std::string::npos){
            try {
                uint32_t start = std::stoul(s.substr(0, colon), nullptr, 16);
                uint32_t end = std::stoul(s.substr(colon + 1), nullptr, 16);
                exe.disasm_range(start, end);
            } catch(...) {
                printf("  [MIPS DISASM] Error parsing range string: %s\n", disasm_range_str);
            }
        }
    }

    // 9. Assemble disc: copy DW7 disc, write EXE + HBD, update ISO dir + PVD
    printf("  Assembling disc...\n");
    // Copy DW7 disc to output
    {
        std::ifstream src(dw7_disc_path,std::ios::binary);
        if(!src.is_open()){printf("  ERROR: Cannot open DW7 disc: %s\n",dw7_disc_path);return r;}
        std::ofstream dst(output_bin_path,std::ios::binary);
        if(!dst.is_open()){printf("  ERROR: Cannot create output: %s\n",output_bin_path);return r;}
        dst<<src.rdbuf();
    }

    IsoImage iso;
    if(!iso.open(output_bin_path)){printf("  ERROR: Cannot reopen output disc\n");return r;}

    // Extend disc if needed to fit hybrid HBD
    uint32_t hbd_sectors_total=(uint32_t)((hbd_data.size()+USER_SIZE-1)/USER_SIZE);
    uint64_t needed_size=(uint64_t)(dynamic_hbd_lba+hbd_sectors_total)*SECTOR_SIZE;
    {
        std::ifstream chk(output_bin_path,std::ios::binary|std::ios::ate);
        uint64_t cur=chk.tellg(); chk.close();
        if(needed_size>cur){
            printf("  Extending disc: %llu -> %llu bytes (for %u HBD sectors)\n",
                (unsigned long long)cur,(unsigned long long)needed_size,hbd_sectors_total);
            iso.close();
            extend_disc_mode2(output_bin_path,needed_size);
            if(!iso.open(output_bin_path)){printf("  ERROR: Cannot reopen extended disc\n");return r;}
        }
    }

    // Write EXE at sector 24
    printf("  Writing EXE at sector %u...\n",EXE_LBA);
    std::vector<uint8_t> exe_out(exe.raw(),exe.raw()+exe.size());
    write_raw_data(iso,EXE_LBA,exe_out);

    // Write processed HBD at dynamic LBA
    printf("  Writing processed HBD at sector %u...\n",dynamic_hbd_lba);
    write_raw_data(iso,dynamic_hbd_lba,hbd_data);
    uint32_t hbd_sectors_actual=(uint32_t)(hbd_data.size()+USER_SIZE-1)/USER_SIZE;
    printf("  HBD spans sectors %u-%u (%u sectors, %zu bytes)\n",
        dynamic_hbd_lba,dynamic_hbd_lba+hbd_sectors_actual-1,hbd_sectors_actual,hbd_data.size());

    // Truncate disc to compact size: only system sectors + HBD sectors
    // This removes bloated trailing DW7 sectors that would inflate the output
    // BUT: when hbd_lba_override is set, we must NOT truncate — original DW7
    // sectors between EXE and HBD contain FMV data that must be preserved.
    uint32_t total_sectors_needed=dynamic_hbd_lba+hbd_sectors_actual;
    uint64_t truncated_size=(uint64_t)total_sectors_needed*SECTOR_SIZE;
    if(hbd_lba_override>0){
        printf("  Truncation SKIPPED — preserving original DW7 sectors (FMV at LBA 146621)\n");
    } else {
        iso.close();
        {
            std::ifstream chk(output_bin_path,std::ios::binary|std::ios::ate);
            uint64_t cur=chk.tellg(); chk.close();
            if(truncated_size<cur){
                printf("  Truncating disc: %llu -> %llu bytes (removing %llu bytes of trailing DW7 padding)\n",
                    (unsigned long long)cur,(unsigned long long)truncated_size,
                    (unsigned long long)(cur-truncated_size));
                // Truncate by opening in read/write, seeking to target, and truncating
                std::filesystem::resize_file(output_bin_path,(uint64_t)truncated_size);
            }
        }
        if(!iso.open(output_bin_path)){printf("  ERROR: Cannot reopen truncated disc\n");return r;}
    }

    // Update ISO directory
    printf("  Updating ISO directory...\n");
    update_iso_dir(iso,r.exe_size,(uint32_t)hbd_data.size(),dynamic_hbd_lba);
    printf("  HBD: LBA=%u, size=%zu\n",dynamic_hbd_lba,hbd_data.size());

    // Update license sector
    printf("  Updating license sector...\n");
    update_license_sector(iso);

    // Update PVD
    printf("  Updating PVD...\n");
    update_pvd(iso);

    iso.close();

    // Write CUE
    // Extract basename from output_bin_path
    std::string bin_name=output_bin_path;
    size_t slash=bin_name.find_last_of("\\/");
    if(slash!=std::string::npos)bin_name=bin_name.substr(slash+1);
    write_cue(output_cue_path,bin_name.c_str());

    // Run EDC/ECC
    if(edcre_path&&*edcre_path){
        printf("  Running EDC/ECC regeneration...\n");
        int ec=run_edcre(edcre_path,output_bin_path);
        printf("  EDC/ECC: %s\n",ec==0?"SUCCESS":"FAILED");
    }

    // Final size
    {
        std::ifstream f(output_bin_path,std::ios::binary|std::ios::ate);
        r.disc_size=(uint32_t)f.tellg();
    }
    printf("\n  BUILD COMPLETE\n");
    printf("  Size: %u bytes\n",r.disc_size);
    printf("  Patches: tree=%u abs=%u(matched=%u,delta=%u) rel=%u\n",
        r.tree_patches,r.abs_matched+r.abs_delta,r.abs_matched,r.abs_delta,
        r.rel_matched);
    printf("  HBD: blocks=%u converted=%u reencoded=%u failed=%u swaps=%u\n",
        r.hbd_blocks_processed,r.hbd_blocks_converted,
        proc_result.blocks_reencoded,proc_result.blocks_reencode_failed,
        r.hbd_subblock_swaps);
    printf("  Strategy: surgical disc-check (no cd_init) + CD-ROM stall bypass + HuffTree re-encode + BSS threadsafe\n");
    printf("  EXE: %u bytes, PC0=0x%08X, tree at RAM 0x%08X\n",
        r.exe_size,r.new_pc0,TREE_RAM_ADDR);

    // P2-4: Run integrity verification after all patches
    printf("\n  --- Post-build EXE Integrity Verification ---\n");
    if(!exe.verify_integrity()){
        printf("  WARNING: EXE integrity check FAILED — build may be unstable\n");
    }
    printf("  --- Patch Summary ---\n");
    exe.list_patches();

    r.success=1;
    return r;
}

// ===== Helper: update SYSTEM.CNF (sector 23) — change boot filename =====
// DQ4 disc has "SLPM_869.16" in SYSTEM.CNF; we need "SLUSP012.06".
// Both are 12 chars (including dot), so it's an in-place replacement.
static bool update_system_cnf(IsoImage& iso){
    std::vector<uint8_t> cnf(USER_SIZE,0);
    int rc=iso.read_sector(23,cnf.data());
    printf("  [DEBUG] update_system_cnf: read_sector(23) returned %d\n",rc);
    if(rc!=0)return false;
    // Debug: print first 80 bytes of CNF
    printf("  [DEBUG] CNF first 80 bytes: ");
    for(int i=0;i<80&&cnf[i];i++)printf("%c",cnf[i]);
    printf("\n");
    const char* old_name="SLPM_869.16";
    const char* new_name="SLUSP012.06";
    const size_t NAME_LEN=11;  // Both names are 11 chars (no null in CNF context)
    bool found=false;
    for(uint32_t i=0;i+NAME_LEN<=USER_SIZE;i++){
        if(std::memcmp(cnf.data()+i,old_name,NAME_LEN)==0){
            std::memcpy(cnf.data()+i,new_name,NAME_LEN);
            found=true;
            printf("  [DEBUG] Found SLPM_869.16 at CNF offset %u, replaced with SLUSP012.06\n",i);
        }
    }
    if(!found){
        printf("  WARNING: SLPM_869.16 not found in SYSTEM.CNF — boot may fail\n");
        return false;
    }
    int wrc=iso.write_sector(23,cnf.data());
    printf("  [DEBUG] write_sector(23) returned %d\n",wrc);
    printf("  SYSTEM.CNF: SLPM_869.16 -> SLUSP012.06\n");
    return true;
}

// ===== Helper: update ISO directory for reverse Frankenstein =====
// On DQ4 disc: EXE is SLPM_869.16 at sector 23, HBD is HBD1PS1D.Q41 at sector 362.
// We need to:
//   - Rename EXE entry from SLPM_869.16 to SLUSP012.06
//   - Update EXE LBA to 24 (sector 24 is where we write the DW7 EXE)
//   - Update EXE size
//   - HBD entry: NO RENAME (MISS-2 fix — we patch the EXE string instead)
//   - Update HBD LBA to 355 (shifted from DQ4 native 362 to make room for EXE)
//   - Update HBD size if needed
static void update_iso_dir_reverse(IsoImage& iso,uint32_t exe_size,uint32_t hbd_size){
    std::vector<uint8_t> dir(USER_SIZE,0);
    if(iso.read_sector(22,dir.data())!=0){
        printf("  ERROR: Failed to read ISO directory sector 22\n");
        return;
    }

    const char* old_exe="SLPM_869.16";
    const char* new_exe="SLUSP012.06";
    const size_t EXE_NAME_LEN=11;  // 11 chars, no null terminator in ISO dir context
    constexpr uint32_t EXE_SECTOR=24;
    constexpr uint32_t HBD_SECTOR=362;

    uint32_t offset=0;
    while(offset<dir.size()){
        uint8_t rec_len=dir[offset];
        if(rec_len==0)break;
        uint8_t name_len=dir[offset+32];

        // Check for HBD file
        bool has_hbd=false;
        for(uint32_t i=0;i+2<name_len;i++){
            if(dir[offset+33+i]=='H'&&dir[offset+34+i]=='B'&&dir[offset+35+i]=='D'){
                has_hbd=true; break;
            }
        }
        if(has_hbd){
            // MISS-2: No ISO directory rename — keep native .Q41 extension.
            // The EXE string has been patched from 'hbd1ps1d.w71' to 'hbd1ps1d.q41'
            // so the DW7 EXE will find the DQ4 HBD file by its native .Q41 name.
            // Clear the hidden file flag so CdSearchFile can find it
            dir[offset+25] &= ~0x01;
            
            // Update HBD LBA to 362 and size
            std::memcpy(dir.data()+offset+2,&HBD_SECTOR,4);
            uint32_t hbd_be=_byteswap_ulong(HBD_SECTOR);
            std::memcpy(dir.data()+offset+6,&hbd_be,4);
            std::memcpy(dir.data()+offset+10,&hbd_size,4);
            uint32_t size_be=_byteswap_ulong(hbd_size);
            std::memcpy(dir.data()+offset+14,&size_be,4);
            printf("  ISO dir: HBD entry LBA=%u size=%u (hidden flag cleared)\n",HBD_SECTOR,hbd_size);
        } else {
            // Check for EXE entry (SLPM_869.16 or any SL* entry)
            if(name_len>=EXE_NAME_LEN){
                bool is_exe=true;
                for(uint32_t i=0;i<EXE_NAME_LEN;i++){
                    if(dir[offset+33+i]!=old_exe[i]){is_exe=false;break;}
                }
                if(is_exe){
                    // Rename to SLUSP012.06
                    printf("  ISO dir: found EXE entry '%.11s' at offset %u, renaming...\n",dir.data()+offset+33,offset);
                    std::memcpy(dir.data()+offset+33,new_exe,EXE_NAME_LEN);
                    // Update LBA to sector 24
                    std::memcpy(dir.data()+offset+2,&EXE_SECTOR,4);
                    uint32_t exe_be=_byteswap_ulong(EXE_SECTOR);
                    std::memcpy(dir.data()+offset+6,&exe_be,4);
                    // Update size
                    std::memcpy(dir.data()+offset+10,&exe_size,4);
                    uint32_t size_be=_byteswap_ulong(exe_size);
                    std::memcpy(dir.data()+offset+14,&size_be,4);
                    printf("  ISO dir: EXE renamed SLPM_869.16->SLUSP012.06, LBA=%u size=%u\n",
                        EXE_SECTOR,exe_size);
                }
            }
        }
        offset+=rec_len;
    }
    iso.write_sector(22,dir.data());
}

// ===== FrankensteinBuilder::build_reverse_option_a =====
// Reverse Frankenstein: DQ4 disc as base, DW7 EXE swapped in.
// DQ4 HBD stays at native sector 362, completely unmodified.
// Full patch suite from build_v39 tree_mode=3, adapted for DQ4 disc base.
BuildResult FrankensteinBuilder::build_reverse_option_a(
    const char* dq4_disc_path,
    const char* dw7_exe_path,
    const char* hybrid_tree_path,
    const char* output_bin_path,
    const char* output_cue_path,
    const char* edcre_path,
    uint32_t build_flags,
    const char* translation_map_path,
    const char* hotfix_file_path,
    bool no_xa_stub,
    const char* thread_blob_path,
    bool safe_boot_stub)
{
    BuildResult r={};
    printf("\n  Profile: reverse_option_a (DQ4 disc base + DW7 EXE swap + full patch suite)\n");
    if(safe_boot_stub) printf("  Safe boot stub: ENABLED (KSEG1 uncached translation)\n");

    // 1. Load DW7 EXE
    auto exe_buf=read_file(dw7_exe_path);
    if(exe_buf.empty()){printf("  ERROR: Cannot read DW7 EXE: %s\n",dw7_exe_path);return r;}
    printf("  DW7 EXE: %zu bytes\n",exe_buf.size());

    ExePatcher exe;
    if(!exe.load(exe_buf.data(),(uint32_t)exe_buf.size())){
        printf("  ERROR: ExePatcher::load failed\n");return r;
    }
    exe.set_safe_boot_stub(safe_boot_stub);

    // 2. Load hybrid tree
    auto hybrid_tree=read_file(hybrid_tree_path);
    if(hybrid_tree.empty()){printf("  ERROR: Cannot read hybrid tree: %s\n",hybrid_tree_path);return r;}
    printf("  Hybrid tree: %zu bytes\n",hybrid_tree.size());

    // =====================================================
    // FULL PATCH SUITE — tree_mode=3 approach from build_v39
    // Tree at 0x800BC700 (end of original EXE), BSS narrowed
    // All decompressor patches, R-TREEHOOK, HBD trampoline, etc.
    // =====================================================
    constexpr uint32_t TREE_FILE_OFF=0xA4800;  // Original EXE end = RAM 0x800BC700
    constexpr uint32_t TREE_RAM_ADDR=0x800BC700;
    constexpr uint32_t ORIG_PC0=0x8008E284;

    // 3. Append hybrid tree at TREE_FILE_OFF (RAM 0x800BC700)
    if(exe.size()<TREE_FILE_OFF){
        while(exe.size()<TREE_FILE_OFF)exe.append_payload(nullptr,0);
    }
    exe.append_payload(hybrid_tree.data(),(uint32_t)hybrid_tree.size());
    uint32_t pad=(2048-(exe.size()%2048))%2048;
    if(pad>0){
        std::vector<uint8_t> zeros(pad,0);
        exe.append_payload(zeros.data(),pad);
    }
    exe.update_text_size();
    r.exe_size=exe.size();
    printf("  Appended hybrid tree at file offset 0x%X (RAM 0x%08X), EXE size: %u\n",
        TREE_FILE_OFF,TREE_RAM_ADDR,r.exe_size);

    // 4. Patch tree references (0x800EF1C8 -> 0x800BC700)
    uint16_t new_lui,new_addiu;
    ExePatcher::compute_tree_addr(TREE_RAM_ADDR,new_lui,new_addiu);
    uint32_t verify=(new_lui<<16)+(new_addiu>=0x8000?(int32_t)(int16_t)new_addiu:new_addiu);
    printf("  Tree: LUI=0x%04X ADDIU=0x%04X -> 0x%08X (%s)\n",
        new_lui,new_addiu,verify,verify==TREE_RAM_ADDR?"OK":"FAIL");
    r.tree_patches=exe.patch_tree_references(OLD_LUI_IMM,OLD_ADDIU_IMM,new_lui,new_addiu);
    printf("  Tree ref patches: %u\n",r.tree_patches);

    r.new_pc0=*(uint32_t*)(exe.raw()+0x10);
    printf("  PC0: 0x%08X (unchanged)\n",r.new_pc0);

    // 5. BSS clear — preserve tree at 0x800BC700, keep original BSS end 0x800F4980
    if(exe.patch_bss_clear_narrow()){
        printf("  BSS clear patched: START moved past tree, END kept at original 0x800F4980\n");
    }else{
        printf("  WARNING: BSS clear patch FAILED — tree may be zeroed!\n");
    }

    // 6. Zero pre-tree BSS region (0x800BC668-0x800BC700)
    exe.zero_pre_tree_bss();

    // 7. Initialize runtime tree pointer variables at 0x800BC6F8 and 0x800BC6FC
    {
        uint32_t var_off=TREE_PTR_VAR_OFF;       // 0xA4FF8
        uint32_t var_plus2_off=TREE_PTR_VAR_PLUS2_OFF;  // 0xA4FFC
        if(var_off+4<=exe.size() && var_plus2_off+4<=exe.size()){
            uint32_t tree_addr=TREE_RAM_ADDR;
            uint32_t tree_addr_plus2=tree_addr+2;
            std::memcpy((uint8_t*)exe.raw()+var_off,&tree_addr,4);
            std::memcpy((uint8_t*)exe.raw()+var_plus2_off,&tree_addr_plus2,4);
            printf("  Tree ptr variables: 0x%08X = 0x%08X (raw), 0x%08X = 0x%08X (+2)\n",
                TREE_PTR_VAR_RAM,tree_addr,TREE_PTR_VAR_PLUS2_RAM,tree_addr_plus2);
        }
    }

    // 8. Decompressor patches (Targets 4, 6) — Target 5R deferred to after HBD trampoline (Constraint 3)
    if(exe.patch_decomp_tree_pointer()){
        printf("  Decompressor Target 4 (tree pointer): OK\n");
    }else{
        printf("  WARNING: Decompressor Target 4 (tree pointer) FAILED\n");
    }
    if(exe.patch_decomp_offset_b_mask()){
        printf("  Decompressor Target 6 (offset_b mask): OK\n");
    }else{
        printf("  WARNING: Decompressor Target 6 (offset_b mask) FAILED\n");
    }

    // 8.5 Dynamic CLI Hotfixes
    exe.patch_hotfixes(hotfix_file_path);

    // 9. LBA patches: DW7 expects HBD at 354, we keep DQ4 HBD at sector 362
    //    (EXE with hybrid tree occupies sectors 24-355, HBD starts at 362)
    constexpr uint32_t HBD_TARGET_SECTOR=362;
    r.lba_patches=exe.patch_lba_references(354,HBD_TARGET_SECTOR);
    printf("  LBA broad scan: %u references patched (354 -> %u)\n",r.lba_patches,HBD_TARGET_SECTOR);
    r.seq_patches=exe.patch_sequential_sector_table(354,HBD_TARGET_SECTOR);
    printf("  Sequential sector table: %u entries patched\n",r.seq_patches);

    // 9a. Final LBA sweep: REMOVED (prevent EXE instruction corruption)
    printf("  LBA final sweep: SKIPPED (prevent instruction corruption)\n");

    // 9b. HBD LBA table patch — REMOVED Aug 4, 2026 (V3: LBA hypothesis FALSIFIED)
    //     patch_hbd_lba_table applied +146 delta to 128 entries; built disc still
    //     black-screened in DuckStation. The DW7 EXE locates HBD by ISO directory
    //     filename, not by hardcoded LBA table. See GLM_HANDOFF_BACK_LBA72_FALSIFIED_Aug4_2026.md.
    r.hbd_table_patches=0;
    printf("  HBD LBA table: SKIPPED (V3 — LBA hypothesis falsified Aug 4)\n");

    // 10. Disc-check bypass — 3-patch suite (proven Enix logo config)
    // Only the 3 caller-side exit patches (exit1/2/3 force success).
    // The extra 8 patches (nop_timeout, nop_error, redirect_trap, graft_a/b/c,
    // disc_check_6, disc_check_jr_ra) were removed because they break CD-ROM
    // initialization and cause the game to stall after reading LBA 154-174.
    {
        static const uint32_t dc_offsets[]={
            0x6112C,0x611D8,0x613B8   // exit1, exit2, exit3: force success
        };
        static const uint32_t dc_patches[]={
            0x24020001,0x24020001,0x24020001   // li $v0, 1 (force success)
        };
        r.disc_patches=exe.patch_disc_check(dc_offsets,dc_patches,3);
        printf("  Disc-check bypass (3-patch Enix logo config): %u patches applied\n",r.disc_patches);
    }

    // 11. CD-ROM stall bypass — REMOVED (D3: dead code, stale offset, proven ineffective)
    printf("  CD-ROM stall bypass: REMOVED (D3 — dead code)\n");

    // 12. HBD type trampoline — RE-ENABLED (full patch suite)
    exe.set_tramp_base(0x800BCF00);
    if(exe.patch_hbd_type_trampoline()){
        r.trampoline_patches++;
        printf("  HBD type trampoline: OK\n");
    }else{
        printf("  WARNING: HBD type trampoline FAILED\n");
    }

    // 12b. Malloc clamp — RE-ENABLED (full patch suite)
    if(exe.patch_malloc_clamp()){
        printf("  Malloc clamp (P1): OK\n");
    }else{
        printf("  WARNING: Malloc clamp (P1) FAILED\n");
    }

    // 12c. Target 5R (Root ID +1 runtime) — RE-ENABLED (full patch suite)
    if(exe.patch_decomp_root_id_runtime()){
        printf("  Decompressor Target 5R (root ID runtime): OK\n");
    }else{
        printf("  WARNING: Decompressor Target 5R FAILED\n");
    }

    // 13. R-TREEHOOK — RE-ENABLED (full patch suite)
    if(exe.patch_tree_hook()){
        printf("  R-TREEHOOK: OK\n");
    }else{
        printf("  WARNING: R-TREEHOOK FAILED\n");
    }

    // 15. FMV XA stub + CD-ROM FIFO drain (Frankenstein Fixes)
    //     XA stub: Overwrite XA playback init entry (0x8008B32C) with a
    //              6-instruction flag-setting stub that sets $v0=1, writes
    //              1 to BIOS event flags 0x800E2038 and 0x800E3D94, then returns.
    //              This cures event starvation (root cause of CP3/CP4/CP5 stalls).
    //              SKIPPED when no_xa_stub=true — FMV player must run to init GPU.
    //     FIFO drain: Inject CLRPRM trampoline at 0x8008B65C to clear
    //                 stale CD-ROM parameter FIFO before each command dispatch.
    r.fmv_bcd_patches = 0;
    if(!no_xa_stub){
        if(exe.patch_fmv_skip_xa_stub()){
            r.fmv_bcd_patches++;
            printf("  FMV XA stub: OK\n");
        }else{
            printf("  WARNING: FMV XA stub FAILED\n");
        }
        if(exe.patch_vblank_wait_bypass()){
            r.fmv_bcd_patches++;
            printf("  VBlank wait bypass: OK\n");
        }else{
            printf("  WARNING: VBlank wait bypass FAILED\n");
        }
    }else{
        printf("  FMV XA stub: SKIPPED (no_xa_stub — preserving FMV player for GPU init)\n");
        printf("  VBlank wait bypass: SKIPPED (no_xa_stub)\n");
    }
    if(exe.patch_fifo_drain()){
        r.trampoline_patches++;
        printf("  CD-ROM FIFO drain (CLRPRM): OK\n");
    }else{
        printf("  WARNING: CD-ROM FIFO drain FAILED\n");
    }

    // 18. HBD string patch (MISS-2): Patch EXE string 'hbd1ps1d.w71' -> 'hbd1ps1d.q41'
    //     This lets the DW7 EXE find the DQ4 HBD file on disc by its native .Q41 extension.
    //     The ISO directory keeps the original .Q41 name (no renaming to .W71).
    {
        const char w71_pattern[]={'h','b','d','1','p','s','1','d','.','w','7','1'};
        const char q41_replacement[]={'h','b','d','1','p','s','1','d','.','q','4','1'};
        const uint32_t pat_len=sizeof(w71_pattern);
        bool found=false;
        for(uint32_t i=0;i+pat_len<=exe.size();i++){
            if(std::memcmp((uint8_t*)exe.raw()+i,w71_pattern,pat_len)==0){
                found=true;
                std::memcpy((uint8_t*)exe.raw()+i,q41_replacement,pat_len);
                printf("  HBD string: patched 'hbd1ps1d.w71' -> 'hbd1ps1d.q41' at file offset 0x%X\n",i);
                break;
            }
        }
        if(!found){
            printf("  ERROR: HBD string 'hbd1ps1d.w71' NOT FOUND in EXE — aborting build (V2 guard)\n");
            return r;
        }
    }

    // 18b. FMV BCD seek patch: REMOVED — XA stub at 0x8008B32C returns success
    //      before any CD-ROM seek is issued. CLRPRM FIFO drain handles stale params.
    printf("  FMV BCD seek: SKIPPED (XA stub returns success — no Setloc call will execute)\n");

    // 19. Pad EXE to BSS start to avoid uninitialized BSS gaps containing garbage
    {
        uint32_t bss_start_ram = 0x800BD700;
        uint32_t current_end_ram = EXE_LOAD_ADDR + (uint32_t)exe.size() - 0x800;
        if(bss_start_ram > current_end_ram){
            uint32_t pad = bss_start_ram - current_end_ram;
            std::vector<uint8_t> zeros(pad, 0);
            exe.append_payload(zeros.data(), pad);
            printf("  Padded BSS gap: %u bytes to 0x%08X\n", pad, bss_start_ram);
        }
    }

    // 19b. Update EXE size after all trampoline/stub patches and BSS padding
    exe.update_text_size();
    r.exe_size=exe.size();
    printf("  Final EXE size (pre-MISS1): %u bytes (text_size=0x%X)\n",r.exe_size,(uint32_t)(exe.size()-0x800));

    // 19c. MISS-1: Thread Blob Injection
    //   Append thread_code_blob.bin (2048 bytes) to EXE, then append a MIPS boot copy stub
    //   that copies the blob from its on-disc RAM address to 0x800D9E80, then jumps to original PC0.
    //   Finally, redirect EXE header PC0 to the boot copy stub.
    if(thread_blob_path&&*thread_blob_path){
        auto blob=read_file(thread_blob_path);
        if(blob.empty()){
            printf("  ERROR: Cannot read thread blob: %s\n",thread_blob_path);
            return r;
        }
        printf("  Thread blob: %zu bytes from %s\n",blob.size(),thread_blob_path);

        // Align to 4
        uint32_t align_pad=(4-(exe.size()%4))%4;
        if(align_pad>0){
            std::vector<uint8_t> z(align_pad,0);
            exe.append_payload(z.data(),align_pad);
        }

        // Append blob to EXE
        uint32_t blob_file_off=(uint32_t)exe.size();
        uint32_t blob_ram_addr=EXE_LOAD_ADDR+blob_file_off-0x800;
        exe.append_payload(blob.data(),(uint32_t)blob.size());
        printf("  Thread blob appended at file offset 0x%X (RAM 0x%08X)\n",blob_file_off,blob_ram_addr);

        // Align before stub
        align_pad=(4-(exe.size()%4))%4;
        if(align_pad>0){
            std::vector<uint8_t> z(align_pad,0);
            exe.append_payload(z.data(),align_pad);
        }

        // Build boot copy stub
        uint32_t stub_file_off=(uint32_t)exe.size();
        uint32_t stub_ram_addr=EXE_LOAD_ADDR+stub_file_off-0x800;

        uint16_t src_hi,src_lo;
        split_addr(blob_ram_addr,src_hi,src_lo);

        // KSEG1 uncached translation for destination (cache coherency)
        uint32_t dst_base = 0x800D9E80;
        uint32_t dst_end = 0x800DA680;
        if(safe_boot_stub){
            dst_base |= 0x20000000;  // KSEG1: 0xA00D9E80
            dst_end  |= 0x20000000;  // KSEG1: 0xA00DA680
            printf("  Boot copy stub: KSEG1 uncached dst=0x%08X end=0x%08X\n",dst_base,dst_end);
        }
        uint16_t dst_hi,dst_lo,end_hi,end_lo;
        split_addr(dst_base,dst_hi,dst_lo);
        split_addr(dst_end,end_hi,end_lo);

        uint32_t stub[13]={
            MIPS_LUI(8,src_hi),       MIPS_ADDIU(8,8,src_lo),     // t0 = src (blob RAM)
            MIPS_LUI(9,dst_hi),       MIPS_ADDIU(9,9,dst_lo),     // t1 = dst (0x800D9E80 or KSEG1)
            MIPS_LUI(10,end_hi),      MIPS_ADDIU(10,10,end_lo),   // t2 = end (0x800DA680 or KSEG1)
            MIPS_LW(11,0,8),          MIPS_ADDIU(8,8,4),          // lw t3,0(t0); addiu t0,4 (delay slot fill)
            MIPS_SW(11,0,9),          MIPS_BNE(9,10,-4),          // sw t3,0(t1); bne t1,t2,loop
            MIPS_ADDIU(9,9,4),        // delay slot: addiu t1,4
            MIPS_J(0x8008E284),       MIPS_NOP                    // j original PC0; nop
        };

        std::vector<uint8_t> stub_bytes;
        for(uint32_t insn:stub){
            stub_bytes.push_back(insn&0xFF);
            stub_bytes.push_back((insn>>8)&0xFF);
            stub_bytes.push_back((insn>>16)&0xFF);
            stub_bytes.push_back((insn>>24)&0xFF);
        }
        exe.append_payload(stub_bytes.data(),(uint32_t)stub_bytes.size());
        printf("  Boot copy stub appended at file offset 0x%X (RAM 0x%08X), 12 instructions\n",
            stub_file_off,stub_ram_addr);

        // Patch PC0 in EXE header to point to boot copy stub
        std::memcpy((uint8_t*)exe.raw()+0x10,&stub_ram_addr,4);
        r.new_pc0=stub_ram_addr;
        printf("  PC0 redirected: 0x%08X -> 0x%08X (boot copy stub)\n",ORIG_PC0,stub_ram_addr);

        // Pad to sector boundary, update text_size.
        // The BIOS will not load the EXE unless t_size is a multiple of 2048;
        // it reads the header sector and silently abandons the text section.
        // This append runs after the last sector-aligned pad, so it must
        // re-pad — omitting it is what stalled v99-v112 (t_size=0xA6034).
        uint32_t sp=(2048-(exe.size()%2048))%2048;
        if(sp>0){
            std::vector<uint8_t> z(sp,0);
            exe.append_payload(z.data(),sp);
            printf("  Sector-align pad: %u bytes\n",sp);
        }
        exe.update_text_size();
        r.exe_size=exe.size();
        printf("  Final EXE size (post-MISS1): %u bytes (text_size=0x%X)\n",r.exe_size,(uint32_t)(exe.size()-0x800));
    }else{
        printf("  MISS-1: SKIPPED (no thread_blob_path provided)\n");
    }

    // 20a. GATE: t_size must be sector-aligned or the BIOS never loads the EXE.
    //      Hard-fail here rather than shipping a disc that boots to a silent
    //      stall with every downstream patch verified and none of them running.
    {
        uint32_t t_size;
        std::memcpy(&t_size,(const uint8_t*)exe.raw()+0x1C,4);
        printf("  Gate: t_size=0x%X, %% 2048 = %u — %s\n",t_size,t_size%2048,
            t_size%2048==0?"OK":"MISALIGNED!");
        if(t_size%2048!=0){
            printf("  ERROR: t_size 0x%X is not a multiple of 0x800. The PSX BIOS\n",t_size);
            printf("         will read the EXE header and abandon the text load.\n");
            return r;
        }
        if((uint32_t)exe.size()!=t_size+0x800){
            printf("  ERROR: EXE size %u != t_size+0x800 (%u)\n",(uint32_t)exe.size(),t_size+0x800);
            return r;
        }
    }

    // 20. Verify EXE fits in available space (sectors 24-355 = 332 sectors)
    uint32_t max_exe=(HBD_TARGET_SECTOR-EXE_LBA)*USER_SIZE;
    printf("  Max EXE before HBD overlap: %u bytes — %s\n",max_exe,
        r.exe_size<=max_exe?"OK":"OVERLAP!");
    if(r.exe_size>max_exe){
        printf("  ERROR: Patched EXE (%u) exceeds available space (%u)\n",r.exe_size,max_exe);
        return r;
    }

    // 21. Copy DQ4 disc to output
    printf("  Copying DQ4 disc as base...\n");
    {
        std::ifstream src(dq4_disc_path,std::ios::binary);
        if(!src.is_open()){printf("  ERROR: Cannot open DQ4 disc: %s\n",dq4_disc_path);return r;}
        std::ofstream dst(output_bin_path,std::ios::binary);
        if(!dst.is_open()){printf("  ERROR: Cannot create output: %s\n",output_bin_path);return r;}
        dst<<src.rdbuf();
    }

    // 22. Write patched DW7 EXE at sector 24
    IsoImage iso;
    if(!iso.open(output_bin_path)){printf("  ERROR: Cannot reopen output disc\n");return r;}
    printf("  Writing patched DW7 EXE at sector %u (%u bytes)...\n",EXE_LBA,r.exe_size);
    std::vector<uint8_t> exe_out(exe.raw(),exe.raw()+exe.size());
    write_raw_data(iso,EXE_LBA,exe_out);

    // 22a. Boot sector normalization: zero LBA 0-3 to match DW7 master
    {
        std::vector<uint8_t> zero_sector(SECTOR_SIZE,0);
        for(uint32_t lba=0;lba<4;lba++){
            iso.write_sector(lba,zero_sector.data());
        }
        printf("  Boot sectors LBA 0-3 zeroed\n");
    }

    // 22b. HBD Re-encoding (bit 2 of build_flags)
    //    HBD is moved from sector 362 to sector 356 to make room for the EXE
    uint32_t actual_hbd_size=DQ4_HBD_SIZE;
    if(build_flags&0x4){
        printf("  HBD Re-encoding: ENABLED\n");
        auto dq4_hbd=extract_hbd_from_disc(dq4_disc_path,DQ4_HBD_DISC_START,DQ4_HBD_SIZE);
        if(dq4_hbd.empty()){
            printf("  ERROR: Cannot extract DQ4 HBD from %s at sector %u\n",dq4_disc_path,DQ4_HBD_DISC_START);
            return r;
        }
        printf("  DQ4 HBD extracted: %zu bytes\n",dq4_hbd.size());

        HbdReencoder reencoder;
        reencoder.load(dq4_hbd.data(),(uint32_t)dq4_hbd.size(),
                       hybrid_tree.data(),(uint32_t)hybrid_tree.size());

        // Load pre-encoded translation map for English text injection (V5: abort on failure)
        if(translation_map_path&&*translation_map_path){
            if(!reencoder.load_translation_map(translation_map_path)){
                printf("  ERROR: Failed to load translation map: %s — aborting build (V5)\n",translation_map_path);
                return r;
            }
            printf("  Translation map loaded: %s\n",translation_map_path);
        }else{
            printf("  ERROR: No translation map provided — cannot produce English HBD (V5). Aborting.\n");
            return r;
        }

        auto proc_result=reencoder.process_hbd(DQ4_HBD_DISC_START,HBD_TARGET_SECTOR);
        r.hbd_blocks_processed=proc_result.blocks_processed;
        r.hbd_blocks_converted=proc_result.blocks_converted;
        r.hbd_subblock_swaps=proc_result.subblock_swaps;
        r.hbd_lba_patches=proc_result.lba_patches;
        printf("  HBD processed: folders=%u files=%u blocks=%u converted=%u reencoded=%u failed=%u swaps=%u errors=%u\n",
            proc_result.folders_parsed,proc_result.files_parsed,
            proc_result.blocks_processed,proc_result.blocks_converted,
            proc_result.blocks_reencoded,proc_result.blocks_reencode_failed,
            proc_result.subblock_swaps,proc_result.errors);

        if(proc_result.errors>0&&!proc_result.success){
            printf("  ERROR: HBD processing had %u errors — aborting build (V1: no partial re-encode)\n",proc_result.errors);
            return r;
        }

        uint32_t processed_size=reencoder.size();
        printf("  Processed HBD size: %u bytes (original: %u, delta: %+d)\n",
            processed_size,DQ4_HBD_SIZE,(int32_t)processed_size-(int32_t)DQ4_HBD_SIZE);

        std::vector<uint8_t> hbd_out(reencoder.raw(),reencoder.raw()+std::min(processed_size,DQ4_HBD_SIZE));
        if(hbd_out.size()<DQ4_HBD_SIZE){
            hbd_out.resize(DQ4_HBD_SIZE,0);
            printf("  Padded HBD with %u zero bytes\n",DQ4_HBD_SIZE-(uint32_t)hbd_out.size());
        }else if(processed_size>DQ4_HBD_SIZE){
            printf("  WARNING: Processed HBD larger than original — truncated to %u bytes\n",DQ4_HBD_SIZE);
        }

        // Ensure disc is large enough for HBD at new position
        uint32_t required_sectors=HBD_TARGET_SECTOR+DQ4_HBD_SECTORS;
        uint32_t current_sectors=iso.file_size()/SECTOR_SIZE;
        if(required_sectors>current_sectors){
            printf("  Extending disc from %u to %u sectors...\n",current_sectors,required_sectors);
            iso.close();
            extend_disc_mode2(output_bin_path,(uint64_t)required_sectors*SECTOR_SIZE);
            if(!iso.open(output_bin_path)){printf("  ERROR: Cannot reopen output disc\n");return r;}
        }

        printf("  Writing re-encoded HBD at sector %u...\n",HBD_TARGET_SECTOR);
        write_raw_data(iso,HBD_TARGET_SECTOR,hbd_out);
        actual_hbd_size=DQ4_HBD_SIZE;
    }else{
        // Even without re-encoding, move HBD to sector 356
        auto dq4_hbd=extract_hbd_from_disc(dq4_disc_path,DQ4_HBD_DISC_START,DQ4_HBD_SIZE);
        if(!dq4_hbd.empty()){
            uint32_t required_sectors=HBD_TARGET_SECTOR+DQ4_HBD_SECTORS;
            uint32_t current_sectors=iso.file_size()/SECTOR_SIZE;
            if(required_sectors>current_sectors){
                printf("  Extending disc from %u to %u sectors...\n",current_sectors,required_sectors);
                iso.close();
                extend_disc_mode2(output_bin_path,(uint64_t)required_sectors*SECTOR_SIZE);
                if(!iso.open(output_bin_path)){printf("  ERROR: Cannot reopen output disc\n");return r;}
            }
            printf("  Writing HBD (unmodified) at sector %u...\n",HBD_TARGET_SECTOR);
            write_raw_data(iso,HBD_TARGET_SECTOR,dq4_hbd);
        }
        printf("  HBD Re-encoding: DISABLED (HBD moved to sector %u)\n",HBD_TARGET_SECTOR);
    }

    // 23. Update SYSTEM.CNF, ISO directory, license sector, PVD
    update_system_cnf(iso);
    update_iso_dir_reverse(iso,r.exe_size,actual_hbd_size);
    update_license_sector(iso);
    update_pvd(iso);
    iso.close();

    // 23b. Update HBD LBA in ISO directory to point to sector 356
    {
        // The ISO directory entry for the HBD file needs to point to the new sector
        // This is handled by update_iso_dir_reverse which uses actual_hbd_size
        // but we also need to update the LBA field in the directory entry
        // For now, log the move
        printf("  HBD moved: sector %u -> sector %u\n",DQ4_HBD_DISC_START,HBD_TARGET_SECTOR);
    }

    // 24. Write CUE sheet
    std::string bin_name=output_bin_path;
    size_t slash=bin_name.find_last_of("\\/");
    if(slash!=std::string::npos)bin_name=bin_name.substr(slash+1);
    write_cue(output_cue_path,bin_name.c_str());

    // 25. Run EDC/ECC regeneration
    if(edcre_path&&*edcre_path){
        printf("  Running EDC/ECC regeneration...\n");
        int ec=run_edcre(edcre_path,output_bin_path);
        printf("  EDC/ECC: %s\n",ec==0?"SUCCESS":"FAILED");
    }

    // 26. Final size and PC0
    {
        std::ifstream f(output_bin_path,std::ios::binary|std::ios::ate);
        r.disc_size=(uint32_t)f.tellg();
    }
    r.new_pc0=*(uint32_t*)(exe.raw()+0x10);

    // 27. Integrity verification
    printf("\n  --- Post-build EXE Integrity Verification ---\n");
    if(!exe.verify_integrity()){
        printf("  WARNING: EXE integrity check FAILED — build may be unstable\n");
    }
    printf("  --- Patch Summary ---\n");
    exe.list_patches();

    printf("\n  REVERSE FRANKENSTEIN BUILD COMPLETE\n");
    printf("  Size: %u bytes (%.1f MB)\n",r.disc_size,(double)r.disc_size/(1024*1024));
    printf("  Patches: tree=%u disc=%u lba=%u seq=%u trampoline=%u\n",
        r.tree_patches,r.disc_patches,r.lba_patches,r.seq_patches,r.trampoline_patches);
    printf("  EXE: %u bytes, PC0=0x%08X\n",r.exe_size,r.new_pc0);
    printf("  HBD: %s at sector %u\n",
        (build_flags&0x4)?"re-encoded":"unmodified",(build_flags&0x4)?HBD_TARGET_SECTOR:DQ4_HBD_DISC_START);
    printf("  Strategy: DQ4 disc base + DW7 EXE swap + full patch suite (tree@0x800BC700, BSS narrow, R-TREEHOOK, HBD trampoline)\n");

    r.success=1;
    return r;
}

// ===== C API wrappers =====
extern "C" BuildResult build_frankenstein_v39(
    const char* dw7_disc_path,
    const char* dw7_exe_path,
    const char* dq4_hbd_disc_path,
    const char* hybrid_tree_path,
    const char* folder_map_path,
    const char* output_bin_path,
    const char* output_cue_path,
    const char* edcre_path)
{
    return FrankensteinBuilder::build_v39(
        dw7_disc_path,dw7_exe_path,dq4_hbd_disc_path,
        hybrid_tree_path,folder_map_path,
        output_bin_path,output_cue_path,edcre_path,3);
}

extern "C" BuildResult build_frankenstein_v40c(
    const char* dw7_disc_path,
    const char* dw7_exe_path,
    const char* dq4_hbd_disc_path,
    const char* hybrid_tree_path,
    const char* folder_map_path,
    const char* output_bin_path,
    const char* output_cue_path,
    const char* edcre_path)
{
    return FrankensteinBuilder::build_v39(
        dw7_disc_path,dw7_exe_path,dq4_hbd_disc_path,
        hybrid_tree_path,folder_map_path,
        output_bin_path,output_cue_path,edcre_path,0);
}

extern "C" BuildResult build_frankenstein_v40b(
    const char* dw7_disc_path,
    const char* dw7_exe_path,
    const char* dq4_hbd_disc_path,
    const char* hybrid_tree_path,
    const char* folder_map_path,
    const char* output_bin_path,
    const char* output_cue_path,
    const char* edcre_path)
{
    return FrankensteinBuilder::build_v39(
        dw7_disc_path,dw7_exe_path,dq4_hbd_disc_path,
        hybrid_tree_path,folder_map_path,
        output_bin_path,output_cue_path,edcre_path,1);
}

extern "C" BuildResult build_frankenstein_v40a(
    const char* dw7_disc_path,
    const char* dw7_exe_path,
    const char* dq4_hbd_disc_path,
    const char* hybrid_tree_path,
    const char* folder_map_path,
    const char* output_bin_path,
    const char* output_cue_path,
    const char* edcre_path)
{
    return FrankensteinBuilder::build_v39(
        dw7_disc_path,dw7_exe_path,dq4_hbd_disc_path,
        hybrid_tree_path,folder_map_path,
        output_bin_path,output_cue_path,edcre_path,2);
}

// ===== C API wrappers for patch functions =====
extern "C" int exe_patch_malloc_clamp(void* exe){
    return ((ExePatcher*)exe)->patch_malloc_clamp()?1:0;
}
extern "C" void exe_zero_pre_tree_bss(void* exe){
    ((ExePatcher*)exe)->zero_pre_tree_bss();
}
extern "C" int exe_patch_decomp_tree_pointer(void* exe){
    return ((ExePatcher*)exe)->patch_decomp_tree_pointer()?1:0;
}
extern "C" int exe_patch_decomp_root_id_plus1(void* exe){
    return ((ExePatcher*)exe)->patch_decomp_root_id_plus1()?1:0;
}
extern "C" int exe_patch_decomp_root_id_runtime(void* exe){
    return ((ExePatcher*)exe)->patch_decomp_root_id_runtime()?1:0;
}
extern "C" int exe_patch_decomp_offset_b_mask(void* exe){
    return ((ExePatcher*)exe)->patch_decomp_offset_b_mask()?1:0;
}
extern "C" int exe_patch_tree_hook(void* exe){
    return ((ExePatcher*)exe)->patch_tree_hook()?1:0;
}
extern "C" int exe_patch_fmv_skip_xa_stub(void* exe){
    return ((ExePatcher*)exe)->patch_fmv_skip_xa_stub()?1:0;
}
extern "C" int exe_patch_fifo_drain(void* exe){
    return ((ExePatcher*)exe)->patch_fifo_drain()?1:0;
}

// ===== P2-4: C API wrappers for validation + revert =====
extern "C" int exe_verify_cdrom_flow(void* exe){
    return ((ExePatcher*)exe)->verify_cdrom_flow()?1:0;
}
extern "C" int exe_verify_integrity(void* exe){
    return ((ExePatcher*)exe)->verify_integrity()?1:0;
}
extern "C" int exe_revert_patch(void* exe, const char* name){
    return ((ExePatcher*)exe)->revert_patch(name)?1:0;
}
extern "C" void exe_revert_all_patches(void* exe){
    ((ExePatcher*)exe)->revert_all_patches();
}
extern "C" void exe_list_patches(void* exe){
    ((ExePatcher*)exe)->list_patches();
}
extern "C" int exe_has_patch(void* exe, const char* name){
    return ((ExePatcher*)exe)->has_patch(name)?1:0;
}
extern "C" uint32_t exe_patch_count(void* exe){
    return (uint32_t)((ExePatcher*)exe)->get_patch_history().size();
}
