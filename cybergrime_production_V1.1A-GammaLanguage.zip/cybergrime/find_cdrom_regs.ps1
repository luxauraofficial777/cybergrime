# The PSX CDROM Setloc command writes 3 bytes (M, S, F in BCD) to port 0x1F801AD0, 0x1F801AD1, 0x1F801AD2
# Then writes command 0x02 to 0x1F801AD3 (command register)
# Search for code that stores to these hardware registers

$exePath = 'c:\LuxAura\VoidWalkers_Project\DQLOSTTRANSLATION\translation\SLUSP012.06'
$bytes = [System.IO.File]::ReadAllBytes($exePath)
$loadAddr = 0x80017F00

# Search for sb/sh to 0x1F801AD0, 0x1F801AD1, 0x1F801AD2
# These would be: lui $rt, 0x1F80; sb/sh $rt, offset($rt2)
# Or: lui $rt, 0xBF80; addiu $rt, $rt, 0x1AD0

# First: find all lui with 0x1F80
Write-Host "=== lui \$rt, 0x1F80 (hardware register base) ==="
$hits = @()
for ($i = 0x800; $i -lt $bytes.Length - 3; $i += 4) {
    $insn = [BitConverter]::ToUInt32($bytes, $i)
    if (($insn -shr 26) -eq 0x0F -and ($insn -band 0x0000FFFF) -eq 0x1F80) {
        $rt = ($insn -shr 16) -band 0x1F
        $ram = $loadAddr + $i - 0x800
        $next = [BitConverter]::ToUInt32($bytes, $i + 4)
        $hits += [PSCustomObject]@{File=$i; RAM=$ram; Insn=$insn; Next=$next; Reg=$rt}
    }
}
Write-Host "Found $($hits.Count) lui 0x1F80 instructions"
$hits | ForEach-Object {
    $nextHex = '0x{0:X8}' -f $_.Next
    $nextImm = $_.Next -band 0xFFFF
    if ($nextImm -ge 0x8000) { $nextImm = $nextImm - 0x10000 }
    Write-Host ("  RAM 0x{0:X8}: lui ${($_.Reg)},0x1F80  next=0x{1:X8} (imm={2})" -f $_.RAM, $nextHex, $nextImm)
}

# Search for 0x1AD0 as immediate in addiu/ori
Write-Host ""
Write-Host "=== addiu/ori with immediate 0x1AD0 (CDROM regs) ==="
for ($i = 0x800; $i -lt $bytes.Length - 3; $i += 4) {
    $insn = [BitConverter]::ToUInt32($bytes, $i)
    if (($insn -band 0x0000FFFF) -eq 0x00001AD0) {
        $ram = $loadAddr + $i - 0x800
        $prev = [BitConverter]::ToUInt32($bytes, $i - 4)
        Write-Host ("  RAM 0x{0:X8}: 0x{1:X8} (prev=0x{2:X8})" -f $ram, $insn, $prev)
    }
}

# Search for 0x1AD1 and 0x1AD2 too
Write-Host ""
Write-Host "=== addiu/ori with 0x1AD1 or 0x1AD2 ==="
for ($i = 0x800; $i -lt $bytes.Length - 3; $i += 4) {
    $insn = [BitConverter]::ToUInt32($bytes, $i)
    $imm = $insn -band 0x0000FFFF
    if ($imm -eq 0x00001AD1 -or $imm -eq 0x00001AD2 -or $imm -eq 0x00001AD3) {
        $ram = $loadAddr + $i - 0x800
        $prev = [BitConverter]::ToUInt32($bytes, $i - 4)
        Write-Host ("  RAM 0x{0:X8}: 0x{1:X8} (prev=0x{2:X8}) imm=0x{3:X4}" -f $ram, $insn, $prev, $imm)
    }
}

# Also search for the value 146621 (0x23C7D) as lui/addiu pair
# lui $rt, 0x0002; addiu $rt, $rt, 0x3C7D  -> 0x00023C7D = 146621
# Or lui $rt, 0x0003; addiu $rt, $rt, -0x4383 (0xBC7D sign-extended)
Write-Host ""
Write-Host "=== Search for LBA 146621 (0x23C7D) as lui+addiu ==="
for ($i = 0x800; $i -lt $bytes.Length - 7; $i += 4) {
    $insn1 = [BitConverter]::ToUInt32($bytes, $i)
    $insn2 = [BitConverter]::ToUInt32($bytes, $i + 4)
    
    # lui $rt, 0x0002 + addiu $rt, $rs, 0x3C7D
    if (($insn1 -shr 26) -eq 0x0F -and ($insn1 -band 0x0000FFFF) -eq 0x0002) {
        if (($insn2 -band 0x0000FFFF) -eq 0x00003C7D -and (($insn2 -shr 26) -eq 0x09)) {
            $rt1 = ($insn1 -shr 16) -band 0x1F
            $ram = $loadAddr + $i - 0x800
            Write-Host ("  FOUND at RAM 0x{0:X8}: lui ${rt1},0x0002 + addiu 0x3C7D" -f $ram)
        }
    }
    # lui $rt, 0x0003 + addiu $rt, $rs, 0xBC7D (sign-extended = 0x0002BC7D... no)
    # Actually 146621 = 0x23C7D. lui 0x0002, addiu 0x3C7D
    # Or maybe stored as a plain 32-bit value somewhere
}

# Search for 146621 as raw 32-bit LE
Write-Host ""
Write-Host "=== Search for 146621 (0x00023C7D) as 32-bit LE ==="
$target = [BitConverter]::GetBytes([uint32]146621)
for ($i = 0x800; $i -lt $bytes.Length - 3; $i += 1) {
    if ($bytes[$i] -eq $target[0] -and $bytes[$i+1] -eq $target[1] -and $bytes[$i+2] -eq $target[2] -and $bytes[$i+3] -eq $target[3]) {
        $ram = $loadAddr + $i - 0x800
        $prev4 = [BitConverter]::ToUInt32($bytes, [Math]::Max($i - 4, 0))
        $next4 = [BitConverter]::ToUInt32($bytes, $i + 4)
        Write-Host ("  FOUND at file 0x{0:X} (RAM 0x{1:X8}) prev=0x{2:X8} next=0x{3:X8}" -f $i, $ram, $prev4, $next4)
    }
}

# Search for MSF in BCD: 32:34:71 = 0x32 0x34 0x71 — we found one at 0x92936
# Let's check if there are more
Write-Host ""
Write-Host "=== All BCD 32 34 71 occurrences ==="
for ($i = 0x800; $i -lt $bytes.Length - 3; $i += 1) {
    if ($bytes[$i] -eq 0x32 -and $bytes[$i+1] -eq 0x34 -and $bytes[$i+2] -eq 0x71) {
        $ram = $loadAddr + $i - 0x800
        Write-Host ("  file 0x{0:X} (RAM 0x{1:X8})" -f $i, $ram)
    }
}
