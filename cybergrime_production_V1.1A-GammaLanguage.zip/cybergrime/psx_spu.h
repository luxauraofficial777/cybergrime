#pragma once

// ============================================================================
// PSX SPU — Sound Processing Unit
// Implements 24-voice ADPCM playback, ADSR envelopes, noise, reverb,
// CD-DA mixing, and 512KB SPU RAM. Header-only, dependency-free.
// Adapted from Nocash PSXspec and DuckStation SPU logic.
// ============================================================================

#include <cstdint>
#include <cstring>
#include <cmath>
#ifndef M_PI
#define M_PI 3.14159265358979323846
#endif

class PSX_SPU {
public:
    static constexpr int NUM_VOICES = 24;
    static constexpr int SPU_RAM_SIZE = 512 * 1024;      // 512KB
    static constexpr int SAMPLE_RATE = 44100;
    static constexpr int BUFFER_SIZE = 4096;

    // ADSR envelope phases
    enum ADSRPhase : uint8_t {
        ADSR_OFF = 0,
        ADSR_ATTACK = 1,
        ADSR_DECAY = 2,
        ADSR_SUSTAIN = 3,
        ADSR_RELEASE = 4,
    };

    struct Voice {
        // Volume (left/right) — 16-bit signed
        int16_t volume_left;
        int16_t volume_right;

        // Pitch (sample rate modifier) — 12-bit
        uint16_t pitch;          // 0x1000 = 44100 Hz

        // Start address in SPU RAM (in 8-byte units)
        uint16_t start_addr;
        uint16_t curr_addr;      // Current read address
        uint16_t loop_addr;      // Loop address (from ADPCM header)

        // ADSR envelope
        uint32_t adsr;           // Raw ADSR register
        uint8_t adsr_attack_mode;   // 0=linear, 1=exponential
        uint8_t adsr_attack_shift;
        uint8_t adsr_attack_step;
        uint8_t adsr_decay_shift;
        uint8_t adsr_sustain_mode;  // 0=+linear, 1=+exponential, 2=-linear, 3=-exponential
        uint8_t adsr_sustain_shift;
        uint8_t adsr_sustain_step;
        uint8_t adsr_release_mode; // 0=+linear, 1=+exponential (always decreasing)
        uint8_t adsr_release_shift;
        uint8_t adsr_release_step;

        ADSRPhase adsr_phase;
        uint32_t adsr_counter;
        uint32_t adsr_rate;
        int16_t adsr_volume;     // Current envelope volume (0-0x7FFF)

        // ADPCM decoding state
        int32_t old_samples[2];  // Previous decoded samples (for prediction)
        int32_t older_samples[2];
        uint8_t adpcm_header;    // Current block header
        int adpcm_block_pos;     // Position within 28-sample block
        int16_t adpcm_samples[28]; // Decoded samples for current block

        // Flags
        bool key_on;
        bool key_off;
        bool noise_mode;
        bool reverb_mode;
        bool pitch_mod_mode;

        // Current sample output
        int16_t curr_sample;

        void reset() {
            memset(this, 0, sizeof(*this));
            adsr_phase = ADSR_OFF;
            adsr_volume = 0;
            curr_addr = 0;
            loop_addr = 0;
            adpcm_block_pos = 28; // Force fetch on first key-on
        }
    };

    // Global registers
    uint16_t main_vol_left;
    uint16_t main_vol_right;
    uint16_t reverb_vol_left;
    uint16_t reverb_vol_right;
    uint16_t key_on_status;     // Bits 0-23: voice key-on
    uint16_t key_off_status;
    uint16_t noise_clock;       // Noise frequency
    uint16_t reverb_on;         // Bits 0-23: reverb enable per voice
    uint16_t cd_vol_left;
    uint16_t cd_vol_right;
    uint16_t irq_addr;          // SPU IRQ address
    bool irq_enabled;
    bool reverb_enabled;
    bool muted;

    // SPU RAM
    uint8_t ram[SPU_RAM_SIZE];

    // Voices
    Voice voices[NUM_VOICES];

    // Output buffer (stereo interleaved)
    int16_t output_buffer[BUFFER_SIZE * 2];
    int output_count;

    // CD-DA input buffer (from CD-ROM)
    int16_t cdda_left;
    int16_t cdda_right;
    bool cdda_active;

    PSX_SPU() { reset(); }

    void reset() {
        memset(ram, 0, sizeof(ram));
        memset(voices, 0, sizeof(voices));
        for (int i = 0; i < NUM_VOICES; i++) voices[i].reset();
        main_vol_left = 0x7FFF;
        main_vol_right = 0x7FFF;
        reverb_vol_left = 0;
        reverb_vol_right = 0;
        key_on_status = 0;
        key_off_status = 0;
        noise_clock = 0;
        reverb_on = 0;
        cd_vol_left = 0x7FFF;
        cd_vol_right = 0x7FFF;
        irq_addr = 0;
        irq_enabled = false;
        reverb_enabled = false;
        muted = false;
        cdda_left = 0;
        cdda_right = 0;
        cdda_active = false;
        output_count = 0;
    }

    // --- Register read/write (0x1F801C00 - 0x1F801DFF) ---
    uint16_t read_reg(uint32_t addr) {
        uint32_t off = (addr - 0x1F801C00) >> 2;

        // Voice registers (0x00-0x17F)
        if (off < 0x180) {
            int voice = off / 8;
            int reg = off % 8;
            switch (reg) {
                case 0: return voices[voice].volume_left;
                case 1: return voices[voice].volume_right;
                case 2: return voices[voice].pitch;
                case 3: return voices[voice].start_addr;
                case 4: return (uint16_t)(voices[voice].adsr & 0xFFFF);
                case 5: return (uint16_t)(voices[voice].adsr >> 16);
                case 6: return voices[voice].loop_addr;
                case 7: return voices[voice].curr_addr;
            }
        }

        // Global registers
        switch (off) {
            case 0x180: return main_vol_left;
            case 0x181: return main_vol_right;
            case 0x182: return reverb_vol_left;
            case 0x183: return reverb_vol_right;
            case 0x184: return key_on_status;
            case 0x185: return key_off_status;
            case 0x186: return reverb_on;
            case 0x187: return noise_clock;
            case 0x188: return reverb_enabled ? 1 : 0;
            case 0x189: return muted ? 0 : 1;
            case 0x18A: return cd_vol_left;
            case 0x18B: return cd_vol_right;
            case 0x18C: return irq_addr;
            case 0x18D: return irq_enabled ? 1 : 0;
        }

        return 0;
    }

    void write_reg(uint32_t addr, uint16_t val) {
        uint32_t off = (addr - 0x1F801C00) >> 2;

        // Voice registers
        if (off < 0x180) {
            int voice = off / 8;
            int reg = off % 8;
            switch (reg) {
                case 0: voices[voice].volume_left = val; break;
                case 1: voices[voice].volume_right = val; break;
                case 2: voices[voice].pitch = val; break;
                case 3: voices[voice].start_addr = val; break;
                case 4:
                    voices[voice].adsr = (voices[voice].adsr & 0xFFFF0000) | val;
                    parse_adsr(voice);
                    break;
                case 5:
                    voices[voice].adsr = (voices[voice].adsr & 0x0000FFFF) | ((uint32_t)val << 16);
                    parse_adsr(voice);
                    break;
                case 6: voices[voice].loop_addr = val; break;
                case 7: /* read-only curr_addr */ break;
            }
            return;
        }

        switch (off) {
            case 0x180: main_vol_left = val; break;
            case 0x181: main_vol_right = val; break;
            case 0x182: reverb_vol_left = val; break;
            case 0x183: reverb_vol_right = val; break;
            case 0x184:
                key_on_status = val;
                for (int i = 0; i < 16 && i < NUM_VOICES; i++) {
                    if (val & (1 << i)) key_on(i);
                }
                break;
            case 0x185:
                key_off_status = val;
                for (int i = 0; i < 16 && i < NUM_VOICES; i++) {
                    if (val & (1 << i)) key_off(i);
                }
                break;
            case 0x186: reverb_on = val; break;
            case 0x187: noise_clock = val; break;
            case 0x188: reverb_enabled = (val != 0); break;
            case 0x189: muted = (val == 0); break;
            case 0x18A: cd_vol_left = val; break;
            case 0x18B: cd_vol_right = val; break;
            case 0x18C: irq_addr = val; break;
            case 0x18D: irq_enabled = (val != 0); break;
        }
    }

    void key_on(int voice) {
        if (voice >= NUM_VOICES) return;
        voices[voice].key_on = true;
        voices[voice].key_off = false;
        voices[voice].curr_addr = voices[voice].start_addr;
        voices[voice].adsr_phase = ADSR_ATTACK;
        voices[voice].adsr_volume = 0;
        voices[voice].adpcm_block_pos = 28; // Force fetch
        voices[voice].old_samples[0] = 0;
        voices[voice].old_samples[1] = 0;
        voices[voice].older_samples[0] = 0;
        voices[voice].older_samples[1] = 0;
        update_adsr_rate(voice);
    }

    void key_off(int voice) {
        if (voice >= NUM_VOICES) return;
        voices[voice].key_on = false;
        voices[voice].key_off = true;
        voices[voice].adsr_phase = ADSR_RELEASE;
        update_adsr_rate(voice);
    }

    void parse_adsr(int voice) {
        Voice& v = voices[voice];
        uint32_t a = v.adsr;
        v.adsr_attack_mode = (a >> 31) & 1;
        v.adsr_attack_shift = (a >> 24) & 0xF;
        v.adsr_attack_step = (a >> 22) & 3;
        v.adsr_decay_shift = (a >> 16) & 0xF;
        v.adsr_sustain_mode = (a >> 14) & 3;
        v.adsr_sustain_shift = (a >> 8) & 0xF;
        v.adsr_sustain_step = (a >> 6) & 3;
        v.adsr_release_mode = (a >> 5) & 1;
        v.adsr_release_shift = a & 0xF;
        v.adsr_release_step = (a >> 3) & 3; // Not exactly right but close
    }

    void update_adsr_rate(int voice) {
        Voice& v = voices[voice];
        uint8_t shift, step;
        switch (v.adsr_phase) {
            case ADSR_ATTACK:
                shift = v.adsr_attack_shift;
                step = v.adsr_attack_step;
                break;
            case ADSR_DECAY:
                shift = v.adsr_decay_shift;
                step = 0;
                break;
            case ADSR_SUSTAIN:
                shift = v.adsr_sustain_shift;
                step = v.adsr_sustain_step;
                break;
            case ADSR_RELEASE:
                shift = v.adsr_release_shift;
                step = 0;
                break;
            default:
                v.adsr_rate = 0;
                return;
        }
        // Rate = (step << (shift+1)) — simplified
        if (shift >= 11) {
            v.adsr_rate = 7;
        } else {
            v.adsr_rate = (uint32_t)(1 << (shift + 1));
        }
    }

    // ADPCM prediction filter coefficients (XA-ADPCM / SPU-ADPCM shared)
    static const int32_t adpcm_coeffs[5][2];

    // Decode one ADPCM block (28 samples) from SPU RAM
    void decode_adpcm_block(Voice& v) {
        uint32_t addr = (uint32_t)v.curr_addr * 8;
        if (addr + 15 >= SPU_RAM_SIZE) {
            memset(v.adpcm_samples, 0, sizeof(v.adpcm_samples));
            return;
        }

        // Read 16-byte block: 1 header byte + 14 data bytes (28 nibbles)
        uint8_t header = ram[addr];
        uint8_t filter = (header >> 4) & 0xF;
        uint8_t shift = header & 0xF;
        bool loop_flag = (header >> 7) & 1;
        bool end_flag = (header >> 6) & 1;

        if (loop_flag) v.loop_addr = v.curr_addr;

        // Decode 28 4-bit samples
        for (int i = 0; i < 28; i++) {
            uint8_t nibble;
            if (i < 14) {
                nibble = ram[addr + 2 + i] & 0xF;
            } else {
                nibble = (ram[addr + 2 + i - 14] >> 4) & 0xF;
            }

            // Sign-extend 4-bit to int32
            int32_t sample = (int32_t)(int8_t)(nibble << 4) >> shift;

            // Apply prediction filter
            if (filter < 5) {
                sample += (adpcm_coeffs[filter][0] * v.old_samples[0]) >> 6;
                sample += (adpcm_coeffs[filter][1] * v.old_samples[1]) >> 6;
            }

            // Clamp to 16-bit
            if (sample > 32767) sample = 32767;
            if (sample < -32768) sample = -32768;

            v.adpcm_samples[i] = (int16_t)sample;

            // Shift history
            v.older_samples[1] = v.old_samples[1];
            v.older_samples[0] = v.old_samples[0];
            v.old_samples[1] = v.old_samples[0];
            v.old_samples[0] = sample;
        }

        // Advance address
        if (end_flag) {
            if (loop_flag) {
                v.curr_addr = v.loop_addr;
            } else {
                // End without loop — stop voice
                v.key_on = false;
                v.adsr_phase = ADSR_RELEASE;
            }
        } else {
            v.curr_addr += 2; // Each block is 16 bytes = 2 x 8-byte units
        }

        v.adpcm_block_pos = 0;
    }

    // Generate one sample for a voice
    int16_t generate_sample(Voice& v) {
        if (!v.key_on && v.adsr_phase == ADSR_OFF) return 0;

        // Fetch new block if needed
        if (v.adpcm_block_pos >= 28) {
            decode_adpcm_block(v);
        }

        // Get base sample
        int32_t sample = v.adpcm_samples[v.adpcm_block_pos++];

        // Apply pitch (simple resampling — skip samples for higher pitch)
        // Full implementation would use Bresenham interpolation
        if (v.pitch < 0x1000) {
            // Lower pitch: interpolate (simplified — just use sample as-is)
        }

        // Apply ADSR envelope
        apply_adsr(v);

        // Apply volume
        int32_t out = (sample * v.adsr_volume) >> 15;
        return (int16_t)out;
    }

    void apply_adsr(Voice& v) {
        if (v.adsr_phase == ADSR_OFF) return;

        v.adsr_counter += v.adsr_rate;
        if (v.adsr_counter < 44100) return; // Not time to update yet
        v.adsr_counter = 0;

        switch (v.adsr_phase) {
            case ADSR_ATTACK:
                if (v.adsr_attack_mode == 0) {
                    // Linear
                    v.adsr_volume += (v.adsr_attack_step == 0) ? 7 :
                                     (v.adsr_attack_step == 1) ? 0x70 :
                                     (v.adsr_attack_step == 2) ? 0x700 : 0x7000;
                } else {
                    // Exponential
                    v.adsr_volume += (v.adsr_attack_step == 0) ? 7 :
                                     (v.adsr_attack_step == 1) ? 0x70 :
                                     (v.adsr_attack_step == 2) ? 0x700 : 0x7000;
                    v.adsr_volume = (int16_t)((v.adsr_volume * v.adsr_volume) / 0x7FFF);
                }
                if (v.adsr_volume >= 0x7FFF) {
                    v.adsr_volume = 0x7FFF;
                    v.adsr_phase = ADSR_DECAY;
                    update_adsr_rate((int)(&v - voices));
                }
                break;

            case ADSR_DECAY: {
                // Exponential decay
                v.adsr_volume -= (v.adsr_volume >> (v.adsr_decay_shift + 1));
                // Check sustain level (bits 16-19 of ADSR)
                uint16_t sustain_level = (v.adsr >> 16) & 0xF;
                int16_t target = (int16_t)(sustain_level << 11);
                if (v.adsr_volume <= target) {
                    v.adsr_phase = ADSR_SUSTAIN;
                    update_adsr_rate((int)(&v - voices));
                }
                break;
            }

            case ADSR_SUSTAIN:
                // Mode determines direction
                if (v.adsr_sustain_mode & 2) {
                    // Decreasing
                    if (v.adsr_sustain_mode & 1) {
                        // Exponential
                        v.adsr_volume -= (v.adsr_volume >> (v.adsr_sustain_shift + 1));
                    } else {
                        // Linear
                        v.adsr_volume -= (v.adsr_sustain_step == 0) ? 7 :
                                         (v.adsr_sustain_step == 1) ? 0x70 :
                                         (v.adsr_sustain_step == 2) ? 0x700 : 0x7000;
                    }
                    if (v.adsr_volume < 0) v.adsr_volume = 0;
                } else {
                    // Increasing
                    if (v.adsr_sustain_mode & 1) {
                        v.adsr_volume = (int16_t)((v.adsr_volume * v.adsr_volume) / 0x7FFF);
                    } else {
                        v.adsr_volume += (v.adsr_sustain_step == 0) ? 7 :
                                         (v.adsr_sustain_step == 1) ? 0x70 :
                                         (v.adsr_sustain_step == 2) ? 0x700 : 0x7000;
                    }
                    if (v.adsr_volume >= 0x7FFF) v.adsr_volume = 0x7FFF;
                }
                break;

            case ADSR_RELEASE:
                if (v.adsr_release_mode) {
                    // Exponential
                    v.adsr_volume -= (v.adsr_volume >> (v.adsr_release_shift + 1));
                } else {
                    // Linear
                    v.adsr_volume -= 0x70 << (v.adsr_release_shift > 0 ? (v.adsr_release_shift - 1) : 0);
                }
                if (v.adsr_volume <= 0) {
                    v.adsr_volume = 0;
                    v.adsr_phase = ADSR_OFF;
                }
                break;
        }
    }

    // Generate one stereo sample pair
    void generate_sample_pair(int16_t& left_out, int16_t& right_out) {
        int32_t left = 0, right = 0;

        if (!muted) {
            for (int i = 0; i < NUM_VOICES; i++) {
                Voice& v = voices[i];
                if (v.adsr_phase == ADSR_OFF && !v.key_on) continue;

                int16_t sample = generate_sample(v);
                int32_t l = (sample * v.volume_left) >> 15;
                int32_t r = (sample * v.volume_right) >> 15;
                left += l;
                right += r;
            }
        }

        // CD-DA mixing
        if (cdda_active) {
            left += (cdda_left * (int16_t)cd_vol_left) >> 15;
            right += (cdda_right * (int16_t)cd_vol_right) >> 15;
        }

        // Main volume
        left = (left * (int16_t)main_vol_left) >> 15;
        right = (right * (int16_t)main_vol_right) >> 15;

        // Clamp
        if (left > 32767) left = 32767;
        if (left < -32768) left = -32768;
        if (right > 32767) right = 32767;
        if (right < -32768) right = -32768;

        left_out = (int16_t)left;
        right_out = (int16_t)right;
    }

    // Feed CD-DA audio from CD-ROM
    void feed_cdda(int16_t left, int16_t right) {
        cdda_left = left;
        cdda_right = right;
        cdda_active = true;
    }

    // DMA transfer to/from SPU RAM
    void dma_write(uint32_t ram_offset, const uint8_t* data, uint32_t size) {
        if (ram_offset + size > SPU_RAM_SIZE) size = SPU_RAM_SIZE - ram_offset;
        memcpy(ram + ram_offset, data, size);
    }

    void dma_read(uint32_t ram_offset, uint8_t* data, uint32_t size) {
        if (ram_offset + size > SPU_RAM_SIZE) size = SPU_RAM_SIZE - ram_offset;
        memcpy(data, ram + ram_offset, size);
    }
};

// ADPCM prediction filter coefficients (from PSX spec)
const int32_t PSX_SPU::adpcm_coeffs[5][2] = {
    {   0,   0 },
    {  60,   0 },
    { 115, -52 },
    {  98, -55 },
    { 122, -60 },
};
