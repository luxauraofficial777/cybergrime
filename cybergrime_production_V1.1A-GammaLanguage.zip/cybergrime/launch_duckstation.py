#!/usr/bin/env python3
"""Launch DuckStation with Frankenstein v16 and capture console output.
Tests both patched and unpatched versions."""
import subprocess
import time
import os
import sys

DUCKSTATION = r"C:\LuxAura\VoidWalkers_Project\DQLOSTTRANSLATION\duckstation\duckstation-qt-x64-ReleaseLTCG.exe"
CUE_FILE = r"C:\LuxAura\VoidWalkers_Project\DQLOSTTRANSLATION\dq4_frankenstein_v16.cue"
LOG_DIR = r"C:\LuxAura\VoidWalkers_Project\DQLOSTTRANSLATION\cybergrime"
WORK_DIR = r"C:\LuxAura\VoidWalkers_Project\DQLOSTTRANSLATION\duckstation"

LOG_FILE = os.path.join(LOG_DIR, "duckstation_frank_v16.log")

print(f"Launching DuckStation with Frankenstein v16...")
print(f"  CUE: {CUE_FILE}")
print(f"  Log: {LOG_FILE}")

# Kill any existing DuckStation processes
os.system('taskkill /F /IM duckstation-qt-x64-ReleaseLTCG.exe >nul 2>&1')
time.sleep(2)

# Launch DuckStation with stdout/stderr capture
try:
    proc = subprocess.Popen(
        [DUCKSTATION, "-batch", "-earlyconsole", CUE_FILE],
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        cwd=WORK_DIR,
        text=True,
        bufsize=1,
    )
except Exception as e:
    print(f"  Failed to launch DuckStation: {e}")
    sys.exit(1)

print(f"  PID: {proc.pid}")
print(f"  Capturing output for 60 seconds...")

start_time = time.time()
lines_written = 0

with open(LOG_FILE, 'w', encoding='utf-8', errors='replace') as log:
    while time.time() - start_time < 60:
        if proc.poll() is not None:
            print(f"  DuckStation exited with code {proc.returncode}")
            break
        try:
            line = proc.stdout.readline()
            if line:
                log.write(line)
                log.flush()
                lines_written += 1
                stripped = line.strip()
                if any(k in stripped for k in ['CDROM', 'BIOS', 'POST', 'Error', 'ERROR', 'Warning', 'WARNING',
                                                'Executable', 'System', 'GPU', 'Sector', 'Setloc',
                                                'ReadN', 'SeekL', 'Getstat', 'DataSector', 'Init', 'Pause',
                                                'HBD', 'disc', 'Insert', 'thread', 'Thread', 'boot', 'Boot',
                                                'EXE', 'load', 'Load', 'frame', 'Frame', 'crash', 'Crash']):
                    print(f"  {stripped}")
        except Exception as e:
            print(f"  Read error: {e}")
            break
        time.sleep(0.01)

# Kill DuckStation if still running
if proc.poll() is None:
    proc.kill()
    print(f"  Killed DuckStation after 60s timeout")

print(f"\n  Total lines captured: {lines_written}")
print(f"  Log saved to: {LOG_FILE}")
