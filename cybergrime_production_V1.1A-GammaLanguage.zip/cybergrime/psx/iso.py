"""ISO 9660 raw-sector I/O with automatic 2048/2352 stride detection."""

import struct
from pathlib import Path
from typing import BinaryIO, Optional


class IsoIO:
    """Read/write a PSX disc image with either 2048 or 2352-byte sectors."""

    def __init__(self, path: str):
        self.path = Path(path)
        self.size = self.path.stat().st_size
        # Detect stride from file size divisibility; PSX dumps are usually 2352
        if self.size % 2352 == 0 and self.size % 2048 != 0:
            self.sector_size = 2352
            self.data_offset = 0
        elif self.size % 2048 == 0:
            # Could be 2048; some tools strip ECC/EDC
            self.sector_size = 2048
            self.data_offset = 0
        else:
            # Default to 2352 with 0 offset as most common for raw dumps
            self.sector_size = 2352
            self.data_offset = 0

    @classmethod
    def from_stride(cls, path: str, sector_size: int, data_offset: int = 0):
        obj = cls.__new__(cls)
        obj.path = Path(path)
        obj.size = obj.path.stat().st_size
        obj.sector_size = sector_size
        obj.data_offset = data_offset
        return obj

    def lba_to_offset(self, lba: int) -> int:
        return lba * self.sector_size + self.data_offset

    def read_lba(self, f: BinaryIO, lba: int, length: Optional[int] = None) -> bytes:
        f.seek(self.lba_to_offset(lba))
        if length is None:
            length = self.sector_size
        return f.read(length)

    def write_lba(self, f: BinaryIO, lba: int, data: bytes) -> None:
        f.seek(self.lba_to_offset(lba))
        f.write(data)

    def read_sector(self, f: BinaryIO, lba: int) -> bytes:
        """Return the 2048-byte payload of a Mode 2 Form 1 sector."""
        raw = self.read_lba(f, lba, self.sector_size)
        if self.sector_size == 2352:
            # Mode 2 Form 1: sync (12) + header (4) + sub-header (8) + data (2048) + ECC/EDC (280)
            # For XA Mode 2 Form 1, data starts at offset 24.
            return raw[24:24 + 2048]
        return raw[:2048]

    def write_sector(self, f: BinaryIO, lba: int, data: bytes) -> None:
        if self.sector_size == 2048:
            self.write_lba(f, lba, data)
        elif self.sector_size == 2352:
            # For raw images we only overwrite the 2048 data portion; we do NOT recompute EDC/ECC
            # Caller must run edcre.exe after modification.
            f.seek(self.lba_to_offset(lba) + 24)
            f.write(data[:2048])
        else:
            raise ValueError("Unsupported sector size")

    def __repr__(self) -> str:
        return f"IsoIO({self.path}, sector_size={self.sector_size})"
