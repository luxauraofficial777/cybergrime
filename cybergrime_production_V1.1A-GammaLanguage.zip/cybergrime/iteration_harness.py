#!/usr/bin/env python3
"""
iteration_harness.py — Phase 12: Automated Iteration Harness

Master loop script that allows the agent stack to automatically:
1. Inject a hex patch into the ISO
2. Boot the headless emulator
3. Parse the resulting triage log + telemetry JSON
4. Refine the patch based on diagnostic hints
5. Repeat without manual user intervention

Usage:
  python iteration_harness.py --disc iso.bin --patches patches.json --max-iterations 10
  python iteration_harness.py --disc iso.bin --patches patches.json --strategy auto
  python iteration_harness.py --disc iso.bin --patches patches.json --dry-run
"""

import argparse
import json
import os
import shutil
import subprocess
import sys
import time
from typing import Dict, List, Any, Optional, Tuple

# ── Paths ──────────────────────────────────────────────────────────────────────

BASE = os.path.dirname(os.path.abspath(__file__))
CYBERGRIME = BASE
RUNNER = os.path.join(CYBERGRIME, "psx_agent_runner.exe")
EDCRE = r"C:\LuxAura\VoidWalkers_Project\DQLOSTTRANSLATION\edcre\edcre-v1.1.0-windows-x86_64-static\edcre.exe"
TELEMETRY_PARSER = os.path.join(CYBERGRIME, "agent_telemetry.py")
DIFF_ENGINE = os.path.join(CYBERGRIME, "diff_telemetry.py")
PATCH_VERIFIER = os.path.join(CYBERGRIME, "verify_patches.py")


# ── Patch Application ──────────────────────────────────────────────────────────

def apply_patches_to_iso(disc_path: str, patches: List[Dict], output_path: str) -> bool:
    """Apply hex patches to a copy of the ISO binary."""
    shutil.copy2(disc_path, output_path)

    with open(output_path, "r+b") as f:
        for patch in patches:
            exe_offset = patch.get("exe_offset", 0)
            patch_hex = patch.get("patch_bytes", "")
            if not patch_hex or exe_offset <= 0:
                continue

            # Find EXE start in ISO (search for PS-X EXE magic)
            f.seek(0)
            data = f.read(2048 * 100)  # Search first 100 sectors
            exe_magic = b"PS-X EXE"
            exe_start = data.find(exe_magic)
            if exe_start < 0:
                print(f"  ERROR: PS-X EXE magic not found", file=sys.stderr)
                return False

            abs_offset = exe_start + exe_offset
            patch_bytes = bytes.fromhex(patch_hex.replace(" ", "").replace("0x", ""))

            f.seek(abs_offset)
            f.write(patch_bytes)
            print(f"  Patched offset {exe_offset} (abs {abs_offset}): {patch_hex}")

    # Regenerate EDC/ECC if edcre is available
    if os.path.exists(EDCRE):
        print("  Regenerating EDC/ECC...")
        result = subprocess.run(
            [EDCRE, output_path],
            capture_output=True, text=True, timeout=120
        )
        if result.returncode != 0:
            print(f"  WARNING: EDC/ECC regeneration failed: {result.stderr[:200]}", file=sys.stderr)
        else:
            print("  EDC/ECC regenerated successfully")

    return True


def load_patch_spec(path: str) -> List[Dict]:
    """Load a patch specification JSON file."""
    with open(path, "r") as f:
        data = json.load(f)
    if isinstance(data, dict):
        data = data.get("patches", data.get("entries", []))
    if not isinstance(data, list):
        return []
    # Deduplicate by exe_offset + patch_bytes
    seen = set()
    unique = []
    for p in data:
        key = (p.get("exe_offset", 0), p.get("patch_bytes", ""))
        if key not in seen:
            seen.add(key)
            unique.append(p)
    return unique


# ── Emulator Execution ─────────────────────────────────────────────────────────

def run_emulator(disc_path: str, profile: str, max_instrs: int = 200000000,
                 wallclock_ms: int = 300000, extra_args: List[str] = None) -> Dict[str, Any]:
    """Run the headless emulator and return parsed results."""
    telemetry_path = os.path.join(CYBERGRIME, f"telemetry_{profile}.json")
    triage_path = os.path.join(CYBERGRIME, f"emulator_triage_{profile}.log")

    cmd = [
        RUNNER,
        disc_path,
        profile,
        str(max_instrs),
        telemetry_path,
        str(wallclock_ms),
        "--triage", triage_path,
    ]
    if extra_args:
        cmd.extend(extra_args)

    print(f"  Running: {' '.join(cmd[:6])}...")
    start_time = time.time()
    result = subprocess.run(cmd, capture_output=True, text=True, timeout=wallclock_ms // 1000 + 60)
    elapsed = time.time() - start_time

    print(f"  Emulator exited with code {result.returncode} in {elapsed:.1f}s")
    if result.returncode != 0 and result.stderr:
        print(f"  stderr: {result.stderr[:500]}", file=sys.stderr)

    # Parse telemetry
    telemetry = {}
    if os.path.exists(telemetry_path):
        with open(telemetry_path, "r", encoding="utf-8", errors="replace") as f:
            telemetry = json.load(f)

    # Parse triage log via agent_telemetry.py
    brief = {}
    if os.path.exists(triage_path):
        brief_cmd = [sys.executable, TELEMETRY_PARSER,
                     "--telemetry", telemetry_path,
                     "--triage", triage_path,
                     "-o", os.path.join(CYBERGRIME, f"brief_{profile}.json")]
        subprocess.run(brief_cmd, capture_output=True, text=True, timeout=30)
        brief_path = os.path.join(CYBERGRIME, f"brief_{profile}.json")
        if os.path.exists(brief_path):
            with open(brief_path, "r") as f:
                brief = json.load(f)

    return {
        "return_code": result.returncode,
        "elapsed_seconds": elapsed,
        "telemetry": telemetry,
        "brief": brief,
        "telemetry_path": telemetry_path,
        "triage_path": triage_path,
    }


# ── Patch Refinement Strategies ───────────────────────────────────────────────

def refine_patches(patches: List[Dict], brief: Dict, iteration: int) -> List[Dict]:
    """Refine patch list based on diagnostic hints from the brief."""
    hints = brief.get("diagnostic_hints", [])
    verdict = brief.get("verdict", "UNKNOWN")
    freeze_type = brief.get("freeze_type", "NONE")
    freeze_pc = brief.get("freeze_pc", "0x00000000")

    refined = [p for p in patches]  # Copy

    # Strategy 1: If freeze is a tight loop, add NOP patches for loop body PCs
    if freeze_type == "TIGHT_LOOP":
        loop_body = brief.get("loop_body", [])
        for pc_str in loop_body:
            pc = int(pc_str, 16) if isinstance(pc_str, str) else pc_str
            # Check if we already have a patch for this PC
            already_patched = any(
                int(p.get("ram", "0x0"), 16) == pc for p in refined
                if p.get("ram")
            )
            if not already_patched:
                # Add a NOP patch for this PC
                # Need to compute exe_offset from RAM address
                # Assuming load_addr = 0x80017F00 (DW7 standard)
                load_addr = 0x80017F00
                exe_offset = pc - load_addr
                if exe_offset > 0:
                    refined.append({
                        "ram": f"0x{pc:08X}",
                        "exe_offset": exe_offset,
                        "original_bytes": "00000000",
                        "patch_bytes": "00000000",
                        "description": f"Auto-NOP loop body PC 0x{pc:08X} (iteration {iteration})",
                    })
                    print(f"  → Auto-patch: NOP at 0x{pc:08X} (exe_offset={exe_offset})")

    # Strategy 2: If VBlank stall, add injection to force VBlank event flags
    elif freeze_type == "VBLANK_STALL":
        # Add RAM injection entries (will be passed as --inject spec)
        print(f"  → VBlank stall detected — recommend injection spec with event flag forcing")

    # Strategy 3: If PC stuck, NOP the instruction at the stuck PC
    elif freeze_type == "PC_STUCK" and freeze_pc != "0x00000000":
        pc = int(freeze_pc, 16)
        load_addr = 0x80017F00
        exe_offset = pc - load_addr
        if exe_offset > 0:
            already = any(
                int(p.get("ram", "0x0"), 16) == pc for p in refined
                if p.get("ram")
            )
            if not already:
                refined.append({
                    "ram": f"0x{pc:08X}",
                    "exe_offset": exe_offset,
                    "original_bytes": "00000000",
                    "patch_bytes": "00000000",
                    "description": f"Auto-NOP stuck PC 0x{pc:08X} (iteration {iteration})",
                })
                print(f"  → Auto-patch: NOP at stuck PC 0x{pc:08X}")

    # Strategy 4: If VFS failures, skip file not found checks
    vfs_fails = brief.get("vfs_failures", [])
    if vfs_fails:
        print(f"  → {len(vfs_fails)} VFS failures — consider patching file open checks")

    return refined


# ── Main Iteration Loop ───────────────────────────────────────────────────────

def run_iteration_loop(disc_path: str, patch_spec_path: str, max_iterations: int,
                       max_instrs: int, wallclock_ms: int, strategy: str,
                       dry_run: bool, extra_args: List[str]) -> Dict[str, Any]:
    """Run the automated patch-test-refine loop."""
    results = {
        "disc": disc_path,
        "patch_spec": patch_spec_path,
        "max_iterations": max_iterations,
        "strategy": strategy,
        "iterations": [],
        "final_verdict": "UNKNOWN",
    }

    patches = load_patch_spec(patch_spec_path)
    print(f"Loaded {len(patches)} unique patches from {patch_spec_path}")

    current_patches = patches
    best_result = None
    best_instrs = 0

    for i in range(max_iterations):
        print(f"\n{'='*60}")
        print(f"  ITERATION {i+1}/{max_iterations}")
        print(f"{'='*60}")

        # Apply patches to a working copy
        work_disc = os.path.join(CYBERGRIME, f"dw7_iter_{i+1}.bin")
        profile = f"iter_{i+1}"

        if dry_run:
            print(f"  [DRY RUN] Would patch {len(current_patches)} entries to {work_disc}")
            print(f"  [DRY RUN] Would run emulator with profile={profile}")
            results["iterations"].append({
                "iteration": i + 1,
                "dry_run": True,
                "patch_count": len(current_patches),
            })
            continue

        # Apply patches
        print(f"  Applying {len(current_patches)} patches...")
        if not apply_patches_to_iso(disc_path, current_patches, work_disc):
            print(f"  FAILED to apply patches — stopping iteration loop")
            break

        # Verify patches
        print(f"  Verifying patches...")
        verify_cmd = [sys.executable, PATCH_VERIFIER,
                      "--disc", work_disc,
                      "--patches", patch_spec_path,
                      "--check", "patched"]
        v_result = subprocess.run(verify_cmd, capture_output=True, text=True, timeout=30)
        if v_result.returncode != 0:
            print(f"  WARNING: Patch verification failed")

        # Run emulator
        print(f"  Running emulator...")
        emu_result = run_emulator(
            work_disc, profile, max_instrs, wallclock_ms, extra_args
        )

        brief = emu_result.get("brief", {})
        verdict = brief.get("verdict", "UNKNOWN")
        instrs = brief.get("instruction_count", 0)

        iter_result = {
            "iteration": i + 1,
            "patch_count": len(current_patches),
            "verdict": verdict,
            "instructions": instrs,
            "freeze_type": brief.get("freeze_type", "NONE"),
            "freeze_pc": brief.get("freeze_pc", "0x00000000"),
            "elapsed_seconds": emu_result.get("elapsed_seconds", 0),
            "diagnostic_hints": brief.get("diagnostic_hints", []),
        }
        results["iterations"].append(iter_result)

        print(f"  Verdict: {verdict}  Instructions: {instrs:,}")
        for hint in brief.get("diagnostic_hints", [])[:3]:
            print(f"  → {hint}")

        # Check if we're done
        if verdict == "PASS":
            print(f"\n  *** PASS — emulation completed successfully at iteration {i+1} ***")
            results["final_verdict"] = "PASS"
            best_result = iter_result
            break

        # Track best result
        if instrs > best_instrs:
            best_instrs = instrs
            best_result = iter_result

        # Refine patches for next iteration
        if strategy == "auto" and i < max_iterations - 1:
            print(f"\n  Refining patches based on diagnostics...")
            current_patches = refine_patches(current_patches, brief, i + 1)
            if len(current_patches) > len(patches):
                print(f"  Refined: {len(current_patches)} patches (was {len(patches)})")
            else:
                print(f"  No new patches generated — stopping iteration loop")
                break

        # Clean up working disc
        if os.path.exists(work_disc):
            os.remove(work_disc)

    if results["final_verdict"] == "UNKNOWN" and best_result:
        results["final_verdict"] = best_result.get("verdict", "UNKNOWN")

    # Summary
    print(f"\n{'='*60}")
    print(f"  ITERATION LOOP COMPLETE")
    print(f"{'='*60}")
    print(f"  Iterations run: {len(results['iterations'])}")
    print(f"  Final verdict:  {results['final_verdict']}")
    if best_result:
        print(f"  Best result:    {best_result['instructions']:,} instructions")
        print(f"  Best verdict:   {best_result['verdict']}")
    print(f"{'='*60}")

    return results


def main():
    parser = argparse.ArgumentParser(description="Phase 12: Automated Iteration Harness")
    parser.add_argument("--disc", required=True, help="Path to base ISO .bin file")
    parser.add_argument("--patches", required=True, help="Path to patch spec JSON")
    parser.add_argument("--max-iterations", type=int, default=10, help="Max refinement iterations")
    parser.add_argument("--max-instrs", type=int, default=200000000, help="Max emulator instructions")
    parser.add_argument("--wallclock-ms", type=int, default=300000, help="Wall-clock timeout in ms")
    parser.add_argument("--strategy", choices=["auto", "manual"], default="auto",
                        help="Patch refinement strategy")
    parser.add_argument("--dry-run", action="store_true", help="Don't actually run emulator")
    parser.add_argument("--output", "-o", help="Write results to JSON file")
    parser.add_argument("--inject", help="RAM injection spec JSON (passed to emulator)")
    parser.add_argument("--monitor", help="Buffer monitor spec JSON (passed to emulator)")
    args = parser.parse_args()

    extra_args = []
    if args.inject:
        extra_args.extend(["--inject", args.inject])
    if args.monitor:
        extra_args.extend(["--monitor", args.monitor])

    results = run_iteration_loop(
        args.disc, args.patches, args.max_iterations,
        args.max_instrs, args.wallclock_ms, args.strategy,
        args.dry_run, extra_args
    )

    if args.output:
        with open(args.output, "w") as f:
            json.dump(results, f, indent=2)
        print(f"\nResults written to {args.output}")


if __name__ == "__main__":
    main()
