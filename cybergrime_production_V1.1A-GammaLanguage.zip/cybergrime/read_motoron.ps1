$j = Get-Content telemetry_motoron_20m.json -Raw | ConvertFrom-Json
Write-Host "Instructions: $($j.Instructions_Executed)"
Write-Host "VBlanks: $($j.VBlank_Count)"
Write-Host "Crashed: $($j.Crashed)"
Write-Host "PC: $($j.Register_Dump.PC)"
$lines = $j.TTY_Tail -split "`n"
Write-Host "TTY lines: $($lines.Count)"
Write-Host "=== Last 40 TTY lines ==="
$lines | Select-Object -Last 40 | ForEach-Object { Write-Host "  $_" }
Write-Host ""
Write-Host "=== CD-ROM cmd lines ==="
$cd = $lines | Where-Object { $_ -match 'CDDBG|CDROM.*Read|Setloc|ReadN|ReadS|INT1|sector.*ready' }
Write-Host "CD-ROM cmd lines: $($cd.Count)"
$cd | Select-Object -First 30 | ForEach-Object { Write-Host "  $_" }
Write-Host ""
Write-Host "=== Unique CD commands ==="
$cmds = @{}
foreach ($l in $lines) {
    if ($l -match 'cmd processing: cmd=0x([0-9A-Fa-f]+)') {
        $c = $matches[1]
        if (-not $cmds.ContainsKey($c)) { $cmds[$c] = 0 }
        $cmds[$c]++
    }
}
foreach ($k in ($cmds.Keys | Sort-Object)) {
    Write-Host "  Cmd 0x$k : $($cmds[$k]) times"
}
Write-Host ""
Write-Host "=== STDOUT lines ==="
$stdout = $lines | Where-Object { $_ -match 'STDOUT' }
$stdout | Select-Object -First 20 | ForEach-Object { Write-Host "  $_" }
Write-Host ""
Write-Host "=== BIOS Calls (unique) ==="
$calls = @{}
foreach ($e in $j.BIOS_Call_Log) {
    $fn = '{0:X2}' -f [int]$e.fn
    $key = "$($e.table):0x$fn"
    if (-not $calls.ContainsKey($key)) { $calls[$key] = 0 }
    $calls[$key]++
}
foreach ($k in ($calls.Keys | Sort-Object)) {
    Write-Host "  $k : $($calls[$k]) calls"
}
Write-Host ""
Write-Host "=== Last 20 BIOS calls ==="
$j.BIOS_Call_Log | Select-Object -Last 20 | ForEach-Object {
    $fn = '{0:X2}' -f [int]$_.fn
    Write-Host ("  #{0} {1}:0x{2} ra=0x{3} a0=0x{4}" -f $_.instr, $_.table, $fn, $_.ra, $_.a0)
}
