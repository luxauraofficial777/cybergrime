@echo off
call "C:\Progra~2\Microsoft Visual Studio\2022\BuildTools\VC\Auxiliary\Build\vcvars64.bat" >nul 2>&1
cd /d C:\LuxAura\VoidWalkers_Project\DQLOSTTRANSLATION\cybergrime
cl /nologo /std:c++17 /EHsc /O2 /Fe:frankenstein_build.exe frankenstein_build_main.cpp psx_binary_ops.cpp /I. /D_CRT_SECURE_NO_WARNINGS /link /SUBSYSTEM:CONSOLE /LARGEADDRESSAWARE
