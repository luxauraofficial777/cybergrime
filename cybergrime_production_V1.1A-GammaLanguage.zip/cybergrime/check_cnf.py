import sys
path = r"c:\LuxAura\VoidWalkers_Project\DQLOSTTRANSLATION\dq4_reverse_noedc.bin"
with open(path, "rb") as f:
    # Read SYSTEM.CNF at sector 23
    f.seek(23 * 2352 + 24)
    cnf = f.read(2048)
    # Print up to first null
    end = cnf.find(b'\x00')
    if end < 0: end = 200
    print("SYSTEM.CNF (sector 23):")
    print(cnf[:end].decode('ascii', errors='replace'))
    
    # Read EXE header at sector 23 (where DQ4 EXE lives)
    f.seek(23 * 2352 + 24)
    exe23 = f.read(8)
    print(f"\nSector 23 magic: {exe23}")
    
    # Read EXE header at sector 24 (where we wrote DW7 EXE)
    f.seek(24 * 2352 + 24)
    exe24 = f.read(8)
    print(f"Sector 24 magic: {exe24}")
    
    # Check ISO directory at sector 22
    f.seek(22 * 2352 + 24)
    dirdata = f.read(2048)
    print(f"\nISO directory (sector 22), first 200 bytes:")
    # Parse directory entries
    off = 0
    while off < len(dirdata):
        rec_len = dirdata[off]
        if rec_len == 0: break
        name_len = dirdata[off + 32]
        name = dirdata[off+33:off+33+name_len]
        lba = int.from_bytes(dirdata[off+2:off+6], 'little')
        size = int.from_bytes(dirdata[off+10:off+14], 'little')
        print(f"  Entry: name={name} lba={lba} size={size} rec_len={rec_len}")
        off += rec_len
