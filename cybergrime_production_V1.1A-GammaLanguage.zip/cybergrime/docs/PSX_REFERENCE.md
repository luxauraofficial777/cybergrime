# PSX Reference — Memory Map, BIOS Calls, Hardware Registers

## Memory Map

| Address Range | Size | Region |
|---|---|---|
| 0x00000000-0x001FFFFF | 2MB | Main RAM |
| 0x1F000000-0x1F7FFFFF | 8MB | Expansion Region 1 |
| 0x1F800000-0x1F800FFF | 4KB | Scratchpad (D-cache) |
| 0x1F801000-0x1F801FFF | 4KB | I/O Ports (hardware registers) |
| 0x1F802000-0x1F80FFFF | — | Expansion Region 2 |
| 0x1FA00000-0x1FBFFFFF | 2MB | Expansion Region 3 |
| 0x1FC00000-0x1FC7FFFF | 512KB | BIOS ROM |
| 0x80000000-0x801FFFFF | 2MB | RAM (cached, KUSEG) |
| 0xA0000000-0xA01FFFFF | 2MB | RAM (uncached) |
| 0xBFC00000-0xBFC7FFFF | 512KB | BIOS (uncached) |

## BIOS Call Tables

### A-Table (0xA0)

| Function | Name | Args |
|---|---|---|
| 0x00 | open | (path, mode) |
| 0x01 | lseek | (fd, offset, seektype) |
| 0x02 | read | (fd, buf, nbytes) |
| 0x03 | write | (fd, buf, nbytes) |
| 0x04 | close | (fd) |
| 0x05 | ioctl | (fd, cmd, arg) |
| 0x08 | getc | (fd) |
| 0x09 | putc | (fd, ch) |
| 0x0A | todigit | (ch) |
| 0x0B | atof | (s) |
| 0x0C | strtoul | (s, endptr, base) |
| 0x30 | CdInit | () |
| 0x38 | CdGetDelimDelim | () |
| 0x3C | CdGetStatus | () |
| 0x3E | CdGetMode | () |
| 0x4B | CdRead | (sectors, buf, mode) |
| 0x4C | CdReadSync | (mode, result) |
| 0x56 | CdGetRegion | () |

### B-Table (0xB0)

| Function | Name | Args |
|---|---|---|
| 0x00 | alloc_kernel_memory | (size) |
| 0x0D | ChangeClearPAD | (val) |
| 0x10 | ChangeTh | (thread) |
| 0x32 | open | (path, mode) |
| 0x34 | read | (fd, buf, nbytes) |
| 0x35 | write | (fd, buf, nbytes) |
| 0x36 | close | (fd) |
| 0x3C | printf | (format, ...) |
| 0x3D | SystemErrorUnresolved | () |
| 0x44 | FlushCache | () |
| 0x5A | EnableEvent | (event) |
| 0x5C | DeliverEvent | (event, spec) |
| 0x60 | OpenEvent | (class, spec, mode, func) |
| 0x62 | CloseEvent | (event) |
| 0x7B | ReturnFromException | () |
| 0x87 | Interrupt2IOP | () |

### C-Table (0xC0)

| Function | Name | Args |
|---|---|---|
| 0x00 | EnqueueTimerAndVBlank | () |
| 0x01 | EnqueueTimerAndVBlank | () |
| 0x03 | CdromISR | () |
| 0x05 | CdromISR2 | () |
| 0x08 | VBlankISR | () |

## Hardware Registers

### GPU (0x1F801810-0x1F801814)

| Address | Name | Description |
|---|---|---|
| 0x1F801810 | GPUREAD | GPU read data / GP0 command port |
| 0x1F801814 | GPUSTAT | GPU status / GP1 command port |

### GPUSTAT Bits

| Bit | Description |
|---|---|
| 31 | Drawing even line (interlace) |
| 30 | Drawing odd line (interlace) |
| 29 | DMA request direction |
| 28 | DMA ready |
| 27 | VRAM-to-CPU transfer ready |
| 26 | CPU-to-VRAM transfer ready |
| 25 | Drawing busy |
| 24 | Drawing even/odd (interlace) |
| 23-16 | Texture page settings |
| 15 | Tex disable |
| 14 | Tex page X base |
| 13 | Tex page Y base |
| 12 | Semi-transparency |
| 11-10 | Tex depth |
| 9 | Dither enable |
| 8 | Drawing to display area |
| 7 | Set mask bit |
| 6 | Draw pixels mask |
| 5 | Interlace field |
| 4 | Reverse flag |
| 3 | Texture disable |
| 2 | Display enable |
| 1 | IRQ flag |
| 0 | Drawing even/odd |

### CD-ROM (0x1F801800-0x1F801803)

| Address | Name |
|---|---|
| 0x1F801800 | Status/Command |
| 0x1F801801 | Data FIFO |
| 0x1F801802 | IRQ Enable/Response |
| 0x1F801803 | IRQ Mask/Control |

### DMA (0x1F801080-0x1F8010F0)

| Channel | Address | Use |
|---|---|---|
| 0 | 0x1F801080 | MDEC IN |
| 1 | 0x1F801090 | MDEC OUT |
| 2 | 0x1F8010A0 | GPU (VRAM transfer) |
| 3 | 0x1F8010B0 | CD-ROM |
| 4 | 0x1F8010C0 | SPU |
| 5 | 0x1F8010D0 | PIO |
| 6 | 0x1F8010E0 | OTC (clear ordering table) |

### Timers (0x1F801100-0x1F80112F)

| Address | Timer | Use |
|---|---|---|
| 0x1F801100 | Timer 0 | Dotclock |
| 0x1F801110 | Timer 1 | HBlank |
| 0x1F801120 | Timer 2 | 1/8 system clock |

### SPU (0x1F801C00-0x1F801FFF)

24 voices, each with 16 bytes of registers. Sound RAM at 0x1F801C00-0x1F801DFF.

### Interrupt Controller (0x1F801070-0x1F801077)

| Address | Name |
|---|---|
| 0x1F801070 | I_STAT (interrupt status) |
| 0x1F801074 | I_MASK (interrupt mask) |

### IRQ Bits

| Bit | Source |
|---|---|
| 0 | VBlank |
| 1 | GPU |
| 2 | CD-ROM |
| 3 | DMA |
| 4 | Timer 0 |
| 5 | Timer 1 |
| 6 | Timer 2 |
| 7 | Controller/Memory Card |
| 8 | SPU |
| 9 | PIO |
| 10 | SIO |
