$j = Get-Content telemetry_bios50_50m.json -Raw | ConvertFrom-Json
Write-Host "=== BIOS 50M Run State ==="
Write-Host "Status: $($j.Pass_Status)"
Write-Host "Instructions: $($j.Instructions_Executed)"
Write-Host "VBlanks: $($j.VBlank_Count)"
Write-Host "Crashed: $($j.Crashed)"
Write-Host ""
Write-Host "=== BIOS Call Log ($($j.BIOS_Call_Log.Count) entries) ==="
# Show unique function calls (not just ReturnFromException spam)
$seen = @{}
foreach ($e in $j.BIOS_Call_Log) {
    $tbl = $e.table
    $fn = '{0:X2}' -f [int]$e.fn
    $key = "${tbl}:0x${fn}"
    if ($key -notin @('B:0x17','B:0x35')) {
        Write-Host ("  #{0} {1}:0x{2} ra={3} a0={4} a1={5} a2={6} a3={7}" -f $e.instr, $tbl, $fn, $e.ra, $e.a0, $e.a1, $e.a2, $e.a3)
    }
}
Write-Host ""
Write-Host "=== B:0x35 (printf) entries ==="
foreach ($e in $j.BIOS_Call_Log) {
    $tbl = $e.table
    $fn = '{0:X2}' -f [int]$e.fn
    if ($key -eq 'B:0x35') {
        Write-Host ("  #{0} a0={1} a1={2} a2={3}" -f $e.instr, $e.a0, $e.a1, $e.a2)
    }
}
