#!/usr/bin/env python3
"""Check the remaining LBA 354 reference and the ABS/REL table contents"""
import struct

def read_sector(disc, lba):
    return disc[lba * 2352 + 24: lba * 2352 + 24 + 2048]

def read_exe_from_disc(disc_path, exe_lba, exe_size):
    with open(disc_path, 'rb') as f:
        disc = f.read()
    exe = bytearray()
    sectors = (exe_size + 2047) // 2048
    for i in range(sectors):
        exe.extend(read_sector(disc, exe_lba + i))
    return bytes(exe[:exe_size])

DISC = r'c:\LuxAura\VoidWalkers_Project\DQLOSTTRANSLATION\dq4_phaseC_build1.bin'
exe = read_exe_from_disc(DISC, 24, 960948)
DW7_DISC = r'c:\LuxAura\VoidWalkers_Project\DQLOSTTRANSLATION\DW7D1\DW7D1.bin'
dw7_exe = read_exe_from_disc(DW7_DISC, 24, 675840)

LOAD_ADDR = 0x80017F00
EXE_HEADER = 0x800

def ram_to_file(ram):
    return ram - LOAD_ADDR + EXE_HEADER

def read_word(data, foff):
    if 0 <= foff and foff + 4 <= len(data):
        return struct.unpack_from('<I', data, foff)[0]
    return None

# Constants from the patcher
ABS_TABLE_START = 0x4184  # file offset
REL_TABLE_START = 0x511C  # file offset
TABLE_ENTRY_SIZE = 8
MAX_TABLE_ENTRIES = 6000

# Check the remaining LBA=354 reference at file offset 0x422AE
print("=== LBA=354 reference at file offset 0x422AE (RAM 0x800599AE) ===")
off = 0x422AE
# Is this inside the ABS table?
abs_end = ABS_TABLE_START + MAX_TABLE_ENTRIES * TABLE_ENTRY_SIZE
rel_end = REL_TABLE_START + MAX_TABLE_ENTRIES * TABLE_ENTRY_SIZE
print(f"  ABS table: 0x{ABS_TABLE_START:X} to 0x{abs_end:X}")
print(f"  REL table: 0x{REL_TABLE_START:X} to 0x{rel_end:X}")
print(f"  Offset 0x{off:X} is {'INSIDE' if ABS_TABLE_START <= off < abs_end else 'OUTSIDE'} ABS table")
print(f"  Offset 0x{off:X} is {'INSIDE' if REL_TABLE_START <= off < rel_end else 'OUTSIDE'} REL table")

# Check what's around this offset in both EXEs
print("\n--- Frank EXE around 0x422AE ---")
for i in range(-8, 12, 4):
    o = off + i
    w = read_word(exe, o)
    if w is not None:
        ram = LOAD_ADDR + o - EXE_HEADER
        print(f"  0x{ram:08X} (off 0x{o:X}): 0x{w:08X} ({w})")

print("\n--- DW7 EXE around 0x422AE ---")
for i in range(-8, 12, 4):
    o = off + i
    w = read_word(dw7_exe, o)
    if w is not None:
        ram = LOAD_ADDR + o - EXE_HEADER
        print(f"  0x{ram:08X} (off 0x{o:X}): 0x{w:08X} ({w})")

# Dump the ABS table entries in both EXEs
print("\n=== ABS TABLE (first 20 entries) ===")
print("--- Frank ---")
for i in range(20):
    o = ABS_TABLE_START + i * TABLE_ENTRY_SIZE
    w1 = read_word(exe, o)
    w2 = read_word(exe, o + 4)
    if w1 is not None:
        ram = LOAD_ADDR + o - EXE_HEADER
        print(f"  [{i:3d}] 0x{ram:08X}: 0x{w1:08X} ({w1})  0x{w2:08X}" if w2 is not None else f"  [{i:3d}] 0x{ram:08X}: 0x{w1:08X} ({w1})")

print("\n--- DW7 ---")
for i in range(20):
    o = ABS_TABLE_START + i * TABLE_ENTRY_SIZE
    w1 = read_word(dw7_exe, o)
    w2 = read_word(dw7_exe, o + 4)
    if w1 is not None:
        ram = LOAD_ADDR + o - EXE_HEADER
        print(f"  [{i:3d}] 0x{ram:08X}: 0x{w1:08X} ({w1})  0x{w2:08X}" if w2 is not None else f"  [{i:3d}] 0x{ram:08X}: 0x{w1:08X} ({w1})")

# Check: how many ABS table entries are 354 vs 500 in Frank?
print("\n=== ABS table entry value distribution (Frank) ===")
count_354 = 0
count_500 = 0
count_other = 0
count_zero = 0
for i in range(MAX_TABLE_ENTRIES):
    o = ABS_TABLE_START + i * TABLE_ENTRY_SIZE
    w = read_word(exe, o)
    if w is None: break
    if w == 0: count_zero += 1
    elif w == 354: count_354 += 1
    elif w == 500: count_500 += 1
    else: count_other += 1
print(f"  354: {count_354}, 500: {count_500}, 0: {count_zero}, other: {count_other}")

print("\n=== ABS table entry value distribution (DW7) ===")
count_354 = 0
count_500 = 0
count_other = 0
count_zero = 0
for i in range(MAX_TABLE_ENTRIES):
    o = ABS_TABLE_START + i * TABLE_ENTRY_SIZE
    w = read_word(dw7_exe, o)
    if w is None: break
    if w == 0: count_zero += 1
    elif w == 354: count_354 += 1
    elif w == 500: count_500 += 1
    else: count_other += 1
print(f"  354: {count_354}, 500: {count_500}, 0: {count_zero}, other: {count_other}")

# Check REL table too
print("\n=== REL table entry value distribution (Frank) ===")
count_zero = 0
count_nonzero = 0
for i in range(MAX_TABLE_ENTRIES):
    o = REL_TABLE_START + i * TABLE_ENTRY_SIZE
    w = read_word(exe, o)
    if w is None: break
    if w == 0: count_zero += 1
    else: count_nonzero += 1
print(f"  nonzero: {count_nonzero}, zero: {count_zero}")

# Check REL table first 20 entries
print("\n=== REL TABLE (first 20 entries) ===")
print("--- Frank ---")
for i in range(20):
    o = REL_TABLE_START + i * TABLE_ENTRY_SIZE
    w1 = read_word(exe, o)
    w2 = read_word(exe, o + 4)
    if w1 is not None:
        ram = LOAD_ADDR + o - EXE_HEADER
        print(f"  [{i:3d}] 0x{ram:08X}: 0x{w1:08X} ({w1})  0x{w2:08X}" if w2 is not None else f"  [{i:3d}] 0x{ram:08X}: 0x{w1:08X} ({w1})")

print("\n--- DW7 ---")
for i in range(20):
    o = REL_TABLE_START + i * TABLE_ENTRY_SIZE
    w1 = read_word(dw7_exe, o)
    w2 = read_word(dw7_exe, o + 4)
    if w1 is not None:
        ram = LOAD_ADDR + o - EXE_HEADER
        print(f"  [{i:3d}] 0x{ram:08X}: 0x{w1:08X} ({w1})  0x{w2:08X}" if w2 is not None else f"  [{i:3d}] 0x{ram:08X}: 0x{w1:08X} ({w1})")

# Check the LBA=500 references found in Frank EXE
print("\n=== LBA=500 references in Frank EXE ===")
for off in [0x3A94, 0x4FD4, 0x8F850, 0x8F854]:
    w = read_word(exe, off)
    ram = LOAD_ADDR + off - EXE_HEADER
    print(f"  0x{ram:08X} (off 0x{off:X}): 0x{w:08X} ({w})")
    # Check DW7 at same offset
    w_dw7 = read_word(dw7_exe, off)
    if w_dw7 is not None:
        print(f"    DW7: 0x{w_dw7:08X} ({w_dw7})")

# Check what's at the HBD LBA table (0x4000-0x4400)
print("\n=== HBD LBA TABLE (0x4000-0x4400, first 20 entries) ===")
print("--- Frank ---")
for i in range(20):
    o = 0x4000 + i * 4
    w = read_word(exe, o)
    if w is not None:
        ram = LOAD_ADDR + o - EXE_HEADER
        print(f"  [{i:3d}] 0x{ram:08X}: 0x{w:08X} ({w})")

print("\n--- DW7 ---")
for i in range(20):
    o = 0x4000 + i * 4
    w = read_word(dw7_exe, o)
    if w is not None:
        ram = LOAD_ADDR + o - EXE_HEADER
        print(f"  [{i:3d}] 0x{ram:08X}: 0x{w:08X} ({w})")
