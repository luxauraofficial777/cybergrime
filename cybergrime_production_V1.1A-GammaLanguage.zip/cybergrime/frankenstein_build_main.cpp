// ARCHIVED — DO NOT BUILD. Canonical builder is at cybergrime/frankenstein_build_main.cpp
// Per ruleset M5/Phase 0.6. This copy is kept for reference only.
// ============================================================
// frankenstein_build_main.cpp
//
// Gold Standard Build Path entry point.
// Executes the complete Frankenstein disc build pipeline:
//   1. Input validation
//   2. EXE patching (disc-check, LBA, tree, BSS, pointers)
//   3. HBD re-encoding (field swap + LBA relocation + Huffman)
//   4. Disc assembly (ISO write + PVD + EDC/ECC)
//
// Usage:
//   frankenstein_build.exe --profile gold --output dq4_gold.bin
//   frankenstein_build.exe --dw7-disc <path> --dw7-exe <path>
//                          --dq4-hbd <path> --hybrid-tree <path>
//                          --folder-map <path> --edcre <path>
//                          --output <path> [--output-cue <path>]
//                          [--tree-mode <0|1|2|3>]
//
// Default paths are auto-detected from the DQLOSTTRANSLATION directory.
// ============================================================

#include "psx_binary_ops.h"
#include <cstring>
#include <cstdio>
#include <string>
#include <filesystem>

namespace fs = std::filesystem;

struct BuildArgs {
    std::string dw7_disc_path;
    std::string dw7_exe_path;
    std::string dq4_hbd_disc_path;
    std::string hybrid_tree_path;
    std::string folder_map_path;
    std::string edcre_path;
    std::string output_bin_path;
    std::string output_cue_path;
    int tree_mode = 3;  // Default: tree@0x800BC700 + BSS narrow (current best)
    std::string profile;
    bool duckstation_mode = false;  // Skip CD-ROM stall bypass for DuckStation
    bool reverse_mode = false;      // Option A: DQ4 disc base + DW7 EXE swap
    bool cd_intercept = false;      // build_flags bit 0: CD-ROM Setloc FMV intercept
    bool stall_bypass = false;      // build_flags bit 1: CD-ROM stall bypass (BAD-3)
    bool reencode_hbd = false;      // build_flags bit 2: HBD re-encoding (DQ4→DW7 format)
};

static std::string find_dqlt_root() {
    // Walk up from current directory to find DQLOSTTRANSLATION
    fs::path cwd = fs::current_path();
    for (fs::path p = cwd; !p.empty(); p = p.parent_path()) {
        if (p.filename() == "DQLOSTTRANSLATION") return p.string();
        fs::path check = p / "DQLOSTTRANSLATION";
        if (fs::exists(check)) return check.string();
    }
    // Also check relative to the executable location
    return cwd.string();
}

static bool file_exists(const std::string& path) {
    return fs::exists(path) && !fs::is_empty(path);
}

static void print_usage() {
    printf("Usage: frankenstein_build.exe [options]\n\n");
    printf("Options:\n");
    printf("  --profile gold          Use Gold Standard profile (all defaults)\n");
    printf("  --dw7-disc <path>       DW7 US disc image (.bin)\n");
    printf("  --dw7-exe <path>        DW7 US executable (SLUSP012.06)\n");
    printf("  --dq4-hbd <path>        DQ4 HBD disc image (.bin)\n");
    printf("  --hybrid-tree <path>    Hybrid Huffman tree (dw7_hybrid_tree.bin)\n");
    printf("  --folder-map <path>     Folder mapping JSON (folder_mapping.json)\n");
    printf("  --edcre <path>          EDC/ECC tool (edcre.exe)\n");
    printf("  --output <path>         Output .bin path\n");
    printf("  --output-cue <path>     Output .cue path (default: <output>.cue)\n");
    printf("  --tree-mode <0-3>       Tree placement mode (default: 3)\n");
    printf("    0 = no tree (Option C)\n");
    printf("    1 = tree@0x800F4980 + copy routine\n");
    printf("    2 = tree@0x80100000 + copy routine\n");
    printf("    3 = tree@0x800BC700 + BSS narrow (GOLD STANDARD)\n");
    printf("  --duckstation           DuckStation compatibility mode\n");
    printf("  --reverse               Option A: DQ4 disc as base, DW7 EXE swapped in\n");
    printf("  --cd-intercept          Redirect FMV Setloc (min>=0x32) to DQ4 23:31:15 (build_flags bit 0)\n");
    printf("  --stall-bypass          Skip CD event-wait poll loop (build_flags bit 1, BAD-3)\n");
    printf("  --reencode-hbd          Re-encode DQ4 HBD to DW7 format (build_flags bit 2)\n");
    printf("  --help                  Show this help\n");
}

static BuildArgs parse_args(int argc, char* argv[]) {
    BuildArgs args;

    for (int i = 1; i < argc; i++) {
        std::string arg = argv[i];
        if (arg == "--help" || arg == "-h") {
            print_usage();
            exit(0);
        } else if (arg == "--profile" && i + 1 < argc) {
            args.profile = argv[++i];
        } else if (arg == "--dw7-disc" && i + 1 < argc) {
            args.dw7_disc_path = argv[++i];
        } else if (arg == "--dw7-exe" && i + 1 < argc) {
            args.dw7_exe_path = argv[++i];
        } else if (arg == "--dq4-hbd" && i + 1 < argc) {
            args.dq4_hbd_disc_path = argv[++i];
        } else if (arg == "--hybrid-tree" && i + 1 < argc) {
            args.hybrid_tree_path = argv[++i];
        } else if (arg == "--folder-map" && i + 1 < argc) {
            args.folder_map_path = argv[++i];
        } else if (arg == "--edcre" && i + 1 < argc) {
            args.edcre_path = argv[++i];
        } else if (arg == "--output" && i + 1 < argc) {
            args.output_bin_path = argv[++i];
        } else if (arg == "--output-cue" && i + 1 < argc) {
            args.output_cue_path = argv[++i];
        } else if (arg == "--tree-mode" && i + 1 < argc) {
            args.tree_mode = std::atoi(argv[++i]);
        } else if (arg == "--duckstation") {
            args.duckstation_mode = true;
        } else if (arg == "--reverse") {
            args.reverse_mode = true;
        } else if (arg == "--cd-intercept") {
            args.cd_intercept = true;
        } else if (arg == "--stall-bypass") {
            args.stall_bypass = true;
        } else if (arg == "--reencode-hbd") {
            args.reencode_hbd = true;
        }
    }

    return args;
}

static bool validate_inputs(const BuildArgs& args, std::string& error) {
    struct InputCheck {
        const std::string& path;
        const char* name;
    };
    InputCheck checks[] = {
        {args.dw7_disc_path,      "DW7 disc"},
        {args.dw7_exe_path,       "DW7 EXE (SLUSP012.06)"},
        {args.dq4_hbd_disc_path,  "DQ4 HBD disc"},
        {args.hybrid_tree_path,   "Hybrid Huffman tree"},
        {args.folder_map_path,    "Folder mapping JSON"},
    };

    for (auto& c : checks) {
        if (c.path.empty()) {
            error = std::string("Missing path: ") + c.name;
            return false;
        }
        if (!file_exists(c.path)) {
            error = std::string("File not found or empty: ") + c.name + " (" + c.path + ")";
            return false;
        }
    }

    if (args.output_bin_path.empty()) {
        error = "No output path specified";
        return false;
    }

    return true;
}

int main(int argc, char* argv[]) {
    printf("============================================================\n");
    printf("  FRANKENSTEIN BUILD — Gold Standard Pipeline\n");
    printf("  Native C++ EXE patching + HBD re-encoding + Disc assembly\n");
    printf("============================================================\n\n");

    BuildArgs args = parse_args(argc, argv);

    // Auto-detect paths if --profile gold or if paths are missing
    std::string dqlt_root = find_dqlt_root();
    printf("  Project root: %s\n\n", dqlt_root.c_str());

    if (args.dw7_disc_path.empty()) {
        args.dw7_disc_path = (fs::path(dqlt_root) / "DW7D1" / "DW7D1.bin").string();
    }
    if (args.dw7_exe_path.empty()) {
        // Try clean unpatched EXE first, then pre-patched versions
        const char* exe_candidates[] = {
            "translation/SLUSP012.06",
            "translation/SLUSP012.06_disc_extract.bin",
            "translation/SLUSP012.06_PATCHED.bin",
            "translation/SLUSP012.06_FINAL.bin",
            "translation/SLUSP012.06_HYBRID.bin",
        };
        for (auto& c : exe_candidates) {
            std::string p = (fs::path(dqlt_root) / c).string();
            if (file_exists(p)) {
                args.dw7_exe_path = p;
                break;
            }
        }
    }
    if (args.dq4_hbd_disc_path.empty()) {
        // DQ4 HBD disc — the original Japanese DQ4 disc
        std::string p1 = (fs::path(dqlt_root) / "Dragon Quest IV - Michibikareshi Mono Tachi (Japan).bin").string();
        std::string p2 = (fs::path(dqlt_root) / "dq4_heart_v17.bin").string();
        if (file_exists(p1)) args.dq4_hbd_disc_path = p1;
        else if (file_exists(p2)) args.dq4_hbd_disc_path = p2;
    }
    if (args.hybrid_tree_path.empty()) {
        // Try frozen/ first (has real 1472-byte tree), then root
        std::string p1 = (fs::path(dqlt_root) / "frozen" / "dw7_hybrid_tree.bin").string();
        std::string p2 = (fs::path(dqlt_root) / "dw7_hybrid_tree.bin").string();
        if (file_exists(p1)) args.hybrid_tree_path = p1;
        else if (file_exists(p2)) args.hybrid_tree_path = p2;
    }
    if (args.folder_map_path.empty()) {
        args.folder_map_path = (fs::path(dqlt_root) / "translation" / "folder_mapping.json").string();
    }
    if (args.edcre_path.empty()) {
        args.edcre_path = (fs::path(dqlt_root) / "edcre" / "edcre-v1.1.0-windows-x86_64-static" / "edcre.exe").string();
    }
    if (args.output_bin_path.empty()) {
        args.output_bin_path = (fs::path(dqlt_root) / "dq4_gold.bin").string();
    }
    if (args.output_cue_path.empty()) {
        args.output_cue_path = args.output_bin_path + ".cue";
        // Replace .bin.cue with just .cue
        size_t pos = args.output_cue_path.find(".bin.cue");
        if (pos != std::string::npos) {
            args.output_cue_path = args.output_cue_path.substr(0, pos) + ".cue";
        }
    }

    // Print mode
    if (args.reverse_mode) {
        printf("  MODE: REVERSE FRANKENSTEIN (Option A)\n");
        printf("  DQ4 disc as base, DW7 EXE swapped in, HBD %s\n\n",
            args.reencode_hbd ? "RE-ENCODED" : "unmodified");
    }

    // Print resolved paths
    printf("=== Input Validation ===\n");
    printf("  DW7 disc:       %s\n", args.dw7_disc_path.c_str());
    printf("  DW7 EXE:        %s\n", args.dw7_exe_path.c_str());
    printf("  DQ4 HBD disc:   %s\n", args.dq4_hbd_disc_path.c_str());
    printf("  Hybrid tree:    %s\n", args.hybrid_tree_path.c_str());
    printf("  Folder map:     %s\n", args.folder_map_path.c_str());
    printf("  EDC/ECC tool:   %s\n", args.edcre_path.c_str());
    printf("  Output .bin:    %s\n", args.output_bin_path.c_str());
    printf("  Output .cue:    %s\n", args.output_cue_path.c_str());
    printf("  Tree mode:      %d\n", args.tree_mode);
    printf("  DuckStation mode: %s\n\n", args.duckstation_mode ? "YES" : "NO");

    // Validate — reverse mode has different requirements
    std::string error;
    if (args.reverse_mode) {
        // Reverse mode needs: DQ4 disc, DW7 EXE, hybrid tree, edcre, output
        // Does NOT need: DW7 disc, folder mapping
        if (args.dq4_hbd_disc_path.empty()) {
            error = "Missing path: DQ4 disc (needed as base for reverse mode)";
            printf("\n  INPUT VALIDATION FAILED: %s\n", error.c_str());
            return 1;
        }
        if (args.dw7_exe_path.empty()) {
            error = "Missing path: DW7 EXE";
            printf("\n  INPUT VALIDATION FAILED: %s\n", error.c_str());
            return 1;
        }
        if (args.hybrid_tree_path.empty()) {
            error = "Missing path: Hybrid Huffman tree";
            printf("\n  INPUT VALIDATION FAILED: %s\n", error.c_str());
            return 1;
        }
        if (args.output_bin_path.empty()) {
            error = "No output path specified";
            printf("\n  INPUT VALIDATION FAILED: %s\n", error.c_str());
            return 1;
        }
        // Check files exist
        const char* required[] = {args.dq4_hbd_disc_path.c_str(), args.dw7_exe_path.c_str(),
                                   args.hybrid_tree_path.c_str()};
        const char* names[] = {"DQ4 disc", "DW7 EXE", "Hybrid tree"};
        for (int i = 0; i < 3; i++) {
            if (!file_exists(required[i])) {
                printf("\n  INPUT VALIDATION FAILED: File not found: %s (%s)\n", names[i], required[i]);
                return 1;
            }
        }
        printf("  All inputs validated (reverse mode — folder mapping not needed).\n\n");
    } else if (!validate_inputs(args, error)) {
        printf("\n  INPUT VALIDATION FAILED: %s\n", error.c_str());
        printf("\n  Use --help for usage information.\n");
        return 1;
    }

    // Print file sizes
    printf("  File sizes:\n");
    printf("    DW7 disc:     %.1f MB\n", (double)fs::file_size(args.dw7_disc_path) / (1024*1024));
    printf("    DW7 EXE:      %.1f KB\n", (double)fs::file_size(args.dw7_exe_path) / 1024);
    printf("    DQ4 HBD:      %.1f MB\n", (double)fs::file_size(args.dq4_hbd_disc_path) / (1024*1024));
    printf("    Hybrid tree:  %llu bytes\n", (unsigned long long)fs::file_size(args.hybrid_tree_path));
    printf("    Folder map:   %.1f KB\n", (double)fs::file_size(args.folder_map_path) / 1024);
    printf("\n  All inputs validated.\n\n");

    // Execute the build
    BuildResult result;
    if (args.reverse_mode) {
        printf("=== Executing Reverse Frankenstein Build (Option A) ===\n\n");
        result = FrankensteinBuilder::build_reverse_option_a(
            args.dq4_hbd_disc_path.c_str(),
            args.dw7_exe_path.c_str(),
            args.hybrid_tree_path.c_str(),
            args.output_bin_path.c_str(),
            args.output_cue_path.c_str(),
            args.edcre_path.c_str(),
            (args.cd_intercept ? 1u : 0u) | (args.stall_bypass ? 2u : 0u) | (args.reencode_hbd ? 4u : 0u));
    } else {
        printf("=== Executing Gold Standard Build (tree_mode=%d) ===\n\n", args.tree_mode);
        uint32_t build_flags = args.duckstation_mode ? 2 : 0;  // bit 1 = partial DS mode (keep stall bypass, skip FMV/intercept)
        result = FrankensteinBuilder::build_v39(
            args.dw7_disc_path.c_str(),
            args.dw7_exe_path.c_str(),
            args.dq4_hbd_disc_path.c_str(),
            args.hybrid_tree_path.c_str(),
            args.folder_map_path.c_str(),
            args.output_bin_path.c_str(),
            args.output_cue_path.c_str(),
            args.edcre_path.c_str(),
            args.tree_mode,
            build_flags);
    }

    // Print final results
    printf("\n=== BUILD RESULTS ===\n");
    printf("  Success:          %s\n", result.disc_size > 0 ? "YES" : "NO");
    printf("  Disc size:        %u bytes (%.1f MB)\n", result.disc_size, (double)result.disc_size / (1024*1024));
    printf("  EXE size:         %u bytes\n", result.exe_size);
    printf("  PC0:              0x%08X\n", result.new_pc0);
    printf("  Tree patches:     %u\n", result.tree_patches);
    printf("  Disc-check patches: %u\n", result.disc_patches);
    printf("  LBA patches:      %u\n", result.lba_patches);
    printf("  Seq table patches: %u\n", result.seq_patches);
    printf("  ABS matched:      %u (delta: %u)\n", result.abs_matched, result.abs_delta);
    printf("  REL matched:      %u\n", result.rel_matched);
    printf("  Trampoline patches: %u\n", result.trampoline_patches);
    printf("  HBD blocks:       %u processed, %u converted\n",
           result.hbd_blocks_processed, result.hbd_blocks_converted);
    printf("  HBD sub-block swaps: %u\n", result.hbd_subblock_swaps);
    printf("  HBD LBA patches:  %u\n", result.hbd_lba_patches);
    printf("  Output: %s + %s\n", args.output_bin_path.c_str(), args.output_cue_path.c_str());

    // Verification checks
    printf("\n=== VERIFICATION ===\n");

    // Check 1: EXE header magic
    {
        std::ifstream f(args.output_bin_path, std::ios::binary);
        if (f.is_open()) {
            // Read sector 24 (EXE LBA), offset 24 for MODE2 Form1 user data
            f.seekg(24LL * 2352 + 24);
            char magic[8];
            f.read(magic, 8);
            bool magic_ok = std::memcmp(magic, "PS-X EXE", 8) == 0;
            printf("  EXE magic: %s\n", magic_ok ? "PASS (PS-X EXE)" : "FAIL");
        }
    }

    // Check 2: Output file exists and is non-empty
    bool output_ok = file_exists(args.output_bin_path);
    printf("  Output disc exists: %s\n", output_ok ? "PASS" : "FAIL");

    // Check 3: CUE sheet exists
    bool cue_ok = file_exists(args.output_cue_path);
    printf("  CUE sheet exists: %s\n", cue_ok ? "PASS" : "FAIL");

    // Check 4: Disc size > 350MB (must contain HBD)
    if (output_ok) {
        uint64_t sz = fs::file_size(args.output_bin_path);
        printf("  Disc size > 350MB: %s (%.1f MB)\n",
               sz > 350ULL * 1024 * 1024 ? "PASS" : "FAIL",
               (double)sz / (1024*1024));
    }

    // Check 5: Tree patches > 0 (tree was injected)
    printf("  Tree patches > 0: %s (%u)\n",
           result.tree_patches > 0 ? "PASS" : (args.tree_mode == 0 ? "SKIP (no tree mode)" : "FAIL"),
           result.tree_patches);

    // Check 6: Disc-check patches applied
    printf("  Disc-check patches: %s (%u)\n",
           result.disc_patches > 0 ? "PASS" : "FAIL",
           result.disc_patches);

    // Check 7: HBD blocks processed
    printf("  HBD blocks processed: %s (%u)\n",
           result.hbd_blocks_processed > 0 ? "PASS" : "FAIL",
           result.hbd_blocks_processed);

    printf("\n============================================================\n");
    printf("  Gold Standard Build %s\n", result.disc_size > 0 ? "COMPLETE" : "FAILED");
    printf("============================================================\n");

    return result.disc_size > 0 ? 0 : 1;
}
