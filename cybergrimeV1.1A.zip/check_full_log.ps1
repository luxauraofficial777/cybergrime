$lines = Get-Content "C:\LuxAura\VoidWalkers_Project\DQLOSTTRANSLATION\cybergrime\diag_traps.log"
Write-Output "Total lines: $($lines.Count)"
Write-Output ""
Write-Output "=== First 50 lines ==="
$lines | Select-Object -First 50
Write-Output ""
Write-Output "=== STATUS/SAMPLE lines ==="
$lines | Where-Object { $_ -match '^\[STATUS\]' -or $_ -match '^\[SAMPLE\]' } | Select-Object -First 30
Write-Output ""
Write-Output "=== VBPASS lines ==="
$lines | Where-Object { $_ -match 'VBPASS' }
Write-Output ""
Write-Output "=== BOOT/CDROM/HBD lines ==="
$lines | Where-Object { $_ -match 'BOOT|CDROM|HBD|sector|VFS|file' } | Select-Object -First 30
