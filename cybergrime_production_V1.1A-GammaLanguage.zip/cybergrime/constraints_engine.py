#!/usr/bin/env python3
"""
constraints_engine.py — Static analysis of DW7 EXE to produce constraint_map.json.

This is the "Golden Model" generator: it reads the DW7 EXE and disc,
calculates where every expected header, Huffman tree, and memory boundary
must be, and outputs a Structural Constraint Map that serves as the source
of truth for C++ surgery and runtime comparison.

Usage:
  python constraints_engine.py --exe translation/SLUSP012.06 --disc DW7D1/DW7D1.bin
  python constraints_engine.py --exe translation/SLUSP012.06 --output constraint_map.json
"""

import argparse
import json
import os
import struct
import sys
from typing import Dict, List, Any, Optional, Tuple

# ── Constants (locked from psx_binary_ops.h) ──────────────────────────────────

EXE_LBA = 24
HBD_LBA = 355
SECTOR_SIZE = 2352
USER_OFFSET = 24
USER_SIZE = 2048

EXE_LOAD_ADDR = 0x80017F00
ORIGINAL_PC0 = 0x8008E284
BSS_CLEAR_START_RAM = 0x800BC668
BSS_CLEAR_END_RAM = 0x800F4980
THREAD_ENTRY_RAM = 0x800D9E80

# EXE offsets (file offset = RAM - EXE_LOAD_ADDR + 0x800)
BSS_CLEAR_LUI_OFF = 0x76B84      # lui $v0, 0x800C
BSS_CLEAR_ADDIU_OFF = 0x76B88   # addiu $v0, 0xC668
BSS_CLEAR_END_LUI_OFF = 0x76B8C  # lui $v1, 0x800F
BSS_CLEAR_END_ADDIU_OFF = 0x76B90  # addiu $v1, 0xF4980

OLD_LUI_IMM = 0x800F
OLD_ADDIU_IMM = 0xF1C8

# Disc check patch offsets (from psx_binary_ops.cpp)
DISC_CHECK_OFFSETS = [0x6112C, 0x611D8, 0x613B8, 0x614A4, 0x614F8,
                      0x7308C, 0x61424, 0x61520, 0x61360]
DISC_CHECK_VAR_PATCHES = [
    (0x60FA4, 12),
    (0x387CC, 12),
]

# ABS/REL table locations
ABS_TABLE_START = 0x4184
REL_TABLE_START = 0x511C
TABLE_ENTRY_SIZE = 8
MAX_TABLE_ENTRIES = 6000

# Sequential sector table
SEQ_TABLE_START = 0xA39AA
SEQ_TABLE_END = 0xA3A02
SEQ_TABLE_MIN = 300
SEQ_TABLE_MAX = 400

# Tree placement options
TREE_ORIGINAL_RAM = 0x800EF1C8
TREE_MODE3_RAM = 0x800BC700     # Current: tree at EXE end, BSS narrowed
TREE_OPTION_B_RAM = 0x800F4980  # Tree at BSS boundary, copy routine
TREE_OPTION_A_RAM = 0x80100000  # Tree in safe high RAM, copy routine

SAFE_HIGH_RAM_START = 0x80100000
SAFE_HIGH_RAM_END = 0x801F0000
STACK_TOP = 0x801FFFF0


def ram_to_offset(ram: int) -> int:
    """Convert KSEG0 RAM address to EXE file offset."""
    return ram - EXE_LOAD_ADDR + 0x800


def offset_to_ram(offset: int) -> int:
    """Convert EXE file offset to KSEG0 RAM address."""
    return offset + EXE_LOAD_ADDR - 0x800


def read_u32(data: bytes, offset: int) -> int:
    """Read little-endian uint32 at offset."""
    return struct.unpack_from('<I', data, offset)[0]


def read_u16(data: bytes, offset: int) -> int:
    """Read little-endian uint16 at offset."""
    return struct.unpack_from('<H', data, offset)[0]


def decode_mips_lui(insn: int) -> Optional[int]:
    """Extract immediate from LUI instruction (opcode 0x0F)."""
    if (insn >> 26) == 0x0F:
        return insn & 0xFFFF
    return None


def decode_mips_addiu(insn: int) -> Optional[int]:
    """Extract immediate from ADDIU instruction (opcode 0x09)."""
    if (insn >> 26) == 0x09:
        return insn & 0xFFFF
    return None


def sign_extend_16(val: int) -> int:
    """Sign-extend a 16-bit value to 32-bit."""
    if val & 0x8000:
        return val | 0xFFFF0000
    return val


def compute_lui_addiu_addr(lui_imm: int, addiu_imm: int) -> int:
    """Compute the effective address from a LUI/ADDIU pair (32-bit wrap)."""
    return ((lui_imm << 16) + sign_extend_16(addiu_imm)) & 0xFFFFFFFF


class ConstraintsEngine:
    """Static analysis of DW7 EXE — produces constraint_map.json."""

    def __init__(self, exe_path: str, disc_path: str = "",
                 hybrid_tree_path: str = "",
                 folder_map_path: str = ""):
        self.exe_path = exe_path
        self.disc_path = disc_path
        self.hybrid_tree_path = hybrid_tree_path
        self.folder_map_path = folder_map_path

        with open(exe_path, 'rb') as f:
            self.exe = f.read()

    def build_constraint_map(self) -> dict:
        """Produce the complete structural constraint map."""
        return {
            "exe_header": self._map_exe_header(),
            "bss_clear": self._map_bss_clear(),
            "huffman_tree": self._map_huffman_tree(),
            "hbd_layout": self._map_hbd_layout(),
            "disc_check": self._map_disc_check(),
            "memory_regions": self._map_memory_regions(),
            "folder_pointers": self._map_folder_pointers(),
            "valid_tree_placements": self._enumerate_tree_placements(),
            "critical_addresses": self._map_critical_addresses(),
        }

    def validate_patch(self, patch_spec: dict) -> List[str]:
        """Check a candidate patch against constraints. Returns list of violations."""
        violations = []

        tree_addr = patch_spec.get("tree_addr")
        bss_narrowed = patch_spec.get("bss_narrowed", False)
        exe_size = patch_spec.get("exe_size", 0)
        hbd_lba = patch_spec.get("hbd_lba", HBD_LBA)

        # Check tree addr not in BSS range (unless BSS narrowed)
        if tree_addr is not None:
            tree_addr_int = int(tree_addr, 16) if isinstance(tree_addr, str) else tree_addr
            tree_size = self._get_tree_size()
            tree_end = tree_addr_int + tree_size

            if BSS_CLEAR_START_RAM <= tree_addr_int < BSS_CLEAR_END_RAM:
                if not bss_narrowed:
                    violations.append(
                        f"Tree at {hex(tree_addr_int)} is inside BSS clear range "
                        f"[{hex(BSS_CLEAR_START_RAM)}, {hex(BSS_CLEAR_END_RAM)}) "
                        f"but BSS is not narrowed — tree will be zeroed"
                    )
                else:
                    # Check tree doesn't overlap thread entry
                    if tree_addr_int <= THREAD_ENTRY_RAM < tree_end:
                        violations.append(
                            f"Tree at {hex(tree_addr_int)} overlaps thread entry "
                            f"at {hex(THREAD_ENTRY_RAM)}"
                        )

            # Check tree doesn't overflow into stack
            if tree_end > STACK_TOP:
                violations.append(f"Tree end {hex(tree_end)} exceeds stack top {hex(STACK_TOP)}")

        # Check EXE size doesn't overflow into HBD
        max_exe = (hbd_lba - EXE_LBA) * USER_SIZE
        if exe_size > max_exe:
            violations.append(
                f"EXE size {exe_size} ({hex(exe_size)}) exceeds max "
                f"{max_exe} ({hex(max_exe)}) — would overlap HBD at LBA {hbd_lba}"
            )

        # Check LBA delta
        if hbd_lba != HBD_LBA:
            violations.append(
                f"HBD LBA {hbd_lba} differs from expected {HBD_LBA} — "
                f"all LBA references must be patched consistently"
            )

        return violations

    # ── Internal mappers ──────────────────────────────────────────────────

    def _map_exe_header(self) -> dict:
        exe = self.exe
        load_addr = read_u32(exe, 0x18)
        file_size = read_u32(exe, 0x1C)
        pc0 = read_u32(exe, 0x10)
        sp = read_u32(exe, 0x30)
        gp = read_u32(exe, 0x28)

        actual_file_size = len(exe)
        max_exe_size = (HBD_LBA - EXE_LBA) * USER_SIZE
        text_section_end = load_addr + file_size

        return {
            "load_address": hex(load_addr),
            "original_file_size": hex(file_size),
            "actual_file_size": actual_file_size,
            "original_pc0": hex(pc0),
            "sp": hex(sp),
            "gp": hex(gp),
            "max_exe_size": max_exe_size,
            "max_exe_size_hex": hex(max_exe_size),
            "text_section_end": hex(text_section_end),
            "constraint": f"EXE size must not exceed {hex(max_exe_size)} (HBD at LBA {HBD_LBA})",
        }

    def _map_bss_clear(self) -> dict:
        exe = self.exe

        # Read BSS clear instructions
        lui_insn = read_u32(exe, BSS_CLEAR_LUI_OFF)
        addiu_insn = read_u32(exe, BSS_CLEAR_ADDIU_OFF)
        end_lui_insn = read_u32(exe, BSS_CLEAR_END_LUI_OFF)
        end_addiu_insn = read_u32(exe, BSS_CLEAR_END_ADDIU_OFF)

        # Verify instructions
        start_lui_imm = decode_mips_lui(lui_insn)
        start_addiu_imm = decode_mips_addiu(addiu_insn)
        end_lui_imm = decode_mips_lui(end_lui_insn)
        end_addiu_imm = decode_mips_addiu(end_addiu_insn)

        computed_start = compute_lui_addiu_addr(start_lui_imm or 0, start_addiu_imm or 0)
        computed_end = compute_lui_addiu_addr(end_lui_imm or 0, end_addiu_imm or 0)

        # Narrow patch target: stop BSS before tree at 0x800BC700
        narrow_target = 0x800BCCC8  # Tree end if placed at 0x800BC700 (1480 bytes)

        return {
            "start_address": hex(computed_start),
            "end_address": hex(computed_end),
            "start_verified": computed_start == BSS_CLEAR_START_RAM,
            "end_verified": computed_end == BSS_CLEAR_END_RAM,
            "instruction_offset_lui": hex(BSS_CLEAR_LUI_OFF),
            "instruction_offset_addiu": hex(BSS_CLEAR_ADDIU_OFF),
            "instruction_offset_end_lui": hex(BSS_CLEAR_END_LUI_OFF),
            "instruction_offset_end_addiu": hex(BSS_CLEAR_END_ADDIU_OFF),
            "lui_instruction": hex(lui_insn),
            "addiu_instruction": hex(addiu_insn),
            "end_lui_instruction": hex(end_lui_insn),
            "end_addiu_instruction": hex(end_addiu_insn),
            "narrow_patch_offset": hex(BSS_CLEAR_ADDIU_OFF),
            "narrow_patch_target": hex(narrow_target),
            "narrow_patch_imm": hex(narrow_target & 0xFFFF),
            "thread_entry_in_range": BSS_CLEAR_START_RAM <= THREAD_ENTRY_RAM < BSS_CLEAR_END_RAM,
            "constraint": (
                f"tree_addr MUST NOT be in [{hex(BSS_CLEAR_START_RAM)}, "
                f"{hex(BSS_CLEAR_END_RAM)}) unless BSS is narrowed to "
                f"{hex(narrow_target)}"
            ),
        }

    def _map_huffman_tree(self) -> dict:
        exe = self.exe

        # Scan for all lui/addiu pairs pointing to original tree address
        ref_count = 0
        ref_offsets = []
        for i in range(0, len(exe) - 8, 4):
            insn1 = read_u32(exe, i)
            insn2 = read_u32(exe, i + 4)

            lui_imm = decode_mips_lui(insn1)
            addiu_imm = decode_mips_addiu(insn2)

            if lui_imm is not None and addiu_imm is not None:
                if lui_imm == OLD_LUI_IMM and addiu_imm == OLD_ADDIU_IMM:
                    ref_count += 1
                    ref_offsets.append(hex(i))

        tree_size = self._get_tree_size()

        return {
            "original_dw7_ram": hex(TREE_ORIGINAL_RAM),
            "original_dw7_lui_imm": hex(OLD_LUI_IMM),
            "original_dw7_addiu_imm": hex(OLD_ADDIU_IMM),
            "hybrid_tree_size": tree_size,
            "hybrid_tree_file": os.path.basename(self.hybrid_tree_path) if self.hybrid_tree_path else "dw7_hybrid_tree.bin",
            "ref_count": ref_count,
            "ref_offsets": ref_offsets,
            "constraint": f"all {ref_count} refs MUST be patched to same target addr",
        }

    def _map_hbd_layout(self) -> dict:
        return {
            "original_dw7_lba": 354,
            "frankenstein_lba": HBD_LBA,
            "lba_delta": HBD_LBA - 354,
            "dq4_hbd_disc_start": 362,
            "dq4_hbd_size": 319436800,
            "dq4_hbd_sectors": 319436800 // USER_SIZE,
            "constraint": (
                f"all LBA refs 354→{HBD_LBA}, seq table entries patched, "
                f"unmatched ABS get +{HBD_LBA - 354} delta"
            ),
        }

    def _map_disc_check(self) -> dict:
        return {
            "patch_count": len(DISC_CHECK_OFFSETS) + len(DISC_CHECK_VAR_PATCHES),
            "offsets": [hex(o) for o in DISC_CHECK_OFFSETS],
            "var_patches": [{"offset": hex(o), "size": s} for o, s in DISC_CHECK_VAR_PATCHES],
            "constraint": "ALL disc-check patches MUST be applied or game hangs at disc identity check",
        }

    def _map_memory_regions(self) -> list:
        return [
            {"name": "EXE_TEXT", "start": hex(EXE_LOAD_ADDR), "end": hex(0x800BC700),
             "type": "loaded", "description": "DW7 EXE code + data (loaded from disc)"},
            {"name": "BSS_CLEAR", "start": hex(BSS_CLEAR_START_RAM), "end": hex(BSS_CLEAR_END_RAM),
             "type": "zeroed_at_boot", "description": "Zeroed by BSS clear loop at PC0"},
            {"name": "TREE_ORIG", "start": hex(TREE_ORIGINAL_RAM),
             "end": hex(TREE_ORIGINAL_RAM + self._get_tree_size()),
             "type": "runtime_copied", "description": "DW7 original tree location (in BSS range)"},
            {"name": "THREAD_ENTRY", "start": hex(THREAD_ENTRY_RAM), "end": hex(THREAD_ENTRY_RAM + 0x800),
             "type": "zeroed_at_boot", "description": "CD-ROM thread entry (zeroed by BSS — ROOT CAUSE)"},
            {"name": "STACK", "start": hex(STACK_TOP - 0x10000), "end": hex(STACK_TOP + 0x10),
             "type": "stack", "description": "Stack region (grows down from 0x801FFFF0)"},
            {"name": "SAFE_HIGH", "start": hex(SAFE_HIGH_RAM_START), "end": hex(SAFE_HIGH_RAM_END),
             "type": "free", "description": "Safe high RAM — no BSS, no stack, available for tree"},
            {"name": "TEXT_CACHE", "start": hex(0x80120000), "end": hex(0x80130000),
             "type": "buffer", "description": "Huffman decompression output buffer (96KB)"},
            {"name": "DYNAMIC_HEAP", "start": hex(0x80138000), "end": hex(0x801F0000),
             "type": "heap", "description": "Dynamic heap (map geometry, event data)"},
        ]

    def _map_folder_pointers(self) -> dict:
        folder_map = {"matched_count": 168, "unmatched_delta_count": 1755, "rel_matched_count": 167}
        if self.folder_map_path and os.path.exists(self.folder_map_path):
            try:
                with open(self.folder_map_path) as f:
                    mappings = json.load(f)
                if isinstance(mappings, list):
                    folder_map["matched_count"] = len(mappings)
                elif isinstance(mappings, dict):
                    folder_map["matched_count"] = len(mappings.get("mappings", []))
            except Exception:
                pass

        folder_map["abs_table_start"] = hex(ABS_TABLE_START)
        folder_map["rel_table_start"] = hex(REL_TABLE_START)
        folder_map["constraint"] = (
            "matched→DQ4 base sector, unmatched→+1 LBA delta to DW7 data"
        )
        return folder_map

    def _enumerate_tree_placements(self) -> list:
        tree_size = self._get_tree_size()
        return [
            {
                "mode": 3,
                "addr": hex(TREE_MODE3_RAM),
                "requires_bss_narrow": True,
                "requires_copy": False,
                "risk": "BSS variables after tree start are not zeroed — may cause undefined behavior",
                "description": "Tree at EXE end (0x800BC700), BSS narrowed to 0x800BCCC8",
            },
            {
                "mode": 1,
                "addr": hex(TREE_OPTION_B_RAM),
                "requires_bss_narrow": False,
                "requires_copy": True,
                "risk": "BSS boundary edge — tree at exact BSS clear end",
                "description": "Tree at BSS end (0x800F4980), copy routine at 0x800BC700",
            },
            {
                "mode": 2,
                "addr": hex(TREE_OPTION_A_RAM),
                "requires_bss_narrow": False,
                "requires_copy": True,
                "risk": "none (safe high RAM, no conflicts)",
                "description": "Tree at safe high RAM (0x80100000), copy routine at 0x800BC700",
            },
            {
                "mode": 0,
                "addr": hex(TREE_ORIGINAL_RAM),
                "requires_bss_narrow": False,
                "requires_copy": False,
                "risk": "Uses DW7 original tree — incompatible with DQ4 data",
                "description": "No tree appended — game uses own tree at 0x800EF1C8",
            },
        ]

    def _map_critical_addresses(self) -> dict:
        """Map all known critical MIPS addresses from reverse engineering."""
        return {
            "huffman_decompress_primary": {"ram": "0x80073670", "exe_offset": "0x5B770",
                                           "callers": 9, "description": "Primary Huffman decompression"},
            "huffman_decompress_secondary": {"ram": "0x80084BF0", "exe_offset": "0x6CCF0",
                                             "callers": 3, "description": "Secondary Huffman decompression"},
            "huffman_decompress_inline": {"ram": "0x80041CE8", "exe_offset": "0x29CE8",
                                          "callers": 4, "description": "DQ4 inline decompression (menu render)"},
            "bss_clear_entry": {"ram": hex(ORIGINAL_PC0), "exe_offset": hex(ram_to_offset(ORIGINAL_PC0)),
                                "description": "Original PC0 — BSS clear entry"},
            "hbd_subblock_parser": {"ram": "0x800562C0", "exe_offset": "0x443C0",
                                    "description": "HBD sub-block type parser"},
            "cdrom_thread_entry": {"ram": hex(THREAD_ENTRY_RAM), "exe_offset": hex(ram_to_offset(THREAD_ENTRY_RAM)),
                                   "description": "CD-ROM thread entry (zeroed by BSS)"},
            "cdrom_cmd_handler": {"ram": "0x80098898", "exe_offset": "0x80998",
                                  "description": "CD-ROM command handler"},
            "cdrom_after_branch": {"ram": "0x80098670", "exe_offset": "0x80770",
                                   "description": "Post-disc-check continuation"},
            "gpu_display_setup": {"ram": "0x8009F790", "exe_offset": "0x87890",
                                  "callers": 6, "description": "GPU display init"},
            "gpu_cw_call_site": {"ram": "0x8009F828", "exe_offset": "0x87928",
                                 "description": "GP0 command dispatch (sole JAL site)"},
            "gpu_cw_trampoline": {"ram": "0x800A5DA0", "exe_offset": "0x93EA0",
                                  "description": "BIOS A:0x49 wrapper for GPU_cw"},
            "dw7_global_tree": {"ram": "0x80096FA0", "exe_offset": "0x850A0",
                                "description": "DW7 Huffman tree (186 leaves) in EXE"},
            "spinlock_a": {"ram": "0x800B52A0", "description": "Threading spinlock A"},
            "spinlock_b": {"ram": "0x800B52A4", "description": "Threading spinlock B"},
            "vblank_count": {"ram": "0x800B63D8", "description": "VBlank counter register"},
            "text_cache_buffer": {"ram": "0x80120000", "description": "Decompression output (96KB)"},
        }

    def _get_tree_size(self) -> int:
        if self.hybrid_tree_path and os.path.exists(self.hybrid_tree_path):
            return os.path.getsize(self.hybrid_tree_path)
        # Try default path
        default = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
                               "dw7_hybrid_tree.bin")
        if os.path.exists(default):
            return os.path.getsize(default)
        return 1480  # Known size


def main():
    parser = argparse.ArgumentParser(
        description="Constraints Engine — generates constraint_map.json from DW7 EXE analysis"
    )
    parser.add_argument("--exe", required=True, help="Path to DW7 EXE (SLUSP012.06)")
    parser.add_argument("--disc", default="", help="Path to DW7 disc (.bin)")
    parser.add_argument("--tree", default="", help="Path to hybrid tree file")
    parser.add_argument("--folder-map", default="", help="Path to folder_mapping.json")
    parser.add_argument("--output", default="constraint_map.json", help="Output JSON path")
    parser.add_argument("--validate", default="", help="Patch spec JSON to validate against constraints")

    args = parser.parse_args()

    if not os.path.exists(args.exe):
        print(f"ERROR: EXE not found: {args.exe}")
        sys.exit(1)

    engine = ConstraintsEngine(
        exe_path=args.exe,
        disc_path=args.disc,
        hybrid_tree_path=args.tree,
        folder_map_path=args.folder_map,
    )

    print("=" * 70)
    print("CONSTRAINTS ENGINE — DW7 EXE Static Analysis")
    print("=" * 70)

    cmap = engine.build_constraint_map()

    # Print summary
    hdr = cmap["exe_header"]
    print(f"\n  EXE Header:")
    print(f"    Load address:  {hdr['load_address']}")
    print(f"    Original PC0:  {hdr['original_pc0']}")
    print(f"    File size:     {hdr['original_file_size']} ({hdr['actual_file_size']:,} bytes actual)")
    print(f"    Max EXE size:  {hdr['max_exe_size_hex']} ({hdr['max_exe_size']:,} bytes)")
    print(f"    SP:            {hdr['sp']}")

    bss = cmap["bss_clear"]
    print(f"\n  BSS Clear:")
    print(f"    Range:         {bss['start_address']} → {bss['end_address']}")
    print(f"    Verified:      start={bss['start_verified']}, end={bss['end_verified']}")
    print(f"    Thread entry:  {'IN RANGE (will be zeroed!)' if bss['thread_entry_in_range'] else 'outside range'}")
    print(f"    Narrow target: {bss['narrow_patch_target']}")

    tree = cmap["huffman_tree"]
    print(f"\n  Huffman Tree:")
    print(f"    Original RAM:  {tree['original_dw7_ram']}")
    print(f"    Tree size:     {tree['hybrid_tree_size']} bytes")
    print(f"    Ref count:     {tree['ref_count']} lui/addiu pairs")

    placements = cmap["valid_tree_placements"]
    print(f"\n  Valid Tree Placements:")
    for p in placements:
        print(f"    Mode {p['mode']}: {p['addr']} — {p['description']}")

    crit = cmap["critical_addresses"]
    print(f"\n  Critical Addresses: {len(crit)} entries")

    # Validate if requested
    if args.validate:
        if os.path.exists(args.validate):
            with open(args.validate) as f:
                patch_spec = json.load(f)
            violations = engine.validate_patch(patch_spec)
            if violations:
                print(f"\n  ⚠ PATCH VALIDATION: {len(violations)} VIOLATIONS:")
                for v in violations:
                    print(f"    ✗ {v}")
            else:
                print(f"\n  ✓ PATCH VALIDATION: No violations")
        else:
            print(f"\n  WARNING: Patch spec not found: {args.validate}")

    # Write output
    with open(args.output, 'w') as f:
        json.dump(cmap, f, indent=2)
    print(f"\n  Output: {args.output}")
    print("=" * 70)


if __name__ == "__main__":
    main()
