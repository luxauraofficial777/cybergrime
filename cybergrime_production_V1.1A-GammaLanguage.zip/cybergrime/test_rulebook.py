#!/usr/bin/env python3
"""Test the Pipeline Rulebook — 5 Laws enforcement gate."""
import sys, os, time
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from pipeline_rulebook import PipelineRulebook, GateVerdict, LawViolation

gate = PipelineRulebook()

print("=" * 60)
print("  PIPELINE RULEBOOK — 5 LAWS ENFORCEMENT TEST")
print("=" * 60)

# ── Test 1: Valid patch with all laws satisfied ──
print("\n--- Test 1: Valid BSS narrow patch (should APPROVE) ---")
patch1 = {
    'action': 'WRITE_MEM',
    'address': '0x8008E290',
    'value': '0x2462CCC8',
    'size': 4,
    'description': 'Narrow BSS clear end',
}
telemetry1 = {
    'Last_Known_PC': 0x80098780,
    'timestamp': time.time(),
    'thread_entry': 0,
    'bss_clear_end_instr': 0x24634980,
}
sim1 = {'result': 'PASS', 'detail': 'BSS narrow verified'}
vector_matches1 = [
    {'source': 'historical_HF-001', 'similarity': 1.0, 'match_type': 'STRUCTURED',
     'historical_failure': {'id': 'HF-001', 'fix_address': 0x8008E290,
                            'fix_value': 0x2462CCC8, 'status': 'PATCHED_AT_BUILD_TIME'}}
]

verdict1 = gate.evaluate(patch1, telemetry1, sim1, vector_matches1)
print(verdict1)
print(f"  Approved: {verdict1.approved}")

# ── Test 2: Patch with no simulation (Law 1 violation) ──
print("\n--- Test 2: Patch without simulation (Law 1 violation) ---")
sim2 = {'result': 'SKIP', 'detail': 'No simulation'}
verdict2 = gate.evaluate(patch1, telemetry1, sim2, vector_matches1)
print(verdict2)
print(f"  Approved: {verdict2.approved}")

# ── Test 3: Patch with no vector check (Law 3 violation) ──
print("\n--- Test 3: No vector pre-check (Law 3 violation) ---")
verdict3 = gate.evaluate(patch1, telemetry1, sim1, vector_matches=None)
print(verdict3)
print(f"  Approved: {verdict3.approved}")

# ── Test 4: Non-DuckStation source (Law 2 violation) ──
print("\n--- Test 4: Non-DuckStation telemetry source (Law 2 violation) ---")
verdict4 = gate.evaluate(patch1, telemetry1, sim1, vector_matches1,
                         source="custom_core")
print(verdict4)
print(f"  Approved: {verdict4.approved}")

# ── Test 5: Pointer drift — writing zero to tree (Law 5 violation) ──
print("\n--- Test 5: Writing zero to tree address (Law 5 violation) ---")
patch5 = {
    'action': 'WRITE_MEM',
    'address': '0x80100000',
    'value': '0x00000000',
    'size': 4,
    'description': 'Zero the tree (BAD)',
}
verdict5 = gate.evaluate(patch5, telemetry1, sim1, vector_matches1)
print(verdict5)
print(f"  Approved: {verdict5.approved}")

# ── Test 6: Python attempting disc write (Law 4 violation) ──
print("\n--- Test 6: Python binary disc write (Law 4 violation) ---")
patch6 = {
    'action': 'WRITE_DISC',
    'address': '0x096198',
    'value': '0x2462CCC8',
    'description': 'Direct disc write from Python',
}
verdict6 = gate.evaluate(patch6, telemetry1, sim1, vector_matches1)
print(verdict6)
print(f"  Approved: {verdict6.approved}")

# ── Test 7: C++ routed disc write (Law 4 satisfied) ──
print("\n--- Test 7: C++ engine disc write (Law 4 satisfied) ---")
patch7 = gate.enforce_cpp_surgery(patch6.copy())
verdict7 = gate.evaluate(patch7, telemetry1, sim1, vector_matches1)
print(verdict7)
print(f"  Approved: {verdict7.approved}")

# ── Summary ──
print("\n" + "=" * 60)
print("  ENFORCEMENT SUMMARY")
print("=" * 60)
summary = gate.get_enforcement_summary()
print(f"  Total evaluations: {summary['total_evaluations']}")
print(f"  Approved: {summary['approved']}")
print(f"  Rejected: {summary['rejected']}")
print(f"  Approval rate: {summary['approval_rate']:.0%}")
if summary['top_violations']:
    print("  Top violations:")
    for v, count in summary['top_violations']:
        print(f"    {v}: {count}")
