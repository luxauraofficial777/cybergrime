#!/usr/bin/env python3
"""Find STR/FMV sector ranges on DQ4 disc and compare to DW7."""
import struct

DQ4_PATH = r"C:\LuxAura\VoidWalkers_Project\DQLOSTTRANSLATION\Dragon Quest IV - Michibikareshi Mono Tachi (Japan).bin"
DW7_PATH = r"C:\LuxAura\VoidWalkers_Project\DQLOSTTRANSLATION\DW7D1\DW7D1.bin"

def find_str_ranges(path, label):
    with open(path, 'rb') as f:
        data = f.read()
    sectors = len(data) // 2352
    
    str_ranges = []
    in_str = False
    start_lba = 0
    
    for lba in range(sectors):
        off = lba * 2352 + 24
        if off + 20 > len(data):
            break
        submode = data[off + 18]
        is_str = bool(submode & 0x40)  # REAL-TIME flag
        
        if is_str and not in_str:
            in_str = True
            start_lba = lba
        elif not is_str and in_str:
            in_str = False
            end_lba = lba - 1
            count = end_lba - start_lba + 1
            str_ranges.append((start_lba, end_lba, count))
    
    if in_str:
        end_lba = sectors - 1
        count = end_lba - start_lba + 1
        str_ranges.append((start_lba, end_lba, count))
    
    print(f"\n{'='*60}")
    print(f"  {label}: {sectors} sectors ({len(data)/1024/1024:.1f} MB)")
    print(f"{'='*60}")
    
    significant = [(s,e,c) for s,e,c in str_ranges if c >= 50]
    print(f"  STR ranges >= 50 sectors: {len(significant)}")
    
    for start, end, count in significant:
        # Check submode flags at start
        off = start * 2352 + 24
        submode = data[off + 18]
        flags = []
        if submode & 0x80: flags.append("EOF")
        if submode & 0x40: flags.append("REALTIME")
        if submode & 0x20: flags.append("FORM2")
        if submode & 0x10: flags.append("TRIGGER")
        if submode & 0x08: flags.append("DATA")
        if submode & 0x04: flags.append("AUDIO")
        if submode & 0x02: flags.append("VIDEO")
        if submode & 0x01: flags.append("AUDIO_INT")
        
        # Show first 16 bytes of user data
        user_data = data[off:off+16]
        print(f"  LBA {start:6d}-{end:6d} ({count:6d} sectors, {count*2048/1024/1024:.2f} MB) submode=0x{submode:02X} [{','.join(flags)}]")
        print(f"    Data: {user_data.hex()}")
        
        # Convert LBA to MSF (MM:SS:FF)
        m = (start // 75) // 60
        s = (start // 75) % 60
        f = start % 75
        print(f"    MSF: {m:02d}:{s:02d}:{f:02d}")
    
    return str_ranges

dq4_ranges = find_str_ranges(DQ4_PATH, "DQ4 Disc")
dw7_ranges = find_str_ranges(DW7_PATH, "DW7 Disc")

# Summary comparison
print(f"\n{'='*60}")
print(f"  COMPARISON: FMV/STR Data")
print(f"{'='*60}")

dq4_sig = [(s,e,c) for s,e,c in dq4_ranges if c >= 50]
dw7_sig = [(s,e,c) for s,e,c in dw7_ranges if c >= 50]

print(f"\n  DQ4 FMV ranges:")
for s,e,c in dq4_sig:
    print(f"    LBA {s:6d}-{e:6d} ({c:6d} sectors, {c*2048/1024/1024:.2f} MB)")

print(f"\n  DW7 FMV ranges:")
for s,e,c in dw7_sig:
    print(f"    LBA {s:6d}-{e:6d} ({c:6d} sectors, {c*2048/1024/1024:.2f} MB)")

# Total STR data
dq4_total = sum(c for s,e,c in dq4_sig)
dw7_total = sum(c for s,e,c in dw7_sig)
print(f"\n  DQ4 total STR: {dq4_total} sectors ({dq4_total*2048/1024/1024:.1f} MB)")
print(f"  DW7 total STR: {dw7_total} sectors ({dw7_total*2048/1024/1024:.1f} MB)")

# What LBA does DW7 EXE seek to for FMV?
# Known: LBA 146621 (MSF 32:34:71)
print(f"\n  DW7 EXE FMV seek: LBA 146621 (MSF 32:34:71)")
print(f"  This falls within DW7 STR range: ", end="")
in_dw7 = any(s <= 146621 <= e for s,e,c in dw7_sig)
print("YES" if in_dw7 else "NO")

# Check if DQ4 has STR data at or near LBA 146621
in_dq4 = any(s <= 146621 <= e for s,e,c in dq4_sig)
print(f"  DQ4 has STR at LBA 146621: {'YES' if in_dq4 else 'NO'}")
