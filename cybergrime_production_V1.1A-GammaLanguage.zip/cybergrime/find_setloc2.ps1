$exePath = 'c:\LuxAura\VoidWalkers_Project\DQLOSTTRANSLATION\translation\SLUSP012.06'
$bytes = [System.IO.File]::ReadAllBytes($exePath)
$loadAddr = 0x80017F00

# Search for li $t1, 7 (CDROM_Setloc = B0 func 7) = 0x24090007
Write-Host "=== li t1, 7 (CDROM_Setloc B0 func 7) ==="
for ($i = 0x800; $i -lt $bytes.Length - 3; $i += 4) {
    $insn = [BitConverter]::ToUInt32($bytes, $i)
    if ($insn -eq 0x24090007) {
        $ram = $loadAddr + $i - 0x800
        $next = [BitConverter]::ToUInt32($bytes, $i + 4)
        $next2 = [BitConverter]::ToUInt32($bytes, $i + 8)
        $prev = [BitConverter]::ToUInt32($bytes, $i - 4)
        $prev2 = [BitConverter]::ToUInt32($bytes, $i - 8)
        Write-Host ("  RAM 0x{0:X8}: li t1,7  prev2=0x{1:X8} prev=0x{2:X8} next=0x{3:X8} next2=0x{4:X8}" -f $ram, $prev2, $prev, $next, $next2)
    }
}

# Search for li $t1, 0x0E (CDROM_Setmode = B0 func 14)
Write-Host ""
Write-Host "=== li t1, 0x0E (CDROM_Setmode B0 func 14) ==="
for ($i = 0x800; $i -lt $bytes.Length - 3; $i += 4) {
    $insn = [BitConverter]::ToUInt32($bytes, $i)
    if ($insn -eq 0x2409000E) {
        $ram = $loadAddr + $i - 0x800
        $next = [BitConverter]::ToUInt32($bytes, $i + 4)
        Write-Host ("  RAM 0x{0:X8}: li t1,0x0E  next=0x{1:X8}" -f $ram, $next)
    }
}

# Search for li t1, 8 (CDROM_ReadN = B0 func 8)
Write-Host ""
Write-Host "=== li t1, 8 (CDROM_ReadN B0 func 8) ==="
for ($i = 0x800; $i -lt $bytes.Length - 3; $i += 4) {
    $insn = [BitConverter]::ToUInt32($bytes, $i)
    if ($insn -eq 0x24090008) {
        $ram = $loadAddr + $i - 0x800
        $next = [BitConverter]::ToUInt32($bytes, $i + 4)
        Write-Host ("  RAM 0x{0:X8}: li t1,8  next=0x{1:X8}" -f $ram, $next)
    }
}

# Search for jal 0xB0 (BIOS B0 function table) = 0x0C00002C
Write-Host ""
Write-Host "=== jal 0xB0 (BIOS B0 dispatch) with li t1 pattern ==="
for ($i = 0x800; $i -lt $bytes.Length - 3; $i += 4) {
    $insn = [BitConverter]::ToUInt32($bytes, $i)
    if ($insn -eq 0x0C00002C) {
        $ram = $loadAddr + $i - 0x800
        $prev = [BitConverter]::ToUInt32($bytes, $i - 4)
        $prev2 = [BitConverter]::ToUInt32($bytes, $i - 8)
        $prev3 = [BitConverter]::ToUInt32($bytes, $i - 12)
        $prev4 = [BitConverter]::ToUInt32($bytes, $i - 16)
        # Check if any of prev instructions is li t1, N
        $funcNum = -1
        if (($prev -band 0xFFFF0000) -eq 0x24090000) { $funcNum = $prev -band 0xFFFF }
        elseif (($prev2 -band 0xFFFF0000) -eq 0x24090000) { $funcNum = $prev2 -band 0xFFFF }
        if ($funcNum -ge 0) {
            Write-Host ("  RAM 0x{0:X8}: jal 0xB0 func={1}  prev4=0x{2:X8} prev3=0x{3:X8} prev2=0x{4:X8} prev=0x{5:X8}" -f $ram, $funcNum, $prev4, $prev3, $prev2, $prev)
        }
    }
}
