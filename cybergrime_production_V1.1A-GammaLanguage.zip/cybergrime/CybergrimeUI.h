#pragma once

// ============================================================================
// CYBERGRIME UI MODULE — Standalone atmospheric rendering layer
// ============================================================================
// Replaces clean "Alpha" UI aesthetic with corrupted signal decay:
//   • Flickering cyan neon (unstable signal)
//   • Scanline jitter overlay
//   • CRT phosphor burn on static text
//   • Chromatic aberration at panel edges
//   • Procedural glitch in text lists
//   • High-frequency noise layer
//
// All helpers operate on the active GDI+ compose surface (DX11_GetComposeDC).
// Underlying data structures and alignment remain untouched.
// ============================================================================

#include <windows.h>
#include <cstdint>

// ── Lifecycle ─────────────────────────────────────────────────────────────
void CybergrimeUI_Init();
void CybergrimeUI_Shutdown();
void CybergrimeUI_Tick();  // Advance once per frame for flicker / glitch state

// ── Volatile Color ──────────────────────────────────────────────────────────
// Returns a flicker-modified RGB triplet based on frame counter and sine.
// baseR/G/B: the "nominal" neon color (e.g. 0,240,255 for cyan).
// intensity: 0.0f = no flicker, 1.0f = full decay.
void Cybergrime_GetFlickerCyan(uint8_t baseR, uint8_t baseG, uint8_t baseB,
                               uint8_t& outR, uint8_t& outG, uint8_t& outB,
                               float intensity = 1.0f);

// ── Panel Rendering ─────────────────────────────────────────────────────────
// Replaces DrawIndustrialPanel.  Grime borders instead of sharp lines.
void Cybergrime_DrawGrimePanel(int x, int y, int w, int h, bool isActive,
                               const char* title = nullptr);

// ── CRT Overlays ─────────────────────────────────────────────────────────────
// Full-screen scanline grid.  Call after all UI elements drawn.
void Cybergrime_DrawScanlineOverlay(HDC hdc);

// Sparse random noise dots across the entire 1600x900 surface.
void Cybergrime_DrawCRTNoise(HDC hdc);

// ── Text Effects ────────────────────────────────────────────────────────────
// Phosphor burn glow: draws text twice with slight offset and lower alpha.
void Cybergrime_DrawPhosphorText(HDC hdc, int x, int y, const char* text,
                                 uint8_t r, uint8_t g, uint8_t b,
                                 HFONT hFont);

// Glitch text for lists: occasional letter offset, alpha flicker, color split.
// seed: row index — determines glitch probability for that row.
void Cybergrime_DrawGlitchText(HDC hdc, int x, int y, const char* text,
                               uint8_t r, uint8_t g, uint8_t b,
                               HFONT hFont, int seed);

// ── Edge Decay ──────────────────────────────────────────────────────────────
// Chromatic aberration border: red channel nudged left, blue nudged right.
void Cybergrime_DrawChromaticBorder(HDC hdc, int x, int y, int w, int h,
                                    uint8_t r, uint8_t g, uint8_t b,
                                    int thickness = 2);

// ── Selection Halo ──────────────────────────────────────────────────────────
// Flickering selection rectangle with grime corners.
void Cybergrime_DrawGlitchSelector(HDC hdc, int x, int y, int w, int h,
                                   uint8_t r, uint8_t g, uint8_t b);

// ── Refined Panel (cleaner, for interior views & focused contexts) ────────
void Cybergrime_DrawSubtlePanel(int x, int y, int w, int h, bool isActive,
                                const char* title = nullptr);

// ── Action Row (horizontal button with icon + label + shortcut) ─────────────
void Cybergrime_DrawActionRow(HDC hdc, int x, int y, int w, int h,
                              const char* label, bool isSelected,
                              const char* shortcutKey = nullptr);

// ── Lightweight Tween System ──────────────────────────────────────────────
struct CG_Tween {
    float* target = nullptr;
    float  from = 0.0f;
    float  to = 0.0f;
    float  duration = 0.0f;
    float  elapsed = 0.0f;
    bool   active = false;
};

// Advance tweens by delta-time (seconds). Max 16 concurrent.
void CybergrimeUI_Tick(float dt);
// Legacy no-arg tick — delegates to dt version with dt=0
void CybergrimeUI_Tick();

// Start a tween on a target value.
void CG_TweenStart(float* target, float to, float duration);

// ── VRAM Viewer (Phase 2.4) ────────────────────────────────────────────────
// Renders a scaled view of PSX VRAM (1024x512) into the UI compose surface.
// vram: pointer to uint16_t[1024*512] VRAM array
// dstX, dstY: top-left position in compose surface
// scale: pixels per VRAM pixel (1 = full 1024x512, 2 = 2048x1024, etc.)
// showGrid: draw texture-page grid lines every 64x256 pixels
void Cybergrime_DrawVRAMViewer(const uint16_t* vram, int dstX, int dstY,
                                int scale = 1, bool showGrid = true);

// ── RAM Heatmap (Phase 2.4) ─────────────────────────────────────────────────
// Renders a heatmap of RAM activity (2MB = 512 pages of 4KB).
// ram: pointer to uint8_t[0x200000] RAM array
// heatmap: pointer to uint32_t[512] access counters per 4KB page
// dstX, dstY: top-left position in compose surface
// pageW: width in pixels per heatmap cell
// pageH: height in pixels per heatmap cell
// Highlights: injected code (red), HBD data (green), stack (blue)
void Cybergrime_DrawRAMHeatmap(const uint8_t* ram,
                                const uint32_t* heatmap, int heatmapCount,
                                int dstX, int dstY,
                                int pageW = 4, int pageH = 8);

// ── VRAM Pixel Format Helper ────────────────────────────────────────────────
// Convert PSX 15-bit color (0xBBBBGGGGGRRRRR) to 32-bit RGB
inline uint32_t PSXColor15to32(uint16_t c) {
    uint8_t r = (c & 0x1F) << 3;
    uint8_t g = ((c >> 5) & 0x1F) << 3;
    uint8_t b = ((c >> 10) & 0x1F) << 3;
    return (r << 16) | (g << 8) | b;
}
