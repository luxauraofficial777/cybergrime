# CyberGrime Architecture

## Overview

CyberGrime is a from-scratch PSX emulator designed for headless automated
testing of Dragon Quest IV translation patches. It prioritizes determinism
and introspection over accuracy.

## Core Components

### CPU (MIPS R3000A)

- Implemented in `psx_test_station.h` (class `MIPS_CPU`)
- Full MIPS I instruction set with delay slot handling
- 32 general registers, HI/LO, CP0 (Status, Cause, EPC, BadVAddr)
- Trace ring buffer (last 100 meaningful instructions)
- Breakpoint system (up to 16 breakpoints)

### Memory (PSX_Memory)

- 2MB RAM (0x000000-0x1FFFFF)
- 512KB BIOS (0x1FC000-0x200000)
- 4KB Scratchpad (0x1F8000-0x1F9000)
- 1MB VRAM (1024x512 x 16-bit)
- Hardware registers (0x1F801000-0x1F801FFF)
- I/O ports (0x1F801000-0x1F801080)
- CD-ROM subsystem with ISO9660 parsing
- DMA controller (6 channels)
- Timers (3 channels)

### GPU (psx_gpu.h)

- Software rasterizer (triangles, quads, lines, rects)
- VRAM transfers (CPU↔VRAM)
- Texture page management
- Display area and framebuffer
- GPUSTAT register with ready/busy bits
- Drawing area clipping

### GTE (psx_gte.h)

- Geometry Transformation Engine
- Rotation, translation, projection
- Color calculation
- 64 data registers

### SPU (psx_spu.h)

- ADPCM decode
- 24 voices
- Reverb (stub)
- Noise generator

### MDEC (psx_mdec.h)

- JPEG-like macroblock decode
- YCbCr to RGB conversion

### XA-ADPCM (psx_xa.h)

- CD-XA audio sector decode
- 4-bit ADPCM with filter

## Harness (agent_harness.h/.cpp)

The harness wraps the emulator for automated testing:

1. **TTY Interception** — captures all stdout/stderr into JSON telemetry
2. **VFS Logging** — logs every file open/read with LBA and result
3. **Freeze Detection** — monitors VBlank delivery and PC stagnation
4. **JSON Telemetry** — structured output for automated pass/fail evaluation
5. **Interactive Console** — stdin command interface for debugging
6. **Triage Logs** — full register dump on crash/freeze/timeout

## Debugger (psx_debugger.h)

Interactive CLI debugger with commands:
- `b`, `bc`, `bl` — breakpoints
- `w`, `wr` — watchpoints
- `m`, `mm` — memory dump/write
- `r`, `pc` — register/PC display
- `s`, `si` — step / step into delay slot
- `c`, `p` — continue / pause
- `dis` — disassemble
- `bt` — backtrace
- `info` — hardware state dump
- `save`, `load` — save/load state
- `screenshot` — framebuffer capture
- `log` — toggle trace logging

## Timeline (psx_timeline.h)

Records 18 event types during emulation:
- VBlank, IRQ, BIOS calls
- CD-ROM commands and IRQs
- DMA transfers
- GTE/GPU commands
- Breakpoints, freezes, injections
- Thread switches

Exports as JSON for `analyze_telemetry.py`.

## Advanced Features

### Save States (psx_savestate.h)
- Binary format with magic + version + CRC
- Captures CPU, RAM, BIOS, scratchpad, GTE, VRAM
- `--savestate-out` / `--loadstate` CLI flags

### Rewind (psx_rewind.h)
- Circular buffer of compact snapshots
- 600 snapshots @ 100K instruction intervals
- Stack + game state region captured per snapshot

### GDB Stub (psx_gdb_stub.h)
- GDB remote serial protocol over TCP
- Register read/write, memory read/write
- Breakpoints, single step, continue
- Compatible with `gdb-multiarch` and `lldb`

### Lua Scripting (psx_lua.h)
- Lua 5.4 bindings for memory, registers, breakpoints
- Event callbacks: `on_vblank`, `on_pc`, `on_bios`
- Input injection: `press_button`, `release_button`
- Compile-time toggle (`HAS_LUA` define)

## Testing Framework

### Test Definitions (test_definitions.json)
- JSON format with test ID, disc, max_instrs, wallclock, expect criteria
- Profiles: quick_smoke, full_regression, emulator_only, unit_only

### Regression Runner (regression_runner.py)
- Runs tests via `psx_agent_runner.exe`
- Evaluates pass/fail: no_crash, min_vblank, thread_executes, etc.
- SQLite results database

### Baseline Manager (baseline_manager.py)
- Save/compare telemetry baselines
- Detects regressions in instruction count, VBlank count, BIOS call histogram
