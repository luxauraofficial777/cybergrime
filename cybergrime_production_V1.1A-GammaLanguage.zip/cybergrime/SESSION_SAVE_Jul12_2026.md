# CD-ROM Pipeline Fix Session — Jul 12, 2026 5:19 AM

## User's Goal
Frankenstein ROM (DW7 modified EXE + DQ4 translated HBD + DW7 ROM body) must reach Chapter 1 battle as Ragnar + save file. User will playtest from there.

**Frankenstein is NOT dead.** User explicitly corrected this. The Frankenstein approach IS the path forward.

---

## Phase 1: CD-ROM Status Register Fix — COMPLETE

### Changes to `psx_emulator_core.cpp`
- Status register (0x1F801800) bit layout matches DuckStation:
  - Bit 3 = PRMEMPTY (param FIFO empty)
  - Bit 4 = PRMWRDY (param FIFO not full)
  - Bit 5 = RSLRRDY (response FIFO has data)
  - Bit 6 = DRQSTS (data FIFO ready, gated by BFRD)
  - Bit 7 = BUSYSTS (command in progress)
- Response FIFO (0x1F801801) separated from data FIFO (0x1F801802)
- Interrupt flag register (0x1F801803): upper bits always read as 1 (`| 0xF8`), ACK uses bits 0-2, param FIFO clear is bit 6 (was incorrectly bit 7)
- BFRD bit handling in request register (bit 5 of 0x1F801803 index=0)
- `cdrom_int_flag` tracking — game must ACK interrupts by writing to 0x1F801803 index=1
- Setloc pending + LBA apply on ReadN/ReadS
- Added Test (0x19) and Init (0x1E) commands
- Exception handler no longer clears `cdrom_irq_code` — leaves `cdrom_int_flag` for game to ACK

### Changes to `psx_test_station.h`
- `cdrom_tick()` IRQ firing now sets `cdrom_int_flag` and checks `cdrom_int_enable` before asserting IRQ line
- Secondary status cleared on pause

### Verification
- Build succeeded
- Status register reads 0x18 (PRMEMPTY|PRMWRDY) — CORRECT
- Interrupt flag reads 0xF8 (no pending, upper bits=1) — CORRECT

---

## Phase 0: HBD Scan — IN PROGRESS (~65%)

- `scan_hbd_for_prologue.py` scanning DW7 HBD for MIPS prologue patterns near RAM 0x800D9E80
- Found 9967+ code regions so far
- Output: `scan_prologue_output.txt` and `thread_code_blob.bin`
- `scan_hbd_for_thread.py` also available (user has this open in IDE)

---

## Freeze Detector Fix — APPLIED, NOT YET BUILT

| Setting | Old Value | New Value | File |
|---------|-----------|-----------|------|
| `HARNESS_LOOP_INSTR_THRESH` | 10M | 200M | `agent_harness.h:60` |
| `set_freeze_threshold()` | 50M | 500M | `psx_agent_runner.cpp:256` |

Build was canceled before completion. Need to rebuild.

---

## Test Results

### dq4_full_en_v26.bin (Native DQ4 — for reference only, not the target)

| Run | Instrs | VBlanks | Sectors | Status |
|-----|--------|---------|---------|--------|
| 10M | 10M | 25 | 0 | Running, status reg correct (0x18) |
| 50M | 50M | 125 | 0 | Running, VBlank wait loop at 0x80099F40 |
| 100M | 52.8M | 132 | 0 | FREEZE detector killed run (false positive) |

BIOS calls: only B:16 (ChangeClearPadInt) and B:23 (InitPAD). No OpenTh, no CD-ROM commands.

### dq4_frankenstein_v14.bin (Frankenstein — THE TARGET)

- **Crashed at instr #34,523,696**
- PC=0x8004BD71, `jal 0x8C000000` (unmapped)
- 86 VBlanks, 0 sectors read
- BIOS calls: B:23(16), B:53(2), B:8(1), B:12(1), B:10(44)
  - B:10 = ChangeTh called 44 times (thread switching active!)
  - B:8 = OpenEvent (1 call — event registered)
  - B:12 = CloseEvent(1)

### V14 Crash Analysis
```
0x8004BD61: 0xCC3C0280  — op=0x33 (INVALID MIPS)
0x8004BD69: 0x48000000  — op=0x12 (INVALID MIPS)
0x8004BD71: 0x0F000000  — jal 0x8C000000 (unmapped → crash)
```
Code at 0x8004BD61 is corrupted — not valid MIPS. Likely HBD data overwriting EXE code region. Previous diagnostic found HBD loading corrupts BIOS vector region (0x800E2000-0x800E2400). This crash may be a different manifestation of the same issue.

---

## Key Files Modified This Session

| File | Changes |
|------|---------|
| `psx_emulator_core.cpp` | CD-ROM register handlers, interrupt flag, exception handler, BFRD, Setloc pending |
| `psx_test_station.h` | cdrom_tick IRQ firing with int_flag, secondary status on pause |
| `agent_harness.h` | HARNESS_LOOP_INSTR_THRESH 10M→200M |
| `psx_agent_runner.cpp` | freeze threshold 50M→500M |
| `disasm_openth.py` | Created — finds OpenTh call sites in DQ4 EXE |

---

## Next Steps (Priority Order)

1. **Rebuild** with freeze detector fix (`.\build_agent.bat`)
2. **Complete HBD scan** → extract `thread_code_blob.bin`
3. **Inject thread code** into `psx_agent_runner.cpp` PRELOAD at 0x800D9E80
4. **Fix Frankenstein v14 crash** at 0x8004BD71 — investigate corrupted code region, likely HBD overwrite
5. **Run 500M+ instruction test** with freeze detector fixed
6. **Verify**: OpenTh → CD-ROM commands (Setloc/ReadN) → sectors read > 0 → title screen
7. **Ultimate goal**: Chapter 1 battle as Ragnar + save file → user playtests
