#!/usr/bin/env python3
"""Disassemble the game's HookEntryInt handler at 0x800969F4 and the
full interrupt processing path to understand what it does with 0x800B679C."""
import struct, os
from capstone import Cs, CS_ARCH_MIPS, CS_MODE_MIPS32, CS_MODE_LITTLE_ENDIAN

def read_exe_from_disc(disc_path, exe_lba=24, sector_size=2352, user_offset=24, user_size=2048):
    with open(disc_path, 'rb') as f:
        exe_sectors = 340
        f.seek(exe_lba * sector_size)
        raw = f.read(exe_sectors * sector_size)
    exe_data = bytearray()
    for i in range(exe_sectors):
        sector = raw[i * sector_size:(i + 1) * sector_size]
        if len(sector) < user_offset + user_size:
            break
        exe_data += sector[user_offset:user_offset + user_size]
    return bytes(exe_data)

def disasm_range(exe_data, load_addr, start_ram, end_ram):
    code_offset = 0x800
    file_start = start_ram - load_addr + code_offset
    file_end = end_ram - load_addr + code_offset
    if file_start < 0 or file_end > len(exe_data):
        return "  (outside EXE)\n"
    code = exe_data[file_start:file_end]
    md = Cs(CS_ARCH_MIPS, CS_MODE_MIPS32 | CS_MODE_LITTLE_ENDIAN)
    lines = []
    for insn in md.disasm(code, start_ram):
        lines.append(f"  0x{insn.address:08X}: {insn.mnemonic:8s} {insn.op_str}")
    return '\n'.join(lines) + '\n'

base = r"C:\LuxAura\VoidWalkers_Project\DQLOSTTRANSLATION"
disc = os.path.join(base, "dq4_frankenstein_v41.bin")
load_addr = 0x80017F00

exe = read_exe_from_disc(disc)
print(f"EXE: {len(exe)} bytes, magic={exe[0:8]}")

# Game's HookEntryInt handler at 0x800969F4
print("\n=== GAME INTERRUPT HANDLER (0x800969F4-0x80096A80) ===")
print(disasm_range(exe, load_addr, 0x800969F4, 0x80096A80))

# Also check the VBlank handler entry at 0x8009695C (from disc_comparison)
print("\n=== VBLANK HANDLER ENTRY (0x8009695C-0x800969F4) ===")
print(disasm_range(exe, load_addr, 0x8009695C, 0x800969F4))

# Check what's at 0x800B5348 (HookEntryInt register block)
print("\n=== 0x800B5348 (HookEntryInt reg block) ===")
off = 0x800B5348 - load_addr + 0x800
print(f"  EXE file offset: 0x{off:X}")
if off < len(exe):
    vals = struct.unpack_from('<12I', exe, off)
    for i, v in enumerate(vals):
        print(f"  [{i}] = 0x{v:08X}")
else:
    print("  Beyond EXE (BSS)")

# Check the full function from 0x800969F4 to find what it writes
print("\n=== FULL HANDLER + RETURN (0x800969F4-0x80096B00) ===")
print(disasm_range(exe, load_addr, 0x800969F4, 0x80096B00))
