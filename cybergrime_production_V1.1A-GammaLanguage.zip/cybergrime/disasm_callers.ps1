$exePath = 'c:\LuxAura\VoidWalkers_Project\DQLOSTTRANSLATION\translation\SLUSP012.06'
$bytes = [System.IO.File]::ReadAllBytes($exePath)
$loadAddr = 0x80017F00

$rn = @('zero','at','v0','v1','a0','a1','a2','a3','t0','t1','t2','t3','t4','t5','t6','t7','s0','s1','s2','s3','s4','s5','s6','s7','t8','t9','k0','k1','gp','sp','fp','ra')

function D($ramAddr, $count) {
    $fileOff = $ramAddr - $loadAddr + 0x800
    for ($j = 0; $j -lt $count; $j++) {
        $off = $fileOff + $j * 4
        if ($off -lt 0 -or $off + 3 -ge $bytes.Length) { Write-Host "  [oor]"; continue }
        $val = [BitConverter]::ToUInt32($bytes, $off)
        $ram = $loadAddr + $off - 0x800
        $op = $val -shr 26
        $imm = $val -band 0xFFFF
        if ($imm -ge 0x8000) { $immS = $imm - 0x10000 } else { $immS = $imm }
        $rs = ($val -shr 21) -band 0x1F; $rt = ($val -shr 16) -band 0x1F; $rd = ($val -shr 11) -band 0x1F
        $funct = $val -band 0x3F
        $rsn=$rn[$rs]; $rtn=$rn[$rt]; $rdn=$rn[$rd]
        $d = ''
        if ($val -eq 0) { $d = 'nop' }
        elseif ($op -eq 0x09) { $d = "addiu $rtn,$rsn,$immS" }
        elseif ($op -eq 0x0F) { $d = "lui $rtn,0x$($imm.ToString('X4'))" }
        elseif ($op -eq 0x0D) { $d = "ori $rtn,$rsn,0x$($imm.ToString('X4'))" }
        elseif ($op -eq 0x0C) { $d = "andi $rtn,$rsn,0x$($imm.ToString('X4'))" }
        elseif ($op -eq 0x23) { $d = "lw $rtn,0x$($imm.ToString('X4'))($rsn)" }
        elseif ($op -eq 0x21) { $d = "lh $rtn,0x$($imm.ToString('X4'))($rsn)" }
        elseif ($op -eq 0x25) { $d = "lhu $rtn,0x$($imm.ToString('X4'))($rsn)" }
        elseif ($op -eq 0x24) { $d = "lbu $rtn,0x$($imm.ToString('X4'))($rsn)" }
        elseif ($op -eq 0x20) { $d = "lb $rtn,0x$($imm.ToString('X4'))($rsn)" }
        elseif ($op -eq 0x28) { $d = "sb $rtn,0x$($imm.ToString('X4'))($rsn)" }
        elseif ($op -eq 0x29) { $d = "sh $rtn,0x$($imm.ToString('X4'))($rsn)" }
        elseif ($op -eq 0x2B) { $d = "sw $rtn,0x$($imm.ToString('X4'))($rsn)" }
        elseif ($op -eq 0x03) { $t2=($val -band 0x3FFFFFF)-shl 2; $d="jal 0x$($t2.ToString('X8'))" }
        elseif ($op -eq 0x02) { $t2=($val -band 0x3FFFFFF)-shl 2; $d="j 0x$($t2.ToString('X8'))" }
        elseif ($op -eq 0x04) { $bt=$ram+4+$immS*4; $d="beq $rsn,$rtn,0x$($bt.ToString('X8'))" }
        elseif ($op -eq 0x05) { $bt=$ram+4+$immS*4; $d="bne $rsn,$rtn,0x$($bt.ToString('X8'))" }
        elseif ($op -eq 0x00 -and $funct -eq 0x08) { $d="jr $rsn" }
        elseif ($op -eq 0x00 -and $funct -eq 0x21) { $d="addu $rdn,$rsn,$rtn" }
        elseif ($op -eq 0x00 -and $funct -eq 0x25) { $d="or $rdn,$rsn,$rtn" }
        elseif ($op -eq 0x00 -and $funct -eq 0x02) { $sh=($val -shr 6)-band 0x1F; $d="srl $rdn,$rtn,$sh" }
        elseif ($op -eq 0x00 -and $funct -eq 0x00) { $sh=($val -shr 6)-band 0x1F; $d="sll $rdn,$rtn,$sh" }
        else { $d="op=0x$($op.ToString('X2')) f=0x$($funct.ToString('X2'))" }
        Write-Host ("  0x{0:X8}: 0x{1:X8}  {2}" -f $ram, $val, $d)
    }
}

# Caller 1: 0x80091C7C — show 30 instructions before
Write-Host "=== Caller 1: 0x80091C7C (30 instr before) ==="
D 0x80091C04 35

# Caller 2: 0x800965C4 — show 30 instructions before
Write-Host ""
Write-Host "=== Caller 2: 0x800965C4 (30 instr before) ==="
D 0x8009654C 35
