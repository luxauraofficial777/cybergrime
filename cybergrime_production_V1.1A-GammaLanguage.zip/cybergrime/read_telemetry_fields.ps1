$j = Get-Content telemetry_clean_50m.json -Raw | ConvertFrom-Json
Write-Host "=== Telemetry fields ==="
$j.PSObject.Properties | ForEach-Object { 
    if ($_.Value -is [string]) {
        Write-Host "$($_.Name): $($_.Value.Substring(0, [Math]::Min(200, $_.Value.Length)))"
    } else {
        Write-Host "$($_.Name): $($_.Value)"
    }
}
Write-Host ""
Write-Host "=== BIOS Call Log ==="
if ($j.PSObject.Properties.Match('BIOS_Call_Log').Count -gt 0) {
    $bios = $j.BIOS_Call_Log
    Write-Host "Count: $($bios.Count)"
    $bios | Select-Object -First 30 | ForEach-Object { Write-Host "  $_" }
} else {
    Write-Host "No BIOS_Call_Log field"
}
Write-Host ""
Write-Host "=== Last_BIOS_Calls ==="
if ($j.PSObject.Properties.Match('Last_BIOS_Calls').Count -gt 0) {
    $bios = $j.Last_BIOS_Calls
    Write-Host "Count: $($bios.Count)"
    $bios | ForEach-Object { Write-Host "  $_" }
} else {
    Write-Host "No Last_BIOS_Calls field"
}
