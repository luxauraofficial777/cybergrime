#!/usr/bin/env python3
"""Phase 1 Step 1: Static return-value audit of FMV seek NOP sites.

Per GLM_EXECUTION_ROADMAP §4.2:
- Disassemble 6 wrappers (0x80041C30..0x80041E78) and 0x8003DDC4 itself
- For every JAL->0x8003DDC4 and the two NOP sites, look for:
  beq/bne $v0, slti/sltiu $v0, sw $v0, move $X,$v0 within ~10 instructions after
  and any store of $v0 to BSS (0x800F0Dxx region)
"""
import struct, sys, os

EXE_PATH = os.path.join(os.path.dirname(__file__), '..', 'translation', 'SLUSP012.06_clean.bin')
LOAD_ADDR = 0x80017F00
EXE_HEADER = 0x800  # 2048-byte PS-X EXE header

def ram_to_file(ram_addr):
    return ram_addr - LOAD_ADDR + EXE_HEADER

def read_exe():
    with open(EXE_PATH, 'rb') as f:
        data = f.read()
    return data

def read_word(data, file_off):
    return struct.unpack_from('<I', data, file_off)[0]

# MIPS register names
REG_NAMES = ['zero','at','v0','v1','a0','a1','a2','a3',
             't0','t1','t2','t3','t4','t5','t6','t7',
             's0','s1','s2','s3','s4','s5','s6','s7',
             't8','t9','k0','k1','gp','sp','fp','ra']

def reg(n):
    return f"${REG_NAMES[n]}" if n < 32 else f"${n}"

def disasm_one(word, pc):
    """Minimal MIPS disassembler for control-flow analysis."""
    op = (word >> 26) & 0x3F
    rs = (word >> 21) & 0x1F
    rt = (word >> 16) & 0x1F
    rd = (word >> 11) & 0x1F
    shamt = (word >> 6) & 0x1F
    funct = word & 0x3F
    imm = word & 0xFFFF
    simm = imm if imm < 0x8000 else imm - 0x10000
    target = (word & 0x3FFFFFF) << 2 | (pc & 0xF0000000)
    
    if word == 0:
        return "nop"
    if op == 0:  # SPECIAL
        if funct == 0x20: return f"add {reg(rd)}, {reg(rs)}, {reg(rt)}"
        if funct == 0x21: return f"addu {reg(rd)}, {reg(rs)}, {reg(rt)}"
        if funct == 0x22: return f"sub {reg(rd)}, {reg(rs)}, {reg(rt)}"
        if funct == 0x23: return f"subu {reg(rd)}, {reg(rs)}, {reg(rt)}"
        if funct == 0x24: return f"and {reg(rd)}, {reg(rs)}, {reg(rt)}"
        if funct == 0x25: return f"or {reg(rd)}, {reg(rs)}, {reg(rt)}"
        if funct == 0x26: return f"xor {reg(rd)}, {reg(rs)}, {reg(rt)}"
        if funct == 0x27: return f"nor {reg(rd)}, {reg(rs)}, {reg(rt)}"
        if funct == 0x2A: return f"slt {reg(rd)}, {reg(rs)}, {reg(rt)}"
        if funct == 0x2B: return f"sltu {reg(rd)}, {reg(rs)}, {reg(rt)}"
        if funct == 0x00: return f"sll {reg(rd)}, {reg(rt)}, {shamt}"
        if funct == 0x02: return f"srl {reg(rd)}, {reg(rt)}, {shamt}"
        if funct == 0x03: return f"sra {reg(rd)}, {reg(rt)}, {shamt}"
        if funct == 0x04: return f"sllv {reg(rd)}, {reg(rt)}, {reg(rs)}"
        if funct == 0x06: return f"srlv {reg(rd)}, {reg(rt)}, {reg(rs)}"
        if funct == 0x07: return f"srav {reg(rd)}, {reg(rt)}, {reg(rs)}"
        if funct == 0x08: return f"jr {reg(rs)}"
        if funct == 0x09: return f"jalr {reg(rd)}, {reg(rs)}"
        if funct == 0x0C: return f"syscall"
        if funct == 0x10: return f"mfhi {reg(rd)}"
        if funct == 0x11: return f"mthi {reg(rs)}"
        if funct == 0x12: return f"mflo {reg(rd)}"
        if funct == 0x13: return f"mtlo {reg(rs)}"
        return f".special 0x{funct:02x}"
    if op == 0x01:  # REGIMM
        if rt == 0: return f"bltz {reg(rs)}, 0x{pc + 4 + simm*4:08X}"
        if rt == 1: return f"bgez {reg(rs)}, 0x{pc + 4 + simm*4:08X}"
        return f".regimm {rt}"
    if op == 0x02: return f"j 0x{target:08X}"
    if op == 0x03: return f"jal 0x{target:08X}"
    if op == 0x04: return f"beq {reg(rs)}, {reg(rt)}, 0x{pc + 4 + simm*4:08X}"
    if op == 0x05: return f"bne {reg(rs)}, {reg(rt)}, 0x{pc + 4 + simm*4:08X}"
    if op == 0x06: return f"blez {reg(rs)}, 0x{pc + 4 + simm*4:08X}"
    if op == 0x07: return f"bgtz {reg(rs)}, 0x{pc + 4 + simm*4:08X}"
    if op == 0x08: return f"addi {reg(rt)}, {reg(rs)}, {simm}"
    if op == 0x09: return f"addiu {reg(rt)}, {reg(rs)}, {simm}"
    if op == 0x0A: return f"slti {reg(rt)}, {reg(rs)}, {simm}"
    if op == 0x0B: return f"sltiu {reg(rt)}, {reg(rs)}, {simm}"
    if op == 0x0C: return f"andi {reg(rt)}, {reg(rs)}, 0x{imm:04X}"
    if op == 0x0D: return f"ori {reg(rt)}, {reg(rs)}, 0x{imm:04X}"
    if op == 0x0E: return f"xori {reg(rt)}, {reg(rs)}, 0x{imm:04X}"
    if op == 0x0F: return f"lui {reg(rt)}, 0x{imm:04X}"
    if op == 0x20: return f"lb {reg(rt)}, {simm}({reg(rs)})"
    if op == 0x21: return f"lh {reg(rt)}, {simm}({reg(rs)})"
    if op == 0x23: return f"lw {reg(rt)}, {simm}({reg(rs)})"
    if op == 0x24: return f"lbu {reg(rt)}, {simm}({reg(rs)})"
    if op == 0x25: return f"lhu {reg(rt)}, {simm}({reg(rs)})"
    if op == 0x28: return f"sb {reg(rt)}, {simm}({reg(rs)})"
    if op == 0x29: return f"sh {reg(rt)}, {simm}({reg(rs)})"
    if op == 0x2B: return f"sw {reg(rt)}, {simm}({reg(rs)})"
    return f".unk 0x{word:08X} (op=0x{op:02x})"

def disasm_range(data, start_ram, count):
    """Disassemble `count` instructions starting at `start_ram`."""
    fo = ram_to_file(start_ram)
    lines = []
    for i in range(count):
        word = read_word(data, fo + i*4)
        pc = start_ram + i*4
        lines.append(f"  0x{pc:08X}: 0x{word:08X}  {disasm_one(word, pc)}")
    return lines

def audit_v0_usage(lines):
    """Check if any instruction references $v0 (reg 2) or $v1 (reg 3)."""
    v0_hits = []
    for line in lines:
        low = line.lower()
        if 'v0' in low or 'v1' in low:
            v0_hits.append(line)
    return v0_hits

def main():
    data = read_exe()
    print(f"EXE size: {len(data)} bytes")
    print(f"EXE text: {len(data) - EXE_HEADER} bytes")
    print()
    
    # === FMV playback function 0x8003DDC4 ===
    print("=" * 70)
    print("FMV PLAYBACK FUNCTION: 0x8003DDC4 (file offset 0x{:05X})".format(ram_to_file(0x8003DDC4)))
    print("=" * 70)
    lines = disasm_range(data, 0x8003DDC4, 80)
    for l in lines:
        print(l)
    
    # Highlight NOP sites
    print()
    print("--- NOP SITE ANALYSIS ---")
    for label, nop_ram in [("PRIMARY NOP SITE", 0x8003DE60), ("SECONDARY NOP SITE", 0x8003DF4C)]:
        print(f"\n{label}: 0x{nop_ram:08X}")
        print(f"  Context (10 before, 15 after):")
        start = nop_ram - 10*4
        lines = disasm_range(data, start, 26)
        for l in lines:
            marker = " <<< NOP" if ("0x00000000  nop" in l and nop_ram == start + 10*4) else ""
            # Mark the NOP site
            pc_val = int(l.strip().split(':')[0].strip(), 16)
            if pc_val == nop_ram:
                marker = " <<< NOP SITE (was JAL 0x8004081C)"
            print(f"  {l}{marker}")
        
        # Check for v0 usage in the 10 instructions after NOP
        after_lines = disasm_range(data, nop_ram + 4, 10)
        v0_hits = audit_v0_usage(after_lines)
        if v0_hits:
            print(f"  *** $v0/$v1 USAGE AFTER NOP:")
            for h in v0_hits:
                print(f"  {h}")
        else:
            print(f"  (no $v0/$v1 usage in 10 instructions after NOP)")
    
    # === 6 wrapper functions ===
    print()
    print("=" * 70)
    print("WRAPPER FUNCTIONS (callers of 0x8003DDC4)")
    print("=" * 70)
    wrappers = [
        (0x80041C30, "idx=0 (intro FMV, 11 callers)"),
        (0x80041C88, "idx=1 (2 callers)"),
        (0x80041CE0, "idx=2 (0 callers)"),
        (0x80041D38, "idx=3 (0 callers)"),
        (0x80041DFC, "idx=4 (0 callers)"),
        (0x80041E78, "idx=4 (2 callers)"),
    ]
    
    for wram, desc in wrappers:
        print(f"\n--- WRAPPER 0x{wram:08X} ({desc}) ---")
        lines = disasm_range(data, wram, 20)
        for l in lines:
            print(l)
        # Check for v0 usage
        v0_hits = audit_v0_usage(lines)
        if v0_hits:
            print(f"  *** $v0/$v1 USAGE:")
            for h in v0_hits:
                print(f"  {h}")
    
    # === Check what's at 0x8008BA54 (file search string) ===
    print()
    print("=" * 70)
    print("FILE SEARCH STRING at 0x8008BA54")
    print("=" * 70)
    fo = ram_to_file(0x8008BA54)
    raw = data[fo:fo+32]
    print(f"  Raw bytes: {raw.hex()}")
    # Try ASCII
    try:
        ascii_str = raw.decode('ascii', errors='replace')
        print(f"  ASCII: {ascii_str!r}")
    except:
        pass
    
    # Also check the file search function context
    print()
    print("--- FILE SEARCH FUNCTION 0x8008B9CC ---")
    lines = disasm_range(data, 0x8008B9CC, 20)
    for l in lines:
        print(l)

if __name__ == '__main__':
    main()
