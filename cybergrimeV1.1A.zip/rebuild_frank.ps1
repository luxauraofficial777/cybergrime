# Rebuild Frankenstein disc with corrected FMV stubs (only 0x8008CAD0)
$base = "C:\LuxAura\VoidWalkers_Project\DQLOSTTRANSLATION"
$builder = "$base\cybergrime\frankenstein_build.exe"

# Kill stale processes
Stop-Process -Name 'duckstation-qt-x64-ReleaseLTCG' -Force -ErrorAction SilentlyContinue
Stop-Process -Name 'psx_agent_runner' -Force -ErrorAction SilentlyContinue

$args = @(
    "--reverse",
    "--dq4-hbd", "$base\Dragon Quest IV - Michibikareshi Mono Tachi (Japan).bin",
    "--dw7-exe", "$base\translation\SLUSP012.06_clean.bin",
    "--hybrid-tree", "$base\frozen\dw7_hybrid_tree.bin",
    "--folder-map", "$base\translation\folder_mapping.json",
    "--edcre", "$base\edcre\edcre-v1.1.0-windows-x86_64-static\edcre.exe",
    "--output", "$base\build_staging\dq4_reverse_a.bin",
    "--output-cue", "$base\build_staging\dq4_reverse_a.cue",
    "--duckstation",
    "--reencode-hbd",
    "--skip-hash-check",
    "--staging-dir", "$base\build_staging"
)

Write-Output "=== Rebuilding Frankenstein disc ==="
Write-Output "Builder: $builder"

$proc = Start-Process -FilePath $builder -ArgumentList $args `
    -NoNewWindow -PassThru `
    -WorkingDirectory "$base\cybergrime" `
    -RedirectStandardOutput "rebuild_stdout.txt" `
    -RedirectStandardError "rebuild_stderr.txt"

$proc | Wait-Process -Timeout 300 -ErrorAction SilentlyContinue

if (-not $proc.HasExited) {
    Write-Output "Build timed out, killing..."
    $proc | Stop-Process -Force
}

Write-Output "Exit code: $($proc.ExitCode)"
Write-Output ""
Write-Output "=== Build output (last 50 lines) ==="
$out = Get-Content "$base\cybergrime\rebuild_stdout.txt" -ErrorAction SilentlyContinue
if ($out) {
    $out | Select-Object -Last 50
}
