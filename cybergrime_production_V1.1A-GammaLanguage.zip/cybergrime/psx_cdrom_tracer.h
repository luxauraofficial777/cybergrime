#pragma once
#include <cstdint>
#include <cstring>
#include <vector>
#include <cstdio>

// ===== CD-ROM Command Tracer =====
// Captures every CD-ROM command for diagnostic purposes.
// Detects parameter overflow, command spam, and missing interrupts.

struct CdromCommandLog {
    uint64_t instruction_count;
    uint8_t command;
    uint8_t params[16];
    int param_count;
    uint32_t pc;
    uint32_t ra;
    int result;              // 0=success, nonzero=error code
    char command_name[16];
};

struct CdromEventLog {
    uint64_t instruction_count;
    uint32_t event_id;
    uint32_t class_id;
    uint32_t spec;
    int flags;               // 0=free, 1=disabled, 2=enabled, 3=pending
    const char* action;      // "deliver", "test", "wait", "enable", "disable"
    int test_result;         // For testEvent: 0 or 1
};

class CdromTracer {
public:
    static constexpr int MAX_COMMANDS = 4096;
    static constexpr int MAX_EVENTS = 1024;
    static constexpr int SPAM_THRESHOLD = 5;

    std::vector<CdromCommandLog> commands;
    std::vector<CdromEventLog> events;

    // Statistics
    int setloc_errors;
    int getstat_spam_count;
    uint32_t last_progress_lba;
    uint64_t instructions_at_last_progress;
    int total_commands;
    int total_errors;

    // Spam detection state
    uint8_t last_command;
    int repeat_count;

    // Error breakpoint (Section 5.2)
    bool error_breakpoint_enabled;
    bool error_breakpoint_fired;
    uint32_t breakpoint_pc;
    uint32_t breakpoint_ra;
    int breakpoint_cmd;
    int breakpoint_param_count;
    uint8_t breakpoint_params[16];
    char breakpoint_cmd_name[16];

    CdromTracer() { reset(); }

    void reset() {
        commands.clear();
        events.clear();
        commands.reserve(MAX_COMMANDS);
        events.reserve(MAX_EVENTS);
        setloc_errors = 0;
        getstat_spam_count = 0;
        last_progress_lba = 0;
        instructions_at_last_progress = 0;
        total_commands = 0;
        total_errors = 0;
        last_command = 0xFF;
        repeat_count = 0;
        error_breakpoint_enabled = false;
        error_breakpoint_fired = false;
        breakpoint_pc = 0;
        breakpoint_ra = 0;
        breakpoint_cmd = 0;
        breakpoint_param_count = 0;
        memset(breakpoint_params, 0, sizeof(breakpoint_params));
        breakpoint_cmd_name[0] = 0;
    }

    static const char* command_name(uint8_t cmd) {
        switch (cmd) {
            case 0x01: return "Getstat";
            case 0x02: return "Setloc";
            case 0x03: return "Play";
            case 0x04: return "Forward";
            case 0x05: return "Backward";
            case 0x06: return "ReadN";
            case 0x07: return "MotorOn";
            case 0x08: return "Stop";
            case 0x09: return "Pause";
            case 0x0A: return "Init";
            case 0x0B: return "Mute";
            case 0x0C: return "Demute";
            case 0x0D: return "Setfilter";
            case 0x0E: return "Setmode";
            case 0x0F: return "Getparam";
            case 0x10: return "GetlocL";
            case 0x11: return "GetlocP";
            case 0x12: return "Setsession";
            case 0x13: return "GetTN";
            case 0x14: return "GetTD";
            case 0x15: return "SeekL";
            case 0x16: return "SeekP";
            case 0x19: return "Test";
            case 0x1A: return "GetID";
            case 0x1B: return "ReadS";
            case 0x1C: return "Reset";
            case 0x1E: return "ReadTOC";
            default: return "Unknown";
        }
    }

    void log_command(uint8_t cmd, const uint8_t* params, int param_count,
                     uint32_t pc, uint32_t ra, int result = 0) {
        total_commands++;

        // Spam detection
        if (cmd == last_command) {
            repeat_count++;
            if (repeat_count >= SPAM_THRESHOLD) {
                if (cmd == 0x01) getstat_spam_count++;
            }
        } else {
            last_command = cmd;
            repeat_count = 1;
        }

        // Track errors
        if (result != 0) {
            total_errors++;
            if (cmd == 0x02) setloc_errors++;
        }

        // Track progress (LBA changes)
        if (cmd == 0x02 && param_count == 3) {
            uint8_t m = (params[0] >> 4) * 10 + (params[0] & 0xF);
            uint8_t s = (params[1] >> 4) * 10 + (params[1] & 0xF);
            uint8_t f = (params[2] >> 4) * 10 + (params[2] & 0xF);
            uint32_t lba = (uint32_t)(m * 60 + s) * 75 + f - 150;
            if (lba != last_progress_lba) {
                last_progress_lba = lba;
                // instruction_count will be set by caller
            }
        }

        if ((int)commands.size() < MAX_COMMANDS) {
            CdromCommandLog entry;
            entry.instruction_count = 0; // Set by caller
            entry.command = cmd;
            entry.param_count = param_count;
            entry.pc = pc;
            entry.ra = ra;
            entry.result = result;
            memset(entry.params, 0, sizeof(entry.params));
            memcpy(entry.params, params, param_count < 16 ? param_count : 16);
            strncpy(entry.command_name, command_name(cmd), 15);
            entry.command_name[15] = '\0';
            commands.push_back(entry);
        }
    }

    void log_event(uint32_t event_id, uint32_t class_id, uint32_t spec,
                   int flags, const char* action, int test_result = -1) {
        if ((int)events.size() < MAX_EVENTS) {
            CdromEventLog entry;
            entry.instruction_count = 0; // Set by caller
            entry.event_id = event_id;
            entry.class_id = class_id;
            entry.spec = spec;
            entry.flags = flags;
            entry.action = action;
            entry.test_result = test_result;
            events.push_back(entry);
        }
    }

    void dump(FILE* f) const {
        fprintf(f, "\n=== CD-ROM Command Trace ===\n");
        fprintf(f, "Total commands: %d, Errors: %d, Setloc errors: %d\n",
                total_commands, total_errors, setloc_errors);
        fprintf(f, "Getstat spam count: %d, Last progress LBA: %u\n\n",
                getstat_spam_count, last_progress_lba);

        fprintf(f, "Commands (last %d):\n", (int)commands.size());
        for (const auto& c : commands) {
            fprintf(f, "  [%7llu] PC=0x%08X RA=0x%08X %-10s (0x%02X) params=%d",
                    (unsigned long long)c.instruction_count, c.pc, c.ra,
                    c.command_name, c.command, c.param_count);
            if (c.param_count > 0) {
                fprintf(f, " [");
                for (int i = 0; i < c.param_count && i < 16; i++) {
                    fprintf(f, "%02X%s", c.params[i], i < c.param_count - 1 ? " " : "");
                }
                fprintf(f, "]");
            }
            if (c.result != 0) fprintf(f, " ERROR=%d", c.result);
            fprintf(f, "\n");
        }

        if (!events.empty()) {
            fprintf(f, "\nEvents (last %d):\n", (int)events.size());
            for (const auto& e : events) {
                fprintf(f, "  [%7llu] evt=0x%08X class=0x%08X spec=0x%08X flags=%d %s",
                        (unsigned long long)e.instruction_count, e.event_id,
                        e.class_id, e.spec, e.flags, e.action);
                if (e.test_result >= 0) fprintf(f, " result=%d", e.test_result);
                fprintf(f, "\n");
            }
        }

        // Pattern analysis
        fprintf(f, "\nPattern Analysis:\n");
        if (setloc_errors > 0) {
            fprintf(f, "  WARNING: %d Setloc parameter errors -- FIFO not cleared between commands\n",
                    setloc_errors);
        }
        if (getstat_spam_count > 0) {
            fprintf(f, "  WARNING: Getstat spam detected (%d repeats) -- CD-ROM may be stuck\n",
                    getstat_spam_count);
        }
        if (total_commands > 0 && last_progress_lba == 0) {
            fprintf(f, "  WARNING: No LBA progress detected -- CD-ROM may not be reading\n");
        }
    }

    void dump_json(FILE* f) const {
        fprintf(f, "\"cdrom_trace\": {\n");
        fprintf(f, "  \"total_commands\": %d,\n", total_commands);
        fprintf(f, "  \"total_errors\": %d,\n", total_errors);
        fprintf(f, "  \"setloc_errors\": %d,\n", setloc_errors);
        fprintf(f, "  \"getstat_spam_count\": %d,\n", getstat_spam_count);
        fprintf(f, "  \"last_progress_lba\": %u,\n", last_progress_lba);
        fprintf(f, "  \"commands\": [\n");
        for (size_t i = 0; i < commands.size(); i++) {
            const auto& c = commands[i];
            fprintf(f, "    {\"instr\": %llu, \"pc\": \"%08X\", \"ra\": \"%08X\", "
                       "\"cmd\": \"%s\", \"cmd_byte\": %d, \"params\": %d, \"result\": %d}%s\n",
                    (unsigned long long)c.instruction_count, c.pc, c.ra,
                    c.command_name, c.command, c.param_count, c.result,
                    i < commands.size() - 1 ? "," : "");
        }
        fprintf(f, "  ]\n");
        fprintf(f, "}\n");
    }

    // Section 5.2: Error breakpoint — call after detecting a CD-ROM error
    void fire_error_breakpoint(uint8_t cmd, const uint8_t* params, int param_count,
                                uint32_t pc, uint32_t ra) {
        if (!error_breakpoint_enabled || error_breakpoint_fired) return;
        error_breakpoint_fired = true;
        breakpoint_pc = pc;
        breakpoint_ra = ra;
        breakpoint_cmd = cmd;
        breakpoint_param_count = param_count;
        memset(breakpoint_params, 0, sizeof(breakpoint_params));
        if (params && param_count > 0) {
            memcpy(breakpoint_params, params, param_count < 16 ? param_count : 16);
        }
        strncpy(breakpoint_cmd_name, command_name(cmd), 15);
        breakpoint_cmd_name[15] = 0;

        fprintf(stderr, "\n=== CD-ROM ERROR BREAKPOINT FIRED ===\n");
        fprintf(stderr, "Command: %s (0x%02X) at PC=0x%08X RA=0x%08X\n",
                breakpoint_cmd_name, cmd, pc, ra);
        fprintf(stderr, "Parameters: %d [", param_count);
        for (int i = 0; i < param_count && i < 16; i++) {
            fprintf(stderr, "%02X%s", params[i], i < param_count - 1 ? " " : "");
        }
        fprintf(stderr, "]\n");

        // Dump last 10 commands for context
        fprintf(stderr, "\nLast 10 CD-ROM commands:\n");
        size_t start = commands.size() > 10 ? commands.size() - 10 : 0;
        for (size_t i = start; i < commands.size(); i++) {
            const auto& c = commands[i];
            fprintf(stderr, "  [%7llu] PC=0x%08X %-10s (0x%02X) params=%d",
                    (unsigned long long)c.instruction_count, c.pc,
                    c.command_name, c.command, c.param_count);
            if (c.result != 0) fprintf(stderr, " ERROR=%d", c.result);
            fprintf(stderr, "\n");
        }
        fprintf(stderr, "=== END BREAKPOINT ===\n\n");
    }

    void enable_error_breakpoint() {
        error_breakpoint_enabled = true;
        error_breakpoint_fired = false;
    }

    void dump_breakpoint_json(FILE* f) const {
        fprintf(f, "  \"cdrom_breakpoint\": {\n");
        fprintf(f, "    \"enabled\": %s,\n", error_breakpoint_enabled ? "true" : "false");
        fprintf(f, "    \"fired\": %s,\n", error_breakpoint_fired ? "true" : "false");
        if (error_breakpoint_fired) {
            fprintf(f, "    \"pc\": \"0x%08X\",\n", breakpoint_pc);
            fprintf(f, "    \"ra\": \"0x%08X\",\n", breakpoint_ra);
            fprintf(f, "    \"cmd\": \"%s\",\n", breakpoint_cmd_name);
            fprintf(f, "    \"cmd_byte\": %d,\n", breakpoint_cmd);
            fprintf(f, "    \"param_count\": %d,\n", breakpoint_param_count);
            fprintf(f, "    \"params\": [");
            for (int i = 0; i < breakpoint_param_count && i < 16; i++) {
                fprintf(f, "%d%s", breakpoint_params[i], i < breakpoint_param_count - 1 ? "," : "");
            }
            fprintf(f, "]\n");
        } else {
            fprintf(f, "    \"pc\": null,\n");
            fprintf(f, "    \"cmd\": null\n");
        }
        fprintf(f, "  },\n");
    }
};
