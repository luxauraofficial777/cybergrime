#pragma once
#include <cstdint>
#include <cstring>
#include <vector>
#include <string>
#include <unordered_map>
#include <functional>
#include <memory>
#include "psx_binary_ops.h"

// ============================================================
// Frankenstein Driver Framework
//
// Treats PSX EXEs as fully programmable bootloaders, not black
// boxes to patch. We hold the decompiled source for both DW7
// and DQ4 EXEs. We can rewrite the execution flow from scratch.
//
// The EXE is a driver. The HBD is the payload. We control both.
// ============================================================

// ===== MIPS Register Names =====
enum MipsReg : uint8_t {
    R0=0, AT=1, V0=2, V1=3,
    A0=4, A1=5, A2=6, A3=7,
    T0=8, T1=9, T2=10, T3=11, T4=12, T5=13, T6=14, T7=15,
    S0=16, S1=17, S2=18, S3=19, S4=20, S5=21, S6=22, S7=23,
    T8=24, T9=25, K0=26, K1=27,
    GP=28, SP=29, FP=30, RA=31
};

// ===== MIPS Instruction Encoding (extended from psx_binary_ops.h) =====
// The constexpr encoders in psx_binary_ops.h are for one-off patches.
// This emitter builds entire code sequences with labels and branches.

struct MipsInstr {
    uint32_t word;

    // Primary constructors
    static MipsInstr nop() { return {0x00000000}; }
    static MipsInstr jr(MipsReg rs) { return {0x00000008 | ((uint32_t)rs << 21)}; }
    static MipsInstr jalr(MipsReg rd, MipsReg rs) { return {0x00000009 | ((uint32_t)rs << 21) | ((uint32_t)rd << 11)}; }
    static MipsInstr jal(uint32_t target) { return {0x0C000000 | ((target >> 2) & 0x03FFFFFF)}; }
    static MipsInstr j(uint32_t target) { return {0x08000000 | ((target >> 2) & 0x03FFFFFF)}; }
    static MipsInstr lui(MipsReg rt, uint16_t imm) { return {0x3C000000 | ((uint32_t)rt << 16) | imm}; }
    static MipsInstr addiu(MipsReg rt, MipsReg rs, uint16_t imm) { return {0x24000000 | ((uint32_t)rs << 21) | ((uint32_t)rt << 16) | imm}; }
    static MipsInstr addu(MipsReg rd, MipsReg rs, MipsReg rt) { return {0x00000021 | ((uint32_t)rs << 21) | ((uint32_t)rt << 16) | ((uint32_t)rd << 11)}; }
    static MipsInstr or_(MipsReg rd, MipsReg rs, MipsReg rt) { return {0x00000025 | ((uint32_t)rs << 21) | ((uint32_t)rt << 16) | ((uint32_t)rd << 11)}; }
    static MipsInstr and_(MipsReg rd, MipsReg rs, MipsReg rt) { return {0x00000024 | ((uint32_t)rs << 21) | ((uint32_t)rt << 16) | ((uint32_t)rd << 11)}; }
    static MipsInstr sll(MipsReg rd, MipsReg rt, uint8_t sa) { return {0x00000000 | ((uint32_t)rt << 16) | ((uint32_t)rd << 11) | ((uint32_t)sa << 6)}; }
    static MipsInstr srl(MipsReg rd, MipsReg rt, uint8_t sa) { return {0x00000002 | ((uint32_t)rt << 16) | ((uint32_t)rd << 11) | ((uint32_t)sa << 6)}; }
    static MipsInstr sra(MipsReg rd, MipsReg rt, uint8_t sa) { return {0x00000003 | ((uint32_t)rt << 16) | ((uint32_t)rd << 11) | ((uint32_t)sa << 6)}; }
    static MipsInstr sltu(MipsReg rd, MipsReg rs, MipsReg rt) { return {0x0000002B | ((uint32_t)rs << 21) | ((uint32_t)rt << 16) | ((uint32_t)rd << 11)}; }
    static MipsInstr sltiu(MipsReg rt, MipsReg rs, uint16_t imm) { return {0x2C000000 | ((uint32_t)rs << 21) | ((uint32_t)rt << 16) | imm}; }
    static MipsInstr lw(MipsReg rt, uint16_t off, MipsReg base) { return {0x8C000000 | ((uint32_t)base << 21) | ((uint32_t)rt << 16) | off}; }
    static MipsInstr sw(MipsReg rt, uint16_t off, MipsReg base) { return {0xAC000000 | ((uint32_t)base << 21) | ((uint32_t)rt << 16) | off}; }
    static MipsInstr lbu(MipsReg rt, uint16_t off, MipsReg base) { return {0x90000000 | ((uint32_t)base << 21) | ((uint32_t)rt << 16) | off}; }
    static MipsInstr sb(MipsReg rt, uint16_t off, MipsReg base) { return {0xA0000000 | ((uint32_t)base << 21) | ((uint32_t)rt << 16) | off}; }
    static MipsInstr lh(MipsReg rt, uint16_t off, MipsReg base) { return {0x84000000 | ((uint32_t)base << 21) | ((uint32_t)rt << 16) | off}; }
    static MipsInstr sh(MipsReg rt, uint16_t off, MipsReg base) { return {0xA4000000 | ((uint32_t)base << 21) | ((uint32_t)rt << 16) | off}; }
    static MipsInstr mfc0(MipsReg rt, uint8_t rd) { return {0x40000000 | ((uint32_t)rt << 16) | ((uint32_t)rd << 11)}; }
    static MipsInstr mtc0(MipsReg rt, uint8_t rd) { return {0x40800000 | ((uint32_t)rt << 16) | ((uint32_t)rd << 11)}; }
    static MipsInstr rfe() { return {0x42000010}; }

    // Branch with placeholder offset — resolved by MipsEmitter
    enum BranchType { BEQ, BNE, BLEZ, BGTZ, BLTZ, BGEZ };
    struct Branch {
        BranchType type;
        MipsReg rs, rt;
        std::string target_label;
    };

    // LI (load immediate) — expands to lui+addiu for 32-bit values
    static std::vector<MipsInstr> li32(MipsReg rt, uint32_t val) {
        uint16_t lo = val & 0xFFFF;
        uint16_t hi = (val >> 16) & 0xFFFF;
        if (hi == 0 && lo < 0x8000) {
            return {addiu(rt, R0, lo)};
        }
        if (lo >= 0x8000) hi++;  // sign extension compensation
        return {lui(rt, hi), addiu(rt, rt, lo)};
    }

    // LA (load address) — same as li32 but semantically distinct
    static std::vector<MipsInstr> la(MipsReg rt, uint32_t addr) {
        return li32(rt, addr);
    }
};

// ===== Label for branch resolution =====
struct Label {
    std::string name;
    uint32_t offset;  // byte offset in code buffer, 0xFFFFFFFF = unresolved
};

// ===== MipsEmitter: Build MIPS code sequences with labels =====
class MipsEmitter {
    std::vector<uint8_t> code;
    std::vector<Label> labels;
    std::vector<std::pair<uint32_t, std::string>> pending_branches;  // offset, label

public:
    MipsEmitter() {}

    void clear() { code.clear(); labels.clear(); pending_branches.clear(); }
    uint32_t size() const { return (uint32_t)code.size(); }
    const uint8_t* data() const { return code.data(); }

    // Place a label at the current position
    void label(const std::string& name) {
        labels.push_back({name, (uint32_t)code.size()});
    }

    // Get the absolute RAM address of a label (given the base RAM address)
    uint32_t label_addr(const std::string& name, uint32_t base_ram) const {
        for (auto& l : labels) {
            if (l.name == name) return base_ram + l.offset;
        }
        return 0;
    }

    // Emit a single instruction
    void emit(MipsInstr instr) {
        uint32_t w = instr.word;
        code.push_back(w & 0xFF);
        code.push_back((w >> 8) & 0xFF);
        code.push_back((w >> 16) & 0xFF);
        code.push_back((w >> 24) & 0xFF);
    }

    // Emit multiple instructions
    void emit(const std::vector<MipsInstr>& instrs) {
        for (auto& i : instrs) emit(i);
    }

    // Emit a branch with a label target (resolved at finalize)
    void emit_branch(MipsInstr::BranchType type, MipsReg rs, MipsReg rt, const std::string& target) {
        emit_branch(type, rs, rt, target, 0);
    }
    // Overload for single-register branches (BLEZ, BGTZ, BLTZ, BGEZ)
    void emit_branch(MipsInstr::BranchType type, MipsReg rs, const std::string& target) {
        emit_branch(type, rs, R0, target, 0);
    }

private:
    void emit_branch(MipsInstr::BranchType type, MipsReg rs, MipsReg rt, const std::string& target, int) {
        uint32_t op;
        switch (type) {
            case MipsInstr::BEQ:  op = 0x10000000; break;
            case MipsInstr::BNE:  op = 0x14000000; break;
            case MipsInstr::BLEZ: op = 0x18000000; break;
            case MipsInstr::BGTZ: op = 0x1C000000; break;
            case MipsInstr::BLTZ: op = 0x04000000; break;
            case MipsInstr::BGEZ: op = 0x04010000; break;
            default: op = 0x10000000; break;
        }
        uint32_t w = op | ((uint32_t)rs << 21) | ((uint32_t)rt << 16);
        pending_branches.push_back({(uint32_t)code.size(), target});
        code.push_back(w & 0xFF);
        code.push_back((w >> 8) & 0xFF);
        code.push_back((w >> 16) & 0xFF);
        code.push_back((w >> 24) & 0xFF);
    }

public:
    // Emit a JAL to a known absolute address
    void emit_jal(uint32_t target) {
        emit(MipsInstr::jal(target));
    }

    // Emit a function prologue
    void prologue(uint32_t frame_size) {
        // addiu sp, sp, -frame_size
        emit(MipsInstr::addiu(SP, SP, (uint16_t)(-(int16_t)frame_size)));
        // sw ra, frame_size-4(sp)
        emit(MipsInstr::sw(RA, (uint16_t)(frame_size - 4), SP));
    }

    // Emit a function epilogue
    void epilogue(uint32_t frame_size) {
        // lw ra, frame_size-4(sp)
        emit(MipsInstr::lw(RA, (uint16_t)(frame_size - 4), SP));
        // addiu sp, sp, frame_size
        emit(MipsInstr::addiu(SP, SP, (uint16_t)frame_size));
        // jr ra
        emit(MipsInstr::jr(RA));
        // nop (delay slot)
        emit(MipsInstr::nop());
    }

    // Emit a return with value
    void ret_value(MipsReg val) {
        // move v0, val
        emit(MipsInstr::or_(V0, val, R0));
        epilogue(0);  // no frame — just jr ra; nop
    }

    // Emit a CD-ROM BIOS call wrapper
    // PSX BIOS calls use jal to 0xA0/0xB0/0xC0 region functions
    void emit_bios_call(uint8_t table, uint8_t func_num, MipsReg arg_reg = A0) {
        // The BIOS functions are at fixed addresses:
        // A0 table: 0xA0 + func_num*4 (but in practice, jal to known wrappers)
        // B0 table: 0xB0 + func_num*4
        // C0 table: 0xC0 + func_num*4
        // For our custom driver, we call through the game's existing wrappers
        // or through direct syscall emulation
        uint32_t target = ((uint32_t)table << 24) | ((uint32_t)func_num << 2);
        emit_jal(target);
        emit(MipsInstr::nop());  // delay slot
    }

    // Resolve all pending branches and finalize
    void finalize(uint32_t base_ram) {
        for (auto& pb : pending_branches) {
            // Find label
            uint32_t target_offset = 0xFFFFFFFF;
            for (auto& l : labels) {
                if (l.name == pb.second) {
                    target_offset = l.offset;
                    break;
                }
            }
            if (target_offset == 0xFFFFFFFF) continue;

            // Compute branch offset in instructions
            int32_t branch_off = (int32_t)(target_offset - pb.first - 4) / 4;
            uint16_t imm = (uint16_t)(int16_t)branch_off;

            // Patch the branch instruction
            uint32_t w = rd32(&code[pb.first]);
            w = (w & 0xFFFF0000) | imm;
            wr32(&code[pb.first], w);
        }
        pending_branches.clear();
    }

private:
    static inline uint32_t rd32(const uint8_t* p) {
        return (uint32_t)p[0] | ((uint32_t)p[1]<<8) | ((uint32_t)p[2]<<16) | ((uint32_t)p[3]<<24);
    }
    static inline void wr32(uint8_t* p, uint32_t v) {
        p[0]=v&0xFF; p[1]=(v>>8)&0xFF; p[2]=(v>>16)&0xFF; p[3]=(v>>24)&0xFF;
    }
};

// ===== Function Extractor: Pull raw MIPS from existing EXEs =====
// Extracts function bodies from decompiled EXEs by file offset,
// so we can reuse proven code from DW7 or DQ4 without rewriting it.
class FunctionExtractor {
public:
    struct ExtractedFunc {
        uint32_t ram_addr;       // RAM address where this function lives
        uint32_t file_offset;    // Offset in source EXE file
        uint32_t size;           // Size in bytes
        std::vector<uint8_t> code;
        std::string name;
    };

    // Load an EXE for extraction
    bool load(const uint8_t* exe_data, uint32_t exe_size);

    // Extract a function by RAM address (scans for function prologue/epilogue)
    ExtractedFunc extract_by_ram(uint32_t ram_addr, uint32_t max_size = 4096);

    // Extract a function by file offset
    ExtractedFunc extract_by_offset(uint32_t file_offset, uint32_t size);

    // Extract a range of functions
    std::vector<ExtractedFunc> extract_range(uint32_t start_ram, uint32_t end_ram);

    // Get the EXE's load address
    uint32_t load_address() const { return load_addr; }

    // Get the EXE's PC0 (entry point)
    uint32_t pc0() const { return pc0_val; }

    // Get the EXE's text size
    uint32_t text_size() const { return text_sz; }

private:
    std::vector<uint8_t> data;
    uint32_t load_addr = 0;
    uint32_t pc0_val = 0;
    uint32_t text_sz = 0;

    // Detect function end by scanning for jr $ra + nop pattern
    uint32_t find_func_end(uint32_t start_offset, uint32_t max_size);
};

// ===== Driver Spec: Defines what the custom EXE does =====
// This is the "play god" interface. You specify the boot sequence,
// HBD parameters, block type handlers, and disc check behavior.
// The ExeBuilder emits a complete PS-X EXE from this spec.

struct BlockTypeHandler {
    uint16_t type_id;           // DQ4 block type (23, 24, 25, 27, 32, 46, etc.)
    enum HandlerMode {
        NATIVE_DQ4,             // Use DQ4's own handler (extracted from DQ4 EXE)
        NATIVE_DW7,             // Use DW7's handler (for DW7-compatible types)
        REENCODED,              // Data pre-converted at build time, use DW7 handler
        CUSTOM_SHIM,            // Custom MIPS shim that translates at runtime
        SKIP                    // Skip this block type entirely
    } mode;
    uint32_t handler_ram;       // RAM address of handler function (0 = auto-locate)
    std::string handler_name;   // Name for logging
};

struct DiscCheckSpec {
    enum Mode {
        FULL_BYPASS,            // No disc checks at all — custom driver doesn't check
        PATCH_EXISTING,         // Patch existing DW7 disc check (surgical 10-11 patches)
        CDROM_LIE_LAYER,        // Intercept all CD-ROM calls, return fabricated identity
        DQ4_NATIVE              // Use DQ4's own disc check (patched to accept our disc)
    } mode = FULL_BYPASS;

    // For CDROM_LIE_LAYER: the RAM address of the CD-ROM dispatch to intercept
    uint32_t cdrom_dispatch_ram = 0x80097814;

    // Disc identity to report (for lie layer)
    char disc_id[32] = "SLUS-01206";  // DW7 US disc 1
};

struct HbdMountSpec {
    uint32_t hbd_lba;           // Sector where HBD data starts on disc
    uint32_t hbd_size;          // HBD data size in bytes (0 = auto-detect)
    uint32_t exe_lba;           // Sector where EXE is written on disc

    // Block type handler table
    std::vector<BlockTypeHandler> block_handlers;

    // Whether to use DQ4 per-block trees or hybrid global tree
    enum TreeMode {
        DQ4_PER_BLOCK,          // Use DQ4's per-block trees (no re-encoding needed)
        HYBRID_GLOBAL,          // Use hybrid global tree (requires re-encoding)
        DW7_NATIVE              // Use DW7's original tree (for DW7 HBD only)
    } tree_mode = DQ4_PER_BLOCK;

    // Hybrid tree data (if tree_mode == HYBRID_GLOBAL)
    const uint8_t* hybrid_tree = nullptr;
    uint32_t hybrid_tree_size = 0;
    uint32_t hybrid_tree_target_ram = 0;  // Where to place tree in RAM
};

struct BootSequenceSpec {
    uint32_t load_address;      // EXE load address (default 0x80017F00)
    uint32_t entry_point;       // PC0 (0 = auto: first instruction of emitted code)

    // Boot phases (executed in order)
    enum Phase {
        PHASE_BSS_CLEAR,        // Clear BSS region
        PHASE_CDROM_INIT,       // Initialize CD-ROM hardware
        PHASE_HBD_MOUNT,        // Mount HBD at specified LBA
        PHASE_GPU_INIT,         // Initialize GPU
        PHASE_EVENT_LOOP,       // Enter main event loop
        PHASE_DISC_CHECK,       // Perform disc validation
        PHADE_FMV_LOAD,         // Load/play FMV
        PHASE_CUSTOM            // Custom code injection point
    };

    struct BootStep {
        Phase phase;
        uint32_t custom_ram;    // RAM address for custom code (0 = auto-allocate)
        std::string name;
    };

    std::vector<BootStep> steps;

    // BSS clear parameters
    uint32_t bss_start = 0;
    uint32_t bss_end = 0;

    // Whether to copy DW7's main event loop or write a custom one
    bool use_dw7_event_loop = true;
    uint32_t event_loop_ram = 0;  // 0 = use DW7's original
};

struct DriverSpec {
    BootSequenceSpec boot;
    HbdMountSpec hbd;
    DiscCheckSpec disc_check;

    // Source EXEs for function extraction
    const uint8_t* dw7_exe = nullptr;
    uint32_t dw7_exe_size = 0;
    const uint8_t* dq4_exe = nullptr;
    uint32_t dq4_exe_size = 0;

    // Output EXE parameters
    uint32_t max_exe_size;      // Maximum EXE size in bytes (before HBD overlap)

    // FMV handling
    enum FmvMode {
        FMV_DW7_NATIVE,         // Play DW7 FMV from DW7 disc sectors
        FMV_DQ4_NATIVE,         // Play DQ4 FMV from DQ4 disc sectors
        FMV_SKIP,               // Skip FMV playback entirely
        FMV_REDIRECT            // Redirect FMV reads to alternative sectors
    } fmv_mode = FMV_DW7_NATIVE;
    uint32_t fmv_redirect_lba = 0;  // For FMV_REDIRECT
};

// ===== Payload Remapper: DQ4 HBD → DW7 disc layout =====
// Handles the physical data reallocation: placing DQ4 HBD data
// at the right sectors on the hybrid disc, updating ISO directory
// entries, and managing LBA pointer remapping.

class PayloadRemapper {
public:
    struct RemapEntry {
        uint32_t dw7_sector;    // Original DW7 HBD sector
        uint32_t dq4_sector;    // DQ4 HBD sector (in dq4_heart_v17.bin)
        uint32_t new_disc_sector;  // Where it goes on the hybrid disc
        uint32_t size;          // Size in bytes
    };

    struct RemapConfig {
        uint32_t exe_lba;           // Where EXE starts on disc (typically 24)
        uint32_t exe_size;          // EXE size in bytes
        uint32_t hbd_lba;           // Where HBD starts on disc
        uint32_t hbd_size;          // HBD size in bytes
        uint32_t dq4_hbd_source_lba;  // Where DQ4 HBD starts in dq4_heart_v17.bin (362)
        uint32_t dw7_fmv_lba;       // Where DW7 FMV starts (146621)
        bool preserve_dw7_fmv;      // Keep DW7 FMV/audio at original sectors
    };

    // Compute the disc layout from a config
    static std::vector<RemapEntry> compute_layout(const RemapConfig& cfg,
                                                   const std::vector<FolderMapping>& folder_map);

    // Build the ABS/REL pointer tables for the remapped layout
    struct PointerTables {
        std::vector<uint8_t> abs_table;  // 6000 entries × 8 bytes
        std::vector<uint8_t> rel_table;  // 6000 entries × 8 bytes
        uint32_t abs_matched;
        uint32_t abs_delta;
        uint32_t rel_matched;
    };

    static PointerTables build_pointer_tables(const std::vector<RemapEntry>& entries,
                                              const std::vector<FolderMapping>& folder_map,
                                              int32_t lba_delta);

    // Validate that the remapped layout fits on the disc
    static bool validate_layout(const RemapConfig& cfg,
                                const std::vector<RemapEntry>& entries,
                                std::string& error_msg);
};

// ===== Custom Driver Code Generator =====
// Generates MIPS code for custom boot sequences, block type handlers,
// disc check bypasses, and CD-ROM lie layers.

class DriverCodegen {
public:
    // Generate a complete disc-check bypass (no-op stub that always returns 1)
    // This replaces the entire disc_check function with:
    //   li $v0, 1
    //   jr $ra
    //   nop
    static std::vector<uint8_t> gen_disc_check_bypass();

    // Generate a CD-ROM lie layer trampoline
    // Intercepts CD-ROM BIOS calls and returns fabricated disc identity
    // for GetLocP/GetLocL/Getstat commands, passes through everything else
    static std::vector<uint8_t> gen_cdrom_lie_layer(uint32_t install_ram);

    // Generate a BSS clear routine
    // Zeros memory from bss_start to bss_end in 4-byte increments
    static std::vector<uint8_t> gen_bss_clear(uint32_t bss_start, uint32_t bss_end);

    // Generate an HBD mount routine
    // Calls CD-ROM BIOS to read HBD sectors into RAM at the specified address
    static std::vector<uint8_t> gen_hbd_mount(uint32_t hbd_lba, uint32_t hbd_ram,
                                               uint32_t hbd_sectors);

    // Generate a block type dispatch trampoline
    // Patches the DW7 block header reader to redirect DQ4 types to custom handlers
    static std::vector<uint8_t> gen_block_type_trampoline(
        uint32_t install_ram,
        uint32_t original_dispatch_ram,
        const std::vector<BlockTypeHandler>& handlers);

    // Generate a FMV skip stub
    // Replaces FMV playback calls with immediate return
    static std::vector<uint8_t> gen_fmv_skip();

    // Generate a thread-entry preservation stub
    // Copies the thread entry point to a safe location before BSS clear
    // and restores it after
    static std::vector<uint8_t> gen_thread_preserve(uint32_t thread_entry_ram,
                                                     uint32_t safe_ram,
                                                     uint32_t thread_entry_size);

    // Generate a complete boot sequence from a DriverSpec
    // Returns the full MIPS code for the custom EXE body
    static std::vector<uint8_t> gen_boot_sequence(const DriverSpec& spec,
                                                   uint32_t& out_entry_point);

    // Generate glue code to call an extracted function
    // Sets up arguments and calls the function at the given RAM address
    static std::vector<uint8_t> gen_call_extracted(uint32_t func_ram,
                                                    uint32_t arg1 = 0,
                                                    uint32_t arg2 = 0,
                                                    uint32_t arg3 = 0,
                                                    uint32_t arg4 = 0);
};

// ===== EXE Builder: Assembles a complete PS-X EXE from components =====
class ExeBuilder {
public:
    struct ExeComponent {
        enum Type {
            RAW_CODE,           // Raw MIPS bytes at a fixed offset
            EXTRACTED_FUNC,     // Function extracted from DW7/DQ4 EXE
            EMITTED_CODE,       // Code generated by MipsEmitter
            DATA_PAYLOAD,       // Data (e.g., hybrid Huffman tree)
            ZERO_FILL           // Padding/alignment
        } type;
        uint32_t target_ram;    // Where in RAM this component goes
        std::vector<uint8_t> data;
        std::string name;
    };

    // PS-X EXE header structure (80 bytes, then data)
    struct PsxExeHeader {
        char magic[8];          // "PS-X EXE"
        uint8_t pad0[8];
        uint32_t pc;            // Initial PC
        uint32_t gp;            // Global pointer
        uint32_t addr;          // Load address
        uint32_t t_size;        // Text size (data following header)
        uint32_t m_size;        // Memory fill size (BSS)
        uint32_t m_addr;        // Memory fill address
        uint32_t s_size;        // S (stack) size
        uint32_t s_addr;        // S (stack) address
        uint8_t pad1[0x800 - 0x30];
    };
    static_assert(sizeof(PsxExeHeader) == 0x800, "PS-X EXE header must be 2048 bytes");

    // Add a component to the EXE
    void add_component(ExeComponent::Type type, uint32_t target_ram,
                       const std::vector<uint8_t>& data, const std::string& name);

    // Add the DW7 EXE as a base (extract specific functions from it)
    void set_dw7_base(const uint8_t* exe, uint32_t size);

    // Add the DQ4 EXE for function extraction
    void set_dq4_source(const uint8_t* exe, uint32_t size);

    // Build the final EXE
    // Returns the complete EXE binary (header + code + data)
    std::vector<uint8_t> build(uint32_t load_addr, uint32_t entry_pc,
                                uint32_t gp_val = 0, uint32_t sp_val = 0x801FFFF0);

    // Validate the built EXE
    bool validate(const std::vector<uint8_t>& exe, std::string& error) const;

    // Get the total size of all components
    uint32_t total_component_size() const;

private:
    std::vector<ExeComponent> components;
    std::vector<uint8_t> dw7_base;
    std::vector<uint8_t> dq4_source;
    uint32_t dw7_load_addr = 0;
    uint32_t dq4_load_addr = 0;

    // Sort components by target_ram and assemble
    std::vector<uint8_t> assemble(uint32_t load_addr);
};

// ===== HBD Processor: Data-side transformation pipeline =====
// Wraps the existing HbdReencoder from psx_binary_ops.h to provide
// a clean interface for the driver framework.
// Performs:
//   A) Block header conversion (hts→1366, treeEnd=0, textEnd=0)
//   B) Sub-block field swap (flags↔type_id for types 32/39/40/42/46)
//   C) LBA relocation (adjust internal sector refs by delta)

class HbdProcessor {
public:
    struct ProcessResult {
        uint32_t folders_parsed;
        uint32_t files_parsed;
        uint32_t blocks_processed;
        uint32_t blocks_converted;
        uint32_t blocks_reencoded;
        uint32_t blocks_reencode_failed;
        uint32_t subblock_swaps;
        uint32_t lba_patches;
        uint32_t errors;
        bool success;
    };

    // Load raw DQ4 HBD data + optional hybrid tree
    bool load(const uint8_t* hbd_data, uint32_t hbd_size,
              const uint8_t* hybrid_tree = nullptr, uint32_t tree_size = 0);

    // Run full transformation pipeline (A+B+C)
    // source_lba: where DQ4 HBD starts on original disc (362)
    // target_lba: where HBD will be placed on hybrid disc (355)
    ProcessResult process(uint32_t source_lba, uint32_t target_lba);

    // Phase 1 only: field swap (B) + LBA relocation (C), no Huffman re-encoding
    // Safer — no size changes, no repacking
    ProcessResult process_phase1(uint32_t source_lba, uint32_t target_lba);

    // Validate processed HBD (check no DQ4 types remain)
    bool validate(uint32_t source_lba);

    // Get processed HBD data
    const uint8_t* data() const;
    uint32_t size() const;

private:
    std::vector<uint8_t> hbd_data;
    const uint8_t* hybrid_tree = nullptr;
    uint32_t tree_sz = 0;
    bool processed = false;
};

// ===== Disc Assembler: ISO image construction =====
// Writes the custom EXE and processed HBD data to a disc image,
// updates ISO 9660 directory entries, PVD, and runs EDC/ECC.

class DiscAssembler {
public:
    struct DiscConfig {
        uint32_t exe_lba;           // Sector for EXE (typically 24)
        uint32_t hbd_lba;           // Sector for HBD (typically 355)
        uint32_t sector_size;       // 2352 for MODE2
        uint32_t user_size;         // 2048 for Form1
        uint32_t data_offset;       // 24 for MODE2 Form1
        const char* disc_id;        // Volume ID (e.g., "SLUS_012.06")
    };

    // Assemble a complete disc from components
    // 1. Copy base DW7 disc to output
    // 2. Write custom EXE at exe_lba
    // 3. Write processed HBD at hbd_lba
    // 4. Update ISO directory + PVD
    // 5. Run EDC/ECC regeneration
    static bool assemble(
        const char* base_disc_path,
        const char* output_bin_path,
        const char* output_cue_path,
        const uint8_t* exe_data, uint32_t exe_size,
        const uint8_t* hbd_data, uint32_t hbd_size,
        const DiscConfig& cfg,
        const char* edcre_path);

    // Write CUE sheet
    static bool write_cue(const char* cue_path, const char* bin_name);

    // Extend disc image to required size
    static bool extend_disc(const char* path, uint64_t needed_size);
};

// ===== Frankenstein Driver Builder: Top-level orchestrator =====
// Combines all the above into a single "play god" interface.
// Give it a DriverSpec, get back a complete hybrid disc.

class FrankensteinDriverBuilder {
public:
    struct BuildResult {
        // EXE build results
        uint32_t exe_size;
        uint32_t exe_entry_pc;
        uint32_t exe_components;
        uint32_t custom_code_size;
        uint32_t extracted_functions;
        std::vector<std::string> component_names;

        // HBD remap results
        uint32_t hbd_lba;
        uint32_t hbd_sectors;
        uint32_t remap_entries;
        uint32_t abs_matched;
        uint32_t abs_delta;
        uint32_t rel_matched;

        // Disc assembly results
        uint32_t disc_size;
        uint32_t edc_ecc_sectors;

        // Validation
        bool exe_valid;
        bool hbd_valid;
        bool disc_valid;
        std::string validation_errors;

        int success;
    };

    // Build a complete hybrid disc from a DriverSpec
    static BuildResult build(const DriverSpec& spec,
                              const char* dw7_disc_path,
                              const char* dq4_hbd_disc_path,
                              const char* output_bin_path,
                              const char* output_cue_path,
                              const char* edcre_path);

    // Build only the custom EXE (no disc assembly)
    static std::vector<uint8_t> build_exe(const DriverSpec& spec,
                                           BuildResult* result = nullptr);

    // Validate a DriverSpec before building
    static bool validate_spec(const DriverSpec& spec, std::string& error);

    // Generate a default DriverSpec for the current Frankenstein approach
    // (DW7 bootloader + DQ4 HBD with per-block trees, full disc bypass)
    static DriverSpec default_frankenstein_spec();

    // Generate a DriverSpec for the DQ4 native approach
    // (DQ4 bootloader + DQ4 HBD natively, minimal patches)
    static DriverSpec default_dq4_native_spec();

    // Generate a DriverSpec for the cleanroom approach
    // (Custom bootloader from extracted functions, no disc checks)
    static DriverSpec default_cleanroom_spec();
};

// ===== Block Type Registry =====
// Maps DQ4 block types to their handler strategies.
// This is the key to eliminating the HBD re-encoding blocker.

namespace BlockTypes {
    // DQ4 native block types
    constexpr uint16_t DQ4_TEXT_23   = 23;
    constexpr uint16_t DQ4_TEXT_24   = 24;
    constexpr uint16_t DQ4_TEXT_25   = 25;
    constexpr uint16_t DQ4_TEXT_27   = 27;
    constexpr uint16_t DQ4_SCRIPT_32 = 32;
    constexpr uint16_t DQ4_MSG_46    = 46;
    constexpr uint16_t DQ4_SUB_39    = 39;
    constexpr uint16_t DQ4_SUB_40    = 40;
    constexpr uint16_t DQ4_SUB_42    = 42;

    // DW7 native block types
    constexpr uint16_t DW7_TEXT_19   = 19;
    constexpr uint16_t DW7_TEXT_40   = 40;
    constexpr uint16_t DW7_TEXT_42   = 42;

    // DQ4→DW7 type mapping (for re-encoding approach)
    inline uint16_t dq4_to_dw7(uint16_t dq4_type) {
        switch (dq4_type) {
            case DQ4_TEXT_23:
            case DQ4_TEXT_24:
            case DQ4_TEXT_25:
            case DQ4_TEXT_27:   return DW7_TEXT_19;  // All text → DW7 type 19
            case DQ4_SCRIPT_32: return DW7_TEXT_40;  // Script → DW7 type 40
            case DQ4_MSG_46:    return DW7_TEXT_42;  // Message → DW7 type 42
            default:            return dq4_type;     // Unknown — pass through
        }
    }

    // Check if a type needs re-encoding or can be handled natively
    inline bool needs_reencode(uint16_t type) {
        return type == DQ4_TEXT_23 || type == DQ4_TEXT_24 ||
               type == DQ4_TEXT_25 || type == DQ4_TEXT_27 ||
               type == DQ4_SCRIPT_32 || type == DQ4_MSG_46;
    }

    // Check if a type has sub-block field swap requirements
    inline bool needs_field_swap(uint16_t type) {
        return type == DQ4_SUB_39 || type == DQ4_SUB_40 ||
               type == DQ4_SUB_42 || type == DQ4_SCRIPT_32 ||
               type == DQ4_MSG_46;
    }

    // Get the handler strategy for a DQ4 block type
    inline BlockTypeHandler::HandlerMode recommended_strategy(uint16_t type) {
        // Types 32 and 46 are the known blockers — use native DQ4 handler
        if (type == DQ4_SCRIPT_32 || type == DQ4_MSG_46)
            return BlockTypeHandler::NATIVE_DQ4;
        // Text types can be re-encoded or handled natively
        if (type == DQ4_TEXT_23 || type == DQ4_TEXT_24 ||
            type == DQ4_TEXT_25 || type == DQ4_TEXT_27)
            return BlockTypeHandler::NATIVE_DQ4;  // Prefer native — no re-encoding
        // Sub-block types need field swap
        if (needs_field_swap(type))
            return BlockTypeHandler::CUSTOM_SHIM;
        // Unknown types — skip
        return BlockTypeHandler::SKIP;
    }
}

// ===== Known RAM Addresses (from decompilation) =====
// These are the critical function addresses in the DW7 and DQ4 EXEs.
// The driver builder uses these to extract and rewire functions.

namespace KnownAddresses {
    // DW7 EXE (SLUSP012.06, load at 0x80017F00)
    namespace DW7 {
        constexpr uint32_t LOAD_ADDR     = 0x80017F00;
        constexpr uint32_t PC0           = 0x8008E284;
        constexpr uint32_t HBD_MOUNT     = 0x8002EC2C;  // HBD mount routine entry
        constexpr uint32_t BLOCK_READER  = 0x80042A04;  // Block header reader
        constexpr uint32_t FILE_TABLE    = 0x8002F238;  // File table lookup
        constexpr uint32_t FILE_SEARCH   = 0x80075430;  // File entry search
        constexpr uint32_t HUFFMAN       = 0x80073670;  // Huffman decompressor
        constexpr uint32_t CDROM_WRAPPER = 0x80097814;  // CD-ROM BIOS wrapper
        constexpr uint32_t DISC_CHECK    = 0x80078FF4;  // Disc check function
        constexpr uint32_t DISC_CHANGE   = 0x800506CC;  // Disc change handler
        constexpr uint32_t POST_VERIFY   = 0x8008AEF4;  // Post-disc-change verify
        constexpr uint32_t CDROM_DISPATCH= 0x80098898;  // CD-ROM command dispatch
        constexpr uint32_t EVENT_LOOP    = 0x8009885C;  // Main event loop
        constexpr uint32_t BSS_CLEAR     = 0x800BC668;  // BSS clear start
        constexpr uint32_t BSS_END       = 0x800F4980;  // BSS clear end
        constexpr uint32_t THREAD_ENTRY  = 0x800D9E80;  // Thread entry point
        constexpr uint32_t HUFF_TREE     = 0x800EF1C8;  // Original DW7 Huffman tree
        constexpr uint32_t DISC_NUM_VAR  = 0x800E3D90;  // Disc number variable
        constexpr uint32_t FMV_LBA       = 146621;      // First FMV sector
        constexpr uint32_t ABS_TABLE     = 0x80017F00 + 0x4184 - 0x800;  // ABS pointer table
        constexpr uint32_t REL_TABLE     = 0x80017F00 + 0x511C - 0x800;  // REL pointer table
    }

    // DQ4 EXE (SLPM_869.16, load at 0x80017F00)
    namespace DQ4 {
        constexpr uint32_t LOAD_ADDR     = 0x80017F00;
        constexpr uint32_t PC0           = 0x800918F4;
        constexpr uint32_t HBD_MOUNT     = 0x8002EC7C;  // HBD mount (FUN_0002ec7c)
        constexpr uint32_t BLOCK_READER  = 0x80042AA0;  // Block header reader (FUN_00042aa0)
        constexpr uint32_t HUFFMAN       = 0x8007366C;  // Huffman decompressor (FUN_0007366c)
        constexpr uint32_t DISC_CHECK    = 0x80078F24;  // Disc check (FUN_00078f24)
        constexpr uint32_t DISC_VERIFY   = 0x80078FE4;  // Disc verify (FUN_00078fe4)
        constexpr uint32_t CDROM_INIT    = 0x8008E284;  // CD-ROM init (same offset as DW7 PC0)
        constexpr uint32_t BSS_CLEAR     = 0x800BC668;  // BSS clear start (same as DW7)
        constexpr uint32_t BSS_END       = 0x800F4980;  // BSS clear end (same as DW7)
        constexpr uint32_t HBD_LBA       = 362;         // DQ4 HBD starts at sector 362
    }

    // RAM regions safe for custom code injection
    namespace Safe {
        constexpr uint32_t HIGH_RAM_START    = 0x80100000;
        constexpr uint32_t HIGH_RAM_END      = 0x80102000;  // 8KB safe zone
        constexpr uint32_t TRAMPOLINE_BASE   = 0x80101000;
        constexpr uint32_t CDROM_LIE_RAM     = 0x80101200;
        constexpr uint32_t BLOCK_HANDLER_RAM = 0x80101400;
        constexpr uint32_t BOOT_CODE_RAM     = 0x80101800;
    }
}
