#include "CybergrimeUI.h"
#include "UIBackdropLoader.h"
#include <windows.h>
#include <gdiplus.h>
#include <cmath>
#include <cstdlib>

// ============================================================================
// EXTERNS — DX11 compose surface helpers (defined in LUX_CORE_X64.cpp)
// ============================================================================
extern "C" void DX11_ComposeFillRect(int, int, int, int, uint8_t, uint8_t, uint8_t, uint8_t);
extern "C" void DX11_ComposeDrawLine(int, int, int, int, uint8_t, uint8_t, uint8_t, uint8_t);
extern "C" void DX11_ComposeDrawRect(int, int, int, int, uint8_t, uint8_t, uint8_t, uint8_t, int);
extern "C" HDC DX11_GetComposeDC();

// ============================================================================
// STATIC STATE
// ============================================================================
static uint32_t s_cgFrameCounter = 0;
static float    s_cgTimeAccum    = 0.0f;

// Deterministic glitch RNG — no heap, no std::mt19937
static uint32_t s_cgRngState = 0xACE1u;

// Lightweight tween system — max 16 concurrent, no heap
static constexpr int CG_MAX_TWEENS = 16;
static CG_Tween s_cgTweens[CG_MAX_TWEENS];
static int      s_cgTweenCount = 0;
static inline uint32_t CG_Rand() {
    s_cgRngState ^= s_cgRngState << 13;
    s_cgRngState ^= s_cgRngState >> 17;
    s_cgRngState ^= s_cgRngState << 5;
    return s_cgRngState;
}
static inline uint32_t CG_RandRange(uint32_t max) {
    return CG_Rand() % max;
}
static inline float CG_RandF01() {
    return (float)(CG_Rand() & 0xFFFF) / 65535.0f;
}

// ============================================================================
// LIFECYCLE
// ============================================================================
void CybergrimeUI_Init() {
    LARGE_INTEGER qpc;
    QueryPerformanceCounter(&qpc);
    s_cgRngState = static_cast<uint32_t>(qpc.LowPart) ^ 0xACE1u;
    s_cgFrameCounter = 0;
    s_cgTimeAccum = 0.0f;
}

void CybergrimeUI_Shutdown() {
    // Nothing owned
}

// ============================================================================
// VOLATILE COLOR — flickering cyan
// ============================================================================
void Cybergrime_GetFlickerCyan(uint8_t baseR, uint8_t baseG, uint8_t baseB,
                               uint8_t& outR, uint8_t& outG, uint8_t& outB,
                               float intensity) {
    // Multi-frequency interference: 3.7Hz primary, 11.3Hz harmonic, 0.4Hz drift
    float t = static_cast<float>(s_cgFrameCounter);
    float flicker = 0.65f
                  + 0.20f * sinf(t * 0.062f)      // ~3.7 Hz @ 60fps
                  + 0.10f * sinf(t * 0.189f)      // ~11.3 Hz harmonic
                  + 0.05f * sinf(t * 0.007f + 1.3f); // slow drift

    // Random micro-dropouts (signal loss)
    if (CG_RandF01() < 0.02f * intensity) flicker *= 0.4f;
    if (CG_RandF01() < 0.005f * intensity) flicker *= 0.1f;

    flicker = fmaxf(0.15f, fminf(1.0f, flicker));
    float dim = 1.0f - (intensity * 0.3f); // inactive panels are dimmer

    outR = static_cast<uint8_t>(baseR * flicker * dim);
    outG = static_cast<uint8_t>(baseG * flicker * dim);
    outB = static_cast<uint8_t>(baseB * flicker * dim);
}

// ============================================================================
// GRIME PANEL — replaces sharp industrial panels
// ============================================================================
void Cybergrime_DrawGrimePanel(int x, int y, int w, int h, bool isActive,
                               const char* title) {
    uint8_t br, bg, bb;
    Cybergrime_GetFlickerCyan(0, 240, 255, br, bg, bb, isActive ? 1.0f : 0.5f);
    uint8_t dimR = static_cast<uint8_t>(br * 0.35f);
    uint8_t dimG = static_cast<uint8_t>(bg * 0.35f);
    uint8_t dimB = static_cast<uint8_t>(bb * 0.35f);

    // 1. Obsidian background — draw authored textured backdrops if loaded
    HDC hdc = DX11_GetComposeDC();
    Gdiplus::Bitmap* backdrop = nullptr;
    if (w >= 1500 && h >= 800)      backdrop = UIBackdrop::Get("panel_main_overlay");
    else if (w >= 600 && h >= 600)  backdrop = UIBackdrop::Get("panel_desc_right");
    else if (w >= 500 && h >= 600)  backdrop = UIBackdrop::Get("panel_modules_center");
    else if (w >= 300 && h >= 600)  backdrop = UIBackdrop::Get("panel_stats_left");
    else if (w >= 1300 && h >= 700) backdrop = UIBackdrop::Get("panel_blitz_list");

    if (hdc && backdrop) {
        Gdiplus::Graphics gfx(hdc);
        gfx.SetInterpolationMode(Gdiplus::InterpolationModeNearestNeighbor);
        gfx.DrawImage(backdrop, x, y, w, h);
    } else {
        uint8_t obsAlpha = 160 + static_cast<uint8_t>(CG_RandRange(20));
        DX11_ComposeFillRect(x, y, w, h, 0, 8, 16, obsAlpha);
    }

    // 2. Grime border — not a perfect rectangle; jittered segments
    int segLen = 20 + static_cast<int>(CG_RandRange(8));
    int jitter = static_cast<int>(CG_RandRange(3)) - 1; // -1..1

    // Top edge — segmented with micro-gaps
    for (int cx = x + 2; cx < x + w - 2; cx += segLen + 2) {
        int len = (cx + segLen > x + w - 2) ? (x + w - 2 - cx) : segLen;
        if (len > 2) {
            DX11_ComposeDrawLine(cx, y + 2 + jitter, cx + len, y + 2 + jitter, br, bg, bb,
                                 180 + static_cast<uint8_t>(CG_RandRange(40)));
        }
    }
    // Bottom edge
    for (int cx = x + 2; cx < x + w - 2; cx += segLen + 2) {
        int len = (cx + segLen > x + w - 2) ? (x + w - 2 - cx) : segLen;
        if (len > 2) {
            DX11_ComposeDrawLine(cx, y + h - 2 + jitter, cx + len, y + h - 2 + jitter, br, bg, bb,
                                 180 + static_cast<uint8_t>(CG_RandRange(40)));
        }
    }
    // Left edge
    for (int cy = y + 2; cy < y + h - 2; cy += segLen + 2) {
        int len = (cy + segLen > y + h - 2) ? (y + h - 2 - cy) : segLen;
        if (len > 2) {
            DX11_ComposeDrawLine(x + 2 + jitter, cy, x + 2 + jitter, cy + len, br, bg, bb,
                                 180 + static_cast<uint8_t>(CG_RandRange(40)));
        }
    }
    // Right edge
    for (int cy = y + 2; cy < y + h - 2; cy += segLen + 2) {
        int len = (cy + segLen > y + h - 2) ? (y + h - 2 - cy) : segLen;
        if (len > 2) {
            DX11_ComposeDrawLine(x + w - 2 + jitter, cy, x + w - 2 + jitter, cy + len, br, bg, bb,
                                 180 + static_cast<uint8_t>(CG_RandRange(40)));
        }
    }

    // 3. Corroded corner brackets (shorter, more erratic)
    int off = 4;
    int seg = 8 + static_cast<int>(CG_RandRange(6));
    DX11_ComposeDrawLine(x + off, y + off,         x + off + seg, y + off,         br, bg, bb, 200);
    DX11_ComposeDrawLine(x + off, y + off,         x + off,       y + off + seg,   br, bg, bb, 200);
    DX11_ComposeDrawLine(x + w - off, y + off,     x + w - off - seg, y + off,     br, bg, bb, 200);
    DX11_ComposeDrawLine(x + w - off, y + off,     x + w - off,   y + off + seg,   br, bg, bb, 200);
    DX11_ComposeDrawLine(x + off, y + h - off,     x + off + seg, y + h - off,     br, bg, bb, 200);
    DX11_ComposeDrawLine(x + off, y + h - off,     x + off,       y + h - off - seg, br, bg, bb, 200);
    DX11_ComposeDrawLine(x + w - off, y + h - off, x + w - off - seg, y + h - off, br, bg, bb, 200);
    DX11_ComposeDrawLine(x + w - off, y + h - off, x + w - off,   y + h - off - seg, br, bg, bb, 200);

    // 4. Title bar — flickering, with chromatic split
    if (title) {
        int ty = y + off + 18;
        // Red channel shifted left
        DX11_ComposeDrawLine(x + off + seg - 1, ty, x + w - off - seg - 1, ty,
                             static_cast<uint8_t>(br * 0.6f), 0, 0, 100);
        // Cyan channel (normal)
        DX11_ComposeDrawLine(x + off + seg, ty, x + w - off - seg, ty,
                             0, bg, bb, 120 + static_cast<uint8_t>(CG_RandRange(40)));
        // Blue channel shifted right
        DX11_ComposeDrawLine(x + off + seg + 1, ty, x + w - off - seg + 1, ty,
                             0, 0, static_cast<uint8_t>(bb * 0.5f), 80);
    }
}

// ============================================================================
// SCANLINE OVERLAY — horizontal CRT raster lines
// ============================================================================
void Cybergrime_DrawScanlineOverlay(HDC hdc) {
    if (!hdc) return;
    Gdiplus::Graphics gfx(hdc);
    gfx.SetSmoothingMode(Gdiplus::SmoothingModeNone);

    // Every 3rd pixel row — variable opacity
    for (int y = 0; y < 900; y += 3) {
        uint8_t alpha = static_cast<uint8_t>(6 + CG_RandRange(10));
        Gdiplus::Pen pen(Gdiplus::Color(alpha, 0, 0, 0), 1.0f);
        gfx.DrawLine(&pen, 0, y, 1600, y);
    }
    // Occasional brighter scanline (CRT refresh artifact)
    if (CG_RandF01() < 0.15f) {
        int brightY = static_cast<int>(CG_RandRange(300)) * 3;
        Gdiplus::Pen pen(Gdiplus::Color(25, 0, 255, 240), 1.0f);
        gfx.DrawLine(&pen, 0, brightY, 1600, brightY);
    }
}

// ============================================================================
// CRT NOISE — sparse random pixel corruption
// ============================================================================
void Cybergrime_DrawCRTNoise(HDC hdc) {
    if (!hdc) return;
    Gdiplus::Graphics gfx(hdc);
    gfx.SetSmoothingMode(Gdiplus::SmoothingModeNone);

    // ~400 noise dots per frame
    for (int i = 0; i < 400; ++i) {
        int nx = static_cast<int>(CG_RandRange(1600));
        int ny = static_cast<int>(CG_RandRange(900));
        uint8_t a = static_cast<uint8_t>(20 + CG_RandRange(40));
        uint8_t c = static_cast<uint8_t>(180 + CG_RandRange(75));
        // Mix of cyan, white, and dead-pixel black
        int mode = CG_RandRange(10);
        Gdiplus::Color col;
        if (mode < 4) col = Gdiplus::Color(a, 0, c, c);       // cyan glitch
        else if (mode < 7) col = Gdiplus::Color(a, c, c, c); // white noise
        else col = Gdiplus::Color(a, 0, 0, 0);               // dead pixel

        Gdiplus::SolidBrush brush(col);
        gfx.FillRectangle(&brush, nx, ny, 1 + CG_RandRange(2), 1);
    }
}

// ============================================================================
// PHOSPHOR BURN — glow trail behind static text
// ============================================================================
void Cybergrime_DrawPhosphorText(HDC hdc, int x, int y, const char* text,
                                 uint8_t r, uint8_t g, uint8_t b,
                                 HFONT hFont) {
    if (!hdc || !text || !text[0]) return;
    Gdiplus::Graphics gfx(hdc);
    gfx.SetTextRenderingHint(Gdiplus::TextRenderingHintSingleBitPerPixelGridFit);

    // Measure for glow centering
    SIZE sz = {};
    HFONT old = (HFONT)SelectObject(hdc, hFont);
    GetTextExtentPoint32A(hdc, text, static_cast<int>(strlen(text)), &sz);
    SelectObject(hdc, old);

    // Glow layers — red-shifted trail (phosphor persistence)
    for (int i = 2; i >= 1; --i) {
        uint8_t ga = static_cast<uint8_t>(18 / i);
        Gdiplus::SolidBrush glow(Gdiplus::Color(ga, r, g, b));
        Gdiplus::PointF pt(static_cast<Gdiplus::REAL>(x + i), static_cast<Gdiplus::REAL>(y));
        wchar_t wtxt[128] = {};
        MultiByteToWideChar(CP_UTF8, 0, text, -1, wtxt, 128);
        Gdiplus::FontFamily ff(L"Segoe UI");
        int height = 16;
        if (hFont) {
            LOGFONTA lf = {};
            GetObjectA(hFont, sizeof(lf), &lf);
            height = abs(lf.lfHeight);
        }
        Gdiplus::Font font(&ff, static_cast<Gdiplus::REAL>(height), Gdiplus::FontStyleRegular, Gdiplus::UnitPixel);
        gfx.DrawString(wtxt, -1, &font, pt, &glow);
    }

    // Primary text — crisp but with slight bleed
    Gdiplus::SolidBrush main(Gdiplus::Color(255, r, g, b));
    Gdiplus::PointF pt(static_cast<Gdiplus::REAL>(x), static_cast<Gdiplus::REAL>(y));
    wchar_t wtxt[128] = {};
    MultiByteToWideChar(CP_UTF8, 0, text, -1, wtxt, 128);
    Gdiplus::FontFamily ff(L"Segoe UI");
    int height = 16;
    if (hFont) {
        LOGFONTA lf = {};
        GetObjectA(hFont, sizeof(lf), &lf);
        height = abs(lf.lfHeight);
    }
    Gdiplus::Font font(&ff, static_cast<Gdiplus::REAL>(height), Gdiplus::FontStyleRegular, Gdiplus::UnitPixel);
    gfx.DrawString(wtxt, -1, &font, pt, &main);
}

// ============================================================================
// GLITCH TEXT — for lists and indexes
// ============================================================================
void Cybergrime_DrawGlitchText(HDC hdc, int x, int y, const char* text,
                               uint8_t r, uint8_t g, uint8_t b,
                               HFONT hFont, int seed) {
    if (!hdc || !text || !text[0]) return;

    // Deterministic per-row glitch probability
    uint32_t rowRng = s_cgRngState ^ static_cast<uint32_t>(seed * 0x9E3779B9);
    float glitchChance = static_cast<float>(rowRng & 0xFF) / 255.0f;

    // 15% chance of some glitch artifact
    bool doGlitch = glitchChance < 0.15f;
    bool doDropout = glitchChance < 0.03f;
    bool doShift = (glitchChance > 0.08f && glitchChance < 0.12f);

    int dx = x;
    int dy = y;
    if (doShift) dx += (static_cast<int>(CG_RandRange(4)) - 2);

    Gdiplus::Graphics gfx(hdc);
    gfx.SetTextRenderingHint(Gdiplus::TextRenderingHintSingleBitPerPixelGridFit);

    // Chromatic split for glitched rows: red / cyan offset
    if (doGlitch && !doDropout) {
        wchar_t wtxt[256] = {};
        MultiByteToWideChar(CP_UTF8, 0, text, -1, wtxt, 256);
        Gdiplus::FontFamily ff(L"Segoe UI");
        int height = 16;
        if (hFont) {
            LOGFONTA lf = {};
            GetObjectA(hFont, sizeof(lf), &lf);
            height = abs(lf.lfHeight);
        }
        Gdiplus::Font font(&ff, static_cast<Gdiplus::REAL>(height), Gdiplus::FontStyleRegular, Gdiplus::UnitPixel);

        // Red channel offset left
        Gdiplus::SolidBrush red(Gdiplus::Color(140, r, 0, 0));
        gfx.DrawString(wtxt, -1, &font,
                       Gdiplus::PointF(static_cast<Gdiplus::REAL>(dx - 1), static_cast<Gdiplus::REAL>(dy)),
                       &red);
        // Cyan channel offset right
        Gdiplus::SolidBrush cyan(Gdiplus::Color(140, 0, g, b));
        gfx.DrawString(wtxt, -1, &font,
                       Gdiplus::PointF(static_cast<Gdiplus::REAL>(dx + 1), static_cast<Gdiplus::REAL>(dy)),
                       &cyan);
    }

    if (doDropout) {
        // 3% chance: text is replaced with noise fragments
        char frag[256];
        size_t len = strlen(text);
        if (len > 0) {
            size_t fragLen = (len > 4) ? (len - CG_RandRange(3)) : len;
            for (size_t i = 0; i < fragLen; ++i) {
                int mode = CG_RandRange(10);
                if (mode < 3) frag[i] = text[i];
                else if (mode < 6) frag[i] = '?';
                else if (mode < 8) frag[i] = static_cast<char>(0xB0 + CG_RandRange(8)); // block chars
                else frag[i] = ' ';
            }
            frag[fragLen] = '\0';
            Cybergrime_DrawPhosphorText(hdc, dx, dy, frag, r, g, b, hFont);
        }
    } else {
        // Normal render (with optional alpha flicker)
        uint8_t alpha = 255;
        if (doGlitch) alpha = 200 + static_cast<uint8_t>(CG_RandRange(55));
        Gdiplus::SolidBrush brush(Gdiplus::Color(alpha, r, g, b));
        Gdiplus::PointF pt(static_cast<Gdiplus::REAL>(dx), static_cast<Gdiplus::REAL>(dy));
        wchar_t wtxt[256] = {};
        MultiByteToWideChar(CP_UTF8, 0, text, -1, wtxt, 256);
        Gdiplus::FontFamily ff(L"Segoe UI");
        int height = 16;
        if (hFont) {
            LOGFONTA lf = {};
            GetObjectA(hFont, sizeof(lf), &lf);
            height = abs(lf.lfHeight);
        }
        Gdiplus::Font font(&ff, static_cast<Gdiplus::REAL>(height), Gdiplus::FontStyleRegular, Gdiplus::UnitPixel);
        gfx.DrawString(wtxt, -1, &font, pt, &brush);
    }
}

// ============================================================================
// CHROMATIC BORDER — red/blue edge shift
// ============================================================================
void Cybergrime_DrawChromaticBorder(HDC hdc, int x, int y, int w, int h,
                                    uint8_t r, uint8_t g, uint8_t b,
                                    int thickness) {
    if (!hdc) return;
    Gdiplus::Graphics gfx(hdc);
    gfx.SetSmoothingMode(Gdiplus::SmoothingModeNone);

    // Red channel nudged left by 1px
    Gdiplus::Pen redPen(Gdiplus::Color(120, r, 0, 0), static_cast<Gdiplus::REAL>(thickness));
    gfx.DrawRectangle(&redPen, x - 1, y, w, h);

    // Blue channel nudged right by 1px
    Gdiplus::Pen bluePen(Gdiplus::Color(100, 0, 0, b), static_cast<Gdiplus::REAL>(thickness));
    gfx.DrawRectangle(&bluePen, x + 1, y, w, h);

    // Primary cyan center
    Gdiplus::Pen mainPen(Gdiplus::Color(200, 0, g, b), static_cast<Gdiplus::REAL>(thickness));
    gfx.DrawRectangle(&mainPen, x, y, w, h);
}

// ============================================================================
// GLITCH SELECTOR — flickering selection rect with grime corners
// ============================================================================
void Cybergrime_DrawGlitchSelector(HDC hdc, int x, int y, int w, int h,
                                   uint8_t r, uint8_t g, uint8_t b) {
    if (!hdc) return;

    uint8_t alpha = 180 + static_cast<uint8_t>(CG_RandRange(60));
    uint8_t flicker = static_cast<uint8_t>(CG_RandRange(40));

    // Background pulse — flickering alpha
    DX11_ComposeFillRect(x, y, w, h,
                         static_cast<uint8_t>(r * 0.12f),
                         static_cast<uint8_t>(g * 0.15f + flicker),
                         static_cast<uint8_t>(b * 0.18f + flicker),
                         alpha / 3);

    // Jittered border — not a perfect rectangle
    int jx = static_cast<int>(CG_RandRange(3)) - 1;
    int jy = static_cast<int>(CG_RandRange(3)) - 1;

    // Chromatic split border
    Cybergrime_DrawChromaticBorder(hdc, x + jx, y + jy, w, h, r, g, b, 2);

    // Corner glitch ticks
    int tick = 4 + static_cast<int>(CG_RandRange(4));
    DX11_ComposeDrawLine(x, y, x + tick, y, r, g, b, 200);
    DX11_ComposeDrawLine(x, y, x, y + tick, r, g, b, 200);
    DX11_ComposeDrawLine(x + w - tick, y, x + w, y, r, g, b, 200);
    DX11_ComposeDrawLine(x + w, y, x + w, y + tick, r, g, b, 200);
    DX11_ComposeDrawLine(x, y + h, x + tick, y + h, r, g, b, 200);
    DX11_ComposeDrawLine(x, y + h - tick, x, y + h, r, g, b, 200);
    DX11_ComposeDrawLine(x + w - tick, y + h, x + w, y + h, r, g, b, 200);
    DX11_ComposeDrawLine(x + w, y + h - tick, x + w, y + h, r, g, b, 200);
}

// ============================================================================
// SUBTLE PANEL — cleaner border for interior views and focused contexts
// ============================================================================
void Cybergrime_DrawSubtlePanel(int x, int y, int w, int h, bool isActive,
                                const char* title) {
    uint8_t br, bg, bb;
    Cybergrime_GetFlickerCyan(0, 240, 255, br, bg, bb, isActive ? 1.0f : 0.5f);

    // 1. Obsidian background — slightly more opaque than GrimePanel
    uint8_t obsAlpha = 180 + static_cast<uint8_t>(CG_RandRange(12));
    DX11_ComposeFillRect(x, y, w, h, 0, 8, 16, obsAlpha);

    // 2. Solid 1px border (not segmented)
    int jitter = isActive ? (static_cast<int>(CG_RandRange(3)) - 1) : 0;
    DX11_ComposeDrawRect(x + 1 + jitter, y + 1 + jitter, w - 2, h - 2,
                         br, bg, bb,
                         160 + static_cast<uint8_t>(CG_RandRange(40)), 1);

    // 3. Title bar — only if title provided, no corner brackets
    if (title && isActive) {
        int ty = y + 8;
        DX11_ComposeDrawLine(x + 8, ty, x + w - 8, ty,
                             0, bg, bb,
                             120 + static_cast<uint8_t>(CG_RandRange(40)));
    }
}

// ============================================================================
// ACTION ROW — horizontal button with rounded feel
// ============================================================================
void Cybergrime_DrawActionRow(HDC hdc, int x, int y, int w, int h,
                              const char* label, bool isSelected,
                              const char* shortcutKey) {
    if (!hdc || !label) return;

    uint8_t br, bg, bb;
    Cybergrime_GetFlickerCyan(0, 240, 255, br, bg, bb, isSelected ? 1.0f : 0.5f);

    // Background fill — draw authored button background if available
    const char* btnName = isSelected ? "button_hover" : "button_default";
    Gdiplus::Bitmap* btnBg = UIBackdrop::Get(btnName);
    Gdiplus::Graphics gfx(hdc);
    if (btnBg) {
        gfx.SetInterpolationMode(Gdiplus::InterpolationModeNearestNeighbor);
        gfx.DrawImage(btnBg, x, y, w, h);
    } else {
        uint8_t alpha = isSelected ? 120 : 80;
        DX11_ComposeFillRect(x, y, w, h,
                             static_cast<uint8_t>(br * 0.12f),
                             static_cast<uint8_t>(bg * 0.14f),
                             static_cast<uint8_t>(bb * 0.16f),
                             alpha);
    }

    // Rounded rect border (simplified: rect with slightly inset corners)
    DX11_ComposeDrawRect(x, y, w, h, br, bg, bb,
                         isSelected ? 200 : 140, 1);

    // Label text
    gfx.SetTextRenderingHint(Gdiplus::TextRenderingHintSingleBitPerPixelGridFit);

    wchar_t wtxt[128] = {};
    MultiByteToWideChar(CP_UTF8, 0, label, -1, wtxt, 128);
    Gdiplus::FontFamily ff(L"Segoe UI");
    int height = 20;
    Gdiplus::Font font(&ff, static_cast<Gdiplus::REAL>(height), Gdiplus::FontStyleRegular, Gdiplus::UnitPixel);

    uint8_t tr = isSelected ? 255 : 200;
    uint8_t tg = isSelected ? 255 : 210;
    uint8_t tb = isSelected ? 200 : 230;
    Gdiplus::SolidBrush brush(Gdiplus::Color(255, tr, tg, tb));
    Gdiplus::PointF pt(static_cast<Gdiplus::REAL>(x + 16), static_cast<Gdiplus::REAL>(y + (h - height) / 2));
    gfx.DrawString(wtxt, -1, &font, pt, &brush);

    // Shortcut key (right-aligned)
    if (shortcutKey && shortcutKey[0]) {
        wchar_t wsc[16] = {};
        MultiByteToWideChar(CP_UTF8, 0, shortcutKey, -1, wsc, 16);
        Gdiplus::Font scFont(&ff, static_cast<Gdiplus::REAL>(14), Gdiplus::FontStyleRegular, Gdiplus::UnitPixel);
        Gdiplus::SolidBrush scBrush(Gdiplus::Color(160, 180, 200, 220));
        Gdiplus::PointF scPt(static_cast<Gdiplus::REAL>(x + w - 48), static_cast<Gdiplus::REAL>(y + (h - 14) / 2));
        gfx.DrawString(wsc, -1, &scFont, scPt, &scBrush);
    }
}

// ============================================================================
// TWEEN SYSTEM
// ============================================================================
void CG_TweenStart(float* target, float to, float duration) {
    if (!target || duration <= 0.0f) return;
    // Find inactive slot or oldest active
    int slot = -1;
    for (int i = 0; i < CG_MAX_TWEENS; ++i) {
        if (!s_cgTweens[i].active) { slot = i; break; }
    }
    if (slot < 0) {
        // Overwrite first slot if all busy
        slot = 0;
    }
    s_cgTweens[slot].target = target;
    s_cgTweens[slot].from = *target;
    s_cgTweens[slot].to = to;
    s_cgTweens[slot].duration = duration;
    s_cgTweens[slot].elapsed = 0.0f;
    s_cgTweens[slot].active = true;
    s_cgTweenCount++;
}

static float CG_EaseOut(float t) {
    // Ease-out cubic
    return 1.0f - (1.0f - t) * (1.0f - t) * (1.0f - t);
}

void CybergrimeUI_Tick(float dt) {
    ++s_cgFrameCounter;
    // Advance tweens
    for (int i = 0; i < CG_MAX_TWEENS; ++i) {
        CG_Tween& tw = s_cgTweens[i];
        if (!tw.active || !tw.target) continue;
        tw.elapsed += dt;
        float t = tw.elapsed / tw.duration;
        if (t >= 1.0f) {
            *tw.target = tw.to;
            tw.active = false;
            tw.target = nullptr;
            s_cgTweenCount--;
        } else {
            *tw.target = tw.from + (tw.to - tw.from) * CG_EaseOut(t);
        }
    }
}

void CybergrimeUI_Tick() {
    CybergrimeUI_Tick(0.0f);
}

// ============================================================================
// PHASE 2.4 — VRAM VIEWER & RAM HEATMAP
// ============================================================================

void Cybergrime_DrawVRAMViewer(const uint16_t* vram, int dstX, int dstY,
                                int scale, bool showGrid) {
    if (!vram || scale < 1) return;
    HDC hdc = DX11_GetComposeDC();
    if (!hdc) return;

    const int VRAM_W = 1024, VRAM_H = 512;

    // Render VRAM as scaled pixels using GDI+ Bitmap
    // Create a 1024x512 bitmap, fill it from VRAM, then draw scaled
    Gdiplus::Bitmap bmp(VRAM_W, VRAM_H, PixelFormat32bppARGB);
    for (int y = 0; y < VRAM_H; y++) {
        for (int x = 0; x < VRAM_W; x++) {
            uint16_t c = vram[y * VRAM_W + x];
            uint8_t r = (c & 0x1F) << 3;
            uint8_t g = ((c >> 5) & 0x1F) << 3;
            uint8_t b = ((c >> 10) & 0x1F) << 3;
            bmp.SetPixel(x, y, Gdiplus::Color(255, r, g, b));
        }
    }

    Gdiplus::Graphics g(hdc);
    g.SetInterpolationMode(Gdiplus::InterpolationModeNearestNeighbor);
    g.DrawImage(&bmp, dstX, dstY, VRAM_W * scale, VRAM_H * scale);

    // Draw texture-page grid (every 64px horizontal, 256px vertical)
    if (showGrid) {
        Gdiplus::Pen gridPen(Gdiplus::Color(80, 0, 240, 255), 1);
        // Vertical lines every 64 pixels
        for (int x = 64; x < VRAM_W; x += 64) {
            g.DrawLine(&gridPen, dstX + x * scale, dstY,
                       dstX + x * scale, dstY + VRAM_H * scale);
        }
        // Horizontal lines every 256 pixels
        for (int y = 256; y < VRAM_H; y += 256) {
            g.DrawLine(&gridPen, dstX, dstY + y * scale,
                       dstX + VRAM_W * scale, dstY + y * scale);
        }

        // Border
        Gdiplus::Pen borderPen(Gdiplus::Color(180, 0, 240, 255), 2);
        g.DrawRectangle(&borderPen, dstX, dstY, VRAM_W * scale, VRAM_H * scale);
    }
}

void Cybergrime_DrawRAMHeatmap(const uint8_t* ram,
                                const uint32_t* heatmap, int heatmapCount,
                                int dstX, int dstY,
                                int pageW, int pageH) {
    if (!heatmap || heatmapCount <= 0) return;
    HDC hdc = DX11_GetComposeDC();
    if (!hdc) return;

    // Find max access count for normalization
    uint32_t maxCount = 1;
    for (int i = 0; i < heatmapCount; i++) {
        if (heatmap[i] > maxCount) maxCount = heatmap[i];
    }

    Gdiplus::Graphics g(hdc);
    g.SetSmoothingMode(Gdiplus::SmoothingModeNone);

    // RAM is 2MB = 512 pages of 4KB
    // Layout: 32 columns x 16 rows = 512 pages
    const int COLS = 32;
    const int ROWS = (heatmapCount + COLS - 1) / COLS;

    // Draw background
    Gdiplus::SolidBrush bgBrush(Gdiplus::Color(255, 10, 10, 15));
    g.FillRectangle(&bgBrush, dstX - 2, dstY - 2,
                    COLS * pageW + 4, ROWS * pageH + 4);

    for (int i = 0; i < heatmapCount; i++) {
        int col = i % COLS;
        int row = i / COLS;
        int px = dstX + col * pageW;
        int py = dstY + row * pageH;

        // Determine color based on access frequency
        float ratio = (float)heatmap[i] / maxCount;
        uint8_t r, gC, b;

        if (ratio < 0.01f) {
            // Cold — dark blue
            r = 5; gC = 5; b = 20;
        } else if (ratio < 0.25f) {
            // Cool — blue to cyan
            r = 0; gC = (uint8_t)(ratio * 4 * 255); b = 128;
        } else if (ratio < 0.5f) {
            // Warm — cyan to green
            r = 0; gC = 255; b = (uint8_t)(128 - (ratio - 0.25f) * 4 * 128);
        } else if (ratio < 0.75f) {
            // Hot — green to yellow
            r = (uint8_t)((ratio - 0.5f) * 4 * 255); gC = 255; b = 0;
        } else {
            // Very hot — yellow to red
            r = 255; gC = (uint8_t)(255 - (ratio - 0.75f) * 4 * 255); b = 0;
        }

        // Special highlights for known regions
        uint32_t pageAddr = i * 0x1000;
        if (pageAddr >= 0x1F0000 && pageAddr < 0x1F8000) {
            // Hardware registers region — purple
            r = 180; gC = 0; b = 255;
        } else if (pageAddr >= 0x1F8000 && pageAddr < 0x1F9000) {
            // Scratchpad — orange
            r = 255; gC = 165; b = 0;
        } else if (pageAddr >= 0x1FF000 && pageAddr < 0x200000) {
            // Stack region — blue highlight
            r = 0; gC = 100; b = 255;
        }

        Gdiplus::SolidBrush cellBrush(Gdiplus::Color(255, r, gC, b));
        g.FillRectangle(&cellBrush, px, py, pageW - 1, pageH - 1);
    }

    // Draw grid lines
    Gdiplus::Pen gridPen(Gdiplus::Color(40, 0, 240, 255), 1);
    for (int col = 0; col <= COLS; col++) {
        g.DrawLine(&gridPen, dstX + col * pageW, dstY,
                   dstX + col * pageW, dstY + ROWS * pageH);
    }
    for (int row = 0; row <= ROWS; row++) {
        g.DrawLine(&gridPen, dstX, dstY + row * pageH,
                   dstX + COLS * pageW, dstY + row * pageH);
    }

    // Border
    Gdiplus::Pen borderPen(Gdiplus::Color(180, 0, 240, 255), 2);
    g.DrawRectangle(&borderPen, dstX - 1, dstY - 1,
                    COLS * pageW + 2, ROWS * pageH + 2);
}

