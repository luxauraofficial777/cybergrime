// ============================================================================
// LIMINAL LINK — VFS Sector Alignment Validator & Comparator
// ============================================================================
// Parses ISO9660 directories from two PSX disc images and compares:
//   1. File LBA alignment (must be sector-aligned, 2048-byte boundaries)
//   2. File size conformance
//   3. Sector gap analysis (overlapping or wasted sectors)
//   4. EXE hardcoded LBA pointer extraction and cross-reference
//   5. VFS index table structure comparison
//
// Outputs a JSON diff report that the Agent Harness can consume to
// identify exactly where the DW7 engine's VFS expectations diverge
// from the DQ4 asset tree.
//
// Usage:
//   vfs_compare.exe <dw7_base.bin> <dq4_injected.bin> [output.json]
// ============================================================================

#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <cstdint>
#include <vector>
#include <algorithm>

// ── Constants ────────────────────────────────────────────────────────────────
#define SECTOR_SIZE 2048
#define MAX_DIR_ENTRIES 256
#define MAX_NAME_LEN 64
#define MAX_EXE_SIZE (2 * 1024 * 1024)  // 2MB max EXE scan
#define MAX_LBA_REFS 4096

// ── Data Structures ──────────────────────────────────────────────────────────

struct IsoFileEntry {
    char    name[MAX_NAME_LEN];
    uint32_t lba;        // Logical Block Address (sector number)
    uint32_t size;       // File size in bytes
    uint32_t sectors;    // Number of sectors occupied
    uint32_t end_lba;    // lba + sectors - 1
    bool    is_dir;
    int     gap_after;   // Sectors gap before next file
};

struct LbaReference {
    uint32_t exe_offset;   // Offset within EXE where LBA value appears
    uint32_t lba_value;    // The LBA value found
    char     context[32];  // Disassembly context (LUI/ADDIU pair info)
    bool     in_dw7_tree;  // Does this LBA exist in DW7's directory?
    bool     in_dq4_tree;  // Does this LBA exist in DQ4's directory?
};

struct VfsDiffReport {
    // Per-disc directory listings
    std::vector<IsoFileEntry> dw7_files;
    std::vector<IsoFileEntry> dq4_files;

    // Files present in one but not the other
    std::vector<IsoFileEntry> only_dw7;
    std::vector<IsoFileEntry> only_dq4;

    // Files in both but with different LBA or size
    struct MismatchEntry {
        char name[MAX_NAME_LEN];
        uint32_t dw7_lba, dq4_lba;
        uint32_t dw7_size, dq4_size;
        bool lba_mismatch;
        bool size_mismatch;
        bool overlap;      // DQ4 file overlaps with a different DW7 file's sectors
    };
    std::vector<MismatchEntry> mismatches;

    // LBA references found in EXE
    std::vector<LbaReference> dw7_exe_refs;
    std::vector<LbaReference> dq4_exe_refs;

    // Alignment faults
    struct AlignmentFault {
        char    name[MAX_NAME_LEN];
        uint32_t lba;
        char    fault[128];
    };
    std::vector<AlignmentFault> faults;

    // Sector overlap map
    struct SectorOverlap {
        uint32_t start_lba;
        uint32_t end_lba;
        char dw7_file[MAX_NAME_LEN];
        char dq4_file[MAX_NAME_LEN];
    };
    std::vector<SectorOverlap> overlaps;
};

// ── ISO9660 Parser ───────────────────────────────────────────────────────────

// Detect sector format: 2048 (cooked) or 2352 (raw)
static int detect_sector_size(FILE* f) {
    // Check first 16 bytes for raw sector sync pattern
    uint8_t hdr[16];
    fseek(f, 0, SEEK_SET);
    if (fread(hdr, 1, 16, f) != 16) return 2048;
    // Raw Mode 1 sync: 00 FF*10 00
    if (hdr[0] == 0x00 && hdr[1] == 0xFF && hdr[2] == 0xFF &&
        hdr[3] == 0xFF && hdr[4] == 0xFF && hdr[5] == 0xFF &&
        hdr[6] == 0xFF && hdr[7] == 0xFF && hdr[8] == 0xFF &&
        hdr[9] == 0xFF && hdr[10] == 0xFF && hdr[11] == 0x00) {
        return 2352;
    }
    return 2048;
}

static int g_sector_size = 2352;  // detected per-file

static bool read_sector(FILE* f, uint32_t lba, uint8_t* buf) {
    long offset;
    if (g_sector_size == 2352) {
        // Raw Mode 1: 16-byte sync + 4-byte header + 2048 user data + 288 EDC/ECC
        offset = (long)lba * 2352 + 24;
    } else {
        offset = (long)lba * 2048;
    }
    if (fseek(f, offset, SEEK_SET) != 0) return false;
    return fread(buf, 1, 2048, f) == 2048;
}

static std::vector<IsoFileEntry> parse_iso_directory(const char* path) {
    std::vector<IsoFileEntry> entries;
    FILE* f = fopen(path, "rb");
    if (!f) {
        fprintf(stderr, "[VFS] Cannot open: %s\n", path);
        return entries;
    }

    // Detect sector format
    g_sector_size = detect_sector_size(f);
    printf("[VFS] Sector format: %d-byte (%s)\n", g_sector_size,
           g_sector_size == 2352 ? "raw" : "cooked");

    // Read PVD at LBA 16
    uint8_t pvd[SECTOR_SIZE];
    if (!read_sector(f, 16, pvd) || pvd[0] != 0x01) {
        fprintf(stderr, "[VFS] Invalid PVD in: %s\n", path);
        fclose(f);
        return entries;
    }

    // Root directory record at PVD offset 156
    uint8_t* root = pvd + 156;
    uint32_t root_lba = root[2] | (root[3] << 8) | (root[4] << 16) | (root[5] << 24);
    uint32_t root_size = root[10] | (root[11] << 8) | (root[12] << 16) | (root[13] << 24);
    uint32_t root_sectors = (root_size + SECTOR_SIZE - 1) / SECTOR_SIZE;

    // Read all root directory sectors
    uint8_t* dir_buf = new uint8_t[root_sectors * SECTOR_SIZE];
    for (uint32_t s = 0; s < root_sectors; s++) {
        if (!read_sector(f, root_lba + s, dir_buf + s * SECTOR_SIZE)) {
            delete[] dir_buf;
            fclose(f);
            return entries;
        }
    }

    // Parse directory records
    uint32_t pos = 0;
    while (pos < root_size && entries.size() < MAX_DIR_ENTRIES) {
        uint8_t rec_len = dir_buf[pos];
        if (rec_len == 0) {
            pos = (pos / SECTOR_SIZE + 1) * SECTOR_SIZE;
            continue;
        }

        uint32_t file_lba = dir_buf[pos+2] | (dir_buf[pos+3]<<8) |
                            (dir_buf[pos+4]<<16) | (dir_buf[pos+5]<<24);
        uint32_t file_size = dir_buf[pos+10] | (dir_buf[pos+11]<<8) |
                             (dir_buf[pos+12]<<16) | (dir_buf[pos+13]<<24);
        uint8_t flags = dir_buf[pos+25];
        uint8_t name_len = dir_buf[pos+32];
        bool is_dir = (flags & 0x02) != 0;

        // Skip . and ..
        if (name_len == 1 && (dir_buf[pos+33] == 0x00 || dir_buf[pos+33] == 0x01)) {
            pos += rec_len;
            continue;
        }

        IsoFileEntry entry;
        memset(&entry, 0, sizeof(entry));
        int nlen = name_len < MAX_NAME_LEN - 1 ? name_len : MAX_NAME_LEN - 1;
        memcpy(entry.name, dir_buf + pos + 33, nlen);
        entry.name[nlen] = 0;
        // Strip ;1 version suffix
        char* semi = strchr(entry.name, ';');
        if (semi) *semi = 0;

        entry.lba = file_lba;
        entry.size = file_size;
        entry.sectors = (file_size + SECTOR_SIZE - 1) / SECTOR_SIZE;
        entry.end_lba = file_lba + entry.sectors - 1;
        entry.is_dir = is_dir;
        entry.gap_after = 0;

        entries.push_back(entry);
        pos += rec_len;
    }

    // Calculate gaps between consecutive files
    std::sort(entries.begin(), entries.end(),
              [](const IsoFileEntry& a, const IsoFileEntry& b) { return a.lba < b.lba; });
    for (size_t i = 0; i + 1 < entries.size(); i++) {
        if (!entries[i].is_dir && !entries[i+1].is_dir) {
            uint32_t expected_next = entries[i].lba + entries[i].sectors;
            entries[i].gap_after = (int)entries[i+1].lba - (int)expected_next;
        }
    }

    delete[] dir_buf;
    fclose(f);
    return entries;
}

// ── EXE LBA Reference Scanner ────────────────────────────────────────────────

static std::vector<LbaReference> scan_exe_lba_refs(const char* disc_path) {
    std::vector<LbaReference> refs;
    FILE* f = fopen(disc_path, "rb");
    if (!f) return refs;

    // Detect sector format and set global
    g_sector_size = detect_sector_size(f);

    // Parse ISO directory to find the EXE
    auto entries = parse_iso_directory(disc_path);
    uint32_t exe_lba = 0, exe_size = 0;
    for (auto& e : entries) {
        if (strstr(e.name, ".EXE") || strstr(e.name, ".exe") ||
            strstr(e.name, "SLPS") || strstr(e.name, "SLPM") ||
            strstr(e.name, "SLUS") || strstr(e.name, "SLES")) {
            exe_lba = e.lba;
            exe_size = e.size;
            break;
        }
    }
    if (exe_lba == 0) {
        // Try SYSTEM.CNF approach
        for (auto& e : entries) {
            if (strstr(e.name, "SYSTEM.CNF") || strstr(e.name, "system.cnf")) {
                uint8_t cnf[SECTOR_SIZE];
                read_sector(f, e.lba, cnf);
                // Find BOOT= line
                char* boot = strstr((char*)cnf, "BOOT");
                if (boot) {
                    char* eq = strchr(boot, '=');
                    if (eq) {
                        eq++;
                        while (*eq == ' ' || *eq == '\\' || *eq == '/') eq++;
                        char clean[128] = {0};
                        int j = 0;
                        while (eq[j] && eq[j] != '\r' && eq[j] != '\n' && j < 127) {
                            clean[j] = eq[j]; j++;
                        }
                        // Strip cdrom: prefix
                        char* fname = clean;
                        if (strncmp(fname, "cdrom:", 6) == 0) fname += 6;
                        if (*fname == '\\' || *fname == '/') fname++;
                        char* semi = strchr(fname, ';');
                        if (semi) *semi = 0;
                        // Find this file in entries
                        for (auto& e2 : entries) {
                            if (_stricmp(e2.name, fname) == 0) {
                                exe_lba = e2.lba;
                                exe_size = e2.size;
                                break;
                            }
                        }
                    }
                }
                break;
            }
        }
    }

    if (exe_lba == 0 || exe_size == 0) {
        fclose(f);
        return refs;
    }

    // Read EXE into memory
    uint32_t read_size = exe_size < MAX_EXE_SIZE ? exe_size : MAX_EXE_SIZE;
    uint32_t exe_sectors = (read_size + SECTOR_SIZE - 1) / SECTOR_SIZE;
    uint8_t* exe = new uint8_t[exe_sectors * SECTOR_SIZE];
    for (uint32_t s = 0; s < exe_sectors; s++) {
        read_sector(f, exe_lba + s, exe + s * SECTOR_SIZE);
    }
    fclose(f);

    // Skip PSX EXE header (2048 bytes) — actual code starts at offset 2048
    uint32_t code_start = 2048;
    uint32_t code_end = read_size;

    // Scan for LUI/ADDIU pairs that construct 32-bit addresses
    // LUI rt, imm16     → opcode 0x3C000000 | (rt << 16) | imm16
    // ADDIU rt, rs, imm → opcode 0x24000000 | (rs << 21) | (rt << 16) | imm16
    // We look for LUI followed by ADDIU within 4 instructions

    for (uint32_t off = code_start; off + 8 <= code_end; off += 4) {
        uint32_t instr1 = exe[off] | (exe[off+1] << 8) | (exe[off+2] << 16) | (exe[off+3] << 24);
        uint32_t op1 = instr1 >> 26;

        if (op1 != 0x0F) continue;  // LUI

        uint16_t upper = instr1 & 0xFFFF;
        uint32_t rt1 = (instr1 >> 16) & 0x1F;

        // Look ahead up to 4 instructions for matching ADDIU
        for (int skip = 1; skip <= 4; skip++) {
            uint32_t off2 = off + skip * 4;
            if (off2 + 4 > code_end) break;
            uint32_t instr2 = exe[off2] | (exe[off2+1] << 8) |
                              (exe[off2+2] << 16) | (exe[off2+3] << 24);
            uint32_t op2 = instr2 >> 26;
            if (op2 != 0x09) continue;  // ADDIU

            uint32_t rt2 = (instr2 >> 16) & 0x1F;
            uint32_t rs2 = (instr2 >> 21) & 0x1F;
            if (rt2 != rt1 || rs2 != rt1) continue;

            uint16_t lower = instr2 & 0xFFFF;
            // Sign-extend lower
            int32_t lower_se = (lower & 0x8000) ? (lower | 0xFFFF0000) : lower;
            uint32_t full_addr = ((uint32_t)upper << 16) + (uint32_t)lower_se;

            // Check if this looks like an LBA (sector number, typically < 200000)
            // LBAs are small values, not RAM addresses (0x800xxxxx)
            if (full_addr < 200000 && full_addr > 0) {
                LbaReference ref;
                memset(&ref, 0, sizeof(ref));
                ref.exe_offset = off - code_start;
                ref.lba_value = full_addr;
                snprintf(ref.context, sizeof(ref), "LUI 0x%04X + ADDIU 0x%04X (r%u)",
                         upper, lower, rt1);
                refs.push_back(ref);
            }
            break;
        }
    }

    // Also scan for raw 32-bit LE values that match known sector ranges
    // (sectors 20-400 are typical for PSX game data area)
    for (uint32_t off = code_start; off + 4 <= code_end; off += 4) {
        uint32_t val = exe[off] | (exe[off+1] << 8) | (exe[off+2] << 16) | (exe[off+3] << 24);
        if (val >= 20 && val <= 400) {
            // Check it's not part of a LUI/ADDIU we already found
            bool dup = false;
            for (auto& r : refs) {
                if (r.exe_offset == off - code_start) { dup = true; break; }
            }
            if (!dup) {
                LbaReference ref;
                memset(&ref, 0, sizeof(ref));
                ref.exe_offset = off - code_start;
                ref.lba_value = val;
                snprintf(ref.context, sizeof(ref), "raw32 LE at EXE+0x%X", off - code_start);
                refs.push_back(ref);
            }
        }
    }

    delete[] exe;
    return refs;
}

// ── Comparison Logic ─────────────────────────────────────────────────────────

static VfsDiffReport compare_vfs(const char* dw7_path, const char* dq4_path) {
    VfsDiffReport report;
    memset(&report, 0, sizeof(report));

    report.dw7_files = parse_iso_directory(dw7_path);
    report.dq4_files = parse_iso_directory(dq4_path);

    // Build lookup maps
    auto find_in = [](std::vector<IsoFileEntry>& list, const char* name) -> IsoFileEntry* {
        for (auto& e : list) {
            if (_stricmp(e.name, name) == 0) return &e;
        }
        return nullptr;
    };

    // Find files only in DW7
    for (auto& dw : report.dw7_files) {
        if (!find_in(report.dq4_files, dw.name)) {
            report.only_dw7.push_back(dw);
        }
    }

    // Find files only in DQ4
    for (auto& dq : report.dq4_files) {
        if (!find_in(report.dw7_files, dq.name)) {
            report.only_dq4.push_back(dq);
        }
    }

    // Find mismatches in shared files
    for (auto& dw : report.dw7_files) {
        IsoFileEntry* dq = find_in(report.dq4_files, dw.name);
        if (!dq) continue;

        if (dw.lba != dq->lba || dw.size != dq->size) {
            VfsDiffReport::MismatchEntry m;
            memset(&m, 0, sizeof(m));
            strncpy(m.name, dw.name, MAX_NAME_LEN - 1);
            m.dw7_lba = dw.lba;
            m.dq4_lba = dq->lba;
            m.dw7_size = dw.size;
            m.dq4_size = dq->size;
            m.lba_mismatch = (dw.lba != dq->lba);
            m.size_mismatch = (dw.size != dq->size);

            // Check for sector overlap: does the DQ4 file's sector range
            // overlap with a *different* DW7 file?
            for (auto& dw2 : report.dw7_files) {
                if (_stricmp(dw2.name, dq->name) == 0) continue;
                if (dq->lba >= dw2.lba && dq->lba <= dw2.end_lba) {
                    m.overlap = true;
                    break;
                }
                if (dq->end_lba >= dw2.lba && dq->end_lba <= dw2.end_lba) {
                    m.overlap = true;
                    break;
                }
            }
            report.mismatches.push_back(m);
        }
    }

    // Check alignment faults
    for (auto& e : report.dq4_files) {
        if (e.is_dir) continue;
        // LBA must be > 0 (sector-aligned by ISO9660 spec)
        if (e.lba == 0) {
            VfsDiffReport::AlignmentFault fault;
            memset(&fault, 0, sizeof(fault));
            strncpy(fault.name, e.name, MAX_NAME_LEN - 1);
            fault.lba = e.lba;
            snprintf(fault.fault, sizeof(fault), "LBA=0 (null sector pointer)");
            report.faults.push_back(fault);
        }
        // Check for negative gap (overlap with previous file)
        if (e.gap_after < 0) {
            VfsDiffReport::AlignmentFault fault;
            memset(&fault, 0, sizeof(fault));
            strncpy(fault.name, e.name, MAX_NAME_LEN - 1);
            fault.lba = e.lba;
            snprintf(fault.fault, sizeof(fault),
                     "Sector overlap: %d sectors into previous file", -e.gap_after);
            report.faults.push_back(fault);
        }
    }

    // Build sector overlap map
    for (auto& dq : report.dq4_files) {
        if (dq.is_dir) continue;
        for (auto& dw : report.dw7_files) {
            if (dw.is_dir) continue;
            if (_stricmp(dw.name, dq.name) == 0) continue;
            // Check sector range overlap
            if (dq.lba <= dw.end_lba && dq.end_lba >= dw.lba) {
                VfsDiffReport::SectorOverlap overlap;
                memset(&overlap, 0, sizeof(overlap));
                overlap.start_lba = (dq.lba > dw.lba) ? dq.lba : dw.lba;
                overlap.end_lba = (dq.end_lba < dw.end_lba) ? dq.end_lba : dw.end_lba;
                strncpy(overlap.dw7_file, dw.name, MAX_NAME_LEN - 1);
                strncpy(overlap.dq4_file, dq.name, MAX_NAME_LEN - 1);
                report.overlaps.push_back(overlap);
            }
        }
    }

    // Scan EXE LBA references
    printf("[VFS] Scanning DW7 EXE for hardcoded LBA references...\n");
    report.dw7_exe_refs = scan_exe_lba_refs(dw7_path);
    printf("[VFS] Found %zu LBA references in DW7 EXE\n", report.dw7_exe_refs.size());

    printf("[VFS] Scanning DQ4 EXE for hardcoded LBA references...\n");
    report.dq4_exe_refs = scan_exe_lba_refs(dq4_path);
    printf("[VFS] Found %zu LBA references in DQ4 EXE\n", report.dq4_exe_refs.size());

    // Cross-reference: check which EXE LBA refs exist in which directory tree
    auto cross_ref = [](std::vector<LbaReference>& refs,
                        std::vector<IsoFileEntry>& files) {
        for (auto& ref : refs) {
            for (auto& f : files) {
                if (ref.lba_value >= f.lba && ref.lba_value <= f.end_lba) {
                    // This LBA falls within a file's sector range
                    if (&files == &files) {
                        // Will be set by caller
                    }
                }
            }
        }
    };

    // Mark which refs are in which tree
    for (auto& ref : report.dw7_exe_refs) {
        for (auto& f : report.dw7_files) {
            if (ref.lba_value >= f.lba && ref.lba_value <= f.end_lba) {
                ref.in_dw7_tree = true;
                break;
            }
        }
        for (auto& f : report.dq4_files) {
            if (ref.lba_value >= f.lba && ref.lba_value <= f.end_lba) {
                ref.in_dq4_tree = true;
                break;
            }
        }
    }
    for (auto& ref : report.dq4_exe_refs) {
        for (auto& f : report.dw7_files) {
            if (ref.lba_value >= f.lba && ref.lba_value <= f.end_lba) {
                ref.in_dw7_tree = true;
                break;
            }
        }
        for (auto& f : report.dq4_files) {
            if (ref.lba_value >= f.lba && ref.lba_value <= f.end_lba) {
                ref.in_dq4_tree = true;
                break;
            }
        }
    }

    return report;
}

// ── JSON Output ──────────────────────────────────────────────────────────────

static void json_escape(const char* in, char* out, int outlen) {
    if (!in || !out || outlen <= 0) return;
    int j = 0;
    for (int i = 0; in[i] && j < outlen - 2; i++) {
        char c = in[i];
        if (c == '"' || c == '\\') { if (j < outlen-2) { out[j++] = '\\'; out[j++] = c; } }
        else if (c == '\n') { if (j < outlen-2) { out[j++] = '\\'; out[j++] = 'n'; } }
        else if (c == '\r') { if (j < outlen-2) { out[j++] = '\\'; out[j++] = 'r'; } }
        else if ((unsigned char)c < 0x20) { /* skip */ }
        else { out[j++] = c; }
    }
    out[j] = 0;
}

static void write_json(const char* path, VfsDiffReport& report) {
    FILE* f = fopen(path, "w");
    if (!f) {
        fprintf(stderr, "[VFS] Cannot write JSON: %s\n", path);
        return;
    }

    fprintf(f, "{\n");

    // ── DW7 Directory ────────────────────────────────────────────────────
    fprintf(f, "  \"dw7_directory\": [\n");
    for (size_t i = 0; i < report.dw7_files.size(); i++) {
        auto& e = report.dw7_files[i];
        char ename[128]; json_escape(e.name, ename, sizeof(ename));
        fprintf(f, "    {\"name\": \"%s\", \"lba\": %u, \"size\": %u, \"sectors\": %u, \"end_lba\": %u, \"is_dir\": %s, \"gap_after\": %d}%s\n",
                ename, e.lba, e.size, e.sectors, e.end_lba,
                e.is_dir ? "true" : "false", e.gap_after,
                (i < report.dw7_files.size() - 1) ? "," : "");
    }
    fprintf(f, "  ],\n");

    // ── DQ4 Directory ────────────────────────────────────────────────────
    fprintf(f, "  \"dq4_directory\": [\n");
    for (size_t i = 0; i < report.dq4_files.size(); i++) {
        auto& e = report.dq4_files[i];
        char ename[128]; json_escape(e.name, ename, sizeof(ename));
        fprintf(f, "    {\"name\": \"%s\", \"lba\": %u, \"size\": %u, \"sectors\": %u, \"end_lba\": %u, \"is_dir\": %s, \"gap_after\": %d}%s\n",
                ename, e.lba, e.size, e.sectors, e.end_lba,
                e.is_dir ? "true" : "false", e.gap_after,
                (i < report.dq4_files.size() - 1) ? "," : "");
    }
    fprintf(f, "  ],\n");

    // ── Files only in DW7 ────────────────────────────────────────────────
    fprintf(f, "  \"only_dw7\": [");
    for (size_t i = 0; i < report.only_dw7.size(); i++) {
        char ename[128]; json_escape(report.only_dw7[i].name, ename, sizeof(ename));
        fprintf(f, "%s\n    {\"name\": \"%s\", \"lba\": %u, \"size\": %u}",
                i == 0 ? "" : ",", ename, report.only_dw7[i].lba, report.only_dw7[i].size);
    }
    fprintf(f, "%s],\n", report.only_dw7.empty() ? "" : "\n  ");

    // ── Files only in DQ4 ────────────────────────────────────────────────
    fprintf(f, "  \"only_dq4\": [");
    for (size_t i = 0; i < report.only_dq4.size(); i++) {
        char ename[128]; json_escape(report.only_dq4[i].name, ename, sizeof(ename));
        fprintf(f, "%s\n    {\"name\": \"%s\", \"lba\": %u, \"size\": %u}",
                i == 0 ? "" : ",", ename, report.only_dq4[i].lba, report.only_dq4[i].size);
    }
    fprintf(f, "%s],\n", report.only_dq4.empty() ? "" : "\n  ");

    // ── Mismatches ───────────────────────────────────────────────────────
    fprintf(f, "  \"mismatches\": [\n");
    for (size_t i = 0; i < report.mismatches.size(); i++) {
        auto& m = report.mismatches[i];
        char ename[128]; json_escape(m.name, ename, sizeof(ename));
        fprintf(f, "    {\"name\": \"%s\", \"dw7_lba\": %u, \"dq4_lba\": %u, \"dw7_size\": %u, \"dq4_size\": %u, \"lba_mismatch\": %s, \"size_mismatch\": %s, \"overlap\": %s}%s\n",
                ename, m.dw7_lba, m.dq4_lba, m.dw7_size, m.dq4_size,
                m.lba_mismatch ? "true" : "false",
                m.size_mismatch ? "true" : "false",
                m.overlap ? "true" : "false",
                (i < report.mismatches.size() - 1) ? "," : "");
    }
    fprintf(f, "  ],\n");

    // ── Alignment Faults ─────────────────────────────────────────────────
    fprintf(f, "  \"alignment_faults\": [\n");
    for (size_t i = 0; i < report.faults.size(); i++) {
        auto& fault = report.faults[i];
        char ename[128], efault[256];
        json_escape(fault.name, ename, sizeof(ename));
        json_escape(fault.fault, efault, sizeof(efault));
        fprintf(f, "    {\"name\": \"%s\", \"lba\": %u, \"fault\": \"%s\"}%s\n",
                ename, fault.lba, efault,
                (i < report.faults.size() - 1) ? "," : "");
    }
    fprintf(f, "  ],\n");

    // ── Sector Overlaps ──────────────────────────────────────────────────
    fprintf(f, "  \"sector_overlaps\": [\n");
    for (size_t i = 0; i < report.overlaps.size(); i++) {
        auto& o = report.overlaps[i];
        char dw7n[128], dq4n[128];
        json_escape(o.dw7_file, dw7n, sizeof(dw7n));
        json_escape(o.dq4_file, dq4n, sizeof(dq4n));
        fprintf(f, "    {\"start_lba\": %u, \"end_lba\": %u, \"dw7_file\": \"%s\", \"dq4_file\": \"%s\"}%s\n",
                o.start_lba, o.end_lba, dw7n, dq4n,
                (i < report.overlaps.size() - 1) ? "," : "");
    }
    fprintf(f, "  ],\n");

    // ── DW7 EXE LBA References ───────────────────────────────────────────
    fprintf(f, "  \"dw7_exe_lba_refs\": [\n");
    for (size_t i = 0; i < report.dw7_exe_refs.size(); i++) {
        auto& r = report.dw7_exe_refs[i];
        char ctx[128]; json_escape(r.context, ctx, sizeof(ctx));
        fprintf(f, "    {\"exe_offset\": %u, \"lba_value\": %u, \"context\": \"%s\", \"in_dw7_tree\": %s, \"in_dq4_tree\": %s}%s\n",
                r.exe_offset, r.lba_value, ctx,
                r.in_dw7_tree ? "true" : "false",
                r.in_dq4_tree ? "true" : "false",
                (i < report.dw7_exe_refs.size() - 1) ? "," : "");
    }
    fprintf(f, "  ],\n");

    // ── DQ4 EXE LBA References ───────────────────────────────────────────
    fprintf(f, "  \"dq4_exe_lba_refs\": [\n");
    for (size_t i = 0; i < report.dq4_exe_refs.size(); i++) {
        auto& r = report.dq4_exe_refs[i];
        char ctx[128]; json_escape(r.context, ctx, sizeof(ctx));
        fprintf(f, "    {\"exe_offset\": %u, \"lba_value\": %u, \"context\": \"%s\", \"in_dw7_tree\": %s, \"in_dq4_tree\": %s}%s\n",
                r.exe_offset, r.lba_value, ctx,
                r.in_dw7_tree ? "true" : "false",
                r.in_dq4_tree ? "true" : "false",
                (i < report.dq4_exe_refs.size() - 1) ? "," : "");
    }
    fprintf(f, "  ]\n");

    fprintf(f, "}\n");
    fclose(f);
}

// ── Console Summary ──────────────────────────────────────────────────────────

static void print_summary(VfsDiffReport& report) {
    printf("\n");
    printf("========================================\n");
    printf("  VFS COMPARISON SUMMARY\n");
    printf("========================================\n\n");

    printf("DW7 Directory (%zu files):\n", report.dw7_files.size());
    for (auto& e : report.dw7_files) {
        printf("  %-32s LBA=%-8u size=%-10u sectors=%-6u end=%u gap=%d\n",
               e.name, e.lba, e.size, e.sectors, e.end_lba, e.gap_after);
    }

    printf("\nDQ4 Directory (%zu files):\n", report.dq4_files.size());
    for (auto& e : report.dq4_files) {
        printf("  %-32s LBA=%-8u size=%-10u sectors=%-6u end=%u gap=%d\n",
               e.name, e.lba, e.size, e.sectors, e.end_lba, e.gap_after);
    }

    printf("\nFiles only in DW7 (%zu):\n", report.only_dw7.size());
    for (auto& e : report.only_dw7) {
        printf("  %-32s LBA=%u size=%u\n", e.name, e.lba, e.size);
    }

    printf("\nFiles only in DQ4 (%zu):\n", report.only_dq4.size());
    for (auto& e : report.only_dq4) {
        printf("  %-32s LBA=%u size=%u\n", e.name, e.lba, e.size);
    }

    printf("\nMismatches (%zu):\n", report.mismatches.size());
    for (auto& m : report.mismatches) {
        printf("  %-32s DW7[LBA=%u,sz=%u] vs DQ4[LBA=%u,sz=%u] %s%s%s\n",
               m.name, m.dw7_lba, m.dw7_size, m.dq4_lba, m.dq4_size,
               m.lba_mismatch ? "LBA_MISMATCH " : "",
               m.size_mismatch ? "SIZE_MISMATCH " : "",
               m.overlap ? "OVERLAP!" : "");
    }

    printf("\nAlignment Faults (%zu):\n", report.faults.size());
    for (auto& f : report.faults) {
        printf("  %-32s LBA=%u: %s\n", f.name, f.lba, f.fault);
    }

    printf("\nSector Overlaps (%zu):\n", report.overlaps.size());
    for (auto& o : report.overlaps) {
        printf("  LBA %u-%u: DW7[%s] overlaps DQ4[%s]\n",
               o.start_lba, o.end_lba, o.dw7_file, o.dq4_file);
    }

    // EXE LBA ref analysis
    printf("\nDW7 EXE LBA References (%zu):\n", report.dw7_exe_refs.size());
    int dw7_orphan = 0;
    for (auto& r : report.dw7_exe_refs) {
        if (!r.in_dq4_tree) dw7_orphan++;
        printf("  EXE+0x%-6X LBA=%-8u %s  DW7:%s DQ4:%s\n",
               r.exe_offset, r.lba_value, r.context,
               r.in_dw7_tree ? "YES" : "no",
               r.in_dq4_tree ? "YES" : "no");
    }
    printf("  → %d/%zu DW7 EXE LBA refs NOT found in DQ4 tree (ORPHANED)\n",
           dw7_orphan, report.dw7_exe_refs.size());

    printf("\nDQ4 EXE LBA References (%zu):\n", report.dq4_exe_refs.size());
    int dq4_orphan = 0;
    for (auto& r : report.dq4_exe_refs) {
        if (!r.in_dw7_tree) dq4_orphan++;
        printf("  EXE+0x%-6X LBA=%-8u %s  DW7:%s DQ4:%s\n",
               r.exe_offset, r.lba_value, r.context,
               r.in_dw7_tree ? "YES" : "no",
               r.in_dq4_tree ? "YES" : "no");
    }
    printf("  → %d/%zu DQ4 EXE LBA refs NOT found in DW7 tree (ORPHANED)\n",
           dq4_orphan, report.dq4_exe_refs.size());

    // Critical diagnosis
    printf("\n========================================\n");
    printf("  DIAGNOSIS\n");
    printf("========================================\n");
    if (!report.overlaps.empty()) {
        printf("  CRITICAL: %zu sector overlaps detected!\n", report.overlaps.size());
        printf("  DQ4 files are overlapping DW7 file sectors.\n");
        printf("  The DW7 engine will read wrong data at these LBAs.\n");
    }
    if (dw7_orphan > 0) {
        printf("  CRITICAL: %d DW7 EXE LBA references point to sectors\n", dw7_orphan);
        printf("  that don't exist in the DQ4 directory tree.\n");
        printf("  The engine will read garbage or zeros → BLACK SCREEN.\n");
    }
    if (!report.faults.empty()) {
        printf("  WARNING: %zu alignment faults detected\n", report.faults.size());
    }
    if (report.overlaps.empty() && dw7_orphan == 0 && report.faults.empty()) {
        printf("  No critical issues detected.\n");
    }
    printf("========================================\n\n");
}

// ── Main ─────────────────────────────────────────────────────────────────────

int main(int argc, char* argv[]) {
    if (argc < 3) {
        fprintf(stderr, "Usage: vfs_compare.exe <dw7_base.bin> <dq4_injected.bin> [output.json]\n");
        fprintf(stderr, "\nCompares ISO9660 directory structures and EXE LBA references\n");
        fprintf(stderr, "between two PSX disc images to identify VFS alignment faults.\n");
        return 2;
    }

    const char* dw7_path = argv[1];
    const char* dq4_path = argv[2];
    char json_path[512];
    if (argc >= 4) {
        strncpy(json_path, argv[3], 511);
    } else {
        snprintf(json_path, sizeof(json_path), "vfs_diff_report.json");
    }
    json_path[511] = 0;

    printf("[VFS] Parsing DW7 directory: %s\n", dw7_path);
    printf("[VFS] Parsing DQ4 directory: %s\n", dq4_path);
    printf("[VFS] Output JSON: %s\n\n", json_path);

    VfsDiffReport report = compare_vfs(dw7_path, dq4_path);

    print_summary(report);
    write_json(json_path, report);

    printf("[VFS] JSON report written to: %s\n", json_path);

    // Exit code: 0 = no critical issues, 1 = critical issues found
    bool has_critical = !report.overlaps.empty() ||
                        std::any_of(report.dw7_exe_refs.begin(), report.dw7_exe_refs.end(),
                                    [](const LbaReference& r) { return !r.in_dq4_tree; });
    return has_critical ? 1 : 0;
}
