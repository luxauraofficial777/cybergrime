# PSX Matrix test harness runner for Frankenstein disc
$base = "C:\LuxAura\VoidWalkers_Project\DQLOSTTRANSLATION"
$runner = "$base\cybergrime\psx_agent_runner.exe"
$disc = "$base\build_staging\dq4_reverse_a.bin"
$profile = "frank_fmv_stub"
$maxInstrs = 50000000
$jsonOut = "$base\cybergrime\telemetry_frank_fmv_stub.json"

# Kill any stale DuckStation processes
Stop-Process -Name 'duckstation-qt-x64-ReleaseLTCG' -Force -ErrorAction SilentlyContinue

Write-Output "=== PSX Matrix Test ==="
Write-Output "Runner: $runner"
Write-Output "Disc: $disc"
Write-Output "Profile: $profile"
Write-Output "MaxInstrs: $maxInstrs"
Write-Output "JSON: $jsonOut"
Write-Output ""

# Run the agent runner
$proc = Start-Process -FilePath $runner `
    -ArgumentList $disc, $profile, $maxInstrs, $jsonOut `
    -NoNewWindow -PassThru `
    -WorkingDirectory "$base\cybergrime" `
    -RedirectStandardOutput "matrix_stdout.txt" `
    -RedirectStandardError "matrix_stderr.txt"

Write-Output "Process started (PID: $($proc.Id))"
Write-Output "Waiting for completion (120s timeout)..."

$proc | Wait-Process -Timeout 120 -ErrorAction SilentlyContinue

if (-not $proc.HasExited) {
    Write-Output "Process timed out, killing..."
    $proc | Stop-Process -Force
    Start-Sleep -Seconds 2
}

Write-Output "Exit code: $($proc.ExitCode)"

# Show telemetry summary
if (Test-Path $jsonOut) {
    Write-Output ""
    Write-Output "=== Telemetry JSON found ==="
    $json = Get-Content $jsonOut -Raw | ConvertFrom-Json
    Write-Output "Status: $($json.status)"
    Write-Output "InstrCount: $($json.instr_count)"
    Write-Output "VFS Count: $($json.vfs_count)"
    Write-Output "Errors: $($json.error_count)"
    Write-Output "Frozen: $($json.frozen)"
    Write-Output "LastPC: $($json.last_pc)"
    if ($json.CdromReads) {
        Write-Output "CDROM Sectors Read: $($json.CdromReads.sectors_read)"
        Write-Output "CDROM Cur LBA: $($json.CdromReads.cur_lba)"
    }
} else {
    Write-Output "No telemetry JSON found at $jsonOut"
}

# Show last 20 lines of stdout
if (Test-Path "$base\cybergrime\matrix_stdout.txt") {
    Write-Output ""
    Write-Output "=== Last 20 lines of stdout ==="
    Get-Content "$base\cybergrime\matrix_stdout.txt" -Tail 20
}
