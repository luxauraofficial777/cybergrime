#!/usr/bin/env python3
"""Quick test of the vector bridge pipeline."""
import sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from vector_db import VectorDB
from agent_bridge import AgentBridge

# Build index
db = VectorDB()
n = db.build_index(force_rebuild=True)
print(f"Indexed {n} entries")

# Simulate live telemetry from the patched disc stall at 0x80048004
live_telemetry = {
    'Last_Known_PC': 0x80048004,
    'Instructions_Executed': 12800,
    'Register_Dump': {
        'ra': '0x80048004',
        'sp': '0x801FFFF0',
        'gp': '0x80030000',
    },
    'Frozen': True,
    'Crashed': False,
    'thread_entry': 0,
    'bss_clear_end_instr': 0x2462CCC8,
    'tree_value': 0x240261AA,
    'stall_instructions': [0x00801821, 0xAFBF001C, 0xAFB10014, 0xAFB00010,
                           0x00A31021, 0x90421382, 0x00000000, 0x10400002],
}

# Query vector DB
print("\n=== Vector DB Query ===")
results = db.query(live_telemetry, top_k=5)
for m in results:
    print(f"  {m['source']:30s} sim={m['similarity']:.2f} type={m['match_type']}")
    if m.get('root_cause'):
        print(f"    root_cause: {m['root_cause'][:80]}")
    if m.get('false_hypotheses'):
        print(f"    false_hypotheses: {len(m['false_hypotheses'])} entries")

# Full agent diagnosis
print("\n=== Agent Bridge Diagnosis ===")
agent = AgentBridge()
report = agent.get_full_diagnostic_report(live_telemetry)
print(report)
