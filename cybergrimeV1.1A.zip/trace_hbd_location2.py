#!/usr/bin/env python3
"""Trace how the LBA table at 0x8001B9DC is accessed, and find the CD-ROM file loader."""
import struct

exe_path = r'..\translation\SLUSP012.06_disc_extract.bin'
with open(exe_path, 'rb') as f:
    data = f.read()

LOAD_ADDR = 0x80017F00

def f2r(off):
    return LOAD_ADDR + off - 0x800

def r2f(ram):
    return ram - LOAD_ADDR + 0x800

def disasm_mips(insn):
    op = (insn >> 26) & 0x3F
    rs = (insn >> 21) & 0x1F
    rt = (insn >> 16) & 0x1F
    rd = (insn >> 11) & 0x1F
    shamt = (insn >> 6) & 0x1F
    funct = insn & 0x3F
    imm = insn & 0xFFFF
    simm = imm if imm < 0x8000 else imm - 0x10000
    target = insn & 0x3FFFFFF
    regs = ['zero','at','v0','v1','a0','a1','a2','a3',
            't0','t1','t2','t3','t4','t5','t6','t7',
            's0','s1','s2','s3','s4','s5','s6','s7',
            't8','t9','k0','k1','gp','sp','fp','ra']
    if op == 0:
        if funct == 0x08: return f"jr ${regs[rs]}"
        if funct == 0x09: return f"jalr ${regs[rd]}, ${regs[rs]}"
        if funct == 0x21: return f"addu ${regs[rd]}, ${regs[rs]}, ${regs[rt]}"
        if funct == 0x23: return f"subu ${regs[rd]}, ${regs[rs]}, ${regs[rt]}"
        if funct == 0x24: return f"and ${regs[rd]}, ${regs[rs]}, ${regs[rt]}"
        if funct == 0x25: return f"or ${regs[rd]}, ${regs[rs]}, ${regs[rt]}"
        if funct == 0x2A: return f"slt ${regs[rd]}, ${regs[rs]}, ${regs[rt]}"
        if funct == 0x00: return "nop" if insn == 0 else f"sll ${regs[rd]}, ${regs[rt]}, {shamt}"
        if funct == 0x03: return f"sra ${regs[rd]}, ${regs[rt]}, {shamt}"
        if funct == 0x0C: return f"syscall"
        if funct == 0x07: return f"srav ${regs[rd]}, ${regs[rt]}, ${regs[rs]}"
        if funct == 0x04: return f"sllv ${regs[rd]}, ${regs[rt]}, ${regs[rs]}"
        if funct == 0x06: return f"srlv ${regs[rd]}, ${regs[rt]}, ${regs[rs]}"
        if funct == 0x2B: return f"sltu ${regs[rd]}, ${regs[rs]}, ${regs[rt]}"
        if funct == 0x26: return f"nor ${regs[rd]}, ${regs[rs]}, ${regs[rt]}"
        if funct == 0x27: return f"nor ${regs[rd]}, ${regs[rs]}, ${regs[rt]}"
        return f".word 0x{insn:08X}"
    if op == 0x01:
        if rt == 0: return f"bltz ${regs[rs]}, 0x{simm*4+4+0x80000000:08X}"
        if rt == 1: return f"bgez ${regs[rs]}, 0x{simm*4+4+0x80000000:08X}"
        return f".word 0x{insn:08X}"
    if op == 0x02: return f"j 0x{(target<<2):08X}"
    if op == 0x03: return f"jal 0x{(target<<2):08X}"
    if op == 0x04: return f"beq ${regs[rs]}, ${regs[rt]}, 0x{simm*4+4+0x80000000:08X}"
    if op == 0x05: return f"bne ${regs[rs]}, ${regs[rt]}, 0x{simm*4+4+0x80000000:08X}"
    if op == 0x06: return f"blez ${regs[rs]}, 0x{simm*4+4+0x80000000:08X}"
    if op == 0x07: return f"bgtz ${regs[rs]}, 0x{simm*4+4+0x80000000:08X}"
    if op == 0x08: return f"addi ${regs[rt]}, ${regs[rs]}, {simm}"
    if op == 0x09: return f"addiu ${regs[rt]}, ${regs[rs]}, {simm}"
    if op == 0x0A: return f"slti ${regs[rt]}, ${regs[rs]}, {simm}"
    if op == 0x0B: return f"sltiu ${regs[rt]}, ${regs[rs]}, {simm}"
    if op == 0x0C: return f"andi ${regs[rt]}, ${regs[rs]}, 0x{imm:04X}"
    if op == 0x0D: return f"ori ${regs[rt]}, ${regs[rs]}, 0x{imm:04X}"
    if op == 0x0E: return f"xori ${regs[rt]}, ${regs[rs]}, 0x{imm:04X}"
    if op == 0x0F: return f"lui ${regs[rt]}, 0x{imm:04X}"
    if op == 0x20: return f"lb ${regs[rt]}, {simm}(${regs[rs]})"
    if op == 0x21: return f"lh ${regs[rt]}, {simm}(${regs[rs]})"
    if op == 0x23: return f"lw ${regs[rt]}, {simm}(${regs[rs]})"
    if op == 0x24: return f"lbu ${regs[rt]}, {simm}(${regs[rs]})"
    if op == 0x25: return f"lhu ${regs[rt]}, {simm}(${regs[rs]})"
    if op == 0x28: return f"sb ${regs[rt]}, {simm}(${regs[rs]})"
    if op == 0x29: return f"sh ${regs[rt]}, {simm}(${regs[rs]})"
    if op == 0x2B: return f"sw ${regs[rt]}, {simm}(${regs[rs]})"
    return f".word 0x{insn:08X}"

# 1. Dump the full LBA table structure
print('=== Full LBA/descriptor table dump ===')
# The table seems to start earlier. Let's dump from 0x8001B980
base_off = r2f(0x8001B980)
for i in range(0, 256, 4):
    off = base_off + i
    if off + 4 <= len(data):
        val = struct.unpack('<I', data[off:off+4])[0]
        ram = f2r(off)
        if 0x100 <= val <= 0x2000:
            print(f'  0x{ram:08X}: 0x{val:08X}  LBA={val}')
        elif 0x80100000 <= val <= 0x801F0000:
            print(f'  0x{ram:08X}: 0x{val:08X}  PTR={val:08X}')
        else:
            print(f'  0x{ram:08X}: 0x{val:08X}')

# 2. Find the start of the table (look backwards for a count or base)
print('\n=== Table bounds ===')
# Look for where the LBA values start
first_lba_off = None
for off in range(r2f(0x8001B900), r2f(0x8001BA00), 4):
    if off + 4 <= len(data):
        val = struct.unpack('<I', data[off:off+4])[0]
        if 0x100 <= val <= 0x2000:
            first_lba_off = off
            break
if first_lba_off:
    print(f'First LBA-like value at file 0x{first_lba_off:X} (RAM 0x{f2r(first_lba_off):08X})')

# 3. Search for any lui 0x8001 in the code (broader search)
print('\n=== All lui 0x8001 references ===')
count = 0
for i in range(0x800, len(data) - 4, 4):
    insn = struct.unpack('<I', data[i:i+4])[0]
    if (insn >> 26) == 0x0F and (insn & 0xFFFF) == 0x8001:
        reg = (insn >> 16) & 0x1F
        ram = f2r(i)
        # Look at next instruction
        if i + 8 <= len(data):
            next_insn = struct.unpack('<I', data[i+4:i+8])[0]
            if (next_insn >> 26) == 0x09:  # addiu
                next_imm = next_insn & 0xFFFF
                next_simm = next_imm if next_imm < 0x8000 else next_imm - 0x10000
                addr = 0x80010000 + next_simm
                if 0x8001B900 <= addr <= 0x8001BB00:
                    print(f'\n  HIT: lui ${reg}, 0x8001 + addiu 0x{next_imm:04X} = 0x{addr:08X} at 0x{ram:08X}')
                    for k in range(-4, 20):
                        off2 = i + k*4
                        if 0x800 <= off2 and off2 + 4 <= len(data):
                            insn2 = struct.unpack('<I', data[off2:off2+4])[0]
                            r2 = f2r(off2)
                            print(f'    0x{r2:08X}: 0x{insn2:08X}  {disasm_mips(insn2)}')
                    count += 1
                    if count > 5:
                        break
        if count > 5:
            break

# 4. Search for the "cdrom file" debug string function
print('\n=== Function containing "cdrom file = %d" string ===')
# The string is at 0x80028F87. Find the function that references it.
# Search for addiu with 0x8F87 as immediate (low 16 bits of 0x80028F87)
for i in range(0x800, len(data) - 4, 4):
    insn = struct.unpack('<I', data[i:i+4])[0]
    if (insn >> 26) == 0x09:  # addiu
        imm = insn & 0xFFFF
        if imm == 0x8F87:
            # Check if previous was lui 0x8002
            if i >= 4:
                prev = struct.unpack('<I', data[i-4:i])[0]
                if (prev >> 26) == 0x0F and (prev & 0xFFFF) == 0x8002:
                    ram = f2r(i-4)
                    print(f'  xref at 0x{ram:08X}')
                    for k in range(0, 30):
                        off2 = i - 4 + k*4
                        if off2 + 4 <= len(data):
                            insn2 = struct.unpack('<I', data[off2:off2+4])[0]
                            r2 = f2r(off2)
                            print(f'    0x{r2:08X}: 0x{insn2:08X}  {disasm_mips(insn2)}')
                    break

# 5. Search for BIOS A0:07 (CdReadFile) calls
# In PSX, A0 functions are called via jal to the A0 dispatch table
# The A0 table is at 0xA0, each entry is 4 bytes
# CdReadFile is A0:0x4C = function 76
# But in practice, games call through the A0 handler at 0x000001xx
# Actually, the BIOS A0 calls go to address 0xA0000000 + func*4? No.
# The A0 table entries are at 0xA0 in the BIOS region (0xA0-0x1FF)
# Games typically call through jal to specific A0 entry points
# Let me search for "open" (A0:0x44) which is at 0xA0 + 0x44*4 = 0xA0 + 0x110 = 0x1B0
# Actually, the A0 dispatch is at 0x000001A0 for the first entry
# Each entry is 4 bytes, so function N is at 0x000001A0 + N*4
# But jal targets must be word-aligned: target = 0xA0 + N*4, then jal (target >> 2)

# Let me search for common BIOS call patterns instead
# A0:44 = open -> jal 0x000001A0 + 0x44*4 = 0x00000290 -> jal target = 0x000000A4
# A0:4C = CdReadFile -> 0x1A0 + 0x4C*4 = 0x1A0 + 0x130 = 0x2D0 -> jal target = 0x000000B4
# Actually, the A0 table is at 0xA0 in KSEG1 (0xA00000A0), but the call goes through
# the function at that address. In HLE BIOS, these are at 0xA0 + N*4.

# Let me just search for all JAL targets and see which ones go to BIOS region
print('\n=== JAL to BIOS A0/B0/C0 region (0x000001A0-0x00000400) ===')
bios_calls = {}
for i in range(0x800, len(data) - 4, 4):
    insn = struct.unpack('<I', data[i:i+4])[0]
    if (insn >> 26) == 0x03:  # jal
        target = (insn & 0x3FFFFFF) << 2
        if 0x1A0 <= target <= 0x400:
            ram = f2r(i)
            if target not in bios_calls:
                bios_calls[target] = []
            bios_calls[target].append(ram)

for target in sorted(bios_calls.keys()):
    callers = bios_calls[target]
    # Map to BIOS function
    if 0x1A0 <= target < 0x200:
        func_num = (target - 0x1A0) // 4
        table = "A0"
    elif 0x200 <= target < 0x300:
        func_num = (target - 0x200) // 4
        table = "B0"
    elif 0x300 <= target < 0x400:
        func_num = (target - 0x300) // 4
        table = "C0"
    else:
        func_num = -1
        table = "??"
    print(f'  JAL 0x{target:08X} ({table}:{func_num:02X}) called {len(callers)} times')
    for c in callers[:3]:
        print(f'    from 0x{c:08X}')
    if len(callers) > 3:
        print(f'    ... and {len(callers)-3} more')

print('\n=== Done ===')
