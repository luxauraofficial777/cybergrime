import struct

exe_path = "../translation/SLUSP012.06"
with open(exe_path, "rb") as f:
    data = f.read()

def file_to_ram(foff):
    return foff - 0x800 + 0x80017F00

def decode_mips(insn):
    op = (insn >> 26) & 0x3F
    rs = (insn >> 21) & 0x1F
    rt = (insn >> 16) & 0x1F
    rd = (insn >> 11) & 0x1F
    sh = (insn >> 6) & 0x1F
    fn = insn & 0x3F
    imm = insn & 0xFFFF
    simm = imm if imm < 0x8000 else imm - 0x10000
    target = insn & 0x3FFFFFF
    regs = ["zero","at","v0","v1","a0","a1","a2","a3","t0","t1","t2","t3","t4","t5","t6","t7","s0","s1","s2","s3","s4","s5","s6","s7","t8","t9","k0","k1","gp","sp","fp","ra"]
    if insn == 0: return "nop"
    if op == 0x0F: return f"lui ${regs[rt]},0x{imm:04X}"
    if op == 0x09: return f"addiu ${regs[rt]},${regs[rs]},0x{imm:04X} ({simm})"
    if op == 0x23: return f"lw ${regs[rt]},0x{imm:04X}(${regs[rs]})"
    if op == 0x2B: return f"sw ${regs[rt]},0x{imm:04X}(${regs[rs]})"
    if op == 0x0C: return f"andi ${regs[rt]},${regs[rs]},0x{imm:04X}"
    if op == 0x0D: return f"ori ${regs[rt]},${regs[rs]},0x{imm:04X}"
    if op == 0x00:
        if fn == 0x21: return f"addu ${regs[rd]},${regs[rs]},${regs[rt]}"
        if fn == 0x25: return f"or ${regs[rd]},${regs[rs]},${regs[rt]}"
        if fn == 0x08: return f"jr ${regs[rs]}"
        if fn == 0x00: return f"sll ${regs[rd]},${regs[rt]},{sh}"
        if fn == 0x02: return f"srl ${regs[rd]},${regs[rt]},{sh}"
        if fn == 0x2A: return f"slt ${regs[rd]},${regs[rs]},${regs[rt]}"
        if fn == 0x2B: return f"sltu ${regs[rd]},${regs[rs]},${regs[rt]}"
        return f"special fn=0x{fn:02X}"
    if op == 0x04: return f"beq ${regs[rs]},${regs[rt]},+{simm*4+4:#x}"
    if op == 0x05: return f"bne ${regs[rs]},${regs[rt]},+{simm*4+4:#x}"
    if op == 0x02: return f"j 0x{(target<<2):08X}"
    if op == 0x03: return f"jal 0x{(target<<2):08X}"
    return f"op=0x{op:02X} raw=0x{insn:08X}"

def dump_at(foff, label, count=8):
    ram = file_to_ram(foff)
    print(f"--- {label} ---")
    for i in range(count):
        off = foff + i*4
        if off+4 > len(data): break
        insn = struct.unpack_from("<I", data, off)[0]
        print(f"  0x{off:06X} (RAM 0x{ram+i*4:08X}): 0x{insn:08X}  {decode_mips(insn)}")
    print()

# Site 3 candidate: addiu $v1,$v1,0xF1C8 at file 0x0408F4
# But prev was 0x97A20018 (lhu $v0,0x18($sp)) — not lui. Let's look more carefully.
print("=== addiu $v1,$v1,0xF1C8 context (file 0x0408F4) ===")
dump_at(0x0408F4 - 8, "Site 3 candidate", 8)

# Also check addiu $v1,$v0,0xF1C8 at file 0x05A9C8
print("=== addiu $v1,$v0,0xF1C8 context (file 0x05A9C8) ===")
dump_at(0x05A9C8 - 8, "v1 from v0 candidate", 8)

# The real Site 3 pattern should be: lui $v1,0x800F + addiu $v1,$v1,0xF1C8 + addu $v0,$v0,$v1
# Search for lui $v1,0x800F (0x3C03800F) followed by addiu $v1,$v1,0xF1C8 (0x2463F1C8)
print("=== Searching for lui $v1,0x800F + addiu $v1,$v1,0xF1C8 ===")
pattern = struct.pack("<II", 0x3C03800F, 0x2463F1C8)
pos = 0
while True:
    pos = data.find(pattern, pos)
    if pos == -1: break
    ram = file_to_ram(pos)
    print(f"  Found at file 0x{pos:06X} (RAM 0x{ram:08X})")
    dump_at(pos, f"lui $v1 + addiu $v1 at 0x{pos:06X}", 6)
    pos += 4

# Also search for the pattern: lui $v1,0x800F + addiu $v1,$v1,* + addu $v0,$v0,$v1
# This is more general — the addiu immediate might not be 0xF1C8 if tree refs were already patched
print("=== Searching for lui $v1,0x800F + addiu $v1,$v1,* + addu $v0,$v0,$v1 ===")
pos = 0x800
while pos < len(data) - 12:
    insn1 = struct.unpack_from("<I", data, pos)[0]
    insn2 = struct.unpack_from("<I", data, pos+4)[0]
    insn3 = struct.unpack_from("<I", data, pos+8)[0]
    # lui $v1,0x800F = 0x3C03800F
    # addiu $v1,$v1,* = 0x2463???? 
    # addu $v0,$v0,$v1 = 0x00431021
    if insn1 == 0x3C03800F and (insn2 >> 16) == 0x2463 and insn3 == 0x00431021:
        ram = file_to_ram(pos)
        print(f"  Found at file 0x{pos:06X} (RAM 0x{ram:08X})")
        dump_at(pos, f"Site 3 pattern", 6)
    pos += 4

# Also look for the broader pattern: any lui + addiu + addu $v0,$v0,$v1
# where the lui loads 0x800F (tree segment)
print("=== Searching for lui *,0x800F + addiu *,*,* + addu $v0,$v0,$v1 ===")
pos = 0x800
while pos < len(data) - 12:
    insn1 = struct.unpack_from("<I", data, pos)[0]
    insn2 = struct.unpack_from("<I", data, pos+4)[0]
    insn3 = struct.unpack_from("<I", data, pos+8)[0]
    # lui $reg,0x800F = 0x3C??800F
    # addiu $reg,$reg,* = 0x24??????
    # addu $v0,$v0,$v1 = 0x00431021
    if (insn1 & 0xFFFF) == 0x800F and (insn1 >> 26) == 0x0F and insn3 == 0x00431021:
        rt1 = (insn1 >> 16) & 0x1F
        rt2 = (insn2 >> 16) & 0x1F
        rs2 = (insn2 >> 21) & 0x1F
        if (insn2 >> 26) == 0x09 and rt2 == rt1 and rs2 == rt1:
            ram = file_to_ram(pos)
            regs = ["zero","at","v0","v1","a0","a1","a2","a3","t0","t1","t2","t3","t4","t5","t6","t7","s0","s1","s2","s3","s4","s5","s6","s7","t8","t9","k0","k1","gp","sp","fp","ra"]
            print(f"  Found at file 0x{pos:06X} (RAM 0x{ram:08X}): lui ${regs[rt1]},0x800F + addiu ${regs[rt2]},${regs[rs2]},0x{insn2&0xFFFF:04X} + addu $v0,$v0,$v1")
    pos += 4

# Now let's look at the offset_b candidates more carefully
# The decompressor offset_b should be near other decompressor code
# Check what's around each andi candidate
print("\n=== Offset_b candidate 1: file 0x01AFB8 (RAM 0x800326B8) ===")
dump_at(0x01AFB8 - 12, "context before", 8)

print("=== Offset_b candidate 2: file 0x01C5F8 (RAM 0x80033CF8) ===")
dump_at(0x01C5F8 - 12, "context before", 8)

print("=== Offset_b candidate 3: file 0x07CAA4 (RAM 0x800941A4) ===")
dump_at(0x07CAA4 - 12, "context before", 8)

# Check which offset_b candidate is near the decompressor
# The decompressor tree refs are at RAM 0x800562EC and 0x8006E8FC
# Let's check if any andi is near those
# Also check: the old hardcoded offset was 0x1EEA8 (RAM 0x800365A8)
# The andi at 0x01AFB8 is at RAM 0x800326B8 — ~0x4000 away from old offset
# The andi at 0x01C5F8 is at RAM 0x80033CF8 — ~0x2900 away
# The andi at 0x07CAA4 is at RAM 0x800941A4 — very far

# Let's also look for the tree hook context more carefully
# The tree hook should be in the HBD block loader
# lw $s1,12($s4) at 0x03EBB8 is right before the first tree ptr pair
print("=== Tree hook context (broader) ===")
dump_at(0x03EBB8 - 20, "Tree hook area", 15)
