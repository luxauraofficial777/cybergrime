#pragma once
#include <cstdint>
#include <cstring>
#include <vector>

namespace {
    inline int psx_gpu_s11(uint32_t v) {
        int x = v & 0x7FF;
        if (v & 0x800) x |= ~0x7FF;
        return x;
    }
    template<typename T>
    inline T psx_gpu_min(T a, T b) { return a < b ? a : b; }
    template<typename T>
    inline T psx_gpu_max(T a, T b) { return a > b ? a : b; }
    inline int psx_gpu_abs(int a) { return a < 0 ? -a : a; }

    inline uint16_t psx_gpu_rgb24_to_rgb15(uint32_t c) {
        uint8_t r = (c >> 0) & 0xFF;
        uint8_t g = (c >> 8) & 0xFF;
        uint8_t b = (c >> 16) & 0xFF;
        return (uint16_t)((r >> 3) | ((g >> 3) << 5) | ((b >> 3) << 10));
    }

    inline uint16_t psx_gpu_modulate_texel(uint16_t texel, uint32_t color) {
        uint32_t tr = (texel & 0x1F) << 3;
        uint32_t tg = ((texel >> 5) & 0x1F) << 3;
        uint32_t tb = ((texel >> 10) & 0x1F) << 3;
        uint32_t cr = (color >> 0) & 0xFF;
        uint32_t cg = (color >> 8) & 0xFF;
        uint32_t cb = (color >> 16) & 0xFF;
        uint32_t r = (tr * cr) >> 7;
        uint32_t g = (tg * cg) >> 7;
        uint32_t b = (tb * cb) >> 7;
        if (r > 255) r = 255;
        if (g > 255) g = 255;
        if (b > 255) b = 255;
        return (uint16_t)((r >> 3) | ((g >> 3) << 5) | ((b >> 3) << 10));
    }

    inline uint16_t psx_gpu_apply_semi_trans(uint16_t src, uint16_t dst, uint8_t mode) {
        int sr = src & 0x1F, sg = (src >> 5) & 0x1F, sb = (src >> 10) & 0x1F;
        int dr = dst & 0x1F, dg = (dst >> 5) & 0x1F, db = (dst >> 10) & 0x1F;
        int r, g, b;
        switch (mode & 3) {
            case 0: r = (sr + dr) >> 1; g = (sg + dg) >> 1; b = (sb + db) >> 1; break;
            case 1: r = sr + dr; g = sg + dg; b = sb + db; break;
            case 2: r = dr - sr; g = dg - sg; b = db - sb; break;
            case 3: r = dr + (sr >> 2); g = dg + (sg >> 2); b = db + (sb >> 2); break;
            default: r = sr; g = sg; b = sb; break;
        }
        if (r < 0) r = 0; if (r > 31) r = 31;
        if (g < 0) g = 0; if (g > 31) g = 31;
        if (b < 0) b = 0; if (b > 31) b = 31;
        return (uint16_t)(r | (g << 5) | (b << 10));
    }

    inline uint16_t psx_gpu_sample_texel(PSX_Memory* mem, uint16_t u, uint16_t v, uint16_t clut) {
        uint16_t tx = (u & ~(mem->gpu_texwin_mask_x * 8)) | ((mem->gpu_texwin_off_x * 8) & (mem->gpu_texwin_mask_x * 8));
        uint16_t ty = (v & ~(mem->gpu_texwin_mask_y * 8)) | ((mem->gpu_texwin_off_y * 8) & (mem->gpu_texwin_mask_y * 8));
        uint16_t y = (mem->gpu_tpage_y + ty) & 511;
        uint16_t base_x = mem->gpu_tpage_x & 1023;
        uint16_t pixel = 0;
        switch (mem->gpu_tex_color_mode) {
            case 0: { // 4-bit
                uint16_t halfword_x = (base_x + (tx >> 2)) & 1023;
                uint16_t half = mem->vram[y * 1024 + halfword_x];
                uint8_t idx = (half >> ((tx & 3) * 4)) & 0xF;
                uint16_t cx = clut & 0x3F;
                uint16_t cy = (clut >> 6) & 0x1FF;
                uint16_t clut_x = ((cx * 16 + idx) & 1023);
                pixel = mem->vram[(cy & 511) * 1024 + clut_x];
                break;
            }
            case 1: { // 8-bit
                uint16_t halfword_x = (base_x + (tx >> 1)) & 1023;
                uint16_t half = mem->vram[y * 1024 + halfword_x];
                uint8_t idx = (half >> ((tx & 1) * 8)) & 0xFF;
                uint16_t cx = clut & 0x3F;
                uint16_t cy = (clut >> 6) & 0x1FF;
                uint16_t clut_x = ((cx * 16 + idx) & 1023);
                pixel = mem->vram[(cy & 511) * 1024 + clut_x];
                break;
            }
            case 2: // 15-bit direct
            default:
                pixel = mem->vram[y * 1024 + ((base_x + tx) & 1023)];
                break;
        }
        return pixel;
    }

    inline int psx_gpu_cmd_word_count(uint8_t cmd) {
        uint8_t top = (cmd >> 5) & 7;
        if (top == 1) { // polygon
            bool gouraud = (cmd >> 4) & 1;
            bool quad = (cmd >> 3) & 1;
            bool textured = (cmd >> 2) & 1;
            int nv = quad ? 4 : 3;
            int words = 1 + nv;
            if (gouraud) words += (nv - 1);
            if (textured) words += nv;
            return words;
        } else if (top == 2) { // line
            bool gouraud = (cmd >> 4) & 1;
            bool polyline = (cmd >> 3) & 1;
            if (polyline) return 16;
            return gouraud ? 4 : 3;
        } else if (top == 3) { // rectangle
            bool textured = (cmd >> 2) & 1;
            int size = (cmd >> 3) & 3;
            int words = 1 + 1 + (textured ? 1 : 0) + (size == 0 ? 1 : 0);
            return words;
        } else if (top == 0) { // misc
            switch (cmd) {
                case 0x02: return 3;
                default: return 1;
            }
        } else if (top == 4) { // VRAM->VRAM
            return 4;
        } else if (top == 5 || top == 6) { // CPU->VRAM, VRAM->CPU
            return 3;
        } else { // environment (top==7)
            return 1;
        }
    }
}

inline void PSX_Memory::gpu_write_pixel(int x, int y, uint16_t color, bool semi_trans) {
    if (x < gpu_draw_x1 || x > gpu_draw_x2 || y < gpu_draw_y1 || y > gpu_draw_y2) return;
    uint16_t* ptr = &vram[(y & 511) * 1024 + (x & 1023)];
    if (semi_trans) {
        color = psx_gpu_apply_semi_trans(color, *ptr, gpu_semi_trans_mode);
    }
    *ptr = color;
    gpu_vram_write_total++;
    fb_dirty = true;
}

inline void PSX_Memory::gpu_draw_triangle(const GPVertex& v0, const GPVertex& v1, const GPVertex& v2,
                                          bool textured, bool shaded, bool semi_trans, bool raw) {
    int minx = psx_gpu_min(psx_gpu_min(v0.x, v1.x), v2.x);
    int miny = psx_gpu_min(psx_gpu_min(v0.y, v1.y), v2.y);
    int maxx = psx_gpu_max(psx_gpu_max(v0.x, v1.x), v2.x);
    int maxy = psx_gpu_max(psx_gpu_max(v0.y, v1.y), v2.y);
    minx = psx_gpu_max(minx, gpu_draw_x1);
    miny = psx_gpu_max(miny, gpu_draw_y1);
    maxx = psx_gpu_min(maxx, gpu_draw_x2);
    maxy = psx_gpu_min(maxy, gpu_draw_y2);

    int x0 = v0.x, y0 = v0.y;
    int x1 = v1.x, y1 = v1.y;
    int x2 = v2.x, y2 = v2.y;

    int denom = (y1 - y2)*(x0 - x2) + (x2 - x1)*(y0 - y2);
    if (denom == 0) return;
    float inv_denom = 1.0f / (float)denom;

    float c0r, c0g, c0b, c1r, c1g, c1b, c2r, c2g, c2b;
    if (shaded) {
        c0r = (float)(v0.color & 0xFF); c0g = (float)((v0.color >> 8) & 0xFF); c0b = (float)((v0.color >> 16) & 0xFF);
        c1r = (float)(v1.color & 0xFF); c1g = (float)((v1.color >> 8) & 0xFF); c1b = (float)((v1.color >> 16) & 0xFF);
        c2r = (float)(v2.color & 0xFF); c2g = (float)((v2.color >> 8) & 0xFF); c2b = (float)((v2.color >> 16) & 0xFF);
    } else {
        c0r = c1r = c2r = (float)(v0.color & 0xFF);
        c0g = c1g = c2g = (float)((v0.color >> 8) & 0xFF);
        c0b = c2b = c1b = (float)((v0.color >> 16) & 0xFF);
    }
    float u0 = (float)v0.u, vv0 = (float)v0.v;
    float u1 = (float)v1.u, vv1 = (float)v1.v;
    float u2 = (float)v2.u, vv2 = (float)v2.v;

    for (int y = miny; y <= maxy; y++) {
        for (int x = minx; x <= maxx; x++) {
            int w0 = (y1 - y2)*(x - x2) + (x2 - x1)*(y - y2);
            int w1 = (y2 - y0)*(x - x2) + (x0 - x2)*(y - y2);
            float fw0 = (float)w0 * inv_denom;
            float fw1 = (float)w1 * inv_denom;
            float fw2 = 1.0f - fw0 - fw1;
            if (fw0 < -0.0001f || fw1 < -0.0001f || fw2 < -0.0001f) continue;

            uint16_t color15 = 0;
            if (textured) {
                float u = u0*fw0 + u1*fw1 + u2*fw2;
                float v = vv0*fw0 + vv1*fw1 + vv2*fw2;
                uint16_t texel = psx_gpu_sample_texel(this, (uint16_t)u, (uint16_t)v, v0.clut);
                if (texel == 0) continue;
                if (raw) {
                    color15 = texel;
                } else {
                    uint32_t mod_color;
                    if (shaded) {
                        uint8_t r = (uint8_t)(c0r*fw0 + c1r*fw1 + c2r*fw2);
                        uint8_t g = (uint8_t)(c0g*fw0 + c1g*fw1 + c2g*fw2);
                        uint8_t b = (uint8_t)(c0b*fw0 + c1b*fw1 + c2b*fw2);
                        mod_color = r | (g << 8) | (b << 16);
                    } else {
                        mod_color = v0.color;
                    }
                    color15 = psx_gpu_modulate_texel(texel, mod_color);
                }
            } else {
                if (shaded) {
                    uint8_t r = (uint8_t)(c0r*fw0 + c1r*fw1 + c2r*fw2);
                    uint8_t g = (uint8_t)(c0g*fw0 + c1g*fw1 + c2g*fw2);
                    uint8_t b = (uint8_t)(c0b*fw0 + c1b*fw1 + c2b*fw2);
                    color15 = psx_gpu_rgb24_to_rgb15(r | (g << 8) | (b << 16));
                } else {
                    color15 = psx_gpu_rgb24_to_rgb15(v0.color);
                }
            }
            gpu_write_pixel(x, y, color15, semi_trans);
        }
    }
}

inline void PSX_Memory::gpu_draw_quad(const GPVertex& v0, const GPVertex& v1, const GPVertex& v2, const GPVertex& v3,
                                      bool textured, bool shaded, bool semi_trans, bool raw) {
    gpu_draw_triangle(v0, v1, v2, textured, shaded, semi_trans, raw);
    gpu_draw_triangle(v1, v2, v3, textured, shaded, semi_trans, raw);
}

inline void PSX_Memory::gpu_draw_line(const GPVertex& v0, const GPVertex& v1, bool shaded, bool semi_trans) {
    int x0 = v0.x, y0 = v0.y;
    int x1 = v1.x, y1 = v1.y;
    int dx = psx_gpu_abs(x1 - x0), dy = psx_gpu_abs(y1 - y0);
    int sx = x0 < x1 ? 1 : -1;
    int sy = y0 < y1 ? 1 : -1;
    int err = dx - dy;
    int steps = psx_gpu_max(dx, dy) + 1;
    int step = 0;
    float t = 0.0f;

    uint32_t c0 = v0.color;
    uint32_t c1 = v1.color;

    int x = x0, y = y0;
    while (true) {
        t = (steps > 1) ? (float)step / (float)(steps - 1) : 0.0f;
        uint32_t color = c0;
        if (shaded) {
            uint8_t r0 = c0 & 0xFF, g0 = (c0 >> 8) & 0xFF, b0 = (c0 >> 16) & 0xFF;
            uint8_t r1 = c1 & 0xFF, g1 = (c1 >> 8) & 0xFF, b1 = (c1 >> 16) & 0xFF;
            uint8_t r = (uint8_t)(r0 + (int)((r1 - r0) * t));
            uint8_t g = (uint8_t)(g0 + (int)((g1 - g0) * t));
            uint8_t b = (uint8_t)(b0 + (int)((b1 - b0) * t));
            color = r | (g << 8) | (b << 16);
        }
        gpu_write_pixel(x, y, psx_gpu_rgb24_to_rgb15(color), semi_trans);
        if (x == x1 && y == y1) break;
        int e2 = 2 * err;
        if (e2 > -dy) { err -= dy; x += sx; }
        if (e2 < dx) { err += dx; y += sy; }
        step++;
    }
}

inline void PSX_Memory::gpu_draw_sprite(const GPVertex& v, int w, int h, bool textured, bool semi_trans, bool raw) {
    int x0 = v.x;
    int y0 = v.y;
    for (int row = 0; row < h; row++) {
        for (int col = 0; col < w; col++) {
            int x = x0 + col;
            int y = y0 + row;
            if (x < gpu_draw_x1 || x > gpu_draw_x2 || y < gpu_draw_y1 || y > gpu_draw_y2) continue;
            uint16_t color = 0;
            if (textured) {
                uint16_t u = v.u + col;
                uint16_t vv = v.v + row;
                uint16_t texel = psx_gpu_sample_texel(this, u, vv, v.clut);
                if (texel == 0) continue;
                if (raw) {
                    color = texel;
                } else {
                    color = psx_gpu_modulate_texel(texel, v.color);
                }
            } else {
                color = psx_gpu_rgb24_to_rgb15(v.color);
            }
            gpu_write_pixel(x, y, color, semi_trans);
        }
    }
}

inline void PSX_Memory::gpu_process_command() {
    uint8_t cmd = (gpu_cmd_fifo[0] >> 24) & 0xFF;
    uint32_t w0 = gpu_cmd_fifo[0];
    uint8_t top = (cmd >> 5) & 7;

    if (top == 1) { // polygon
        bool gouraud = (cmd >> 4) & 1;
        bool quad = (cmd >> 3) & 1;
        bool textured = (cmd >> 2) & 1;
        bool semi_trans = (cmd >> 1) & 1;
        bool raw = cmd & 1;
        int nv = quad ? 4 : 3;
        int idx = 1;
        GPVertex v[4];
        for (int i = 0; i < nv; i++) {
            uint32_t vw = gpu_cmd_fifo[idx++];
            v[i].x = psx_gpu_s11(vw);
            v[i].y = psx_gpu_s11(vw >> 16);
            v[i].u = 0; v[i].v = 0; v[i].clut = 0;
            if (gouraud) {
                if (i == 0) v[i].color = w0 & 0xFFFFFF;
                else v[i].color = gpu_cmd_fifo[idx++] & 0xFFFFFF;
            } else {
                v[i].color = w0 & 0xFFFFFF;
            }
            if (textured) {
                uint32_t tw = gpu_cmd_fifo[idx++];
                v[i].u = tw & 0xFF;
                v[i].v = (tw >> 8) & 0xFF;
                if (i == 0) {
                    v[i].clut = (tw >> 16) & 0xFFFF;
                } else if (i == 1) {
                    // Second UV word carries texture page
                    uint16_t tpage = (tw >> 16) & 0xFFFF;
                    gpu_tpage_x = (tpage & 0xF) * 64;
                    gpu_tpage_y = ((tpage >> 4) & 0x1) * 256;
                    gpu_semi_trans_mode = (tpage >> 5) & 0x3;
                    gpu_tex_color_mode = (tpage >> 7) & 0x3;
                }
            }
            v[i].x += gpu_off_x;
            v[i].y += gpu_off_y;
        }
        if (quad) {
            gpu_draw_quad(v[0], v[1], v[2], v[3], textured, gouraud, semi_trans, raw);
        } else {
            gpu_draw_triangle(v[0], v[1], v[2], textured, gouraud, semi_trans, raw);
        }
    } else if (top == 2) { // line
        bool gouraud = (cmd >> 4) & 1;
        bool polyline = (cmd >> 3) & 1;
        bool semi_trans = (cmd >> 1) & 1;
        if (polyline) {
            int idx = 1;
            while (idx + 1 < gpu_cmd_words_got) {
                GPVertex v0, v1;
                uint32_t w1 = gpu_cmd_fifo[idx++];
                if (gouraud) {
                    if ((w1 & 0xF000F000) == 0x50005000) break;
                    v0.color = w1 & 0xFFFFFF;
                    if (idx >= gpu_cmd_words_got) break;
                    uint32_t w2 = gpu_cmd_fifo[idx++];
                    v0.x = psx_gpu_s11(w2); v0.y = psx_gpu_s11(w2 >> 16);
                    if (idx >= gpu_cmd_words_got) break;
                    uint32_t w3 = gpu_cmd_fifo[idx++];
                    if ((w3 & 0xF000F000) == 0x50005000) break;
                    v1.color = w3 & 0xFFFFFF;
                    if (idx >= gpu_cmd_words_got) break;
                    uint32_t w4 = gpu_cmd_fifo[idx++];
                    v1.x = psx_gpu_s11(w4); v1.y = psx_gpu_s11(w4 >> 16);
                } else {
                    if ((w1 & 0xF000F000) == 0x50005000) break;
                    v0.color = w0 & 0xFFFFFF;
                    v0.x = psx_gpu_s11(w1); v0.y = psx_gpu_s11(w1 >> 16);
                    if (idx >= gpu_cmd_words_got) break;
                    uint32_t w2 = gpu_cmd_fifo[idx++];
                    if ((w2 & 0xF000F000) == 0x50005000) break;
                    v1.color = w0 & 0xFFFFFF;
                    v1.x = psx_gpu_s11(w2); v1.y = psx_gpu_s11(w2 >> 16);
                }
                v0.x += gpu_off_x; v0.y += gpu_off_y;
                v1.x += gpu_off_x; v1.y += gpu_off_y;
                gpu_draw_line(v0, v1, gouraud, semi_trans);
            }
        } else {
            int idx = 1;
            GPVertex v0, v1;
            uint32_t w1 = gpu_cmd_fifo[idx++];
            v0.x = psx_gpu_s11(w1); v0.y = psx_gpu_s11(w1 >> 16);
            if (gouraud) {
                v0.color = w0 & 0xFFFFFF;
                uint32_t c2 = gpu_cmd_fifo[idx++];
                v1.color = c2 & 0xFFFFFF;
            } else {
                v0.color = w0 & 0xFFFFFF;
                v1.color = w0 & 0xFFFFFF;
            }
            uint32_t w2 = gpu_cmd_fifo[idx++];
            v1.x = psx_gpu_s11(w2); v1.y = psx_gpu_s11(w2 >> 16);
            v0.x += gpu_off_x; v0.y += gpu_off_y;
            v1.x += gpu_off_x; v1.y += gpu_off_y;
            gpu_draw_line(v0, v1, gouraud, semi_trans);
        }
    } else if (top == 3) { // rectangle
        bool textured = (cmd >> 2) & 1;
        bool semi_trans = (cmd >> 1) & 1;
        bool raw = cmd & 1;
        int size = (cmd >> 3) & 3;
        int idx = 1;
        GPVertex v;
        uint32_t w1 = gpu_cmd_fifo[idx++];
        v.x = psx_gpu_s11(w1); v.y = psx_gpu_s11(w1 >> 16);
        v.color = w0 & 0xFFFFFF;
        v.u = 0; v.v = 0; v.clut = 0;
        int w = 0, h = 0;
        if (size == 0) {
            uint32_t sz = gpu_cmd_fifo[idx++];
            w = sz & 0xFFFF; h = (sz >> 16) & 0xFFFF;
        } else if (size == 1) { w = h = 1; }
        else if (size == 2) { w = h = 8; }
        else if (size == 3) { w = h = 16; }
        if (textured) {
            uint32_t tw = gpu_cmd_fifo[idx++];
            v.u = tw & 0xFF; v.v = (tw >> 8) & 0xFF; v.clut = (tw >> 16) & 0xFFFF;
        }
        v.x += gpu_off_x; v.y += gpu_off_y;
        gpu_draw_sprite(v, w, h, textured, semi_trans, raw);
    } else if (top == 0) { // misc
        switch (cmd) {
            case 0x02: { // fill
                uint16_t color = psx_gpu_rgb24_to_rgb15(w0);
                uint32_t w1 = gpu_cmd_fifo[1];
                uint32_t w2 = gpu_cmd_fifo[2];
                int x = (w1 & 0xFFFF) & 0x3F0;
                int y = (w1 >> 16) & 0x1FF;
                int w = (w2 & 0xFFFF);
                w = ((w & 0x3FF) + 0xF) & ~0xF;
                int h = (w2 >> 16) & 0x1FF;
                if (w == 0 || h == 0) break;
                for (int row = 0; row < h; row++) {
                    for (int col = 0; col < w; col++) {
                        int px = x + col;
                        int py = y + row;
                        vram[(py & 511) * 1024 + (px & 1023)] = color;
                    }
                }
                fb_dirty = true;
                break;
            }
            case 0x01: // clear cache
            default:
                break;
        }
    } else if (top == 4) { // VRAM->VRAM
        if (gpu_cmd_words_got >= 4) {
            uint32_t w1 = gpu_cmd_fifo[1];
            uint32_t w2 = gpu_cmd_fifo[2];
            uint32_t w3 = gpu_cmd_fifo[3];
            int sx = w1 & 0x3FF;
            int sy = (w1 >> 16) & 0x1FF;
            int dx = w2 & 0x3FF;
            int dy = (w2 >> 16) & 0x1FF;
            int w = (((w3 & 0xFFFF) - 1) & 0x3FF) + 1;
            int h = ((((w3 >> 16) & 0xFFFF) - 1) & 0x1FF) + 1;
            if (w > 0 && h > 0) {
                std::vector<uint16_t> temp(w * h);
                for (int y = 0; y < h; y++) {
                    for (int x = 0; x < w; x++) {
                        temp[y * w + x] = vram[((sy + y) & 511) * 1024 + ((sx + x) & 1023)];
                    }
                }
                for (int y = 0; y < h; y++) {
                    for (int x = 0; x < w; x++) {
                        vram[((dy + y) & 511) * 1024 + ((dx + x) & 1023)] = temp[y * w + x];
                    }
                }
                fb_dirty = true;
            }
        }
    } else if (top == 5) { // CPU->VRAM
        if (gpu_cmd_words_got >= 3) {
            uint32_t w1 = gpu_cmd_fifo[1];
            uint32_t w2 = gpu_cmd_fifo[2];
            gpu_xfer_x = w1 & 0x3FF;
            gpu_xfer_y = (w1 >> 16) & 0x1FF;
            gpu_xfer_w = ((w2 & 0xFFFF) - 1) & 0x3FF;
            gpu_xfer_w += 1;
            gpu_xfer_h = (((w2 >> 16) & 0xFFFF) - 1) & 0x1FF;
            gpu_xfer_h += 1;
            gpu_xfer_cx = 0;
            gpu_xfer_cy = 0;
            gpu_xfer_is_read = false;
        }
    } else if (top == 6) { // VRAM->CPU
        if (gpu_cmd_words_got >= 3) {
            uint32_t w1 = gpu_cmd_fifo[1];
            uint32_t w2 = gpu_cmd_fifo[2];
            gpu_xfer_x = w1 & 0x3FF;
            gpu_xfer_y = (w1 >> 16) & 0x1FF;
            gpu_xfer_w = ((w2 & 0xFFFF) - 1) & 0x3FF;
            gpu_xfer_w += 1;
            gpu_xfer_h = (((w2 >> 16) & 0xFFFF) - 1) & 0x1FF;
            gpu_xfer_h += 1;
            gpu_xfer_cx = 0;
            gpu_xfer_cy = 0;
            gpu_xfer_is_read = true;
            gpu_read_data = vram[(gpu_xfer_y & 511) * 1024 + (gpu_xfer_x & 1023)];
        }
    } else if (top == 7) { // environment
        switch (cmd) {
            case 0xE1: { // draw mode / texpage
                gpu_texpage = w0 & 0x1FFF;
                gpu_tpage_x = ((w0 >> 0) & 0xF) * 64;
                gpu_tpage_y = ((w0 >> 4) & 0x1) * 256;
                gpu_semi_trans_mode = (w0 >> 5) & 0x3;
                gpu_tex_color_mode = (w0 >> 7) & 0x3;
                gpu_dither = (w0 >> 9) & 1;
                break;
            }
            case 0xE2: { // texture window
                gpu_texwin = w0 & 0xFFFFF;
                gpu_texwin_mask_x = (w0 >> 0) & 0x1F;
                gpu_texwin_mask_y = (w0 >> 5) & 0x1F;
                gpu_texwin_off_x = (w0 >> 10) & 0x1F;
                gpu_texwin_off_y = (w0 >> 15) & 0x1F;
                break;
            }
            case 0xE3: { // drawing area top-left
                gpu_draw_area_tl = w0 & 0x3FFFFF;
                gpu_draw_x1 = w0 & 0x3FF;
                gpu_draw_y1 = (w0 >> 10) & 0x3FF;
                break;
            }
            case 0xE4: { // drawing area bottom-right
                gpu_draw_area_br = w0 & 0x3FFFFF;
                gpu_draw_x2 = w0 & 0x3FF;
                gpu_draw_y2 = (w0 >> 10) & 0x3FF;
                break;
            }
            case 0xE5: { // drawing offset
                gpu_draw_offset = w0 & 0x3FFFFF;
                gpu_off_x = (w0 & 0x7FF); if (w0 & 0x400) gpu_off_x |= ~0x7FF;
                gpu_off_y = ((w0 >> 11) & 0x7FF); if ((w0 >> 11) & 0x400) gpu_off_y |= ~0x7FF;
                break;
            }
            case 0xE6: { // mask bit
                // TODO: mask bit handling
                break;
            }
            default:
                break;
        }
    }
}
