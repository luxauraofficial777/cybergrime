#!/usr/bin/env python3
"""Standalone MIPS assembler that outputs raw .bin or harness injection JSON.

Supports label-based assembly using the mips package.

Examples:
    python mips_asm.py stub.asm --base 0x800D9E80 -o stub.bin
    python mips_asm.py stub.asm --base 0x800D9E80 --json stub_inject.json --cond at_pc --trigger 0x8004BD71
"""

import argparse
import json
import struct
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))
from mips import assemble


def main():
    parser = argparse.ArgumentParser(description="Assemble MIPS source to binary or injection spec")
    parser.add_argument("asm", help="Input assembly file")
    parser.add_argument("--base", type=lambda x: int(x, 0), default=0, help="Base RAM address")
    parser.add_argument("-o", "--out", default=None, help="Output raw binary file")
    parser.add_argument("--json", default=None, help="Output harness injection JSON")
    parser.add_argument("--cond", default="immediate",
                        choices=["immediate", "at_instr", "at_vblank", "at_pc", "on_hardware_init"],
                        help="Injection firing condition (used with --json)")
    parser.add_argument("--trigger", type=lambda x: int(x, 0), default=0,
                        help="Injection trigger value (used with --json)")
    parser.add_argument("--label", default="mips patch", help="Human-readable label")
    args = parser.parse_args()

    with open(args.asm, "r") as f:
        asm_text = f.read()

    words, labels = assemble(asm_text, base_addr=args.base)
    data = b"".join(struct.pack("<I", w) for w in words)

    if args.out:
        with open(args.out, "wb") as f:
            f.write(data)
        print(f"Wrote {len(data)} bytes to {args.out}")

    if args.json:
        byte_list = list(data)
        entry = {
            "addr": f"0x{args.base:08X}",
            "type": "bytes",
            "data": byte_list,
            "condition": args.cond,
            "trigger": args.trigger,
            "label": args.label,
        }
        with open(args.json, "w") as f:
            json.dump({"injections": [entry]}, f, indent=2)
        print(f"Wrote injection spec to {args.json}")

    if not args.out and not args.json:
        # Default: write to stdout as hex if no output specified
        print("Assembled bytes:")
        print(data.hex())


if __name__ == "__main__":
    main()
