$exePath = 'c:\LuxAura\VoidWalkers_Project\DQLOSTTRANSLATION\translation\SLUSP012.06'
$bytes = [System.IO.File]::ReadAllBytes($exePath)
$loadAddr = 0x80017F00

# Search for jal 0xB0 (BIOS B0 function table) = 0x0C00002C
Write-Host "=== jal 0xB0 (BIOS B0 dispatch) ==="
$jalB0 = @()
for ($i = 0x800; $i -lt $bytes.Length - 3; $i += 4) {
    $insn = [BitConverter]::ToUInt32($bytes, $i)
    if ($insn -eq 0x0C00002C) {
        $ram = $loadAddr + $i - 0x800
        $prev = [BitConverter]::ToUInt32($bytes, $i - 4)
        $prev2 = [BitConverter]::ToUInt32($bytes, $i - 8)
        $next = [BitConverter]::ToUInt32($bytes, $i + 4)
        $jalB0 += [PSCustomObject]@{RAM=$ram; File=$i; Prev=$prev; Prev2=$prev2; Next=$next}
        # Check if prev is li $t1, N (0x24090000 | N)
        $prevImm = $prev -band 0xFFFF
        if (($prev -band 0xFFFF0000) -eq 0x24090000) {
            Write-Host ("  RAM 0x{0:X8}: jal 0xB0  prev=li t1,{1} (0x{2:X8})" -f $ram, $prevImm, $prev)
        } elseif (($prev2 -band 0xFFFF0000) -eq 0x24090000) {
            $prev2Imm = $prev2 -band 0xFFFF
            Write-Host ("  RAM 0x{0:X8}: jal 0xB0  prev2=li t1,{1} (0x{2:X8}) prev=0x{3:X8}" -f $ram, $prev2Imm, $prev2, $prev)
        } else {
            Write-Host ("  RAM 0x{0:X8}: jal 0xB0  prev=0x{1:X8} prev2=0x{2:X8}" -f $ram, $prev, $prev2)
        }
    }
}
Write-Host "Total jal 0xB0: $($jalB0.Count)"

# Also search for jal 0xA0 (BIOS A0 function table) = 0x0C000028
Write-Host ""
Write-Host "=== jal 0xA0 (BIOS A0 dispatch) — first 20 ==="
$count = 0
for ($i = 0x800; $i -lt $bytes.Length - 3; $i += 4) {
    $insn = [BitConverter]::ToUInt32($bytes, $i)
    if ($insn -eq 0x0C000028) {
        $ram = $loadAddr + $i - 0x800
        $prev = [BitConverter]::ToUInt32($bytes, $i - 4)
        if (($prev -band 0xFFFF0000) -eq 0x24090000) {
            $prevImm = $prev -band 0xFFFF
            Write-Host ("  RAM 0x{0:X8}: jal 0xA0  prev=li t1,{1}" -f $ram, $prevImm)
        }
        $count++
        if ($count -ge 20) { break }
    }
}
Write-Host "Total jal 0xA0: $count (showing first 20 with li t1 pattern)"

# Search for li $t1, 7 (CDROM_Setloc = B0 func 7) = 0x24090007
Write-Host ""
Write-Host "=== li t1, 7 (CDROM_Setloc B0 func 7) ==="
for ($i = 0x800; $i -lt $bytes.Length - 3; $i += 4) {
    $insn = [BitConverter]::ToUInt32($bytes, $i)
    if ($insn -eq 0x24090007) {
        $ram = $loadAddr + $i - 0x800
        $next = [BitConverter]::ToUInt32($bytes, $i + 4)
        $next2 = [BitConverter]::ToUInt32($bytes, $i + 8)
        Write-Host ("  RAM 0x{0:X8}: li t1,7  next=0x{1:X8} next2=0x{2:X8}" -f $ram, $next, $next2)
    }
}

# Search for li $t1, 0x0E (CDROM_Setmode = B0 func 14) = 0x2409000E
Write-Host ""
Write-Host "=== li t1, 0x0E (CDROM_Setmode B0 func 14) ==="
for ($i = 0x800; $i -lt $bytes.Length - 3; $i += 4) {
    $insn = [BitConverter]::ToUInt32($bytes, $i)
    if ($insn -eq 0x2409000E) {
        $ram = $loadAddr + $i - 0x800
        $next = [BitConverter]::ToUInt32($bytes, $i + 4)
        Write-Host ("  RAM 0x{0:X8}: li t1,0x0E  next=0x{1:X8}" -f $ram, $next)
    }
}

# Also search for li $a0, 0x0E (some games use $a0 for func num)
# And search for li $t1, 8 (CDROM_ReadN = B0 func 8)
Write-Host ""
Write-Host "=== li t1, 8 (CDROM_ReadN B0 func 8) ==="
for ($i = 0x800; $i -lt $bytes.Length - 3; $i += 4) {
    $insn = [BitConverter]::ToUInt32($bytes, $i)
    if ($insn -eq 0x24090008) {
        $ram = $loadAddr + $i - 0x800
        $next = [BitConverter]::ToUInt32($bytes, $i + 4)
        Write-Host ("  RAM 0x{0:X8}: li t1,8  next=0x{1:X8}" -f $ram, $next)
    }
}
