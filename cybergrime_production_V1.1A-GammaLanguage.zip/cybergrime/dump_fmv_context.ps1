# Dump the data around EXE offset 0x92936 to understand the structure
$exePath = 'c:\LuxAura\VoidWalkers_Project\DQLOSTTRANSLATION\translation\SLUSP012.06'
$bytes = [System.IO.File]::ReadAllBytes($exePath)
$loadAddr = 0x80017F00

# Hex dump 128 bytes before and after 0x92936
$start = 0x92936 - 64
$end = 0x92936 + 64

Write-Host "=== Hex dump around 0x92936 (patched EXE) ==="
for ($i = $start; $i -lt $end; $i += 16) {
    $ram = $loadAddr + $i - 0x800
    $hex = ''
    $ascii = ''
    for ($j = 0; $j -lt 16 -and ($i + $j) -lt $end; $j++) {
        $b = $bytes[$i + $j]
        $hex += '{0:X2} ' -f $b
        if ($b -ge 0x20 -and $b -lt 0x7F) { $ascii += [char]$b } else { $ascii += '.' }
    }
    $marker = if ($i -le 0x92936 -and ($i + 16) -gt 0x92936) { ' <<<' } else { '' }
    Write-Host ("  0x{0:X5} R{1:X8}: {2} {3}{4}" -f $i, $ram, $hex, $ascii, $marker)
}

# Now let's look at the data structure. The BCD MSF might be part of
# a larger structure. Let me look for patterns.
# Also check: is 0x92936 in the EXE's text section or data section?
# EXE header: load addr 0x80017F00, text size 0xA4800 (673792)
# Text section: file 0x800 to 0x800 + 0xA4800 = 0xA5000
# 0x92936 is within text section (0x800 to 0xA5000)
# So it's in the code section, not a separate data section.
# It might be embedded in a function as immediate data.

# Let me check what MIPS instruction contains offset 0x92936
# 0x92936 is not 4-byte aligned (0x92936 % 4 = 2)
# So it's NOT a MIPS instruction boundary. It's data embedded between instructions.
# Let me check the surrounding instructions.

Write-Host ""
Write-Host "=== Instructions around 0x92936 ==="
# 0x92936 is at file offset 0x92936
# Nearest 4-byte boundary: 0x92934 and 0x92938
$baseOff = 0x92934 - 32  # start 32 bytes before
for ($i = $baseOff; $i -lt ($baseOff + 80); $i += 4) {
    if ($i -lt 0x800 -or $i + 3 -ge $bytes.Length) { continue }
    $val = [BitConverter]::ToUInt32($bytes, $i)
    $ram = $loadAddr + $i - 0x800
    $op = $val -shr 26
    $imm = $val -band 0xFFFF
    $immS = if ($imm -ge 0x8000) { $imm - 0x10000 } else { $imm }
    $rs = ($val -shr 21) -band 0x1F; $rt = ($val -shr 16) -band 0x1F
    $rn = @('zero','at','v0','v1','a0','a1','a2','a3','t0','t1','t2','t3','t4','t5','t6','t7','s0','s1','s2','s3','s4','s5','s6','s7','t8','t9','k0','k1','gp','sp','fp','ra')
    $rsn=$rn[$rs]; $rtn=$rn[$rt]
    $d = ''
    if ($val -eq 0) { $d = 'nop' }
    elseif ($op -eq 0x09) { $d = "addiu $rtn,$rsn,$immS" }
    elseif ($op -eq 0x0F) { $d = "lui $rtn,0x$($imm.ToString('X4'))" }
    elseif ($op -eq 0x0D) { $d = "ori $rtn,$rsn,0x$($imm.ToString('X4'))" }
    elseif ($op -eq 0x23) { $d = "lw $rtn,0x$($imm.ToString('X4'))($rsn)" }
    elseif ($op -eq 0x24) { $d = "lbu $rtn,0x$($imm.ToString('X4'))($rsn)" }
    elseif ($op -eq 0x28) { $d = "sb $rtn,0x$($imm.ToString('X4'))($rsn)" }
    elseif ($op -eq 0x2B) { $d = "sw $rtn,0x$($imm.ToString('X4'))($rsn)" }
    elseif ($op -eq 0x03) { $t2=($val -band 0x3FFFFFF)-shl 2; $d="jal 0x$($t2.ToString('X8'))" }
    elseif ($op -eq 0x02) { $t2=($val -band 0x3FFFFFF)-shl 2; $d="j 0x$($t2.ToString('X8'))" }
    else { $d="op=0x$($op.ToString('X2'))" }
    # Show raw bytes too
    $b0 = $bytes[$i]; $b1 = $bytes[$i+1]; $b2 = $bytes[$i+2]; $b3 = $bytes[$i+3]
    $marker = ''
    if ($i -le 0x92936 -and ($i + 4) -gt 0x92936) { $marker = ' <<< contains patched byte' }
    Write-Host ("  0x{0:X5} R{1:X8}: {2:X2}{3:X2}{4:X2}{5:X2} = 0x{6:X8}  {7}{8}" -f $i, $ram, $b0, $b1, $b2, $b3, $val, $d, $marker)
}
