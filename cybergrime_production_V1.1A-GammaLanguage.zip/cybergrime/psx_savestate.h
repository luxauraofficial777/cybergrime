#pragma once

// ============================================================================
// PSX Save State System — Full snapshot/restore of emulator state
// Serializes CPU registers, RAM, BIOS, scratchpad, hardware registers,
// GTE, GPU, SPU, MDEC, CD-ROM state, and DMA to a binary file.
// Header-only, dependency-free.
// ============================================================================

#include <cstdint>
#include <cstdio>
#include <cstring>
#include <string>

// Magic header for save state files
static constexpr uint32_t SAVE_STATE_MAGIC = 0x50535853; // "SXPS"
static constexpr uint32_t SAVE_STATE_VERSION = 1;

struct SaveStateHeader {
    uint32_t magic;
    uint32_t version;
    uint32_t cpu_size;
    uint32_t ram_size;
    uint32_t bios_size;
    uint32_t scratchpad_size;
    uint32_t hw_regs_size;
    uint32_t gte_size;
    uint32_t gpu_state_size;
    uint32_t spu_state_size;
    uint32_t cdrom_state_size;
    uint32_t mdec_state_size;
    uint32_t total_size;
    uint64_t instruction_count;
    uint64_t vblank_count;
    char profile_name[64];
};

class PSXSaveState {
public:
    // Save state to file
    static bool save(const char* filename,
                     const void* cpu_state, uint32_t cpu_size,
                     const void* ram, uint32_t ram_size,
                     const void* bios, uint32_t bios_size,
                     const void* scratchpad, uint32_t scratchpad_size,
                     const void* hw_regs, uint32_t hw_regs_size,
                     const void* gte_state, uint32_t gte_size,
                     const void* gpu_state, uint32_t gpu_state_size,
                     const void* spu_state, uint32_t spu_state_size,
                     const void* cdrom_state, uint32_t cdrom_state_size,
                     const void* mdec_state, uint32_t mdec_state_size,
                     uint64_t instruction_count,
                     uint64_t vblank_count,
                     const char* profile_name) {

        FILE* f = fopen(filename, "wb");
        if (!f) return false;

        SaveStateHeader hdr;
        memset(&hdr, 0, sizeof(hdr));
        hdr.magic = SAVE_STATE_MAGIC;
        hdr.version = SAVE_STATE_VERSION;
        hdr.cpu_size = cpu_size;
        hdr.ram_size = ram_size;
        hdr.bios_size = bios_size;
        hdr.scratchpad_size = scratchpad_size;
        hdr.hw_regs_size = hw_regs_size;
        hdr.gte_size = gte_size;
        hdr.gpu_state_size = gpu_state_size;
        hdr.spu_state_size = spu_state_size;
        hdr.cdrom_state_size = cdrom_state_size;
        hdr.mdec_state_size = mdec_state_size;
        hdr.total_size = sizeof(hdr) + cpu_size + ram_size + bios_size +
                         scratchpad_size + hw_regs_size + gte_size +
                         gpu_state_size + spu_state_size + cdrom_state_size +
                         mdec_state_size;
        hdr.instruction_count = instruction_count;
        hdr.vblank_count = vblank_count;
        if (profile_name) {
            strncpy(hdr.profile_name, profile_name, sizeof(hdr.profile_name) - 1);
        }

        // Write header
        if (fwrite(&hdr, sizeof(hdr), 1, f) != 1) { fclose(f); return false; }

        // Write sections in order
        if (cpu_size && fwrite(cpu_state, 1, cpu_size, f) != cpu_size) { fclose(f); return false; }
        if (ram_size && fwrite(ram, 1, ram_size, f) != ram_size) { fclose(f); return false; }
        if (bios_size && fwrite(bios, 1, bios_size, f) != bios_size) { fclose(f); return false; }
        if (scratchpad_size && fwrite(scratchpad, 1, scratchpad_size, f) != scratchpad_size) { fclose(f); return false; }
        if (hw_regs_size && fwrite(hw_regs, 1, hw_regs_size, f) != hw_regs_size) { fclose(f); return false; }
        if (gte_size && fwrite(gte_state, 1, gte_size, f) != gte_size) { fclose(f); return false; }
        if (gpu_state_size && fwrite(gpu_state, 1, gpu_state_size, f) != gpu_state_size) { fclose(f); return false; }
        if (spu_state_size && fwrite(spu_state, 1, spu_state_size, f) != spu_state_size) { fclose(f); return false; }
        if (cdrom_state_size && fwrite(cdrom_state, 1, cdrom_state_size, f) != cdrom_state_size) { fclose(f); return false; }
        if (mdec_state_size && fwrite(mdec_state, 1, mdec_state_size, f) != mdec_state_size) { fclose(f); return false; }

        fclose(f);
        return true;
    }

    // Load state from file
    static bool load(const char* filename,
                     void* cpu_state, uint32_t cpu_size,
                     void* ram, uint32_t ram_size,
                     void* bios, uint32_t bios_size,
                     void* scratchpad, uint32_t scratchpad_size,
                     void* hw_regs, uint32_t hw_regs_size,
                     void* gte_state, uint32_t gte_size,
                     void* gpu_state, uint32_t gpu_state_size,
                     void* spu_state, uint32_t spu_state_size,
                     void* cdrom_state, uint32_t cdrom_state_size,
                     void* mdec_state, uint32_t mdec_state_size,
                     uint64_t* instruction_count = nullptr,
                     uint64_t* vblank_count = nullptr,
                     char* profile_name = nullptr) {

        FILE* f = fopen(filename, "rb");
        if (!f) return false;

        SaveStateHeader hdr;
        if (fread(&hdr, sizeof(hdr), 1, f) != 1) { fclose(f); return false; }

        if (hdr.magic != SAVE_STATE_MAGIC) { fclose(f); return false; }
        if (hdr.version != SAVE_STATE_VERSION) { fclose(f); return false; }

        // Verify sizes match
        if (hdr.cpu_size != cpu_size || hdr.ram_size != ram_size) {
            fclose(f);
            return false;
        }

        // Read sections
        if (cpu_size && fread(cpu_state, 1, cpu_size, f) != cpu_size) { fclose(f); return false; }
        if (ram_size && fread(ram, 1, ram_size, f) != ram_size) { fclose(f); return false; }
        if (bios_size && fread(bios, 1, bios_size, f) != bios_size) { fclose(f); return false; }
        if (scratchpad_size && fread(scratchpad, 1, scratchpad_size, f) != scratchpad_size) { fclose(f); return false; }
        if (hw_regs_size && fread(hw_regs, 1, hw_regs_size, f) != hw_regs_size) { fclose(f); return false; }
        if (gte_size && fread(gte_state, 1, gte_size, f) != gte_size) { fclose(f); return false; }
        if (gpu_state_size && fread(gpu_state, 1, gpu_state_size, f) != gpu_state_size) { fclose(f); return false; }
        if (spu_state_size && fread(spu_state, 1, spu_state_size, f) != spu_state_size) { fclose(f); return false; }
        if (cdrom_state_size && fread(cdrom_state, 1, cdrom_state_size, f) != cdrom_state_size) { fclose(f); return false; }
        if (mdec_state_size && fread(mdec_state, 1, mdec_state_size, f) != mdec_state_size) { fclose(f); return false; }

        if (instruction_count) *instruction_count = hdr.instruction_count;
        if (vblank_count) *vblank_count = hdr.vblank_count;
        if (profile_name) {
            memcpy(profile_name, hdr.profile_name, sizeof(hdr.profile_name));
            profile_name[sizeof(hdr.profile_name) - 1] = '\0';
        }

        fclose(f);
        return true;
    }

    // Get info about a save state without loading it
    static bool get_info(const char* filename, SaveStateHeader* out_hdr) {
        FILE* f = fopen(filename, "rb");
        if (!f) return false;
        bool ok = (fread(out_hdr, sizeof(SaveStateHeader), 1, f) == 1);
        fclose(f);
        return ok && out_hdr->magic == SAVE_STATE_MAGIC;
    }
};
