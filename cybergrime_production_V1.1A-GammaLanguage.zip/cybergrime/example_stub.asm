# Example runtime patch: set CD status flags and return via ChangeTh(0)
# This is the equivalent of the bubble-gum stub, expressed as readable MIPS.

    lui   $t0, 0x800B
    ori   $t1, $zero, 2
    sb    $t1, 0x9164($t0)
    ori   $t1, $zero, 1
    sb    $t1, 0x91CC($t0)
    sb    $t1, 0x91CE($t0)
    ori   $a0, $zero, 0
    ori   $t1, $zero, 0x10
    ori   $t2, $zero, 0xB0
    jr    $t2
    nop
