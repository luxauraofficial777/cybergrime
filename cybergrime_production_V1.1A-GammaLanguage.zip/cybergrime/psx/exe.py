"""PS-X EXE parser and code-cave injector."""

import struct
from pathlib import Path
from typing import BinaryIO, Dict, List, Optional, Tuple

import sys
sys.path.insert(0, str(Path(__file__).parent.parent))
from mips import assemble, disassemble  # noqa: E402


class PsxExe:
    """Parse and patch a PS-X EXE loaded from an ISO image."""

    SIG = b"PS-X EXE"
    HEADER_SIZE = 2048

    def __init__(self, iso_path: str, iso_offset: int, pc: int, gp: int,
                 dest: int, text_size: int, initial_sp: int):
        self.iso_path = iso_path
        self.iso_offset = iso_offset
        self.pc = pc
        self.gp = gp
        self.dest = dest
        self.text_size = text_size
        self.initial_sp = initial_sp
        self.code: bytearray = bytearray()

    @property
    def load_addr(self) -> int:
        return self.dest

    @property
    def end_addr(self) -> int:
        return self.dest + self.text_size

    @classmethod
    def from_iso(cls, iso_path: str, exe_lba: int,
                 iso: Optional["IsoIO"] = None) -> "PsxExe":  # noqa: F821
        from .iso import IsoIO
        if iso is None:
            iso = IsoIO(iso_path)
        iso_offset = iso.lba_to_offset(exe_lba)
        with open(iso_path, "rb") as f:
            header = iso.read_sector(f, exe_lba)
        if header[:8] != cls.SIG:
            raise ValueError(f"Invalid PS-X EXE signature at LBA {exe_lba}")
        pc = struct.unpack_from("<I", header, 0x10)[0]
        gp = struct.unpack_from("<I", header, 0x14)[0]
        dest = struct.unpack_from("<I", header, 0x18)[0]
        text_size = struct.unpack_from("<I", header, 0x1C)[0]
        initial_sp = struct.unpack_from("<I", header, 0x30)[0]
        return cls(iso_path, iso_offset, pc, gp, dest, text_size, initial_sp)

    def load_code(self, iso: Optional["IsoIO"] = None) -> None:  # noqa: F821
        from .iso import IsoIO
        if iso is None:
            iso = IsoIO(self.iso_path)
        # EXE code starts in the sector immediately after the header sector.
        # We read 2048-byte payloads sector-by-sector to handle raw 2352 images.
        start_lba = self.iso_offset // iso.sector_size
        code_offset_lba = start_lba + 1
        self.code = bytearray()
        with open(self.iso_path, "rb") as f:
            for i in range((self.text_size + 2047) // 2048):
                self.code.extend(iso.read_sector(f, code_offset_lba + i))
        self.code = self.code[:self.text_size]

    def ram_to_offset(self, addr: int) -> int:
        if not (self.dest <= addr < self.end_addr):
            raise ValueError(f"Address 0x{addr:08X} outside EXE code range 0x{self.dest:08X}-0x{self.end_addr:08X}")
        return addr - self.dest

    def offset_to_ram(self, offset: int) -> int:
        return self.dest + offset

    def read32(self, addr: int) -> int:
        off = self.ram_to_offset(addr)
        return struct.unpack_from("<I", self.code, off)[0]

    def write32(self, addr: int, value: int) -> None:
        off = self.ram_to_offset(addr)
        struct.pack_into("<I", self.code, off, value & 0xFFFFFFFF)

    def read16(self, addr: int) -> int:
        off = self.ram_to_offset(addr)
        return struct.unpack_from("<H", self.code, off)[0]

    def write16(self, addr: int, value: int) -> None:
        off = self.ram_to_offset(addr)
        struct.pack_into("<H", self.code, off, value & 0xFFFF)

    def find_code_caves(self, min_size: int = 64, fill: Optional[int] = None) -> List[Tuple[int, int]]:
        """Return list of (ram_addr, size) for contiguous zero/FF regions."""
        if fill is None:
            patterns = [bytes([0] * 1), bytes([0xFF] * 1)]
        else:
            patterns = [bytes([fill] * 1)]
        caves = []
        i = 0
        n = len(self.code)
        while i < n:
            matched = False
            for p in patterns:
                if self.code[i:i + len(p)] == p:
                    matched = True
                    break
            if matched:
                start = i
                while i < n and self.code[i:i + 1] in patterns:
                    i += 1
                length = i - start
                if length >= min_size:
                    caves.append((self.offset_to_ram(start), length))
            else:
                i += 1
        return caves

    def find_first_cave(self, min_size: int = 64) -> Optional[Tuple[int, int]]:
        caves = self.find_code_caves(min_size)
        return caves[0] if caves else None

    def inject_code(self, asm_text: str, hook_addr: int,
                    hook_instr: str = "jal") -> int:
        """Assemble asm_text, place it in a code cave, and hook hook_addr to it."""
        words, _ = assemble(asm_text, base_addr=hook_addr)
        patch_size = len(words) * 4

        cave = self.find_first_cave(patch_size + 8)
        if cave is None:
            raise RuntimeError(f"No code cave large enough for {patch_size} bytes")
        cave_addr, cave_size = cave

        # Write assembled patch bytes into the cave
        patch_bytes = b"".join(struct.pack("<I", w) for w in words)
        off = self.ram_to_offset(cave_addr)
        self.code[off:off + len(patch_bytes)] = patch_bytes

        # Hook the original address
        if hook_instr == "jal":
            # JAL opcode = 0x03; encode 26-bit word address within the same 256 MB region
            target = cave_addr
            word = (0x03 << 26) | ((target >> 2) & 0x03FFFFFF)
        elif hook_instr == "j":
            # J opcode = 0x02
            target = cave_addr
            word = (0x02 << 26) | ((target >> 2) & 0x03FFFFFF)
        else:
            raise ValueError(f"Unsupported hook instruction: {hook_instr}")
        self.write32(hook_addr, word)

        return cave_addr

    def patch_jal(self, addr: int, new_target: int) -> None:
        """Redirect an existing JAL at addr to new_target (must be same 256MB region)."""
        word = (0x03 << 26) | ((new_target >> 2) & 0x03FFFFFF)
        self.write32(addr, word)

    def disasm_region(self, addr: int, count: int) -> List[Tuple[int, str]]:
        off = self.ram_to_offset(addr)
        data = bytes(self.code[off:off + count * 4])
        return disassemble(data, addr)

    def save(self, iso: Optional["IsoIO"] = None) -> None:  # noqa: F821
        """Write modified code back into the ISO. Does NOT regenerate EDC/ECC."""
        from .iso import IsoIO
        if iso is None:
            iso = IsoIO(self.iso_path)
        start_lba = self.iso_offset // iso.sector_size
        code_offset_lba = start_lba + 1
        with open(self.iso_path, "r+b") as f:
            for i in range((self.text_size + 2047) // 2048):
                chunk = bytes(self.code[i * 2048:(i + 1) * 2048])
                if len(chunk) < 2048:
                    chunk = chunk + bytes(2048 - len(chunk))
                iso.write_sector(f, code_offset_lba + i, chunk)

    def __repr__(self) -> str:
        return (f"PsxExe(iso_offset={self.iso_offset}, pc=0x{self.pc:08X}, "
                f"dest=0x{self.dest:08X}, text_size=0x{self.text_size:X})")
