import struct

def disasm_mips(word, addr):
    op = (word >> 26) & 0x3F
    rs = (word >> 21) & 0x1F
    rt = (word >> 16) & 0x1F
    rd = (word >> 11) & 0x1F
    shamt = (word >> 6) & 0x1F
    funct = word & 0x3F
    imm = word & 0xFFFF
    simm = imm if imm < 0x8000 else imm - 0x10000
    target = word & 0x3FFFFFF
    
    rn = ['zero','at','v0','v1','a0','a1','a2','a3',
          't0','t1','t2','t3','t4','t5','t6','t7',
          's0','s1','s2','s3','s4','s5','s6','s7',
          't8','t9','k0','k1','gp','sp','fp','ra']
    
    if word == 0: return "nop"
    if op == 0:
        if funct == 0x20: return f"add {rn[rd]},{rn[rs]},{rn[rt]}"
        if funct == 0x21: return f"addu {rn[rd]},{rn[rs]},{rn[rt]}"
        if funct == 0x24: return f"and {rn[rd]},{rn[rs]},{rn[rt]}"
        if funct == 0x08: return f"jr {rn[rs]}"
        if funct == 0x09: return f"jalr {rn[rd]},{rn[rs]}"
        if funct == 0x0C: return f"syscall"
        if funct == 0x10: return f"mfhi {rn[rd]}"
        if funct == 0x12: return f"mflo {rn[rd]}"
        if funct == 0x00: return f"sll {rn[rd]},{rn[rt]},{shamt}"
        if funct == 0x02: return f"srl {rn[rd]},{rn[rt]},{shamt}"
        if funct == 0x25: return f"or {rn[rd]},{rn[rs]},{rn[rt]}"
        if funct == 0x2A: return f"slt {rn[rd]},{rn[rs]},{rn[rt]}"
        if funct == 0x2B: return f"sltu {rn[rd]},{rn[rs]},{rn[rt]}"
        return f"special 0x{funct:02X}"
    if op == 0x01: return f"regimm rt={rt} rs={rn[rs]} imm={simm}"
    if op == 0x02: return f"j 0x{(addr & 0xF0000000) | (target << 2):08X}"
    if op == 0x03: return f"jal 0x{(addr & 0xF0000000) | (target << 2):08X}"
    if op == 0x04: return f"beq {rn[rs]},{rn[rt]},0x{addr+4+(simm<<2):08X}"
    if op == 0x05: return f"bne {rn[rs]},{rn[rt]},0x{addr+4+(simm<<2):08X}"
    if op == 0x06: return f"blez {rn[rs]},0x{addr+4+(simm<<2):08X}"
    if op == 0x07: return f"bgtz {rn[rs]},0x{addr+4+(simm<<2):08X}"
    if op == 0x08: return f"addi {rn[rt]},{rn[rs]},{simm}"
    if op == 0x09: return f"addiu {rn[rt]},{rn[rs]},{simm}"
    if op == 0x0A: return f"slti {rn[rt]},{rn[rs]},{simm}"
    if op == 0x0B: return f"sltiu {rn[rt]},{rn[rs]},{simm}"
    if op == 0x0C: return f"andi {rn[rt]},{rn[rs]},0x{imm:04X}"
    if op == 0x0D: return f"ori {rn[rt]},{rn[rs]},0x{imm:04X}"
    if op == 0x0E: return f"xori {rn[rt]},{rn[rs]},0x{imm:04X}"
    if op == 0x0F: return f"lui {rn[rt]},0x{imm:04X}"
    if op == 0x20: return f"lb {rn[rt]},{simm}({rn[rs]})"
    if op == 0x21: return f"lh {rn[rt]},{simm}({rn[rs]})"
    if op == 0x23: return f"lw {rn[rt]},{simm}({rn[rs]})"
    if op == 0x24: return f"lbu {rn[rt]},{simm}({rn[rs]})"
    if op == 0x28: return f"sb {rn[rt]},{simm}({rn[rs]})"
    if op == 0x29: return f"sh {rn[rt]},{simm}({rn[rs]})"
    if op == 0x2B: return f"sw {rn[rt]},{simm}({rn[rs]})"
    if op == 0x10: return f"cop0 {word:08X}"
    if op == 0x40: return f"mfc0 {rn[rt]},c{rd}"
    if op == 0x42: return f"rfe" if funct == 0x10 else f"cop0 funct=0x{funct:02X}"
    return f"op=0x{op:02X} {word:08X}"

f = open(r'..\duckstation\bios\JP\scph1001.bin', 'rb')
# Disassemble around 0x378 (the loop address)
start = 0x31C
f.seek(start)
data = f.read(200)
f.close()

for i in range(len(data) // 4):
    addr = start + i * 4
    word = struct.unpack_from('<I', data, i * 4)[0]
    print(f'0xBFC{addr:05X}: 0x{word:08X}  {disasm_mips(word, 0xBFC00000 + addr)}')
