#!/usr/bin/env python3
"""Dump ISO 9660 directory from built disc to verify HBD and EXE entries."""
import struct, sys

def read_sector(f, lba, size=2048):
    f.seek(lba * 2352 + 24)  # Mode 2 form 1: skip 24-byte header
    return f.read(size)

def parse_dir(data, indent=0):
    off = 0
    while off < len(data):
        rec_len = data[off]
        if rec_len == 0:
            break
        lba_le = struct.unpack_from('<I', data, off+2)[0]
        lba_be = struct.unpack_from('>I', data, off+6)[0]
        size_le = struct.unpack_from('<I', data, off+10)[0]
        size_be = struct.unpack_from('>I', data, off+14)[0]
        flags = data[off+25]
        name_len = data[off+32]
        name = data[off+33:off+33+name_len]
        pad = "  " * indent
        print(f"{pad}Record: len={rec_len} LBA={lba_le} size={size_le} flags=0x{flags:02X} name={name}")
        off += rec_len

def main():
    disc = sys.argv[1] if len(sys.argv) > 1 else r"C:\LuxAura\VoidWalkers_Project\DQLOSTTRANSLATION\build_staging\dq4_reverse_a.bin"
    with open(disc, 'rb') as f:
        # PVD at LBA 16
        pvd = read_sector(f, 16)
        print(f"PVD signature: {pvd[0:7]}")
        vol_id = pvd[40:72].decode('ascii', errors='replace').strip()
        print(f"Volume ID: {vol_id}")

        # Root directory record is at PVD offset 156
        root_rec = pvd[156:156+34]
        root_lba = struct.unpack_from('<I', root_rec, 2)[0]
        root_size = struct.unpack_from('<I', root_rec, 10)[0]
        print(f"Root directory: LBA={root_lba} size={root_size}")

        # Read root directory
        root_data = read_sector(f, root_lba, root_size)
        print("\n=== Root Directory ===")
        parse_dir(root_data)

        # Also check the path table
        pt_lba = struct.unpack_from('<I', pvd, 132)[0]
        pt_size = struct.unpack_from('<I', pvd, 132+4)[0]
        print(f"\nPath table: LBA={pt_lba} size={pt_size}")

        # Read SYSTEM.CNF area (usually around LBA 150-153)
        print("\n=== SYSTEM.CNF (LBA 150) ===")
        cnf = read_sector(f, 150)
        # Find readable text
        text = cnf.decode('ascii', errors='replace')
        for line in text.split('\n'):
            line = line.strip()
            if line and any(c.isalpha() for c in line):
                print(f"  {line}")

        # Check EXE at LBA 24
        print("\n=== EXE header at LBA 24 ===")
        exe = read_sector(f, 24)
        print(f"  Magic: {exe[0:8]}")
        load_addr = struct.unpack_from('<I', exe, 0x18)[0]
        pc0 = struct.unpack_from('<I', exe, 0x10)[0]
        text_sz = struct.unpack_from('<I', exe, 0x1C)[0]
        print(f"  Load addr: 0x{load_addr:08X}  PC0: 0x{pc0:08X}  Text size: 0x{text_sz:08X}")

        # Check HBD at LBA 356
        print("\n=== HBD at LBA 356 ===")
        hbd = read_sector(f, 356)
        print(f"  First 32 bytes: {hbd[:32].hex()}")

        # Verify FMV stubs in EXE
        print("\n=== FMV stub verification ===")
        exe_full = read_sector(f, 24, 2048)
        # Read more sectors to get full EXE
        f.seek(24 * 2352 + 24)
        exe_full = f.read(678496)
        load_addr = struct.unpack_from('<I', exe_full, 0x18)[0]
        for ram, name in [(0x8008AEF4, "fmv1"), (0x8008CAD0, "fmv2")]:
            off = ram - load_addr + 0x800
            if off + 12 <= len(exe_full):
                words = struct.unpack_from('<III', exe_full, off)
                expected = (0x24020000, 0x03E00008, 0x00000000)
                match = words == expected
                print(f"  {name} at RAM 0x{ram:08X} (offset 0x{off:X}): {'STUB OK' if match else 'NOT STUBBED'} -> {words[0]:08X} {words[1]:08X} {words[2]:08X}")

if __name__ == '__main__':
    main()
