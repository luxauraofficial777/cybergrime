#pragma once

// ============================================================================
// PSX XA-ADPCM — Streaming Audio Decoder for CD-ROM Form 2 sectors
// Decodes 4-bit XA-ADPCM (mono/stereo, 37.8kHz) and feeds PCM to SPU.
// Header-only, dependency-free.
// Adapted from Nocash PSXspec and DuckStation XA decoder.
// ============================================================================

#include <cstdint>
#include <cstring>

class PSX_XA {
public:
    static constexpr int XA_SECTOR_SIZE = 2324;    // Form 2 data payload
    static constexpr int XA_SAMPLES_PER_SECTOR = 18 * 28 * 8; // 4032 samples
    static constexpr int XA_BLOCK_SIZE = 128;      // 8 sub-blocks of 128 bytes

    // XA-ADPCM filter coefficients (8 sets, 4-bit prediction)
    static const int32_t xa_coeffs[8][2];

    // Decode state
    struct XAChannel {
        int32_t old[2];      // Previous samples for prediction
        int32_t older[2];    // Older samples
        bool initialized;
    };

    XAChannel channels[2];  // Left/right (stereo) or single (mono)
    bool is_stereo;
    bool is_18900hz;        // Sample rate flag
    int8_t file_num;        // XA file number filter
    int8_t channel_num;     // XA channel filter

    // Output buffer
    int16_t pcm_left[XA_SAMPLES_PER_SECTOR];
    int16_t pcm_right[XA_SAMPLES_PER_SECTOR];
    int pcm_count;

    PSX_XA() { reset(); }

    void reset() {
        memset(channels, 0, sizeof(channels));
        is_stereo = false;
        is_18900hz = false;
        file_num = -1;
        channel_num = -1;
        memset(pcm_left, 0, sizeof(pcm_left));
        memset(pcm_right, 0, sizeof(pcm_right));
        pcm_count = 0;
    }

    // Set XA filter (for CdRead with XA filtering)
    void set_filter(int file, int channel) {
        file_num = (int8_t)file;
        channel_num = (int8_t)channel;
    }

    // Check if a CD-ROM sector matches our XA filter
    bool matches_filter(uint8_t subheader_file, uint8_t subheader_channel) {
        if (file_num < 0 && channel_num < 0) return true; // No filter
        if (file_num >= 0 && subheader_file != file_num) return false;
        if (channel_num >= 0 && subheader_channel != channel_num) return false;
        return true;
    }

    // Decode an XA-ADPCM sector (Form 2, 2324 bytes payload)
    void decode_sector(const uint8_t* sector_data, uint32_t size) {
        if (size < XA_SECTOR_SIZE) return;

        pcm_count = 0;

        // XA subheader is at offset 0 in Form 2 data
        // uint8_t file_num = sector_data[0];
        // uint8_t channel_num = sector_data[1];
        // uint8_t submode = sector_data[2];
        // uint8_t coding = sector_data[3];

        uint8_t coding = sector_data[3];
        is_stereo = (coding >> 0) & 1;
        is_18900hz = (coding >> 2) & 1;
        uint8_t bits_per_sample = (coding >> 4) & 3; // 0=4-bit, 1=8-bit

        // Reset channel state
        for (int c = 0; c < 2; c++) {
            channels[c].old[0] = 0;
            channels[c].old[1] = 0;
            channels[c].older[0] = 0;
            channels[c].older[1] = 0;
            channels[c].initialized = false;
        }

        // 18 sound groups, each 128 bytes
        // Each group: 8 bytes subheader + 112 bytes data + 8 bytes unused
        // Actually: each 128-byte group = 8 sub-blocks of 14 bytes + 4 bytes header
        // Format: [subheader 4 bytes][data 112 bytes][padding 12 bytes] per 128-byte group

        for (int group = 0; group < 18; group++) {
            const uint8_t* group_data = sector_data + 4 + group * 128;

            // 8 sub-blocks per group
            for (int sb = 0; sb < 8; sb++) {
                // Each sub-block: 4-bit predictor/shift byte + 14 data bytes (28 nibbles)
                // Layout: first 4 bytes are predictors for 8 sub-blocks (interleaved)
                // Actually XA format: 8 sub-blocks, each has a 1-byte header at offset sb
                // then 14 bytes of data at offset 16 + sb*14

                // Simplified XA decoding:
                uint8_t header = group_data[sb];
                uint8_t shift = header & 0xF;
                uint8_t filter = (header >> 4) & 0xF;

                if (filter > 7) filter = 7;
                if (shift > 12) shift = 12;

                // Data for this sub-block starts at offset 16 + sb*14
                const uint8_t* data = group_data + 16 + sb * 14;

                int num_channels = is_stereo ? 2 : 1;
                int samples_per_channel = 28 / num_channels;

                for (int s = 0; s < 28; s++) {
                    uint8_t nibble;
                    if (s < 14) {
                        nibble = data[s] & 0xF;
                    } else {
                        nibble = (data[s - 14] >> 4) & 0xF;
                    }

                    // Sign-extend 4-bit
                    int32_t sample = (int32_t)(int8_t)(nibble << 4) >> shift;

                    // Determine channel (interleaved for stereo)
                    int ch = is_stereo ? (s & 1) : 0;

                    // Apply prediction filter
                    if (channels[ch].initialized) {
                        sample += (xa_coeffs[filter][0] * channels[ch].old[0]) >> 6;
                        sample += (xa_coeffs[filter][1] * channels[ch].older[0]) >> 6;
                    }
                    channels[ch].initialized = true;

                    // Clamp
                    if (sample > 32767) sample = 32767;
                    if (sample < -32768) sample = -32768;

                    // Output
                    if (is_stereo) {
                        if (s & 1) {
                            pcm_right[pcm_count] = (int16_t)sample;
                        } else {
                            pcm_left[pcm_count] = (int16_t)sample;
                            // Don't increment yet for stereo — wait for right
                        }
                        if (s & 1) pcm_count++;
                    } else {
                        pcm_left[pcm_count] = (int16_t)sample;
                        pcm_right[pcm_count] = (int16_t)sample;
                        pcm_count++;
                    }

                    // Shift history
                    channels[ch].older[0] = channels[ch].old[0];
                    channels[ch].old[0] = sample;
                }
            }
        }
    }

    // Get decoded PCM for SPU mixing
    void get_pcm(int16_t* left, int16_t* right, int& count) {
        *left = *pcm_left;
        *right = *pcm_right;
        count = pcm_count;
    }

    // Check if sector is XA-ADPCM (submode bit 2 = audio)
    static bool is_xa_sector(uint8_t submode) {
        return (submode & 0x04) != 0; // Audio bit
    }
};

// XA-ADPCM filter coefficients (from PSX spec)
const int32_t PSX_XA::xa_coeffs[8][2] = {
    {   0,   0 },
    {  60,   0 },
    { 115, -52 },
    {  98, -55 },
    { 122, -60 },
    {  67, -32 },
    {  84, -38 },
    {  82, -37 },
};
