#!/usr/bin/env python3
"""Test the extended MIPS assembler with CP0 instructions."""
import sys
import struct
sys.path.insert(0, r"c:\LuxAura\VoidWalkers_Project\DQLOSTTRANSLATION\cybergrime")
from mips import assemble, disassemble

text = """
.set noreorder
.global _start
.org 0xbfc00000

_start:
    lui   $t0, 0x0013
    ori   $t0, $t0, 0x243F
    mtc0  $t0, $12
    li    $t0, 0
    mtc0  $t0, $13
    nop
    j     0xBFC00150
    nop
"""

words, labels = assemble(text, 0xBFC00000)
data = b"".join(struct.pack("<I", w) for w in words)

print("Labels:", labels)
print("Words:", [f"0x{w:08X}" for w in words])
print()
for (addr, txt), w in zip(disassemble(data, 0xBFC00000), words):
    print(f"0x{addr:08X}: 0x{w:08X}  {txt}")

# Verify mtc0 encoding
# mtc0 $t0, $12: COP0(0x10) | MTC0_rs(0x04)<<21 | rt(8)<<16 | rd(12)<<11
expected_mtc0 = (0x10 << 26) | (0x04 << 21) | (8 << 16) | (12 << 11)
assert words[2] == expected_mtc0, f"mtc0 encoding wrong: 0x{words[2]:08X} != 0x{expected_mtc0:08X}"
print("\nCP0 encoding test PASSED!")
