#!/usr/bin/env python3
"""
Verify what's at LBA 146621 on both DW7 and DQ4 discs.
This is the BCD 32:34:71 seek target — we need to know if it's
inside the HBD range on both discs, and what data is there.
"""
import os

DW7_DISC = r"C:\LuxAura\VoidWalkers_Project\DQLOSTTRANSLATION\DW7D1\DW7D1.bin"
DQ4_DISC = r"C:\LuxAura\VoidWalkers_Project\DQLOSTTRANSLATION\Dragon Quest IV - Michibikareshi Mono Tachi (Japan).bin"
SECTOR_SIZE = 2352
USER_SIZE = 2048

def read_sector(disc_path, lba):
    with open(disc_path, 'rb') as f:
        f.seek(lba * SECTOR_SIZE)
        raw = f.read(SECTOR_SIZE)
    return raw

def main():
    target_lba = 146621
    
    print(f"Target LBA: {target_lba} (BCD 32:34:71)")
    print(f"  Byte offset on disc: {target_lba * SECTOR_SIZE:,}")
    print()
    
    # DW7 HBD range
    dw7_hbd_start = 354
    dw7_hbd_size = 618563584
    dw7_hbd_sectors = dw7_hbd_size // USER_SIZE
    dw7_hbd_end = dw7_hbd_start + dw7_hbd_sectors - 1
    dw7_hbd_offset = target_lba - dw7_hbd_start
    
    print(f"DW7 HBD: LBA {dw7_hbd_start}-{dw7_hbd_end} ({dw7_hbd_sectors} sectors)")
    print(f"  LBA {target_lba} is {'INSIDE' if dw7_hbd_start <= target_lba <= dw7_hbd_end else 'OUTSIDE'} HBD")
    print(f"  HBD internal offset: sector {dw7_hbd_offset} (byte {dw7_hbd_offset * USER_SIZE:,})")
    print()
    
    # DQ4 HBD range (native)
    dq4_hbd_start = 362
    dq4_hbd_size = 319436800
    dq4_hbd_sectors = dq4_hbd_size // USER_SIZE
    dq4_hbd_end = dq4_hbd_start + dq4_hbd_sectors - 1
    dq4_hbd_offset_native = target_lba - dq4_hbd_start
    
    print(f"DQ4 HBD (native): LBA {dq4_hbd_start}-{dq4_hbd_end} ({dq4_hbd_sectors} sectors)")
    print(f"  LBA {target_lba} is {'INSIDE' if dq4_hbd_start <= target_lba <= dq4_hbd_end else 'OUTSIDE'} HBD")
    if dq4_hbd_start <= target_lba <= dq4_hbd_end:
        print(f"  HBD internal offset: sector {dq4_hbd_offset_native} (byte {dq4_hbd_offset_native * USER_SIZE:,})")
    print()
    
    # DQ4 HBD at LBA 354 (proposed)
    dq4_hbd_end_354 = 354 + dq4_hbd_sectors - 1
    dq4_hbd_offset_354 = target_lba - 354
    
    print(f"DQ4 HBD (at LBA 354): LBA 354-{dq4_hbd_end_354} ({dq4_hbd_sectors} sectors)")
    print(f"  LBA {target_lba} is {'INSIDE' if 354 <= target_lba <= dq4_hbd_end_354 else 'OUTSIDE'} HBD")
    print(f"  HBD internal offset: sector {dq4_hbd_offset_354} (byte {dq4_hbd_offset_354 * USER_SIZE:,})")
    print()
    
    # Read actual data at LBA 146621 on both discs
    print("Data at LBA 146621 on DW7 disc:")
    dw7_sec = read_sector(DW7_DISC, target_lba)
    print(f"  Mode: {dw7_sec[15]}")
    print(f"  Submode: 0x{dw7_sec[18]:02X}")
    print(f"  User data (first 32 bytes): {dw7_sec[24:56].hex()}")
    print()
    
    print("Data at LBA 146621 on DQ4 disc:")
    dq4_sec = read_sector(DQ4_DISC, target_lba)
    print(f"  Mode: {dq4_sec[15]}")
    print(f"  Submode: 0x{dq4_sec[18]:02X}")
    print(f"  User data (first 32 bytes): {dq4_sec[24:56].hex()}")
    print()
    
    # Also check what's at the same HBD-internal offset on DQ4
    # DW7 HBD offset = 146621 - 354 = 146267
    # DQ4 HBD at LBA 354: same offset = LBA 354 + 146267 = 146621 (same!)
    # DQ4 HBD native: LBA 362 + 146267 = 146629
    dq4_native_equiv = dq4_hbd_start + dw7_hbd_offset
    print(f"DQ4 native equivalent (same HBD offset {dw7_hbd_offset}): LBA {dq4_native_equiv}")
    if dq4_native_equiv <= dq4_hbd_end:
        dq4_equiv_sec = read_sector(DQ4_DISC, dq4_native_equiv)
        print(f"  Mode: {dq4_equiv_sec[15]}")
        print(f"  Submode: 0x{dq4_equiv_sec[18]:02X}")
        print(f"  User data (first 32 bytes): {dq4_equiv_sec[24:56].hex()}")
    else:
        print(f"  OUTSIDE DQ4 HBD range!")
    print()
    
    # Check if 146621 is within DQ4 disc at all
    dq4_sz = os.path.getsize(DQ4_DISC)
    dq4_total = dq4_sz // SECTOR_SIZE
    print(f"DQ4 disc total sectors: {dq4_total}")
    print(f"LBA 146621 within DQ4 disc? {'YES' if target_lba < dq4_total else 'NO'}")
    print(f"DQ4 HBD at LBA 354 ends at LBA {dq4_hbd_end_354}")
    print(f"Space after HBD: {dq4_total - dq4_hbd_end_354 - 1} sectors")
    
    # Key conclusion
    print(f"\n{'='*70}")
    print(f"CONCLUSION")
    print(f"{'='*70}")
    print(f"  BCD 32:34:71 (LBA 146621) seeks to HBD internal offset {dw7_hbd_offset}")
    print(f"  With DQ4 HBD at LBA 354, this offset is within range (< {dq4_hbd_sectors})")
    print(f"  The seek will read DQ4 HBD data at offset {dw7_hbd_offset * USER_SIZE:,} bytes")
    print(f"  No BCD patch needed — the seek lands inside DQ4 HBD automatically")
    print(f"  The data there will be whatever DQ4 has at that HBD offset")
    print(f"  (May or may not be FMV — depends on DQ4's HBD internal structure)")

if __name__ == '__main__':
    main()
