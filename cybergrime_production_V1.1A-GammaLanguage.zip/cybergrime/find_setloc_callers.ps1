$exePath = 'c:\LuxAura\VoidWalkers_Project\DQLOSTTRANSLATION\translation\SLUSP012.06'
$bytes = [System.IO.File]::ReadAllBytes($exePath)
$loadAddr = 0x80017F00

# Search for jal/j to 0x800A20F8 (Setloc trampoline)
# jal 0x800A20F8 = 0x0C028A83E  (target = 0xA20F8 >> 2 = 0x2883E)
# j 0x800A20F8 = 0x08028A83E
$setlocTarget = 0x0A20F8 -shr 2  # = 0x2883E

Write-Host "=== Callers of Setloc trampoline at 0x800A20F8 ==="
for ($i = 0x800; $i -lt $bytes.Length - 3; $i += 4) {
    $insn = [BitConverter]::ToUInt32($bytes, $i)
    $opcode = $insn -shr 26
    if (($opcode -eq 0x03 -or $opcode -eq 0x02) -and (($insn -band 0x3FFFFFF) -eq $setlocTarget)) {
        $ram = $loadAddr + $i - 0x800
        $type = if ($opcode -eq 0x03) { "jal" } else { "j" }
        # Show context: 8 instructions before the call
        Write-Host ""
        Write-Host "--- $type 0x800A20F8 at RAM 0x$($ram.ToString('X8')) ---"
        for ($k = -8; $k -le 2; $k++) {
            $off2 = $i + $k * 4
            if ($off2 -lt 0x800 -or $off2 + 3 -ge $bytes.Length) { continue }
            $val2 = [BitConverter]::ToUInt32($bytes, $off2)
            $ram2 = $loadAddr + $off2 - 0x800
            $marker = if ($k -eq 0) { " <<<" } else { "" }
            # Simple decode
            $op2 = $val2 -shr 26
            $imm = $val2 -band 0xFFFF
            if ($imm -ge 0x8000) { $immS = $imm - 0x10000 } else { $immS = $imm }
            $rs = ($val2 -shr 21) -band 0x1F
            $rt = ($val2 -shr 16) -band 0x1F
            $regNames = @('zero','at','v0','v1','a0','a1','a2','a3','t0','t1','t2','t3','t4','t5','t6','t7','s0','s1','s2','s3','s4','s5','s6','s7','t8','t9','k0','k1','gp','sp','fp','ra')
            $rsn = $regNames[$rs]; $rtn = $regNames[$rt]
            $d = ''
            if ($op2 -eq 0x09) { $d = "addiu $rtn,$rsn,$immS" }
            elseif ($op2 -eq 0x0F) { $d = "lui $rtn,0x$($imm.ToString('X4'))" }
            elseif ($op2 -eq 0x0D) { $d = "ori $rtn,$rsn,0x$($imm.ToString('X4'))" }
            elseif ($op2 -eq 0x0C) { $d = "andi $rtn,$rsn,0x$($imm.ToString('X4'))" }
            elseif ($op2 -eq 0x23) { $d = "lw $rtn,0x$($imm.ToString('X4'))($rsn)" }
            elseif ($op2 -eq 0x21) { $d = "lh $rtn,0x$($imm.ToString('X4'))($rsn)" }
            elseif ($op2 -eq 0x24) { $d = "lbu $rtn,0x$($imm.ToString('X4'))($rsn)" }
            elseif ($op2 -eq 0x20) { $d = "lb $rtn,0x$($imm.ToString('X4'))($rsn)" }
            elseif ($op2 -eq 0x28) { $d = "sb $rtn,0x$($imm.ToString('X4'))($rsn)" }
            elseif ($op2 -eq 0x2B) { $d = "sw $rtn,0x$($imm.ToString('X4'))($rsn)" }
            elseif ($op2 -eq 0x03) { $t2 = ($val2 -band 0x3FFFFFF) -shl 2; $d = "jal 0x$($t2.ToString('X8'))" }
            elseif ($op2 -eq 0x02) { $t2 = ($val2 -band 0x3FFFFFF) -shl 2; $d = "j 0x$($t2.ToString('X8'))" }
            elseif ($op2 -eq 0x00 -and $val2 -eq 0) { $d = "nop" }
            elseif ($op2 -eq 0x00 -and ($val2 -band 0x3F) -eq 0x08) { $d = "jr $rsn" }
            elseif ($op2 -eq 0x00 -and ($val2 -band 0x3F) -eq 0x21) { $rd = ($val2 -shr 11) -band 0x1F; $d = "addu $($regNames[$rd]),$rsn,$rtn" }
            else { $d = "op=0x$($op2.ToString('X2'))" }
            Write-Host ("  0x{0:X8}: 0x{1:X8}  {2}{3}" -f $ram2, $val2, $d, $marker)
        }
    }
}
