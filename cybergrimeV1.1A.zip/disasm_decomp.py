#!/usr/bin/env python3
"""Disassemble DW7 EXE around decompressor sites to find R-TREEHOOK insertion point."""
import struct, sys

def decode_mips(word):
    """Minimal MIPS I decoder for R/I/J types."""
    op = (word >> 26) & 0x3F
    rs = (word >> 21) & 0x1F
    rt = (word >> 16) & 0x1F
    rd = (word >> 11) & 0x1F
    shamt = (word >> 6) & 0x1F
    funct = word & 0x3F
    imm = word & 0xFFFF
    simm = imm - 0x10000 if imm >= 0x8000 else imm
    target = word & 0x03FFFFFF
    tgt_addr = (target << 2) & 0x0FFFFFFF
    
    regs = ['zero','at','v0','v1','a0','a1','a2','a3',
            't0','t1','t2','t3','t4','t5','t6','t7',
            's0','s1','s2','s3','s4','s5','s6','s7',
            't8','t9','k0','k1','gp','sp','fp','ra']
    
    if op == 0:  # R-type
        if funct == 0x20: return f"add {regs[rd]},{regs[rs]},{regs[rt]}"
        if funct == 0x21: return f"addu {regs[rd]},{regs[rs]},{regs[rt]}"
        if funct == 0x22: return f"sub {regs[rd]},{regs[rs]},{regs[rt]}"
        if funct == 0x23: return f"subu {regs[rd]},{regs[rs]},{regs[rt]}"
        if funct == 0x24: return f"and {regs[rd]},{regs[rs]},{regs[rt]}"
        if funct == 0x25: return f"or {regs[rd]},{regs[rs]},{regs[rt]}"
        if funct == 0x26: return f"xor {regs[rd]},{regs[rs]},{regs[rt]}"
        if funct == 0x27: return f"nor {regs[rd]},{regs[rs]},{regs[rt]}"
        if funct == 0x2A: return f"slt {regs[rd]},{regs[rs]},{regs[rt]}"
        if funct == 0x2B: return f"sltu {regs[rd]},{regs[rs]},{regs[rt]}"
        if funct == 0x00: 
            if word == 0: return "nop"
            return f"sll {regs[rd]},{regs[rt]},{shamt}"
        if funct == 0x02: return f"srl {regs[rd]},{regs[rt]},{shamt}"
        if funct == 0x03: return f"sra {regs[rd]},{regs[rt]},{shamt}"
        if funct == 0x04: return f"sllv {regs[rd]},{regs[rt]},{regs[rs]}"
        if funct == 0x06: return f"srlv {regs[rd]},{regs[rt]},{regs[rs]}"
        if funct == 0x07: return f"srav {regs[rd]},{regs[rt]},{regs[rs]}"
        if funct == 0x08: return f"jr {regs[rs]}"
        if funct == 0x09: return f"jalr {regs[rd]},{regs[rs]}"
        if funct == 0x0C: return f"syscall"
        if funct == 0x10: return f"mfhi {regs[rd]}"
        if funct == 0x12: return f"mflo {regs[rd]}"
        if funct == 0x18: return f"mult {regs[rs]},{regs[rt]}"
        if funct == 0x19: return f"multu {regs[rs]},{regs[rt]}"
        if funct == 0x1A: return f"div {regs[rs]},{regs[rt]}"
        if funct == 0x1B: return f"divu {regs[rs]},{regs[rt]}"
        return f".word 0x{word:08X}"
    
    if op == 0x01:  # REGIMM
        if rt == 0: return f"bltz {regs[rs]},{simm}"
        if rt == 1: return f"bgez {regs[rs]},{simm}"
        return f".word 0x{word:08X}"
    
    if op == 0x02: return f"j 0x{tgt_addr:08X}"
    if op == 0x03: return f"jal 0x{tgt_addr:08X}"
    if op == 0x04: return f"beq {regs[rs]},{regs[rt]},{simm}"
    if op == 0x05: return f"bne {regs[rs]},{regs[rt]},{simm}"
    if op == 0x06: return f"blez {regs[rs]},{simm}"
    if op == 0x07: return f"bgtz {regs[rs]},{simm}"
    if op == 0x08: return f"addi {regs[rt]},{regs[rs]},{simm}"
    if op == 0x09: return f"addiu {regs[rt]},{regs[rs]},{simm}"
    if op == 0x0A: return f"slti {regs[rt]},{regs[rs]},{simm}"
    if op == 0x0B: return f"sltiu {regs[rt]},{regs[rs]},{simm}"
    if op == 0x0C: return f"andi {regs[rt]},{regs[rs]},0x{imm:04X}"
    if op == 0x0D: return f"ori {regs[rt]},{regs[rs]},0x{imm:04X}"
    if op == 0x0E: return f"xori {regs[rt]},{regs[rs]},0x{imm:04X}"
    if op == 0x0F: return f"lui {regs[rt]},0x{imm:04X}"
    if op == 0x20: return f"lb {regs[rt]},{simm}({regs[rs]})"
    if op == 0x21: return f"lh {regs[rt]},{simm}({regs[rs]})"
    if op == 0x23: return f"lw {regs[rt]},{simm}({regs[rs]})"
    if op == 0x24: return f"lbu {regs[rt]},{simm}({regs[rs]})"
    if op == 0x25: return f"lhu {regs[rt]},{simm}({regs[rs]})"
    if op == 0x28: return f"sb {regs[rt]},{simm}({regs[rs]})"
    if op == 0x29: return f"sh {regs[rt]},{simm}({regs[rs]})"
    if op == 0x2B: return f"sw {regs[rt]},{simm}({regs[rs]})"
    return f".word 0x{word:08X}"

def main():
    exe_path = sys.argv[1] if len(sys.argv) > 1 else "../translation/SLUSP012.06_disc_extract.bin"
    
    with open(exe_path, "rb") as f:
        data = f.read()
    
    load_addr = struct.unpack_from("<I", data, 0x18)[0]
    
    # Disassemble around decompressor sites
    # Site 1: file 0x571FC (RAM 0x8006F0FC)
    # Site 2: file 0x57244 (RAM 0x8006F144)  
    # Site 3: file 0x572A4 (RAM 0x8006F1A4)
    # Also look at block loader area before these
    
    regions = [
        (0x57000, 0x57400, "Decompressor area (0x8006E800-0x8006FC00)"),
        (0x56200, 0x56500, "HBD type dispatcher area (0x80056200-0x80056500)"),
    ]
    
    for start_off, end_off, label in regions:
        print(f"\n=== {label} ===")
        print(f"    (file 0x{start_off:X} - 0x{end_off:X})")
        for off in range(start_off, min(end_off, len(data)), 4):
            word = struct.unpack_from("<I", data, off)[0]
            ram = load_addr + off - 0x800
            insn = decode_mips(word)
            # Mark known sites
            marker = ""
            if off == 0x571FC: marker = " <-- SITE 1 lui (tree ptr)"
            elif off == 0x57200: marker = " <-- SITE 1 addiu (tree ptr)"
            elif off == 0x57244: marker = " <-- SITE 2 lui (tree ptr)"
            elif off == 0x57248: marker = " <-- SITE 2 addiu (tree ptr)"
            elif off == 0x572A4: marker = " <-- SITE 3 addiu (root_id)"
            elif off == 0x1AFB8: marker = " <-- offset_b mask"
            print(f"  0x{ram:08X} [{off:05X}] 0x{word:08X}  {insn}{marker}")

if __name__ == "__main__":
    main()
