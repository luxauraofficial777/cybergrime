# Read the full DuckStation log and show ALL lines (not just CDROM)
# Focus on the sequence around the Setloc call
$log = 'C:\LuxAura\VoidWalkers_Project\DuckStation\duckstation.log'
$lines = Get-Content $log

# Find the line with Setloc 32:34:71 and show context
$setlocIdx = -1
for ($i = 0; $i -lt $lines.Count; $i++) {
    if ($lines[$i] -match 'Setloc.*32:34:71') {
        $setlocIdx = $i
        break
    }
}

if ($setlocIdx -ge 0) {
    Write-Host "=== Context around Setloc 32:34:71 (line $setlocIdx) ==="
    $start = [Math]::Max(0, $setlocIdx - 50)
    $end = [Math]::Min($lines.Count - 1, $setlocIdx + 20)
    for ($i = $start; $i -le $end; $i++) {
        $marker = if ($i -eq $setlocIdx) { ' <<<' } else { '' }
        Write-Host ("  [{0}] {1}{2}" -f $i, $lines[$i], $marker)
    }
} else {
    Write-Host "Setloc 32:34:71 not found in log!"
    # Show last 200 lines
    Write-Host "=== Last 200 lines ==="
    $start = [Math]::Max(0, $lines.Count - 200)
    for ($i = $start; $i -lt $lines.Count; $i++) {
        Write-Host ("  [{0}] {1}" -f $i, $lines[$i])
    }
}
