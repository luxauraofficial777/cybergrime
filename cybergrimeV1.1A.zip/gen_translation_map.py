#!/usr/bin/env python3
"""Generate binary translation map from dw7_encoded_translation.json.

Output format (translation_map.bin):
  Header: 4 bytes magic "TXMP"
  Entry count: uint32 LE
  For each entry:
    text_id: uint16 LE (e.g. 0x0020)
    seq_count: uint16 LE
    For each sequence:
      enc_len: uint32 LE
      enc_bytes: enc_len bytes

The C++ HbdReencoder loads this map and uses it to inject pre-encoded
English text into HBD blocks, replacing the decode->re-encode approach
that fails because the hybrid tree lacks Japanese character values.
"""
import json, struct, sys, os

def main():
    dqlt_root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    enc_path = os.path.join(dqlt_root, 'dw7_encoded_translation.json')
    out_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'translation_map.bin')

    print('Loading %s...' % enc_path)
    data = json.load(open(enc_path, encoding='utf-8'))
    print('  %d text IDs' % len(data))

    entries = []
    for text_id_str, sequences in sorted(data.items()):
        text_id = int(text_id_str, 16)
        seq_list = []
        for seq_id_str, seq_val in sorted(sequences.items(), key=lambda x: int(x[0])):
            enc_hex = seq_val.get('encoded_hex', '')
            enc_bytes = bytes.fromhex(enc_hex)
            seq_list.append(enc_bytes)

        entries.append((text_id, seq_list))

    print('  %d entries prepared' % len(entries))

    with open(out_path, 'wb') as f:
        # Header
        f.write(b'TXMP')
        f.write(struct.pack('<I', len(entries)))

        for text_id, seq_list in entries:
            f.write(struct.pack('<HH', text_id, len(seq_list)))
            for enc_bytes in seq_list:
                f.write(struct.pack('<I', len(enc_bytes)))
                f.write(enc_bytes)

    total_bytes = os.path.getsize(out_path)
    print('Written: %s (%d bytes, %.1f KB)' % (out_path, total_bytes, total_bytes / 1024))

    # Show sample
    print('\nSample entries:')
    for text_id, seq_list in entries[:5]:
        print('  %04X: %d sequences, first seq %d bytes' % (text_id, len(seq_list), len(seq_list[0]) if seq_list else 0))

if __name__ == '__main__':
    main()
