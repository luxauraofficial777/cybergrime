# Check what the game is doing at key points — dump RAM from the 30M run telemetry
# The 30M run didn't crash, so we can examine the state before corruption
$j = Get-Content telemetry_puppeteer_30m.json -Raw | ConvertFrom-Json

Write-Host "=== 30M Run State (no crash) ==="
Write-Host "PC: $($j.Register_Dump.PC)"
Write-Host "SP: $($j.Register_Dump.sp)"
Write-Host "GP: $($j.Register_Dump.gp)"
Write-Host "RA: $($j.Register_Dump.ra)"
Write-Host "VBlanks: $($j.VBlank_Count)"
Write-Host ""

# Check the TTY tail for the last instructions
$tty = $j.TTY_Tail
# Find the last BIOS call in the TTY
$biosCalls = [regex]::Matches($tty, 'BIOS [ABC]:0x[0-9A-Fa-f]+')
Write-Host "Last BIOS calls in TTY tail:"
foreach ($m in $biosCalls) { Write-Host "  $($m.Value)" }
Write-Host ""

# Check the full TTY for any GPU_cw or text render related calls
Write-Host "=== Looking for GPU/text render calls in TTY ==="
$gpuLines = [regex]::Matches($tty, 'GPU|gpu|render|font|text|VRAM|vram|0x800A5D|0x800A3B')
Write-Host "GPU/text references: $($gpuLines.Count)"
foreach ($m in $gpuLines) { Write-Host "  $($m.Value)" }
