$j = Get-Content telemetry_cdromfix2_15m.json -Raw | ConvertFrom-Json
$lines = $j.TTY_Tail -split "`n"
Write-Host "=== CD-ROM write lines ==="
$cdw = $lines | Where-Object { $_ -match 'CDWR|CDDBG|CDROM.*cmd|Setloc|ReadN|ReadS|Setmode' }
Write-Host "CD-ROM write lines: $($cdw.Count)"
$cdw | Select-Object -First 30 | ForEach-Object { Write-Host "  $_" }
Write-Host ""
Write-Host "=== TestEvent / Event lines ==="
$tev = $lines | Where-Object { $_ -match 'TestEvent|EnableEvent|OpenEvent|DeliverEvent|event.*deliver' }
Write-Host "Event lines: $($tev.Count)"
$tev | Select-Object -First 20 | ForEach-Object { Write-Host "  $_" }
Write-Host ""
Write-Host "=== SIO / Pad lines ==="
$sio = $lines | Where-Object { $_ -match 'SIO|pad|PAD|InitPAD|StartPAD|controller' }
Write-Host "SIO/Pad lines: $($sio.Count)"
$sio | Select-Object -First 10 | ForEach-Object { Write-Host "  $_" }
Write-Host ""
Write-Host "=== All non-trace TTY lines (excluding CDRD8/CDRD/HWREG/instruction traces) ==="
$interesting = $lines | Where-Object { 
    $_ -notmatch 'CDRD8|HWREG|^\s+#|DIVERGENCE|END DIVERG|=== END' -and 
    $_ -match '\['
}
Write-Host "Interesting lines: $($interesting.Count)"
$interesting | Select-Object -First 50 | ForEach-Object { Write-Host "  $_" }
