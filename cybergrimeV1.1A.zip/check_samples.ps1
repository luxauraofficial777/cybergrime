$lines = Get-Content "C:\LuxAura\VoidWalkers_Project\DQLOSTTRANSLATION\cybergrime\diag_traps.log"
$filtered = $lines | Where-Object { $_ -match 'SAMPLE|STATUS' }
$filtered | Select-Object -Last 20
