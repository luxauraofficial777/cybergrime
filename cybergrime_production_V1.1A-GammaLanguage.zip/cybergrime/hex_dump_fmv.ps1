$exePath = 'c:\LuxAura\VoidWalkers_Project\DQLOSTTRANSLATION\translation\SLUSP012.06'
$bytes = [System.IO.File]::ReadAllBytes($exePath)
$loadAddr = 0x80017F00

# Hex dump around 0x92936 — 128 bytes before and after, 16 bytes per line
$center = 0x92936
Write-Host "=== Hex dump around file 0x92936 (RAM 0x800AA036) ==="
Write-Host "    BCD 32 34 71 = MSF 32:34:71 = abs frame 146621 (DuckStation LBA)"
Write-Host ""
for ($i = $center - 128; $i -le $center + 128; $i += 16) {
    $ram = $loadAddr + $i - 0x800
    $hex = ''
    $ascii = ''
    for ($j = 0; $j -lt 16 -and ($i + $j) -lt $bytes.Length; $j++) {
        $b = $bytes[$i + $j]
        $hex += $b.ToString('X2') + ' '
        if ($b -ge 0x20 -and $b -lt 0x7F) { $ascii += [char]$b } else { $ascii += '.' }
    }
    $marker = ''
    for ($j = 0; $j -lt 16; $j++) {
        if (($i + $j) -eq $center) { $marker += '^^ ' }
        elseif (($i + $j) -ge $center -and ($i + $j) -le ($center + 2)) { $marker += '-- ' }
        else { $marker += '   ' }
    }
    Write-Host ("  0x{0:X5} R{1:X8}: {2} {3}" -f $i, $ram, $hex.PadRight(48), $ascii)
    Write-Host ("                       {0}" -f $marker)
}

# Also check: is this in a table of 4-byte or 8-byte entries?
# Look for aligned patterns
Write-Host ""
Write-Host "=== 4-byte aligned values around 0x92936 ==="
for ($i = $center - 32; $i -le $center + 48; $i += 4) {
    $val = [BitConverter]::ToUInt32($bytes, $i)
    $ram = $loadAddr + $i - 0x800
    Write-Host ("  0x{0:X5} R{1:X8}: 0x{2:X8} ({3})" -f $i, $ram, $val, $val)
}
