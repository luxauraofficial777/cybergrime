@echo off
"C:\LuxAura\VoidWalkers_Project\DuckStation\duckstation-qt-x64-ReleaseLTCG.exe" "c:\LuxAura\VoidWalkers_Project\DQLOSTTRANSLATION\Dragon Quest IV - Michibikareshi Mono Tachi (Japan).cue"
