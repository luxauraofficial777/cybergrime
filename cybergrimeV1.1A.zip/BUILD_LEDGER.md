# DQ4 Frankenstein — Build Ledger
**Per ruleset M4:** A build is only real when its gate results are appended here.
Format: `artifact | sha256 | builder-hash | G1..G5 results | date | notes`

---

## Backfilled Results (from prior session evidence)

| Artifact | SHA-256 | Builder | G1 | G2 | G3 | G4 | G5 | Date | Notes |
|---|---|---|---|---|---|---|---|---|---|
| dq4_gold_v40.bin | TBD | frankenstein_build.exe tree-mode 3 | — | — | — | — | — | Aug 2 | Builds clean, EDC/ECC passes. User reports does not boot. Stall bypass corruption fix untested. |
| dq4_frankenstein_v41.bin | TBD | frankenstein_build.exe | PASS | PASS | FAIL | — | — | Jul 20 | G2: boots to Enix logo. G3: freezes ~20s at Enix logo. |
| dq4_frankenstein_v105.bin | TBD | frankenstein_build.exe | PASS | PASS | FAIL | — | — | Jul 28 | G2: boots. G3: Enix freeze. Pre-Aug-2 (corrupted stall bypass). |
| dq4_frankenstein_v106.bin | TBD | frankenstein_build.exe | PASS | PASS | FAIL | — | — | Jul 28 | G2: boots. G3: Enix freeze. Proved stall bypass doesn't fix freeze. Pre-Aug-2 (corrupted). |
| dq4_reencoded.bin | TBD | — | — | — | — | — | — | Jul 30 | 1150/1150 blocks re-encoded. NEVER TESTED (Q2). |
| dq4_reencoded_v2.bin | TBD | — | — | — | — | — | — | Jul 31 | Never tested. |
| dq4_reverse_a.bin | TBD | frankenstein_build.exe --reverse | PASS | — | — | — | — | Jul 23 | Reverse Option A. Translation map system. Never emulator-tested. |

## Phase 0 Builds (this session forward)

| Artifact | SHA-256 | Builder | G1 | G2 | G3 | G4 | G5 | Date | Notes |
|---|---|---|---|---|---|---|---|---|---|
| _(none yet)_ | | | | | | | | | |

---

**Gate definitions (from SURGICAL_COMPLETION_DQ4_Aug3_2026.md):**
- **G1:** `python verify_reverse_disc.py <disc>` — 19/19 static checks
- **G2:** DuckStation boot — BIOS splash → Enix logo, no illegal instruction
- **G3:** DuckStation continued — past Enix logo (no freeze at ~20s)
- **G4:** DuckStation continued — first rendered English text
- **G5:** 10-min play: prologue → first battle → memory-card save → reload
