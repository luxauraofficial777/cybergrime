$j = Get-Content telemetry_diag_55m.json -Raw | ConvertFrom-Json
Write-Host "=== DIAG 55M Run State ==="
Write-Host "Status: $($j.Pass_Status)"
Write-Host "Instructions: $($j.Instructions_Executed)"
Write-Host "VBlanks: $($j.VBlank_Count)"
Write-Host "Crashed: $($j.Crashed)"
Write-Host ""
Write-Host "=== Hardware State ==="
Write-Host "CD-ROM Reading: $($j.HW_State.cdrom_reading)"
Write-Host "CD-ROM Sectors Read: $($j.HW_State.cdrom_sectors_read)"
Write-Host "PAD Started: $($j.HW_State.pad_started)"
Write-Host ""
$tty = $j.TTY_Tail
$lines = $tty -split "`n"
# Find MEMDUMP at 50M
$dumpLines = $lines | Where-Object { $_ -match 'MEMDUMP|END MEMDUMP|TIMEOUT|EVT_FLAG|DISP_FLAG|CD_INIT|CD_READY|FRAME_CNT|VBC|DISP_AREA|HOOK_ENTRY|THREAD_CTX|ev\[' }
Write-Host "=== 50M MEMDUMP ==="
$dumpLines | ForEach-Object { Write-Host "  $_" }
