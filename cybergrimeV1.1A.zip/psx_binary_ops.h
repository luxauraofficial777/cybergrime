#pragma once
#include <cstdint>
#include <cstring>
#include <vector>
#include <fstream>
#include <string>
#include <unordered_map>
#include <unordered_set>

// ===== Locked Constants =====
constexpr uint32_t EXE_LBA=24, HBD_LBA=356, SECTOR_SIZE=2352, USER_OFFSET=24, USER_SIZE=2048;
constexpr uint32_t DQ4_HBD_SIZE=319436800, DW7_HBD_SIZE=618563584, HYBRID_TREE_SIZE=1480;
constexpr uint32_t EXE_LOAD_ADDR=0x80017F00, ORIGINAL_PC0=0x8008E284;
constexpr uint32_t THREAD_ENTRY=0x800D9E80;
constexpr uint32_t ABS_TABLE_START=0x4184, REL_TABLE_START=0x511C, TABLE_ENTRY_SIZE=8, MAX_TABLE_ENTRIES=6000;
constexpr uint32_t CDROM_CMD_WRITE_OFF=0x80F64, CDROM_BRANCH_OFF=0x80F68;
constexpr uint32_t CDROM_BRANCH_TARGET=0x80098898, CDROM_AFTER_BRANCH_RAM=0x80098670;

// ===== P3: CD-ROM command interception constants — REMOVED Aug 3, 2026 =====
// FMV skip family (stubs, Setloc intercept, BCD redirect) removed per user directive.
// It never worked: disc verification showed the game still seeks 32:34:71 from a
// source none of these patches touched, and the intercept destroyed dispatch+4.

// ===== Malloc clamp (P1) =====
// Descriptor publish at 0x8007AD74: sw $a2, 8744($v1) writes descriptor base to 0x800F2228.
// $a2 comes from 0x800C9A40 (descriptor table offset+8), set by bump allocator starting
// from heap base 0x80190000. DQ4 HBD over-allocation pushes bump pointer past 0x80800000.
// Clamp trampoline at tramp_base+0x80 checks $a2 >= 0x80800000, clamps to 0x80100000.
constexpr uint32_t DESC_PUBLISH_RAM=0x8007AD74;       // sw $a2, 0x2228($v1) — descriptor base publish
constexpr uint32_t DESC_PUBLISH_OFF=0x63674;          // EXE file offset (0x8007AD74 - 0x80017F00 + 0x800)
constexpr uint32_t DESC_PUBLISH_ORIG=0xAC662228;      // Original instruction (sw $a2, 0x2228($v1))
constexpr uint32_t DESC_PUBLISH_NEXT=0x24632228;      // Next instruction (addiu $v1, $v1, 0x2228)
constexpr uint32_t DESC_PUBLISH_CONT_RAM=0x8007AD7C;  // Continue target after trampoline
constexpr uint32_t RAM_CEILING=0x80800000;            // 8MB RAM ceiling
constexpr uint32_t DESC_CLAMP_VALUE=0x80100000;       // Safe fallback descriptor base
constexpr uint32_t MALLOC_CLAMP_TRAMP_OFFSET=0x80;    // Offset from tramp_base for clamp trampoline
constexpr uint32_t ROOT_ID_RUNTIME_TRAMP_OFFSET=0x200; // Offset from tramp_base for root_id runtime stub

// ===== Pre-tree BSS zero region =====
// Hardened end: stop at 0x800BC6F0 so the tree pointer variables at 0x800BC6F8
// and 0x800BC6FC are never zeroed, even if zero_pre_tree_bss runs after
// write_runtime_tree_ptrs (orphan-builder C1 regression class).
constexpr uint32_t PRE_TREE_BSS_START=0x800BC668;
constexpr uint32_t PRE_TREE_BSS_END=0x800BC6F0;
constexpr uint32_t PRE_TREE_BSS_LEN=PRE_TREE_BSS_END-PRE_TREE_BSS_START;  // 136 bytes

// Thread-entry fix constants (from VECTOR_ANALYSIS_REPORT.md)
// BSS clear loop: lui $v0,0x800C; addiu $v0,0xC668; lui $v1,0x800F; addiu $v1,imm; sw $zero,0($v0)
// EXE file offsets (0x800 header INCLUDED — do NOT add +0x800):
//   0x76B84 = lui $v0, 0x800C    (0x3C02800C) — BSS start upper (RAM 0x8008E284)
//   0x76B88 = addiu $v0, 0xC668  (0x2442C668) — BSS start lower (RAM 0x8008E288)
//   0x76B8C = lui $v1, 0x800F    (0x3C03800F) — BSS end upper (MUST PATCH to 0x800E)
//   0x76B90 = addiu $v1, imm     (0x24634980) — BSS end lower (MUST PATCH to 0x9E80)
//   0x76B94 = sw $zero, 0($v0)   (0xAC400000) — store zero
//
// CRITICAL: addiu uses SIGNED 16-bit immediate. 0xCCC8 = -13112.
// With lui 0x800F: v1 = 0x800F0000 - 13112 = 0x800ECCC8 (WRONG — includes thread entry)
// With lui 0x800C: v1 = 0x800C0000 - 13112 = 0x800BCCC8 (CORRECT — preserves thread entry)
constexpr uint32_t BSS_CLEAR_LUI_V1_OFF=0x76B8C;   // EXE offset of lui $v1 (BSS end upper, RAM 0x8008E28C)
constexpr uint32_t BSS_CLEAR_ADDIU_V1_OFF=0x76B90;  // EXE offset of addiu $v1 (BSS end lower, RAM 0x8008E290)
constexpr uint16_t BSS_CLEAR_LUI_V1_ORIG=0x800F;    // Original lui immediate
constexpr uint16_t BSS_CLEAR_LUI_V1_NARROW=0x800C;  // Patched lui immediate
constexpr uint16_t BSS_CLEAR_ADDIU_V1_ORIG=0x4980;  // Original addiu immediate (positive)
constexpr uint16_t BSS_CLEAR_ADDIU_V1_NARROW=0xCCC8; // Patched addiu immediate (signed negative)
// Legacy compat (deprecated — use the two-instruction patch above)
constexpr uint32_t THREAD_ENTRY_SAFE_RAM=0x80101000;  // Safe location for thread entry copy (outside BSS)

// ===== BSS clear START patch constants =====
// To preserve the hybrid tree at 0x800BC700, we move BSS START past it.
// BSS start is controlled by lui $v0 + addiu $v0 at offsets 0x76B84/0x76B88.
// New BSS start = 0x800BCCC8 (past tree end):
//   lui $v0, 0x800C (unchanged) + addiu $v0, 0xCCC8 (signed -13112) = 0x800BCCC8
constexpr uint32_t BSS_CLEAR_LUI_V0_OFF=0x76B84;     // EXE offset of lui $v0 (BSS start upper, RAM 0x8008E284)
constexpr uint32_t BSS_CLEAR_ADDIU_V0_OFF=0x76B88;   // EXE offset of addiu $v0 (BSS start lower, RAM 0x8008E288)
constexpr uint16_t BSS_CLEAR_ADDIU_V0_ORIG=0xC668;   // Original addiu immediate
constexpr uint16_t BSS_CLEAR_ADDIU_V0_NEW=0xD700;    // Patched: BSS start -> 0x800BD700 (past tree + trampolines, aligned to 2048)

// Thread-entry-preserving BSS END: narrow to 0x800D9E80 (just before thread entry)
// MIPS addiu sign-extends: 0x9E80 >= 0x8000 → treated as -0x6180
// lui $v1, 0x800E + addiu $v1, 0x9E80 = 0x800E0000 - 0x6180 = 0x800D9E80
constexpr uint16_t BSS_CLEAR_LUI_V1_THREADSAFE=0x800E;
constexpr uint16_t BSS_CLEAR_ADDIU_V1_THREADSAFE=0x9E80;

// ===== Additional build constants =====
constexpr uint32_t OLD_LUI_IMM=0x800F, OLD_ADDIU_IMM=0xF1C8;

// ===== Decompressor patch targets (from patch_targets.md) =====
// Target 4: Tree pointer — register variable mapping
//   Patches addiu at 0x8005F760 and 0x8005F7A8 to load tree base from
//   a runtime variable at 0x800BC6F8 instead of hardcoded immediate.
//   This allows per-block tree updates without code changes.
//   Site 1: lui $v0,0x800F at file 0x3EBEC (RAM 0x800562EC)
//           addiu $v0,$v0,-3640 at file 0x3EBF0 (RAM 0x800562F0)
//   Site 2: lui $v0,0x800F at file 0x3EC34 (RAM 0x80056334)
//           addiu $v0,$v0,-3640 at file 0x3EC38 (RAM 0x80056338)
constexpr uint32_t DECOMP_TREE_PTR1_OFF=0x3EBF0;      // File offset of addiu $v0 (site 1, RAM 0x800562F0)
constexpr uint32_t DECOMP_TREE_PTR2_OFF=0x3EC38;      // File offset of addiu $v0 (site 2, RAM 0x80056338)
constexpr uint32_t TREE_PTR_VAR_RAM=0x800BC6F8;        // Runtime tree pointer variable (RAM, raw tree base)
constexpr uint32_t TREE_PTR_VAR_OFF=0xA4FF8;           // File offset of tree pointer variable (0x800BC6F8 - 0x80017F00 + 0x800)
constexpr uint32_t TREE_PTR_VAR_PLUS2_RAM=0x800BC6FC;  // Runtime tree pointer + 2 (for root_id +1 at Site 3)
constexpr uint32_t TREE_PTR_VAR_PLUS2_OFF=0xA4FFC;     // File offset of tree pointer + 2 variable

// Target 5: Root ID +1 — DQ4 uses (value & 0x7FFF) + 1, DW7 uses value & 0x7FFF
//   Site 3 at 0x80057FEC: lui $v1,0x800F + addiu $v1,-3640 loads tree base 0x800EF1C8
//   andi $v0,$v0,0x7FFF at 0x80057FF8, then addu $v0,$v0,$v1 at 0x80058000
//   Runtime variant: JAL stub loads tree base from runtime var, adds +1 via tree_base+2
constexpr uint32_t DECOMP_ROOT_ID_OFF=0x408F4;         // File offset of addiu $v1 (site 3, RAM 0x80057FF4)

// Target 6: Offset_b mask removal — DW7 forces offset_b even with andi 0xFFFE
//   DQ4 requires odd offset_b values. Replace andi with nop.
constexpr uint32_t DECOMP_OFFSET_B_OFF=0x7CAA4;        // File offset of andi $v0,$v0,0xFFFE (RAM 0x800941A4)
constexpr uint32_t DQ4_HBD_DISC_START=362;
constexpr uint32_t DQ4_HBD_SECTORS=DQ4_HBD_SIZE/USER_SIZE;   // 155975
constexpr uint32_t DQ4_HBD_END=DQ4_HBD_DISC_START+DQ4_HBD_SECTORS;  // 156337
constexpr uint32_t SEQ_TABLE_START=0xA39AA, SEQ_TABLE_END=0xA3A02;
constexpr uint32_t SEQ_TABLE_MIN=300, SEQ_TABLE_MAX=400;

// ===== Folder mapping entry (from folder_mapping.json) =====
struct FolderMapping{
    uint32_t dw7_sector;
    uint32_t dq4_sector;
};

// ===== Disc-check patch entry (variable-length byte patches) =====
struct DiscCheckPatch{
    uint32_t offset;        // EXE offset (without 0x800 header)
    uint32_t patch_len;     // Length of patch data
    const uint8_t* patch_data;
    const char* desc;
};

// ===== Build result struct =====
struct BuildResult{
    uint32_t lba_patches;
    uint32_t seq_patches;
    uint32_t abs_matched;
    uint32_t abs_delta;
    uint32_t rel_matched;
    uint32_t disc_patches;
    uint32_t tree_patches;
    uint32_t trampoline_patches;
    uint32_t exe_size;
    uint32_t new_pc0;
    uint32_t disc_size;
    uint32_t hbd_blocks_processed;
    uint32_t hbd_blocks_converted;
    uint32_t hbd_subblock_swaps;
    uint32_t hbd_lba_patches;
    uint32_t hbd_table_patches;
    uint32_t fmv_seek_skips;
    uint32_t fmv_bcd_patches;
    int success;
};

// ===== MIPS Instruction Encoding (compile-time verified) =====
constexpr uint32_t MIPS_JAL(uint32_t t){return(0x03<<26)|((t>>2)&0x03FFFFFF);}
constexpr uint32_t MIPS_J(uint32_t t){return(0x02<<26)|((t>>2)&0x03FFFFFF);}
constexpr uint32_t MIPS_LUI(uint8_t rt,uint16_t imm){return(0x0F<<26)|(rt<<16)|imm;}
constexpr uint32_t MIPS_ADDIU(uint8_t rt,uint8_t rs,uint16_t imm){return(0x09<<26)|(rs<<21)|(rt<<16)|imm;}
constexpr uint32_t MIPS_LW(uint8_t rt,uint16_t off,uint8_t base){return(0x23<<26)|(base<<21)|(rt<<16)|off;}
constexpr uint32_t MIPS_SW(uint8_t rt,uint16_t off,uint8_t base){return(0x2B<<26)|(base<<21)|(rt<<16)|off;}
constexpr uint32_t MIPS_BNE(uint8_t rs,uint8_t rt,int16_t off){return(0x05<<26)|(rs<<21)|(rt<<16)|(uint16_t)off;}
constexpr uint32_t MIPS_BEQ(uint8_t rs,uint8_t rt,int16_t off){return(0x04<<26)|(rs<<21)|(rt<<16)|(uint16_t)off;}
constexpr uint32_t MIPS_SB(uint8_t rt,uint16_t off,uint8_t base){return(0x28<<26)|(base<<21)|(rt<<16)|off;}
constexpr uint32_t MIPS_NOP=0x00000000;
constexpr uint32_t MIPS_JR_RA=0x03E00008;

// ===== Structs (byte-exact to hardware) =====
struct HbdBlockHeader{
    uint32_t end_marker,block_id,hts,tree_end,text_end,unknown;
};
static_assert(sizeof(HbdBlockHeader)==24,"HBD block header layout");

// ===== HuffTree: Huffman tree parser + codec (DQ4/DW7 formats) =====
class HuffTree{
    struct Node{
        bool is_branch;
        uint16_t value;     // leaf: content value; branch: branch id
        int left,right;     // child indices, -1 for leaves
    };
    std::vector<Node> nodes;
    int root_idx;
    std::unordered_map<uint16_t,std::string> code_table;

    int parse_node(const uint8_t* tree,uint32_t tree_len,int branch_id,
                   uint32_t offset_b,std::unordered_set<int>& seen);
    void build_codes(int node_idx,const std::string& prefix);
public:
    HuffTree():root_idx(-1){}
    bool parse_dq4(const uint8_t* tree,uint32_t len);
    bool parse_dw7(const uint8_t* tree,uint32_t len);
    std::vector<uint16_t> decode(const uint8_t* text,uint32_t len) const;
    std::vector<uint8_t> encode(const std::vector<uint16_t>& leaves) const;
    bool valid() const{return root_idx>=0;}
};

// ===== IsoImage: ISO 9660 raw-sector I/O =====
class IsoImage{
    std::fstream file;
    uint32_t sector_sz, data_off;
public:
    bool open(const char* path);
    void close();
    int read_sector(uint32_t lba,void* buf2048);
    int write_sector(uint32_t lba,const void* buf2048);
    int read_range(uint32_t lba,uint32_t count,void* buf);
    uint32_t file_size() const;
    uint32_t sector_size() const{return sector_sz;}
};

// ===== Patch record for validation + revert =====
struct PatchRecord {
    uint32_t offset;           // EXE file offset (including 0x800 header)
    uint32_t original_value;   // Original 32-bit word before patch
    uint32_t patched_value;    // Value written by the patch
    uint32_t ram_addr;         // RAM address (load_addr + offset - 0x800)
    char patch_name[48];       // Human-readable patch name
    bool reverted;             // True if this patch was reverted
};

// ===== ExePatcher: type-safe EXE read/write/patch =====
class ExePatcher{
    std::vector<uint8_t> data;
    uint32_t load_addr, text_sz, pc0_val;
    uint32_t tramp_base = 0x80101000;  // HBD trampoline RAM (overridable for reverse build)
    bool safe_boot_stub = false;       // When true, translate copy destinations to KSEG1 (0xA0000000)
    std::vector<PatchRecord> patch_history;
    // Internal: record a 32-bit patch for later revert/validation
    void record_patch(uint32_t file_offset, uint32_t orig, uint32_t patched, const char* name);
    // Internal: record a 16-bit patch (stored as 32-bit with upper bits from original)
    void record_patch16(uint32_t file_offset, uint16_t orig, uint16_t patched, const char* name);
public:
    bool load(const uint8_t* buf,uint32_t size);
    uint32_t ram_to_offset(uint32_t ram)const;
    uint32_t read32(uint32_t ram)const;
    void write32(uint32_t ram,uint32_t val);
    uint16_t read16(uint32_t ram)const;
    void write16(uint32_t ram,uint16_t val);
    uint32_t patch_lba_references(uint32_t old_lba,uint32_t new_lba);
    uint32_t patch_sequential_sector_table(uint32_t old_lba,uint32_t new_lba);
    // Patch the 72-entry HBD LBA table at file offset 0x4000-0x4400.
    // Scans for 32-bit words in HBD LBA range, applies delta, with verify-then-patch-or-abort.
    // Returns count of entries patched (excluding already-patched idempotent skips).
    uint32_t patch_hbd_lba_table(uint32_t lba_delta,uint32_t& already_patched_count);
    uint32_t patch_tree_references(uint32_t old_lui,uint16_t old_addiu,uint16_t new_lui,uint16_t new_addiu);
    uint32_t patch_disc_check(const uint32_t* offsets,const uint32_t* patches,uint32_t count);
    uint32_t patch_disc_check_variable(const DiscCheckPatch* patches,uint32_t count);
    void append_payload(const uint8_t* payload,uint32_t size);
    void append_reloc_payload(const uint8_t* tree,uint32_t tree_sz,uint32_t tree_target_ram,uint32_t orig_pc0);
    // Thread-entry fix: Option B — narrow BSS clear to preserve 0x800D9E80
    bool patch_bss_clear_narrow();
    // Thread-entry fix: Option A — extend copy routine with post-BSS thread injection
    void append_reloc_payload_with_thread_fix(const uint8_t* tree,uint32_t tree_sz,
        uint32_t tree_target_ram,uint32_t orig_pc0,
        const uint8_t* thread_entry_data,uint32_t thread_entry_sz);
    // Folder pointer remapping (ABS + REL tables, matched + delta)
    void remap_folder_pointers(const FolderMapping* mappings,uint32_t count,
        uint32_t lba_delta,uint32_t dq4_base_sector,
        uint32_t& abs_matched,uint32_t& abs_delta_count,
        uint32_t& rel_matched);
    // Compute tree address with sign-extension
    static void compute_tree_addr(uint32_t target_ram,uint16_t& lui,uint16_t& addiu);
    // HBD sub-block type trampoline: patch 0x8005F754 to JAL trampoline
    // and append trampoline code to EXE payload
    bool patch_hbd_type_trampoline();
    // P1: Malloc clamp — patch descriptor publish at 0x8007AD74 to jump to
    // trampoline that clamps $a2 to 0x80100000 if >= 0x80800000 (8MB ceiling)
    bool patch_malloc_clamp();
    // Zero pre-tree BSS region (0x800BC668-0x800BC700) to fix thread
    // status polling loop at PC 0x80048004
    void zero_pre_tree_bss();
    // Decompressor Target 4: Patch tree pointer loads at 0x8005F760 (Site 1)
    // and 0x8005F7A8 (Site 2) to load from runtime variable at 0x800BC6F8
    // instead of hardcoded immediate. Variable stores raw tree base (no +2).
    // Uses 2-instruction form: lui $at,0x800C; lw $reg,0xC6F8($at).
    bool patch_decomp_tree_pointer();
    // Decompressor Target 5: Add +2 to tree base immediate at 0x80061924
    // (Site 3) to implement DQ4's root_id = (value & 0x7FFF) + 1 convention.
    // This is the static variant — bakes +2 into the addiu immediate.
    // Use patch_decomp_root_id_runtime() instead when R-TREEHOOK is active
    // and per-block trees may reside at different addresses.
    bool patch_decomp_root_id_plus1();
    // Decompressor Target 5R: Runtime root ID — replaces Site 3's lui+addiu
    // with a JAL to a stub that loads tree_base+2 from runtime variable
    // 0x800BC6FC. Uses JAL stub (not 2-instruction lw form) because Site 3's
    // third instruction (addu $v0,$v0,$v1) uses the loaded register, creating
    // a MIPS I load-delay hazard. The stub adjusts $ra to skip the original
    // addu and performs the load + addu with proper delay slot spacing.
    // Supports per-block trees updated by R-TREEHOOK.
    bool patch_decomp_root_id_runtime();
    // Decompressor Target 6: Replace andi $v0,$v0,0xFFFE at 0x800365A8
    // with nop to allow odd offset_b values (DQ4 requirement).
    bool patch_decomp_offset_b_mask();
    // R-TREEHOOK (BUG-3): Hook block loader at 0x8005F728 to update
    // runtime tree pointer variable (0x800BC6F8) with per-block inline
    // tree address: tree_addr = block_base + tree_start(header@0x0C).
    // Appends stub after HBD type trampoline.
    bool patch_tree_hook();
    // Parse and apply hotfixes from a simple text file
    bool patch_hotfixes(const char* hotfix_file_path);
    // Dump MIPS disassembly of a RAM address range
    void disasm_range(uint32_t start_ram, uint32_t end_ram) const;
    // Refresh pc0_val from data after external patch
    void refresh_pc0(){pc0_val=*(uint32_t*)(data.data()+0x10);}
    void update_text_size();
    void set_tramp_base(uint32_t ram){tramp_base=ram;}
    void set_safe_boot_stub(bool v){safe_boot_stub=v;}
    // Check if the instruction at ram-4 is a branch/jump (i.e., ram is a delay slot)
    bool is_delay_slot(uint32_t ram) const;
    // Write a jump instruction at ram after checking delay-slot safety.
    // Returns false (and skips the write) if ram is a branch delay slot.
    bool safe_write_jump(uint32_t ram, uint32_t value, const char* name);
    const uint8_t* raw()const{return data.data();}
    uint32_t size()const{return(uint32_t)data.size();}
    uint32_t pc0()const{return pc0_val;}
    uint32_t load_address()const{return load_addr;}

    // FMV XA stub: overwrite XA playback init entry (0x8008B32C) with 6-instruction
    // flag-setting stub that writes 1 to 0x800E2038 and 0x800E3D94 before returning.
    bool patch_fmv_skip_xa_stub();

    // VBlank wait bypass: patch 0x800965E8 entry to return immediately (jr ra; move v0,zero; nop).
    // The original function has 3 spinlock loops that block forever because VBlank IRQ
    // doesn't update timer memory in this Frankenstein graft. 35 call sites affected.
    bool patch_vblank_wait_bypass();

    // CD-ROM FIFO drain: inject CLRPRM trampoline at 0x8008B65C
    bool patch_fifo_drain();

    // --- P2-4: Patch validation + revert ---

    // Verify CD-ROM event wait loop at 0x800986E0 is intact (not stall-bypassed)
    bool verify_cdrom_flow() const;

    // Full EXE integrity check after all patches
    // Checks: PC0, load addr, text size, CD-ROM event loop, no forbidden patches
    bool verify_integrity() const;

    // Revert a specific patch by name (restores original value)
    bool revert_patch(const char* name);

    // Revert all patches (restores EXE to original state)
    void revert_all_patches();

    // List all recorded patches
    void list_patches() const;

    // Get patch history (for external inspection / JSON telemetry)
    const std::vector<PatchRecord>& get_patch_history() const { return patch_history; }

    // Check if a specific patch was applied
    bool has_patch(const char* name) const;
};

// ===== FrankensteinBuilder: full v39 build pipeline in C++ =====
class FrankensteinBuilder{
public:
    // Run the complete v39 build. All paths are absolute.
    // Returns BuildResult with patch counts and success flag.
    static BuildResult build_v39(
        const char* dw7_disc_path,      // DW7D1/DW7D1.bin
        const char* dw7_exe_path,       // translation/SLUSP012.06
        const char* dq4_hbd_disc_path,  // dq4_heart_v17.bin
        const char* hybrid_tree_path,   // dw7_hybrid_tree.bin
        const char* folder_map_path,    // translation/folder_mapping.json
        const char* output_bin_path,    // output .bin
        const char* output_cue_path,    // output .cue
        const char* edcre_path,         // edcre.exe path (or nullptr to skip)
        int tree_mode = 3,              // 0=no tree, 1=tree@0x800F4980, 2=tree@0x80100000, 3=tree@0x800BC700+BSS narrow
        uint32_t build_flags = 0,       // bit0=skip CD-ROM stall bypass (for DuckStation)
        const char* translation_map_path = nullptr,  // translation_map.bin (pre-encoded English text)
        uint32_t hbd_lba_override = 0,  // 0=dynamic, nonzero=force HBD to this LBA (e.g. 160000)
        bool no_xa_stub = false,        // skip patch_fmv_skip_xa_stub (preserve FMV player for GPU init)
        const char* hotfix_file_path = nullptr, // dynamic CLI hotfixes (addr:val:name)
        bool no_disc_checks = false,    // skip anti-piracy disc check patches
        const char* disasm_range_str = nullptr, // dump MIPS disassembly range (e.g. 0x8004F344:0x8004F4D8)
        bool safe_boot_stub = false         // translate boot copy destinations to KSEG1 uncached
    );

    // Reverse Frankenstein (Option A): DQ4 disc as base, DW7 EXE swapped in.
    // DQ4 HBD at native sector 362, optionally re-encoded to DW7 format.
    static BuildResult build_reverse_option_a(
        const char* dq4_disc_path,      // DQ4 translated disc (base)
        const char* dw7_exe_path,       // DW7 US EXE (to patch + swap in)
        const char* hybrid_tree_path,   // dw7_hybrid_tree.bin
        const char* output_bin_path,    // output .bin
        const char* output_cue_path,    // output .cue
        const char* edcre_path,         // edcre.exe path (or nullptr to skip)
        uint32_t build_flags = 0,       // bit 0: CD-ROM command intercept, bit 1: stall bypass, bit 2: HBD re-encoding
        const char* translation_map_path = nullptr, // translation_map.bin (pre-encoded English text)
        const char* hotfix_file_path = nullptr,     // hotfixes.txt for dynamic CLI patches
        bool no_xa_stub = false,                    // skip patch_fmv_skip_xa_stub
        const char* thread_blob_path = nullptr,     // thread_code_blob.bin for MISS-1 injection
        bool safe_boot_stub = false                  // translate boot copy destinations to KSEG1 uncached
    );
};

// ===== HbdReencoder: HBD text block re-encoding =====
struct ParsedBlock{
    uint32_t offset,end,block_id,hts,tree_end,text_end,unk1;
    uint32_t tree_start,tree_middle,tree_nodes;
    uint32_t at_end,dp_count,total_size;
    std::vector<uint8_t> text_bytes,tree_bytes,dp_data;
    bool has_per_block_tree;
};

struct HbdProcessResult{
    uint32_t blocks_processed;
    uint32_t blocks_converted;
    uint32_t blocks_reencoded;
    uint32_t blocks_reencode_failed;
    uint32_t subblock_swaps;
    uint32_t lba_patches;
    uint32_t folders_parsed;
    uint32_t files_parsed;
    uint32_t errors;
    int success;
};

struct TranslationSeq{
    std::vector<uint8_t> encoded_bytes;
};
struct TranslationEntry{
    uint16_t text_id;
    std::vector<TranslationSeq> sequences;
};

class HbdReencoder{
    std::vector<uint8_t> hbd;
    const uint8_t* hybrid_tree;
    uint32_t tree_sz;
    std::unordered_map<uint16_t,TranslationEntry> tx_map;
public:
    bool load(const uint8_t* data,uint32_t size,const uint8_t* tree,uint32_t tree_sz);
    bool load_translation_map(const char* path);
    bool parse_block(uint32_t offset,ParsedBlock& out);
    int handle_zero_length_tree(uint32_t offset);
    std::vector<uint8_t> reencode_block(const ParsedBlock& parsed);
    HbdProcessResult process_hbd(uint32_t source_lba,uint32_t target_lba);
    bool validate_processed(uint32_t source_lba);
    const uint8_t* raw()const{return hbd.data();}
    uint32_t size()const{return(uint32_t)hbd.size();}
};

// ===== C API for ctypes =====
extern "C"{
    // IsoImage
    void* iso_open(const char* path);
    void  iso_close(void* iso);
    int   iso_read_sector(void* iso,uint32_t lba,void* buf);
    int   iso_write_sector(void* iso,uint32_t lba,const void* buf);
    uint32_t iso_file_size(void* iso);

    // ExePatcher
    void* exe_load(const uint8_t* buf,uint32_t size);
    void  exe_free(void* exe);
    uint32_t exe_read32(void* exe,uint32_t ram);
    void  exe_write32(void* exe,uint32_t ram,uint32_t val);
    uint32_t exe_patch_lba(void* exe,uint32_t old_lba,uint32_t new_lba);
    uint32_t exe_patch_seq_table(void* exe,uint32_t old_lba,uint32_t new_lba);
    uint32_t exe_patch_tree_refs(void* exe,uint16_t old_lui,uint16_t old_addiu,uint16_t new_lui,uint16_t new_addiu);
    uint32_t exe_patch_disc_check(void* exe,const uint32_t* offsets,const uint32_t* patches,uint32_t count);
    void  exe_append_reloc_payload(void* exe,const uint8_t* tree,uint32_t tree_sz,uint32_t tree_target_ram,uint32_t orig_pc0);
    int   exe_patch_bss_clear_narrow(void* exe);
    int   exe_patch_malloc_clamp(void* exe);
    void  exe_zero_pre_tree_bss(void* exe);
    int   exe_patch_decomp_tree_pointer(void* exe);
    int   exe_patch_decomp_root_id_plus1(void* exe);
    int   exe_patch_decomp_root_id_runtime(void* exe);
    int   exe_patch_decomp_offset_b_mask(void* exe);
    int   exe_patch_tree_hook(void* exe);
    int   exe_patch_fmv_skip_xa_stub(void* exe);
    int   exe_patch_fifo_drain(void* exe);
    void  exe_append_reloc_payload_with_thread_fix(void* exe,const uint8_t* tree,uint32_t tree_sz,
        uint32_t tree_target_ram,uint32_t orig_pc0,
        const uint8_t* thread_entry_data,uint32_t thread_entry_sz);
    const uint8_t* exe_raw(void* exe);
    uint32_t exe_size(void* exe);
    uint32_t exe_pc0(void* exe);

    // P2-4: Patch validation + revert
    int   exe_verify_cdrom_flow(void* exe);
    int   exe_verify_integrity(void* exe);
    int   exe_revert_patch(void* exe, const char* name);
    void  exe_revert_all_patches(void* exe);
    void  exe_list_patches(void* exe);
    int   exe_has_patch(void* exe, const char* name);
    uint32_t exe_patch_count(void* exe);

    // HbdReencoder
    void* hbd_load(const uint8_t* data,uint32_t size,const uint8_t* tree,uint32_t tree_sz);
    void  hbd_free(void* hbd);
    int   hbd_handle_zero_tree(void* hbd,uint32_t offset);
    const uint8_t* hbd_raw(void* hbd);
    uint32_t hbd_size(void* hbd);
    HbdProcessResult hbd_process(void* hbd,uint32_t source_lba,uint32_t target_lba);
    int   hbd_validate(void* hbd,uint32_t source_lba);

    // Utility: extend disc with valid MODE2 sectors
    int   extend_disc_mode2(const char* path,uint64_t new_size);

    // FrankensteinBuilder — full v39 build in C++
    BuildResult build_frankenstein_v39(
        const char* dw7_disc_path,
        const char* dw7_exe_path,
        const char* dq4_hbd_disc_path,
        const char* hybrid_tree_path,
        const char* folder_map_path,
        const char* output_bin_path,
        const char* output_cue_path,
        const char* edcre_path
    );
}
