#!/usr/bin/env python3
"""Print ALL diffs between DW7 and Frankenstein EXE, check stall point."""
import struct

def read_sector(disc, lba):
    return disc[lba * 2352 + 24: lba * 2352 + 24 + 2048]

def read_exe_from_disc(disc_path, exe_lba, exe_size):
    with open(disc_path, 'rb') as f:
        disc = f.read()
    exe = bytearray()
    sectors = (exe_size + 2047) // 2048
    for i in range(sectors):
        exe.extend(read_sector(disc, exe_lba + i))
    return bytes(exe[:exe_size])

DW7_DISC = r'c:\LuxAura\VoidWalkers_Project\DQLOSTTRANSLATION\DW7D1\DW7D1.bin'
dw7_exe = read_exe_from_disc(DW7_DISC, 24, 675840)

DISC = r'c:\LuxAura\VoidWalkers_Project\DQLOSTTRANSLATION\dq4_phaseC_build1.bin'
frank_exe = read_exe_from_disc(DISC, 24, 960948)

min_size = min(len(dw7_exe), len(frank_exe))
all_diffs = []
for i in range(0x800, min_size, 4):
    dw = struct.unpack_from('<I', dw7_exe, i)[0]
    fw = struct.unpack_from('<I', frank_exe, i)[0]
    if dw != fw:
        ram = 0x80017F00 + i - 0x800
        all_diffs.append((i, ram, dw, fw))

print(f"Total diffs: {len(all_diffs)}")
print(f"\nALL DIFFERENCES:")
for off, ram, dw, fw in all_diffs:
    print(f"  file=0x{off:X} ram=0x{ram:08X}: DW7=0x{dw:08X} FRANK=0x{fw:08X}")

# Check stall point specifically
stall_file = 0x7F0E0
stall_ram = 0x800967E0
print(f"\n=== STALL POINT CHECK ===")
print(f"  File offset: 0x{stall_file:X}, RAM: 0x{stall_ram:08X}")
dw = struct.unpack_from('<I', dw7_exe, stall_file)[0]
fw = struct.unpack_from('<I', frank_exe, stall_file)[0]
print(f"  DW7:  0x{dw:08X}")
print(f"  FRANK: 0x{fw:08X}")
print(f"  SAME: {dw == fw}")

# Check if stall point is in diff list
in_diffs = any(ram == stall_ram for _, ram, _, _ in all_diffs)
print(f"  In diff list: {in_diffs}")

# Check a range around stall point
print(f"\n=== STALL POINT CONTEXT (both EXEs) ===")
for i in range(-5, 10):
    off = stall_file + i * 4
    if 0 <= off < min_size:
        dw = struct.unpack_from('<I', dw7_exe, off)[0]
        fw = struct.unpack_from('<I', frank_exe, off)[0]
        ram = stall_ram + i * 4
        same = "SAME" if dw == fw else "DIFF"
        print(f"  0x{ram:08X}: DW7=0x{dw:08X} FRANK=0x{fw:08X} [{same}]")
