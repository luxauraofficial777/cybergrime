#!/usr/bin/env python3
"""Search for GPU register accesses with any register, and find the main game loop."""
import os, struct
from capstone import Cs, CS_ARCH_MIPS, CS_MODE_MIPS32, CS_MODE_LITTLE_ENDIAN

def read_exe_from_disc(disc_path, exe_lba=24, sector_size=2352, user_offset=24, user_size=2048):
    with open(disc_path, 'rb') as f:
        exe_sectors = 340
        f.seek(exe_lba * sector_size)
        raw = f.read(exe_sectors * sector_size)
    exe_data = bytearray()
    for i in range(exe_sectors):
        sector = raw[i * sector_size:(i + 1) * sector_size]
        if len(sector) < user_offset + user_size:
            break
        exe_data += sector[user_offset:user_offset + user_size]
    return bytes(exe_data)

def disasm_range(exe_data, load_addr, start_ram, end_ram):
    code_offset = 0x800
    file_start = start_ram - load_addr + code_offset
    file_end = end_ram - load_addr + code_offset
    if file_start < 0 or file_end > len(exe_data):
        return "  (outside EXE)\n"
    code = exe_data[file_start:file_end]
    md = Cs(CS_ARCH_MIPS, CS_MODE_MIPS32 | CS_MODE_LITTLE_ENDIAN)
    lines = []
    for insn in md.disasm(code, start_ram):
        lines.append(f"  0x{insn.address:08X}: {insn.mnemonic:8s} {insn.op_str}")
    return '\n'.join(lines) + '\n'

base = r"C:\LuxAura\VoidWalkers_Project\DQLOSTTRANSLATION"
disc = os.path.join(base, "dq4_frankenstein_v41.bin")
load_addr = 0x80017F00
exe = read_exe_from_disc(disc)
md = Cs(CS_ARCH_MIPS, CS_MODE_MIPS32 | CS_MODE_LITTLE_ENDIAN)
code_offset = 0x800

# Search for ANY lui with 0x1F80 (GPU/IRQ/DMA registers)
print("=== All lui $xx, 0x1F80 instructions ===")
count = 0
for i in range(0, len(exe) - code_offset - 4, 4):
    ram = load_addr + i - code_offset
    if ram < 0x80018000 or ram > 0x800C0000:
        continue
    word = int.from_bytes(exe[i:i+4], 'little')
    # lui $rt, imm = 0x3C000000 | (rt << 16) | imm
    if (word & 0xFC000000) == 0x3C000000 and (word & 0x0000FFFF) == 0x1F80:
        rt = (word >> 16) & 0x1F
        reg_names = ['zero','at','v0','v1','a0','a1','a2','a3',
                     't0','t1','t2','t3','t4','t5','t6','t7',
                     's0','s1','s2','s3','s4','s5','s6','s7',
                     't8','t9','k0','k1','gp','sp','fp','ra']
        # Look at next 3 instructions for 0x1810/0x1814 offset
        context = ""
        for j in range(1, 4):
            if i + j*4 + 4 > len(exe):
                break
            w2 = int.from_bytes(exe[i+j*4:i+j*4+4], 'little')
            off = w2 & 0xFFFF
            if off in (0x1810, 0x1814, 0x1818, 0x1820, 0x1824, 0x1828, 0x182C):
                context += f"  *** GPU REG 0x1F80{off:04X} ***"
                break
        
        insns = list(md.disasm(exe[i:i+8], ram))
        for ins in insns:
            print(f"  0x{ins.address:08X}: {ins.mnemonic:8s} {ins.op_str}{context}")
        count += 1
        if count > 30:
            print("  ... (truncated)")
            break

# Also search for direct memory-mapped register access patterns
# 0x1F801810 = GPU data, 0x1F801814 = GPU status
# These might be accessed via lui 0xBF80 instead of 0x1F80 (mirrored at 0xBF80)
print("\n=== All lui $xx, 0xBF80 instructions (mirror region) ===")
count = 0
for i in range(0, len(exe) - code_offset - 4, 4):
    ram = load_addr + i - code_offset
    if ram < 0x80018000 or ram > 0x800C0000:
        continue
    word = int.from_bytes(exe[i:i+4], 'little')
    if (word & 0xFC000000) == 0x3C000000 and (word & 0x0000FFFF) == 0xBF80:
        insns = list(md.disasm(exe[i:i+8], ram))
        for ins in insns:
            print(f"  0x{ins.address:08X}: {ins.mnemonic:8s} {ins.op_str}")
        count += 1
        if count > 20:
            print("  ... (truncated)")
            break

# Search for the main game loop - look for jal to VSync function (0x80096600)
# Also check for function pointer tables
print("\n=== Calls to 0x80096600 (VSync function) ===")
for i in range(0, len(exe) - code_offset - 4, 4):
    ram = load_addr + i - code_offset
    if ram < 0x80018000 or ram > 0x800C0000:
        continue
    word = int.from_bytes(exe[i:i+4], 'little')
    if (word & 0xFC000000) == 0x0C000000:
        target = (word & 0x03FFFFFF) << 2
        if target == 0x80096600:
            insns = list(md.disasm(exe[max(0,i-16):i+8], ram-16))
            for ins in insns:
                print(f"  0x{ins.address:08X}: {ins.mnemonic:8s} {ins.op_str}")
            print()

# Check what's at 0x800B6398 (function pointer table used by 0x800967F8)
print("\n=== Function pointer table at 0x800B6398 ===")
# This is in BSS, so it won't be in the EXE. But let's check what writes to it.
# Search for sw $xx, 0x6398($yy) where $yy is 0x800B
print("(BSS - search for writes to 0x800B6398)")
for i in range(0, len(exe) - code_offset - 4, 4):
    ram = load_addr + i - code_offset
    if ram < 0x80018000 or ram > 0x800C0000:
        continue
    word = int.from_bytes(exe[i:i+4], 'little')
    # sw $rt, off($rs) = 0xAC000000 | (rs << 21) | (rt << 16) | off
    if (word & 0xFC000000) == 0xAC000000:
        off = word & 0xFFFF
        rs = (word >> 21) & 0x1F
        if off == 0x6398:
            insns = list(md.disasm(exe[max(0,i-8):i+8], ram-8))
            for ins in insns:
                print(f"  0x{ins.address:08X}: {ins.mnemonic:8s} {ins.op_str}")
            print()

# Check what the game does at 0x80027E7C (the string passed to printf in VSync timeout)
print("\n=== String at 0x80027E7C (VSync timeout message) ===")
str_offset = 0x80027E7C - load_addr + code_offset
if 0 <= str_offset < len(exe):
    s = exe[str_offset:str_offset+80]
    end = s.find(0)
    if end >= 0:
        s = s[:end]
    print(f"  '{s.decode('ascii', errors='replace')}'")
else:
    print("  (outside EXE)")
