$j = Get-Content telemetry_puppeteer_30m.json -Raw | ConvertFrom-Json
$tty = $j.TTY_Tail
Write-Host $tty.Substring(0, [Math]::Min(3000, $tty.Length))
