#!/usr/bin/env python3
"""
duckstation_bridge.py — Low-latency bridge between DuckStation and Cybergrime.

Architecture:
  DuckStation (child process)
    └── PSX RAM (2MB contiguous allocation)
         ↑ ReadProcessMemory / WriteProcessMemory ↑
    └── CPU::Core state struct (GPR[32], PC, HI, LO)
         ↑ ReadProcessMemory ↑
         ↓ WriteProcessMemory ↓
  duckstation_bridge.py (this module)
    ├── RAM scan: finds 2MB PSX RAM base in DuckStation's virtual address space
    ├── Register scan: finds CPU::Core struct by matching known GPR values
    ├── read_mem(addr, size) / write_mem(addr, data)
    ├── read_regs() / write_reg(name, value)
    └── Telemetry stream → build_orchestrator.py

  duckstation_supervisor.py (supervisor loop)
    ├── Polls PC at configurable interval
    ├── Detects stall loops (PC stays in same range)
    ├── Feeds telemetry to orchestrator for analysis
    └── Injects patches via write_mem when orchestrator commands

Usage:
  from duckstation_bridge import DuckStationBridge

  bridge = DuckStationBridge()
  bridge.launch("dq4_frankenstein_v38a.cue")
  bridge.wait_for_ram(timeout=30)

  pc = bridge.read_pc()
  regs = bridge.read_all_regs()
  bridge.write_mem(0x800D9E80, b'\\x01\\x00\\x00\\x00')
"""

import ctypes
import ctypes.wintypes as wt
import struct
import time
import os
import sys
import subprocess
import json
from typing import Optional, Dict, Tuple, List


# ── Windows API constants ────────────────────────────────────────────────────

PROCESS_ALL_ACCESS = 0x1F0FFF
PROCESS_VM_READ = 0x0010
PROCESS_VM_WRITE = 0x0020
PROCESS_VM_OPERATION = 0x0008
PROCESS_QUERY_INFORMATION = 0x0400
MEM_COMMIT = 0x1000
MEM_PRIVATE = 0x20000
PAGE_READWRITE = 0x04
PAGE_EXECUTE_READ = 0x20
PAGE_EXECUTE_READWRITE = 0x40
PAGE_READONLY = 0x02
PAGE_WRITECOPY = 0x08

kernel32 = ctypes.WinDLL('kernel32', use_last_error=True)

# Function prototypes
kernel32.OpenProcess.restype = wt.HANDLE
kernel32.OpenProcess.argtypes = [wt.DWORD, wt.BOOL, wt.DWORD]

kernel32.CloseHandle.argtypes = [wt.HANDLE]

kernel32.ReadProcessMemory.restype = wt.BOOL
kernel32.ReadProcessMemory.argtypes = [
    wt.HANDLE, wt.LPCVOID, wt.LPVOID, ctypes.c_size_t,
    ctypes.POINTER(ctypes.c_size_t)
]

kernel32.WriteProcessMemory.restype = wt.BOOL
kernel32.WriteProcessMemory.argtypes = [
    wt.HANDLE, wt.LPVOID, wt.LPCVOID, ctypes.c_size_t,
    ctypes.POINTER(ctypes.c_size_t)
]

kernel32.VirtualQueryEx.restype = ctypes.c_size_t
kernel32.VirtualQueryEx.argtypes = [
    wt.HANDLE, wt.LPCVOID, ctypes.c_void_p, ctypes.c_size_t
]

kernel32.VirtualProtectEx.restype = wt.BOOL
kernel32.VirtualProtectEx.argtypes = [
    wt.HANDLE, wt.LPVOID, ctypes.c_size_t, wt.DWORD,
    ctypes.POINTER(wt.DWORD)
]

kernel32.GetLastError.restype = wt.DWORD


class MEMORY_BASIC_INFORMATION(ctypes.Structure):
    _fields_ = [
        ('BaseAddress', ctypes.c_void_p),
        ('AllocationBase', ctypes.c_void_p),
        ('AllocationProtect', wt.DWORD),
        ('RegionSize', ctypes.c_size_t),
        ('State', wt.DWORD),
        ('Protect', wt.DWORD),
        ('Type', wt.DWORD),
    ]


# ── PSX constants ────────────────────────────────────────────────────────────

PSX_RAM_SIZE = 0x200000       # 2MB
PSX_RAM_MASK = 0x1FFFFF
PSX_RAM_BASE_KSEG = 0x80000000  # Kernel cached segment
PSX_SCRATCH_BASE = 0x1F800000
PSX_SCRATCH_SIZE = 0x400       # 1KB scratchpad

# MIPS register names (GPR indices)
MIPS_REGS = [
    'zero', 'at', 'v0', 'v1', 'a0', 'a1', 'a2', 'a3',
    't0', 't1', 't2', 't3', 't4', 't5', 't6', 't7',
    's0', 's1', 's2', 's3', 's4', 's5', 's6', 's7',
    't8', 't9', 'k0', 'k1', 'gp', 'sp', 'fp', 'ra',
]

# Additional CPU state
CPU_STATE_REGS = ['pc', 'hi', 'lo', 'cp0_status', 'cp0_cause', 'cp0_epc']


# ── Bridge ───────────────────────────────────────────────────────────────────

class DuckStationBridge:
    """External supervisor bridge to DuckStation via Windows process memory."""

    def __init__(self, duckstation_exe: str = None, bios_dir: str = None):
        self.exe_path = duckstation_exe or self._find_duckstation()
        self.bios_dir = bios_dir
        self.process: Optional[subprocess.Popen] = None
        self.pid: Optional[int] = None
        self.handle: Optional[int] = None

        # Discovered memory regions
        self.ram_base: Optional[int] = None       # Host address of PSX RAM
        self.scratch_base: Optional[int] = None    # Host address of scratchpad
        self.cpu_state_base: Optional[int] = None  # Host address of CPU::Core
        self.bus_base: Optional[int] = None        # Host address of Bus struct

        # Telemetry
        self.last_pc = 0
        self.pc_history: List[int] = []
        self.max_pc_history = 1024

    def _find_duckstation(self) -> str:
        candidates = [
            os.path.join(os.getcwd(), 'duckstation', 'duckstation-qt-x64-ReleaseLTCG.exe'),
            os.path.join(os.getcwd(), 'duckstation', 'duckstation-qt-x64.exe'),
        ]
        for c in candidates:
            if os.path.exists(c):
                return c
        raise FileNotFoundError("DuckStation executable not found")

    # ── Process management ───────────────────────────────────────────────

    def launch(self, cue_path: str, extra_args: list = None):
        """Launch DuckStation with a disc, return immediately."""
        args = [self.exe_path, '-batch', '-earlyconsole']
        if self.bios_dir:
            # BIOS directory is set via INI, not command line.
            # -bios flag boots into BIOS shell (no disc), so don't use it here.
            pass
        args.append(cue_path)
        if extra_args:
            args.extend(extra_args)

        print(f"[BRIDGE] Launching DuckStation: {' '.join(args)}")
        self.process = subprocess.Popen(
            args,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            creationflags=subprocess.CREATE_NEW_PROCESS_GROUP
        )
        self.pid = self.process.pid
        print(f"[BRIDGE] DuckStation PID: {self.pid}")

    def attach(self, pid: int):
        """Attach to an already-running DuckStation process."""
        self.pid = pid
        self.process = None
        print(f"[BRIDGE] Attaching to PID {pid}...")

    def _open_handle(self):
        """Open process handle for memory access."""
        self.handle = kernel32.OpenProcess(
            PROCESS_VM_READ | PROCESS_VM_WRITE | PROCESS_VM_OPERATION |
            PROCESS_QUERY_INFORMATION,
            False, self.pid
        )
        if not self.handle:
            err = kernel32.GetLastError()
            raise OSError(f"OpenProcess failed: error {err}")
        print(f"[BRIDGE] Process handle opened: 0x{self.handle:X}")

    def close(self):
        """Close the bridge and terminate DuckStation."""
        if self.handle:
            kernel32.CloseHandle(self.handle)
            self.handle = None
        if self.process:
            self.process.terminate()
            self.process = None

    # ── Memory region scanning ───────────────────────────────────────────

    def _scan_regions(self) -> List[dict]:
        """Scan virtual address space of the target process."""
        if not self.handle:
            self._open_handle()

        regions = []
        addr = 0
        mbi = MEMORY_BASIC_INFORMATION()

        while addr < 0x7FFFFFFFFFFF:
            size = kernel32.VirtualQueryEx(
                self.handle, ctypes.c_void_p(addr),
                ctypes.byref(mbi), ctypes.sizeof(mbi)
            )
            if size == 0:
                break

            if mbi.State == MEM_COMMIT and mbi.Protect in (
                PAGE_READWRITE, PAGE_EXECUTE_READWRITE,
                PAGE_EXECUTE_READ, PAGE_READONLY, PAGE_WRITECOPY
            ):
                regions.append({
                    'base': mbi.BaseAddress if mbi.BaseAddress else 0,
                    'size': mbi.RegionSize,
                    'protect': mbi.Protect,
                    'type': mbi.Type,
                })

            addr += mbi.RegionSize if mbi.RegionSize > 0 else 0x1000

        return regions

    def wait_for_ram(self, timeout: float = 30.0) -> bool:
        """Wait for DuckStation to allocate PSX RAM, then find it.

        DuckStation allocates PSX RAM within a larger Bus object on the heap.
        We search for the "PS-X EXE" signature at RAM offset 0x17F00 to locate
        the true PSX RAM base within the process virtual address space.
        """
        print(f"[BRIDGE] Waiting for PSX RAM allocation (timeout={timeout}s)...")

        # Give DuckStation time to initialize before first scan
        time.sleep(3.0)

        EXE_SIG = b'PS-X EXE'
        EXE_RAM_OFFSET = 0x17F00  # PSX address 0x80017F00 - 0x80000000

        deadline = time.time() + timeout
        while time.time() < deadline:
            if self.process and self.process.poll() is not None:
                raise RuntimeError("DuckStation exited before RAM allocated")

            if not self.handle:
                try:
                    self._open_handle()
                except OSError:
                    time.sleep(0.5)
                    continue

            regions = self._scan_regions()
            print(f"[BRIDGE] Scanned {len(regions)} committed readable regions")

            # ── Method 1: BSS clear pattern search (PRIMARY) ──
            # The BSS clear loop at RAM offset 0x8E290 has a unique 5-instruction
            # pattern. This is more reliable than the EXE signature because:
            # 1. The EXE header may be in a different memory region than RAM base
            # 2. DuckStation has internal "PS-X EXE" strings that cause false positives
            # 3. The BSS pattern is in READWRITE regions (PSX RAM data pages)
            BSS_OFFSET = 0x8E290
            BSS_STORE = struct.pack('<I', 0xAC400000)   # sw $zero, 0($v0)
            BSS_ENTRY = struct.pack('<I', 0x3C02800C)   # lui $v0, 0x800C

            for r in regions:
                # Only scan READWRITE regions for BSS pattern —
                # PSX RAM data pages are RW, DLL code pages are RX/RO
                if r['protect'] != PAGE_READWRITE:
                    continue
                if r['size'] < 0x10000:
                    continue

                # BSS code at offset 0x8E290 is within first 1MB of RAM
                search_size = 0x100000
                chunk_size = 0x10000
                for offset in range(0, search_size - 4, chunk_size - 0x200):
                    read_size = min(chunk_size, search_size - offset)
                    data = self._read_raw(r['base'] + offset, read_size)
                    if data is None:
                        continue

                    pos = 0
                    while True:
                        pos = data.find(BSS_STORE, pos)
                        if pos < 0:
                            break

                        # BSS store is at RAM offset 0x8E294
                        store_host = r['base'] + offset + pos
                        ram_base = store_host - (BSS_OFFSET + 4)  # 0x8E294

                        # ram_base must be page-aligned
                        if ram_base % 0x1000 != 0:
                            pos += 1
                            continue

                        if ram_base < 0x10000:
                            pos += 1
                            continue

                        # Verify full 5-instruction BSS clear loop
                        loop_data = self._read_raw(ram_base + BSS_OFFSET - 12, 20)
                        if loop_data and len(loop_data) >= 20:
                            words = struct.unpack_from('<5I', loop_data)
                            if (words[0] == 0x3C02800C and
                                words[1] in (0x2442C668, 0x2442CCC8) and  # DW7 or Frankenstein BSS start
                                words[2] in (0x3C03800F, 0x3C03800C, 0x3C03800E) and  # DW7, patched, or Frank LUI
                                words[4] == 0xAC400000 and
                                words[3] in (0x24634980, 0x2462CCC8, 0x24639E80)):  # DW7 or Frank BSS end
                                self.ram_base = ram_base
                                print(f"[BRIDGE] PSX RAM found at host 0x{ram_base:016X} "
                                      f"(BSS clear pattern, 5-instruction match)")
                                return True

                        pos += 1

            # ── Method 2: Fall back to EXE signature search ──
            MIN_SEARCH_SIZE = 0x18000

            for r in regions:
                if r['size'] < MIN_SEARCH_SIZE:
                    continue

                # For regions that are exactly 2MB, check directly
                if r['size'] == PSX_RAM_SIZE:
                    if self._validate_ram_candidate(r['base']):
                        self.ram_base = r['base']
                        print(f"[BRIDGE] PSX RAM found at host 0x{r['base']:016X} "
                              f"(exact 2MB region)")
                        return True
                    continue

                # For larger regions, search for "PS-X EXE" within them
                found = self._search_region_for_exe(r['base'], r['size'],
                                                     EXE_SIG, EXE_RAM_OFFSET)
                if found is not None:
                    self.ram_base = found
                    print(f"[BRIDGE] PSX RAM found at host 0x{found:016X} "
                          f"(within region 0x{r['base']:016X} size {r['size']:#x})")
                    return True

            # Also try: scan smaller regions for EXE signature at offset 0x17F00
            for r in regions:
                if r['size'] >= PSX_RAM_SIZE or r['size'] < 0x1000:
                    continue
                if r['size'] > EXE_RAM_OFFSET + 8:
                    data = self._read_raw(r['base'] + EXE_RAM_OFFSET, 8)
                    if data and data == EXE_SIG:
                        if self._validate_ram_candidate(r['base']):
                            self.ram_base = r['base']
                            print(f"[BRIDGE] PSX RAM found at host 0x{r['base']:016X} "
                                  f"(EXE sig at offset in small region)")
                            return True

            time.sleep(1.0)

        print("[BRIDGE] ERROR: Could not find PSX RAM within timeout")
        return False

    def _search_region_for_exe(self, region_base: int, region_size: int,
                                signature: bytes, expected_offset: int) -> Optional[int]:
        """Search a memory region for the PS-X EXE signature.

        Returns the host address of PSX RAM base if found, None otherwise.
        The 2MB PSX RAM may span multiple adjacent regions with different
        page protections, so we don't require the full 2MB to fit in one region.
        """
        chunk_size = 0x10000  # 64KB
        overlap = len(signature) + 0x200  # Extra overlap for alignment

        # Don't search the entire region if it's huge — limit to first 16MB
        search_size = min(region_size, 0x1000000)

        for offset in range(0, search_size - len(signature), chunk_size - overlap):
            read_size = min(chunk_size, search_size - offset)
            data = self._read_raw(region_base + offset, read_size)
            if data is None:
                continue

            pos = data.find(signature)
            if pos >= 0:
                exe_host_addr = region_base + offset + pos
                # PSX RAM base = exe_host_addr - expected_offset
                ram_base = exe_host_addr - expected_offset

                # RAM base must not be before the region start
                if ram_base < region_base:
                    continue  # This is a buffer copy, not actual PSX RAM

                # Validate: read from ram_base should look like PSX RAM
                # (RAM may span multiple regions — ReadProcessMemory handles this)
                if self._validate_ram_candidate(ram_base):
                    return ram_base

        return None

    def _search_region_for_bss(self, region_base: int, region_size: int) -> Optional[int]:
        """Search a large region for the BSS clear store pattern.

        The BSS clear loop has: sw $zero, 0($v0) = 0xAC400000 at offset 0x8E294.
        We search for this + the lui $v0, 0x800C at 0x8E284 to confirm.
        Returns the host address of PSX RAM base if found, None otherwise.
        """
        BSS_STORE = struct.pack('<I', 0xAC400000)  # sw $zero, 0($v0)
        BSS_ENTRY = struct.pack('<I', 0x3C02800C)  # lui $v0, 0x800C
        BSS_OFFSET = 0x8E290

        chunk_size = 0x10000
        search_size = min(region_size, 0x1000000)

        for offset in range(0, search_size - 4, chunk_size - 0x200):
            read_size = min(chunk_size, search_size - offset)
            data = self._read_raw(region_base + offset, read_size)
            if data is None:
                continue

            # Search for the store pattern
            pos = 0
            while True:
                pos = data.find(BSS_STORE, pos)
                if pos < 0:
                    break

                # The store is at RAM offset 0x8E294
                # So RAM base = (region_base + offset + pos) - 0x8E294
                store_host = region_base + offset + pos
                ram_base = store_host - (BSS_OFFSET + 4)  # 0x8E294

                if ram_base < region_base:
                    pos += 1
                    continue

                # Verify: check entry pattern at ram_base + 0x8E284
                entry_data = self._read_raw(ram_base + BSS_OFFSET - 12, 4)
                if entry_data and entry_data == BSS_ENTRY:
                    # Also check the instruction at 0x8E290 (either original or patched)
                    instr_data = self._read_raw(ram_base + BSS_OFFSET, 4)
                    if instr_data:
                        instr_val = struct.unpack('<I', instr_data)[0]
                        # Accept either original (0x24634980) or patched (0x2462CCC8)
                        if instr_val in (0x24634980, 0x2462CCC8):
                            return ram_base

                pos += 1

        return None

    def _search_region_for_pattern(self, region_base: int, region_size: int,
                                    pattern: bytes, expected_offset: int) -> Optional[int]:
        """Search a large region for a known byte pattern at the expected RAM offset.

        Returns the host address of PSX RAM base if found, None otherwise.
        """
        chunk_size = 0x10000  # 64KB
        overlap = len(pattern) + 0x200
        search_size = min(region_size, 0x1000000)  # Limit to 16MB

        for offset in range(0, search_size - len(pattern), chunk_size - overlap):
            read_size = min(chunk_size, search_size - offset)
            data = self._read_raw(region_base + offset, read_size)
            if data is None:
                continue

            pos = data.find(pattern)
            if pos >= 0:
                pattern_host = region_base + offset + pos
                ram_base = pattern_host - expected_offset

                if ram_base < region_base:
                    continue

                # Validate by checking the entry pattern too
                entry_data = self._read_raw(ram_base + expected_offset - 12, 4)
                if entry_data and entry_data == struct.pack('<I', 0x3C02800C):
                    return ram_base

        return None

    def _validate_ram_candidate(self, host_addr: int) -> bool:
        """Check if a memory region looks like PSX RAM.

        Multiple validation checks to reject false positives (text buffers,
        DLL sections, etc. that happen to contain 'PS-X EXE' bytes).
        """
        # Method 1: Check for valid PS-X EXE header at offset 0x17F00
        # The header has specific structure: "PS-X EXE" at +0, then zeros,
        # then SP/PC values in 0x80000000-0x80200000 range
        exe_area = self._read_raw(host_addr + 0x17F00, 0x80)
        if exe_area is not None and exe_area[:8] == b'PS-X EXE':
            # Validate header fields — these should be MIPS addresses
            # Offset 0x10: initial PC (should be 0x80017F00-ish)
            # Offset 0x18: initial SP (should be 0x801FFFFF-ish)
            # Offset 0x20: text section start (should be 0x00000000 or 0x17F00)
            try:
                pc_val = struct.unpack_from('<I', exe_area, 0x10)[0]
                sp_val = struct.unpack_from('<I', exe_area, 0x20)[0]
                gp_val = struct.unpack_from('<I', exe_area, 0x28)[0]

                # PC should be in PSX kernel space (0x80000000-0x80200000)
                pc_valid = 0x80000000 <= pc_val <= 0x80200000
                # SP should be in PSX RAM range
                sp_valid = 0x80000000 <= sp_val <= 0x80200000 or sp_val == 0

                if pc_valid and sp_valid:
                    print(f"[BRIDGE]   Validated: PS-X EXE header "
                          f"(PC=0x{pc_val:08X} SP=0x{sp_val:08X})")
                    # Extra check: verify code at entry point looks like MIPS
                    code_data = self._read_raw(host_addr + 0x18000, 16)
                    if code_data:
                        word0 = struct.unpack_from('<I', code_data, 0)[0]
                        word1 = struct.unpack_from('<I', code_data, 4)[0]
                        # Check for MIPS opcodes (top 6 bits should be valid)
                        op0 = (word0 >> 26) & 0x3F
                        op1 = (word1 >> 26) & 0x3F
                        # Valid MIPS opcodes: 0 (SPECIAL), 1 (REGIMM), 2 (J),
                        # 3 (JAL), 4 (BEQ), 5 (BNE), 9 (ADDIU), 0x0F (LUI),
                        # 0x20 (LB), 0x23 (LW), 0x2B (SW), etc.
                        valid_ops = {0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 0x0A, 0x0B,
                                     0x0C, 0x0D, 0x0F, 0x20, 0x21, 0x23, 0x24,
                                     0x25, 0x28, 0x29, 0x2B, 0x2D, 0x2E, 0x2F}
                        if op0 in valid_ops and op1 in valid_ops:
                            print(f"[BRIDGE]   MIPS code verified at entry point")
                        else:
                            print(f"[BRIDGE]   Rejected: EXE header valid but "
                                  f"code at entry not MIPS "
                                  f"(op0=0x{op0:02X} op1=0x{op1:02X})")
                            return False

                    # CRITICAL: Verify the full 2MB range is accessible
                    # and contains plausible PSX data (not text/garbage)
                    # Check at 0x100000 (512KB into RAM) — should be BSS/data
                    mid_data = self._read_raw(host_addr + 0x100000, 32)
                    if mid_data is None:
                        print(f"[BRIDGE]   Rejected: Cannot read at offset 0x100000 "
                              f"(2MB range not accessible)")
                        return False

                    # Check for UTF-16 text (common false positive indicator)
                    # UTF-16 ASCII has pattern: XX 00 XX 00 (every other byte is 0)
                    utf16_count = sum(1 for i in range(0, len(mid_data)-1, 2)
                                     if mid_data[i+1] == 0 and 0x20 <= mid_data[i] <= 0x7E)
                    if utf16_count > 10:
                        print(f"[BRIDGE]   Rejected: Data at 0x100000 looks like "
                              f"UTF-16 text ({utf16_count} ASCII pairs)")
                        return False

                    # Check at 0x1F0000 (near end of 2MB)
                    end_data = self._read_raw(host_addr + 0x1F0000, 32)
                    if end_data is None:
                        print(f"[BRIDGE]   Rejected: Cannot read at offset 0x1F0000 "
                              f"(2MB range not accessible)")
                        return False

                    # Same UTF-16 check for end data
                    utf16_end = sum(1 for i in range(0, len(end_data)-1, 2)
                                   if end_data[i+1] == 0 and 0x20 <= end_data[i] <= 0x7E)
                    if utf16_end > 10:
                        print(f"[BRIDGE]   Rejected: Data at 0x1F0000 looks like "
                              f"UTF-16 text ({utf16_end} ASCII pairs)")
                        return False

                    print(f"[BRIDGE]   2MB range verified (mid+end readable, no UTF-16)")
                    return True
                else:
                    print(f"[BRIDGE]   Rejected: PS-X EXE sig found but "
                          f"PC=0x{pc_val:08X} SP=0x{sp_val:08X} not PSX addrs")
                    return False
            except struct.error:
                return False

        # Method 2: Check BIOS exception vectors at 0x000, 0x080, 0x180
        # These should be J instructions (opcode 0x02) targeting PSX addresses
        data = self._read_raw(host_addr, 0x200)
        if data is not None and len(data) >= 0x200:
            j_count = 0
            for offset in [0x000, 0x080, 0x180]:
                word = struct.unpack_from('<I', data, offset)[0]
                opcode = (word >> 26) & 0x3F
                target = word & 0x03FFFFFF
                if opcode == 0x02 and 0x00060000 <= target <= 0x00080000:
                    j_count += 1
            if j_count >= 2:
                print(f"[BRIDGE]   Validated: {j_count} BIOS J vectors")
                return True

        return False

    # ── Low-level memory access ──────────────────────────────────────────

    def _read_raw(self, host_addr: int, size: int) -> Optional[bytes]:
        """Read raw bytes from host address space."""
        if not self.handle:
            return None
        buf = (ctypes.c_ubyte * size)()
        bytesRead = ctypes.c_size_t(0)
        ok = kernel32.ReadProcessMemory(
            self.handle, ctypes.c_void_p(host_addr),
            buf, size, ctypes.byref(bytesRead)
        )
        if not ok or bytesRead.value != size:
            return None
        return bytes(buf[:bytesRead.value])

    def _write_raw(self, host_addr: int, data: bytes) -> bool:
        """Write raw bytes to host address space.
        Uses VirtualProtectEx to temporarily make the page writable
        if DuckStation has marked it read-only (JIT code pages)."""
        if not self.handle:
            return False

        buf = (ctypes.c_ubyte * len(data))(*data)
        bytesWritten = ctypes.c_size_t(0)

        # First try direct write
        ok = kernel32.WriteProcessMemory(
            self.handle, ctypes.c_void_p(host_addr),
            buf, len(data), ctypes.byref(bytesWritten)
        )

        if not ok or bytesWritten.value != len(data):
            # Page may be read-only — try VirtualProtectEx
            oldProtect = wt.DWORD(0)
            # Round to page boundary (4KB)
            page_addr = host_addr & ~0xFFF
            page_size = ((host_addr + len(data) - page_addr) + 0xFFF) & ~0xFFF

            prot_ok = kernel32.VirtualProtectEx(
                self.handle, ctypes.c_void_p(page_addr),
                page_size, PAGE_READWRITE,
                ctypes.byref(oldProtect)
            )

            if prot_ok:
                # Retry write
                ok = kernel32.WriteProcessMemory(
                    self.handle, ctypes.c_void_p(host_addr),
                    buf, len(data), ctypes.byref(bytesWritten)
                )

                # Restore original protection
                kernel32.VirtualProtectEx(
                    self.handle, ctypes.c_void_p(page_addr),
                    page_size, oldProtect.value,
                    ctypes.byref(oldProtect)
                )
            else:
                err = kernel32.GetLastError()
                print(f"[BRIDGE] VirtualProtectEx failed: error {err}")

        return ok and bytesWritten.value == len(data)

    # ── PSX address translation ──────────────────────────────────────────

    def _psx_to_host(self, psx_addr: int) -> Optional[int]:
        """Translate PSX virtual address to host process address."""
        # KUSEG: 0x00000000-0x7FFFFFFF (user, 2MB mirrored)
        # KSEG0: 0x80000000-0x9FFFFFFF (kernel cached, 2MB)
        # KSEG1: 0xA0000000-0xBFFFFFFF (kernel uncached, 2MB)

        if 0x80000000 <= psx_addr <= 0x9FFFFFFF:
            offset = psx_addr - 0x80000000
        elif 0xA0000000 <= psx_addr <= 0xBFFFFFFF:
            offset = psx_addr - 0xA0000000
        elif 0x00000000 <= psx_addr <= 0x1FFFFFFF:
            offset = psx_addr & PSX_RAM_MASK
        else:
            return None

        if self.ram_base is None:
            return None
        if offset >= PSX_RAM_SIZE:
            return None
        return self.ram_base + offset

    # ── Public API: Memory ───────────────────────────────────────────────

    def read_mem(self, psx_addr: int, size: int) -> Optional[bytes]:
        """Read bytes from PSX address space."""
        host = self._psx_to_host(psx_addr)
        if host is None:
            return None
        return self._read_raw(host, size)

    def read_u32(self, psx_addr: int) -> Optional[int]:
        """Read a 32-bit word from PSX address space."""
        data = self.read_mem(psx_addr, 4)
        if data is None or len(data) < 4:
            return None
        return struct.unpack_from('<I', data)[0]

    def read_u16(self, psx_addr: int) -> Optional[int]:
        data = self.read_mem(psx_addr, 2)
        if data is None or len(data) < 2:
            return None
        return struct.unpack_from('<H', data)[0]

    def read_u8(self, psx_addr: int) -> Optional[int]:
        data = self.read_mem(psx_addr, 1)
        if data is None or len(data) < 1:
            return None
        return data[0]

    def write_mem(self, psx_addr: int, data: bytes) -> bool:
        """Write bytes to PSX address space (MEMORY INJECTION VECTOR)."""
        host = self._psx_to_host(psx_addr)
        if host is None:
            return False
        ok = self._write_raw(host, data)
        if ok:
            print(f"[BRIDGE] Wrote {len(data)} bytes to PSX 0x{psx_addr:08X}")
        return ok

    def write_u32(self, psx_addr: int, value: int) -> bool:
        """Write a 32-bit word to PSX address space."""
        return self.write_mem(psx_addr, struct.pack('<I', value))

    # ── Public API: Registers ────────────────────────────────────────────

    def _find_cpu_state(self, timeout: float = 15.0) -> bool:
        """
        Find the CPU::Core state structure in DuckStation's heap.

        DuckStation stores CPU state as a struct with:
          - GPR[32] (32 x uint32 = 128 bytes)
          - PC (uint32) at some offset after GPR
          - HI, LO (uint32 each)
          - CP0 registers

        Strategy: Search all RW regions for a pattern of consecutive uint32
        values in the PSX KSEG0 range (0x80000000-0x801FFFFF) that looks like
        a GPR array. We validate by checking:
          - $zero (GPR[0]) == 0
          - $sp (GPR[29]) in 0x800xxxxx range
          - $ra (GPR[31]) in 0x800xxxxx range or 0
          - Multiple consecutive regs in valid range
        """
        if self.ram_base is None:
            return False

        print("[BRIDGE] Scanning for CPU::Core state struct...")

        deadline = time.time() + timeout
        while time.time() < deadline:
            regions = self._scan_regions()
            for r in regions:
                # CPU state struct is small (~256 bytes) but may be in a
                # larger allocation. Scan regions up to 1MB.
                if r['size'] < 256:
                    continue

                read_size = min(r['size'], 0x100000)  # Read up to 1MB
                data = self._read_raw(r['base'], read_size)
                if data is None:
                    continue

                # Search for GPR array pattern:
                # 32 consecutive uint32s where:
                #   - index 0 ($zero) == 0
                #   - index 28 ($gp) in 0x80000000-0x801FFFFF
                #   - index 29 ($sp) in 0x80000000-0x801FFFFF
                #   - index 31 ($ra) in 0x80000000-0x801FFFFF or 0
                #   - At least 10 of the 32 regs in valid range
                for off in range(0, len(data) - 128, 4):
                    gpr0 = struct.unpack_from('<I', data, off)[0]
                    if gpr0 != 0:
                        continue

                    # Check $gp, $sp, $ra
                    gp = struct.unpack_from('<I', data, off + 28*4)[0]
                    sp = struct.unpack_from('<I', data, off + 29*4)[0]
                    ra = struct.unpack_from('<I', data, off + 31*4)[0]

                    if not (0x80000000 <= gp <= 0x801FFFFF):
                        continue
                    if not (0x80000000 <= sp <= 0x801FFFFF):
                        continue
                    if not (0x80000000 <= ra <= 0x801FFFFF or ra == 0):
                        continue

                    # Count how many regs are in valid PSX range
                    valid_count = 0
                    for i in range(32):
                        val = struct.unpack_from('<I', data, off + i*4)[0]
                        if 0x80000000 <= val <= 0x801FFFFF or val == 0:
                            valid_count += 1

                    if valid_count < 15:
                        continue

                    # Found likely GPR array. Now find PC.
                    # DuckStation's CPU::Core has PC after GPR[32],
                    # but the exact offset varies. Search nearby.
                    gpr_base_host = r['base'] + off

                    # Try PC at offset 128 (right after GPR[32])
                    pc = struct.unpack_from('<I', data, off + 128)[0]
                    if 0x80000000 <= pc <= 0x801FFFFF:
                        self.cpu_state_base = gpr_base_host
                        print(f"[BRIDGE] CPU::Core found at host 0x{gpr_base_host:016X}")
                        print(f"[BRIDGE]   PC=0x{pc:08X} SP=0x{sp:08X} GP=0x{gp:08X} RA=0x{ra:08X}")
                        print(f"[BRIDGE]   Valid regs: {valid_count}/32")
                        return True

                    # Try PC at other common offsets
                    for pc_off in [132, 136, 144, 160, 192, 256]:
                        if off + pc_off + 4 <= len(data):
                            pc = struct.unpack_from('<I', data, off + pc_off)[0]
                            if 0x80000000 <= pc <= 0x801FFFFF:
                                self.cpu_state_base = gpr_base_host
                                self.pc_offset = pc_off
                                print(f"[BRIDGE] CPU::Core found at host 0x{gpr_base_host:016X}")
                                print(f"[BRIDGE]   PC at offset +{pc_off}, PC=0x{pc:08X} SP=0x{sp:08X} GP=0x{gp:08X}")
                                return True

            time.sleep(1.0)

        print("[BRIDGE] WARNING: Could not find CPU::Core struct — register reads will use RAM scan")
        return False

    def read_pc(self) -> Optional[int]:
        """Read the current Program Counter."""
        if self.cpu_state_base is not None:
            pc_off = getattr(self, 'pc_offset', 128)
            data = self._read_raw(self.cpu_state_base + pc_off, 4)
            if data and len(data) == 4:
                pc = struct.unpack_from('<I', data)[0]
                if 0x80000000 <= pc <= 0x801FFFFF:
                    return pc
                # PC might be in KSEG1 (uncached) — normalize
                if 0xA0000000 <= pc <= 0xA01FFFFF:
                    return pc - 0xA0000000 + 0x80000000

        return None

    def read_all_regs(self) -> Dict[str, int]:
        """Read all MIPS GPR registers + PC + HI + LO."""
        regs = {}

        if self.cpu_state_base is not None:
            pc_off = getattr(self, 'pc_offset', 128)
            # Read GPR[32] (128 bytes) + PC + HI + LO = 140 bytes minimum
            read_len = max(pc_off + 16, 140)
            data = self._read_raw(self.cpu_state_base, read_len)
            if data and len(data) >= 128:
                for i, name in enumerate(MIPS_REGS):
                    regs[name] = struct.unpack_from('<I', data, i * 4)[0]
                if len(data) >= pc_off + 4:
                    pc = struct.unpack_from('<I', data, pc_off)[0]
                    # Normalize KSEG1 to KSEG0
                    if 0xA0000000 <= pc <= 0xA01FFFFF:
                        pc = pc - 0xA0000000 + 0x80000000
                    regs['pc'] = pc
                if len(data) >= pc_off + 8:
                    regs['hi'] = struct.unpack_from('<I', data, pc_off + 4)[0]
                if len(data) >= pc_off + 12:
                    regs['lo'] = struct.unpack_from('<I', data, pc_off + 8)[0]

                # Try CP0 at pc_off + 12
                cp0_data = self._read_raw(self.cpu_state_base + pc_off + 12, 24)
                if cp0_data and len(cp0_data) >= 24:
                    regs['cp0_status'] = struct.unpack_from('<I', cp0_data, 0)[0]
                    regs['cp0_cause'] = struct.unpack_from('<I', cp0_data, 4)[0]
                    regs['cp0_epc'] = struct.unpack_from('<I', cp0_data, 8)[0]

        return regs

    def write_reg(self, name: str, value: int) -> bool:
        """Write a value to a MIPS register."""
        if self.cpu_state_base is None:
            return False

        if name in MIPS_REGS:
            offset = MIPS_REGS.index(name) * 4
        elif name == 'pc':
            offset = 128
        elif name == 'hi':
            offset = 132
        elif name == 'lo':
            offset = 136
        else:
            return False

        return self._write_raw(
            self.cpu_state_base + offset,
            struct.pack('<I', value & 0xFFFFFFFF)
        )

    # ── Telemetry ────────────────────────────────────────────────────────

    def get_telemetry(self) -> dict:
        """Capture a full telemetry snapshot."""
        regs = self.read_all_regs()
        pc = regs.get('pc', 0)

        self.last_pc = pc
        self.pc_history.append(pc)
        if len(self.pc_history) > self.max_pc_history:
            self.pc_history = self.pc_history[-self.max_pc_history:]

        # Read critical memory regions
        critical_regions = {
            'thread_entry': self.read_u32(0x800D9E80),
            'bss_clear_end_reg': self.read_u32(0x800A2098),  # addiu $v1 value
            'tree_at_80100000': self.read_u32(0x80100000),
            'hbd_lba_in_exe': self.read_u32(0x80017F00 + 0x4184),  # ABS table start
        }

        return {
            'timestamp': time.time(),
            'pc': pc,
            'registers': {k: f'0x{v:08X}' for k, v in regs.items()},
            'critical_memory': {
                k: (f'0x{v:08X}' if v is not None else 'N/A')
                for k, v in critical_regions.items()
            },
            'pc_history_len': len(self.pc_history),
        }

    def detect_stall(self, window: int = 64, threshold: float = 0.8) -> Optional[int]:
        """
        Detect if the CPU is in a stall loop.
        Returns the stall PC if detected, None otherwise.
        """
        if len(self.pc_history) < window:
            return None

        recent = self.pc_history[-window:]
        unique_pcs = set(recent)

        # If >threshold% of recent PCs are in a small range (≤4 unique), it's a stall
        if len(unique_pcs) <= 4:
            return max(recent, key=recent.count)

        return None

    # ── Memory dump ──────────────────────────────────────────────────────

    def dump_region(self, psx_addr: int, size: int) -> Dict:
        """Dump a memory region for analysis."""
        data = self.read_mem(psx_addr, size)
        if data is None:
            return {'address': f'0x{psx_addr:08X}', 'error': 'read failed'}

        return {
            'address': f'0x{psx_addr:08X}',
            'size': size,
            'hex': data.hex(),
            'words': [struct.unpack_from('<I', data, i)[0]
                      for i in range(0, min(len(data), 256), 4)],
        }

    def dump_telemetry_json(self, output_path: str):
        """Write a full telemetry snapshot to JSON."""
        tel = self.get_telemetry()
        with open(output_path, 'w') as f:
            json.dump(tel, f, indent=2)
        print(f"[BRIDGE] Telemetry written to {output_path}")


# ── CLI ──────────────────────────────────────────────────────────────────────

def main():
    import argparse

    parser = argparse.ArgumentParser(description="DuckStation-Cybergrime Bridge")
    parser.add_argument("--cue", help="CUE file to launch")
    parser.add_argument("--pid", type=int, help="Attach to existing PID")
    parser.add_argument("--read", metavar="ADDR", help="Read 4 bytes from PSX address")
    parser.add_argument("--write", nargs=2, metavar=("ADDR", "HEX"),
                        help="Write hex bytes to PSX address")
    parser.add_argument("--regs", action="store_true", help="Dump all registers")
    parser.add_argument("--dump", nargs=2, metavar=("ADDR", "SIZE"),
                        help="Dump memory region")
    parser.add_argument("--monitor", type=int, default=0,
                        help="Monitor PC for N seconds")
    parser.add_argument("--bios", default=None, help="BIOS directory")
    args = parser.parse_args()

    bridge = DuckStationBridge(bios_dir=args.bios)

    if args.pid:
        bridge.attach(args.pid)
    elif args.cue:
        bridge.launch(args.cue)

    # Wait for RAM
    if not bridge.wait_for_ram(timeout=30):
        print("FATAL: Could not find PSX RAM")
        sys.exit(1)

    # Find CPU state
    bridge._find_cpu_state(timeout=10)

    if args.read:
        addr = int(args.read, 0)
        val = bridge.read_u32(addr)
        print(f"0x{addr:08X} = 0x{val:08X}" if val is not None else "READ FAILED")

    if args.write:
        addr = int(args.write[0], 0)
        data = bytes.fromhex(args.write[1])
        ok = bridge.write_mem(addr, data)
        print(f"WRITE {'OK' if ok else 'FAILED'}")

    if args.regs:
        regs = bridge.read_all_regs()
        for name, val in regs.items():
            print(f"  ${name:12s} = 0x{val:08X}")

    if args.dump:
        addr = int(args.dump[0], 0)
        size = int(args.dump[1], 0)
        dump = bridge.dump_region(addr, size)
        print(json.dumps(dump, indent=2))

    if args.monitor:
        print(f"\n[BRIDGE] Monitoring PC for {args.monitor}s...")
        end = time.time() + args.monitor
        while time.time() < end:
            pc = bridge.read_pc()
            if pc is not None:
                stall = bridge.detect_stall()
                marker = " ⚠ STALL" if stall else ""
                print(f"  PC=0x{pc:08X}{marker}")
            time.sleep(0.1)

    if not any([args.read, args.write, args.regs, args.dump, args.monitor]):
        # Default: print status
        pc = bridge.read_pc()
        regs = bridge.read_all_regs()
        print(f"\n[BRIDGE] Status:")
        print(f"  RAM base:  0x{bridge.ram_base:016X}")
        print(f"  CPU state: {f'0x{bridge.cpu_state_base:016X}' if bridge.cpu_state_base else 'NOT FOUND'}")
        print(f"  PC:        {f'0x{pc:08X}' if pc else 'N/A'}")
        if regs:
            print(f"  Registers:")
            for name in ['pc', 'sp', 'gp', 'ra', 'v0', 'v1', 'a0']:
                if name in regs:
                    print(f"    ${name:4s} = 0x{regs[name]:08X}")

    bridge.close()


if __name__ == "__main__":
    main()
