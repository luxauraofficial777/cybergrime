import struct, sys

SECTOR_SIZE = 2352
DATA_OFFSET = 24
USER_SIZE = 2048

def read_sector_user(f, abs_lba):
    f.seek(abs_lba * SECTOR_SIZE + DATA_OFFSET)
    return f.read(USER_SIZE)

def read_multi_sector(f, iso_lba, size):
    abs_lba = iso_lba + 150
    data = bytearray()
    sectors = (size + USER_SIZE - 1) // USER_SIZE
    for i in range(sectors):
        chunk = read_sector_user(f, abs_lba + i)
        data.extend(chunk)
    return bytes(data[:size])

disc = r"C:\LuxAura\VoidWalkers_Project\DQLOSTTRANSLATION\build_staging\dq4_reverse_a.bin"
with open(disc, "rb") as f:
    # SYSTEM.CNF at ISO LBA 23 = absolute LBA 173
    cnf = read_multi_sector(f, 23, 68)
    print("=== SYSTEM.CNF ===")
    print(cnf.decode('ascii', errors='replace'))
    
    # EXE header at ISO LBA 24 = absolute LBA 174
    exe_hdr = read_multi_sector(f, 24, 2048)
    pc0 = struct.unpack_from('<I', exe_hdr, 0x10)[0]
    load_addr = struct.unpack_from('<I', exe_hdr, 0x18)[0]
    text_sz = struct.unpack_from('<I', exe_hdr, 0x1C)[0]
    print(f"\n=== EXE header ===")
    print(f"PC0=0x{pc0:08X} load_addr=0x{load_addr:08X} text_sz=0x{text_sz:08X} ({text_sz})")
    
    # Root dir at ISO LBA 22 = absolute LBA 172
    root = read_sector_user(f, 172)
    print(f"\n=== Root directory (ISO LBA 22) ===")
    off = 0
    while off < len(root) and root[off] != 0:
        rec_len = root[off]
        lba = struct.unpack_from('<I', root, off+2)[0]
        sz = struct.unpack_from('<I', root, off+10)[0]
        flags = root[off+25]
        nl = root[off+32]
        nm = root[off+33:off+33+nl]
        print(f"  LBA={lba} size={sz} flags=0x{flags:02X} name={nm}")
        off += rec_len
    
    # Check boot sectors (LBA 0-3 should be zeroed)
    print(f"\n=== Boot sectors ===")
    for lba in range(4):
        s = read_sector_user(f, lba + 150)
        print(f"  ISO LBA {lba}: first 16 bytes = {s[:16].hex()}")
    cnf = f.read(2048)
    # Print up to first null
    end = cnf.find(b'\x00')
    if end < 0: end = 200
    print("SYSTEM.CNF (sector 23):")
    print(cnf[:end].decode('ascii', errors='replace'))
    
    # Read EXE header at sector 23 (where DQ4 EXE lives)
    f.seek(23 * 2352 + 24)
    exe23 = f.read(8)
    print(f"\nSector 23 magic: {exe23}")
    
    # Read EXE header at sector 24 (where we wrote DW7 EXE)
    f.seek(24 * 2352 + 24)
    exe24 = f.read(8)
    print(f"Sector 24 magic: {exe24}")
    
    # Check ISO directory at sector 22
    f.seek(22 * 2352 + 24)
    dirdata = f.read(2048)
    print(f"\nISO directory (sector 22), first 200 bytes:")
    # Parse directory entries
    off = 0
    while off < len(dirdata):
        rec_len = dirdata[off]
        if rec_len == 0: break
        name_len = dirdata[off + 32]
        name = dirdata[off+33:off+33+name_len]
        lba = int.from_bytes(dirdata[off+2:off+6], 'little')
        size = int.from_bytes(dirdata[off+10:off+14], 'little')
        print(f"  Entry: name={name} lba={lba} size={size} rec_len={rec_len}")
        off += rec_len
