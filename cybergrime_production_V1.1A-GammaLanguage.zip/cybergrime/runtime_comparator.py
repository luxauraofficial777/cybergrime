#!/usr/bin/env python3
"""
runtime_comparator.py — Compares live emulator state against the Golden Model.

Reads JSON-line events from the instrumentation bus and checks them against
constraint_map.json + golden_state.json. Flags byte-level divergences between
the DW7 engine's expectations and DQ4 asset reality.
"""

import json
import time
from typing import Dict, List, Any, Optional


class RuntimeComparator:
    """Compares live emulator state against the Golden Model."""

    def __init__(self, constraint_map: dict, golden_state: dict):
        self.constraints = constraint_map
        self.golden = golden_state
        self.divergences: List[dict] = []
        self.checkpoints_hit: set = set()
        self.valid_paths: List[dict] = []
        self._last_pc: int = 0
        self._last_instr: int = 0

    def handle_event(self, event: dict) -> Optional[dict]:
        """Route event to appropriate handler. Returns divergence if found."""
        etype = event.get('type')
        handler = {
            'state': self._handle_state,
            'mem': self._handle_mem,
            'vfs': self._handle_vfs,
            'bp_hit': self._handle_bp_hit,
            'divergence': self._handle_emulator_divergence,
        }.get(etype)

        if handler:
            return handler(event)
        return None

    def _handle_state(self, event: dict) -> Optional[dict]:
        """Compare register state against golden state."""
        pc = int(event['pc'], 16)
        instr = event.get('instr', 0)
        regs = event.get('regs', {})

        self._last_pc = pc
        self._last_instr = instr

        # Check register checkpoints for this PC
        checkpoints = self.golden.get('register_checkpoints', {})
        pc_key = f"0x{pc:08X}"
        expected = checkpoints.get(pc_key) or checkpoints.get(hex(pc))

        if expected:
            for reg_name, exp_val_str in expected.items():
                if reg_name.startswith('_'):
                    continue
                actual = regs.get(reg_name, '0x00000000')
                exp_val = int(exp_val_str, 16) if isinstance(exp_val_str, str) else exp_val_str
                actual_val = int(actual, 16) if isinstance(actual, str) else actual
                if actual_val != exp_val:
                    div = self._make_divergence(
                        instr, pc, 'REGISTER_MISMATCH', reg_name,
                        exp_val_str, actual,
                        f"${reg_name} expected {exp_val_str} but got {actual}"
                    )
                    self.divergences.append(div)
                    return div

        # Track valid execution path
        self.valid_paths.append({
            'instr': instr,
            'pc': event['pc'],
            'regs': regs,
        })

        return None

    def _handle_mem(self, event: dict) -> Optional[dict]:
        """Validate memory accesses against constraint map."""
        addr = int(event['addr'], 16)
        value = int(event['value'], 16)
        instr = event.get('instr', 0)
        pc = int(event.get('pc', '0x0'), 16)

        for region in self.constraints.get('memory_regions', []):
            start = int(region['start'], 16)
            end = int(region['end'], 16)
            if not (start <= addr < end):
                continue

            rtype = region['type']
            name = region['name']

            if rtype == 'zeroed_at_boot':
                # BSS region — check tree placement exception
                tree_info = self.constraints.get('huffman_tree', {})
                tree_addr_str = self.golden.get('tree_placement', {}).get('addr')
                tree_size = tree_info.get('hybrid_tree_size', 1480)

                if tree_addr_str:
                    tree_addr = int(tree_addr_str, 16)
                    if tree_addr <= addr < tree_addr + tree_size:
                        # Tree is here — should be non-zero after copy
                        if value == 0 and instr > 500000:
                            return self._record_divergence(
                                instr, pc, 'TREE_ZEROED_IN_BSS', addr,
                                'non-zero (tree data)', '0x00000000',
                                f"Tree at {hex(addr)} was zeroed by BSS clear"
                            )
                    elif value != 0 and instr > 200000:
                        return self._record_divergence(
                            instr, pc, 'BSS_NOT_ZEROED', addr,
                            '0x00000000', hex(value),
                            f"BSS region {name} not zeroed at instr {instr}"
                        )

            elif rtype == 'runtime_copied':
                # Tree should be copied here by now
                if value == 0 and instr > 500000:
                    return self._record_divergence(
                        instr, pc, 'TREE_NOT_COPIED', addr,
                        'non-zero (tree data)', '0x00000000',
                        f"Tree not copied to {name} — decompression will fail"
                    )

            elif rtype == 'free':
                # Safe high RAM — should be zero unless tree placed here
                tree_addr_str = self.golden.get('tree_placement', {}).get('addr')
                if tree_addr_str:
                    tree_addr = int(tree_addr_str, 16)
                    tree_size = self.constraints.get('huffman_tree', {}).get('hybrid_tree_size', 1480)
                    if tree_addr <= addr < tree_addr + tree_size:
                        # Tree should be here
                        if value == 0 and instr > 500000:
                            return self._record_divergence(
                                instr, pc, 'TREE_NOT_COPIED', addr,
                                'non-zero (tree data)', '0x00000000',
                                f"Tree not copied to {name} (safe high RAM)"
                            )

            break

        return None

    def _handle_vfs(self, event: dict) -> Optional[dict]:
        """Check VFS access for LBA correctness."""
        lba = event.get('lba', 0)
        resolved = event.get('resolved', True)
        instr = event.get('instr', 0)
        pc = int(event.get('pc', '0x0'), 16)

        if not resolved:
            return self._record_divergence(
                instr, pc, 'VFS_UNRESOLVED', lba,
                'resolved', 'FAILED',
                f"VFS access failed for LBA {lba}"
            )

        # Check LBA matches expected HBD LBA
        expected_lba = self.constraints.get('hbd_layout', {}).get('frankenstein_lba', 355)
        if lba == 354 and expected_lba != 354:
            return self._record_divergence(
                instr, pc, 'LBA_NOT_PATCHED', lba,
                str(expected_lba), str(lba),
                f"CD-ROM reading original LBA 354 — LBA references not patched to {expected_lba}"
            )

        return None

    def _handle_bp_hit(self, event: dict) -> Optional[dict]:
        """Handle breakpoint hit — check specific checkpoint logic."""
        pc = int(event['pc'], 16)
        instr = event.get('instr', 0)
        regs = event.get('regs', {})

        self.checkpoints_hit.add(pc)

        # Huffman decompression entry — verify tree pointer
        if pc == 0x80073670 or pc == 0x80084BF0:
            tree_addr_str = self.golden.get('tree_placement', {}).get('addr')
            if tree_addr_str:
                expected_tree = int(tree_addr_str, 16)
                actual_tree = int(regs.get('a2', '0x0'), 16)
                if actual_tree != expected_tree:
                    return self._record_divergence(
                        instr, pc, 'HUFFMAN_TREE_MISMATCH', 'a2',
                        hex(expected_tree), hex(actual_tree),
                        f"Huffman decompress called with tree pointer {hex(actual_tree)}, "
                        f"expected {hex(expected_tree)}"
                    )

        # Copy routine entry — verify src/dst
        if pc == 0x800BC700:
            expected_dst = self.golden.get('tree_placement', {}).get('addr')
            if expected_dst:
                exp_dst_val = int(expected_dst, 16)
                actual_dst = int(regs.get('t1', '0x0'), 16)
                if actual_dst != exp_dst_val:
                    return self._record_divergence(
                        instr, pc, 'COPY_DST_MISMATCH', 't1',
                        hex(exp_dst_val), hex(actual_dst),
                        f"Copy routine destination $t1={hex(actual_dst)}, expected {hex(exp_dst_val)}"
                    )

        return None

    def _handle_emulator_divergence(self, event: dict) -> Optional[dict]:
        """Pass through divergences reported by the emulator itself."""
        div = self._make_divergence(
            event.get('instr', 0),
            int(event.get('pc', '0x0'), 16),
            event.get('type', 'EMULATOR_DIVERGENCE'),
            '',
            event.get('expected', ''),
            event.get('actual', ''),
            event.get('detail', '')
        )
        div['severity'] = event.get('severity', 'WARN')
        self.divergences.append(div)
        return div

    def _record_divergence(self, instr, pc, dtype, addr, expected, actual, detail):
        div = self._make_divergence(instr, pc, dtype, addr, expected, actual, detail)
        self.divergences.append(div)
        return div

    def _make_divergence(self, instr, pc, dtype, addr, expected, actual, detail):
        return {
            'id': len(self.divergences) + 1,
            'instr_count': instr,
            'pc': f"0x{pc:08X}",
            'type': dtype,
            'address': hex(addr) if isinstance(addr, int) else str(addr),
            'expected': str(expected),
            'actual': str(actual),
            'detail': detail,
            'severity': 'FATAL' if 'MISMATCH' in dtype or 'ZEROED' in dtype or 'NOT_COPIED' in dtype else 'WARN',
            'timestamp': time.time(),
        }

    def get_report(self) -> dict:
        """Generate the full divergence report."""
        fatal = [d for d in self.divergences if d['severity'] == 'FATAL']
        return {
            'total_divergences': len(self.divergences),
            'fatal_count': len(fatal),
            'warning_count': len(self.divergences) - len(fatal),
            'first_fatal': fatal[0] if fatal else None,
            'divergences': self.divergences,
            'checkpoints_hit': [f"0x{pc:08X}" for pc in sorted(self.checkpoints_hit)],
            'valid_paths_count': len(self.valid_paths),
        }
