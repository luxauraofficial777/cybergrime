#!/usr/bin/env python3
"""
stall_telemetry.py — Use CyberGrime duckstation_bridge to read live PSX state
at the VBlank stall point.

Reads:
  - PC and registers (confirm stall at 0x800967E0)
  - VBlank counter at 0x800B63D8 (should be 0 / not incrementing)
  - Interrupt status/mask registers (0xBF801070, 0xBF801074)
  - VBlank handler pointer at 0x800B6398
  - Key init pointers
  - BSS region check (is it zeroed?)
"""

import sys
import os
import time
import struct
import json

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from duckstation_bridge import DuckStationBridge

CUE = r"C:\LuxAura\VoidWalkers_Project\DQLOSTTRANSLATION\dq4_phaseC_build1.cue"
BIOS_DIR = r"C:\LuxAura\VoidWalkers_Project\DQLOSTTRANSLATION\bios\US"

# Key addresses to probe
WATCH_ADDRS = {
    0x800B63D8: "VBlank counter",
    0x800B6398: "VBlank handler ptr",
    0x800B52A0: "Event flag ptr 1",
    0x800B52A4: "Event flag ptr 2",
    0x800B52A8: "Event flag ptr 3",
    0x800B52AC: "Counter value",
    0x800BCCC8: "BSS start (should be 0)",
    0x800BC700: "Hybrid tree start",
    0x800D9E80: "Thread entry",
    0x800C0574: "Stack top (sp target)",
}

# Hardware interrupt registers (mapped through DuckStation)
HW_REGS = {
    0xBF801070: "IRQ Status (ISTR)",
    0xBF801074: "IRQ Mask (IMASK)",
    0xBF801078: "IRQ Write Pending",
    0x1F801070: "IRQ Status (physical)",
    0x1F801074: "IRQ Mask (physical)",
}

def read_u32_safe(bridge, addr):
    """Read 4 bytes from PSX address, return None on failure."""
    data = bridge.read_mem(addr, 4)
    if data and len(data) == 4:
        return struct.unpack('<I', data)[0]
    return None

def read_u16_safe(bridge, addr):
    data = bridge.read_mem(addr, 2)
    if data and len(data) == 2:
        return struct.unpack('<H', data)[0]
    return None

def main():
    print("=== STALL TELEMETRY: Phase C Build ===")
    print(f"Disc: {CUE}")
    print(f"BIOS: {BIOS_DIR}")
    print()

    DS_EXE = r"C:\LuxAura\VoidWalkers_Project\DQLOSTTRANSLATION\duckstation\duckstation-qt-x64-ReleaseLTCG.exe"
    bridge = DuckStationBridge(duckstation_exe=DS_EXE, bios_dir=BIOS_DIR)
    print("[1] Launching DuckStation...")
    bridge.launch(CUE)

    print("[2] Waiting for PSX RAM...")
    if not bridge.wait_for_ram(timeout=30):
        print("FATAL: Could not find PSX RAM in DuckStation process")
        bridge.close()
        return

    print("[3] Waiting 12s for game to boot and reach stall...")
    time.sleep(12)

    print("[4] Finding CPU state...")
    bridge._find_cpu_state(timeout=15)

    # Wait a bit more to ensure we're at the stall
    print("[5] Waiting 8s more for stall to settle...")
    time.sleep(8)

    print()
    print("=" * 70)
    print("TELEMETRY SNAPSHOT AT STALL")
    print("=" * 70)

    # Read PC
    pc = bridge.read_pc()
    print(f"\n--- CPU STATE ---")
    print(f"  PC: 0x{pc:08X}" if pc is not None else "  PC: <read failed>")

    # Read all registers
    regs = bridge.read_all_regs()
    if regs:
        reg_names = ['zero','at','v0','v1','a0','a1','a2','a3',
                     't0','t1','t2','t3','t4','t5','t6','t7',
                     's0','s1','s2','s3','s4','s5','s6','s7',
                     't8','t9','k0','k1','gp','sp','fp','ra']
        for i, name in enumerate(reg_names):
            val = regs.get(name, regs.get(f'${i}', None))
            if val is not None:
                print(f"  ${name:3s} = 0x{val:08X}")
            else:
                print(f"  ${name:3s} = <not found>")

    # Read watch addresses
    print(f"\n--- KEY MEMORY LOCATIONS ---")
    for addr, desc in WATCH_ADDRS.items():
        val = read_u32_safe(bridge, addr)
        if val is not None:
            print(f"  0x{addr:08X} ({desc}): 0x{val:08X} ({val})")
        else:
            print(f"  0x{addr:08X} ({desc}): <read failed>")

    # Read hardware interrupt registers
    print(f"\n--- INTERRUPT REGISTERS ---")
    for addr, desc in HW_REGS.items():
        val = read_u32_safe(bridge, addr)
        if val is not None:
            # Decode IRQ bits
            irq_bits = []
            if val & 0x01: irq_bits.append("VBlank")
            if val & 0x02: irq_bits.append("GPU")
            if val & 0x04: irq_bits.append("CDROM")
            if val & 0x08: irq_bits.append("DMA")
            if val & 0x10: irq_bits.append("Timer0")
            if val & 0x20: irq_bits.append("Timer1")
            if val & 0x40: irq_bits.append("Timer2")
            if val & 0x80: irq_bits.append("Controller")
            if val & 0x100: irq_bits.append("SPU")
            print(f"  0x{addr:08X} ({desc}): 0x{val:08X} [{', '.join(irq_bits) or 'none'}]")
        else:
            print(f"  0x{addr:08X} ({desc}): <read failed>")

    # Poll VBlank counter for 5 seconds to confirm it's not incrementing
    print(f"\n--- VBLANK COUNTER POLL (5s) ---")
    vblank_values = []
    for i in range(50):
        val = read_u32_safe(bridge, 0x800B63D8)
        if val is not None:
            vblank_values.append(val)
        time.sleep(0.1)

    if vblank_values:
        unique = set(vblank_values)
        print(f"  Samples: {len(vblank_values)}, Unique values: {len(unique)}")
        print(f"  Values: {[f'0x{v:08X}' for v in vblank_values[:10]]}...")
        if len(unique) == 1:
            print(f"  *** VBLANK COUNTER IS STUCK AT 0x{vblank_values[0]:08X} ***")
        else:
            print(f"  VBlank counter IS changing (min=0x{min(unique):08X} max=0x{max(unique):08X})")

    # Read the stall function code from RAM to confirm
    print(f"\n--- STALL FUNCTION CODE (from RAM at 0x80096760) ---")
    for i in range(16):
        addr = 0x80096760 + i * 4
        val = read_u32_safe(bridge, addr)
        if val is not None:
            print(f"  0x{addr:08X}: 0x{val:08X}")
        else:
            print(f"  0x{addr:08X}: <read failed>")

    # Check what 0x800B6398 points to (VBlank handler vtable)
    print(f"\n--- VBLANK HANDLER VTABLE ---")
    vtable_ptr = read_u32_safe(bridge, 0x800B6398)
    if vtable_ptr is not None:
        print(f"  0x800B6398 -> 0x{vtable_ptr:08X}")
        # Read the vtable entries
        for i in range(8):
            addr = vtable_ptr + i * 4
            val = read_u32_safe(bridge, addr)
            if val is not None:
                print(f"    [0x{addr:08X}] -> 0x{val:08X}")
    else:
        print(f"  0x800B6398: <read failed>")

    # Check the function that 0x800967F8 calls through vtable
    print(f"\n--- FIRST VBLANK WAIT (0x800967F8) VTABLE ---")
    fptr = read_u32_safe(bridge, 0x800B6398)
    if fptr is not None:
        # 0x800967F8 reads [0x800B6398] then calls [that + 12]
        target = read_u32_safe(bridge, fptr + 12)
        if target is not None:
            print(f"  Vtable+12 -> 0x{target:08X}")
            # Read first few instructions at target
            for i in range(8):
                addr = target + i * 4
                val = read_u32_safe(bridge, addr)
                if val is not None:
                    print(f"    0x{addr:08X}: 0x{val:08X}")
        else:
            print(f"  Vtable+12: <read failed>")

    # PC history for stall loop detection
    print(f"\n--- PC HISTORY (last 32 samples) ---")
    if hasattr(bridge, 'pc_history') and bridge.pc_history:
        for i, hpc in enumerate(bridge.pc_history[-32:]):
            print(f"  [{i:3d}] 0x{hpc:08X}")
    else:
        print("  <no PC history>")

    # Final summary
    print(f"\n{'=' * 70}")
    print("DIAGNOSIS SUMMARY")
    print(f"{'=' * 70}")
    if vblank_values and len(set(vblank_values)) == 1:
        print(f"  VBlank counter STUCK at 0x{vblank_values[0]:08X}")
        print(f"  Root cause: VBlank interrupt handler not running")
        if vtable_ptr is not None:
            print(f"  VBlank handler vtable at 0x{vtable_ptr:08X}")
            if vtable_ptr == 0:
                print(f"  *** VTABLE POINTER IS NULL — handler never installed ***")
    else:
        print(f"  VBlank counter appears to be changing")

    bridge.close()
    print("\n[Done]")

if __name__ == '__main__':
    main()
