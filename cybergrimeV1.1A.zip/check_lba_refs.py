#!/usr/bin/env python3
"""Check what's at the old DW7 HBD LBA (354/355) on the phaseC disc,
   and compare with what's at the new HBD LBA (500)."""
import struct

def read_sector_data(disc, lba):
    return disc[lba * 2352 + 24: lba * 2352 + 24 + 2048]

with open(r'c:\LuxAura\VoidWalkers_Project\DQLOSTTRANSLATION\dq4_phaseC_build1.bin', 'rb') as f:
    frank_disc = f.read()

with open(r'c:\LuxAura\VoidWalkers_Project\DQLOSTTRANSLATION\DW7D1\DW7D1.bin', 'rb') as f:
    dw7_disc = f.read()

print("=== PhaseC disc: sectors 354-355 (old DW7 HBD LBA) ===")
for lba in [354, 355]:
    data = read_sector_data(frank_disc, lba)
    print(f"  LBA {lba}: first 32 bytes: {data[:32].hex()}")
    print(f"  LBA {lba}: first 16 bytes as ASCII: {data[:16].decode('ascii', errors='replace')}")

print("\n=== PhaseC disc: sector 500 (new HBD1PS1D.Q41 LBA) ===")
data = read_sector_data(frank_disc, 500)
print(f"  LBA 500: first 32 bytes: {data[:32].hex()}")
print(f"  LBA 500: first 16 bytes as ASCII: {data[:16].decode('ascii', errors='replace')}")

print("\n=== DW7 disc: sector 354 (original HBD1PS1D.W71 LBA) ===")
data = read_sector_data(dw7_disc, 354)
print(f"  LBA 354: first 32 bytes: {data[:32].hex()}")
print(f"  LBA 354: first 16 bytes as ASCII: {data[:16].decode('ascii', errors='replace')}")

# Check if the data at phaseC LBA 354-355 matches the HBD header at LBA 500
print("\n=== Comparing phaseC LBA 354 vs LBA 500 ===")
d354 = read_sector_data(frank_disc, 354)
d500 = read_sector_data(frank_disc, 500)
match = sum(1 for a, b in zip(d354[:64], d500[:64]) if a == b)
print(f"  First 64 bytes: {match}/64 match")

# Check what's at LBA 354-355 on phaseC — is it another file?
# The SLUSP012.06 EXE is at LBA 24, size 960948 = ~469 sectors
# So EXE spans LBA 24 to 24+469 = 493
# SYSTEM.CNF at LBA 23
# HBD1PS1D.Q41 at LBA 500
# What's at LBA 354? It's within the EXE file's sector range!
exe_end_lba = 24 + (960948 + 2047) // 2048
print(f"\n  EXE spans LBA 24 to {exe_end_lba} ({(960948 + 2047) // 2048} sectors)")
print(f"  LBA 354 is {'within' if 354 < exe_end_lba else 'after'} the EXE range")
print(f"  LBA 500 is {'within' if 500 < exe_end_lba else 'after'} the EXE range")

# So LBA 354 on phaseC is in the middle of the EXE file!
# The game's internal LBA references to 354 would read EXE data, not HBD data.

# Check the folder pointer remapping — what LBA delta is used?
# From the patcher: lba_delta = dq4_base_sector - HBD_LBA
# HBD_LBA for DW7 is 354
# dq4_base_sector for phaseC would be 500
# So lba_delta = 500 - 354 = 146
print(f"\n  LBA delta should be: 500 - 354 = {500 - 354}")
print(f"  If folder pointers are remapped with delta 146, LBA 354 -> {354 + 146}")

# Check the ABS table in the Frank EXE
# ABS_TABLE_START and REL_TABLE_START need to be found
# Let's search for the HBD LBA value (354 or 500) in the EXE
print("\n=== Searching for LBA values in Frank EXE ===")
def read_exe_from_disc(disc_path, exe_lba, exe_size):
    disc = disc_path
    exe = bytearray()
    sectors = (exe_size + 2047) // 2048
    for i in range(sectors):
        exe.extend(read_sector_data(disc, exe_lba + i))
    return bytes(exe[:exe_size])

frank_exe = read_exe_from_disc(frank_disc, 24, 960948)
dw7_exe = read_exe_from_disc(dw7_disc, 24, 675840)

# Search for 354 (0x162) as a 32-bit value in the EXE data
target_354 = struct.pack('<I', 354)
target_500 = struct.pack('<I', 500)
target_355 = struct.pack('<I', 355)

print("\nSearching for LBA=354 (0x162) in Frank EXE:")
pos = 0
count = 0
while pos < len(frank_exe) - 4 and count < 20:
    pos = frank_exe.find(target_354, pos)
    if pos < 0:
        break
    ram = 0x80017F00 + pos - 0x800
    print(f"  Found at EXE offset 0x{pos:X} (RAM 0x{ram:08X})")
    pos += 4
    count += 1

print(f"\nSearching for LBA=500 (0x1F4) in Frank EXE:")
pos = 0
count = 0
while pos < len(frank_exe) - 4 and count < 20:
    pos = frank_exe.find(target_500, pos)
    if pos < 0:
        break
    ram = 0x80017F00 + pos - 0x800
    print(f"  Found at EXE offset 0x{pos:X} (RAM 0x{ram:08X})")
    pos += 4
    count += 1

print(f"\nSearching for LBA=354 (0x162) in DW7 EXE:")
pos = 0
count = 0
while pos < len(dw7_exe) - 4 and count < 20:
    pos = dw7_exe.find(target_354, pos)
    if pos < 0:
        break
    ram = 0x80017F00 + pos - 0x800
    print(f"  Found at EXE offset 0x{pos:X} (RAM 0x{ram:08X})")
    pos += 4
    count += 1

# Also search for 355 (0x163)
print(f"\nSearching for LBA=355 (0x163) in Frank EXE:")
pos = 0
count = 0
while pos < len(frank_exe) - 4 and count < 20:
    pos = frank_exe.find(target_355, pos)
    if pos < 0:
        break
    ram = 0x80017F00 + pos - 0x800
    print(f"  Found at EXE offset 0x{pos:X} (RAM 0x{ram:08X})")
    pos += 4
    count += 1

print(f"\nSearching for LBA=355 (0x163) in DW7 EXE:")
pos = 0
count = 0
while pos < len(dw7_exe) - 4 and count < 20:
    pos = dw7_exe.find(target_355, pos)
    if pos < 0:
        break
    ram = 0x80017F00 + pos - 0x800
    print(f"  Found at EXE offset 0x{pos:X} (RAM 0x{ram:08X})")
    pos += 4
    count += 1
