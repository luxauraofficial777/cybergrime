@echo off
REM ============================================================================
REM BUILD SCRIPT — Agent Harness + Runner
REM ============================================================================
REM Compiles the agent testing harness and runner executable.
REM Uses MSVC (cl.exe) — must be run from a Developer Command Prompt
REM or after calling vcvarsall.bat.
REM
REM Usage:
REM   build_agent.bat          — release build
REM   build_agent.bat debug    — debug build with extra logging
REM ============================================================================

setlocal

set BASE_DIR=C:\LuxAura\VoidWalkers_Project\DQLOSTTRANSLATION\VHB_SUPER_BIOS_V1.00A\cybergrime
set OUT_DIR=%BASE_DIR%

set CXXFLAGS=/EHsc /O2 /std:c++17 /D_CRT_SECURE_NO_WARNINGS /DAGENT_HARNESS_ENABLED
set LINKFLAGS=/link /SUBSYSTEM:CONSOLE

if /i "%~1"=="debug" (
    set CXXFLAGS=/EHsc /Od /Zi /std:c++17 /D_CRT_SECURE_NO_WARNINGS /DAGENT_HARNESS_ENABLED /D_DEBUG
    set LINKFLAGS=/link /SUBSYSTEM:CONSOLE /DEBUG
)

REM ── Find and load MSVC environment ──────────────────────────────────────────
set VCVARS="C:\Program Files (x86)\Microsoft Visual Studio\2022\BuildTools\VC\Auxiliary\Build\vcvars64.bat"
if not exist %VCVARS% (
    echo ERROR: vcvars64.bat not found at expected path
    exit /b 1
)
call %VCVARS% >nul 2>&1

REM ── Handle clean rebuild request ───────────────────────────────────────────
if /i "%~1"=="clean" (
    echo [CLEAN] Removing stale object files and executable...
    if exist "%OUT_DIR%\agent_harness.obj" del /q "%OUT_DIR%\agent_harness.obj"
    if exist "%OUT_DIR%\psx_agent_runner.obj" del /q "%OUT_DIR%\psx_agent_runner.obj"
    if exist "%OUT_DIR%\psx_emulator_core.obj" del /q "%OUT_DIR%\psx_emulator_core.obj"
    if exist "%OUT_DIR%\instrumentation_bus.obj" del /q "%OUT_DIR%\instrumentation_bus.obj"
    if exist "%OUT_DIR%\psx_agent_runner.exe" del /q "%OUT_DIR%\psx_agent_runner.exe"
    echo [CLEAN] Done.
    echo.
)

REM ── Dependency sanity check (best-effort, no make) ──────────────────────────
for %%f in ("%BASE_DIR%\agent_harness.cpp" "%BASE_DIR%\psx_agent_runner.cpp" "%BASE_DIR%\psx_emulator_core.cpp" "%BASE_DIR%\agent_harness.h" "%BASE_DIR%\psx_emulator_core.h" "%BASE_DIR%\orchestration_engine.h") do (
    for %%o in ("%OUT_DIR%\agent_harness.obj" "%OUT_DIR%\psx_agent_runner.obj" "%OUT_DIR%\psx_emulator_core.obj") do (
        if exist "%%o" if exist "%%f" (
            for /f "usebackq tokens=*" %%a in (`powershell -NoProfile -Command "if ((Get-Item '%%f').LastWriteTime -gt (Get-Item '%%o').LastWriteTime) { Write-Host 'WARN: %%f is newer than %%o' }"`) do echo %%a
        )
    )
)

echo ============================================
echo  Building PSX Agent Runner
echo  Mode: %~1 (release if empty)
echo  Dir:  %BASE_DIR%
echo ============================================
echo.

REM ── Compile harness ────────────────────────────────────────────────────────
echo [1/2] Compiling agent_harness.cpp...
cl %CXXFLAGS% /c "%BASE_DIR%\agent_harness.cpp" /Fo:"%OUT_DIR%\agent_harness.obj"
if errorlevel 1 (
    echo FAILED: agent_harness.cpp compilation
    exit /b 1
)

REM ── Compile + link runner (includes emulator core + instrumentation bus) ───
echo [2/2] Compiling and linking psx_agent_runner.cpp + psx_emulator_core.cpp + instrumentation_bus.cpp...
cl %CXXFLAGS% ^
    "%BASE_DIR%\psx_agent_runner.cpp" ^
    "%BASE_DIR%\psx_emulator_core.cpp" ^
    "%BASE_DIR%\instrumentation_bus.cpp" ^
    "%OUT_DIR%\agent_harness.obj" ^
    /Fe:"%OUT_DIR%\psx_agent_runner.exe" ^
    %LINKFLAGS%

if errorlevel 1 (
    echo FAILED: psx_agent_runner.exe linking
    exit /b 1
)

echo.
echo ============================================
echo  BUILD SUCCESS
echo  Output: %OUT_DIR%\psx_agent_runner.exe
echo ============================================
echo.
echo Usage:
echo   psx_agent_runner.exe ^<disc.bin^> ^<profile_name^> [max_instrs] [json_path] [wallclock_ms]
echo.
echo CLI Flags:
echo   --bp ^<addr^>           Add breakpoint (log only)
echo   --bp-halt ^<addr^>       Add breakpoint that halts execution
echo   --wp ^<addr^>            Add memory watchpoint
echo   --trace-from ^<addr^>    Start instruction trace from address
echo   --trace-to ^<file^>      Trace output file path
echo   --inject ^<json^>        RAM injection spec file (Phase 9)
echo   --monitor ^<json^>       Buffer monitor spec file (Phase 10)
echo   --symbols ^<json^>       Load symbol table for named addresses
echo   --console                Enable interactive stdin console (Phase 11)
echo   --savestate-out ^<file^>  Save emulator state to file on exit
echo   --loadstate ^<file^>      Load emulator state from file before boot
echo   --screenshot ^<file.bmp^>  Dump framebuffer to BMP on exit
echo   --timeline ^<file.json^>   Export event timeline as JSON
echo   --gdb [port]            Start GDB remote stub (default port 3333)
echo   --rewind                Enable rewind snapshot buffer
echo   --lua ^<file.lua^>       Load Lua automation script
echo   --psn00b-align           Map watchpoints to BIOS vectors + GTE registers
echo   --huffman-trace          Active trace on decompression + text cache buffer
echo   --live-instrument ^<N^>    Enable instrumentation bus (emit state every N instrs)
echo   --rebuild-iso ^<xml^>    Generate ISO rebuild manifest from layout XML
echo.
echo Batch testing:
echo   run_agent_tests.bat [max_instrs] [wallclock_ms]
echo.

endlocal
