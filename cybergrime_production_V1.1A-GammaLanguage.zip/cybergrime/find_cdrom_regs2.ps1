# Search for ANY reference to 0x1AD0 in any instruction
# Could be: addiu $rt, $rs, 0x1AD0 (opcode 0x09)
# or: ori $rt, $rs, 0x1AD0 (opcode 0x0D)
# or: lw/sw/lb/sb with offset 0x1AD0
# Also search for 0xBF80 (alternate CDROM base) and 0x1F80

$exePath = 'c:\LuxAura\VoidWalkers_Project\DQLOSTTRANSLATION\translation\SLUSP012.06'
$bytes = [System.IO.File]::ReadAllBytes($exePath)
$loadAddr = 0x80017F00

$rn = @('zero','at','v0','v1','a0','a1','a2','a3','t0','t1','t2','t3','t4','t5','t6','t7','s0','s1','s2','s3','s4','s5','s6','s7','t8','t9','k0','k1','gp','sp','fp','ra')

# Search for any instruction with immediate 0x1AD0
Write-Host "=== Instructions with immediate 0x1AD0 ==="
for ($i = 0x800; $i -lt $bytes.Length - 3; $i += 4) {
    $insn = [BitConverter]::ToUInt32($bytes, $i)
    $imm = $insn -band 0xFFFF
    if ($imm -eq 0x1AD0) {
        $ram = $loadAddr + $i - 0x800
        $op = $insn -shr 26
        $rs = ($insn -shr 21) -band 0x1F; $rt = ($insn -shr 16) -band 0x1F
        $rsn=$rn[$rs]; $rtn=$rn[$rt]
        $d = ''
        if ($op -eq 0x09) { $d = "addiu $rtn,$rsn,0x1AD0" }
        elseif ($op -eq 0x0D) { $d = "ori $rtn,$rsn,0x1AD0" }
        elseif ($op -eq 0x08) { $d = "addi $rtn,$rsn,0x1AD0" }
        elseif ($op -eq 0x23) { $d = "lw $rtn,0x1AD0($rsn)" }
        elseif ($op -eq 0x2B) { $d = "sw $rtn,0x1AD0($rsn)" }
        elseif ($op -eq 0x20) { $d = "lb $rtn,0x1AD0($rsn)" }
        elseif ($op -eq 0x28) { $d = "sb $rtn,0x1AD0($rsn)" }
        elseif ($op -eq 0x24) { $d = "lbu $rtn,0x1AD0($rsn)" }
        else { $d = "op=0x$($op.ToString('X2'))" }
        # Check previous instruction for lui
        $prev = [BitConverter]::ToUInt32($bytes, $i - 4)
        $prevImm = $prev -band 0xFFFF
        $prevInfo = ''
        if (($prev -shr 26) -eq 0x0F) {
            $prevInfo = " [prev: lui $($rn[$rt]),0x$($prevImm.ToString('X4'))]"
        }
        Write-Host ("  RAM 0x{0:X8}: 0x{1:X8}  {2}{3}" -f $ram, $insn, $d, $prevInfo)
    }
}

# Search for 0x1AD1, 0x1AD2, 0x1AD3 (other CDROM registers)
Write-Host ""
Write-Host "=== Instructions with immediate 0x1AD1-0x1AD3 ==="
for ($i = 0x800; $i -lt $bytes.Length - 3; $i += 4) {
    $insn = [BitConverter]::ToUInt32($bytes, $i)
    $imm = $insn -band 0xFFFF
    if ($imm -ge 0x1AD1 -and $imm -le 0x1AD3) {
        $ram = $loadAddr + $i - 0x800
        $op = $insn -shr 26
        $rs = ($insn -shr 21) -band 0x1F; $rt = ($insn -shr 16) -band 0x1F
        $rsn=$rn[$rs]; $rtn=$rn[$rt]
        $d = "op=0x$($op.ToString('X2')) imm=0x$($imm.ToString('X4'))"
        if ($op -eq 0x28) { $d = "sb $rtn,0x$($imm.ToString('X4'))($rsn)" }
        elseif ($op -eq 0x24) { $d = "lbu $rtn,0x$($imm.ToString('X4'))($rsn)" }
        elseif ($op -eq 0x23) { $d = "lw $rtn,0x$($imm.ToString('X4'))($rsn)" }
        $prev = [BitConverter]::ToUInt32($bytes, $i - 4)
        $prevInfo = ''
        if (($prev -shr 26) -eq 0x0F) {
            $prevImm = $prev -band 0xFFFF
            $prevInfo = " [prev: lui 0x$($prevImm.ToString('X4'))]"
        }
        Write-Host ("  RAM 0x{0:X8}: 0x{1:X8}  {2}{3}" -f $ram, $insn, $d, $prevInfo)
    }
}

# Also search for lui with 0x1F80 or 0xBF80 anywhere
Write-Host ""
Write-Host "=== lui 0x1F80 ==="
$count = 0
for ($i = 0x800; $i -lt $bytes.Length - 3; $i += 4) {
    $insn = [BitConverter]::ToUInt32($bytes, $i)
    if (($insn -shr 26) -eq 0x0F -and ($insn -band 0xFFFF) -eq 0x1F80) {
        $ram = $loadAddr + $i - 0x800
        $rt = ($insn -shr 16) -band 0x1F
        Write-Host ("  RAM 0x{0:X8}: lui {1},0x1F80" -f $ram, $rn[$rt])
        $count++
        if ($count -ge 20) { Write-Host "  ... (truncated)"; break }
    }
}

Write-Host ""
Write-Host "=== lui 0xBF80 ==="
$count = 0
for ($i = 0x800; $i -lt $bytes.Length - 3; $i += 4) {
    $insn = [BitConverter]::ToUInt32($bytes, $i)
    if (($insn -shr 26) -eq 0x0F -and ($insn -band 0xFFFF) -eq 0xBF80) {
        $ram = $loadAddr + $i - 0x800
        $rt = ($insn -shr 16) -band 0x1F
        Write-Host ("  RAM 0x{0:X8}: lui {1},0xBF80" -f $ram, $rn[$rt])
        $count++
        if ($count -ge 20) { Write-Host "  ... (truncated)"; break }
    }
}
