import struct

exe_path = "../translation/SLUSP012.06"
with open(exe_path, "rb") as f:
    data = f.read()

# PSX EXE header format:
# 0x00: magic "PS-X EXE"
# 0x08: text_start (unused, usually 0)
# 0x0C: data_start (unused)  
# 0x10: load_addr (RAM address where file data after header is loaded)
# 0x14: pc0 (entry point)
# 0x18: gp (global pointer)
# 0x1C: text_size (size of data after header, padded to 2048)
# 0x20: data_size
# 0x24: bss_start
# 0x28: bss_size
# ...

header = data[:0x800]
magic = header[0:8]
text_start = struct.unpack_from("<I", header, 0x08)[0]
data_start = struct.unpack_from("<I", header, 0x0C)[0]
load_addr = struct.unpack_from("<I", header, 0x10)[0]
pc0 = struct.unpack_from("<I", header, 0x14)[0]
gp = struct.unpack_from("<I", header, 0x18)[0]
text_size = struct.unpack_from("<I", header, 0x1C)[0]
data_size = struct.unpack_from("<I", header, 0x20)[0]
bss_start = struct.unpack_from("<I", header, 0x24)[0]
bss_size = struct.unpack_from("<I", header, 0x28)[0]

print("=== PSX EXE HEADER ===")
print(f"  Magic:       {magic}")
print(f"  text_start:  0x{text_start:08X}")
print(f"  data_start:  0x{data_start:08X}")
print(f"  load_addr:   0x{load_addr:08X}")
print(f"  pc0:         0x{pc0:08X}")
print(f"  gp:          0x{gp:08X}")
print(f"  text_size:   0x{text_size:X} ({text_size} bytes)")
print(f"  data_size:   0x{data_size:X}")
print(f"  bss_start:   0x{bss_start:08X}")
print(f"  bss_size:    0x{bss_size:08X}")
print(f"  File size:   {len(data)} (0x{len(data):X})")
print()

# So load_addr is the RAM address where file offset 0x800 maps to.
# file_to_ram(foff) = foff - 0x800 + load_addr
ram_base = load_addr
print(f"  RAM base (file 0x800): 0x{ram_base:08X}")
print()

# Now recalculate all offsets with the correct load_addr
def file_to_ram(foff):
    return foff - 0x800 + load_addr

def ram_to_file(ram):
    return ram - load_addr + 0x800

# Verify: tree ptr pattern at file 0x03EBEC
print("=== Verifying offsets with correct load_addr ===")
print(f"  Tree ptr 1 at file 0x03EBEC -> RAM 0x{file_to_ram(0x03EBEC):08X}")
print(f"  Tree ptr 2 at file 0x03EC34 -> RAM 0x{file_to_ram(0x03EC34):08X}")
print(f"  Tree ptr 3 at file 0x0571FC -> RAM 0x{file_to_ram(0x0571FC):08X}")
print(f"  Tree ptr 4 at file 0x057244 -> RAM 0x{file_to_ram(0x057244):08X}")
print(f"  Site 3 (root ID) at file 0x0408F4 -> RAM 0x{file_to_ram(0x0408F4):08X}")
print(f"  Tree hook at file 0x03EBB8 -> RAM 0x{file_to_ram(0x03EBB8):08X}")
print(f"  Offset_b cand 1 at file 0x01AFB8 -> RAM 0x{file_to_ram(0x01AFB8):08X}")
print(f"  Offset_b cand 2 at file 0x01C5F8 -> RAM 0x{file_to_ram(0x01C5F8):08X}")
print(f"  Offset_b cand 3 at file 0x07CAA4 -> RAM 0x{file_to_ram(0x07CAA4):08X}")
print()

# Now check: what does the code assume as load_addr?
# The code uses load_addr member of ExePatcher. Let's check what it's initialized to.
# From the header: TREE_PTR_VAR_OFF=0xA4FF8 which was calculated as:
#   0x800BC6F8 - 0x80017F00 + 0x800 = 0xA4FF8
# This means the code assumes load_addr = 0x80017F00
# But the actual EXE has load_addr = 0x8008E284 (or maybe it's pc0?)

# Wait, let me re-check. PSX EXE header:
# 0x10 = load_addr (also called "initial PC" in some docs)
# Actually, in PSX EXE format:
#   0x10 = text_start (load address / entry point)
#   0x14 = entry_point (PC0)
# Some docs say 0x10 is the load address and 0x14 is PC0.

# Let's check if 0x8008E284 makes sense as a load address.
# DW7 EXE is known to load at 0x80017F00 in many references.
# But this might be a different version.

# Let's check: if load_addr = 0x8008E284, then file 0x800 = RAM 0x8008E284
# And the tree at file 0xA4800 would be at RAM 0x8008E284 + 0xA4000 = 0x801132284
# That doesn't make sense — it's above 0x801FFFFF (2MB RAM limit).

# Actually, 0x8008E284 is likely the PC0 (entry point), not the load address.
# In the PSX EXE header, offset 0x10 is sometimes called "load_addr" but is actually
# the initial PC. Let me check the actual spec.

# PSX EXE header (from nocash docs):
# 0x00: "PS-X EXE" (8 bytes)
# 0x08: text_start (usually 0)
# 0x0C: data_start (usually 0)  
# 0x10: load_addr (RAM address for loading the file)
# 0x14: pc0 (initial PC)
# 0x18: gp (initial $gp)
# 0x1C: text_size (file_size - 0x800, padded)

# So load_addr at 0x10 = 0x8008E284... but that's weird for DW7.
# Let me check if this is actually a pre-patched EXE.

# Actually wait — maybe I'm reading the wrong field. Let me dump the raw header bytes.
print("=== Raw header bytes 0x00-0x30 ===")
for i in range(0, 0x30, 4):
    val = struct.unpack_from("<I", header, i)[0]
    print(f"  0x{i:02X}: 0x{val:08X}")
print()

# Check if load_addr is really at 0x10 or if it's somewhere else
# Some PSX EXE formats have it at different offsets
# The standard format has:
# 0x10: load_addr (also called "initial PC" in some docs — confusing)
# Actually, looking at the nocash spec more carefully:
# 0x10 = "pc0" (initial program counter) — NOT load address!
# 0x14 = "gp0" (initial GP) — NOT pc0!
# 0x18 = "sp" — NOT gp!
# 0x1C = "text_size" — this one is consistent

# Wait no. Let me look at the actual PSX-EXE header layout from py_psx:
# 0x08: text_start
# 0x0C: data_start  
# 0x10: load_r (load address / initial PC)
# 0x14: pc0 (entry point — but some say this is gp)
# The confusion is that different tools label these differently.

# The key question: does file offset 0x800 map to RAM 0x80017F00 or 0x8008E284?
# If load_addr = 0x8008E284, then the tree at file 0xA4800 would be at 
# RAM 0x8008E284 + (0xA4800 - 0x800) = 0x8008E284 + 0xA4000 = 0x80132284
# That's within 2MB RAM (0x80200000), so it's possible.

# But the code's constants assume 0x80017F00:
# TREE_PTR_VAR_OFF = 0xA4FF8 = 0x800BC6F8 - 0x80017F00 + 0x800
# If load_addr is actually 0x8008E284:
# TREE_PTR_VAR_OFF should be = 0x800BC6F8 - 0x8008E284 + 0x800 = 0x0003DC74
# That's very different!

# Let me check what the code actually uses as load_addr
print("=== Checking what load_addr the code assumes ===")
# The code has: TREE_PTR_VAR_OFF = 0xA4FF8
# If this maps to RAM 0x800BC6F8, then:
# 0x800BC6F8 = 0xA4FF8 - 0x800 + load_addr
# load_addr = 0x800BC6F8 - 0xA4FF8 + 0x800 = 0x800BC6F8 - 0xA47F8 = 0x80017F00
print(f"  Code assumes load_addr = 0x80017F00")
print(f"  Actual EXE load_addr (header 0x10) = 0x{load_addr:08X}")
print(f"  Actual EXE pc0 (header 0x14) = 0x{pc0:08X}")
print()

# Hmm, 0x8008E284 as load_addr is unusual. Let me check if this is pc0 instead.
# In many PSX EXE tools, offset 0x10 is the entry point (PC0), and the load address
# is implied to be 0x80017F00 for standard SLUS executables.

# Actually, looking at the PSX EXE spec more carefully:
# The standard header has:
# 0x10: "pc0" — initial program counter (entry point)
# 0x14: "gp0" — initial global pointer
# 0x18: "sp" — initial stack pointer  
# 0x1C: "text_size" — size of program data after header

# The load address is typically NOT in the header — it's always 0x80017F00
# (or the address specified in the SYSTEM.CNF as the load address).

# So 0x8008E284 at offset 0x10 is PC0 (entry point), NOT load address!
# The actual load address IS 0x80017F00 as the code assumes.

# But wait — the build log said "PC0: 0x8008E284 (unchanged)" which matches header 0x10.
# And the code's file_to_ram conversion uses load_addr = 0x80017F00.
# So the offsets SHOULD be correct... but they're not matching.

# Let me verify by checking a known instruction at a known RAM address.
# The build log shows "Patched 0x8005F754: jal 0x80101000 + nop"
# RAM 0x8005F754 = file 0x8005F754 - 0x80017F00 + 0x800 = 0x048054
# Let's check what's at file 0x048054

print("=== Verifying file_to_ram mapping ===")
# If load_addr = 0x80017F00:
# RAM 0x8005F754 -> file 0x048054
# RAM 0x8005F728 -> file 0x048028
off = 0x048054
insn = struct.unpack_from("<I", data, off)[0]
print(f"  File 0x{off:06X} (RAM 0x8005F754): 0x{insn:08X}")

off = 0x048028
insn = struct.unpack_from("<I", data, off)[0]
print(f"  File 0x{off:06X} (RAM 0x8005F728): 0x{insn:08X}")
print()

# The build log says:
# "WARNING: original at 0x48054 is 0xE9ED0000 (expected 0x1260000D)"
# "WARNING: original at 0x8005F728 is 0xAD04FFEC (expected 0x8E91000C = lw s1,12(s4))"
# So the code IS using load_addr = 0x80017F00, and the file offsets ARE correct.
# The problem is that the EXPECTED instructions at those offsets are wrong!

# The tree pointer patterns are NOT at 0x04805C/0x0480A4 — they're at 0x03EBEC/0x03EC34.
# This means the offsets in the code were calculated from a DIFFERENT version of the EXE.

# Let's check: are there other EXE files that might be the "correct" one?
import os
exe_candidates = [
    "translation/SLUSP012.06",
    "translation/SLUSP012.06_disc_extract.bin",
    "translation/SLUSP012.06_PATCHED.bin",
    "translation/SLUSP012.06_FINAL.bin",
    "translation/SLUSP012.06_HYBRID.bin",
]
print("=== Checking all EXE candidates ===")
for p in exe_candidates:
    if not os.path.exists(p):
        print(f"  {p}: MISSING")
        continue
    with open(p, "rb") as f:
        d = f.read()
    hdr_load = struct.unpack_from("<I", d, 0x10)[0]
    hdr_pc0 = struct.unpack_from("<I", d, 0x14)[0]
    hdr_text = struct.unpack_from("<I", d, 0x1C)[0]
    # Check what's at file 0x04805C (expected tree ptr site 1)
    val1 = struct.unpack_from("<I", d, 0x04805C)[0] if len(d) > 0x048060 else 0
    val2 = struct.unpack_from("<I", d, 0x048060)[0] if len(d) > 0x048064 else 0
    # Check what's at file 0x03EBEC (our found tree ptr)
    val3 = struct.unpack_from("<I", d, 0x03EBEC)[0] if len(d) > 0x03EBF0 else 0
    val4 = struct.unpack_from("<I", d, 0x03EBF0)[0] if len(d) > 0x03EBF4 else 0
    print(f"  {p}:")
    print(f"    size={len(d)}, hdr[0x10]=0x{hdr_load:08X}, hdr[0x14]=0x{hdr_pc0:08X}, text=0x{hdr_text:X}")
    print(f"    @0x04805C: 0x{val1:08X} 0x{val2:08X} (expected lui+addiu for tree ptr)")
    print(f"    @0x03EBEC: 0x{val3:08X} 0x{val4:08X} (our found tree ptr)")
    # Check if 0x3C02800F (lui $v0,0x800F) is at 0x03EBEC
    if val3 == 0x3C02800F:
        print(f"    -> Tree ptr found at 0x03EBEC!")
    if val1 == 0x3C02800F:
        print(f"    -> Tree ptr found at 0x04805C!")
    print()
