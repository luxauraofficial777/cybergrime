$root = 'c:\LuxAura\VoidWalkers_Project\DQLOSTTRANSLATION'
$files = @(
    'dq4_heart_v17.bin',
    'frozen\dw7_hybrid_tree.bin',
    'dw7_hybrid_tree.bin',
    'translation\SLUSP012.06',
    'translation\SLUSP012.06_disc_extract.bin',
    'edcre\edcre-v1.1.0-windows-x86_64-static\edcre.exe'
)
# Also check for DQ4 Japan disc with special chars
$jp = Get-ChildItem -Path $root -Filter 'Dragon Quest IV*' -ErrorAction SilentlyContinue
if ($jp) { Write-Output "OK: $($jp.Name) ($($jp.Length) bytes)" }
else { Write-Output "MISSING: Dragon Quest IV Japan disc" }

foreach ($f in $files) {
    $p = Join-Path $root $f
    if (Test-Path $p) { Write-Output "OK: $f ($((Get-Item $p).Length) bytes)" }
    else { Write-Output "MISSING: $f" }
}
