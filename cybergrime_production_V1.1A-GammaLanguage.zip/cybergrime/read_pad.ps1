$j = Get-Content telemetry_pad_50m.json -Raw | ConvertFrom-Json
Write-Host "=== PAD 50M Run State ==="
Write-Host "Status: $($j.Pass_Status)"
Write-Host "Instructions: $($j.Instructions_Executed)"
Write-Host "VBlanks: $($j.VBlank_Count)"
Write-Host "Crashed: $($j.Crashed)"
Write-Host "Crash Reason: $($j.Crash_Reason)"
Write-Host "PC: $($j.Register_Dump.PC)"
Write-Host "GP: $($j.Register_Dump.gp)"
Write-Host ""
Write-Host "=== Non-Routine BIOS Calls ==="
foreach ($e in $j.BIOS_Call_Log) {
    $fn = '{0:X2}' -f [int]$e.fn
    $key = "$($e.table):0x$fn"
    if ($key -notin @('B:0x17','B:0x35')) {
        Write-Host ("  #{0} {1} ra={2} a0={3} a1={4} a2={5} a3={6}" -f $e.instr, $key, $e.ra, $e.a0, $e.a1, $e.a2, $e.a3)
    }
}
Write-Host ""
$tty = $j.TTY_Tail
Write-Host "TTY Tail (first 3000 chars):"
Write-Host $tty.Substring(0, [Math]::Min(3000, $tty.Length))
