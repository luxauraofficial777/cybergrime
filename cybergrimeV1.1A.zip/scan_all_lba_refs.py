#!/usr/bin/env python3
"""Comprehensive scan of ALL LBA references in the DW7 EXE that need patching."""
import struct

exe_path = r'..\translation\SLUSP012.06_disc_extract.bin'
with open(exe_path, 'rb') as f:
    data = f.read()

LOAD_ADDR = 0x80017F00
HBD_LBA_DW7 = 354
HBD_LBA_FRANK = 356
LBA_DELTA = HBD_LBA_FRANK - HBD_LBA_DW7  # +146

def f2r(off):
    return LOAD_ADDR + off - 0x800

# 1. Scan the entire EXE for 32-bit values in HBD LBA range (354-301793)
print(f'=== All 32-bit values in HBD LBA range ({HBD_LBA_DW7}-{HBD_LBA_DW7 + 301440}) ===')
print(f'    HBD on Frankenstein is at LBA {HBD_LBA_FRANK}, delta = +{LBA_DELTA}')
hbd_refs = []
for i in range(0x800, len(data) - 4, 4):
    val = struct.unpack('<I', data[i:i+4])[0]
    if HBD_LBA_DW7 <= val <= HBD_LBA_DW7 + 301440:
        ram = f2r(i)
        hbd_refs.append((i, ram, val))
        
print(f'Found {len(hbd_refs)} 32-bit HBD LBA references:')
for off, ram, val in hbd_refs:
    new_val = val + LBA_DELTA
    print(f'  file 0x{off:X} (RAM 0x{ram:08X}): LBA {val} -> should be {new_val}')

# 2. Also scan for 16-bit values in the HBD LBA range
print(f'\n=== 16-bit values in HBD LBA range ===')
hbd_refs_16 = []
for i in range(0x800, len(data) - 2, 2):
    val = struct.unpack('<H', data[i:i+2])[0]
    if HBD_LBA_DW7 <= val <= HBD_LBA_DW7 + 301440:
        # Check if this is part of a 32-bit value we already found
        is_part_of_32 = False
        for off, ram, val32 in hbd_refs:
            if i == off or i == off + 2:
                is_part_of_32 = True
                break
        if not is_part_of_32:
            ram = f2r(i)
            hbd_refs_16.append((i, ram, val))

print(f'Found {len(hbd_refs_16)} 16-bit HBD LBA references (excluding 32-bit hits):')
for off, ram, val in hbd_refs_16[:30]:
    new_val = val + LBA_DELTA
    print(f'  file 0x{off:X} (RAM 0x{ram:08X}): LBA {val} -> should be {new_val}')
if len(hbd_refs_16) > 30:
    print(f'  ... and {len(hbd_refs_16) - 30} more')

# 3. Dump the full LBA table region with analysis
print('\n=== Full LBA table analysis (0x8001B700-0x8001BB00) ===')
start = 0x8001B700 - LOAD_ADDR + 0x800
for i in range(0, 0x400, 4):
    off = start + i
    if off + 4 <= len(data):
        val = struct.unpack('<I', data[off:off+4])[0]
        ram = f2r(off)
        if HBD_LBA_DW7 <= val <= HBD_LBA_DW7 + 301440:
            new_val = val + LBA_DELTA
            print(f'  0x{ram:08X}: 0x{val:08X} ({val:>6}) -> HBD LBA, should be {new_val}')
        elif 0x80100000 <= val <= 0x801F0000:
            print(f'  0x{ram:08X}: 0x{val:08X}         -> PTR')
        elif 24 <= val <= 353:
            print(f'  0x{ram:08X}: 0x{val:08X} ({val:>6}) -> EXE LBA (no patch needed)')
        elif val < 0x100:
            print(f'  0x{ram:08X}: 0x{val:08X} ({val:>6}) -> small value')

# 4. Check what the builder currently patches
print('\n=== Builder current LBA patch ===')
print(f'  LBA_REF_OFF = 0x42E4 (RAM 0x8001B9E4)')
off = 0x42E4
val = struct.unpack('<I', data[off:off+4])[0]
print(f'  Current value: 0x{val:08X} ({val})')
print(f'  This is LBA {val} -> patched to {val + LBA_DELTA}')

# 5. Count how many HBD LBA refs need patching
patch_needed = [(off, ram, val, val + LBA_DELTA) for off, ram, val in hbd_refs]
print(f'\n=== SUMMARY ===')
print(f'  Total HBD LBA references found: {len(hbd_refs)}')
print(f'  Currently patched by builder: 1')
print(f'  Need to patch: {len(hbd_refs)}')
print(f'  LBA delta: +{LBA_DELTA}')
print(f'  HBD LBAs that need patching:')
for off, ram, val, new_val in patch_needed:
    print(f'    0x{ram:08X} (file 0x{off:X}): {val} -> {new_val}')

print('\n=== Done ===')
