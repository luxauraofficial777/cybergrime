import struct

exe_path = "../translation/SLUSP012.06"
with open(exe_path, "rb") as f:
    data = f.read()

def file_to_ram(foff):
    return foff - 0x800 + 0x80017F00

def decode_mips(insn):
    op = (insn >> 26) & 0x3F
    rs = (insn >> 21) & 0x1F
    rt = (insn >> 16) & 0x1F
    rd = (insn >> 11) & 0x1F
    sh = (insn >> 6) & 0x1F
    fn = insn & 0x3F
    imm = insn & 0xFFFF
    simm = imm if imm < 0x8000 else imm - 0x10000
    target = insn & 0x3FFFFFF
    regs = ["zero","at","v0","v1","a0","a1","a2","a3","t0","t1","t2","t3","t4","t5","t6","t7","s0","s1","s2","s3","s4","s5","s6","s7","t8","t9","k0","k1","gp","sp","fp","ra"]
    if insn == 0: return "nop"
    if op == 0x0F: return f"lui ${regs[rt]},0x{imm:04X}"
    if op == 0x09: return f"addiu ${regs[rt]},${regs[rs]},0x{imm:04X} ({simm})"
    if op == 0x23: return f"lw ${regs[rt]},0x{imm:04X}(${regs[rs]})"
    if op == 0x2B: return f"sw ${regs[rt]},0x{imm:04X}(${regs[rs]})"
    if op == 0x0C: return f"andi ${regs[rt]},${regs[rs]},0x{imm:04X}"
    if op == 0x0D: return f"ori ${regs[rt]},${regs[rs]},0x{imm:04X}"
    if op == 0x00:
        if fn == 0x21: return f"addu ${regs[rd]},${regs[rs]},${regs[rt]}"
        if fn == 0x25: return f"or ${regs[rd]},${regs[rs]},${regs[rt]}"
        if fn == 0x08: return f"jr ${regs[rs]}"
        if fn == 0x00: return f"sll ${regs[rd]},${regs[rt]},{sh}"
        if fn == 0x02: return f"srl ${regs[rd]},${regs[rt]},{sh}"
        if fn == 0x2A: return f"slt ${regs[rd]},${regs[rs]},${regs[rt]}"
        if fn == 0x2B: return f"sltu ${regs[rd]},${regs[rs]},${regs[rt]}"
        if fn == 0x24: return f"and ${regs[rd]},${regs[rs]},${regs[rt]}"
        return f"special fn=0x{fn:02X}"
    if op == 0x04: return f"beq ${regs[rs]},${regs[rt]},+{simm*4+4:#x}"
    if op == 0x05: return f"bne ${regs[rs]},${regs[rt]},+{simm*4+4:#x}"
    if op == 0x02: return f"j 0x{(target<<2):08X}"
    if op == 0x03: return f"jal 0x{(target<<2):08X}"
    if op == 0x25: return f"lhu ${regs[rt]},0x{imm:04X}(${regs[rs]})"
    if op == 0x24: return f"lbu ${regs[rt]},0x{imm:04X}(${regs[rs]})"
    if op == 0x20: return f"lb ${regs[rt]},0x{imm:04X}(${regs[rs]})"
    if op == 0x28: return f"sb ${regs[rt]},0x{imm:04X}(${regs[rs]})"
    if op == 0x29: return f"sh ${regs[rt]},0x{imm:04X}(${regs[rs]})"
    return f"op=0x{op:02X} raw=0x{insn:08X}"

def dump_at(foff, label, count=10):
    ram = file_to_ram(foff)
    print(f"--- {label} ---")
    for i in range(count):
        off = foff + i*4
        if off+4 > len(data): break
        insn = struct.unpack_from("<I", data, off)[0]
        print(f"  0x{off:06X} (RAM 0x{ram+i*4:08X}): 0x{insn:08X}  {decode_mips(insn)}")
    print()

# The key question: which are the decompressor Sites 1&2?
# Candidates: 0x03EBEC/0x03EC34 (close pair) and 0x0571FC/0x057244 (close pair)
# Both have identical pattern: lui $v0,0x800F + addiu $v0,$v0,0xF1C8 + sll $v1,$v1,1 + addu $s0,$v1,$v0

# The tree hook (lw $s1,12($s4)) is at 0x03EBB8, right before the first pair.
# This strongly suggests Sites 1&2 are at 0x03EBEC/0x03EC34 (in the block loader).
# The second pair at 0x0571FC/0x057244 might be in a different decompressor function.

# Let's check: are there exactly 2 sites or 4?
# The code has DECOMP_TREE_PTR1_OFF and DECOMP_TREE_PTR2_OFF (2 sites).
# But we found 4 instances. Let's check if the second pair is also in decompressor context.

print("=== Second pair context (0x0571FC) ===")
dump_at(0x0571FC - 24, "Second pair broader context", 12)

# Also check: the Site 3 pattern at 0x0408EC has lhu between lui and addiu.
# This means patch_decomp_root_id_plus1 (static) can still work — it only patches the addiu.
# But patch_decomp_root_id_runtime (JAL stub) needs lui+addiu adjacent.
# We need to adapt the runtime function for this layout.

print("=== Site 3 detailed (0x0408EC) ===")
dump_at(0x0408EC, "Site 3 - root ID lookup", 8)

# Now let's figure out the offset_b mask.
# The decompressor code is around RAM 0x80056xxx and 0x8006Exxx.
# Let's check which andi is in the decompressor function.
# Candidate 1: 0x01AFB8 (RAM 0x800326B8) — has ori +2 after, then sh. Looks like it forces even+2.
# Candidate 2: 0x01C5F8 (RAM 0x80033CF8) — has sh after. Also forces even.
# Candidate 3: 0x07CAA4 (RAM 0x800941A4) — far from decompressor.

# The old hardcoded offset was 0x1EEA8 (RAM 0x800365A8).
# Candidate 1 at 0x800326B8 is ~0x3EF0 before the old offset.
# Candidate 2 at 0x80033CF8 is ~0x28F0 before.
# Neither is super close. Let's search for the decompressor function boundaries.

# The decompressor is called from multiple sites. Let's look for JAL to the decompressor.
# The tree ref sites are at 0x800562EC and 0x8006E8FC.
# Let's see what function contains the Site 3 pattern at 0x80057FEC.

print("=== Looking for decompressor function around Site 3 (0x0408EC) ===")
dump_at(0x0408EC - 40, "Before Site 3", 15)

# Let's also check the second Site 3 candidate at 0x086690
print("=== Second Site 3 candidate (0x086690) ===")
dump_at(0x086690, "Second root ID pattern", 6)

# Check if there's a second root ID lookup in the second decompressor pair area
# Search for: andi $v0,$v0,0x7FFF + sll $v0,$v0,1 + addu $v0,$v0,$v1
# This is the root ID calculation pattern
print("=== Searching for andi $v0,$v0,0x7FFF + sll $v0,$v0,1 + addu $v0,$v0,$v1 ===")
pattern = struct.pack("<III", 0x30427FFF, 0x00021040, 0x00431021)
pos = 0
while True:
    pos = data.find(pattern, pos)
    if pos == -1: break
    ram = file_to_ram(pos)
    # Look back for the addiu $v1,$v1,* that provides tree base
    prev1 = struct.unpack_from("<I", data, pos-4)[0] if pos >= 4 else 0
    prev2 = struct.unpack_from("<I", data, pos-8)[0] if pos >= 8 else 0
    prev3 = struct.unpack_from("<I", data, pos-12)[0] if pos >= 12 else 0
    print(f"  Found at file 0x{pos:06X} (RAM 0x{ram:08X})")
    print(f"    -12: 0x{prev3:08X} {decode_mips(prev3)}")
    print(f"    -8:  0x{prev2:08X} {decode_mips(prev2)}")
    print(f"    -4:  0x{prev1:08X} {decode_mips(prev1)}")
    print(f"    +0:  0x{struct.unpack_from('<I',data,pos)[0]:08X} andi $v0,$v0,0x7FFF")
    print(f"    +4:  0x{struct.unpack_from('<I',data,pos+4)[0]:08X} sll $v0,$v0,1")
    print(f"    +8:  0x{struct.unpack_from('<I',data,pos+8)[0]:08X} addu $v0,$v0,$v1")
    print()
    pos += 4

# Also check: what's the actual EXE load address and text size from the header?
header = data[:0x800]
magic = header[0:8]
load_addr = struct.unpack_from("<I", header, 0x10)[0]
text_size = struct.unpack_from("<I", header, 0x1C)[0]
pc0 = struct.unpack_from("<I", header, 0x14)[0]
print(f"\n=== EXE HEADER ===")
print(f"  Magic: {magic}")
print(f"  Load addr: 0x{load_addr:08X}")
print(f"  Text size: 0x{text_size:X} ({text_size} bytes)")
print(f"  PC0: 0x{pc0:08X}")
print(f"  File size: {len(data)} (0x{len(data):X})")
print(f"  Code starts at file 0x800 (RAM 0x{load_addr:08X})")
