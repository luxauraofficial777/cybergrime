$j = Get-Content telemetry_cdromfix_10m.json -Raw | ConvertFrom-Json
$lines = $j.TTY_Tail -split "`n"
Write-Host "=== VBC lines ==="
$vbc = $lines | Where-Object { $_ -match 'VBC2|VBC1|VBC_' }
Write-Host "VBC lines: $($vbc.Count)"
$vbc | Select-Object -First 20 | ForEach-Object { Write-Host "  $_" }
Write-Host ""
Write-Host "=== MEMDUMP lines ==="
$mem = $lines | Where-Object { $_ -match 'MEMDUMP' }
$mem | ForEach-Object { Write-Host "  $_" }
Write-Host ""
Write-Host "=== HookEntry / SysEnq lines ==="
$hook = $lines | Where-Object { $_ -match 'HookEntry|SysEnq|hook_entry' }
Write-Host "Hook lines: $($hook.Count)"
$hook | Select-Object -First 10 | ForEach-Object { Write-Host "  $_" }
Write-Host ""
Write-Host "=== Interrupt handler lines ==="
$intp = $lines | Where-Object { $_ -match 'interrupt|IRQ|VBlank.*int|handler' }
Write-Host "Interrupt lines: $($intp.Count)"
$intp | Select-Object -First 10 | ForEach-Object { Write-Host "  $_" }
