import struct

dw7_disc = r"c:\LuxAura\VoidWalkers_Project\DQLOSTTRANSLATION\DW7D1\DW7D1.bin"
dq4_disc = r"c:\LuxAura\VoidWalkers_Project\DQLOSTTRANSLATION\Dragon Quest IV - Michibikareshi Mono Tachi (Japan).bin"
sector_size = 2352
data_offset = 24
user_size = 2048

print("=== DW7 HBD First Block Header ===")
with open(dw7_disc, 'rb') as f:
    f.seek(354 * sector_size + data_offset)
    raw = f.read(user_size * 4)
    
    # DW7 uses hts=1366 — block header is 24 bytes but hts field is different
    end, bid, hts, te, xe, unk = struct.unpack_from('<6I', raw, 0)
    print(f"  Raw: end={end} bid={bid} hts={hts} tree_end={te} text_end={xe} unk={unk}")
    print(f"  hts=1366? {hts == 1366}")
    
    # DW7 HBD doesn't start with a block — it has a folder/file directory structure
    # Let's dump first 64 bytes as hex
    print(f"  First 64 bytes (hex):")
    for i in range(0, 64, 16):
        hex_str = ' '.join(f'{b:02X}' for b in raw[i:i+16])
        print(f"    [{i:4d}] {hex_str}")
    
    # Scan for hts=24 or hts=1366 blocks in DW7 HBD
    found_24 = False
    found_1366 = False
    for i in range(0, min(len(raw) - 24, 32768), 4):
        e, b, h, t, x, u = struct.unpack_from('<6I', raw, i)
        if h == 24 and 24 < e < 1048576 and t > 0 and x > 0:
            print(f"  Found hts=24 block at offset {i}: end={e} bid={b}(0x{b:X})")
            found_24 = True
            break
        if h == 1366 and 1366 < e < 1048576:
            print(f"  Found hts=1366 block at offset {i}: end={e} bid={b}(0x{b:X})")
            found_1366 = True
            break
    if not found_24 and not found_1366:
        print("  No valid blocks found in first 32KB of DW7 HBD")

print("\n=== DQ4 HBD First Block Header ===")
with open(dq4_disc, 'rb') as f:
    f.seek(362 * sector_size + data_offset)
    raw = f.read(user_size * 4)
    
    # DQ4 uses hts=24 — scan for first valid block
    for i in range(0, min(len(raw) - 24, 32768), 4):
        end, bid, hts, te, xe, unk = struct.unpack_from('<6I', raw, i)
        if hts == 24 and 24 < end < 1048576 and te > 0 and xe > 0 and te < end and xe < end:
            print(f"  First valid block at offset {i}: end={end} bid={bid}(0x{bid:X}) hts={hts} tree_end={te} text_end={xe}")
            
            # Read tree metadata
            if i + xe + 10 <= len(raw):
                ts, tm, tn = struct.unpack_from('<IIH', raw, i + xe)
                print(f"  tree_start={ts} tree_middle={tm} tree_nodes={tn}")
                
                # Read tree bytes
                tree_bytes = raw[i + ts:i + te]
                print(f"  tree_size={len(tree_bytes)} bytes")
                
                # Check first few nodes
                for j in range(0, min(20, len(tree_bytes)), 2):
                    val = struct.unpack_from('<H', tree_bytes, j)[0]
                    ntype = "BRANCH" if val & 0x8000 else "LEAF"
                    print(f"    [{j:4d}] 0x{val:04X} ({ntype}, id={val & 0x7FFF})")
            break

print("\n=== DISC LBA MAP COMPARISON ===")
print(f"{'Sector':<10} {'DQ4':<30} {'DW7':<30}")
print(f"{'16':<10} {'PVD (DRAGONQUEST4_1)':<30} {'PVD (DRAGONWARRIOR7_1)':<30}")
print(f"{'22':<10} {'Root directory':<30} {'Root directory':<30}")
print(f"{'23':<10} {'SYSTEM.CNF (SLPM_869.16)':<30} {'SYSTEM.CNF (SLUSP012.06)':<30}")
print(f"{'24':<10} {'DQ4 EXE (692224 bytes)':<30} {'DW7 EXE (675840 bytes)':<30}")
print(f"{'24-361':<10} {'EXE slot (338 sectors)':<30} {'EXE slot (330 sectors)':<30}")
print(f"{'354':<10} {'---':<30} {'DW7 HBD start':<30}")
print(f"{'362':<10} {'DQ4 HBD start':<30} {'---':<30}")
print(f"{'362+155975':<10} {'DQ4 HBD end (156337)':<30} {'---':<30}")
print(f"{'354+301760':<10} {'---':<30} {'DW7 HBD end (302114)':<30}")

print("\n=== REWRITE OPTION A: DQ4 DISC AS BASE ===")
print("1. Copy DQ4 disc as base")
print("2. Write DW7 EXE at sector 24 (fits: 675840 < 692224)")
print("3. Update SYSTEM.CNF: SLPM_869.16 -> SLUSP012.06")
print("4. Update ISO directory: EXE name + size")
print("5. Patch DW7 EXE:")
print("   a. HBD LBA: 354 -> 362 (1 patch)")
print("   b. Tree pointer: global 0x800BC700 -> per-block inline")
print("   c. Root ID: +1 convention")
print("   d. Offset_b: remove &~1 mask")
print("   e. Sub-block fields: DQ4 order")
print("   f. BSS narrow patch (preserve 0x800D9E80)")
print("   g. Disc check bypass (10 patches)")
print("6. DQ4 HBD stays UNMODIFIED at sector 362")
print("7. Regenerate EDC/ECC")
print("8. Test in DuckStation")
