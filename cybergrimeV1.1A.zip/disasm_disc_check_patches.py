#!/usr/bin/env python3
"""Step 1: Disassemble original code at all disc-check patch sites + CD init function.

Reads the clean DW7 EXE and disassembles MIPS instructions at each patch offset
to understand what the original code does and what the patches skip.
"""
import struct
import sys

EXE_PATH = r"C:\LuxAura\VoidWalkers_Project\DQLOSTTRANSLATION\translation\SLUSP012.06_clean.bin"
LOAD_ADDR = 0x80017F00
EXE_HEADER = 0x800

with open(EXE_PATH, "rb") as f:
    exe = f.read()

print(f"EXE size: {len(exe)} bytes (0x{len(exe):X})")

REG_NAMES = ["zero","at","v0","v1","a0","a1","a2","a3",
             "t0","t1","t2","t3","t4","t5","t6","t7",
             "s0","s1","s2","s3","s4","s5","s6","s7",
             "t8","t9","k0","k1","gp","sp","fp","ra"]

def ram_addr(file_off):
    return LOAD_ADDR + file_off - EXE_HEADER

def disasm(val, pc):
    """Basic MIPS disassembly."""
    if val == 0:
        return "nop"
    opcode = (val >> 26) & 0x3F
    rs = (val >> 21) & 0x1F
    rt = (val >> 16) & 0x1F
    rd = (val >> 11) & 0x1F
    shamt = (val >> 6) & 0x1F
    funct = val & 0x3F
    imm = val & 0xFFFF
    simm = imm if imm < 0x8000 else imm - 0x10000
    target = (val & 0x3FFFFFF) << 2

    if opcode == 0x0F:
        return f"lui ${REG_NAMES[rt]}, 0x{imm:04X}"
    elif opcode == 0x09:
        return f"addiu ${REG_NAMES[rt]}, ${REG_NAMES[rs]}, {simm} (0x{imm:04X})"
    elif opcode == 0x08:
        return f"addi ${REG_NAMES[rt]}, ${REG_NAMES[rs]}, {simm} (0x{imm:04X})"
    elif opcode == 0x0C:
        return f"andi ${REG_NAMES[rt]}, ${REG_NAMES[rs]}, 0x{imm:04X}"
    elif opcode == 0x0D:
        return f"ori ${REG_NAMES[rt]}, ${REG_NAMES[rs]}, 0x{imm:04X}"
    elif opcode == 0x23:
        return f"lw ${REG_NAMES[rt]}, {simm}(${REG_NAMES[rs]})"
    elif opcode == 0x2B:
        return f"sw ${REG_NAMES[rt]}, {simm}(${REG_NAMES[rs]})"
    elif opcode == 0x20:
        return f"lb ${REG_NAMES[rt]}, {simm}(${REG_NAMES[rs]})"
    elif opcode == 0x24:
        return f"lbu ${REG_NAMES[rt]}, {simm}(${REG_NAMES[rs]})"
    elif opcode == 0x28:
        return f"sb ${REG_NAMES[rt]}, {simm}(${REG_NAMES[rs]})"
    elif opcode == 0x29:
        return f"sh ${REG_NAMES[rt]}, {simm}(${REG_NAMES[rs]})"
    elif opcode == 0x05:
        tgt = pc + 4 + simm * 4
        return f"bne ${REG_NAMES[rs]}, ${REG_NAMES[rt]}, 0x{tgt:08X} (off={simm})"
    elif opcode == 0x04:
        tgt = pc + 4 + simm * 4
        return f"beq ${REG_NAMES[rs]}, ${REG_NAMES[rt]}, 0x{tgt:08X} (off={simm})"
    elif opcode == 0x06:
        tgt = pc + 4 + simm * 4
        return f"blez ${REG_NAMES[rs]}, 0x{tgt:08X} (off={simm})"
    elif opcode == 0x07:
        tgt = pc + 4 + simm * 4
        return f"bgtz ${REG_NAMES[rs]}, 0x{tgt:08X} (off={simm})"
    elif opcode == 0x01:
        if rt == 0:
            tgt = pc + 4 + simm * 4
            return f"bltz ${REG_NAMES[rs]}, 0x{tgt:08X} (off={simm})"
        elif rt == 1:
            tgt = pc + 4 + simm * 4
            return f"bgez ${REG_NAMES[rs]}, 0x{tgt:08X} (off={simm})"
    elif opcode == 0x02:
        return f"j 0x{target:08X}"
    elif opcode == 0x03:
        return f"jal 0x{target:08X}"
    elif opcode == 0x00:
        if funct == 0x08:
            return f"jr ${REG_NAMES[rs]}"
        elif funct == 0x09:
            return f"jalr ${REG_NAMES[rd]}, ${REG_NAMES[rs]}"
        elif funct == 0x21:
            return f"addu ${REG_NAMES[rd]}, ${REG_NAMES[rs]}, ${REG_NAMES[rt]}"
        elif funct == 0x23:
            return f"subu ${REG_NAMES[rd]}, ${REG_NAMES[rs]}, ${REG_NAMES[rt]}"
        elif funct == 0x24:
            return f"and ${REG_NAMES[rd]}, ${REG_NAMES[rs]}, ${REG_NAMES[rt]}"
        elif funct == 0x25:
            return f"or ${REG_NAMES[rd]}, ${REG_NAMES[rs]}, ${REG_NAMES[rt]}"
        elif funct == 0x2A:
            return f"slt ${REG_NAMES[rd]}, ${REG_NAMES[rs]}, ${REG_NAMES[rt]}"
        elif funct == 0x2B:
            return f"sltu ${REG_NAMES[rd]}, ${REG_NAMES[rs]}, ${REG_NAMES[rt]}"
        elif funct == 0x00:
            if shamt:
                return f"sll ${REG_NAMES[rd]}, ${REG_NAMES[rt]}, {shamt}"
            return "nop"
        elif funct == 0x02:
            return f"srl ${REG_NAMES[rd]}, ${REG_NAMES[rt]}, {shamt}"
        elif funct == 0x03:
            return f"sra ${REG_NAMES[rd]}, ${REG_NAMES[rt]}, {shamt}"
        elif funct == 0x04:
            return f"sllv ${REG_NAMES[rd]}, ${REG_NAMES[rt]}, ${REG_NAMES[rs]}"
        elif funct == 0x06:
            return f"srlv ${REG_NAMES[rd]}, ${REG_NAMES[rt]}, ${REG_NAMES[rs]}"
        elif funct == 0x07:
            return f"srav ${REG_NAMES[rd]}, ${REG_NAMES[rt]}, ${REG_NAMES[rs]}"
        elif funct == 0x0C:
            return f"syscall 0x{(val >> 6) & 0xFFFFF:05X}"
        elif funct == 0x10:
            return f"mfhi ${REG_NAMES[rd]}"
        elif funct == 0x12:
            return f"mflo ${REG_NAMES[rd]}"
        elif funct == 0x18:
            return f"mult ${REG_NAMES[rs]}, ${REG_NAMES[rt]}"
        elif funct == 0x19:
            return f"multu ${REG_NAMES[rs]}, ${REG_NAMES[rt]}"
        elif funct == 0x1A:
            return f"div ${REG_NAMES[rs]}, ${REG_NAMES[rt]}"
        elif funct == 0x1B:
            return f"divu ${REG_NAMES[rs]}, ${REG_NAMES[rt]}"
        else:
            return f"R-type funct=0x{funct:02X}"
    elif opcode == 0x10:
        # COP0
        if rs == 0:
            return f"mfc0 ${REG_NAMES[rt]}, ${rd}"
        elif rs == 4:
            return f"mtc0 ${REG_NAMES[rt]}, ${rd}"
        else:
            return f"cop0 rs={rs} rt={rt} rd={rd}"
    elif opcode == 0x11:
        # COP1 (FPU)
        return f"cop1 0x{val:08X}"
    elif opcode == 0x12:
        # COP2
        if rs == 0:
            return f"mfc2 ${REG_NAMES[rt]}"
        elif rs == 4:
            return f"mtc2 ${REG_NAMES[rt]}"
        else:
            return f"cop2 0x{val:08X}"
    elif opcode == 0x30:
        return f"lwc0 ${REG_NAMES[rt]}, {simm}(${REG_NAMES[rs]})"
    elif opcode == 0x32:
        return f"lwc2 ${REG_NAMES[rt]}, {simm}(${REG_NAMES[rs]})"
    elif opcode == 0x38:
        return f"swc0 ${REG_NAMES[rt]}, {simm}(${REG_NAMES[rs]})"
    elif opcode == 0x3A:
        return f"swc2 ${REG_NAMES[rt]}, {simm}(${REG_NAMES[rs]})"
    return f"op=0x{opcode:02X} raw=0x{val:08X}"

def read_word(off):
    if off + 4 > len(exe):
        return None
    return struct.unpack_from("<I", exe, off)[0]

def disasm_region(name, file_off, count, patch_val=None, patch_desc=None):
    ram = ram_addr(file_off)
    print(f"\n{'='*80}")
    print(f"  {name}")
    print(f"  File offset: 0x{file_off:X}, RAM: 0x{ram:08X}")
    if patch_val is not None:
        if isinstance(patch_val, list):
            print(f"  PATCH: {patch_desc}")
            for i, pv in enumerate(patch_val):
                print(f"    Word {i}: 0x{pv:08X} → {disasm(pv, ram + i*4)}")
        else:
            print(f"  PATCH: 0x{patch_val:08X} → {disasm(patch_val, ram)}")
            print(f"  DESC: {patch_desc}")
    print(f"  Original code ({count} instructions before + after):")
    print(f"{'='*80}")
    
    start = file_off - count * 4
    total = count * 2 + 1  # 'count' before + 1 at offset + 'count' after
    
    for i in range(total):
        off = start + i * 4
        if off < 0 or off + 4 > len(exe):
            continue
        val = read_word(off)
        if val is None:
            continue
        r = ram_addr(off)
        marker = " <<< PATCH SITE" if off == file_off else ""
        print(f"  0x{off:05X} (RAM 0x{r:08X}): 0x{val:08X}  {disasm(val, r)}{marker}")

# ===== CD Init function at 0x60FA4 =====
disasm_region("CD INIT FUNCTION (0x60FA4)", 0x60FA4, 20)

# ===== All 10 disc-check patch sites =====
disasm_region("PATCH 1: disc_check_exit1_return_success (0x6112C)", 
              0x6112C, 10, 0x24020001, "addiu $v0, $zero, 1 (force success)")

disasm_region("PATCH 2: disc_check_exit2_return_success (0x611D8)",
              0x611D8, 10, 0x24020001, "addiu $v0, $zero, 1 (force success)")

disasm_region("PATCH 3: disc_check_exit3_return_success (0x613B8)",
              0x613B8, 10, 0x24020001, "addiu $v0, $zero, 1 (force success)")

disasm_region("PATCH 4: nop_timeout_check (0x614A4)",
              0x614A4, 10, 0x00000000, "nop (skip timeout check)")

disasm_region("PATCH 5: nop_error_path (0x614F8)",
              0x614F8, 10, 0x00000000, "nop (skip error path)")

disasm_region("PATCH 6: neutralize_disc_change_handler (0x387CC)",
              0x387CC, 10, [0x03E00008, 0x00000000, 0x00000000], 
              "jr $ra + nop + nop (return immediately — skip entire handler)")

disasm_region("PATCH 7: redirect_disc_trap_to_success (0x7308C)",
              0x7308C, 10, 0x08022BE9, "j 0x800A2BE8 (redirect to success path)")

disasm_region("PATCH 8: graft_a_gate1_always_skip_disc_change (0x61424)",
              0x61424, 10, 0x1000000B, "beq $zero, $zero, +11 (always branch — skip disc change)")

disasm_region("PATCH 9: graft_b_gate3_always_skip_disc_change (0x61520)",
              0x61520, 10, 0x1000000B, "beq $zero, $zero, +11 (always branch — skip disc change)")

disasm_region("PATCH 10: graft_c_string_compare_always_match (0x61360)",
              0x61360, 10, 0x1000000A, "beq $zero, $zero, +10 (always branch — skip string compare)")

# ===== Also check what's at 0x800A2BE8 (the redirect target) =====
disasm_region("REDIRECT TARGET: 0x800A2BE8 (success path)",
              0x800A2BE8 - LOAD_ADDR + EXE_HEADER, 15)

# ===== Check the function containing 0x387CC — what does the disc change handler do? =====
# Find function start by looking backwards for addiu $sp, $sp, -XX
print(f"\n{'='*80}")
print(f"  SEARCHING FOR disc_change_handler FUNCTION START (before 0x387CC)")
print(f"{'='*80}")
handler_off = 0x387CC
for i in range(50, 0, -1):
    off = handler_off - i * 4
    if off < 0:
        break
    val = read_word(off)
    if val is None:
        continue
    r = ram_addr(off)
    d = disasm(val, r)
    if "addiu $sp, $sp," in d or "addiu $sp," in d:
        print(f"  Likely function start at 0x{off:X} (RAM 0x{r:08X}): {d}")
        # Disassemble from here to the patch site
        for j in range(i + 15):
            off2 = off + j * 4
            if off2 + 4 > len(exe):
                break
            val2 = read_word(off2)
            if val2 is None:
                continue
            r2 = ram_addr(off2)
            marker = " <<< PATCH SITE" if off2 == handler_off else ""
            print(f"    0x{off2:05X} (RAM 0x{r2:08X}): 0x{val2:08X}  {disasm(val2, r2)}{marker}")
        break

# ===== Check callers of the disc change handler (0x387CC region) =====
# The function at 0x387CC is at RAM 0x800506CC
handler_ram = ram_addr(handler_off)
print(f"\n{'='*80}")
print(f"  SEARCHING FOR JAL/CALLS TO disc_change_handler (RAM 0x{handler_ram:08X})")
print(f"{'='*80}")
jal_target = (handler_ram >> 2) & 0x3FFFFFF
jal_val = 0x0C000000 | jal_target
for off in range(EXE_HEADER, len(exe) - 4, 4):
    val = read_word(off)
    if val is None:
        continue
    if val == jal_val:
        r = ram_addr(off)
        print(f"  JAL to handler at 0x{off:X} (RAM 0x{r:08X})")
        # Show context
        for j in range(-2, 3):
            off2 = off + j * 4
            if off2 < 0 or off2 + 4 > len(exe):
                continue
            val2 = read_word(off2)
            if val2 is None:
                continue
            r2 = ram_addr(off2)
            marker = " <<< JAL" if j == 0 else ""
            print(f"    0x{off2:05X} (RAM 0x{r2:08X}): 0x{val2:08X}  {disasm(val2, r2)}{marker}")

print(f"\n{'='*80}")
print(f"  ANALYSIS COMPLETE")
print(f"{'='*80}")
