$j = Get-Content telemetry_hw_10m.json -Raw | ConvertFrom-Json
Write-Host "=== HW 10M Run State ==="
Write-Host "Status: $($j.Pass_Status)"
Write-Host "Instructions: $($j.Instructions_Executed)"
Write-Host "VBlanks: $($j.VBlank_Count)"
Write-Host "Crashed: $($j.Crashed)"
Write-Host ""
Write-Host "=== Hardware State ==="
Write-Host "CD-ROM Reading: $($j.HW_State.cdrom_reading)"
Write-Host "CD-ROM Sectors Read: $($j.HW_State.cdrom_sectors_read)"
Write-Host "CD-ROM Current LBA: $($j.HW_State.cdrom_cur_lba)"
Write-Host "CD-ROM Data Ready: $($j.HW_State.cdrom_data_ready)"
Write-Host "PAD Started: $($j.HW_State.pad_started)"
Write-Host "PAD Buf1 Addr: $($j.HW_State.pad_buf1_addr)"
Write-Host "PAD1 Buttons: $($j.HW_State.pad1_buttons)"
Write-Host ""
Write-Host "=== Non-Routine BIOS Calls ==="
foreach ($e in $j.BIOS_Call_Log) {
    $fn = '{0:X2}' -f [int]$e.fn
    $key = "$($e.table):0x$fn"
    if ($key -notin @('B:0x17','B:0x35')) {
        Write-Host ("  #{0} {1} ra={2} a0={3} a1={4} a2={5} a3={6}" -f $e.instr, $key, $e.ra, $e.a0, $e.a1, $e.a2, $e.a3)
    }
}
Write-Host ""
$tty = $j.TTY_Tail
# Search for key log lines in TTY
$lines = $tty -split "`n"
$cdromLines = $lines | Where-Object { $_ -match 'CDROM|DMA|sector|Setloc|ReadN|INT1' }
Write-Host "CD-ROM log lines ($($cdromLines.Count) found):"
$cdromLines | Select-Object -First 20 | ForEach-Object { Write-Host "  $_" }
Write-Host ""
$padLines = $lines | Where-Object { $_ -match 'PAD|pad|INJECT.*PAD' }
Write-Host "PAD log lines ($($padLines.Count) found):"
$padLines | Select-Object -First 10 | ForEach-Object { Write-Host "  $_" }
Write-Host ""
$gpuLines = $lines | Where-Object { $_ -match 'GPU|gpu' }
Write-Host "GPU log lines ($($gpuLines.Count) found):"
$gpuLines | Select-Object -First 10 | ForEach-Object { Write-Host "  $_" }
