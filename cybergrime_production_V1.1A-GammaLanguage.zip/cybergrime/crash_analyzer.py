#!/usr/bin/env python3
"""Analyze a PSX agent runner telemetry JSON for crash diagnosis."""

import argparse
import json
import struct
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))
from mips import disassemble


def load_telemetry(path):
    with open(path, "r", encoding="latin-1") as f:
        return json.load(f)


def analyze(tel):
    print("=" * 60)
    print("Crash / Exit Analysis")
    print("=" * 60)
    print(f"Profile: {tel.get('Profile_Name')}")
    print(f"Disc:    {tel.get('Disc_Path')}")
    print(f"Status:  {tel.get('Pass_Status')}")
    print(f"Instrs:  {tel.get('Instructions_Executed', 0):,}")
    print(f"VBlank:  {tel.get('VBlank_Count', 0)}")
    print(f"Last PC: {tel.get('Last_Known_PC', 0):#010x}")
    print(f"Crashed: {tel.get('Crashed', False)}")
    print(f"Frozen:  {tel.get('Frozen', False)}")
    print(f"Reason:  {tel.get('Crash_Reason', '')}")

    regs = tel.get("Register_Dump", {})
    print("\nRegisters:")
    for k, v in regs.items():
        if isinstance(v, str) and v.startswith("0x"):
            print(f"  {k:8s} {v}")
        else:
            print(f"  {k:8s} {int(v):#010x}")

    cmd = tel.get("Crash_Memory_Dump")
    if cmd:
        raw = bytes.fromhex(cmd["hex"])
        base = int(cmd["base_addr"], 0)
        pc = int(regs.get("PC", "0"), 0)
        print(f"\nCrash memory dump at 0x{base:08X} ({len(raw)} bytes):")
        for addr, txt in disassemble(raw, base):
            marker = " <<< PC" if addr == (pc & ~3) else ""
            print(f"  0x{addr:08X}: {txt}{marker}")

    err = tel.get("Error_Signature", [])
    if err:
        print("\nError signatures:")
        for e in err:
            print(f"  [{e.get('category')}] {e.get('signature')} @ {e.get('pc')}")

    bios = tel.get("BIOS_Call_Log", [])
    if bios:
        print(f"\nLast 10 BIOS calls ({len(bios)} total):")
        for b in bios[-10:]:
            func = b.get('function', 0)
            if isinstance(func, str):
                func_s = func
            else:
                func_s = f"{int(func):02X}"
            ra = int(b.get('ra', 0), 0) if isinstance(b.get('ra', 0), str) else b.get('ra', 0)
            a0 = int(b.get('a0', 0), 0) if isinstance(b.get('a0', 0), str) else b.get('a0', 0)
            print(f"  {b.get('table', '')}#{func_s} ra={ra:#010x} "
                  f"a0={a0:#010x} instr={b.get('instr_count', 0)}")

    vfs = tel.get("Asset_Load_History", [])
    if vfs:
        print(f"\nVFS accesses ({len(vfs)}):")
        for v in vfs[-10:]:
            print(f"  LBA={v.get('lba')} size={v.get('size')} resolved={v.get('resolved')} "
                  f"pc={v.get('calling_pc')} id={v.get('resource_id')}")

    tty = tel.get("TTY_Tail", "")
    if tty:
        lines = tty.splitlines()
        print(f"\nTTY tail (last {min(len(lines), 2000)} of {len(lines)} lines):")
        for line in lines[-2000:]:
            print(line)


def main():
    parser = argparse.ArgumentParser(description="Analyze agent runner telemetry crash")
    parser.add_argument("telemetry", help="Telemetry JSON path")
    args = parser.parse_args()
    tel = load_telemetry(args.telemetry)
    analyze(tel)


if __name__ == "__main__":
    main()
