// ============================================================================
// AGENT TESTING HARNESS — Implementation
// ============================================================================
// Native C++ implementation for PSX ISO regression analysis.
// Integrates with cybergrime emulator via pipe redirection and hooks.
// ============================================================================

#include "agent_harness.h"
#include "psx_test_station.h"

#include <windows.h>
#include <io.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <stdarg.h>
#include <ctime>

// Global harness instance
AgentHarness* g_harness = nullptr;

// ── Printf override (when AGENT_HARNESS_ENABLED is defined) ──────────────────
#ifdef AGENT_HARNESS_ENABLED
int harness_printf(const char* fmt, ...) {
    if (g_harness && g_harness->is_active()) {
        va_list args;
        va_start(args, fmt);
        // We need to forward to tty_printf which takes va_list
        // But tty_printf also takes va_list — let's use a buffer
        char buf[4096];
        vsnprintf(buf, sizeof(buf), fmt, args);
        va_end(args);
        g_harness->tty_printf("%s", buf);
        return (int)strlen(buf);
    }
    // Fallback to real printf if harness not active
    va_list args;
    va_start(args, fmt);
    int ret = vprintf(fmt, args);
    va_end(args);
    return ret;
}
#endif

// ============================================================================
// Construction / Destruction
// ============================================================================

AgentHarness::AgentHarness()
    : m_active(false)
    , m_frozen(false)
    , m_tty_pipe_read(-1)
    , m_tty_pipe_write(-1)
    , m_orig_stdout_fd(-1)
    , m_orig_stdout_file(nullptr)
    , m_tty_buffer(nullptr)
    , m_tty_pos(0)
    , m_tty_redirected(false)
    , m_vfs_count(0)
    , m_error_count(0)
    , m_regs_captured(false)
    , m_mem_captured(false)
    , m_crash_mem_captured(false)
    , m_last_pc(0)
    , m_last_pc_change_instr(0)
    , m_last_instr_seen(0)
    , m_pc_history_head(0)
    , m_pc_history_count(0)
    , m_loop_start_instr(0)
    , m_freeze_type(FREEZE_NONE)
    , m_loop_body_count(0)
    , m_last_vblank_instr(0)
    , m_vblank_ever_fired(false)
    , m_bios_log_count(0)
    , m_injection_count(0)
    , m_diag_pc_quit(false)
    , m_diag_dump_quit(false)
    , m_diag_mem_set(false)
    , m_diag_mem_addr(0)
    , m_monitor_count(0)
    , m_max_instrs(200000000)
    , m_freeze_threshold(HARNESS_FREEZE_THRESHOLD_DEFAULT)
    , m_wallclock_timeout_ms(0)
    , m_start_tick(0)
    , m_console_thread(nullptr)
    , m_console_running(false)
    , m_console_enabled(false)
    , m_paused(false)
    , m_step_requests(0)
    , m_console_breakpoint(0)
    , m_console_breakpoint_set(false)
{
    m_profile[0] = 0;
    m_disc_path[0] = 0;
    m_json_path[0] = 0;
    m_triage_path[0] = 0;
    m_tty_buffer = (char*)malloc(HARNESS_TTY_BUF_SIZE);
    if (m_tty_buffer) memset(m_tty_buffer, 0, HARNESS_TTY_BUF_SIZE);
    memset(m_pc_history, 0, sizeof(m_pc_history));
    memset(m_loop_body, 0, sizeof(m_loop_body));
    memset(m_bios_log, 0, sizeof(m_bios_log));
    memset(m_injections, 0, sizeof(m_injections));
    m_injection_count = 0;
    memset(m_monitors, 0, sizeof(m_monitors));
    m_monitor_count = 0;
    memset(m_watch_events, 0, sizeof(m_watch_events));
    m_watch_event_count = 0;
    memset(m_snapshots, 0, sizeof(m_snapshots));
    m_snapshot_count = 0;
    m_snapshot_head = 0;
    memset(m_assertions, 0, sizeof(m_assertions));
    m_assert_count = 0;
    m_assert_fail_count = 0;
    m_assert_fail = false;
}

AgentHarness::~AgentHarness() {
    if (m_tty_redirected) {
        // Restore original stdout
        fflush(stdout);
        _dup2(m_orig_stdout_fd, _fileno(stdout));
        _close(m_tty_pipe_read);
        _close(m_tty_pipe_write);
    }
    if (m_tty_buffer) free(m_tty_buffer);
    enable_console(false);
}

// ============================================================================
// Lifecycle
// ============================================================================

void AgentHarness::begin(const char* profile_name, const char* disc_path,
                          const char* json_path, uint64_t max_instrs) {
    strncpy(m_profile, profile_name, HARNESS_PROFILE_LEN - 1);
    m_profile[HARNESS_PROFILE_LEN - 1] = 0;
    strncpy(m_disc_path, disc_path, HARNESS_PATH_LEN - 1);
    m_disc_path[HARNESS_PATH_LEN - 1] = 0;
    strncpy(m_json_path, json_path, HARNESS_PATH_LEN - 1);
    m_json_path[HARNESS_PATH_LEN - 1] = 0;
    m_max_instrs = max_instrs;
    m_active = true;
    m_frozen = false;
    m_vfs_count = 0;
    m_error_count = 0;
    m_regs_captured = false;
    m_mem_captured = false;
    m_crash_mem_captured = false;
    m_tty_pos = 0;
    m_last_pc = 0;
    m_last_pc_change_instr = 0;
    m_last_instr_seen = 0;
    m_pc_history_head = 0;
    m_pc_history_count = 0;
    m_loop_start_instr = 0;
    m_freeze_type = FREEZE_NONE;
    m_loop_body_count = 0;
    m_last_vblank_instr = 0;
    m_vblank_ever_fired = false;
    m_bios_log_count = 0;
    m_start_tick = GetTickCount();

    // Clear buffers
    if (m_tty_buffer) memset(m_tty_buffer, 0, HARNESS_TTY_BUF_SIZE);
    memset(m_vfs_log, 0, sizeof(m_vfs_log));
    memset(m_errors, 0, sizeof(m_errors));
    memset(&m_regs, 0, sizeof(m_regs));
    memset(&m_mem_dump, 0, sizeof(m_mem_dump));
    memset(m_pc_history, 0, sizeof(m_pc_history));
    memset(m_loop_body, 0, sizeof(m_loop_body));
    memset(m_bios_log, 0, sizeof(m_bios_log));

    // ── TTY Pipe Redirection ─────────────────────────────────────────────
    // Create an anonymous pipe. Redirect stdout to the write end.
    // We'll periodically drain the read end into our capture buffer.
    HANDLE hRead, hWrite;
    SECURITY_ATTRIBUTES sa;
    sa.nLength = sizeof(SECURITY_ATTRIBUTES);
    sa.bInheritHandle = TRUE;
    sa.lpSecurityDescriptor = nullptr;

    if (CreatePipe(&hRead, &hWrite, &sa, 1048576)) {
        // Save original stdout
        m_orig_stdout_file = stdout;
        m_orig_stdout_fd = _dup(_fileno(stdout));

        // Associate pipe write end with stdout
        int pipe_write_fd = _open_osfhandle((intptr_t)hWrite, _O_WRONLY);
        if (pipe_write_fd != -1) {
            fflush(stdout);
            _dup2(pipe_write_fd, _fileno(stdout));
            setvbuf(stdout, nullptr, _IONBF, 0);
            m_tty_redirected = true;
        }

        // Store pipe read end as OS file descriptor
        m_tty_pipe_read = _open_osfhandle((intptr_t)hRead, _O_RDONLY);
        m_tty_pipe_write = pipe_write_fd;

        // Make pipe non-blocking
        DWORD mode = PIPE_TYPE_BYTE | PIPE_NOWAIT;
        SetNamedPipeHandleState(hRead, &mode, nullptr, nullptr);
    }

    // Print harness header to the redirected stdout (will be captured)
    tty_printf("=== AGENT HARNESS START ===\n");
    tty_printf("Profile: %s\n", m_profile);
    tty_printf("Disc: %s\n", m_disc_path);
    tty_printf("MaxInstrs: %llu\n", m_max_instrs);
    tty_printf("FreezeThreshold: %llu\n", m_freeze_threshold);
    tty_printf("JSON: %s\n", m_json_path);
    tty_printf("===========================\n");
}

void AgentHarness::end(PassStatus status, MIPS_CPU& cpu, PSX_Memory& mem) {
    if (!m_active) return;

    // Drain remaining TTY
    drain_pipe();
    tty_flush();

    // Capture final state
    capture_registers(cpu);
    capture_memory(mem, 0x8001B200, 256);  // Third Table boundary

    // If we crashed, also capture memory around the crash PC for post-mortem
    if (cpu.crashed || status == PASS_CRASH) {
        uint32_t crash_pc = cpu.pc;
        if (crash_pc >= 0x80000000 && crash_pc < 0x80200000) {
            uint32_t base = crash_pc & ~0xFF;  // 256-byte aligned block containing crash PC
            if (base < 0x80000000) base = 0x80000000;
            if (base + 256 > 0x80200000) base = 0x801FFF00;
            m_crash_mem_dump.base_addr = base;
            m_crash_mem_dump.length = 256;
            for (uint32_t i = 0; i < 256; i++) {
                m_crash_mem_dump.data[i] = mem.read8(base + i);
            }
            m_crash_mem_captured = true;
        }
    }

    // Log freeze if detected
    if (status == PASS_FREEZE) {
        char sig[256];
        snprintf(sig, sizeof(sig),
                 "FREEZE: PC=0x%08X stagnant for %llu instructions (last change at instr #%llu)",
                 m_last_pc, m_last_instr_seen - m_last_pc_change_instr, m_last_pc_change_instr);
        log_error("FREEZE", sig, m_last_pc, m_last_instr_seen);
    }

    // Write JSON telemetry
    write_json(cpu, mem, status);

    // Print summary to TTY
    tty_printf("\n=== AGENT HARNESS END ===\n");
    tty_printf("Status: %d\n", (int)status);
    tty_printf("VFS Accesses: %d\n", m_vfs_count);
    tty_printf("Errors: %d\n", m_error_count);
    tty_printf("Frozen: %s\n", m_frozen ? "YES" : "NO");
    tty_printf("==========================\n");

    // Drain one final time
    drain_pipe();

    // Restore stdout
    if (m_tty_redirected) {
        fflush(stdout);
        _dup2(m_orig_stdout_fd, _fileno(stdout));
        _close(m_tty_pipe_read);
        _close(m_tty_pipe_write);
        m_tty_redirected = false;
    }

    // Print summary to real console
    printf("\n[HARNESS] Profile '%s' complete: status=%d, vfs=%d, errors=%d, json=%s\n",
           m_profile, (int)status, m_vfs_count, m_error_count, m_json_path);

    m_active = false;
}

// ============================================================================
// TTY Interception
// ============================================================================

void AgentHarness::tty_printf(const char* fmt, ...) {
    va_list args;
    va_start(args, fmt);
    char buf[4096];
    int len = vsnprintf(buf, sizeof(buf), fmt, args);
    va_end(args);

    if (len <= 0) return;

    // Write to real stdout (which is now the pipe if redirected, or console if not)
    if (m_tty_redirected) {
        // stdout goes to pipe — write directly to buffer instead to avoid pipe deadlock
        if (m_tty_buffer) {
            int copy = len;
            if (m_tty_pos + copy >= HARNESS_TTY_BUF_SIZE) {
                int discard = HARNESS_TTY_BUF_SIZE / 4;
                memmove(m_tty_buffer, m_tty_buffer + discard, m_tty_pos - discard);
                m_tty_pos -= discard;
                copy = HARNESS_TTY_BUF_SIZE - m_tty_pos - 1;
                if (copy > len) copy = len;
            }
            memcpy(m_tty_buffer + m_tty_pos, buf, copy);
            m_tty_pos += copy;
        }
        // Also drain pipe to capture emulator printf output
        drain_pipe();
    } else {
        // No pipe — write directly to buffer and console
        if (m_tty_buffer && m_tty_pos + len < HARNESS_TTY_BUF_SIZE) {
            memcpy(m_tty_buffer + m_tty_pos, buf, len);
            m_tty_pos += len;
        }
        // Also write to console
        fwrite(buf, 1, len, stdout);
        fflush(stdout);
    }
}

void AgentHarness::drain_pipe() {
    if (!m_tty_redirected || m_tty_pipe_read < 0) return;

    // Use PeekNamedPipe to check available bytes (non-blocking)
    DWORD avail = 0;
    HANDLE hPipe = (HANDLE)_get_osfhandle(m_tty_pipe_read);
    if (!PeekNamedPipe(hPipe, nullptr, 0, nullptr, &avail, nullptr) || avail == 0)
        return;

    char tmp[4096];
    int bytes;
    do {
        int to_read = (avail < sizeof(tmp)) ? avail : sizeof(tmp);
        bytes = _read(m_tty_pipe_read, tmp, to_read);
        if (bytes > 0) {
            if (m_tty_buffer) {
                int copy = bytes;
                if (m_tty_pos + copy >= HARNESS_TTY_BUF_SIZE) {
                    // Buffer full — shift: discard first 25%, append new data
                    int discard = HARNESS_TTY_BUF_SIZE / 4;
                    memmove(m_tty_buffer, m_tty_buffer + discard, m_tty_pos - discard);
                    m_tty_pos -= discard;
                    copy = HARNESS_TTY_BUF_SIZE - m_tty_pos - 1;
                    if (copy > bytes) copy = bytes;
                }
                memcpy(m_tty_buffer + m_tty_pos, tmp, copy);
                m_tty_pos += copy;
            }
            avail -= bytes;
        }
    } while (bytes > 0 && avail > 0);
}

void AgentHarness::tty_flush() {
    drain_pipe();
    if (m_tty_buffer) m_tty_buffer[m_tty_pos] = 0;
}

const char* AgentHarness::tty_tail(int nbytes) const {
    if (!m_tty_buffer || m_tty_pos == 0) return "";
    int start = m_tty_pos - nbytes;
    if (start < 0) start = 0;
    return m_tty_buffer + start;
}

// ============================================================================
// VFS Logging
// ============================================================================

void AgentHarness::log_vfs(const char* resource_id, uint32_t lba, uint32_t size,
                            bool resolved, uint32_t calling_pc, const char* error) {
    if (m_vfs_count >= HARNESS_VFS_MAX) return;

    VfsAccessRecord& rec = m_vfs_log[m_vfs_count++];
    strncpy(rec.resource_id, resource_id ? resource_id : "?", HARNESS_RESOURCE_ID_LEN - 1);
    rec.resource_id[HARNESS_RESOURCE_ID_LEN - 1] = 0;
    rec.lba = lba;
    rec.size = size;
    rec.resolved = resolved;
    rec.calling_pc = calling_pc;
    rec.instr_count = m_last_instr_seen;
    if (error && !resolved) {
        strncpy(rec.error, error, 127);
        rec.error[127] = 0;
    } else {
        rec.error[0] = 0;
    }

    // Auto-log error for unresolved VFS
    if (!resolved) {
        char sig[256];
        snprintf(sig, sizeof(sig),
                 "VFS MISS: resource '%s' (LBA=%u, size=%u) not found at PC=0x%08X",
                 resource_id ? resource_id : "?", lba, size, calling_pc);
        log_error("VFS", sig, calling_pc, m_last_instr_seen);
    }
}

void AgentHarness::log_cdrom_read(uint32_t lba, bool success, uint32_t calling_pc) {
    char id[HARNESS_RESOURCE_ID_LEN];
    snprintf(id, sizeof(id), "CDROM:sector:%u", lba);
    log_vfs(id, lba, 2048, success, calling_pc,
            success ? nullptr : "CD-ROM sector read failed");
}

// ============================================================================
// Error Tracking
// ============================================================================

void AgentHarness::log_error(const char* category, const char* signature,
                              uint32_t pc, uint64_t instr_count) {
    if (m_error_count >= HARNESS_ERROR_MAX) return;

    ErrorRecord& rec = m_errors[m_error_count++];
    strncpy(rec.category, category ? category : "?", 31);
    rec.category[31] = 0;
    strncpy(rec.signature, signature ? signature : "?", HARNESS_ERROR_SIG_LEN - 1);
    rec.signature[HARNESS_ERROR_SIG_LEN - 1] = 0;
    rec.pc = pc;
    rec.instr_count = instr_count;
}

// ============================================================================
// Freeze Detection
// ============================================================================

bool AgentHarness::check_freeze(uint32_t current_pc, uint64_t instr_count) {
    m_last_instr_seen = instr_count;

    // ── Check 1: PC literally stuck (original detection) ─────────────────
    if (current_pc != m_last_pc) {
        m_last_pc = current_pc;
        m_last_pc_change_instr = instr_count;
        if (m_freeze_type == FREEZE_PC_STUCK) m_freeze_type = FREEZE_NONE;
    } else {
        uint64_t stagnant = instr_count - m_last_pc_change_instr;
        if (stagnant >= m_freeze_threshold) {
            m_frozen = true;
            m_freeze_type = FREEZE_PC_STUCK;
            return true;
        }
    }

    // ── Check 2: Tight loop detection (Phase 1) ──────────────────────────
    if (check_loop_freeze(current_pc, instr_count)) {
        m_frozen = true;
        m_freeze_type = FREEZE_TIGHT_LOOP;
        return true;
    }

    // ── Check 3: VBlank stall detection (Phase 1) ────────────────────────
    if (m_vblank_ever_fired) {
        uint64_t since_vblank = instr_count - m_last_vblank_instr;
        if (since_vblank >= HARNESS_VBLANK_STALL_THRESH) {
            m_frozen = true;
            m_freeze_type = FREEZE_VBLANK_STALL;
            return true;
        }
    }

    m_frozen = false;
    return false;
}

// ============================================================================
// Phase 1: Loop Freeze Detection
// ============================================================================

bool AgentHarness::check_loop_freeze(uint32_t current_pc, uint64_t instr_count) {
    // Push PC into history ring buffer
    m_pc_history[m_pc_history_head] = current_pc;
    m_pc_history_head = (m_pc_history_head + 1) % HARNESS_PC_HISTORY_SIZE;
    if (m_pc_history_count < HARNESS_PC_HISTORY_SIZE) m_pc_history_count++;

    // Only check when buffer is full
    if (m_pc_history_count < HARNESS_PC_HISTORY_SIZE) return false;

    // Count unique PCs in the history buffer
    uint32_t unique_pcs[HARNESS_LOOP_BODY_MAX];
    int unique_count = 0;
    int start = m_pc_history_head; // oldest entry
    for (int i = 0; i < HARNESS_PC_HISTORY_SIZE; i++) {
        int idx = (start + i) % HARNESS_PC_HISTORY_SIZE;
        uint32_t pc = m_pc_history[idx];
        bool found = false;
        for (int j = 0; j < unique_count; j++) {
            if (unique_pcs[j] == pc) { found = true; break; }
        }
        if (!found && unique_count < HARNESS_LOOP_BODY_MAX) {
            unique_pcs[unique_count++] = pc;
        }
    }

    // If very few unique PCs, we're in a tight loop
    if (unique_count > 0 && unique_count <= HARNESS_LOOP_UNIQUE_MAX) {
        // Check if we've been in this loop long enough
        if (m_loop_start_instr == 0) {
            m_loop_start_instr = instr_count;
        }
        uint64_t loop_duration = instr_count - m_loop_start_instr;
        if (loop_duration >= (uint64_t)HARNESS_LOOP_INSTR_THRESH) {
            // Freeze! Save the loop body
            m_loop_body_count = unique_count;
            for (int i = 0; i < unique_count && i < HARNESS_LOOP_BODY_MAX; i++) {
                m_loop_body[i] = unique_pcs[i];
            }
            return true;
        }
    } else {
        // PC set changed — reset loop timer
        m_loop_start_instr = instr_count;
    }

    return false;
}

void AgentHarness::notify_vblank(uint64_t instr_count) {
    m_last_vblank_instr = instr_count;
    m_vblank_ever_fired = true;
}

int AgentHarness::get_loop_body(uint32_t* out_pcs, int max_count) const {
    int count = m_loop_body_count < max_count ? m_loop_body_count : max_count;
    for (int i = 0; i < count; i++) out_pcs[i] = m_loop_body[i];
    return count;
}

// ============================================================================
// Phase 2: BIOS Call Logging
// ============================================================================

void AgentHarness::log_bios_call(char table, uint8_t function, uint32_t ra,
                                   uint32_t a0, uint32_t a1, uint32_t a2, uint32_t a3,
                                   uint64_t instr_count) {
    // Ring buffer: shift if full
    if (m_bios_log_count >= HARNESS_BIOS_LOG_MAX) {
        memmove(m_bios_log, m_bios_log + 1, (HARNESS_BIOS_LOG_MAX - 1) * sizeof(BiosCallEntry));
        m_bios_log_count = HARNESS_BIOS_LOG_MAX - 1;
    }
    BiosCallEntry& e = m_bios_log[m_bios_log_count++];
    e.table = table;
    e.function = function;
    e.ra = ra;
    e.a0 = a0; e.a1 = a1; e.a2 = a2; e.a3 = a3;
    e.instr_count = instr_count;
}

// ============================================================================
// Phase 2: Triage Log
// ============================================================================

void AgentHarness::set_triage_path(const char* path) {
    strncpy(m_triage_path, path ? path : "", HARNESS_PATH_LEN - 1);
    m_triage_path[HARNESS_PATH_LEN - 1] = 0;
}

const char* AgentHarness::decode_mnemonic(uint32_t raw, uint32_t pc) const {
    static char buf[128];
    uint32_t op = (raw >> 26) & 0x3F;
    uint32_t rs = (raw >> 21) & 0x1F;
    uint32_t rt = (raw >> 16) & 0x1F;
    uint32_t rd = (raw >> 11) & 0x1F;
    uint32_t shamt = (raw >> 6) & 0x1F;
    uint32_t funct = raw & 0x3F;
    int16_t imm = (int16_t)(raw & 0xFFFF);
    uint32_t target = (raw & 0x3FFFFFF) << 2;

    const char* rn[] = {"zero","at","v0","v1","a0","a1","a2","a3",
                        "t0","t1","t2","t3","t4","t5","t6","t7",
                        "s0","s1","s2","s3","s4","s5","s6","s7",
                        "t8","t9","k0","k1","gp","sp","fp","ra"};

    switch (op) {
        case 0x00: // SPECIAL
            switch (funct) {
                case 0x08: snprintf(buf, sizeof(buf), "jr   %s", rn[rs]); break;
                case 0x09: snprintf(buf, sizeof(buf), "jalr %s, %s", rn[rd], rn[rs]); break;
                case 0x0C: snprintf(buf, sizeof(buf), "syscall"); break;
                case 0x10: snprintf(buf, sizeof(buf), "mfhi %s", rn[rd]); break;
                case 0x12: snprintf(buf, sizeof(buf), "mflo %s", rn[rd]); break;
                case 0x20: snprintf(buf, sizeof(buf), "add  %s, %s, %s", rn[rd], rn[rs], rn[rt]); break;
                case 0x21: snprintf(buf, sizeof(buf), "addu %s, %s, %s", rn[rd], rn[rs], rn[rt]); break;
                case 0x22: snprintf(buf, sizeof(buf), "sub  %s, %s, %s", rn[rd], rn[rs], rn[rt]); break;
                case 0x23: snprintf(buf, sizeof(buf), "subu %s, %s, %s", rn[rd], rn[rs], rn[rt]); break;
                case 0x24: snprintf(buf, sizeof(buf), "and  %s, %s, %s", rn[rd], rn[rs], rn[rt]); break;
                case 0x25: snprintf(buf, sizeof(buf), "or   %s, %s, %s", rn[rd], rn[rs], rn[rt]); break;
                case 0x26: snprintf(buf, sizeof(buf), "xor  %s, %s, %s", rn[rd], rn[rs], rn[rt]); break;
                case 0x27: snprintf(buf, sizeof(buf), "nor  %s, %s, %s", rn[rd], rn[rs], rn[rt]); break;
                case 0x2A: snprintf(buf, sizeof(buf), "slt  %s, %s, %s", rn[rd], rn[rs], rn[rt]); break;
                case 0x2B: snprintf(buf, sizeof(buf), "sltu %s, %s, %s", rn[rd], rn[rs], rn[rt]); break;
                case 0x00: snprintf(buf, sizeof(buf), "sll  %s, %s, %d", rn[rd], rn[rt], shamt); break;
                case 0x02: snprintf(buf, sizeof(buf), "srl  %s, %s, %d", rn[rd], rn[rt], shamt); break;
                case 0x03: snprintf(buf, sizeof(buf), "sra  %s, %s, %d", rn[rd], rn[rt], shamt); break;
                case 0x04: snprintf(buf, sizeof(buf), "sllv %s, %s, %s", rn[rd], rn[rt], rn[rs]); break;
                case 0x06: snprintf(buf, sizeof(buf), "srlv %s, %s, %s", rn[rd], rn[rt], rn[rs]); break;
                case 0x07: snprintf(buf, sizeof(buf), "srav %s, %s, %s", rn[rd], rn[rt], rn[rs]); break;
                default:  snprintf(buf, sizeof(buf), "special 0x%02X", funct); break;
            }
            break;
        case 0x01: { // REGIMM
            int32_t offset = (int32_t)(int16_t)imm << 2;
            uint32_t tgt = pc + 4 + offset;
            switch (rt) {
                case 0x00: snprintf(buf, sizeof(buf), "bltz %s, 0x%08X", rn[rs], tgt); break;
                case 0x01: snprintf(buf, sizeof(buf), "bgez %s, 0x%08X", rn[rs], tgt); break;
                case 0x10: snprintf(buf, sizeof(buf), "bltzal %s, 0x%08X", rn[rs], tgt); break;
                case 0x11: snprintf(buf, sizeof(buf), "bgezal %s, 0x%08X", rn[rs], tgt); break;
                default:  snprintf(buf, sizeof(buf), "regimm 0x%02X", rt); break;
            }
            break;
        }
        case 0x02: snprintf(buf, sizeof(buf), "j    0x%08X", (pc & 0xF0000000) | target); break;
        case 0x03: snprintf(buf, sizeof(buf), "jal  0x%08X", (pc & 0xF0000000) | target); break;
        case 0x04: { int32_t o=(int32_t)(int16_t)imm<<2; snprintf(buf, sizeof(buf), "beq  %s, %s, 0x%08X", rn[rs], rn[rt], pc+4+o); break; }
        case 0x05: { int32_t o=(int32_t)(int16_t)imm<<2; snprintf(buf, sizeof(buf), "bne  %s, %s, 0x%08X", rn[rs], rn[rt], pc+4+o); break; }
        case 0x06: { int32_t o=(int32_t)(int16_t)imm<<2; snprintf(buf, sizeof(buf), "blez %s, 0x%08X", rn[rs], pc+4+o); break; }
        case 0x07: { int32_t o=(int32_t)(int16_t)imm<<2; snprintf(buf, sizeof(buf), "bgtz %s, 0x%08X", rn[rs], pc+4+o); break; }
        case 0x08: snprintf(buf, sizeof(buf), "addi %s, %s, %d", rn[rt], rn[rs], (int16_t)imm); break;
        case 0x09: snprintf(buf, sizeof(buf), "addiu %s, %s, %d", rn[rt], rn[rs], (int16_t)imm); break;
        case 0x0A: snprintf(buf, sizeof(buf), "slti %s, %s, %d", rn[rt], rn[rs], (int16_t)imm); break;
        case 0x0B: snprintf(buf, sizeof(buf), "sltiu %s, %s, %d", rn[rt], rn[rs], (int16_t)imm); break;
        case 0x0C: snprintf(buf, sizeof(buf), "andi %s, %s, 0x%04X", rn[rt], rn[rs], (uint16_t)imm); break;
        case 0x0D: snprintf(buf, sizeof(buf), "ori  %s, %s, 0x%04X", rn[rt], rn[rs], (uint16_t)imm); break;
        case 0x0E: snprintf(buf, sizeof(buf), "xori %s, %s, 0x%04X", rn[rt], rn[rs], (uint16_t)imm); break;
        case 0x0F: snprintf(buf, sizeof(buf), "lui  %s, 0x%04X", rn[rt], (uint16_t)imm); break;
        case 0x20: snprintf(buf, sizeof(buf), "lb   %s, %d(%s)", rn[rt], (int16_t)imm, rn[rs]); break;
        case 0x21: snprintf(buf, sizeof(buf), "lh   %s, %d(%s)", rn[rt], (int16_t)imm, rn[rs]); break;
        case 0x23: snprintf(buf, sizeof(buf), "lw   %s, %d(%s)", rn[rt], (int16_t)imm, rn[rs]); break;
        case 0x24: snprintf(buf, sizeof(buf), "lbu  %s, %d(%s)", rn[rt], (int16_t)imm, rn[rs]); break;
        case 0x25: snprintf(buf, sizeof(buf), "lhu  %s, %d(%s)", rn[rt], (int16_t)imm, rn[rs]); break;
        case 0x28: snprintf(buf, sizeof(buf), "sb   %s, %d(%s)", rn[rt], (int16_t)imm, rn[rs]); break;
        case 0x29: snprintf(buf, sizeof(buf), "sh   %s, %d(%s)", rn[rt], (int16_t)imm, rn[rs]); break;
        case 0x2B: snprintf(buf, sizeof(buf), "sw   %s, %d(%s)", rn[rt], (int16_t)imm, rn[rs]); break;
        case 0x10: snprintf(buf, sizeof(buf), "mfc0 %s, %d", rn[rt], rd); break;
        case 0x12: snprintf(buf, sizeof(buf), "mtc0 %s, %d", rn[rt], rd); break;
        case 0x11: snprintf(buf, sizeof(buf), "cop1 0x%08X", raw); break;
        case 0x13: snprintf(buf, sizeof(buf), "cop3 0x%08X", raw); break;
        default:  snprintf(buf, sizeof(buf), "???  0x%08X (op=%d)", raw, op); break;
    }
    return buf;
}

void AgentHarness::write_triage_loop_body(FILE* f, MIPS_CPU& cpu) {
    if (m_freeze_type == FREEZE_TIGHT_LOOP && m_loop_body_count > 0) {
        fprintf(f, "Type: TIGHT_LOOP (%d unique PCs cycling)\n", m_loop_body_count);
        fprintf(f, "Loop body (decoded):\n");
        for (int i = 0; i < m_loop_body_count; i++) {
            uint32_t pc = m_loop_body[i];
            // Read the instruction from memory
            uint32_t raw = cpu.read32(pc, cpu.mem_ctx);
            const char* mnem = decode_mnemonic(raw, pc);
            fprintf(f, "  0x%08X: %08X  %s\n", pc, raw, mnem);
        }
    } else if (m_freeze_type == FREEZE_PC_STUCK) {
        uint32_t raw = cpu.read32(m_last_pc, cpu.mem_ctx);
        const char* mnem = decode_mnemonic(raw, m_last_pc);
        fprintf(f, "Type: PC_STUCK (single instruction)\n");
        fprintf(f, "  0x%08X: %08X  %s\n", m_last_pc, raw, mnem);
    } else if (m_freeze_type == FREEZE_VBLANK_STALL) {
        fprintf(f, "Type: VBLANK_STALL (no VBlank IRQ for %llu instructions)\n",
                m_last_instr_seen - m_last_vblank_instr);
        // Also dump the trace ring from CPU
        if (cpu.trace_ring_count > 0) {
            fprintf(f, "Last %d instructions from trace ring:\n", cpu.trace_ring_count);
            int start = (cpu.trace_ring_head - cpu.trace_ring_count + cpu.TRACE_RING_SIZE) % cpu.TRACE_RING_SIZE;
            for (int i = 0; i < cpu.trace_ring_count; i++) {
                int idx = (start + i) % cpu.TRACE_RING_SIZE;
                auto& fr = cpu.trace_ring[idx];
                const char* mnem = decode_mnemonic(fr.raw_instr, fr.pc);
                fprintf(f, "  #%llu 0x%08X: %08X  %s\n", fr.instr_count, fr.pc, fr.raw_instr, mnem);
            }
        }
    } else {
        fprintf(f, "Type: UNKNOWN\n");
    }
}

void AgentHarness::write_triage_registers(FILE* f) {
    if (!m_regs_captured) { fprintf(f, "  (not captured)\n"); return; }
    fprintf(f, "PC:  0x%08X   $v0: 0x%08X   $v1: 0x%08X\n", m_regs.pc, m_regs.v0, m_regs.v1);
    fprintf(f, "$a0: 0x%08X   $a1: 0x%08X   $a2: 0x%08X   $a3: 0x%08X\n",
            m_regs.a0, m_regs.a1, m_regs.a2, m_regs.a3);
    fprintf(f, "$t0: 0x%08X   $t1: 0x%08X   $t2: 0x%08X   $t3: 0x%08X\n",
            m_regs.t0, m_regs.t1, m_regs.t2, m_regs.t3);
    fprintf(f, "$s0: 0x%08X   $s1: 0x%08X   $s2: 0x%08X   $s3: 0x%08X\n",
            m_regs.s0, m_regs.s1, m_regs.s2, m_regs.s3);
    fprintf(f, "$s4: 0x%08X   $s5: 0x%08X   $s6: 0x%08X   $s7: 0x%08X\n",
            m_regs.s4, m_regs.s5, m_regs.s6, m_regs.s7);
    fprintf(f, "$sp: 0x%08X   $fp: 0x%08X   $gp: 0x%08X   $ra: 0x%08X\n",
            m_regs.sp, m_regs.fp, m_regs.gp, m_regs.ra);
    fprintf(f, "$hi: 0x%08X   $lo: 0x%08X\n", m_regs.hi, m_regs.lo);
    fprintf(f, "CP0 Status: 0x%08X  Cause: 0x%08X  EPC: 0x%08X\n",
            m_regs.cp0_status, m_regs.cp0_cause, m_regs.cp0_epc);
}

void AgentHarness::write_triage_bios_calls(FILE* f) {
    int start = m_bios_log_count > 10 ? m_bios_log_count - 10 : 0;
    int shown = m_bios_log_count - start;
    fprintf(f, "Showing last %d BIOS calls:\n", shown);
    for (int i = start; i < m_bios_log_count; i++) {
        BiosCallEntry& e = m_bios_log[i];
        fprintf(f, "  #%llu %c:0x%02X $ra=0x%08X a0=0x%08X a1=0x%08X a2=0x%08X a3=0x%08X\n",
                e.instr_count, e.table, e.function, e.ra, e.a0, e.a1, e.a2, e.a3);
    }
}

void AgentHarness::write_triage_vfs(FILE* f) {
    int start = m_vfs_count > 20 ? m_vfs_count - 20 : 0;
    int shown = m_vfs_count - start;
    fprintf(f, "Showing last %d VFS accesses:\n", shown);
    for (int i = start; i < m_vfs_count; i++) {
        VfsAccessRecord& v = m_vfs_log[i];
        fprintf(f, "  [%d] %-32s LBA=%-8u size=%-8u resolved=%s pc=0x%08X",
                i, v.resource_id, v.lba, v.size, v.resolved ? "YES" : "NO", v.calling_pc);
        if (!v.resolved && v.error[0]) fprintf(f, " err=%s", v.error);
        fprintf(f, "\n");
    }
}

void AgentHarness::write_triage_memory(FILE* f, PSX_Memory& mem) {
    // Key DW7 game state addresses
    struct { const char* name; uint32_t addr; int size; } addrs[] = {
        {"vblank_cnt",    0x800B63D8, 4},
        {"disp_flag",     0x800B5312, 2},
        {"evt_flag",      0x800B679C, 1},
        {"vsync_tick",    0x800BA294, 4},
        {"disc1_name",    0x80026D00, 16},
        {"disc2_name",    0x80026D10, 16},
        {"cd_status",     0x800B91CE, 2},
        {nullptr, 0, 0}
    };
    for (int i = 0; addrs[i].name; i++) {
        uint32_t addr = addrs[i].addr;
        int sz = addrs[i].size;
        fprintf(f, "  0x%08X (%s): ", addr, addrs[i].name);
        for (int b = 0; b < sz; b++) {
            fprintf(f, "%02X ", mem.read8(addr + b));
        }
        // Also print as string if it looks like ASCII
        if (sz >= 4) {
            fprintf(f, " \"");
            for (int b = 0; b < sz; b++) {
                uint8_t c = mem.read8(addr + b);
                fprintf(f, "%c", (c >= 32 && c < 127) ? c : '.');
            }
            fprintf(f, "\"");
        }
        fprintf(f, "\n");
    }
}

void AgentHarness::write_triage_log(MIPS_CPU& cpu, PSX_Memory& mem) {
    if (!m_triage_path[0]) return;

    FILE* f = fopen(m_triage_path, "w");
    if (!f) return;

    const char* status_names[] = {"RUNNING","COMPLETE","CRASH","FREEZE","BOOT_FAIL","TIMEOUT"};
    const char* freeze_names[] = {"NONE","PC_STUCK","TIGHT_LOOP","VBLANK_STALL"};

    DWORD elapsed_ms = GetTickCount() - m_start_tick;

    fprintf(f, "=== EMULATOR TRIAGE REPORT ===\n");
    fprintf(f, "Profile: %s\n", m_profile);
    fprintf(f, "Disc: %s\n", m_disc_path);
    fprintf(f, "Status: %s\n", (int)m_freeze_type < 4 ? status_names[3] : "UNKNOWN");
    fprintf(f, "Freeze Type: %s\n", freeze_names[(int)m_freeze_type]);
    fprintf(f, "Instruction count: %llu\n", m_last_instr_seen);
    fprintf(f, "VBlank count: %u\n", mem.vblank_counter);
    fprintf(f, "Wall-clock time: %lu ms (%.1fs)\n", elapsed_ms, elapsed_ms / 1000.0);
    fprintf(f, "\n");

    // ── Freeze Detection Details ─────────────────────────────────────────
    fprintf(f, "=== FREEZE DETECTION ===\n");
    write_triage_loop_body(f, cpu);
    fprintf(f, "\n");

    // ── Register Dump ────────────────────────────────────────────────────
    fprintf(f, "=== REGISTER DUMP ===\n");
    write_triage_registers(f);
    fprintf(f, "\n");

    // ── BIOS Calls ───────────────────────────────────────────────────────
    fprintf(f, "=== LAST BIOS CALLS ===\n");
    write_triage_bios_calls(f);
    fprintf(f, "\n");

    // ── VFS Accesses ─────────────────────────────────────────────────────
    fprintf(f, "=== VFS ACCESSES (last 20) ===\n");
    write_triage_vfs(f);
    fprintf(f, "\n");

    // ── Memory Snapshot ──────────────────────────────────────────────────
    fprintf(f, "=== MEMORY SNAPSHOT (key DW7 addresses) ===\n");
    write_triage_memory(f, mem);
    fprintf(f, "\n");

    // ── TTY Tail ─────────────────────────────────────────────────────────
    fprintf(f, "=== CONSOLE OUTPUT (last 4KB) ===\n");
    drain_pipe();
    tty_flush();
    const char* tail = tty_tail(4096);
    if (tail && *tail) fprintf(f, "%s\n", tail);
    else fprintf(f, "(empty)\n");

    fprintf(f, "\n=== END TRIAGE REPORT ===\n");
    fclose(f);
}

void AgentHarness::set_freeze_threshold(uint64_t threshold) {
    m_freeze_threshold = threshold;
}

// ============================================================================
// State Dump
// ============================================================================

void AgentHarness::capture_registers(MIPS_CPU& cpu) {
    m_regs.pc = cpu.pc;
    m_regs.v0 = cpu.get_reg(2);
    m_regs.v1 = cpu.get_reg(3);
    m_regs.a0 = cpu.get_reg(4);
    m_regs.a1 = cpu.get_reg(5);
    m_regs.a2 = cpu.get_reg(6);
    m_regs.a3 = cpu.get_reg(7);
    m_regs.t0 = cpu.get_reg(8);
    m_regs.t1 = cpu.get_reg(9);
    m_regs.t2 = cpu.get_reg(10);
    m_regs.t3 = cpu.get_reg(11);
    m_regs.t4 = cpu.get_reg(12);
    m_regs.t5 = cpu.get_reg(13);
    m_regs.t6 = cpu.get_reg(14);
    m_regs.t7 = cpu.get_reg(15);
    m_regs.s0 = cpu.get_reg(16);
    m_regs.s1 = cpu.get_reg(17);
    m_regs.s2 = cpu.get_reg(18);
    m_regs.s3 = cpu.get_reg(19);
    m_regs.s4 = cpu.get_reg(20);
    m_regs.s5 = cpu.get_reg(21);
    m_regs.s6 = cpu.get_reg(22);
    m_regs.s7 = cpu.get_reg(23);
    m_regs.sp = cpu.get_reg(29);
    m_regs.fp = cpu.get_reg(30);
    m_regs.gp = cpu.get_reg(28);
    m_regs.ra = cpu.get_reg(31);
    m_regs.hi = cpu.hi;
    m_regs.lo = cpu.lo;
    m_regs.cp0_status = cpu.cp0_status;
    m_regs.cp0_cause = cpu.cp0_cause;
    m_regs.cp0_epc = cpu.cp0_epc;
    m_regs_captured = true;
}

void AgentHarness::capture_memory(PSX_Memory& mem, uint32_t addr, uint32_t length) {
    if (length > sizeof(m_mem_dump.data)) length = sizeof(m_mem_dump.data);
    m_mem_dump.base_addr = addr;
    m_mem_dump.length = length;
    for (uint32_t i = 0; i < length; i++) {
        m_mem_dump.data[i] = mem.read8(addr + i);
    }
    m_mem_captured = true;
}

// ============================================================================
// Wall-Clock Timeout
// ============================================================================

void AgentHarness::set_wallclock_timeout(uint32_t ms) {
    m_wallclock_timeout_ms = ms;
}

bool AgentHarness::check_wallclock_timeout() const {
    if (m_wallclock_timeout_ms == 0) return false;
    DWORD elapsed = GetTickCount() - m_start_tick;
    return elapsed >= m_wallclock_timeout_ms;
}

// ============================================================================
// JSON Output
// ============================================================================

void AgentHarness::json_escape(const char* in, char* out, int out_len) const {
    if (!in || !out || out_len <= 0) return;
    int j = 0;
    for (int i = 0; in[i] && j < out_len - 2; i++) {
        char c = in[i];
        if (c == '"' || c == '\\') {
            if (j + 1 < out_len - 1) out[j++] = '\\';
            out[j++] = c;
        } else if (c == '\n') {
            if (j + 1 < out_len - 1) { out[j++] = '\\'; out[j++] = 'n'; }
        } else if (c == '\r') {
            if (j + 1 < out_len - 1) { out[j++] = '\\'; out[j++] = 'r'; }
        } else if (c == '\t') {
            if (j + 1 < out_len - 1) { out[j++] = '\\'; out[j++] = 't'; }
        } else if ((unsigned char)c < 0x20) {
            // Skip non-printable
        } else {
            out[j++] = c;
        }
    }
    out[j] = 0;
}

void AgentHarness::write_json_string(FILE* f, const char* key, const char* val, int indent) {
    char escaped[1024];
    json_escape(val ? val : "", escaped, sizeof(escaped));
    for (int i = 0; i < indent; i++) fputc(' ', f);
    fprintf(f, "\"%s\": \"%s\"", key, escaped);
}

void AgentHarness::write_json_uint(FILE* f, const char* key, uint64_t val, int indent) {
    for (int i = 0; i < indent; i++) fputc(' ', f);
    fprintf(f, "\"%s\": %llu", key, val);
}

void AgentHarness::write_json_bool(FILE* f, const char* key, bool val, int indent) {
    for (int i = 0; i < indent; i++) fputc(' ', f);
    fprintf(f, "\"%s\": %s", key, val ? "true" : "false");
}

void AgentHarness::write_json(MIPS_CPU& cpu, PSX_Memory& mem, PassStatus status) {
    FILE* f = fopen(m_json_path, "w");
    if (!f) return;

    const char* status_names[] = {
        "RUNNING", "COMPLETE", "CRASH", "FREEZE", "BOOT_FAIL", "TIMEOUT"
    };
    const char* status_str = (int)status < 6 ? status_names[(int)status] : "UNKNOWN";

    // Drain TTY before extracting tail
    drain_pipe();
    if (m_tty_buffer) m_tty_buffer[m_tty_pos] = 0;

    // Get TTY tail (last 8KB)
    const char* tail = tty_tail(HARNESS_TTY_TAIL_SIZE);

    // Get crash reason if any
    const char* crash_reason = cpu.crashed ? cpu.crash_reason : "";

    // ── Write JSON ───────────────────────────────────────────────────────
    fprintf(f, "{\n");

    // Profile metadata
    write_json_string(f, "Profile_Name", m_profile, 2);
    fprintf(f, ",\n");
    write_json_string(f, "Disc_Path", m_disc_path, 2);
    fprintf(f, ",\n");
    write_json_string(f, "Pass_Status", status_str, 2);
    fprintf(f, ",\n");

    // Timing
    DWORD elapsed_ms = GetTickCount() - m_start_tick;
    write_json_uint(f, "Instructions_Executed", cpu.instructions, 2);
    fprintf(f, ",\n");
    write_json_uint(f, "Wall_Clock_MS", elapsed_ms, 2);
    fprintf(f, ",\n");
    write_json_uint(f, "VBlank_Count", mem.vblank_counter, 2);
    fprintf(f, ",\n");

    // Last known PC
    write_json_uint(f, "Last_Known_PC", cpu.pc, 2);
    fprintf(f, ",\n");

    // Crash info
    write_json_bool(f, "Crashed", cpu.crashed, 2);
    fprintf(f, ",\n");
    write_json_string(f, "Crash_Reason", crash_reason, 2);
    fprintf(f, ",\n");
    write_json_bool(f, "Frozen", m_frozen, 2);
    fprintf(f, ",\n");

    // ── Register Dump ────────────────────────────────────────────────────
    if (m_regs_captured) {
        fprintf(f, "  \"Register_Dump\": {\n");
        fprintf(f, "    \"PC\": \"0x%08X\",\n", m_regs.pc);
        fprintf(f, "    \"v0\": \"0x%08X\", \"v1\": \"0x%08X\",\n", m_regs.v0, m_regs.v1);
        fprintf(f, "    \"a0\": \"0x%08X\", \"a1\": \"0x%08X\", \"a2\": \"0x%08X\", \"a3\": \"0x%08X\",\n",
                m_regs.a0, m_regs.a1, m_regs.a2, m_regs.a3);
        fprintf(f, "    \"t0\": \"0x%08X\", \"t1\": \"0x%08X\", \"t2\": \"0x%08X\", \"t3\": \"0x%08X\",\n",
                m_regs.t0, m_regs.t1, m_regs.t2, m_regs.t3);
        fprintf(f, "    \"t4\": \"0x%08X\", \"t5\": \"0x%08X\", \"t6\": \"0x%08X\", \"t7\": \"0x%08X\",\n",
                m_regs.t4, m_regs.t5, m_regs.t6, m_regs.t7);
        fprintf(f, "    \"s0\": \"0x%08X\", \"s1\": \"0x%08X\", \"s2\": \"0x%08X\", \"s3\": \"0x%08X\",\n",
                m_regs.s0, m_regs.s1, m_regs.s2, m_regs.s3);
        fprintf(f, "    \"s4\": \"0x%08X\", \"s5\": \"0x%08X\", \"s6\": \"0x%08X\", \"s7\": \"0x%08X\",\n",
                m_regs.s4, m_regs.s5, m_regs.s6, m_regs.s7);
        fprintf(f, "    \"sp\": \"0x%08X\", \"fp\": \"0x%08X\", \"gp\": \"0x%08X\", \"ra\": \"0x%08X\",\n",
                m_regs.sp, m_regs.fp, m_regs.gp, m_regs.ra);
        fprintf(f, "    \"hi\": \"0x%08X\", \"lo\": \"0x%08X\",\n", m_regs.hi, m_regs.lo);
        fprintf(f, "    \"cp0_status\": \"0x%08X\", \"cp0_cause\": \"0x%08X\", \"cp0_epc\": \"0x%08X\"\n",
                m_regs.cp0_status, m_regs.cp0_cause, m_regs.cp0_epc);
        fprintf(f, "  },\n");
    }

    // ── Memory Dump (Third Table boundary at 0x8001B2xx) ─────────────────
    if (m_mem_captured) {
        fprintf(f, "  \"Memory_Dump\": {\n");
        fprintf(f, "    \"base_addr\": \"0x%08X\",\n", m_mem_dump.base_addr);
        fprintf(f, "    \"length\": %u,\n", m_mem_dump.length);
        fprintf(f, "    \"hex\": \"");
        for (uint32_t i = 0; i < m_mem_dump.length; i++) {
            fprintf(f, "%02X", m_mem_dump.data[i]);
        }
        fprintf(f, "\"\n  },\n");
    }

    // ── Crash Memory Dump (bytes around the crash PC) ─────────────────────
    if (m_crash_mem_captured) {
        fprintf(f, "  \"Crash_Memory_Dump\": {\n");
        fprintf(f, "    \"base_addr\": \"0x%08X\",\n", m_crash_mem_dump.base_addr);
        fprintf(f, "    \"length\": %u,\n", m_crash_mem_dump.length);
        fprintf(f, "    \"hex\": \"");
        for (uint32_t i = 0; i < m_crash_mem_dump.length; i++) {
            fprintf(f, "%02X", m_crash_mem_dump.data[i]);
        }
        fprintf(f, "\"\n  },\n");
    }

    // ── VFS Access History ───────────────────────────────────────────────
    fprintf(f, "  \"Asset_Load_History\": [\n");
    for (int i = 0; i < m_vfs_count; i++) {
        VfsAccessRecord& v = m_vfs_log[i];
        fprintf(f, "    {\n");
        write_json_string(f, "resource_id", v.resource_id, 6);
        fprintf(f, ",\n");
        write_json_uint(f, "lba", v.lba, 6);
        fprintf(f, ",\n");
        write_json_uint(f, "size", v.size, 6);
        fprintf(f, ",\n");
        write_json_bool(f, "resolved", v.resolved, 6);
        fprintf(f, ",\n");
        fprintf(f, "      \"calling_pc\": \"0x%08X\",\n", v.calling_pc);
        write_json_uint(f, "instr_count", v.instr_count, 6);
        fprintf(f, ",\n");
        write_json_string(f, "error", v.error, 6);
        fprintf(f, "\n    }%s\n", (i < m_vfs_count - 1) ? "," : "");
    }
    fprintf(f, "  ],\n");

    // ── Error Signature ──────────────────────────────────────────────────
    fprintf(f, "  \"Error_Signature\": [\n");
    for (int i = 0; i < m_error_count; i++) {
        ErrorRecord& e = m_errors[i];
        fprintf(f, "    {\n");
        write_json_string(f, "category", e.category, 6);
        fprintf(f, ",\n");
        write_json_string(f, "signature", e.signature, 6);
        fprintf(f, ",\n");
        fprintf(f, "      \"pc\": \"0x%08X\",\n", e.pc);
        write_json_uint(f, "instr_count", e.instr_count, 6);
        fprintf(f, "\n    }%s\n", (i < m_error_count - 1) ? "," : "");
    }
    fprintf(f, "  ],\n");

    // ── BIOS Call Log (last 64 calls) ────────────────────────────────────
    fprintf(f, "  \"BIOS_Call_Log\": [\n");
    for (int i = 0; i < m_bios_log_count; i++) {
        BiosCallEntry& e = m_bios_log[i];
        fprintf(f, "    {\"instr\":%llu,\"table\":\"%c\",\"fn\":%d,\"ra\":\"0x%08X\",\"a0\":\"0x%08X\",\"a1\":\"0x%08X\",\"a2\":\"0x%08X\",\"a3\":\"0x%08X\"}%s\n",
                e.instr_count, e.table, e.function, e.ra, e.a0, e.a1, e.a2, e.a3,
                (i < m_bios_log_count - 1) ? "," : "");
    }
    fprintf(f, "  ],\n");

    // ── Hardware State ───────────────────────────────────────────────────
    fprintf(f, "  \"HW_State\": {\n");
    fprintf(f, "    \"cdrom_reading\": %s,\n", mem.cdrom_reading ? "true" : "false");
    fprintf(f, "    \"cdrom_sectors_read\": %d,\n", mem.cdrom_sectors_read);
    fprintf(f, "    \"cdrom_total_sectors_read\": %llu,\n", (unsigned long long)mem.cdrom_total_sectors_read);
    fprintf(f, "    \"cdrom_cur_lba\": %u,\n", mem.cdrom_cur_lba);
    fprintf(f, "    \"cdrom_data_ready\": %s,\n", mem.cdrom_data_ready ? "true" : "false");
    fprintf(f, "    \"pad_started\": %s,\n", mem.pad_started ? "true" : "false");
    fprintf(f, "    \"pad_buf1_addr\": \"0x%08X\",\n", mem.pad_buf1_addr);
    fprintf(f, "    \"pad1_buttons\": \"0x%04X\"\n", mem.pad1_buttons);
    fprintf(f, "  },\n");

    // ── Assertion State (QA-Master) ─────────────────────────────────────
    fprintf(f, "  \"Assertions\": [\n");
    for (int i = 0; i < m_assert_count; i++) {
        AssertRecord& a = m_assertions[i];
        const char* sev_names[] = {"INFO", "WARN", "FAIL", "PARITY"};
        const char* sev_str = (int)a.severity < 4 ? sev_names[(int)a.severity] : "UNKNOWN";
        fprintf(f, "    {\n");
        write_json_string(f, "name", a.name, 6);
        fprintf(f, ",\n");
        write_json_string(f, "severity", sev_str, 6);
        fprintf(f, ",\n");
        write_json_string(f, "detail", a.detail, 6);
        fprintf(f, ",\n");
        fprintf(f, "      \"pc\": \"0x%08X\",\n", a.pc);
        write_json_uint(f, "instr_count", a.instr_count, 6);
        fprintf(f, ",\n");
        fprintf(f, "      \"expected\": \"0x%08X\",\n", a.expected);
        fprintf(f, "      \"actual\": \"0x%08X\"\n", a.actual);
        fprintf(f, "    }%s\n", (i < m_assert_count - 1) ? "," : "");
    }
    fprintf(f, "  ],\n");
    write_json_bool(f, "Assert_Fail", m_assert_fail, 2);
    fprintf(f, ",\n");
    write_json_uint(f, "Assert_Count", m_assert_count, 2);
    fprintf(f, ",\n");
    write_json_uint(f, "Assert_Fail_Count", m_assert_fail_count, 2);
    fprintf(f, ",\n");

    // ── CD-ROM Trace ─────────────────────────────────────────────────────
    fprintf(f, "  \"CDROM_Trace\": {\n");
    fprintf(f, "    \"total_commands\": %d,\n", g_cdrom_tracer.total_commands);
    fprintf(f, "    \"total_errors\": %d,\n", g_cdrom_tracer.total_errors);
    fprintf(f, "    \"setloc_errors\": %d,\n", g_cdrom_tracer.setloc_errors);
    fprintf(f, "    \"getstat_spam_count\": %d,\n", g_cdrom_tracer.getstat_spam_count);
    fprintf(f, "    \"last_progress_lba\": %u,\n", g_cdrom_tracer.last_progress_lba);
    fprintf(f, "    \"instructions_at_last_progress\": %llu,\n",
            (unsigned long long)g_cdrom_tracer.instructions_at_last_progress);
    fprintf(f, "    \"commands\": [\n");
    for (size_t i = 0; i < g_cdrom_tracer.commands.size(); i++) {
        const auto& c = g_cdrom_tracer.commands[i];
        fprintf(f, "      {\"instr\":%llu,\"pc\":\"0x%08X\",\"ra\":\"0x%08X\",\"cmd\":\"%s\",\"cmd_byte\":%d,\"params\":%d,\"result\":%d}%s\n",
                (unsigned long long)c.instruction_count, c.pc, c.ra,
                c.command_name, c.command, c.param_count, c.result,
                i < g_cdrom_tracer.commands.size() - 1 ? "," : "");
    }
    fprintf(f, "    ],\n");

    // Event log
    fprintf(f, "    \"events\": [\n");
    for (size_t i = 0; i < g_cdrom_tracer.events.size(); i++) {
        const auto& e = g_cdrom_tracer.events[i];
        fprintf(f, "      {\"instr\":%llu,\"event_id\":%u,\"class\":%u,\"spec\":%u,\"flags\":%d,\"action\":\"%s\",\"test_result\":%d}%s\n",
                (unsigned long long)e.instruction_count, e.event_id,
                e.class_id, e.spec, e.flags,
                e.action ? e.action : "unknown",
                e.test_result,
                i < g_cdrom_tracer.events.size() - 1 ? "," : "");
    }
    fprintf(f, "    ],\n");

    // Diagnostic summary
    fprintf(f, "    \"diagnostics\": {\n");
    fprintf(f, "      \"fifo_overflow_detected\": %s,\n",
            g_cdrom_tracer.setloc_errors > 0 ? "true" : "false");
    fprintf(f, "      \"command_spam_detected\": %s,\n",
            g_cdrom_tracer.getstat_spam_count > 0 ? "true" : "false");
    fprintf(f, "      \"no_lba_progress\": %s,\n",
            (g_cdrom_tracer.total_commands > 0 && g_cdrom_tracer.last_progress_lba == 0) ? "true" : "false");
    fprintf(f, "      \"command_count\": %d,\n", g_cdrom_tracer.total_commands);
    fprintf(f, "      \"error_rate\": %.4f\n",
            g_cdrom_tracer.total_commands > 0
                ? (double)g_cdrom_tracer.total_errors / g_cdrom_tracer.total_commands
                : 0.0);
    fprintf(f, "    }\n");
    fprintf(f, "  },\n");

    // ── CD-ROM Error Breakpoint (Section 5.2) ─────────────────────────────
    g_cdrom_tracer.dump_breakpoint_json(f);

    // ── TTY Tail (last 64KB of console output) ───────────────────────────
    fprintf(f, "  \"TTY_Tail\": ");
    if (tail && *tail) {
        char escaped[HARNESS_TTY_TAIL_SIZE * 2];
        json_escape(tail, escaped, sizeof(escaped));
        fprintf(f, "\"%s\"\n", escaped);
    } else {
        fprintf(f, "\"\"\n");
    }

    fprintf(f, "}\n");
    fclose(f);
}

// ═══════════════════════════════════════════════════════════════════════════════
// QA-Master: Assertion State
// ═══════════════════════════════════════════════════════════════════════════════

void AgentHarness::record_assert(const char* name, AssertSeverity severity,
                                   const char* detail, uint32_t expected, uint32_t actual) {
    if (m_assert_count >= HARNESS_ASSERT_MAX) {
        tty_printf("[ASSERT] WARNING: Assertion buffer full (%d), ignoring: %s\n",
                   m_assert_count, name ? name : "?");
        return;
    }

    AssertRecord& a = m_assertions[m_assert_count++];
    strncpy(a.name, name ? name : "?", 63);
    a.name[63] = 0;
    a.severity = severity;
    strncpy(a.detail, detail ? detail : "", 255);
    a.detail[255] = 0;
    a.pc = g_cpu ? g_cpu->pc : 0;
    a.instr_count = g_cpu ? g_cpu->instructions : 0;
    a.expected = expected;
    a.actual = actual;
    a.fired = true;

    const char* sev_str = (severity == ASSERT_FAIL) ? "FAIL" :
                          (severity == ASSERT_WARN) ? "WARN" :
                          (severity == ASSERT_PARITY) ? "PARITY" : "INFO";
    tty_printf("[ASSERT:%s] %s — %s (expected=0x%08X actual=0x%08X PC=0x%08X instr=%llu)\n",
               sev_str, a.name, a.detail, expected, actual, a.pc, a.instr_count);

    if (severity == ASSERT_FAIL || severity == ASSERT_PARITY) {
        m_assert_fail = true;
        m_assert_fail_count++;
    }
}

// ═══════════════════════════════════════════════════════════════════════════════
// Phase 9: Live RAM State Injection
// ═══════════════════════════════════════════════════════════════════════════════

void AgentHarness::queue_injection(uint32_t addr, uint32_t value, uint8_t size,
                                    InjectCondition cond, uint64_t trigger_value,
                                    const char* label) {
    if (m_injection_count >= HARNESS_INJECT_MAX) {
        tty_printf("[INJECT] WARNING: Injection queue full (%d), ignoring: %s\n",
                   m_injection_count, label ? label : "?");
        return;
    }
    RamInjection& inj = m_injections[m_injection_count++];
    inj.addr = addr;
    inj.value = value;
    inj.size = size;
    inj.cond = cond;
    inj.trigger_value = trigger_value;
    inj.fired = false;
    inj.type = 0;
    inj.data_len = 0;
    memset(inj.data, 0, sizeof(inj.data));
    if (label) {
        strncpy(inj.label, label, 63);
        inj.label[63] = 0;
    } else {
        inj.label[0] = 0;
    }
    tty_printf("[INJECT] Queued #%d: addr=0x%08X val=0x%X size=%d cond=%d trigger=%llu (%s)\n",
               m_injection_count - 1, addr, value, size, (int)cond, trigger_value,
               inj.label);
}

void AgentHarness::queue_pc_dump(uint32_t pc, const char* label) {
    queue_injection(0, 0, 0, INJECT_AT_PC_DUMP, pc, label);
}

int AgentHarness::load_injections(const char* json_path) {
    FILE* f = fopen(json_path, "r");
    if (!f) {
        tty_printf("[INJECT] Failed to open injection spec: %s\n", json_path);
        return -1;
    }
    fseek(f, 0, SEEK_END);
    long fsize = ftell(f);
    fseek(f, 0, SEEK_SET);
    char* json = (char*)malloc(fsize + 1);
    fread(json, 1, fsize, f);
    json[fsize] = 0;
    fclose(f);

    // Minimal JSON parser — find "injections" array
    const char* p = strstr(json, "\"injections\"");
    if (!p) {
        tty_printf("[INJECT] No \"injections\" key found in spec\n");
        free(json);
        return -1;
    }
    p = strchr(p, '[');
    if (!p) { free(json); return -1; }
    p++;

    int loaded = 0;
    while (p && *p && m_injection_count < HARNESS_INJECT_MAX) {
        const char* obj_start = strchr(p, '{');
        if (!obj_start) break;
        // Find matching closing brace with depth counting (handles nested objects)
        const char* obj_end = nullptr;
        int depth = 0;
        for (const char* q = obj_start; *q; q++) {
            if (*q == '{') depth++;
            else if (*q == '}') { depth--; if (depth == 0) { obj_end = q; break; } }
        }
        if (!obj_end) break;
        int obj_len = (int)(obj_end - obj_start + 1);
        char obj_buf[4096];
        if (obj_len < 4096) {
            memcpy(obj_buf, obj_start, obj_len);
            obj_buf[obj_len] = 0;

            // Parse fields using simple string search
            auto get_uint = [](const char* obj, const char* key) -> uint64_t {
                char pat[64]; snprintf(pat, sizeof(pat), "\"%s\"", key);
                const char* q = strstr(obj, pat);
                if (!q) return 0;
                q = strchr(q, ':'); if (!q) return 0; q++;
                while (*q == ' ' || *q == '\t') q++;
                if (*q == '"') q++;  // skip opening quote for string-valued numbers
                if (*q == '0' && (q[1] == 'x' || q[1] == 'X'))
                    return strtoull(q + 2, nullptr, 16);
                return strtoull(q, nullptr, 10);
            };
            auto get_str = [](const char* obj, const char* key, char* out, int outlen) {
                out[0] = 0;
                char pat[64]; snprintf(pat, sizeof(pat), "\"%s\"", key);
                const char* q = strstr(obj, pat);
                if (!q) return;
                q = strchr(q, ':'); if (!q) return; q++;
                while (*q == ' ' || *q == '\t') q++;
                if (*q != '"') return; q++;
                int i = 0;
                while (*q && *q != '"' && i < outlen - 1) out[i++] = *q++;
                out[i] = 0;
            };

            RamInjection& inj = m_injections[m_injection_count];
            inj.addr = (uint32_t)get_uint(obj_buf, "addr");
            inj.value = (uint32_t)get_uint(obj_buf, "value");
            inj.size = (uint8_t)get_uint(obj_buf, "size");
            if (inj.size == 0) inj.size = 4;  // default to 32-bit
            inj.type = 0;
            inj.data_len = 0;
            memset(inj.data, 0, sizeof(inj.data));

            // Optional byte-array payload for arbitrary-length injections
            char type_str[32];
            get_str(obj_buf, "type", type_str, sizeof(type_str));
            if (!strcmp(type_str, "bytes")) {
                inj.type = 1;
                const char* data_key = strstr(obj_buf, "\"data\"");
                if (data_key) {
                    const char* arr = strchr(data_key, '[');
                    if (arr) {
                        arr++;
                        int idx = 0;
                        while (*arr && *arr != ']' && idx < (int)sizeof(inj.data)) {
                            while (*arr && (*arr == ' ' || *arr == '\t' || *arr == '\n' || *arr == ',')) arr++;
                            if (*arr == ']') break;
                            if (*arr == '"') {
                                arr++;
                                char tok[8] = {0};
                                int t = 0;
                                while (*arr && *arr != '"' && t < 7) tok[t++] = *arr++;
                                if (*arr == '"') arr++;
                                inj.data[idx++] = (uint8_t)strtoul(tok, nullptr, 0);
                            } else {
                                char* end = nullptr;
                                unsigned long v = strtoul(arr, &end, 0);
                                if (end != arr) {
                                    inj.data[idx++] = (uint8_t)v;
                                    arr = end;
                                } else {
                                    arr++;
                                }
                            }
                        }
                        inj.data_len = idx;
                    }
                }
            }

            char cond_str[32];
            get_str(obj_buf, "condition", cond_str, sizeof(cond_str));
            if (!strcmp(cond_str, "at_instr")) inj.cond = INJECT_AT_INSTR;
            else if (!strcmp(cond_str, "at_vblank")) inj.cond = INJECT_AT_VBLANK;
            else if (!strcmp(cond_str, "at_pc")) inj.cond = INJECT_AT_PC;
            else if (!strcmp(cond_str, "immediate")) inj.cond = INJECT_IMMEDIATE;
            else if (!strcmp(cond_str, "on_freeze")) inj.cond = INJECT_ON_FREEZE;
            else if (!strcmp(cond_str, "on_hardware_init")) inj.cond = INJECT_ON_HW_INIT;
            else if (!strcmp(cond_str, "pad_macro")) inj.cond = INJECT_PAD_MACRO;
            else inj.cond = INJECT_IMMEDIATE;

            inj.trigger_value = get_uint(obj_buf, "trigger");
            inj.fired = false;
            inj.pad_step_count = 0;
            get_str(obj_buf, "label", inj.label, sizeof(inj.label));

            // Parse pad_macro array if present (for INJECT_PAD_MACRO condition)
            if (inj.cond == INJECT_PAD_MACRO) {
                const char* pm = strstr(obj_buf, "\"pad_macro\"");
                if (pm) {
                    pm = strchr(pm, '[');
                    if (pm) pm++;
                    while (pm && *pm && inj.pad_step_count < HARNESS_PAD_MACRO_MAX) {
                        const char* pm_obj = strchr(pm, '{');
                        if (!pm_obj) break;
                        // Find matching closing brace with depth counting
                        const char* pm_end = nullptr;
                        int pm_depth = 0;
                        for (const char* qd = pm_obj; *qd; qd++) {
                            if (*qd == '{') pm_depth++;
                            else if (*qd == '}') { pm_depth--; if (pm_depth == 0) { pm_end = qd; break; } }
                        }
                        if (!pm_end) break;
                        int pm_len = (int)(pm_end - pm_obj + 1);
                        char pm_buf[256];
                        if (pm_len < 256) {
                            memcpy(pm_buf, pm_obj, pm_len);
                            pm_buf[pm_len] = 0;

                            PadMacroStep& step = inj.pad_steps[inj.pad_step_count];
                            step.vblank = get_uint(pm_buf, "frame");
                            step.press = true; // default to press

                            // Parse press/release
                            char press_str[16];
                            get_str(pm_buf, "press", press_str, sizeof(press_str));
                            // If press field exists and is a button name, it's a press
                            // If "release" keyword, it's a release
                            if (!strcmp(press_str, "release") || !strcmp(press_str, "RELEASE")) {
                                step.press = false;
                                step.buttons = 0xFFFF; // release all
                            } else {
                                step.press = true;
                                // Parse button name to mask
                                step.buttons = 0;
                                // Check for known button names
                                if (strstr(press_str, "CIRCLE") || strstr(press_str, "circle")) step.buttons |= 0x0010;
                                if (strstr(press_str, "CROSS") || strstr(press_str, "cross")) step.buttons |= 0x0008;
                                if (strstr(press_str, "TRIANGLE") || strstr(press_str, "triangle")) step.buttons |= 0x0020;
                                if (strstr(press_str, "SQUARE") || strstr(press_str, "square")) step.buttons |= 0x0004;
                                if (strstr(press_str, "UP") || strstr(press_str, "up")) step.buttons |= 0x1000;
                                if (strstr(press_str, "DOWN") || strstr(press_str, "down")) step.buttons |= 0x4000;
                                if (strstr(press_str, "LEFT") || strstr(press_str, "left")) step.buttons |= 0x8000;
                                if (strstr(press_str, "RIGHT") || strstr(press_str, "right")) step.buttons |= 0x2000;
                                if (strstr(press_str, "START") || strstr(press_str, "start")) step.buttons |= 0x0800;
                                if (strstr(press_str, "SELECT") || strstr(press_str, "select")) step.buttons |= 0x0400;
                                if (strstr(press_str, "L1") || strstr(press_str, "l1")) step.buttons |= 0x0080;
                                if (strstr(press_str, "R1") || strstr(press_str, "r1")) step.buttons |= 0x0040;
                                if (step.buttons == 0) step.buttons = 0xFFFF; // fallback
                            }
                            strncpy(step.name, press_str, 15);
                            step.name[15] = 0;
                            inj.pad_step_count++;
                        }
                        pm = pm_end + 1;
                    }
                }
                tty_printf("[INJECT] Pad macro: %d steps for '%s'\n", inj.pad_step_count,
                           inj.label[0] ? inj.label : "?");
            }

            m_injection_count++;
            loaded++;
        }
        p = obj_end + 1;
    }

    free(json);
    tty_printf("[INJECT] Loaded %d injection entries from %s\n", loaded, json_path);
    return loaded;
}

// ── Symbol Table ───────────────────────────────────────────────────────────
// Load a simple JSON map: { "NAME": "0x8004BD71", ... }
static const char* skip_whitespace(const char* p) {
    while (p && (*p == ' ' || *p == '\t' || *p == '\n' || *p == '\r')) p++;
    return p;
}

static const char* parse_json_string(const char* p, char* out, int out_len) {
    p = skip_whitespace(p);
    if (!p || *p != '"') return nullptr;
    p++;
    int i = 0;
    while (*p && *p != '"' && i < out_len - 1) {
        out[i++] = *p++;
    }
    out[i] = 0;
    if (*p != '"') return nullptr;
    p++; // skip closing quote
    return p;
}

int AgentHarness::load_symbols(const char* json_path) {
    FILE* f = fopen(json_path, "r");
    if (!f) {
        tty_printf("[SYMBOLS] Failed to open symbol table: %s\n", json_path);
        return -1;
    }
    fseek(f, 0, SEEK_END);
    long fsize = ftell(f);
    fseek(f, 0, SEEK_SET);
    char* json = (char*)malloc(fsize + 1);
    if (!json) { fclose(f); return -1; }
    fread(json, 1, fsize, f);
    json[fsize] = 0;
    fclose(f);

    m_symbols.clear();
    int loaded = 0;
    const char* p = skip_whitespace(json);
    if (*p == '{') p++;

    while (p && *p && *p != '}') {
        char key[128];
        p = parse_json_string(p, key, sizeof(key));
        if (!p) break;
        p = skip_whitespace(p);
        if (*p != ':') break;
        p++;
        p = skip_whitespace(p);

        char val[128];
        if (*p == '"') {
            p = parse_json_string(p, val, sizeof(val));
            if (!p) break;
        } else {
            int i = 0;
            while (*p && *p != ',' && *p != '}' && i < (int)sizeof(val) - 1) {
                val[i++] = *p++;
            }
            val[i] = 0;
        }
        uint32_t addr = (uint32_t)strtoull(val, nullptr, 0);
        m_symbols[std::string(key)] = addr;
        loaded++;

        p = skip_whitespace(p);
        if (*p == ',') p++;
        p = skip_whitespace(p);
    }

    free(json);
    tty_printf("[SYMBOLS] Loaded %d symbols from %s\n", loaded, json_path);
    return loaded;
}

bool AgentHarness::resolve_symbol(const char* name_or_addr, uint32_t* out) const {
    if (!name_or_addr || !out) return false;
    // Numeric address?
    if (name_or_addr[0] == '0' && (name_or_addr[1] == 'x' || name_or_addr[1] == 'X')) {
        *out = (uint32_t)strtoull(name_or_addr, nullptr, 16);
        return true;
    }
    if (name_or_addr[0] >= '0' && name_or_addr[0] <= '9') {
        *out = (uint32_t)strtoull(name_or_addr, nullptr, 0);
        return true;
    }
    auto it = m_symbols.find(std::string(name_or_addr));
    if (it != m_symbols.end()) {
        *out = it->second;
        return true;
    }
    return false;
}

uint32_t AgentHarness::symbol_address(const char* name) const {
    auto it = m_symbols.find(std::string(name ? name : ""));
    return (it != m_symbols.end()) ? it->second : 0;
}

static void dump_pc_state(AgentHarness* harness, MIPS_CPU& cpu, PSX_Memory& mem,
                          uint64_t instr_count, RamInjection& inj, int idx,
                          uint32_t extra_mem_addr = 0, bool extra_mem_set = false) {
    harness->capture_registers(cpu);
    uint32_t sp = cpu.get_reg(29);
    if (sp >= 0x80000000 && sp < 0x80200000) {
        harness->capture_memory(mem, sp & ~0xFF, 256);
    }
    if (extra_mem_set && extra_mem_addr >= 0x80000000 && extra_mem_addr < 0x80200000) {
        harness->capture_memory(mem, extra_mem_addr & ~0xFF, 256);
        harness->tty_printf("[INJECT] DIAG_DUMP extra memory captured at 0x%08X\n",
                            extra_mem_addr & ~0xFF);
    }
    harness->tty_printf("[INJECT] DIAG_DUMP #%d at PC=0x%08X instr #%llu (%s)\n",
                        idx, cpu.pc, instr_count, inj.label[0] ? inj.label : "?");
    harness->tty_printf("[INJECT]   $a0=0x%08X $a1=0x%08X $a2=0x%08X $a3=0x%08X\n",
                        cpu.get_reg(4), cpu.get_reg(5), cpu.get_reg(6), cpu.get_reg(7));
    harness->tty_printf("[INJECT]   $v0=0x%08X $v1=0x%08X $ra=0x%08X $sp=0x%08X\n",
                        cpu.get_reg(2), cpu.get_reg(3), cpu.get_reg(31), sp);
    fprintf(stderr, "[INJECT] DIAG_DUMP #%d at PC=0x%08X instr #%llu (%s)\n",
            idx, cpu.pc, (unsigned long long)instr_count,
            inj.label[0] ? inj.label : "?");
}

void AgentHarness::check_injections(MIPS_CPU& cpu, PSX_Memory& mem,
                                     uint64_t instr_count, uint32_t vblank_count) {
    for (int i = 0; i < m_injection_count; i++) {
        RamInjection& inj = m_injections[i];
        if (inj.fired) continue;

        bool should_fire = false;
        switch (inj.cond) {
            case INJECT_AT_INSTR:
                if (instr_count >= inj.trigger_value) should_fire = true;
                break;
            case INJECT_AT_VBLANK:
                if (vblank_count >= inj.trigger_value) should_fire = true;
                break;
            case INJECT_AT_PC:
                if (cpu.pc == (uint32_t)inj.trigger_value) should_fire = true;
                break;
            case INJECT_IMMEDIATE:
                should_fire = true;
                break;
            case INJECT_ON_FREEZE:
                // Handled separately in freeze detection path
                break;
            case INJECT_ON_HW_INIT:
                // Fire when pad is started (hardware init complete)
                if (mem.pad_started) should_fire = true;
                break;
            case INJECT_PAD_MACRO:
                // Fire immediately — queue all pad inputs
                should_fire = true;
                break;
            case INJECT_AT_PC_DUMP:
                if (cpu.pc == (uint32_t)inj.trigger_value) should_fire = true;
                break;
        }

        if (!should_fire) continue;

        if (inj.cond == INJECT_AT_PC_DUMP) {
            dump_pc_state(this, cpu, mem, instr_count, inj, i,
                          m_diag_mem_addr, m_diag_mem_set);
            inj.fired = true;
            if (m_diag_pc_quit) {
                m_diag_dump_quit = true;
                tty_printf("[INJECT] DIAG_DUMP quit flag set\n");
            }
            console_pause();
            continue;
        }

        if (inj.cond == INJECT_PAD_MACRO) {
            // Queue all pad macro steps into the emulator's input queue
            for (int s = 0; s < inj.pad_step_count; s++) {
                PadMacroStep& step = inj.pad_steps[s];
                mem.queue_input(step.vblank, step.buttons, step.press);
                tty_printf("[INJECT] PAD_MACRO: vblank=%llu %s btn=0x%04X (%s)\n",
                           (unsigned long long)step.vblank,
                           step.press ? "PRESS" : "RELEASE",
                           step.buttons, step.name);
            }
            inj.fired = true;
            tty_printf("[INJECT] FIRED #%d: PAD_MACRO %d steps (%s)\n",
                       i, inj.pad_step_count,
                       inj.label[0] ? inj.label : "?");
            continue;
        }

        // Apply the injection
        if (inj.type == 1 && inj.data_len > 0) {
            for (int b = 0; b < inj.data_len; b++) {
                mem.write8(inj.addr + b, inj.data[b]);
            }
        } else {
            switch (inj.size) {
                case 1:
                    mem.write8(inj.addr, (uint8_t)inj.value);
                    break;
                case 2:
                    mem.write16(inj.addr, (uint16_t)inj.value);
                    break;
                case 4:
                default:
                    mem.write32(inj.addr, inj.value);
                    break;
            }
        }
        inj.fired = true;

        tty_printf("[INJECT] FIRED #%d: addr=0x%08X val=0x%X size=%d len=%u at instr #%llu (%s)\n",
                   i, inj.addr, inj.value, inj.size, (unsigned)inj.data_len, instr_count,
                   inj.label[0] ? inj.label : "?");
        fprintf(stderr, "[INJECT] FIRED #%d: addr=0x%08X val=0x%X size=%d len=%u at instr #%llu (%s)\n",
                i, inj.addr, inj.value, inj.size, (unsigned)inj.data_len, (unsigned long long)instr_count,
                inj.label[0] ? inj.label : "?");
    }
}

int AgentHarness::pending_injections() const {
    int count = 0;
    for (int i = 0; i < m_injection_count; i++)
        if (!m_injections[i].fired) count++;
    return count;
}

int AgentHarness::fired_injections() const {
    int count = 0;
    for (int i = 0; i < m_injection_count; i++)
        if (m_injections[i].fired) count++;
    return count;
}

bool AgentHarness::has_pc_dump_pending() const {
    for (int i = 0; i < m_injection_count; i++) {
        if (!m_injections[i].fired && m_injections[i].cond == INJECT_AT_PC_DUMP) {
            return true;
        }
    }
    return false;
}

bool AgentHarness::check_pc_dump_before_step(MIPS_CPU& cpu, PSX_Memory& mem,
                                              uint64_t instr_count) {
    bool fired_any = false;
    for (int i = 0; i < m_injection_count; i++) {
        RamInjection& inj = m_injections[i];
        if (inj.fired || inj.cond != INJECT_AT_PC_DUMP) continue;
        if (cpu.pc == (uint32_t)inj.trigger_value) {
            dump_pc_state(this, cpu, mem, instr_count, inj, i,
                          m_diag_mem_addr, m_diag_mem_set);
            inj.fired = true;
            if (m_diag_pc_quit) {
                m_diag_dump_quit = true;
                tty_printf("[INJECT] DIAG_DUMP quit flag set\n");
            }
            console_pause();
            fired_any = true;
        }
    }
    return fired_any;
}

// ═══════════════════════════════════════════════════════════════════════════════
// Phase 10: Huffman Tree & Text Cache Buffer Monitor
// ═══════════════════════════════════════════════════════════════════════════════

void AgentHarness::add_monitor(uint32_t addr, uint8_t size, MonitorCondition cond,
                                uint32_t expected, uint32_t threshold,
                                const char* label) {
    if (m_monitor_count >= HARNESS_MONITOR_MAX) {
        tty_printf("[MONITOR] WARNING: Monitor table full (%d), ignoring: %s\n",
                   m_monitor_count, label ? label : "?");
        return;
    }
    BufferMonitor& mon = m_monitors[m_monitor_count++];
    mon.addr = addr;
    mon.size = size;
    mon.cond = cond;
    mon.expected = expected;
    mon.threshold = threshold;
    mon.last_value = 0;
    mon.fired = false;
    mon.active = true;
    // Note: initial value will be read on first check_monitors() call
    // We use a "first_read" flag via last_value == 0 and cond != MONITOR_VALUE_ZERO
    // to detect the first read. For MONITOR_VALUE_CHANGE, we set a sentinel.
    mon.last_value = 0xDEADBEEF;  // sentinel — first check_monitors will update

    if (label) {
        strncpy(mon.label, label, 63);
        mon.label[63] = 0;
    } else {
        mon.label[0] = 0;
    }

    tty_printf("[MONITOR] Added #%d: addr=0x%08X size=%d cond=%d (%s)\n",
               m_monitor_count - 1, addr, size, (int)cond,
               mon.label);
}

int AgentHarness::load_monitors(const char* json_path) {
    FILE* f = fopen(json_path, "r");
    if (!f) {
        tty_printf("[MONITOR] Failed to open monitor spec: %s\n", json_path);
        return -1;
    }
    fseek(f, 0, SEEK_END);
    long fsize = ftell(f);
    fseek(f, 0, SEEK_SET);
    char* json = (char*)malloc(fsize + 1);
    fread(json, 1, fsize, f);
    json[fsize] = 0;
    fclose(f);

    const char* p = strstr(json, "\"monitors\"");
    if (!p) {
        tty_printf("[MONITOR] No \"monitors\" key found in spec\n");
        free(json);
        return -1;
    }
    p = strchr(p, '[');
    if (!p) { free(json); return -1; }
    p++;

    int loaded = 0;
    while (p && *p && m_monitor_count < HARNESS_MONITOR_MAX) {
        const char* obj_start = strchr(p, '{');
        if (!obj_start) break;
        // Find matching closing brace with depth counting (handles nested arrays)
        const char* obj_end = nullptr;
        int depth = 0;
        for (const char* q = obj_start; *q; q++) {
            if (*q == '{') depth++;
            else if (*q == '}') { depth--; if (depth == 0) { obj_end = q; break; } }
        }
        if (!obj_end) break;
        int obj_len = (int)(obj_end - obj_start + 1);
        char obj_buf[2048];
        if (obj_len < 2048) {
            memcpy(obj_buf, obj_start, obj_len);
            obj_buf[obj_len] = 0;

            auto get_uint = [](const char* obj, const char* key) -> uint64_t {
                char pat[64]; snprintf(pat, sizeof(pat), "\"%s\"", key);
                const char* q = strstr(obj, pat);
                if (!q) return 0;
                q = strchr(q, ':'); if (!q) return 0; q++;
                while (*q == ' ' || *q == '\t') q++;
                if (*q == '"') q++;  // skip opening quote for string-valued numbers
                if (*q == '0' && (q[1] == 'x' || q[1] == 'X'))
                    return strtoull(q + 2, nullptr, 16);
                return strtoull(q, nullptr, 10);
            };
            auto get_str = [](const char* obj, const char* key, char* out, int outlen) {
                out[0] = 0;
                char pat[64]; snprintf(pat, sizeof(pat), "\"%s\"", key);
                const char* q = strstr(obj, pat);
                if (!q) return;
                q = strchr(q, ':'); if (!q) return; q++;
                while (*q == ' ' || *q == '\t') q++;
                if (*q != '"') return; q++;
                int i = 0;
                while (*q && *q != '"' && i < outlen - 1) out[i++] = *q++;
                out[i] = 0;
            };

            BufferMonitor& mon = m_monitors[m_monitor_count];
            mon.addr = (uint32_t)get_uint(obj_buf, "addr");
            mon.size = (uint8_t)get_uint(obj_buf, "size");
            if (mon.size == 0) mon.size = 4;

            char cond_str[32];
            get_str(obj_buf, "condition", cond_str, sizeof(cond_str));
            if (!strcmp(cond_str, "change")) mon.cond = MONITOR_VALUE_CHANGE;
            else if (!strcmp(cond_str, "matches")) mon.cond = MONITOR_VALUE_MATCHES;
            else if (!strcmp(cond_str, "nonzero")) mon.cond = MONITOR_VALUE_NONZERO;
            else if (!strcmp(cond_str, "zero")) mon.cond = MONITOR_VALUE_ZERO;
            else if (!strcmp(cond_str, "overflow")) mon.cond = MONITOR_OVERFLOW;
            else mon.cond = MONITOR_VALUE_CHANGE;

            mon.expected = (uint32_t)get_uint(obj_buf, "expected");
            mon.threshold = (uint32_t)get_uint(obj_buf, "threshold");
            mon.last_value = 0;
            mon.fired = false;
            mon.active = true;
            mon.log_regs = false;
            mon.log_mem_dump = false;
            mon.log_reg_mask = 0;
            get_str(obj_buf, "label", mon.label, sizeof(mon.label));

            // Parse log_registers field (array of register names)
            const char* lr = strstr(obj_buf, "\"log_registers\"");
            if (lr) {
                mon.log_regs = true;
                // Parse register names to build bitmask
                // bit0=v0, bit1=v1, bit2=a0, bit3=a1, bit4=ra, bit5=pc
                if (strstr(lr, "v0")) mon.log_reg_mask |= 0x01;
                if (strstr(lr, "v1")) mon.log_reg_mask |= 0x02;
                if (strstr(lr, "a0")) mon.log_reg_mask |= 0x04;
                if (strstr(lr, "a1")) mon.log_reg_mask |= 0x08;
                if (strstr(lr, "ra")) mon.log_reg_mask |= 0x10;
                if (strstr(lr, "pc")) mon.log_reg_mask |= 0x20;
            }
            // Parse log_on_trigger field
            const char* lot = strstr(obj_buf, "\"log_on_trigger\"");
            if (lot) {
                const char* lotv = strchr(lot, ':');
                if (lotv) {
                    lotv++;
                    while (*lotv == ' ' || *lotv == '\t') lotv++;
                    if (*lotv == 't' || *lotv == '1') mon.log_mem_dump = true;
                }
            }

            m_monitor_count++;
            loaded++;
        }
        p = obj_end + 1;
    }

    free(json);
    tty_printf("[MONITOR] Loaded %d monitor entries from %s\n", loaded, json_path);
    return loaded;
}

int AgentHarness::check_monitors(PSX_Memory& mem, MIPS_CPU& cpu, uint64_t instr_count) {
    int triggers = 0;
    for (int i = 0; i < m_monitor_count; i++) {
        BufferMonitor& mon = m_monitors[i];
        if (!mon.active || mon.fired) continue;

        // Read current value
        uint32_t current = 0;
        switch (mon.size) {
            case 1: current = mem.read8(mon.addr); break;
            case 2: current = mem.read16(mon.addr); break;
            case 4: current = mem.read32(mon.addr); break;
        }

        bool triggered = false;
        // Handle first-read sentinel
        if (mon.last_value == 0xDEADBEEF) {
            if (mon.cond == MONITOR_VALUE_CHANGE) {
                // First read — just record, don't trigger
                mon.last_value = current;
                continue;
            }
        }
        switch (mon.cond) {
            case MONITOR_VALUE_CHANGE:
                if (current != mon.last_value) triggered = true;
                break;
            case MONITOR_VALUE_MATCHES:
                if (current == mon.expected) triggered = true;
                break;
            case MONITOR_VALUE_NONZERO:
                if (current != 0) triggered = true;
                break;
            case MONITOR_VALUE_ZERO:
                if (current == 0) triggered = true;
                break;
            case MONITOR_OVERFLOW:
                if (current > mon.threshold) triggered = true;
                break;
        }

        if (triggered) {
            mon.fired = true;
            mon.active = false;
            triggers++;
            tty_printf("[MONITOR] TRIGGERED #%d: addr=0x%08X old=0x%X new=0x%X at instr #%llu (%s)\n",
                       i, mon.addr, mon.last_value, current, instr_count,
                       mon.label[0] ? mon.label : "?");

            // Register logging on trigger
            if (mon.log_regs && mon.log_reg_mask) {
                tty_printf("[MONITOR_REGS] %s:", mon.label[0] ? mon.label : "?");
                if (mon.log_reg_mask & 0x01) tty_printf(" $v0=0x%08X", cpu.get_reg(2));
                if (mon.log_reg_mask & 0x02) tty_printf(" $v1=0x%08X", cpu.get_reg(3));
                if (mon.log_reg_mask & 0x04) tty_printf(" $a0=0x%08X", cpu.get_reg(4));
                if (mon.log_reg_mask & 0x08) tty_printf(" $a1=0x%08X", cpu.get_reg(5));
                if (mon.log_reg_mask & 0x10) tty_printf(" $ra=0x%08X", cpu.get_reg(31));
                if (mon.log_reg_mask & 0x20) tty_printf(" $pc=0x%08X", cpu.pc);
                tty_printf("\n");
            }

            // Memory dump on trigger (256 bytes at addr)
            if (mon.log_mem_dump) {
                tty_printf("[MONITOR_MEM] %s @ 0x%08X (256 bytes):\n",
                           mon.label[0] ? mon.label : "?", mon.addr);
                for (int row = 0; row < 16; row++) {
                    uint32_t row_addr = mon.addr + row * 16;
                    tty_printf("  0x%08X:", row_addr);
                    for (int col = 0; col < 16; col++) {
                        tty_printf(" %02X", mem.read8(row_addr + col));
                    }
                    // ASCII representation
                    tty_printf("  |");
                    for (int col = 0; col < 16; col++) {
                        uint8_t b = mem.read8(row_addr + col);
                        tty_printf("%c", (b >= 0x20 && b < 0x7F) ? b : '.');
                    }
                    tty_printf("|\n");
                }
            }

            // Capture register snapshot on trigger
            // (caller should call capture_registers after seeing triggers > 0)
        }

        mon.last_value = current;
    }
    return triggers;
}

int AgentHarness::active_monitors() const {
    int count = 0;
    for (int i = 0; i < m_monitor_count; i++)
        if (m_monitors[i].active) count++;
    return count;
}

void AgentHarness::dump_monitor_status() {
    tty_printf("[MONITOR] Status: %d active, %d fired, %d total\n",
               active_monitors(), m_monitor_count - active_monitors(), m_monitor_count);
    for (int i = 0; i < m_monitor_count; i++) {
        BufferMonitor& mon = m_monitors[i];
        tty_printf("  #%d addr=0x%08X size=%d cond=%d %s last=0x%X (%s)\n",
                   i, mon.addr, mon.size, (int)mon.cond,
                   mon.fired ? "FIRED" : (mon.active ? "ACTIVE" : "INACTIVE"),
                   mon.last_value, mon.label);
    }
}

// ============================================================================
// Phase 11: Event-Driven Triage Hooks
// ============================================================================

static int find_free_watch_slot(AgentHarness* h, WatchEvent* events, int count) {
    for (int i = 0; i < count; i++) {
        if (!events[i].active) return i;
    }
    if (count < HARNESS_WATCH_EVENT_MAX) return count;
    return -1;
}

void AgentHarness::add_watch_bios_call(char table, uint8_t fn,
                                        WatchEventAction action, const char* label) {
    int slot = find_free_watch_slot(this, m_watch_events, m_watch_event_count);
    if (slot < 0) {
        tty_printf("[WATCH] No free watch-event slots!\n");
        return;
    }
    WatchEvent& we = m_watch_events[slot];
    memset(&we, 0, sizeof(we));
    we.type = WATCH_BIOS_CALL;
    we.action = action;
    we.table = table;
    we.bios_fn = fn;
    we.active = true;
    we.fired = false;
    we.fire_count = 0;
    we.last_fire_instr = 0;
    if (label) { strncpy(we.label, label, 63); we.label[63] = 0; }
    if (slot >= m_watch_event_count) m_watch_event_count = slot + 1;
    tty_printf("[WATCH] Registered BIOS call watch: %c:0x%02X action=0x%02X (%s)\n",
               table, fn, (int)action, label ? label : "?");
}

void AgentHarness::add_watch_bios_return(char table, uint8_t fn,
                                          uint32_t expected_return,
                                          bool return_matches,
                                          WatchEventAction action,
                                          const char* label) {
    int slot = find_free_watch_slot(this, m_watch_events, m_watch_event_count);
    if (slot < 0) { tty_printf("[WATCH] No free slots!\n"); return; }
    WatchEvent& we = m_watch_events[slot];
    memset(&we, 0, sizeof(we));
    we.type = WATCH_BIOS_RETURN;
    we.action = action;
    we.table = table;
    we.bios_fn = fn;
    we.expected_return = expected_return;
    we.return_matches = return_matches;
    we.active = true;
    we.fired = false;
    we.fire_count = 0;
    we.last_fire_instr = 0;
    if (label) { strncpy(we.label, label, 63); we.label[63] = 0; }
    if (slot >= m_watch_event_count) m_watch_event_count = slot + 1;
    tty_printf("[WATCH] Registered BIOS return watch: %c:0x%02X %s 0x%08X (%s)\n",
               table, fn, return_matches ? "==" : "!=", expected_return,
               label ? label : "?");
}

void AgentHarness::add_watch_pc(uint32_t pc_target, WatchEventAction action,
                                 const char* label) {
    int slot = find_free_watch_slot(this, m_watch_events, m_watch_event_count);
    if (slot < 0) { tty_printf("[WATCH] No free slots!\n"); return; }
    WatchEvent& we = m_watch_events[slot];
    memset(&we, 0, sizeof(we));
    we.type = WATCH_PC_REACHED;
    we.action = action;
    we.pc_target = pc_target;
    we.active = true;
    we.fired = false;
    we.fire_count = 0;
    we.last_fire_instr = 0;
    if (label) { strncpy(we.label, label, 63); we.label[63] = 0; }
    if (slot >= m_watch_event_count) m_watch_event_count = slot + 1;
    tty_printf("[WATCH] Registered PC watch: 0x%08X action=0x%02X (%s)\n",
               pc_target, (int)action, label ? label : "?");
}

void AgentHarness::add_watch_cdrom_error(WatchEventAction action, const char* label) {
    int slot = find_free_watch_slot(this, m_watch_events, m_watch_event_count);
    if (slot < 0) { tty_printf("[WATCH] No free slots!\n"); return; }
    WatchEvent& we = m_watch_events[slot];
    memset(&we, 0, sizeof(we));
    we.type = WATCH_CDROM_ERROR;
    we.action = action;
    we.active = true;
    we.fired = false;
    we.fire_count = 0;
    we.last_fire_instr = 0;
    if (label) { strncpy(we.label, label, 63); we.label[63] = 0; }
    if (slot >= m_watch_event_count) m_watch_event_count = slot + 1;
    tty_printf("[WATCH] Registered CD-ROM error watch (%s)\n", label ? label : "?");
}

void AgentHarness::add_watch_vfs_fail(WatchEventAction action, const char* label) {
    int slot = find_free_watch_slot(this, m_watch_events, m_watch_event_count);
    if (slot < 0) { tty_printf("[WATCH] No free slots!\n"); return; }
    WatchEvent& we = m_watch_events[slot];
    memset(&we, 0, sizeof(we));
    we.type = WATCH_VFS_FAIL;
    we.action = action;
    we.active = true;
    we.fired = false;
    we.fire_count = 0;
    we.last_fire_instr = 0;
    if (label) { strncpy(we.label, label, 63); we.label[63] = 0; }
    if (slot >= m_watch_event_count) m_watch_event_count = slot + 1;
    tty_printf("[WATCH] Registered VFS fail watch (%s)\n", label ? label : "?");
}

void AgentHarness::add_watch_int_break(WatchEventAction action, const char* label) {
    int slot = find_free_watch_slot(this, m_watch_events, m_watch_event_count);
    if (slot < 0) { tty_printf("[WATCH] No free slots!\n"); return; }
    WatchEvent& we = m_watch_events[slot];
    memset(&we, 0, sizeof(we));
    we.type = WATCH_INT_BREAK;
    we.action = action;
    we.active = true;
    we.fired = false;
    we.fire_count = 0;
    we.last_fire_instr = 0;
    if (label) { strncpy(we.label, label, 63); we.label[63] = 0; }
    if (slot >= m_watch_event_count) m_watch_event_count = slot + 1;
    tty_printf("[WATCH] Registered interrupt chain break watch (%s)\n", label ? label : "?");
}

static char bios_table_char(uint32_t call_pc) {
    if (call_pc == 0xA0) return 'A';
    if (call_pc == 0xB0) return 'B';
    if (call_pc == 0xC0) return 'C';
    return '?';
}

void AgentHarness::take_snapshot(MIPS_CPU& cpu, PSX_Memory& mem,
                           WatchEvent& we, uint64_t instr_count,
                           const char* trigger_desc) {
    // Find slot in ring buffer
    int slot = m_snapshot_head;
    m_snapshot_head = (m_snapshot_head + 1) % HARNESS_SNAPSHOT_MAX;
    if (m_snapshot_count < HARNESS_SNAPSHOT_MAX) m_snapshot_count++;

    DiagnosticSnapshot& snap = m_snapshots[slot];
    memset(&snap, 0, sizeof(snap));

    // Capture registers
    snap.regs.pc = cpu.pc;
    snap.regs.v0 = cpu.get_reg(2);
    snap.regs.v1 = cpu.get_reg(3);
    snap.regs.a0 = cpu.get_reg(4);
    snap.regs.a1 = cpu.get_reg(5);
    snap.regs.a2 = cpu.get_reg(6);
    snap.regs.a3 = cpu.get_reg(7);
    snap.regs.t0 = cpu.get_reg(8);  snap.regs.t1 = cpu.get_reg(9);
    snap.regs.t2 = cpu.get_reg(10); snap.regs.t3 = cpu.get_reg(11);
    snap.regs.t4 = cpu.get_reg(12); snap.regs.t5 = cpu.get_reg(13);
    snap.regs.t6 = cpu.get_reg(14); snap.regs.t7 = cpu.get_reg(15);
    snap.regs.s0 = cpu.get_reg(16); snap.regs.s1 = cpu.get_reg(17);
    snap.regs.s2 = cpu.get_reg(18); snap.regs.s3 = cpu.get_reg(19);
    snap.regs.s4 = cpu.get_reg(20); snap.regs.s5 = cpu.get_reg(21);
    snap.regs.s6 = cpu.get_reg(22); snap.regs.s7 = cpu.get_reg(23);
    snap.regs.sp = cpu.get_reg(29);
    snap.regs.fp = cpu.get_reg(30);
    snap.regs.gp = cpu.get_reg(28);
    snap.regs.ra = cpu.get_reg(31);
    snap.regs.hi = cpu.hi;
    snap.regs.lo = cpu.lo;
    snap.regs.cp0_status = cpu.cp0_status;
    snap.regs.cp0_cause = cpu.cp0_cause;
    snap.regs.cp0_epc = cpu.cp0_epc;

    // Capture memory around SP (stack frame)
    uint32_t sp = cpu.get_reg(29);
    if (sp >= 0x80000000 && sp < 0x80200000) {
        snap.mem.base_addr = sp;
        snap.mem.length = 256;
        for (uint32_t i = 0; i < 256; i++) {
            snap.mem.data[i] = mem.read8(sp + i);
        }
    }

    snap.instr_count = instr_count;
    snap.valid = true;
    if (trigger_desc) {
        strncpy(snap.trigger_label, trigger_desc, 63);
        snap.trigger_label[63] = 0;
    }
}

void AgentHarness::check_watch_bios(uint32_t call_pc, uint8_t fn,
                                     uint32_t return_val,
                                     MIPS_CPU& cpu, PSX_Memory& mem,
                                     uint64_t instr_count) {
    char table_ch = bios_table_char(call_pc);
    for (int i = 0; i < m_watch_event_count; i++) {
        WatchEvent& we = m_watch_events[i];
        if (!we.active) continue;

        bool trigger = false;
        char desc[128];

        if (we.type == WATCH_BIOS_CALL && we.table == table_ch && we.bios_fn == fn) {
            trigger = true;
            snprintf(desc, sizeof(desc), "BIOS %c:0x%02X called", table_ch, fn);
        } else if (we.type == WATCH_BIOS_RETURN && we.table == table_ch && we.bios_fn == fn) {
            bool matches = (return_val == we.expected_return);
            if (we.return_matches && matches) {
                trigger = true;
                snprintf(desc, sizeof(desc), "BIOS %c:0x%02X returned 0x%08X (==expected)",
                         table_ch, fn, return_val);
            } else if (!we.return_matches && !matches) {
                trigger = true;
                snprintf(desc, sizeof(desc), "BIOS %c:0x%02X returned 0x%08X (!=expected 0x%08X)",
                         table_ch, fn, return_val, we.expected_return);
            }
        }

        if (!trigger) continue;

        we.fired = true;
        we.fire_count++;
        we.last_fire_instr = instr_count;

        // Log
        if (we.action & WATCH_ACTION_LOG) {
            tty_printf("[WATCH_FIRE] #%d: %s at instr #%llu (%s)\n",
                       i, desc, instr_count,
                       we.label[0] ? we.label : "?");
            tty_printf("  PC=0x%08X $v0=0x%08X $a0=0x%08X $a1=0x%08X $ra=0x%08X\n",
                       cpu.pc, return_val, cpu.get_reg(4), cpu.get_reg(5), cpu.get_reg(31));
        }

        // Snapshot
        if (we.action & WATCH_ACTION_SNAPSHOT) {
            take_snapshot(cpu, mem, we, instr_count, desc);
            tty_printf("  [SNAPSHOT] Captured diagnostic snapshot #%d\n",
                       (m_snapshot_head - 1 + HARNESS_SNAPSHOT_MAX) % HARNESS_SNAPSHOT_MAX);
        }

        // Triage
        if (we.action & WATCH_ACTION_TRIAGE) {
            tty_printf("  [TRIAGE] Writing immediate triage log...\n");
            // Mark as non-complete to trigger triage
            write_triage_log(cpu, mem);
        }

        // JSON checkpoint
        if (we.action & WATCH_ACTION_JSON) {
            tty_printf("  [JSON] Writing telemetry checkpoint...\n");
            write_json(cpu, mem, PASS_RUNNING);
        }

        // Break
        if (we.action & WATCH_ACTION_BREAK) {
            tty_printf("  [BREAK] Halting emulation per watch-event!\n");
            m_frozen = true;
        }
    }
}

void AgentHarness::check_watch_pc(uint32_t pc, MIPS_CPU& cpu, PSX_Memory& mem,
                                   uint64_t instr_count) {
    for (int i = 0; i < m_watch_event_count; i++) {
        WatchEvent& we = m_watch_events[i];
        if (!we.active || we.type != WATCH_PC_REACHED) continue;
        if (pc != we.pc_target) continue;

        we.fired = true;
        we.fire_count++;
        we.last_fire_instr = instr_count;

        char desc[128];
        snprintf(desc, sizeof(desc), "PC reached 0x%08X", pc);

        if (we.action & WATCH_ACTION_LOG) {
            tty_printf("[WATCH_FIRE] #%d: %s at instr #%llu (%s)\n",
                       i, desc, instr_count, we.label[0] ? we.label : "?");
            tty_printf("  $v0=0x%08X $a0=0x%08X $ra=0x%08X $sp=0x%08X\n",
                       cpu.get_reg(2), cpu.get_reg(4), cpu.get_reg(31), cpu.get_reg(29));
        }
        if (we.action & WATCH_ACTION_SNAPSHOT) {
            take_snapshot(cpu, mem, we, instr_count, desc);
        }
        if (we.action & WATCH_ACTION_TRIAGE) {
            write_triage_log(cpu, mem);
        }
        if (we.action & WATCH_ACTION_JSON) {
            write_json(cpu, mem, PASS_RUNNING);
        }
        if (we.action & WATCH_ACTION_BREAK) {
            tty_printf("  [BREAK] Halting at PC=0x%08X\n", pc);
            m_frozen = true;
        }
    }
}

void AgentHarness::check_watch_cdrom_error(uint32_t lba, MIPS_CPU& cpu,
                                            PSX_Memory& mem, uint64_t instr_count) {
    for (int i = 0; i < m_watch_event_count; i++) {
        WatchEvent& we = m_watch_events[i];
        if (!we.active || we.type != WATCH_CDROM_ERROR) continue;

        we.fired = true;
        we.fire_count++;
        we.last_fire_instr = instr_count;

        char desc[128];
        snprintf(desc, sizeof(desc), "CD-ROM error at LBA=%u", lba);

        if (we.action & WATCH_ACTION_LOG) {
            tty_printf("[WATCH_FIRE] #%d: %s at instr #%llu (%s)\n",
                       i, desc, instr_count, we.label[0] ? we.label : "?");
            tty_printf("  PC=0x%08X $a0=0x%08X $a1=0x%08X $ra=0x%08X\n",
                       cpu.pc, cpu.get_reg(4), cpu.get_reg(5), cpu.get_reg(31));
        }
        if (we.action & WATCH_ACTION_SNAPSHOT) {
            take_snapshot(cpu, mem, we, instr_count, desc);
        }
        if (we.action & WATCH_ACTION_TRIAGE) {
            write_triage_log(cpu, mem);
        }
        if (we.action & WATCH_ACTION_JSON) {
            write_json(cpu, mem, PASS_RUNNING);
        }
        if (we.action & WATCH_ACTION_BREAK) {
            m_frozen = true;
        }
    }
}

void AgentHarness::check_watch_vfs_fail(const char* resource_id, MIPS_CPU& cpu,
                                         PSX_Memory& mem, uint64_t instr_count) {
    for (int i = 0; i < m_watch_event_count; i++) {
        WatchEvent& we = m_watch_events[i];
        if (!we.active || we.type != WATCH_VFS_FAIL) continue;

        we.fired = true;
        we.fire_count++;
        we.last_fire_instr = instr_count;

        char desc[128];
        snprintf(desc, sizeof(desc), "VFS fail: %s", resource_id ? resource_id : "?");

        if (we.action & WATCH_ACTION_LOG) {
            tty_printf("[WATCH_FIRE] #%d: %s at instr #%llu (%s)\n",
                       i, desc, instr_count, we.label[0] ? we.label : "?");
        }
        if (we.action & WATCH_ACTION_SNAPSHOT) {
            take_snapshot(cpu, mem, we, instr_count, desc);
        }
        if (we.action & WATCH_ACTION_TRIAGE) {
            write_triage_log(cpu, mem);
        }
        if (we.action & WATCH_ACTION_JSON) {
            write_json(cpu, mem, PASS_RUNNING);
        }
        if (we.action & WATCH_ACTION_BREAK) {
            m_frozen = true;
        }
    }
}

void AgentHarness::check_watch_int_break(uint32_t istat, uint32_t imask,
                                          bool event_delivered, MIPS_CPU& cpu,
                                          PSX_Memory& mem, uint64_t instr_count) {
    // Only fire if there are pending interrupts but no event was delivered
    if (!event_delivered || (istat & imask) == 0) return;

    for (int i = 0; i < m_watch_event_count; i++) {
        WatchEvent& we = m_watch_events[i];
        if (!we.active || we.type != WATCH_INT_BREAK) continue;

        we.fired = true;
        we.fire_count++;
        we.last_fire_instr = instr_count;

        char desc[128];
        snprintf(desc, sizeof(desc), "INT chain break: I_STAT=0x%08X I_MASK=0x%08X",
                 istat, imask);

        if (we.action & WATCH_ACTION_LOG) {
            tty_printf("[WATCH_FIRE] #%d: %s at instr #%llu (%s)\n",
                       i, desc, instr_count, we.label[0] ? we.label : "?");
            tty_printf("  PC=0x%08X SR=0x%08X EPC=0x%08X Cause=0x%08X\n",
                       cpu.pc, cpu.cp0_status, cpu.cp0_epc, cpu.cp0_cause);
        }
        if (we.action & WATCH_ACTION_SNAPSHOT) {
            take_snapshot(cpu, mem, we, instr_count, desc);
        }
        if (we.action & WATCH_ACTION_TRIAGE) {
            write_triage_log(cpu, mem);
        }
        if (we.action & WATCH_ACTION_JSON) {
            write_json(cpu, mem, PASS_RUNNING);
        }
        if (we.action & WATCH_ACTION_BREAK) {
            m_frozen = true;
        }
    }
}

int AgentHarness::load_watch_events(const char* json_path) {
    // Simple JSON parser for watch-event definitions
    FILE* f = fopen(json_path, "r");
    if (!f) return -1;

    char buf[16384];
    size_t len = fread(buf, 1, sizeof(buf) - 1, f);
    fclose(f);
    buf[len] = 0;

    // Parse simple JSON array of watch-event objects
    // Expected format: {"type":"bios_call","table":"B","fn":91,"action":"all","label":"..."}
    int count = 0;
    char* p = buf;
    while (*p) {
        // Find "type"
        char* type_pos = strstr(p, "\"type\"");
        if (!type_pos) break;
        type_pos += 7;
        while (*type_pos && *type_pos != '"') type_pos++;
        if (*type_pos != '"') break;
        type_pos++;
        char type_str[32] = {};
        int ti = 0;
        while (*type_pos && *type_pos != '"' && ti < 31) type_str[ti++] = *type_pos++;

        // Find "table"
        char table_ch = 'B';
        char* tbl_pos = strstr(type_pos, "\"table\"");
        if (tbl_pos) {
            tbl_pos += 7;
            while (*tbl_pos && *tbl_pos != '"') tbl_pos++;
            if (*tbl_pos == '"') { tbl_pos++; table_ch = *tbl_pos; }
        }

        // Find "fn"
        uint8_t fn_val = 0;
        char* fn_pos = strstr(type_pos, "\"fn\"");
        if (fn_pos) {
            fn_pos += 4;
            while (*fn_pos && (*fn_pos < '0' || *fn_pos > '9') && *fn_pos != '-') fn_pos++;
            fn_val = (uint8_t)atoi(fn_pos);
        }

        // Find "action"
        WatchEventAction action_val = WATCH_ACTION_ALL;
        char* act_pos = strstr(type_pos, "\"action\"");
        if (act_pos) {
            act_pos += 8;
            while (*act_pos && *act_pos != '"') act_pos++;
            if (*act_pos == '"') {
                act_pos++;
                if (strncmp(act_pos, "log", 3) == 0) action_val = WATCH_ACTION_LOG;
                else if (strncmp(act_pos, "snapshot", 8) == 0) action_val = WATCH_ACTION_SNAPSHOT;
                else if (strncmp(act_pos, "triage", 6) == 0) action_val = WATCH_ACTION_TRIAGE;
                else if (strncmp(act_pos, "break", 5) == 0) action_val = WATCH_ACTION_BREAK;
                else action_val = WATCH_ACTION_ALL;
            }
        }

        // Find "label"
        char label[64] = {};
        char* lbl_pos = strstr(type_pos, "\"label\"");
        if (lbl_pos) {
            lbl_pos += 7;
            while (*lbl_pos && *lbl_pos != '"') lbl_pos++;
            if (*lbl_pos == '"') {
                lbl_pos++;
                int li = 0;
                while (*lbl_pos && *lbl_pos != '"' && li < 63) label[li++] = *lbl_pos++;
            }
        }

        // Register based on type
        if (strcmp(type_str, "bios_call") == 0) {
            add_watch_bios_call(table_ch, fn_val, action_val, label);
        } else if (strcmp(type_str, "bios_return") == 0) {
            uint32_t expected = 0;
            char* exp_pos = strstr(type_pos, "\"expected\"");
            if (exp_pos) {
                exp_pos += 10;
                expected = (uint32_t)strtoul(exp_pos, nullptr, 0);
            }
            bool match = true;
            char* m_pos = strstr(type_pos, "\"matches\"");
            if (m_pos) { m_pos += 9; match = (*m_pos == 't' || *m_pos == '1'); }
            add_watch_bios_return(table_ch, fn_val, expected, match, action_val, label);
        } else if (strcmp(type_str, "pc") == 0) {
            uint32_t pc = 0;
            char* pc_pos = strstr(type_pos, "\"pc\"");
            if (pc_pos) { pc_pos += 4; pc = (uint32_t)strtoul(pc_pos, nullptr, 0); }
            add_watch_pc(pc, action_val, label);
        } else if (strcmp(type_str, "cdrom_error") == 0) {
            add_watch_cdrom_error(action_val, label);
        } else if (strcmp(type_str, "vfs_fail") == 0) {
            add_watch_vfs_fail(action_val, label);
        } else if (strcmp(type_str, "int_break") == 0) {
            add_watch_int_break(action_val, label);
        }

        count++;
        p = type_pos;
        // Advance past this object
        char* next = strstr(p, "}");
        if (next) p = next + 1; else break;
    }

    tty_printf("[WATCH] Loaded %d watch-events from %s\n", count, json_path);
    return count;
}

int AgentHarness::active_watch_events() const {
    int count = 0;
    for (int i = 0; i < m_watch_event_count; i++)
        if (m_watch_events[i].active && !m_watch_events[i].fired) count++;
    return count;
}

int AgentHarness::fired_watch_events() const {
    int count = 0;
    for (int i = 0; i < m_watch_event_count; i++)
        if (m_watch_events[i].fired) count++;
    return count;
}

void AgentHarness::dump_watch_events() {
    tty_printf("[WATCH] Status: %d active, %d fired, %d total\n",
               active_watch_events(), fired_watch_events(), m_watch_event_count);
    for (int i = 0; i < m_watch_event_count; i++) {
        WatchEvent& we = m_watch_events[i];
        tty_printf("  #%d type=%d %s fires=%llu last=%llu (%s)\n",
                   i, (int)we.type,
                   we.fired ? "FIRED" : (we.active ? "ACTIVE" : "INACTIVE"),
                   we.fire_count, we.last_fire_instr,
                   we.label[0] ? we.label : "?");
    }
}

int AgentHarness::get_snapshot_count() const { return m_snapshot_count; }
const DiagnosticSnapshot* AgentHarness::get_snapshots() const { return m_snapshots; }

// ═══════════════════════════════════════════════════════════════════════════════
// Phase 11: Interactive Console
// ═══════════════════════════════════════════════════════════════════════════════

static void console_print_threadsafe(const char* fmt, ...) {
    va_list args;
    va_start(args, fmt);
    vfprintf(stderr, fmt, args);
    va_end(args);
}

static std::vector<std::string> split_args(const std::string& s) {
    std::vector<std::string> out;
    std::string cur;
    bool in_quotes = false;
    for (char c : s) {
        if (c == '"') {
            in_quotes = !in_quotes;
        } else if ((c == ' ' || c == '\t') && !in_quotes) {
            if (!cur.empty()) { out.push_back(cur); cur.clear(); }
        } else {
            cur.push_back(c);
        }
    }
    if (!cur.empty()) out.push_back(cur);
    return out;
}

static void console_reader_thread(AgentHarness* harness) {
    console_print_threadsafe("[CONSOLE] Interactive console active. Commands: b/reak, m/em, r/egs, pc, w/rite, p/ause, c/ontinue, s/tep, q/uit\n");
    console_print_threadsafe("> ");
    fflush(stderr);
    std::string line;
    char buf[256];
    while (harness->is_console_running()) {
        if (!fgets(buf, sizeof(buf), stdin)) {
            Sleep(50);
            continue;
        }
        line = buf;
        if (!line.empty() && line.back() == '\n') line.pop_back();
        if (!line.empty() && line.back() == '\r') line.pop_back();
        if (line.empty()) {
            console_print_threadsafe("> ");
            fflush(stderr);
            continue;
        }
        auto args = split_args(line);
        if (args.empty()) {
            console_print_threadsafe("> ");
            fflush(stderr);
            continue;
        }
        std::vector<std::string> cc_args;
        for (size_t i = 1; i < args.size(); i++) cc_args.push_back(args[i]);
        harness->enqueue_console_command(args[0], cc_args);
        console_print_threadsafe("[CONSOLE] queued: %s\n", args[0].c_str());
        console_print_threadsafe("> ");
        fflush(stderr);
    }
}

void AgentHarness::enable_console(bool enabled) {
    if (enabled && !m_console_enabled) {
        m_console_enabled = true;
        m_console_running = true;
        m_console_thread = new std::thread(console_reader_thread, this);
    } else if (!enabled && m_console_enabled) {
        m_console_running = false;
        if (m_console_thread) {
            m_console_thread->join();
            delete m_console_thread;
            m_console_thread = nullptr;
        }
        m_console_enabled = false;
    }
}

bool AgentHarness::process_console(MIPS_CPU& cpu, PSX_Memory& mem) {
    // Auto-pause on console breakpoint
    if (m_console_breakpoint_set && cpu.pc == m_console_breakpoint) {
        console_print_threadsafe("[CONSOLE] Breakpoint hit at 0x%08X (instr #%llu)\n",
                                  cpu.pc, (unsigned long long)cpu.instructions);
        m_paused = true;
    }

    std::queue<ConsoleCommand> local;
    {
        std::lock_guard<std::mutex> lock(m_console_mutex);
        local.swap(m_console_queue);
    }
    while (!local.empty()) {
        ConsoleCommand& cc = local.front();
        const std::string& cmd = cc.cmd;
        console_print_threadsafe("[CONSOLE] exec: %s\n", cmd.c_str());

        if (cmd == "b" || cmd == "break") {
            if (cc.args.size() >= 1) {
                uint32_t addr = 0;
                if (!resolve_symbol(cc.args[0].c_str(), &addr))
                    addr = (uint32_t)strtoull(cc.args[0].c_str(), nullptr, 0);
                set_console_breakpoint(addr);
                console_print_threadsafe("[CONSOLE] Breakpoint set at 0x%08X (%s)\n", addr, cc.args[0].c_str());
            }
        } else if (cmd == "m" || cmd == "mem") {
            if (cc.args.size() >= 1) {
                uint32_t addr = 0;
                if (!resolve_symbol(cc.args[0].c_str(), &addr))
                    addr = (uint32_t)strtoull(cc.args[0].c_str(), nullptr, 0);
                int len = (cc.args.size() >= 2) ? (int)strtol(cc.args[1].c_str(), nullptr, 0) : 32;
                console_print_threadsafe("[CONSOLE] MEM 0x%08X (%d bytes):\n", addr, len);
                for (int i = 0; i < len; i += 16) {
                    console_print_threadsafe("  0x%08X: ", addr + i);
                    for (int j = 0; j < 16 && i + j < len; j++)
                        console_print_threadsafe("%02X ", mem.read8(addr + i + j));
                    console_print_threadsafe("\n");
                }
            }
        } else if (cmd == "r" || cmd == "regs") {
            console_print_threadsafe("[CONSOLE] Registers:\n");
            console_print_threadsafe("  PC=0x%08X\n", cpu.pc);
            for (int i = 0; i < 32; i++) {
                console_print_threadsafe("  $%02d = 0x%08X\n", i, cpu.get_reg(i));
            }
            console_print_threadsafe("  HI=0x%08X LO=0x%08X\n", cpu.hi, cpu.lo);
        } else if (cmd == "pc") {
            if (cc.args.size() >= 1) {
                uint32_t addr = 0;
                if (!resolve_symbol(cc.args[0].c_str(), &addr))
                    addr = (uint32_t)strtoull(cc.args[0].c_str(), nullptr, 0);
                cpu.pc = addr;
                cpu.next_pc = addr + 4;
                console_print_threadsafe("[CONSOLE] PC set to 0x%08X (%s)\n", addr, cc.args[0].c_str());
            }
        } else if (cmd == "w" || cmd == "write") {
            if (cc.args.size() >= 2) {
                uint32_t addr = 0;
                if (!resolve_symbol(cc.args[0].c_str(), &addr))
                    addr = (uint32_t)strtoull(cc.args[0].c_str(), nullptr, 0);
                uint32_t val = (uint32_t)strtoull(cc.args[1].c_str(), nullptr, 0);
                mem.write32(addr, val);
                console_print_threadsafe("[CONSOLE] Wrote 0x%08X to 0x%08X (%s)\n", val, addr, cc.args[0].c_str());
            }
        } else if (cmd == "p" || cmd == "pause") {
            m_paused = true;
            console_print_threadsafe("[CONSOLE] Paused. Use 'c' to continue or 's' to step.\n");
        } else if (cmd == "c" || cmd == "continue") {
            m_paused = false;
            console_print_threadsafe("[CONSOLE] Continuing.\n");
        } else if (cmd == "s" || cmd == "step") {
            m_step_requests++;
            m_paused = false;
            console_print_threadsafe("[CONSOLE] Stepping 1 instruction.\n");
        } else if (cmd == "q" || cmd == "quit") {
            console_print_threadsafe("[CONSOLE] Quit requested.\n");
            return false;
        } else {
            console_print_threadsafe("[CONSOLE] Unknown command: %s\n", cmd.c_str());
        }
        local.pop();
    }
    return true;
}

bool AgentHarness::is_paused() const {
    return m_paused.load();
}

void AgentHarness::console_pause() {
    m_paused = true;
}

bool AgentHarness::consume_step() {
    int expected = m_step_requests.load();
    while (expected > 0 && !m_step_requests.compare_exchange_weak(expected, expected - 1)) {
        expected = m_step_requests.load();
    }
    return expected > 0;
}

void AgentHarness::set_console_breakpoint(uint32_t addr) {
    m_console_breakpoint = addr;
    m_console_breakpoint_set = true;
}

void AgentHarness::clear_console_breakpoint() {
    m_console_breakpoint_set = false;
}

void AgentHarness::enqueue_console_command(const std::string& cmd, const std::vector<std::string>& args) {
    ConsoleCommand cc;
    cc.cmd = cmd;
    cc.args = args;
    std::lock_guard<std::mutex> lock(m_console_mutex);
    m_console_queue.push(cc);
}

bool AgentHarness::is_console_running() const {
    return m_console_running.load();
}
