-- Lua automation script — press X at title screen to start game
-- Usage: psx_agent_runner.exe disc.bin lua_test telemetry.json 600000 --lua examples/autoplay.lua

local vblank_count = 0
local pressed = false

function on_vblank(instr_count)
    vblank_count = vblank_count + 1
    
    -- Wait for title screen (typically ~200 vblanks)
    if vblank_count == 200 and not pressed then
        log("Title screen reached — pressing X")
        press_button()
        pressed = true
    end
    
    -- Release after 10 vblanks
    if vblank_count == 210 and pressed then
        log("Releasing X")
        release_button()
    end
    
    -- Log every 500 vblanks
    if vblank_count % 500 == 0 then
        log(string.format("VBlank #%d at instr %d PC=0x%08X", 
            vblank_count, instr_count, get_pc()))
    end
end

function on_bios(table, fn, a0, a1)
    -- Log CD-ROM reads
    if table == 66 and fn == 75 then  -- 'B' = 66, CdRead = 0x4B = 75
        log(string.format("CdRead: sectors=%d buf=0x%08X", a0, a1))
    end
end

log("Autoplay script loaded — waiting for title screen")
