#!/usr/bin/env python3
"""
Comprehensive search: find ALL occurrences of BCD 32:34:71 and LBA 146621
in the disc EXE, clean EXE, and HBD data. Patch every occurrence.
"""
import struct, os

disc_path = r"C:\LuxAura\VoidWalkers_Project\DQLOSTTRANSLATION\build_staging\dq4_gold.bin"
clean_exe_path = r"C:\LuxAura\VoidWalkers_Project\DQLOSTTRANSLATION\translation\SLUSP012.06_clean.bin"
SECTOR_SIZE = 2352
USER_SIZE = 2048
EXE_LBA = 24
HEADER = 24
LOAD_ADDR = 0x80017F00

with open(disc_path, "rb") as f:
    disc = f.read()
with open(clean_exe_path, "rb") as f:
    clean = f.read()

def read_exe_from_disc(disc, start_lba, exe_size):
    exe = bytearray()
    sectors_needed = (exe_size + USER_SIZE - 1) // USER_SIZE
    for i in range(sectors_needed):
        sec_start = (start_lba + i) * SECTOR_SIZE + HEADER
        chunk = disc[sec_start:sec_start + USER_SIZE]
        exe.extend(chunk)
    return bytes(exe[:exe_size])

disc_exe = read_exe_from_disc(disc, EXE_LBA, 677888)

# 1. Search for BCD 32:34:71 as 3-byte sequence in both EXEs
print("=== ALL occurrences of 32 34 71 in clean EXE ===")
idx = 0
clean_hits = []
while True:
    idx = clean.find(b'\x32\x34\x71', idx)
    if idx == -1: break
    ram = idx + LOAD_ADDR
    ctx = clean[max(0,idx-8):idx+16].hex()
    print(f"  offset 0x{idx:06X} (RAM 0x{ram:08X}): ...{ctx}...")
    clean_hits.append(idx)
    idx += 1

print(f"\n=== ALL occurrences of 32 34 71 in disc EXE ===")
idx = 0
disc_hits = []
while True:
    idx = disc_exe.find(b'\x32\x34\x71', idx)
    if idx == -1: break
    ram = idx + LOAD_ADDR
    ctx = disc_exe[max(0,idx-8):idx+16].hex()
    print(f"  offset 0x{idx:06X} (RAM 0x{ram:08X}): ...{ctx}...")
    disc_hits.append(idx)
    idx += 1

# 2. Search for LBA 146621 as LE32 and BE32
lba = 146621
le32 = struct.pack("<I", lba)
be32 = struct.pack(">I", lba)
print(f"\n=== LBA 146621 as LE32 ({le32.hex()}) in clean EXE ===")
idx = 0
while True:
    idx = clean.find(le32, idx)
    if idx == -1: break
    ram = idx + LOAD_ADDR
    print(f"  offset 0x{idx:06X} (RAM 0x{ram:08X})")
    idx += 1

print(f"\n=== LBA 146621 as LE32 ({le32.hex()}) in disc EXE ===")
idx = 0
while True:
    idx = disc_exe.find(le32, idx)
    if idx == -1: break
    ram = idx + LOAD_ADDR
    print(f"  offset 0x{idx:06X} (RAM 0x{ram:08X})")
    idx += 1

# 3. Search for BCD minute 0x32 as MIPS immediate (addiu $reg, $zero, 0x32 = 0x24020032 or 0x240X0032)
# Pattern: any addiu with imm=0x32
print(f"\n=== addiu $reg, $zero, 0x32 (BCD minute 32) in disc EXE ===")
for i in range(0, len(disc_exe) - 4, 4):
    word = struct.unpack("<I", disc_exe[i:i+4])[0]
    op = (word >> 26) & 0x3F
    imm = word & 0xFFFF
    if op == 0x09 and imm == 0x32:  # addiu with imm=0x32
        rs = (word >> 21) & 0x1F
        rt = (word >> 16) & 0x1F
        if rs == 0:  # addiu $reg, $zero, 0x32
            ram = i + LOAD_ADDR
            # Show surrounding instructions
            print(f"  0x{ram:08X}: addiu $r{rt}, $zero, 0x32")
            # Show 3 instructions before and after
            for j in range(-12, 16, 4):
                off = i + j
                if 0 <= off < len(disc_exe) - 4:
                    w = struct.unpack("<I", disc_exe[off:off+4])[0]
                    r = off + LOAD_ADDR
                    print(f"    0x{r:08X}: {w:08X}")

# 4. Search for BCD as individual sb/store operations
# The game might store BCD values one byte at a time
# Look for: addiu $reg, $zero, 0x32 followed by sb $reg, offset($base)
print(f"\n=== addiu $reg, $zero, 0x32 followed by sb within 8 instructions ===")
for i in range(0, len(disc_exe) - 32, 4):
    word = struct.unpack("<I", disc_exe[i:i+4])[0]
    op = (word >> 26) & 0x3F
    imm = word & 0xFFFF
    rs = (word >> 21) & 0x1F
    rt = (word >> 16) & 0x1F
    if op == 0x09 and imm == 0x32 and rs == 0:
        # Look ahead for sb with same register
        for j in range(4, 36, 4):
            if i + j + 4 > len(disc_exe): break
            w2 = struct.unpack("<I", disc_exe[i+j:i+j+4])[0]
            op2 = (w2 >> 26) & 0x3F
            rt2 = (w2 >> 16) & 0x1F
            if op2 == 0x28 and rt2 == rt:  # sb
                ram = i + LOAD_ADDR
                ram2 = (i+j) + LOAD_ADDR
                print(f"  0x{ram:08X}: addiu $r{rt}, $zero, 0x32 -> 0x{ram2:08X}: sb $r{rt}, ...")

# 5. Also search for 0x34 and 0x71 as addiu immediates near each other
print(f"\n=== addiu $reg, $zero, 0x34 and 0x71 within 16 instructions of each other ===")
hits_34 = []
hits_71 = []
for i in range(0, len(disc_exe) - 4, 4):
    word = struct.unpack("<I", disc_exe[i:i+4])[0]
    op = (word >> 26) & 0x3F
    imm = word & 0xFFFF
    rs = (word >> 21) & 0x1F
    if op == 0x09 and rs == 0:
        if imm == 0x34:
            hits_34.append(i)
        if imm == 0x71:
            hits_71.append(i)

for h34 in hits_34:
    for h71 in hits_71:
        if abs(h34 - h71) <= 64:  # within 16 instructions
            ram34 = h34 + LOAD_ADDR
            ram71 = h71 + LOAD_ADDR
            print(f"  0x{ram34:08X}: addiu ..., 0x34  and  0x{ram71:08X}: addiu ..., 0x71  (delta={h71-h34})")

# 6. Search the HBD data on disc for 32 34 71
print(f"\n=== BCD 32 34 71 in HBD area (sectors 355-400) ===")
for sec in range(355, 410):
    sec_start = sec * SECTOR_SIZE + HEADER
    sec_data = disc[sec_start:sec_start + USER_SIZE]
    idx = sec_data.find(b'\x32\x34\x71')
    if idx != -1:
        print(f"  Sector {sec}, offset {idx}: found 32 34 71")

# 7. Search entire disc user data for 32 34 71 (first 2000 sectors)
print(f"\n=== BCD 32 34 71 in first 2000 disc sectors ===")
for sec in range(0, 2000):
    sec_start = sec * SECTOR_SIZE + HEADER
    sec_data = disc[sec_start:sec_start + USER_SIZE]
    idx = sec_data.find(b'\x32\x34\x71')
    if idx != -1:
        print(f"  Sector {sec}, offset {idx}: found 32 34 71  ctx: {sec_data[max(0,idx-4):idx+8].hex()}")

print("\n=== DONE ===")
