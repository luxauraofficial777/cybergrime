#!/usr/bin/env python3
"""Check actual jump target of patch 7 and what's there."""
import struct

EXE_PATH = r"C:\LuxAura\VoidWalkers_Project\DQLOSTTRANSLATION\translation\SLUSP012.06_clean.bin"
LOAD_ADDR = 0x80017F00
EXE_HEADER = 0x800

with open(EXE_PATH, "rb") as f:
    exe = f.read()

# Patch 7 value: 0x08022BE9
patch_val = 0x08022BE9
opcode = (patch_val >> 26) & 0x3F
target_field = patch_val & 0x3FFFFFF
# PC at patch site = 0x8008A78C
pc = 0x8008A78C
actual_target = (pc & 0xF0000000) | (target_field << 2)

print(f"Patch 7 value: 0x{patch_val:08X}")
print(f"Opcode: 0x{opcode:02X} (J)")
print(f"Target field: 0x{target_field:07X}")
print(f"PC at patch site: 0x{pc:08X}")
print(f"Actual jump target: 0x{actual_target:08X}")
print(f"Comment says: 0x800A2BE8")
print(f"MISMATCH: {actual_target != 0x800A2BE8}")
print()

# Check what's at the actual target
actual_off = actual_target - LOAD_ADDR + EXE_HEADER
print(f"File offset for actual target: 0x{actual_off:X}")
if 0 <= actual_off < len(exe) - 40:
    REG_NAMES = ["zero","at","v0","v1","a0","a1","a2","a3",
                 "t0","t1","t2","t3","t4","t5","t6","t7",
                 "s0","s1","s2","s3","s4","s5","s6","s7",
                 "t8","t9","k0","k1","gp","sp","fp","ra"]
    print(f"Code at actual target (0x{actual_target:08X}):")
    for i in range(20):
        off = actual_off + i * 4
        if off + 4 > len(exe):
            break
        val = struct.unpack_from("<I", exe, off)[0]
        ram = actual_target + i * 4
        # Simple disasm
        if val == 0:
            d = "nop"
        else:
            op = (val >> 26) & 0x3F
            if op == 0x0F:
                rt = (val >> 16) & 0x1F
                imm = val & 0xFFFF
                d = f"lui ${REG_NAMES[rt]}, 0x{imm:04X}"
            elif op == 0x09:
                rt = (val >> 16) & 0x1F
                rs = (val >> 21) & 0x1F
                imm = val & 0xFFFF
                simm = imm if imm < 0x8000 else imm - 0x10000
                d = f"addiu ${REG_NAMES[rt]}, ${REG_NAMES[rs]}, {simm}"
            elif op == 0x23:
                rt = (val >> 16) & 0x1F
                rs = (val >> 21) & 0x1F
                imm = val & 0xFFFF
                simm = imm if imm < 0x8000 else imm - 0x10000
                d = f"lw ${REG_NAMES[rt]}, {simm}(${REG_NAMES[rs]})"
            elif op == 0x2B:
                rt = (val >> 16) & 0x1F
                rs = (val >> 21) & 0x1F
                imm = val & 0xFFFF
                simm = imm if imm < 0x8000 else imm - 0x10000
                d = f"sw ${REG_NAMES[rt]}, {simm}(${REG_NAMES[rs]})"
            elif op == 0x02:
                tgt = (val & 0x3FFFFFF) << 2
                d = f"j 0x{(pc & 0xF0000000) | tgt:08X}"
            elif op == 0x03:
                tgt = (val & 0x3FFFFFF) << 2
                d = f"jal 0x{(pc & 0xF0000000) | tgt:08X}"
            elif op == 0x00:
                funct = val & 0x3F
                rs = (val >> 21) & 0x1F
                if funct == 0x08:
                    d = f"jr ${REG_NAMES[rs]}"
                elif funct == 0x21:
                    rd = (val >> 11) & 0x1F
                    rt = (val >> 16) & 0x1F
                    d = f"addu ${REG_NAMES[rd]}, ${REG_NAMES[rs]}, ${REG_NAMES[rt]}"
                else:
                    d = f"R-type funct=0x{funct:02X}"
            elif op == 0x04:
                rs = (val >> 21) & 0x1F
                rt = (val >> 16) & 0x1F
                imm = val & 0xFFFF
                simm = imm if imm < 0x8000 else imm - 0x10000
                tgt = ram + 4 + simm * 4
                d = f"beq ${REG_NAMES[rs]}, ${REG_NAMES[rt]}, 0x{tgt:08X}"
            elif op == 0x05:
                rs = (val >> 21) & 0x1F
                rt = (val >> 16) & 0x1F
                imm = val & 0xFFFF
                simm = imm if imm < 0x8000 else imm - 0x10000
                tgt = ram + 4 + simm * 4
                d = f"bne ${REG_NAMES[rs]}, ${REG_NAMES[rt]}, 0x{tgt:08X}"
            else:
                d = f"op=0x{op:02X} raw=0x{val:08X}"
        print(f"  0x{off:05X} (RAM 0x{ram:08X}): 0x{val:08X}  {d}")

# Also check: what does the function at 0x8004FE44 actually do?
# Search for references to 0x800F0EF0 (the counter it reads)
print(f"\n=== Searching for references to 0x800F0EF0 ===")
target_bytes = struct.pack("<I", 0x800F0EF0)
for off in range(EXE_HEADER, len(exe) - 4, 4):
    val = struct.unpack_from("<I", exe, off)[0]
    if val == 0x800F0EF0:
        ram = LOAD_ADDR + off - EXE_HEADER
        print(f"  Found at 0x{off:X} (RAM 0x{ram:08X})")

# Search for lui 0x800F + addiu 0x0EF0 pattern
print(f"\n=== Searching for lui $*, 0x800F near addiu 0x0EF0 ===")
for off in range(EXE_HEADER, len(exe) - 8, 4):
    val = struct.unpack_from("<I", exe, off)[0]
    op = (val >> 26) & 0x3F
    if op == 0x0F:  # lui
        imm = val & 0xFFFF
        if imm == 0x800F:
            # Check next instruction for addiu with 0x0EF0
            next_val = struct.unpack_from("<I", exe, off + 4)[0]
            next_op = (next_val >> 26) & 0x3F
            if next_op == 0x09:  # addiu
                next_imm = next_val & 0xFFFF
                if next_imm == 0x0EF0:
                    ram = LOAD_ADDR + off - EXE_HEADER
                    rt = (val >> 16) & 0x1F
                    print(f"  lui ${REG_NAMES[rt]}, 0x800F + addiu 0x{next_imm:04X} at 0x{off:X} (RAM 0x{ram:08X})")

# Check what 0x8009F2A8 and 0x8009EFF8 are (the JAL targets in the handler)
print(f"\n=== Functions called by handler at 0x8004FE44 ===")
for target_name, target_ram in [("0x8009F2A8", 0x8009F2A8), ("0x8009EFF8", 0x8009EFF8)]:
    target_off = target_ram - LOAD_ADDR + EXE_HEADER
    print(f"\n  {target_name} (file offset 0x{target_off:X}):")
    for i in range(10):
        off = target_off + i * 4
        if off + 4 > len(exe):
            break
        val = struct.unpack_from("<I", exe, off)[0]
        ram = target_ram + i * 4
        if val == 0:
            d = "nop"
        else:
            op = (val >> 26) & 0x3F
            if op == 0x0F:
                rt = (val >> 16) & 0x1F
                imm = val & 0xFFFF
                d = f"lui ${REG_NAMES[rt]}, 0x{imm:04X}"
            elif op == 0x09:
                rt = (val >> 16) & 0x1F
                rs = (val >> 21) & 0x1F
                imm = val & 0xFFFF
                simm = imm if imm < 0x8000 else imm - 0x10000
                d = f"addiu ${REG_NAMES[rt]}, ${REG_NAMES[rs]}, {simm}"
            elif op == 0x23:
                rt = (val >> 16) & 0x1F
                rs = (val >> 21) & 0x1F
                imm = val & 0xFFFF
                simm = imm if imm < 0x8000 else imm - 0x10000
                d = f"lw ${REG_NAMES[rt]}, {simm}(${REG_NAMES[rs]})"
            elif op == 0x2B:
                rt = (val >> 16) & 0x1F
                rs = (val >> 21) & 0x1F
                imm = val & 0xFFFF
                simm = imm if imm < 0x8000 else imm - 0x10000
                d = f"sw ${REG_NAMES[rt]}, {simm}(${REG_NAMES[rs]})"
            elif op == 0x03:
                tgt = (val & 0x3FFFFFF) << 2
                d = f"jal 0x{(ram & 0xF0000000) | tgt:08X}"
            elif op == 0x00:
                funct = val & 0x3F
                rs = (val >> 21) & 0x1F
                if funct == 0x08:
                    d = f"jr ${REG_NAMES[rs]}"
                elif funct == 0x21:
                    rd = (val >> 11) & 0x1F
                    rt = (val >> 16) & 0x1F
                    d = f"addu ${REG_NAMES[rd]}, ${REG_NAMES[rs]}, ${REG_NAMES[rt]}"
                else:
                    d = f"R-type funct=0x{funct:02X}"
            else:
                d = f"op=0x{op:02X} raw=0x{val:08X}"
        print(f"    0x{off:05X} (RAM 0x{ram:08X}): 0x{val:08X}  {d}")
