#pragma once

// ============================================================================
// AGENT TESTING HARNESS — PSX ISO Regression Analysis
// ============================================================================
// Supervisor environment for automated ROM build testing.
// Provides:
//   1. TTY console interception (captures all stdout/stderr)
//   2. VFS / file-system resolution logging
//   3. Freeze / black-screen detection with full register dump
//   4. Agent-readable JSON telemetry output
//
// Designed for batch-compile pipeline integration. No Python wrappers.
// All output is deterministic and machine-parseable.
// ============================================================================

#include <winsock2.h>
#include <windows.h>
#include <cstdint>
#include <cstdio>
#include <cstring>
#include <ctime>
#include <thread>
#include <mutex>
#include <queue>
#include <atomic>
#include <string>
#include <vector>
#include <unordered_map>

// Forward declarations from existing emulator
class PSX_Memory;
class MIPS_CPU;

// ── Constants ────────────────────────────────────────────────────────────────
#define HARNESS_TTY_BUF_SIZE    (1024 * 1024)   // 1MB TTY capture buffer
#define HARNESS_VFS_MAX         512             // Max VFS access entries
#define HARNESS_ERROR_MAX       128             // Max error entries
#define HARNESS_TTY_TAIL_SIZE   65536           // Last 64KB of TTY on termination
#define HARNESS_FREEZE_THRESHOLD_DEFAULT  50000000  // ~50M instrs with no PC change ≈ 5s real time
#define HARNESS_RESOURCE_ID_LEN 64
#define HARNESS_ERROR_SIG_LEN   256
#define HARNESS_PROFILE_LEN     64
#define HARNESS_PATH_LEN        512

// ── Assertion State (QA-Master) ──────────────────────────────────────────────
enum AssertSeverity {
    ASSERT_INFO    = 0,  // Informational checkpoint
    ASSERT_WARN    = 1,  // Warning — unexpected but non-fatal
    ASSERT_FAIL    = 2,  // Hard failure — test should abort
    ASSERT_PARITY  = 3   // Memory/register parity mismatch
};

struct AssertRecord {
    char     name[64];                           // Assertion name (e.g. "HBD_LBA_MATCH")
    AssertSeverity severity;                     // Severity level
    char     detail[256];                        // Human-readable detail
    uint32_t pc;                                 // PC at assertion time
    uint64_t instr_count;                        // Instruction count
    uint32_t expected;                           // Expected value (if applicable)
    uint32_t actual;                             // Actual value (if applicable)
    bool     fired;                              // Has this assertion been recorded?
};

// ── Phase 1: Loop Freeze Detection Constants ─────────────────────────────────
#define HARNESS_PC_HISTORY_SIZE   256   // Ring buffer of recent PCs
#define HARNESS_LOOP_UNIQUE_MAX   16    // If <16 unique PCs in history, it's a loop
#define HARNESS_LOOP_INSTR_THRESH 200000000  // 200M instrs in same PC set = frozen
#define HARNESS_VBLANK_STALL_THRESH 20000000  // 20M instrs without VBlank = stalled
#define HARNESS_BIOS_LOG_MAX      512   // Last 512 BIOS calls for triage
#define HARNESS_LOOP_BODY_MAX     32    // Max unique PCs to dump in triage
#define HARNESS_ASSERT_MAX        64    // Max assertion records

// ── VFS Access Record ────────────────────────────────────────────────────────
struct VfsAccessRecord {
    char     resource_id[HARNESS_RESOURCE_ID_LEN]; // file path, "HBD:sector:NNNN", or "cdrom:FILE.EXT"
    uint32_t lba;                                   // requested LBA (0 if N/A)
    uint32_t size;                                  // requested size in bytes
    bool     resolved;                              // true = found in ISO dir / readable
    uint32_t calling_pc;                            // PC of the calling instruction
    uint64_t instr_count;                           // instruction count at access time
    char     error[128];                            // error string if !resolved
};

// ── Error Record ─────────────────────────────────────────────────────────────
struct ErrorRecord {
    char     category[32];                          // "VFS", "CDROM", "CPU", "BIOS", "FREEZE"
    char     signature[HARNESS_ERROR_SIG_LEN];      // human-readable error description
    uint32_t pc;                                    // PC at error time
    uint64_t instr_count;                           // instruction count
};

// ── Register Snapshot ────────────────────────────────────────────────────────
struct RegisterSnapshot {
    uint32_t pc;
    uint32_t v0, v1;
    uint32_t a0, a1, a2, a3;
    uint32_t t0, t1, t2, t3, t4, t5, t6, t7;
    uint32_t s0, s1, s2, s3, s4, s5, s6, s7;
    uint32_t sp, fp, gp, ra;
    uint32_t hi, lo;
    uint32_t cp0_status, cp0_cause, cp0_epc;
};

// ── Memory Dump Record ───────────────────────────────────────────────────────
struct MemoryDumpRecord {
    uint32_t base_addr;                             // base address of dump
    uint32_t length;                                // number of bytes dumped
    uint8_t  data[256];                             // raw memory contents
};

// ── Pass Status ──────────────────────────────────────────────────────────────
enum PassStatus {
    PASS_RUNNING    = 0,
    PASS_COMPLETE   = 1,    // reached instruction limit without crash
    PASS_CRASH      = 2,    // CPU crashed (divergence, unhandled BIOS, etc.)
    PASS_FREEZE     = 3,    // PC stagnation detected (black screen)
    PASS_BOOT_FAIL  = 4,    // failed to load disc / EXE
    PASS_TIMEOUT    = 5     // wall-clock timeout exceeded
};

// ── Freeze Type (Phase 1) ─────────────────────────────────────────────────────
enum FreezeType {
    FREEZE_NONE       = 0,
    FREEZE_PC_STUCK   = 1,  // PC literally hasn't changed
    FREEZE_TIGHT_LOOP = 2,  // PC cycling through small set of addresses
    FREEZE_VBLANK_STALL = 3 // No VBlank IRQ delivered for extended period
};

// ── BIOS Call Log Entry (Phase 2) ─────────────────────────────────────────────
struct BiosCallEntry {
    char     table;           // 'A', 'B', or 'C'
    uint8_t  function;        // function number
    uint32_t ra;              // return address
    uint32_t a0, a1, a2, a3; // argument registers
    uint64_t instr_count;     // instruction count at call
};

// ── Phase 9: Live RAM State Injection ───────────────────────────────────────
#define HARNESS_INJECT_MAX    64    // Max queued injection entries

enum InjectCondition {
    INJECT_AT_INSTR   = 0,  // Fire when instruction count matches
    INJECT_AT_VBLANK  = 1,  // Fire when VBlank count matches
    INJECT_AT_PC      = 2,  // Fire when PC matches (function entry)
    INJECT_IMMEDIATE  = 3,  // Fire on next check
    INJECT_ON_FREEZE  = 4,  // Fire when freeze is detected (pre-triage)
    INJECT_ON_HW_INIT = 5,  // Fire when hardware init is detected (pad started)
    INJECT_PAD_MACRO  = 6,  // Fire a pad input sequence (button macros)
    INJECT_AT_PC_DUMP = 7   // Capture register/memory snapshot at PC, then pause
};

// Pad macro step — one button press/release at a VBlank frame
#define HARNESS_PAD_MACRO_MAX  256  // Max pad macro steps per injection entry
struct PadMacroStep {
    uint64_t vblank;     // VBlank count to fire at
    uint16_t buttons;    // Button mask (PSX digital pad bits)
    bool     press;      // true=press, false=release
    char     name[16];   // Button name for logging
};

struct RamInjection {
    uint32_t addr;            // RAM address to write
    uint32_t value;           // Value to write (for type==0 scalar injections)
    uint8_t  size;            // 1, 2, or 4 bytes (for type==0)
    InjectCondition cond;     // When to fire
    uint64_t trigger_value;   // instr count, vblank count, or PC depending on cond
    bool     fired;           // Has this injection been applied?
    char     label[64];       // Human-readable description
    uint8_t  type;            // 0 = scalar write (value/size), 1 = byte array
    uint8_t  data[256];       // Byte-array payload (for type==1)
    uint16_t data_len;        // Number of valid bytes in data[]
    // Pad macro support (used when cond == INJECT_PAD_MACRO)
    PadMacroStep pad_steps[HARNESS_PAD_MACRO_MAX];
    int      pad_step_count; // Number of pad macro steps
};

// ── Phase 11: Event-Driven Triage Hooks ──────────────────────────────────────
#define HARNESS_WATCH_EVENT_MAX  64    // Max active watch-events
#define HARNESS_SNAPSHOT_MAX     16    // Max diagnostic snapshots retained

enum WatchEventType {
    WATCH_BIOS_RETURN    = 0,  // Trigger when a BIOS call returns a specific value
    WATCH_BIOS_CALL      = 1,  // Trigger when a specific BIOS function is called
    WATCH_REG_VALUE      = 2,  // Trigger when a register matches expected value
    WATCH_PC_REACHED     = 3,  // Trigger when PC reaches a specific address
    WATCH_INT_BREAK      = 4,  // Trigger when interrupt chain is broken (I_STAT set but no event delivered)
    WATCH_CDROM_ERROR    = 5,  // Trigger on CD-ROM read failure or error return
    WATCH_VFS_FAIL       = 6,  // Trigger on VFS resolution failure
    WATCH_CUSTOM         = 7   // User-defined condition via callback
};

enum WatchEventAction {
    WATCH_ACTION_SNAPSHOT  = 0x01,  // Capture full register + memory snapshot
    WATCH_ACTION_LOG       = 0x02,  // Log to TTY with full context
    WATCH_ACTION_TRIAGE    = 0x04,  // Write immediate triage log
    WATCH_ACTION_JSON      = 0x08,  // Write JSON telemetry checkpoint
    WATCH_ACTION_BREAK     = 0x10,  // Set frozen flag to halt emulation
    WATCH_ACTION_ALL       = 0x1F   // All actions
};

struct WatchEvent {
    WatchEventType type;           // What to watch for
    WatchEventAction action;       // What to do when triggered
    char     table;                // BIOS table ('A','B','C') for BIOS watches
    uint8_t  bios_fn;              // BIOS function number for BIOS watches
    uint32_t expected_return;      // Expected return value (for BIOS_RETURN watches)
    bool     return_matches;       // true=trigger when return==expected, false=trigger when return!=expected
    uint32_t pc_target;            // PC address for PC_REACHED watches
    uint8_t  reg_index;            // Register index for REG_VALUE watches
    uint32_t reg_expected;         // Expected register value
    bool     fired;                // Has this watch-event triggered?
    bool     active;               // Is this watch-event enabled?
    char     label[64];            // Human-readable description
    uint64_t fire_count;           // How many times this has fired
    uint64_t last_fire_instr;      // Instruction count of last fire
};

struct DiagnosticSnapshot {
    RegisterSnapshot regs;
    MemoryDumpRecord mem;
    BiosCallEntry bios_context;    // BIOS call that triggered the snapshot (if any)
    uint64_t instr_count;
    uint32_t vblank_count;
    char     trigger_label[64];
    bool     valid;
};

// ── Phase 10: Buffer Monitor ─────────────────────────────────────────────────
#define HARNESS_MONITOR_MAX   32    // Max active buffer monitors

enum MonitorCondition {
    MONITOR_VALUE_CHANGE   = 0,  // Fire when value changes
    MONITOR_VALUE_MATCHES  = 1,  // Fire when value equals expected
    MONITOR_VALUE_NONZERO  = 2,  // Fire when value becomes nonzero
    MONITOR_VALUE_ZERO     = 3,  // Fire when value becomes zero
    MONITOR_OVERFLOW       = 4,  // Fire when value exceeds threshold
};

struct BufferMonitor {
    uint32_t addr;            // RAM address to watch
    uint8_t  size;            // 1, 2, or 4 bytes
    MonitorCondition cond;   // What to watch for
    uint32_t expected;        // Expected value for MATCHES condition
    uint32_t threshold;       // Threshold for OVERFLOW condition
    uint32_t last_value;      // Last read value (for change detection)
    bool     fired;           // Has this monitor triggered?
    bool     active;          // Is this monitor slot in use?
    char     label[64];       // Human-readable description
    // Register logging on trigger
    bool     log_regs;        // If true, dump registers when triggered
    bool     log_mem_dump;    // If true, dump 256 bytes of memory at addr when triggered
    uint8_t  log_reg_mask;    // Bitmask: bit0=v0, bit1=v1, bit2=a0, bit3=a1, bit4=ra, bit5=pc
};

// ── Agent Harness ────────────────────────────────────────────────────────────
class AgentHarness {
public:
    // ── Construction / Destruction ───────────────────────────────────────────
    AgentHarness();
    ~AgentHarness();

    // ── Lifecycle ────────────────────────────────────────────────────────────

    // Call before emulation starts. Sets up TTY pipe, opens JSON output.
    // profile_name: short identifier for this test run (e.g. "test_a", "rc2")
    // disc_path:    path to the .bin being tested
    // json_path:    output path for telemetry JSON file
    // max_instrs:   instruction limit for this run
    void begin(const char* profile_name, const char* disc_path,
               const char* json_path, uint64_t max_instrs);

    // Call after emulation ends (or on crash/freeze). Flushes TTY,
    // writes JSON telemetry, restores stdout.
    void end(PassStatus status, MIPS_CPU& cpu, PSX_Memory& mem);

    // ── TTY Interception ─────────────────────────────────────────────────────

    // Intercepted printf replacement. Writes to both the real console
    // and the internal capture buffer. Called via harness_printf macro.
    void tty_printf(const char* fmt, ...);

    // Flush TTY buffer to file (for crash recovery).
    void tty_flush();

    // Get the last N bytes of TTY output (for error context).
    // Returns pointer to internal buffer (null-terminated).
    const char* tty_tail(int nbytes) const;

    // Drain TTY pipe into buffer (non-blocking). Call periodically from main loop.
    void drain_pipe();

    // ── VFS Logging ──────────────────────────────────────────────────────────

    // Log a file-system access attempt.
    // resource_id:  file path (e.g. "cdrom:HBD1PS1D.Q41;1") or sector ID
    // lba:          requested LBA sector
    // size:         requested read size in bytes
    // resolved:     true if file/sector was found
    // calling_pc:   PC of the instruction that triggered the access
    // error:        error string if !resolved (nullptr if resolved)
    void log_vfs(const char* resource_id, uint32_t lba, uint32_t size,
                 bool resolved, uint32_t calling_pc, const char* error);

    // Log a CD-ROM sector read attempt.
    void log_cdrom_read(uint32_t lba, bool success, uint32_t calling_pc);

    // ── Error Tracking ───────────────────────────────────────────────────────

    // Log a categorized error.
    void log_error(const char* category, const char* signature,
                   uint32_t pc, uint64_t instr_count);

    // ── Freeze Detection ─────────────────────────────────────────────────────

    // Call every instruction (or every N instructions) with current PC.
    // Returns true if freeze detected (PC has not changed for threshold instrs).
    bool check_freeze(uint32_t current_pc, uint64_t instr_count);

    // Set the freeze threshold (instructions without PC change).
    void set_freeze_threshold(uint64_t threshold);

    // ── Phase 1: Loop Freeze Detection ──────────────────────────────────────

    // Check for tight loop freeze (PC cycling through small set).
    // Called from check_freeze() automatically.
    bool check_loop_freeze(uint32_t current_pc, uint64_t instr_count);

    // Notify harness that a VBlank IRQ was delivered.
    void notify_vblank(uint64_t instr_count);

    // Get the freeze type for triage reporting.
    FreezeType get_freeze_type() const { return m_freeze_type; }

    // Get the loop body PCs (for triage log).
    int get_loop_body(uint32_t* out_pcs, int max_count) const;

    // ── Phase 2: BIOS Call Logging ──────────────────────────────────────────

    // Log a BIOS call for triage reporting.
    void log_bios_call(char table, uint8_t function, uint32_t ra,
                       uint32_t a0, uint32_t a1, uint32_t a2, uint32_t a3,
                       uint64_t instr_count);

    // ── Phase 2: Triage Log ─────────────────────────────────────────────────

    // Set the triage log output path.
    void set_triage_path(const char* path);

    // Write the human-readable triage log file.
    // Called on any non-PASS_COMPLETE exit.
    void write_triage_log(MIPS_CPU& cpu, PSX_Memory& mem);

    // ── Phase 9: Live RAM State Injection ───────────────────────────────────

    // Queue a RAM injection to fire at a specific condition.
    void queue_injection(uint32_t addr, uint32_t value, uint8_t size,
                         InjectCondition cond, uint64_t trigger_value,
                         const char* label);

    // Queue a diagnostic snapshot when PC reaches the given address.
    void queue_pc_dump(uint32_t pc, const char* label);

    // If true, terminate the run after the next diagnostic PC dump fires.
    void set_diag_pc_quit(bool quit) { m_diag_pc_quit = quit; }

    // Set an optional RAM address to capture during the diagnostic PC dump.
    void set_diag_mem_addr(uint32_t addr) { m_diag_mem_addr = addr; m_diag_mem_set = true; }

    // Returns true if a diagnostic dump requested run termination.
    bool diag_dump_quit_requested() const { return m_diag_dump_quit; }

    // Returns true if any INJECT_AT_PC_DUMP entry is still pending.
    bool has_pc_dump_pending() const;

    // Check pending INJECT_AT_PC_DUMP entries against current PC and fire if
    // matched. Captures state *before* the target instruction executes.
    bool check_pc_dump_before_step(MIPS_CPU& cpu, PSX_Memory& mem, uint64_t instr_count);

    // Load injection entries from a JSON spec file.
    // Returns number of entries loaded, or -1 on error.
    int load_injections(const char* json_path);

    // Check and apply pending injections. Call every instruction or
    // every N instructions from the emulation loop.
    void check_injections(MIPS_CPU& cpu, PSX_Memory& mem, uint64_t instr_count,
                          uint32_t vblank_count);

    // Get count of pending (unfired) injections.
    int pending_injections() const;

    // Get count of fired injections.
    int fired_injections() const;

    // ── Phase 11: Interactive Console ─────────────────────────────────────────

    // Enable the stdin console thread. Call once in begin().
    void enable_console(bool enabled);

    // Process pending console commands. Call periodically from the main loop.
    // Returns true if the run should continue; false if 'quit' was requested.
    bool process_console(MIPS_CPU& cpu, PSX_Memory& mem);

    // ── Symbol Table ────────────────────────────────────────────────────────

    // Load a JSON symbol table (name -> hex address). Returns count loaded.
    int load_symbols(const char* json_path);

    // Resolve a symbol name or numeric address string to a 32-bit address.
    // Returns true on success and writes to *out. On failure returns false.
    bool resolve_symbol(const char* name_or_addr, uint32_t* out) const;

    // Look up address for a symbol name. Returns 0 if not found.
    uint32_t symbol_address(const char* name) const;

    // Check if the emulator is currently paused by the console.
    bool is_paused() const;

    // Pause the emulator from the console.
    void console_pause();

    // Check if the emulator should single-step the next instruction.
    bool consume_step();

    // Set a console breakpoint. The main loop should halt when PC == addr.
    void set_console_breakpoint(uint32_t addr);

    // Clear console breakpoint.
    void clear_console_breakpoint();

    // Enqueue a command from the console reader thread.
    void enqueue_console_command(const std::string& cmd, const std::vector<std::string>& args);

    // Query whether the console reader thread should keep running.
    bool is_console_running() const;

    // ── Phase 10: Buffer Monitor ────────────────────────────────────────────

    // Add a buffer monitor on a RAM address.
    void add_monitor(uint32_t addr, uint8_t size, MonitorCondition cond,
                     uint32_t expected, uint32_t threshold, const char* label);

    // Load monitor entries from a JSON spec file.
    int load_monitors(const char* json_path);

    // Check all active monitors. Returns number of triggers fired this call.
    int check_monitors(PSX_Memory& mem, MIPS_CPU& cpu, uint64_t instr_count);

    // Get count of active (unfired) monitors.
    int active_monitors() const;

    // Print monitor status to TTY.
    void dump_monitor_status();

    // ── Phase 11: Event-Driven Triage Hooks ──────────────────────────────────

    // Register a watch-event on a BIOS call (triggers when function is called).
    // table: 'A', 'B', or 'C'; fn: BIOS function number.
    // action: bitmask of WatchEventAction values.
    void add_watch_bios_call(char table, uint8_t fn, WatchEventAction action,
                              const char* label);

    // Register a watch-event on a BIOS return value.
    // Triggers when the specified BIOS function returns expected_return.
    // return_matches=true: trigger when return==expected; false: trigger when return!=expected.
    void add_watch_bios_return(char table, uint8_t fn, uint32_t expected_return,
                                bool return_matches, WatchEventAction action,
                                const char* label);

    // Register a watch-event on PC reaching a specific address.
    void add_watch_pc(uint32_t pc_target, WatchEventAction action,
                       const char* label);

    // Register a watch-event on CD-ROM errors.
    void add_watch_cdrom_error(WatchEventAction action, const char* label);

    // Register a watch-event on VFS failures.
    void add_watch_vfs_fail(WatchEventAction action, const char* label);

    // Register a watch-event on interrupt chain breaks.
    void add_watch_int_break(WatchEventAction action, const char* label);

    // Check watch-events against a BIOS call entry (called from handle_bios_call).
    // call_pc: 0xA0/0xB0/0xC0; fn: function number; return_val: $v0 after call.
    void check_watch_bios(uint32_t call_pc, uint8_t fn, uint32_t return_val,
                           MIPS_CPU& cpu, PSX_Memory& mem, uint64_t instr_count);

    // Check watch-events against current PC (called from step loop).
    void check_watch_pc(uint32_t pc, MIPS_CPU& cpu, PSX_Memory& mem,
                         uint64_t instr_count);

    // Check watch-events for CD-ROM errors (called on read failures).
    void check_watch_cdrom_error(uint32_t lba, MIPS_CPU& cpu, PSX_Memory& mem,
                                  uint64_t instr_count);

    // Check watch-events for VFS failures (called on file resolution failures).
    void check_watch_vfs_fail(const char* resource_id, MIPS_CPU& cpu,
                               PSX_Memory& mem, uint64_t instr_count);

    // Check watch-events for interrupt chain breaks.
    // Fires when I_STAT has pending bits but no event was delivered.
    void check_watch_int_break(uint32_t istat, uint32_t imask,
                                bool event_delivered, MIPS_CPU& cpu,
                                PSX_Memory& mem, uint64_t instr_count);

    // Load watch-event definitions from a JSON spec file.
    int load_watch_events(const char* json_path);

    // Get count of active (unfired) watch-events.
    int active_watch_events() const;

    // Get count of fired watch-events.
    int fired_watch_events() const;

    // Dump all watch-event status to TTY.
    void dump_watch_events();

    // Get diagnostic snapshots (for JSON output).
    int get_snapshot_count() const;
    const DiagnosticSnapshot* get_snapshots() const;

    // ── QA-Master: Assertion State ─────────────────────────────────────────

    // Record an assertion. If severity == ASSERT_FAIL, sets m_assert_failed flag.
    // The harness_runner.py will detect this in telemetry JSON and abort the test.
    void record_assert(const char* name, AssertSeverity severity,
                       const char* detail, uint32_t expected, uint32_t actual);

    // Convenience macro for use in emulator core:
    //   ASSERT_STATE(g_harness, "NAME", condition, "detail", expected, actual)
    // Only fires if g_harness is active.
    bool has_assert_fail() const { return m_assert_fail; }
    int  assert_count() const { return m_assert_count; }
    int  assert_fail_count() const { return m_assert_fail_count; }

    // ── State Dump ────────────────────────────────────────────────────────────

    // Capture a full register snapshot from the CPU.
    void capture_registers(MIPS_CPU& cpu);

    // Capture memory contents at a specific address range.
    void capture_memory(PSX_Memory& mem, uint32_t addr, uint32_t length);

    // ── JSON Output ───────────────────────────────────────────────────────────

    // Write the complete telemetry JSON file.
    // Called by end(), but can also be called mid-run for checkpointing.
    void write_json(MIPS_CPU& cpu, PSX_Memory& mem, PassStatus status);

    // ── Wall-Clock Timeout ────────────────────────────────────────────────────

    // Set wall-clock timeout in milliseconds. 0 = no timeout.
    void set_wallclock_timeout(uint32_t ms);

    // Check if wall-clock timeout has been exceeded.
    bool check_wallclock_timeout() const;

    // ── Accessors ─────────────────────────────────────────────────────────────
    bool is_active() const { return m_active; }
    bool is_frozen() const { return m_frozen; }
    int  vfs_count() const { return m_vfs_count; }
    int  error_count() const { return m_error_count; }
    const char* profile() const { return m_profile; }

private:
    // ── State ─────────────────────────────────────────────────────────────────
    bool     m_active;
    bool     m_frozen;
    char     m_profile[HARNESS_PROFILE_LEN];
    char     m_disc_path[HARNESS_PATH_LEN];
    char     m_json_path[HARNESS_PATH_LEN];
    uint64_t m_max_instrs;
    uint64_t m_freeze_threshold;
    uint32_t m_wallclock_timeout_ms;
    DWORD    m_start_tick;

    // ── TTY Capture ───────────────────────────────────────────────────────────
    // We use a Windows anonymous pipe to intercept stdout.
    int      m_tty_pipe_read;
    int      m_tty_pipe_write;
    int      m_orig_stdout_fd;
    FILE*    m_orig_stdout_file;
    char*    m_tty_buffer;          // heap-allocated HARNESS_TTY_BUF_SIZE
    int      m_tty_pos;             // current write position in buffer
    bool     m_tty_redirected;

    // ── VFS Records ───────────────────────────────────────────────────────────
    VfsAccessRecord m_vfs_log[HARNESS_VFS_MAX];
    int     m_vfs_count;

    // ── Error Records ─────────────────────────────────────────────────────────
    ErrorRecord m_errors[HARNESS_ERROR_MAX];
    int     m_error_count;

    // ── State Snapshots ───────────────────────────────────────────────────────
    RegisterSnapshot  m_regs;
    bool              m_regs_captured;
    MemoryDumpRecord  m_mem_dump;
    bool              m_mem_captured;
    MemoryDumpRecord  m_crash_mem_dump;
    bool              m_crash_mem_captured;

    // ── Freeze Detection State ────────────────────────────────────────────────
    uint32_t m_last_pc;
    uint64_t m_last_pc_change_instr;
    uint64_t m_last_instr_seen;

    // ── Phase 1: Loop Freeze Detection State ──────────────────────────────────
    uint32_t m_pc_history[HARNESS_PC_HISTORY_SIZE];
    int      m_pc_history_head;
    int      m_pc_history_count;
    uint64_t m_loop_start_instr;      // instr count when current PC set started
    FreezeType m_freeze_type;
    uint32_t m_loop_body[HARNESS_LOOP_BODY_MAX];  // unique PCs in the loop
    int      m_loop_body_count;

    // ── Phase 1: VBlank Stall Detection ───────────────────────────────────────
    uint64_t m_last_vblank_instr;     // instr count at last VBlank delivery
    bool     m_vblank_ever_fired;     // has at least one VBlank been delivered?

    // ── Phase 2: BIOS Call Log ────────────────────────────────────────────────
    BiosCallEntry m_bios_log[HARNESS_BIOS_LOG_MAX];
    int      m_bios_log_count;

    // ── Phase 2: Triage Log Path ──────────────────────────────────────────────
    char     m_triage_path[HARNESS_PATH_LEN];

    // ── Phase 9: RAM Injection State ───────────────────────────────────────────
    RamInjection m_injections[HARNESS_INJECT_MAX];
    int      m_injection_count;
    bool     m_diag_pc_quit;   // terminate run after diagnostic PC dump
    bool     m_diag_dump_quit; // set when a dump has requested termination
    bool     m_diag_mem_set;   // optional extra memory dump enabled
    uint32_t m_diag_mem_addr;  // extra memory dump base address

    // ── Phase 10: Buffer Monitor State ─────────────────────────────────────────
    BufferMonitor m_monitors[HARNESS_MONITOR_MAX];
    int      m_monitor_count;

    // ── Phase 11: Event-Driven Triage Hook State ───────────────────────────────
    WatchEvent m_watch_events[HARNESS_WATCH_EVENT_MAX];
    int      m_watch_event_count;
    DiagnosticSnapshot m_snapshots[HARNESS_SNAPSHOT_MAX];
    int      m_snapshot_count;
    int      m_snapshot_head;  // Ring buffer head for snapshots

    // ── Phase 11: Interactive Console State ───────────────────────────────────
    struct ConsoleCommand {
        std::string cmd;
        std::vector<std::string> args;
    };
    std::thread*            m_console_thread;
    std::mutex              m_console_mutex;
    std::queue<ConsoleCommand> m_console_queue;
    std::atomic<bool>       m_console_running;
    bool                    m_console_enabled;
    std::atomic<bool>       m_paused;
    std::atomic<int>        m_step_requests;
    uint32_t                m_console_breakpoint;
    bool                    m_console_breakpoint_set;

    // ── QA-Master: Assertion State ─────────────────────────────────────────
    AssertRecord m_assertions[HARNESS_ASSERT_MAX];
    int      m_assert_count;
    int      m_assert_fail_count;
    bool     m_assert_fail;

    // ── Symbol Table ───────────────────────────────────────────────────────
    std::unordered_map<std::string, uint32_t> m_symbols;

    // ── JSON Helpers ──────────────────────────────────────────────────────────
    void json_escape(const char* in, char* out, int out_len) const;
    void write_json_string(FILE* f, const char* key, const char* val, int indent);
    void write_json_uint(FILE* f, const char* key, uint64_t val, int indent);
    void write_json_bool(FILE* f, const char* key, bool val, int indent);

    // ── Phase 2: Triage Helpers ───────────────────────────────────────────────
    const char* decode_mnemonic(uint32_t raw, uint32_t pc) const;
    void write_triage_loop_body(FILE* f, MIPS_CPU& cpu);
    void write_triage_registers(FILE* f);
    void write_triage_bios_calls(FILE* f);
    void write_triage_vfs(FILE* f);
    void write_triage_memory(FILE* f, PSX_Memory& mem);

    // ── Phase 11: Snapshot Helper ─────────────────────────────────────────────
    void take_snapshot(MIPS_CPU& cpu, PSX_Memory& mem,
                       WatchEvent& we, uint64_t instr_count,
                       const char* trigger_desc);
};

// ── Global Harness Instance ──────────────────────────────────────────────────
extern AgentHarness* g_harness;

// ── Printf Override Macro ────────────────────────────────────────────────────
// When AGENT_HARNESS_ENABLED is defined, all printf calls in the emulator
// source are redirected through the harness for TTY capture.
// Usage: compile with -DAGENT_HARNESS_ENABLED
#ifdef AGENT_HARNESS_ENABLED
  #define printf harness_printf
  // Variadic helper — forwards to g_harness->tty_printf
  int harness_printf(const char* fmt, ...);
#endif

// ── ASSERT_STATE Macro ───────────────────────────────────────────────────────
// Usage in emulator core:
//   ASSERT_STATE("HBD_LBA_MATCH", cdrom_cur_lba == expected_lba, "LBA mismatch", expected_lba, cdrom_cur_lba);
// When condition is false, records an assertion failure in the harness.
#ifdef AGENT_HARNESS_ENABLED
  #define ASSERT_STATE(name, cond, detail, expected, actual) do { \
      if (g_harness && g_harness->is_active() && !(cond)) { \
          g_harness->record_assert(name, ASSERT_FAIL, detail, (uint32_t)(expected), (uint32_t)(actual)); \
      } \
  } while(0)
  #define ASSERT_WARN_STATE(name, cond, detail, expected, actual) do { \
      if (g_harness && g_harness->is_active() && !(cond)) { \
          g_harness->record_assert(name, ASSERT_WARN, detail, (uint32_t)(expected), (uint32_t)(actual)); \
      } \
  } while(0)
  #define ASSERT_INFO_STATE(name, detail, expected, actual) do { \
      if (g_harness && g_harness->is_active()) { \
          g_harness->record_assert(name, ASSERT_INFO, detail, (uint32_t)(expected), (uint32_t)(actual)); \
      } \
  } while(0)
#else
  #define ASSERT_STATE(name, cond, detail, expected, actual) do {} while(0)
  #define ASSERT_WARN_STATE(name, cond, detail, expected, actual) do {} while(0)
  #define ASSERT_INFO_STATE(name, detail, expected, actual) do {} while(0)
#endif
