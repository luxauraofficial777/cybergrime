#!/usr/bin/env python3
"""
Deep analysis of the BCD MSF table region in DW7 EXE around offset 0x09291E.
Also scan for ALL BCD MSF-like patterns in the EXE to find the complete FMV seek table.
"""
import struct

DW7_DISC = r"C:\LuxAura\VoidWalkers_Project\DQLOSTTRANSLATION\DW7D1\DW7D1.bin"
SECTOR_SIZE = 2352
USER_OFFSET = 24
USER_SIZE = 2048
EXE_LBA = 24

def read_exe_from_disc(disc_path, exe_lba, max_size=2*1024*1024):
    with open(disc_path, 'rb') as f:
        f.seek(exe_lba * SECTOR_SIZE + USER_OFFSET)
        header = f.read(USER_SIZE)
        if header[:8] != b'PS-X EXE':
            print(f"ERROR: Not a PS-X EXE at LBA {exe_lba}")
            return None
        text_size = struct.unpack_from('<I', header, 0x1C)[0]
        load_addr = struct.unpack_from('<I', header, 0x10)[0]
        print(f"  PS-X EXE: text_size=0x{text_size:X}, load_addr=0x{load_addr:08X}")
        
        total_size = min(text_size + 0x800, max_size)
        sectors_needed = (total_size + USER_SIZE - 1) // USER_SIZE
        
        f.seek(exe_lba * SECTOR_SIZE + USER_OFFSET)
        data = bytearray()
        for s in range(sectors_needed):
            sector = f.read(SECTOR_SIZE)
            if len(sector) < SECTOR_SIZE:
                break
            data.extend(sector[USER_OFFSET:USER_OFFSET+USER_SIZE])
        
        return bytes(data[:total_size]), load_addr

def is_valid_bcd(b):
    """Check if byte is valid BCD (both nibbles 0-9)."""
    return ((b >> 4) & 0xF) <= 9 and (b & 0xF) <= 9

def bcd_to_int(b):
    return ((b >> 4) & 0xF) * 10 + (b & 0xF)

def is_valid_msf(m, s, f):
    """Check if BCD MSF is valid for a CD-ROM sector."""
    mi = bcd_to_int(m)
    si = bcd_to_int(s)
    fi = bcd_to_int(f)
    if mi > 59 or si > 59 or fi > 74:
        return False
    lba = mi * 60 * 75 + si * 75 + fi
    # PSX disc max is about 75*60*80 = 360000 sectors
    if lba < 100 or lba > 360000:
        return False
    return True

def main():
    print("=" * 70)
    print("  DW7 EXE BCD MSF Table Deep Analysis")
    print("=" * 70)
    
    exe, load_addr = read_exe_from_disc(DW7_DISC, EXE_LBA)
    print(f"  EXE size: {len(exe)} bytes, load_addr: 0x{load_addr:08X}")
    
    # The EXE header is 0x800 bytes. Code/data starts at file offset 0x800.
    # RAM address = load_addr + (file_offset - 0x800)
    def file_to_ram(foff):
        return load_addr + foff - 0x800
    
    # 1. Dump the region around 0x09291E (256 bytes before, 256 after)
    print(f"\n{'='*70}")
    print(f"  Region dump around 0x09291E (±256 bytes)")
    print(f"{'='*70}")
    
    region_start = max(0, 0x09291E - 256)
    region_end = min(len(exe), 0x09291E + 256)
    
    for row in range(region_start, region_end, 16):
        ram = file_to_ram(row)
        hex_bytes = ' '.join(f'{exe[row+i]:02x}' for i in range(min(16, region_end - row)))
        ascii_chars = ''.join(chr(exe[row+i]) if 32 <= exe[row+i] < 127 else '.' for i in range(min(16, region_end - row)))
        marker = " <<<" if row <= 0x09291E < row + 16 else ""
        print(f"  0x{row:06X} (RAM 0x{ram:08X}): {hex_bytes:<48s} {ascii_chars}{marker}")
    
    # 2. Scan entire EXE for valid BCD MSF triplets
    print(f"\n{'='*70}")
    print(f"  Full EXE scan for valid BCD MSF triplets")
    print(f"{'='*70}")
    
    msf_hits = []
    for i in range(0x800, len(exe) - 2):
        b0, b1, b2 = exe[i], exe[i+1], exe[i+2]
        if is_valid_bcd(b0) and is_valid_bcd(b1) and is_valid_bcd(b2):
            if is_valid_msf(b0, b1, b2):
                m = bcd_to_int(b0)
                s = bcd_to_int(b1)
                f = bcd_to_int(b2)
                lba = m * 60 * 75 + s * 75 + f
                ram = file_to_ram(i)
                # Get context
                ctx_start = max(0, i - 4)
                ctx_end = min(len(exe), i + 8)
                ctx = ' '.join(f'{exe[j]:02x}' for j in range(ctx_start, ctx_end))
                msf_hits.append((i, ram, m, s, f, lba, ctx))
    
    print(f"  Found {len(msf_hits)} valid BCD MSF triplets in EXE")
    
    # Filter: only show those with LBA > 10000 (likely disc seeks, not small values)
    disc_seeks = [(foff, ram, m, s, f, lba, ctx) for foff, ram, m, s, f, lba, ctx in msf_hits if lba > 10000]
    print(f"  Of those, {len(disc_seeks)} have LBA > 10000 (likely disc seeks):")
    
    for foff, ram, m, s, f, lba, ctx in disc_seeks:
        marker = ""
        if foff == 0x09291E:
            marker = " *** KNOWN FMV SEEK ***"
        print(f"    File 0x{foff:06X} (RAM 0x{ram:08X}): BCD {m:02d}:{s:02d}:{f:02d} = LBA {lba:6d}  ctx: {ctx}{marker}")
    
    # 3. Check if the BCD values are in a structured table (aligned, sequential)
    print(f"\n{'='*70}")
    print(f"  Table structure analysis around 0x09291E")
    print(f"{'='*70}")
    
    # Check if there's a table of 3-byte or 4-byte BCD entries
    # Look at 0x092900 to 0x092960 for structured data
    print(f"\n  As 3-byte BCD MSF entries (starting at 0x092900):")
    for off in range(0x092900, 0x092960, 3):
        if off + 2 < len(exe):
            b0, b1, b2 = exe[off], exe[off+1], exe[off+2]
            ram = file_to_ram(off)
            if is_valid_bcd(b0) and is_valid_bcd(b1) and is_valid_bcd(b2):
                m, s, f = bcd_to_int(b0), bcd_to_int(b1), bcd_to_int(b2)
                lba = m * 60 * 75 + s * 75 + f
                print(f"    0x{off:06X} (RAM 0x{ram:08X}): {b0:02x} {b1:02x} {b2:02x} = BCD {m:02d}:{s:02d}:{f:02d} = LBA {lba}")
            else:
                print(f"    0x{off:06X} (RAM 0x{ram:08X}): {b0:02x} {b1:02x} {b2:02x} (not valid BCD MSF)")
    
    print(f"\n  As 4-byte entries (3 BCD + 1 padding/index):")
    for off in range(0x092900, 0x092980, 4):
        if off + 3 < len(exe):
            b0, b1, b2, b3 = exe[off], exe[off+1], exe[off+2], exe[off+3]
            ram = file_to_ram(off)
            msf_str = ""
            if is_valid_bcd(b0) and is_valid_bcd(b1) and is_valid_bcd(b2):
                m, s, f = bcd_to_int(b0), bcd_to_int(b1), bcd_to_int(b2)
                if is_valid_msf(b0, b1, b2):
                    lba = m * 60 * 75 + s * 75 + f
                    msf_str = f"= BCD {m:02d}:{s:02d}:{f:02d} = LBA {lba}"
            print(f"    0x{off:06X} (RAM 0x{ram:08X}): {b0:02x} {b1:02x} {b2:02x} {b3:02x} {msf_str}")
    
    # 4. Also check as MIPS data - maybe these are sb (store byte) instructions
    # or part of a function that builds the Setloc parameter
    print(f"\n{'='*70}")
    print(f"  MIPS disassembly around 0x09291E")
    print(f"{'='*70}")
    
    # Check if the region before 0x09291E contains MIPS code that references this data
    # Look for lui/addiu patterns that load the address of this data
    data_ram = file_to_ram(0x09291E)
    print(f"  BCD data at RAM 0x{data_ram:08X}")
    
    # Search for references to this RAM address in the code
    # lui $reg, upper16; addiu $reg, $reg, lower16
    upper = (data_ram >> 16) & 0xFFFF
    lower = data_ram & 0xFFFF
    print(f"  Looking for lui+addiu loading 0x{data_ram:08X} (upper=0x{upper:04X}, lower=0x{lower:04X})")
    
    # Search for lui with upper16
    for i in range(0x800, len(exe) - 8, 4):
        word = struct.unpack_from('<I', exe, i)[0]
        opcode = (word >> 26) & 0x3F
        if opcode == 0x0F:  # lui
            imm = word & 0xFFFF
            rt = (word >> 16) & 0x1F
            if imm == upper:
                # Check next instruction for addiu with lower
                next_word = struct.unpack_from('<I', exe, i + 4)[0]
                next_opcode = (next_word >> 26) & 0x3F
                next_imm = next_word & 0xFFFF
                next_rs = (next_word >> 21) & 0x1F
                next_rt = (next_word >> 16) & 0x1F
                if next_opcode == 0x09 and next_rt == rt and next_rs == rt:
                    ram = file_to_ram(i)
                    loaded_addr = (imm << 16) + struct.unpack('h', struct.pack('H', next_imm))[0]
                    print(f"    REF at 0x{ram:08X}: lui ${rt}, 0x{imm:04X}; addiu ${rt}, ${rt}, 0x{next_imm:04X} → 0x{loaded_addr:08X}")
    
    # 5. Check what's at the known previous patch site 0x92936
    print(f"\n  Also checking offset 0x92936 (previous BCD redirect attempt):")
    if 0x92936 + 3 <= len(exe):
        b0, b1, b2 = exe[0x92936], exe[0x92937], exe[0x92938]
        ram = file_to_ram(0x92936)
        if is_valid_bcd(b0) and is_valid_bcd(b1) and is_valid_bcd(b2):
            m, s, f = bcd_to_int(b0), bcd_to_int(b1), bcd_to_int(b2)
            if is_valid_msf(b0, b1, b2):
                lba = m * 60 * 75 + s * 75 + f
                print(f"    0x92936 (RAM 0x{ram:08X}): BCD {m:02d}:{s:02d}:{f:02d} = LBA {lba}")
            else:
                print(f"    0x92936: {b0:02x} {b1:02x} {b2:02x} (valid BCD but invalid MSF)")
        else:
            print(f"    0x92936: {b0:02x} {b1:02x} {b2:02x} (not valid BCD)")
    
    # 6. Summary of patch plan
    print(f"\n{'='*70}")
    print(f"  PATCH PLAN")
    print(f"{'='*70}")
    
    target_bcd = bytes([0x23, 0x31, 0x15])  # DQ4 BCD 23:31:15
    source_bcd = bytes([0x32, 0x34, 0x71])  # DW7 BCD 32:34:71
    
    print(f"  Source: DW7 BCD 32:34:71 (LBA 146621) at file offset 0x09291E")
    print(f"  Target: DQ4 BCD 23:31:15 (LBA 105840)")
    print(f"  Patch:  3 bytes at 0x09291E: {source_bcd.hex()} → {target_bcd.hex()}")
    
    # Also check if there are other 32:34:71 occurrences we missed
    all_323471 = []
    start = 0
    while True:
        idx = exe.find(source_bcd, start)
        if idx == -1:
            break
        all_323471.append(idx)
        start = idx + 1
    print(f"\n  All occurrences of 32 34 71 in EXE: {len(all_323471)}")
    for off in all_323471:
        ram = file_to_ram(off)
        print(f"    File 0x{off:06X} (RAM 0x{ram:08X})")

if __name__ == '__main__':
    main()
