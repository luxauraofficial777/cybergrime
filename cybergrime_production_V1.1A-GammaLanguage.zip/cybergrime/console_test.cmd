@echo off
echo b 0x8004BD70> C:\LuxAura\VoidWalkers_Project\DQLOSTTRANSLATION\cybergrime\console_cmds.txt
echo q>> C:\LuxAura\VoidWalkers_Project\DQLOSTTRANSLATION\cybergrime\console_cmds.txt
C:\LuxAura\VoidWalkers_Project\DQLOSTTRANSLATION\cybergrime\psx_agent_runner.exe C:\LuxAura\VoidWalkers_Project\DQLOSTTRANSLATION\_archive\dq4_frankenstein_v14.bin console_test 10000000 telemetry_console_test.json 0 --console < C:\LuxAura\VoidWalkers_Project\DQLOSTTRANSLATION\cybergrime\console_cmds.txt
