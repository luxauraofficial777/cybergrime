$bin = 'c:\LuxAura\VoidWalkers_Project\DQLOSTTRANSLATION\build_staging\dq4_frankenstein_v108c.bin'
$f = Get-Item $bin
Write-Host "File: $($f.Name)"
Write-Host "Size: $($f.Length) bytes"
Write-Host "Date: $($f.LastWriteTime)"
$h = (Get-FileHash $bin -Algorithm SHA256).Hash
Write-Host "SHA-256: $h"
