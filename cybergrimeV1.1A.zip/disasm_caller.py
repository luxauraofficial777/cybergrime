#!/usr/bin/env python3
"""Disassemble the caller of the VBlank wait loop."""
import struct

SECTOR_SIZE = 2352
DATA_OFFSET = 24
USER_SIZE = 2048

def read_sector_user(f, lba):
    f.seek(lba * SECTOR_SIZE + DATA_OFFSET)
    return f.read(USER_SIZE)

def read_exe_from_disc(disc_path, exe_lba=24, exe_size=678496):
    with open(disc_path, 'rb') as f:
        data = bytearray()
        sectors = (exe_size + USER_SIZE - 1) // USER_SIZE
        for i in range(sectors):
            chunk = read_sector_user(f, exe_lba + i)
            data.extend(chunk)
        return bytes(data[:exe_size])

def disasm(word, addr=0):
    op = (word >> 26) & 0x3F
    rs = (word >> 21) & 0x1F
    rt = (word >> 16) & 0x1F
    rd = (word >> 11) & 0x1F
    shamt = (word >> 6) & 0x1F
    funct = word & 0x3F
    imm = word & 0xFFFF
    simm = imm if imm < 0x8000 else imm - 0x10000
    target = word & 0x3FFFFFF
    regs = ['zero','at','v0','v1','a0','a1','a2','a3',
            't0','t1','t2','t3','t4','t5','t6','t7',
            's0','s1','s2','s3','s4','s5','s6','s7',
            't8','t9','k0','k1','gp','sp','fp','ra']
    if op == 0:
        if funct == 0x08: return f"jr {regs[rs]}"
        if funct == 0x09: return f"jalr {regs[rd]}, {regs[rs]}"
        if funct == 0x21: return f"addu {regs[rd]}, {regs[rs]}, {regs[rt]}"
        if funct == 0x23: return f"subu {regs[rd]}, {regs[rs]}, {regs[rt]}"
        if funct == 0x24: return f"and {regs[rd]}, {regs[rs]}, {regs[rt]}"
        if funct == 0x25: return f"or {regs[rd]}, {regs[rs]}, {regs[rt]}"
        if funct == 0x27: return f"nor {regs[rd]}, {regs[rs]}, {regs[rt]}"
        if funct == 0x2A: return f"slt {regs[rd]}, {regs[rs]}, {regs[rt]}"
        if funct == 0x2B: return f"sltu {regs[rd]}, {regs[rs]}, {regs[rt]}"
        if funct == 0x00: return f"sll {regs[rd]}, {regs[rt]}, {shamt}" if word != 0 else "nop"
        if funct == 0x02: return f"srl {regs[rd]}, {regs[rt]}, {shamt}"
        if funct == 0x03: return f"sra {regs[rd]}, {regs[rt]}, {shamt}"
        if funct == 0x04: return f"sllv {regs[rd]}, {regs[rt]}, {regs[rs]}"
        if funct == 0x06: return f"srlv {regs[rd]}, {regs[rt]}, {regs[rs]}"
        if funct == 0x07: return f"srav {regs[rd]}, {regs[rt]}, {regs[rs]}"
        if funct == 0x10: return f"mfhi {regs[rd]}"
        if funct == 0x12: return f"mflo {regs[rd]}"
        if funct == 0x18: return f"mult {regs[rs]}, {regs[rt]}"
        if funct == 0x19: return f"multu {regs[rs]}, {regs[rt]}"
        if funct == 0x20: return f"add {regs[rd]}, {regs[rs]}, {regs[rt]}"
        if funct == 0x22: return f"sub {regs[rd]}, {regs[rs]}, {regs[rt]}"
        if funct == 0x0C: return f"syscall 0x{(word >> 6) & 0xFFFFF:05X}"
        return f"R-type f=0x{funct:02X}"
    if op == 0x01:
        if rt == 0: return f"bltz {regs[rs]}, 0x{addr+4+(simm<<2):08X}"
        if rt == 1: return f"bgez {regs[rs]}, 0x{addr+4+(simm<<2):08X}"
        return f"REGIMM rt={rt}"
    if op == 0x02: return f"j 0x{((target << 2) | (addr & 0xF0000000)):08X}"
    if op == 0x03: return f"jal 0x{((target << 2) | (addr & 0xF0000000)):08X}"
    if op == 0x04: return f"beq {regs[rs]}, {regs[rt]}, 0x{addr+4+(simm<<2):08X}"
    if op == 0x05: return f"bne {regs[rs]}, {regs[rt]}, 0x{addr+4+(simm<<2):08X}"
    if op == 0x06: return f"blez {regs[rs]}, 0x{addr+4+(simm<<2):08X}"
    if op == 0x07: return f"bgtz {regs[rs]}, 0x{addr+4+(simm<<2):08X}"
    if op == 0x08: return f"addi {regs[rt]}, {regs[rs]}, {simm}"
    if op == 0x09: return f"addiu {regs[rt]}, {regs[rs]}, {simm}"
    if op == 0x0A: return f"slti {regs[rt]}, {regs[rs]}, {simm}"
    if op == 0x0B: return f"sltiu {regs[rt]}, {regs[rs]}, {simm}"
    if op == 0x0C: return f"andi {regs[rt]}, {regs[rs]}, 0x{imm:04X}"
    if op == 0x0D: return f"ori {regs[rt]}, {regs[rs]}, 0x{imm:04X}"
    if op == 0x0E: return f"xori {regs[rt]}, {regs[rs]}, 0x{imm:04X}"
    if op == 0x0F: return f"lui {regs[rt]}, 0x{imm:04X}"
    if op == 0x20: return f"lb {regs[rt]}, {simm}({regs[rs]})"
    if op == 0x21: return f"lh {regs[rt]}, {simm}({regs[rs]})"
    if op == 0x23: return f"lw {regs[rt]}, {simm}({regs[rs]})"
    if op == 0x24: return f"lbu {regs[rt]}, {simm}({regs[rs]})"
    if op == 0x25: return f"lhu {regs[rt]}, {simm}({regs[rs]})"
    if op == 0x28: return f"sb {regs[rt]}, {simm}({regs[rs]})"
    if op == 0x29: return f"sh {regs[rt]}, {simm}({regs[rs]})"
    if op == 0x2B: return f"sw {regs[rt]}, {simm}({regs[rs]})"
    if op == 0x10: return f"mfc0 {regs[rt]}, {regs[rd]}"
    if op == 0x12: return f"mtc0 {regs[rt]}, {regs[rd]}"
    return f"op=0x{op:02X} w=0x{word:08X}"

disc = r"C:\LuxAura\VoidWalkers_Project\DQLOSTTRANSLATION\build_staging\dq4_reverse_a.bin"
exe = read_exe_from_disc(disc)
load_addr = struct.unpack_from('<I', exe, 0x18)[0]

# Disassemble caller region around 0x800966C4 (ra from the wait loop)
print("=== Caller at 0x80096680 - 0x80096720 ===")
for addr in range(0x80096680, 0x80096720, 4):
    off = addr - load_addr + 0x800
    if 0 <= off and off + 4 <= len(exe):
        word = struct.unpack_from('<I', exe, off)[0]
        marker = " <-- ra" if addr == 0x800966C4 else ""
        print(f"  0x{addr:08X}: 0x{word:08X}  {disasm(word, addr)}{marker}")

# Also check what's at the null callback address 0x80096870
print(f"\n=== Null callback area 0x80096850 - 0x800968B0 ===")
for addr in range(0x80096850, 0x800968B0, 4):
    off = addr - load_addr + 0x800
    if 0 <= off and off + 4 <= len(exe):
        word = struct.unpack_from('<I', exe, off)[0]
        print(f"  0x{addr:08X}: 0x{word:08X}  {disasm(word, addr)}")

# Check the VBlank event handler setup - what's at 0x8002FE54 (the RCnt handler)
print(f"\n=== RCnt handler at 0x8002FE54 ===")
for addr in range(0x8002FE54, 0x8002FE90, 4):
    off = addr - load_addr + 0x800
    if 0 <= off and off + 4 <= len(exe):
        word = struct.unpack_from('<I', exe, off)[0]
        print(f"  0x{addr:08X}: 0x{word:08X}  {disasm(word, addr)}")

# Check what calls the VBlank wait function (0x80096780)
print(f"\n=== Callers of VBlank wait function (0x80096780) ===")
for off in range(0, len(exe) - 4, 4):
    word = struct.unpack_from('<I', exe, off)[0]
    op = (word >> 26) & 0x3F
    if op == 0x03:  # JAL
        target = (word & 0x3FFFFFF) << 2
        target |= 0x80000000
        if target == 0x80096780:
            addr = load_addr + 0x800 + off - 0x800
            ram = off - 0x800 + load_addr
            print(f"  0x{ram:08X}: jal 0x{target:08X}")
