#!/usr/bin/env python3
"""Trace VBlank interrupt registration path"""
import struct

def read_sector(disc, lba):
    return disc[lba * 2352 + 24: lba * 2352 + 24 + 2048]

def read_exe_from_disc(disc_path, exe_lba, exe_size):
    with open(disc_path, 'rb') as f:
        disc = f.read()
    exe = bytearray()
    sectors = (exe_size + 2047) // 2048
    for i in range(sectors):
        exe.extend(read_sector(disc, exe_lba + i))
    return bytes(exe[:exe_size])

DISC = r'c:\LuxAura\VoidWalkers_Project\DQLOSTTRANSLATION\dq4_phaseC_build1.bin'
exe = read_exe_from_disc(DISC, 24, 960948)
DW7_DISC = r'c:\LuxAura\VoidWalkers_Project\DQLOSTTRANSLATION\DW7D1\DW7D1.bin'
dw7_exe = read_exe_from_disc(DW7_DISC, 24, 675840)

LOAD_ADDR = 0x80017F00
EXE_HEADER = 0x800

def ram_to_file(ram):
    return ram - LOAD_ADDR + EXE_HEADER

def read_word(data, ram):
    foff = ram_to_file(ram)
    if foff + 4 <= len(data):
        return struct.unpack_from('<I', data, foff)[0]
    return None

def disasm(word, pc):
    if word == 0: return "nop"
    op = (word >> 26) & 0x3F
    rs = (word >> 21) & 0x1F
    rt = (word >> 16) & 0x1F
    rd = (word >> 11) & 0x1F
    shamt = (word >> 6) & 0x1F
    funct = word & 0x3F
    imm = word & 0xFFFF
    s_imm = imm - 65536 if imm >= 32768 else imm
    target = word & 0x03FFFFFF
    regs = ['zero','at','v0','v1','a0','a1','a2','a3','t0','t1','t2','t3','t4','t5','t6','t7','s0','s1','s2','s3','s4','s5','s6','s7','t8','t9','k0','k1','gp','sp','fp','ra']
    if op == 0:
        if funct == 0x08: return f"jr {regs[rs]}"
        if funct == 0x09: return f"jalr {regs[rd]}, {regs[rs]}"
        if funct == 0x20: return f"add {regs[rd]}, {regs[rs]}, {regs[rt]}"
        if funct == 0x21: return f"addu {regs[rd]}, {regs[rs]}, {regs[rt]}"
        if funct == 0x23: return f"subu {regs[rd]}, {regs[rs]}, {regs[rt]}"
        if funct == 0x24: return f"and {regs[rd]}, {regs[rs]}, {regs[rt]}"
        if funct == 0x25: return f"or {regs[rd]}, {regs[rs]}, {regs[rt]}"
        if funct == 0x2A: return f"slt {regs[rd]}, {regs[rs]}, {regs[rt]}"
        if funct == 0x2B: return f"sltu {regs[rd]}, {regs[rs]}, {regs[rt]}"
        if funct == 0x00: return f"sll {regs[rd]}, {regs[rt]}, {shamt}"
        if funct == 0x02: return f"srl {regs[rd]}, {regs[rt]}, {shamt}"
        if funct == 0x03: return f"sra {regs[rd]}, {regs[rt]}, {shamt}"
        if funct == 0x0C: return f"syscall"
        if funct == 0x10: return f"mfhi {regs[rd]}"
        if funct == 0x12: return f"mflo {regs[rd]}"
        if funct == 0x18: return f"mult {regs[rs]}, {regs[rt]}"
        if funct == 0x19: return f"multu {regs[rs]}, {regs[rt]}"
        if funct == 0x1A: return f"div {regs[rs]}, {regs[rt]}"
        if funct == 0x1B: return f"divu {regs[rs]}, {regs[rt]}"
        return f"special 0x{funct:02X}"
    if op == 0x01:
        if rt == 0: return f"bltz {regs[rs]}, 0x{pc + 4 + (s_imm << 2):08X}"
        if rt == 1: return f"bgez {regs[rs]}, 0x{pc + 4 + (s_imm << 2):08X}"
        return f"regimm {rt}"
    if op == 0x02: return f"j 0x{(pc & 0xF0000000) | (target << 2):08X}"
    if op == 0x03: return f"jal 0x{(pc & 0xF0000000) | (target << 2):08X}"
    if op == 0x04: return f"beq {regs[rs]}, {regs[rt]}, 0x{pc + 4 + (s_imm << 2):08X}"
    if op == 0x05: return f"bne {regs[rs]}, {regs[rt]}, 0x{pc + 4 + (s_imm << 2):08X}"
    if op == 0x06: return f"blez {regs[rs]}, 0x{pc + 4 + (s_imm << 2):08X}"
    if op == 0x07: return f"bgtz {regs[rs]}, 0x{pc + 4 + (s_imm << 2):08X}"
    if op == 0x08: return f"addi {regs[rt]}, {regs[rs]}, {s_imm}"
    if op == 0x09: return f"addiu {regs[rt]}, {regs[rs]}, {s_imm}"
    if op == 0x0A: return f"slti {regs[rt]}, {regs[rs]}, {s_imm}"
    if op == 0x0B: return f"sltiu {regs[rt]}, {regs[rs]}, {s_imm}"
    if op == 0x0C: return f"andi {regs[rt]}, {regs[rs]}, 0x{imm:04X}"
    if op == 0x0D: return f"ori {regs[rt]}, {regs[rs]}, 0x{imm:04X}"
    if op == 0x0E: return f"xori {regs[rt]}, {regs[rs]}, 0x{imm:04X}"
    if op == 0x0F: return f"lui {regs[rt]}, 0x{imm:04X}"
    if op == 0x20: return f"lb {regs[rt]}, {s_imm}({regs[rs]})"
    if op == 0x21: return f"lh {regs[rt]}, {s_imm}({regs[rs]})"
    if op == 0x23: return f"lw {regs[rt]}, {s_imm}({regs[rs]})"
    if op == 0x24: return f"lbu {regs[rt]}, {s_imm}({regs[rs]})"
    if op == 0x25: return f"lhu {regs[rt]}, {s_imm}({regs[rs]})"
    if op == 0x28: return f"sb {regs[rt]}, {s_imm}({regs[rs]})"
    if op == 0x29: return f"sh {regs[rt]}, {s_imm}({regs[rs]})"
    if op == 0x2B: return f"sw {regs[rt]}, {s_imm}({regs[rs]})"
    # CP0 instructions
    if op == 0x10:  # COP0
        if rs == 0: return f"mfc0 {regs[rt]}, ${rd}"
        if rs == 4: return f"mtc0 {regs[rt]}, ${rd}"
        if rs == 0x10 and funct == 0x18: return "eret"
        return f"cop0 rs={rs} rd=${rd}"
    return f"op=0x{op:02X}"

def show(data, start, count, label=""):
    if label: print(f"\n--- {label} ---")
    for i in range(count):
        ram = start + i * 4
        w = read_word(data, ram)
        if w is None:
            print(f"  0x{ram:08X}: <beyond EXE>")
            break
        d = disasm(w, ram)
        print(f"  0x{ram:08X}: 0x{w:08X}  {d}")

# 1. VBlank registration: 0x80096FA8
print("=" * 60)
print("VBLANK REGISTRATION (0x80096FA8)")
print("=" * 60)
show(exe, 0x80096FA8, 32, "Frank")
show(dw7_exe, 0x80096FA8, 32, "DW7")

# 2. vtable[2] = 0x80096C34
print("\n" + "=" * 60)
print("Vtable[2] = 0x80096C34")
print("=" * 60)
show(exe, 0x80096C34, 32, "Frank")
show(dw7_exe, 0x80096C34, 32, "DW7")

# 3. 0x80096FD8 (called from 0x80096A30)
print("\n" + "=" * 60)
print("0x80096FD8 (called from VBlank init)")
print("=" * 60)
show(exe, 0x80096FD8, 32, "Frank")
show(dw7_exe, 0x80096FD8, 32, "DW7")

# 4. 0x80096828 (vtable[2] wrapper, called from 0x80096EF0)
print("\n" + "=" * 60)
print("0x80096828 (vtable[2] wrapper)")
print("=" * 60)
show(exe, 0x80096828, 16, "Frank")
show(dw7_exe, 0x80096828, 16, "DW7")

# 5. 0x80096F10 (VBlank callback)
print("\n" + "=" * 60)
print("0x80096F10 (VBlank callback)")
print("=" * 60)
show(exe, 0x80096F10, 32, "Frank")
show(dw7_exe, 0x80096F10, 32, "DW7")

# 6. Check 0x800965E8 (called right after VBlank wait in bootstrap)
print("\n" + "=" * 60)
print("0x800965E8 (called after VBlank wait in bootstrap)")
print("=" * 60)
show(exe, 0x800965E8, 32, "Frank")
show(dw7_exe, 0x800965E8, 32, "DW7")

# 7. Check 0x80051000 (called from bootstrap)
print("\n" + "=" * 60)
print("0x80051000 (called from bootstrap)")
print("=" * 60)
show(exe, 0x80051000, 32, "Frank")
show(dw7_exe, 0x80051000, 32, "DW7")

# 8. Check the disc-check function at 0x800506CC more carefully
print("\n" + "=" * 60)
print("DISC-CHECK STUB (0x800506CC)")
print("=" * 60)
show(exe, 0x800506CC, 8, "Frank (patched)")
show(dw7_exe, 0x800506CC, 16, "DW7 (original)")

# 9. Check 0x8008206C (target of jal at 0x800562B8)
print("\n" + "=" * 60)
print("0x8008206C (redirect target from 0x800562B8)")
print("=" * 60)
show(exe, 0x8008206C, 16, "Frank")
show(dw7_exe, 0x8008206C, 16, "DW7")

# 10. Check 0x80082000 (redirect target from 0x800562E4)
print("\n" + "=" * 60)
print("0x80082000 (redirect target from 0x800562E4)")
print("=" * 60)
show(exe, 0x80082000, 16, "Frank")
show(dw7_exe, 0x80082000, 16, "DW7")
