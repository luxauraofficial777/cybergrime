# Search for FMV LBA in various encodings
$exePath = 'c:\LuxAura\VoidWalkers_Project\DQLOSTTRANSLATION\translation\SLUSP012.06'
$bytes = [System.IO.File]::ReadAllBytes($exePath)
$loadAddr = 0x80017F00

function Search32($name, $val) {
    $b = [BitConverter]::GetBytes([uint32]$val)
    Write-Host "=== $name (0x$($val.ToString('X8'))): $($b[0].ToString('X2')) $($b[1].ToString('X2')) $($b[2].ToString('X2')) $($b[3].ToString('X2')) ==="
    $count = 0
    for ($i = 0x800; $i -lt $bytes.Length - 3; $i++) {
        if ($bytes[$i] -eq $b[0] -and $bytes[$i+1] -eq $b[1] -and $bytes[$i+2] -eq $b[2] -and $bytes[$i+3] -eq $b[3]) {
            $ram = $loadAddr + $i - 0x800
            Write-Host ("  File 0x{0:X5} RAM 0x{1:X8}" -f $i, $ram)
            $count++
            if ($count -ge 10) { break }
        }
    }
    if ($count -eq 0) { Write-Host "  (none)" }
}

function Search16($name, $val) {
    $b = [BitConverter]::GetBytes([uint16]$val)
    Write-Host "=== $name (0x$($val.ToString('X4'))): $($b[0].ToString('X2')) $($b[1].ToString('X2')) ==="
    $count = 0
    for ($i = 0x800; $i -lt $bytes.Length - 1; $i++) {
        if ($bytes[$i] -eq $b[0] -and $bytes[$i+1] -eq $b[1]) {
            $ram = $loadAddr + $i - 0x800
            # Show context
            $prev = if ($i -ge 2) { ($bytes[$i-2].ToString('X2') + ' ' + $bytes[$i-1].ToString('X2')) } else { '' }
            $next = if ($i + 3 -lt $bytes.Length) { ($bytes[$i+2].ToString('X2') + ' ' + $bytes[$i+3].ToString('X2')) } else { '' }
            Write-Host ("  File 0x{0:X5} RAM 0x{1:X8} prev={2} next={3}" -f $i, $ram, $prev, $next)
            $count++
            if ($count -ge 10) { break }
        }
    }
    if ($count -eq 0) { Write-Host "  (none)" }
}

function Search3($name, $b0, $b1, $b2) {
    Write-Host "=== ${name}: $([string]$b0) $([string]$b1) $([string]$b2) ==="
    $count = 0
    for ($i = 0x800; $i -lt $bytes.Length - 2; $i++) {
        if ($bytes[$i] -eq $b0 -and $bytes[$i+1] -eq $b1 -and $bytes[$i+2] -eq $b2) {
            $ram = $loadAddr + $i - 0x800
            Write-Host ("  File 0x{0:X5} RAM 0x{1:X8}" -f $i, $ram)
            $count++
            if ($count -ge 10) { break }
        }
    }
    if ($count -eq 0) { Write-Host "  (none)" }
}

# LBA values
Search32 "LBA 146621" 146621
Search32 "LBA-150 = 146471" 146471
Search32 "HBD offset DW7 (146621-354=146267)" 146267
Search32 "HBD offset Frank (146621-362=146259)" 146259

# Binary MSF (not BCD)
# Minute 32 = 0x20, Second 34 = 0x22, Frame 71 = 0x47
Search3 "Binary MSF 32-34-71" 0x20 0x22 0x47
Search32 "Binary MSF as 32-bit (20 22 47 00)" 0x00472220
Search32 "Binary MSF as 32-bit (00 20 22 47)" 0x47222000

# 16-bit halves
Search16 "LBA low 16: 0x3C7D" 0x3C7D
Search16 "LBA high 16: 0x0002" 0x0002
Search16 "HBD offset low: 0x3A9B" 0x3A9B

# Also search for the BCD MSF as a 32-bit value
# BCD 32 34 71 00 = 0x00713432 (little-endian)
Search32 "BCD MSF as 32-bit LE (32 34 71 00)" 0x00713432
# BCD 00 32 34 71 = 0x71343200 (little-endian)
Search32 "BCD MSF as 32-bit LE (00 32 34 71)" 0x71343200

# Maybe the LBA is stored as MSF in binary minus 2 seconds (lead-in adjustment)
# LBA 146621 = MSF 32:34:71 (BCD) = binary MSF 32:34:71
# But in some encodings, 2 seconds (150 frames) are added: 32:36:71 = 32*60+36 = 1956 seconds * 75 + 71 = 146721
Search32 "LBA+150 = 146771" 146771

# Maybe it's stored as a sector number within the HBD file
# DW7 HBD starts at sector 354 (on DW7 disc) or 362 (on Frankenstein)
# But the EXE was compiled for DW7, so it would use 354
# FMV sector within HBD: 146621 - 354 = 146267
# Already searched above

# What about the TOC? The PSX TOC stores track start LBAs
# Maybe the game reads the TOC and finds the data track start
# The data track starts at LBA 0 (or LBA 150 after lead-in)
# But the FMV is within the data track, not a separate track

# Let me also search for the value 146621 in big-endian
Search3 "LBA 146621 big-endian first 3 bytes" 0x00 0x23 0xC7
Search16 "LBA 146621 big-endian" 0x23C7
