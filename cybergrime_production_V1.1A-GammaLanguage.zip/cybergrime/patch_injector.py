#!/usr/bin/env python3
"""
patch_injector.py — Send patch commands to the emulator via instrumentation bus.

Can be used as a library or as a standalone interactive CLI.

Usage (library):
    injector = PatchInjector(r"\\.\pipe\cybergrime_live")
    injector.write_mem(0x80100000, 0x2923BE84, 4, "inject tree root")
    injector.write_reg(6, 0x80100000, "set $a2 to relocated tree")
    injector.rollback("undo all patches")

Usage (CLI):
    python patch_injector.py --pipe \\\\.\pipe\cybergrime_live
    > write_mem 0x80100000 0x2923BE84 4 "inject tree root"
    > write_reg 6 0x80100000 "set $a2"
    > dump_region 0x80100000 1488 "verify tree"
    > rollback "undo all"
    > quit
"""

import argparse
import json
import os
import sys
import time
from typing import Optional


class PatchInjector:
    """Send patch commands to the emulator via named pipe."""

    def __init__(self, pipe_name: str):
        self.pipe_name = pipe_name
        self._pipe = None

    def _connect(self) -> bool:
        """Connect to the named pipe (blocking with timeout)."""
        if self._pipe is not None:
            return True

        # Windows named pipe client
        try:
            import win32file
            import win32pipe
            self._pipe = win32file.CreateFile(
                self.pipe_name,
                win32file.GENERIC_READ | win32file.GENERIC_WRITE,
                0, None,
                win32file.OPEN_EXISTING,
                0, None
            )
            return True
        except ImportError:
            pass

        # Fallback: use subprocess with PowerShell
        # Or use ctypes directly
        import ctypes
        from ctypes import wintypes

        kernel32 = ctypes.windll.kernel32

        GENERIC_READ = 0x80000000
        GENERIC_WRITE = 0x40000000
        OPEN_EXISTING = 3
        INVALID_HANDLE_VALUE = ctypes.c_void_p(-1).value

        handle = kernel32.CreateFileW(
            self.pipe_name,
            GENERIC_READ | GENERIC_WRITE,
            0, None,
            OPEN_EXISTING,
            0, None
        )

        if handle == INVALID_HANDLE_VALUE:
            return False

        self._pipe = handle
        return True

    def _send(self, cmd: dict) -> bool:
        """Send a JSON command to the pipe."""
        if not self._connect():
            print(f"ERROR: Cannot connect to pipe: {self.pipe_name}")
            return False

        data = (json.dumps(cmd) + '\n').encode('utf-8')

        try:
            import win32file
            win32file.WriteFile(self._pipe, data)
            return True
        except (ImportError, Exception):
            pass

        # ctypes fallback
        import ctypes
        kernel32 = ctypes.windll.kernel32
        bytes_written = ctypes.c_ulong(0)
        ok = kernel32.WriteFile(
            self._pipe, data, len(data),
            ctypes.byref(bytes_written), None
        )
        return bool(ok)

    def write_mem(self, ram_addr: int, value: int, size: int = 4,
                  description: str = "") -> bool:
        """Write value to RAM address in emulator memory."""
        return self._send({
            'type': 'WRITE_MEM',
            'addr': hex(ram_addr),
            'value': hex(value),
            'size': size,
            'description': description
        })

    def write_reg(self, reg_idx: int, value: int,
                  description: str = "") -> bool:
        """Write value to CPU register (0-31)."""
        return self._send({
            'type': 'WRITE_REG',
            'addr': reg_idx,
            'value': hex(value),
            'description': description
        })

    def set_pc(self, pc: int, description: str = "") -> bool:
        """Set program counter."""
        return self._send({
            'type': 'SET_PC',
            'addr': hex(pc),
            'description': description
        })

    def set_breakpoint(self, addr: int, description: str = "") -> bool:
        """Add a breakpoint."""
        return self._send({
            'type': 'SET_BREAKPOINT',
            'addr': hex(addr),
            'description': description
        })

    def dump_region(self, addr: int, size: int, description: str = "") -> bool:
        """Request a memory dump from the emulator."""
        return self._send({
            'type': 'DUMP_REGION',
            'addr': hex(addr),
            'size': size,
            'description': description
        })

    def rollback(self, description: str = "") -> bool:
        """Rollback all injected patches (restore original memory)."""
        return self._send({
            'type': 'ROLLBACK',
            'description': description
        })

    # ── High-level helpers ──

    def patch_lui_addiu(self, ram_addr: int, new_lui: int, new_addiu: int,
                        description: str = "") -> bool:
        """Patch a lui/addiu pair in emulator RAM."""
        lui_insn = 0x3C000000 | (new_lui & 0xFFFF)
        addiu_insn = 0x24000000 | (new_addiu & 0xFFFF)
        ok1 = self.write_mem(ram_addr, lui_insn, 4, f"lui: {description}")
        ok2 = self.write_mem(ram_addr + 4, addiu_insn, 4, f"addiu: {description}")
        return ok1 and ok2

    def inject_copy_routine(self, ram_addr: int, src: int, dst: int,
                            size: int, jump_to: int) -> bool:
        """Inject a MIPS copy routine at ram_addr in emulator memory."""
        src_hi = (src >> 16) & 0xFFFF
        src_lo = src & 0xFFFF
        dst_hi = (dst >> 16) & 0xFFFF
        dst_lo = dst & 0xFFFF
        if dst_lo >= 0x8000:
            dst_hi += 1
        if src_lo >= 0x8000:
            src_hi += 1

        instructions = [
            0x3C080000 | src_hi,
            0x25080000 | (src_lo & 0xFFFF),
            0x3C090000 | dst_hi,
            0x25290000 | (dst_lo & 0xFFFF),
            0x250A0000 | (size & 0xFFFF),
            0x8D0B0000,
            0x00000000,
            0xAD2B0000,
            0x25080004,
            0x25290004,
            0x150AFFFA,
            0x00000000,
            0x08000000 | (jump_to >> 2),
            0x00000000,
        ]

        ok = True
        for i, insn in enumerate(instructions):
            if not self.write_mem(ram_addr + i * 4, insn, 4,
                                  f"copy_routine[{i}] at {hex(ram_addr)}"):
                ok = False
        return ok

    def close(self):
        """Close the pipe handle."""
        if self._pipe is not None:
            try:
                import win32file
                win32file.CloseHandle(self._pipe)
            except (ImportError, Exception):
                import ctypes
                ctypes.windll.kernel32.CloseHandle(self._pipe)
            self._pipe = None


def cli_main():
    parser = argparse.ArgumentParser(description="Patch Injector — send commands to emulator")
    parser.add_argument("--pipe", default=r"\\.\pipe\cybergrime_live",
                        help="Named pipe path")
    args = parser.parse_args()

    injector = PatchInjector(args.pipe)

    print(f"Patch Injector CLI — pipe: {args.pipe}")
    print("Commands:")
    print("  write_mem <addr> <value> [size] [desc]  — Write to memory")
    print("  write_reg <idx> <value> [desc]          — Write to register")
    print("  set_pc <addr> [desc]                    — Set program counter")
    print("  set_bp <addr> [desc]                    — Set breakpoint")
    print("  dump <addr> <size> [desc]               — Dump memory region")
    print("  rollback [desc]                         — Undo all patches")
    print("  quit                                    — Exit")
    print()

    while True:
        try:
            line = input("> ").strip()
            if not line:
                continue
            if line in ("quit", "exit", "q"):
                break

            parts = line.split(None, 1)
            cmd = parts[0]
            rest = parts[1] if len(parts) > 1 else ""

            if cmd == "write_mem":
                args2 = rest.split()
                addr = int(args2[0], 0)
                value = int(args2[1], 0)
                size = int(args2[2]) if len(args2) > 2 else 4
                desc = args2[3] if len(args2) > 3 else ""
                injector.write_mem(addr, value, size, desc)
                print(f"  → WRITE_MEM {hex(addr)} = {hex(value)} ({size} bytes)")

            elif cmd == "write_reg":
                args2 = rest.split()
                idx = int(args2[0])
                value = int(args2[1], 0)
                desc = args2[2] if len(args2) > 2 else ""
                injector.write_reg(idx, value, desc)
                print(f"  → WRITE_REG ${idx} = {hex(value)}")

            elif cmd == "set_pc":
                args2 = rest.split()
                addr = int(args2[0], 0)
                desc = args2[1] if len(args2) > 1 else ""
                injector.set_pc(addr, desc)
                print(f"  → SET_PC {hex(addr)}")

            elif cmd == "set_bp":
                args2 = rest.split()
                addr = int(args2[0], 0)
                desc = args2[1] if len(args2) > 1 else ""
                injector.set_breakpoint(addr, desc)
                print(f"  → SET_BREAKPOINT {hex(addr)}")

            elif cmd == "dump":
                args2 = rest.split()
                addr = int(args2[0], 0)
                size = int(args2[1])
                desc = args2[2] if len(args2) > 2 else ""
                injector.dump_region(addr, size, desc)
                print(f"  → DUMP_REGION {hex(addr)} +{size} bytes")

            elif cmd == "rollback":
                injector.rollback(rest)
                print("  → ROLLBACK all patches")

            else:
                print(f"  Unknown command: {cmd}")

        except KeyboardInterrupt:
            break
        except Exception as e:
            print(f"  Error: {e}")

    injector.close()
    print("Goodbye.")


if __name__ == "__main__":
    cli_main()
