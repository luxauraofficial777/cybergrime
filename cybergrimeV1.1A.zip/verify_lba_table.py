#!/usr/bin/env python3
"""Verify LBA table in built disc — read EXE sector-by-sector and check patched values."""
import struct

disc_path = r'C:\LuxAura\VoidWalkers_Project\DQLOSTTRANSLATION\dq4_reverse_a.bin'
exe_size = 961108
exe_lba = 24

# Read EXE from disc sector-by-sector (Mode 2 Form 1: 2352 bytes/sector, 24-byte header)
f = open(disc_path, 'rb')
exe = bytearray()
sectors_needed = (exe_size + 2047) // 2048
for sec in range(exe_lba, exe_lba + sectors_needed):
    f.seek(sec * 2352 + 24)
    exe.extend(f.read(2048))
f.close()
exe = bytes(exe[:exe_size])

print(f'EXE size: {len(exe)} bytes')
print(f'EXE magic: {exe[:8]}')

# Check LBA table at 0x4000-0x4400
start = 0x4000
patched_count = 0
unpatched_count = 0
for i in range(start, start + 0x400, 4):
    val = struct.unpack('<I', exe[i:i+4])[0]
    if val == 0:
        continue
    if 500 <= val <= 301940:
        patched_count += 1
    elif 354 <= val <= 301794:
        unpatched_count += 1
        print(f'  UNPATCHED: 0x{i:04X}: {val}')

print(f'\nPatched entries (in [500, 301940]): {patched_count}')
print(f'Unpatched entries (still in [354, 301794]): {unpatched_count}')

# Show first 10 patched entries
print(f'\nFirst 10 patched entries:')
count = 0
for i in range(start, start + 0x400, 4):
    val = struct.unpack('<I', exe[i:i+4])[0]
    if 500 <= val <= 301940:
        print(f'  0x{i:04X}: {val}')
        count += 1
        if count >= 10:
            break
