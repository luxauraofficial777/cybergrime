#!/usr/bin/env python3
"""
CyberGrime Unified CLI — Phase 4.2
Single entry point for all CyberGrime operations.

Usage:
    python -m cybergrime build [--clean]
    python -m cybergrime run --disc <bin> --profile <name> [--max-instrs N] [--flags ...]
    python -m cybergrime test [profile_name]
    python -m cybergrime patch --iso <in> --spec <json> --out <out>
    python -m cybergrime diff --a <a.bin> --b <b.bin>
    python -m cybergrime edc --iso <bin>
    python -m cybergrime screenshot --disc <bin> --state <file> --out <bmp>
    python -m cybergrime list --iso <bin>
    python -m cybergrime info --iso <bin>
"""

import argparse
import os
import subprocess
import sys
from pathlib import Path

BASE_DIR = Path(__file__).parent.resolve()
RUNNER = BASE_DIR / "psx_agent_runner.exe"
BUILD_SCRIPT = BASE_DIR / "build_agent.bat"


def cmd_build(args):
    cmd = ["cmd", "/c", str(BUILD_SCRIPT)]
    if args.clean:
        cmd.append("clean")
    elif args.debug:
        cmd.append("debug")
    result = subprocess.run(cmd, cwd=str(BASE_DIR))
    return result.returncode


def cmd_run(args):
    if not RUNNER.exists():
        print(f"ERROR: {RUNNER} not found. Run 'python -m cybergrime build' first.")
        return 1

    disc = Path(args.disc)
    if not disc.exists():
        print(f"ERROR: Disc not found: {disc}")
        return 1

    cmd = [str(RUNNER), str(disc), args.profile]
    if args.max_instrs:
        cmd.append(str(args.max_instrs))
    else:
        cmd.append("55000000")
    cmd.append(args.json or "telemetry.json")
    cmd.append(str(args.wallclock or 600000))

    for flag in args.flags or []:
        cmd.append(flag)

    result = subprocess.run(cmd, cwd=str(BASE_DIR))
    return result.returncode


def cmd_test(args):
    script = BASE_DIR / "regression_runner.py"
    cmd = [sys.executable, str(script)]
    if args.profile:
        cmd.append(args.profile)
    result = subprocess.run(cmd, cwd=str(BASE_DIR))
    return result.returncode


def cmd_patch(args):
    script = BASE_DIR / "iso_toolkit.py"
    cmd = [sys.executable, str(script), "patch", args.iso, args.spec, args.out]
    result = subprocess.run(cmd, cwd=str(BASE_DIR))
    return result.returncode


def cmd_diff(args):
    script = BASE_DIR / "iso_toolkit.py"
    cmd = [sys.executable, str(script), "diff", args.a, args.b]
    result = subprocess.run(cmd, cwd=str(BASE_DIR))
    return result.returncode


def cmd_edc(args):
    script = BASE_DIR / "iso_toolkit.py"
    cmd = [sys.executable, str(script), "edc", args.iso]
    result = subprocess.run(cmd, cwd=str(BASE_DIR))
    return result.returncode


def cmd_screenshot(args):
    if not RUNNER.exists():
        print(f"ERROR: {RUNNER} not found. Run 'python -m cybergrime build' first.")
        return 1

    cmd = [
        str(RUNNER), args.disc, "screenshot", "5000000",
        "telemetry_screenshot.json", "60000",
        "--loadstate", args.state,
        "--screenshot", args.out
    ]
    result = subprocess.run(cmd, cwd=str(BASE_DIR))
    return result.returncode


def cmd_list(args):
    script = BASE_DIR / "iso_toolkit.py"
    cmd = [sys.executable, str(script), "list", args.iso]
    result = subprocess.run(cmd, cwd=str(BASE_DIR))
    return result.returncode


def cmd_info(args):
    script = BASE_DIR / "iso_toolkit.py"
    cmd = [sys.executable, str(script), "info", args.iso]
    result = subprocess.run(cmd, cwd=str(BASE_DIR))
    return result.returncode


def main():
    parser = argparse.ArgumentParser(
        prog="cybergrime",
        description="CyberGrime PSX Emulator & Reverse-Engineering Toolkit"
    )
    sub = parser.add_subparsers(dest="command", required=True)

    # build
    p_build = sub.add_parser("build", help="Build the emulator")
    p_build.add_argument("--clean", action="store_true", help="Clean build")
    p_build.add_argument("--debug", action="store_true", help="Debug build")
    p_build.set_defaults(func=cmd_build)

    # run
    p_run = sub.add_parser("run", help="Run the emulator")
    p_run.add_argument("--disc", required=True, help="Disc image path")
    p_run.add_argument("--profile", required=True, help="Profile name")
    p_run.add_argument("--max-instrs", type=int, help="Max instructions")
    p_run.add_argument("--wallclock", type=int, help="Wall-clock timeout (ms)")
    p_run.add_argument("--json", help="Telemetry output path")
    p_run.add_argument("--flags", nargs="*", help="Additional CLI flags")
    p_run.set_defaults(func=cmd_run)

    # test
    p_test = sub.add_parser("test", help="Run regression tests")
    p_test.add_argument("profile", nargs="?", help="Test profile name")
    p_test.set_defaults(func=cmd_test)

    # patch
    p_patch = sub.add_parser("patch", help="Patch an ISO")
    p_patch.add_argument("--iso", required=True, help="Input ISO")
    p_patch.add_argument("--spec", required=True, help="Patch spec JSON")
    p_patch.add_argument("--out", required=True, help="Output ISO")
    p_patch.set_defaults(func=cmd_patch)

    # diff
    p_diff = sub.add_parser("diff", help="Compare two ISOs")
    p_diff.add_argument("--a", required=True, help="First ISO")
    p_diff.add_argument("--b", required=True, help="Second ISO")
    p_diff.set_defaults(func=cmd_diff)

    # edc
    p_edc = sub.add_parser("edc", help="Regenerate EDC/ECC")
    p_edc.add_argument("--iso", required=True, help="ISO to fix")
    p_edc.set_defaults(func=cmd_edc)

    # screenshot
    p_scr = sub.add_parser("screenshot", help="Capture screenshot from state")
    p_scr.add_argument("--disc", required=True, help="Disc image")
    p_scr.add_argument("--state", required=True, help="Save state file")
    p_scr.add_argument("--out", required=True, help="Output BMP path")
    p_scr.set_defaults(func=cmd_screenshot)

    # list
    p_list = sub.add_parser("list", help="List ISO contents")
    p_list.add_argument("--iso", required=True, help="ISO to list")
    p_list.set_defaults(func=cmd_list)

    # info
    p_info = sub.add_parser("info", help="Show ISO info")
    p_info.add_argument("--iso", required=True, help="ISO to inspect")
    p_info.set_defaults(func=cmd_info)

    args = parser.parse_args()
    return args.func(args)


if __name__ == "__main__":
    sys.exit(main())
