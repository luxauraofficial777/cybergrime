import json, sys

files = sys.argv[1:]
for name in files:
    with open(name) as f:
        d = json.load(f)
    ps = d["Pass_Status"]
    instrs = d["Instructions_Executed"]
    vblanks = d["VBlank_Count"]
    pc = d["Last_Known_PC"]
    crashed = d["Crashed"]
    frozen = d["Frozen"]
    vfs = len(d.get("VFS_Accesses", []))
    errors = len(d.get("Errors", []))
    print(f"=== {name} ===")
    print(f"  Status: {ps}")
    print(f"  Instructions: {instrs}")
    print(f"  VBlanks: {vblanks}")
    print(f"  Last PC: 0x{pc:08X}")
    print(f"  Crashed: {crashed}")
    print(f"  Frozen: {frozen}")
    print(f"  VFS: {vfs}")
    print(f"  Errors: {errors}")
    print()
