#requires -Version 5.1
<#
.SYNOPSIS
    Run the PSX agent runner against a ROM with standardized paths and telemetry capture.

.PARAMETER Disc
    ROM image file. Accepts absolute path or a filename resolved against
    $ProjectRoot and $ProjectRoot\_archive.

.PARAMETER Profile
    Test profile name (used for telemetry/triage filenames).

.PARAMETER MaxInstrs
    Maximum instructions to execute (default 500,000,000).

.PARAMETER WallclockMs
    Wall-clock timeout in milliseconds (default 600,000 = 10 minutes).

.PARAMETER TelemetryDir
    Directory for telemetry JSON (default $ProjectRoot\cybergrime\telemetry).

.EXAMPLE
    .\run_test.ps1 dq4_frankenstein_v14.bin frank_v14_500m 500000000 600000
#>
param(
    [Parameter(Mandatory = $true, Position = 0)]
    [string]$Disc,

    [Parameter(Mandatory = $true, Position = 1)]
    [string]$Profile,

    [Parameter(Position = 2)]
    [uint64]$MaxInstrs = 500000000,

    [Parameter(Position = 3)]
    [int]$WallclockMs = 600000,

    [Parameter()]
    [string]$TelemetryDir = $null
)

$ErrorActionPreference = "Stop"

$ProjectRoot = "C:\LuxAura\VoidWalkers_Project\DQLOSTTRANSLATION"
$Cybergrime = Join-Path $ProjectRoot "cybergrime"
$Runner = Join-Path $Cybergrime "psx_agent_runner.exe"

if (-not $TelemetryDir) { $TelemetryDir = Join-Path $Cybergrime "telemetry" }
$TriageDir = Join-Path $Cybergrime "triage"

# Resolve disc path
$DiscPath = $null
if (Test-Path -LiteralPath $Disc) {
    $DiscPath = (Resolve-Path -LiteralPath $Disc).Path
} else {
    $candidates = @(
        (Join-Path $ProjectRoot $Disc),
        (Join-Path $ProjectRoot "_archive" $Disc)
    )
    foreach ($c in $candidates) {
        if (Test-Path -LiteralPath $c) {
            $DiscPath = (Resolve-Path -LiteralPath $c).Path
            break
        }
    }
}

if (-not $DiscPath) {
    throw "Disc not found: $Disc (looked in $ProjectRoot and $ProjectRoot\_archive)"
}

if (-not (Test-Path $Runner)) {
    throw "psx_agent_runner.exe not found at $Runner. Run build_agent.bat first."
}

New-Item -ItemType Directory -Force -Path $TelemetryDir | Out-Null
New-Item -ItemType Directory -Force -Path $TriageDir | Out-Null

$TelemetryPath = Join-Path $TelemetryDir "telemetry_${Profile}.json"
$TriageName = "emulator_triage_${Profile}.log"

# Remove any stale triage log left in the project root from a previous run
$OldTriage = Join-Path (Split-Path $ProjectRoot -Parent) $TriageName
if (Test-Path $OldTriage) { Remove-Item $OldTriage -Force -ErrorAction SilentlyContinue }

Write-Host "[RUN ] Profile : $Profile"
Write-Host "[RUN ] Disc     : $DiscPath"
Write-Host "[RUN ] Instrs   : $MaxInstrs"
Write-Host "[RUN ] Wallclock: ${WallclockMs}ms"
Write-Host "[RUN ] Telemetry: $TelemetryPath"

$ProcArgs = @(
    $DiscPath,
    $Profile,
    $MaxInstrs.ToString(),
    $TelemetryPath,
    $WallclockMs.ToString()
)

$proc = Start-Process -FilePath $Runner -ArgumentList $ProcArgs -WorkingDirectory $Cybergrime -NoNewWindow -Wait -PassThru

# The runner writes triage logs to the working directory by default; move them to the triage folder
$GeneratedTriage = Join-Path $Cybergrime $TriageName
if (Test-Path $GeneratedTriage) {
    $FinalTriage = Join-Path $TriageDir $TriageName
    Move-Item $GeneratedTriage $FinalTriage -Force -ErrorAction SilentlyContinue
    if (Test-Path $FinalTriage) {
        Write-Host "[RUN ] Triage   : $FinalTriage"
    } else {
        Write-Host "[RUN ] Triage   : $GeneratedTriage"
    }
}

# Emit one-line summary if telemetry exists
if (Test-Path $TelemetryPath) {
    try {
        $tel = Get-Content $TelemetryPath -Raw | ConvertFrom-Json
        $status = $tel.Pass_Status
        $instrs = $tel.Instructions_Executed
        $lastPc = "0x{0:X8}" -f $tel.Last_Known_PC
        $reason = $tel.Crash_Reason
        Write-Host "[SUMMARY] status=$status instrs=$instrs last_pc=$lastPc reason='$reason'"
    } catch {
        Write-Host "[SUMMARY] telemetry present but could not be parsed"
    }
} else {
    Write-Host "[SUMMARY] telemetry file not generated"
}

exit $proc.ExitCode
