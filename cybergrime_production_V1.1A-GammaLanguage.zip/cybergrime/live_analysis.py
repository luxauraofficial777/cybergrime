#!/usr/bin/env python3
"""
live_analysis.py — Main Python sidecar for live PSX emulator instrumentation.

Reads JSON-line events from the named pipe, compares against the Golden Model
(constraint_map.json + golden_state.json), queries Ghidra for decompiled context
on breakpoint hits, and outputs a structured divergence log.

Usage:
  python live_analysis.py \
    --pipe \\\\.\pipe\\cybergrime_live \
    --constraints cybergrime/constraint_map.json \
    --golden cybergrime/golden_state.json \
    --ghidra-map cybergrime/dw7_function_map.json \
    --output divergence_log.json
"""

import argparse
import json
import os
import sys
import time
from typing import Optional

# Add cybergrime dir to path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from runtime_comparator import RuntimeComparator
from ghidra_bridge import GhidraBridge, generate_default_function_map


class LiveAnalysisSidecar:
    """Main sidecar: reads pipe, compares state, logs divergences."""

    def __init__(self, pipe_name: str, constraint_map: dict,
                 golden_state: dict, ghidra: GhidraBridge,
                 output_path: str = "divergence_log.json"):
        self.pipe_name = pipe_name
        self.comparator = RuntimeComparator(constraint_map, golden_state)
        self.ghidra = ghidra
        self.output_path = output_path
        self.events_received = 0
        self.start_time = time.time()
        self.running = False

    def run(self):
        """Main loop: read pipe, process events."""
        self.running = True
        print(f"[LIVE] Starting live analysis sidecar")
        print(f"[LIVE] Pipe: {self.pipe_name}")
        print(f"[LIVE] Output: {self.output_path}")
        print(f"[LIVE] Waiting for emulator to connect...")

        # Connect to named pipe (Windows)
        pipe_handle = self._connect_pipe()
        if pipe_handle is None:
            print("[LIVE] ERROR: Cannot connect to pipe")
            return

        print(f"[LIVE] Connected to emulator")

        # Read loop
        buf = b""
        try:
            while self.running:
                data = self._read_pipe(pipe_handle)
                if data is None:
                    # Pipe broken
                    print("[LIVE] Pipe disconnected, waiting for reconnect...")
                    pipe_handle = self._connect_pipe()
                    if pipe_handle is None:
                        time.sleep(1)
                        continue
                    continue

                if data:
                    buf += data
                    # Process complete lines
                    while b'\n' in buf:
                        line, buf = buf.split(b'\n', 1)
                        if line.strip():
                            self._process_event(line.decode('utf-8', errors='replace'))
                else:
                    time.sleep(0.001)  # Small sleep when no data

        except KeyboardInterrupt:
            print("\n[LIVE] Interrupted by user")
        finally:
            self._close_pipe(pipe_handle)
            self._write_report()

    def _connect_pipe(self):
        """Connect to the Windows named pipe."""
        try:
            import win32file
            import win32pipe
            import pywintypes

            try:
                handle = win32file.CreateFile(
                    self.pipe_name,
                    win32file.GENERIC_READ | win32file.GENERIC_WRITE,
                    0, None,
                    win32file.OPEN_EXISTING,
                    0, None
                )
                return handle
            except pywintypes.error as e:
                if e.winerror == 231:  # ERROR_PIPE_BUSY
                    win32pipe.WaitNamedPipe(self.pipe_name, 5000)
                    try:
                        handle = win32file.CreateFile(
                            self.pipe_name,
                            win32file.GENERIC_READ | win32file.GENERIC_WRITE,
                            0, None,
                            win32file.OPEN_EXISTING,
                            0, None
                        )
                        return handle
                    except pywintypes.error:
                        return None
                return None
        except ImportError:
            pass

        # ctypes fallback
        import ctypes
        from ctypes import wintypes

        kernel32 = ctypes.windll.kernel32
        GENERIC_READ = 0x80000000
        GENERIC_WRITE = 0x40000000
        OPEN_EXISTING = 3
        INVALID_HANDLE_VALUE = ctypes.c_void_p(-1).value

        # Wait for pipe to be available
        for _ in range(50):
            handle = kernel32.CreateFileW(
                self.pipe_name,
                GENERIC_READ | GENERIC_WRITE,
                0, None,
                OPEN_EXISTING,
                0, None
            )
            if handle != INVALID_HANDLE_VALUE:
                return handle
            time.sleep(0.1)

        return None

    def _read_pipe(self, handle):
        """Read data from the pipe (non-blocking)."""
        try:
            import win32file
            import pywintypes
            try:
                err, data = win32file.ReadFile(handle, 65536)
                if err == 0:
                    return data
                return b""
            except pywintypes.error as e:
                if e.winerror == 232:  # ERROR_NO_DATA
                    return b""
                # Pipe broken
                return None
        except ImportError:
            pass

        # ctypes fallback
        import ctypes
        kernel32 = ctypes.windll.kernel32
        buf = ctypes.create_string_buffer(65536)
        bytes_read = ctypes.c_ulong(0)
        ok = kernel32.ReadFile(
            handle, buf, 65536,
            ctypes.byref(bytes_read), None
        )
        if ok:
            return buf.raw[:bytes_read.value]
        err = kernel32.GetLastError()
        if err == 232:  # ERROR_NO_DATA
            return b""
        return None

    def _close_pipe(self, handle):
        """Close the pipe handle."""
        if handle is None:
            return
        try:
            import win32file
            win32file.CloseHandle(handle)
        except (ImportError, Exception):
            import ctypes
            ctypes.windll.kernel32.CloseHandle(handle)

    def _process_event(self, line: str):
        """Process a single JSON-line event."""
        try:
            event = json.loads(line)
        except json.JSONDecodeError:
            return

        self.events_received += 1
        etype = event.get('type', '')

        # Pass to comparator
        divergence = self.comparator.handle_event(event)

        # Handle breakpoint hits with Ghidra context
        if etype == 'bp_hit':
            self._handle_breakpoint(event, divergence)

        # Print divergences in real-time
        if divergence:
            self._print_divergence(divergence)

        # Periodic status
        if self.events_received % 1000 == 0:
            report = self.comparator.get_report()
            print(f"[LIVE] Events: {self.events_received} | "
                  f"Divergences: {report['total_divergences']} "
                  f"({report['fatal_count']} fatal)")

    def _handle_breakpoint(self, event: dict, divergence: Optional[dict]):
        """Display Ghidra context on breakpoint hit."""
        pc = int(event['pc'], 16)
        regs = event.get('regs', {})
        instr = event.get('instr', 0)

        print(f"\n{'='*70}")
        print(f"  BREAKPOINT HIT at PC={hex(pc)} (instr #{instr})")
        print(f"{'='*70}")

        # Ghidra context
        context = self.ghidra.format_context(pc, regs)
        if context:
            print(context)

        # Show divergence if found
        if divergence:
            self._print_divergence(divergence)

        print()

    def _print_divergence(self, div: dict):
        """Print a divergence in real-time."""
        severity_icon = "✗" if div['severity'] == 'FATAL' else "⚠"
        print(f"\n  {severity_icon} DIVERGENCE #{div['id']} [{div['severity']}] "
              f"at instr {div['instr_count']}, PC={div['pc']}")
        print(f"    Type:     {div['type']}")
        print(f"    Address:  {div['address']}")
        print(f"    Expected: {div['expected']}")
        print(f"    Actual:   {div['actual']}")
        print(f"    Detail:   {div['detail']}")

    def _write_report(self):
        """Write the final divergence report."""
        report = self.comparator.get_report()
        report['session'] = {
            'events_received': self.events_received,
            'duration_seconds': time.time() - self.start_time,
            'pipe': self.pipe_name,
        }

        with open(self.output_path, 'w') as f:
            json.dump(report, f, indent=2)

        print(f"\n{'='*70}")
        print(f"  DIVERGENCE REPORT — {self.output_path}")
        print(f"{'='*70}")
        print(f"  Events received:    {self.events_received}")
        print(f"  Total divergences:  {report['total_divergences']}")
        print(f"  Fatal:              {report['fatal_count']}")
        print(f"  Warnings:           {report['warning_count']}")
        print(f"  Checkpoints hit:    {len(report['checkpoints_hit'])}")
        if report.get('first_fatal'):
            f = report['first_fatal']
            print(f"  First fatal:        instr {f['instr_count']} at {f['pc']}")
            print(f"    {f['type']}: {f['detail']}")
        print(f"{'='*70}")


def load_json(path: str, default=None) -> dict:
    """Load JSON file or return default."""
    if path and os.path.exists(path):
        with open(path) as f:
            return json.load(f)
    return default if default is not None else {}


def main():
    parser = argparse.ArgumentParser(
        description="Live Analysis Sidecar — real-time PSX emulator instrumentation"
    )
    parser.add_argument("--pipe", default=r"\\.\pipe\cybergrime_live",
                        help="Named pipe path")
    parser.add_argument("--constraints", default="cybergrime/constraint_map.json",
                        help="Constraint map JSON path")
    parser.add_argument("--golden", default="cybergrime/golden_state.json",
                        help="Golden state JSON path")
    parser.add_argument("--ghidra-map", default="cybergrime/dw7_function_map.json",
                        help="Ghidra function map JSON path")
    parser.add_argument("--output", default="divergence_log.json",
                        help="Output divergence log path")
    args = parser.parse_args()

    # Load constraint map
    constraints = load_json(args.constraints)
    if not constraints:
        print(f"ERROR: Constraint map not found: {args.constraints}")
        print("Run: python cybergrime/constraints_engine.py --exe translation/SLUSP012.06")
        sys.exit(1)

    # Load or generate golden state
    golden = load_json(args.golden, default={
        "tree_placement": {
            "mode": "Option A",
            "addr": "0x80100000",
            "copy_routine_pc0": "0x800BC700"
        },
        "register_checkpoints": {
            "0x800BC700": {
                "t0": "0x800BC738",
                "t1": "0x80100000",
                "_description": "Copy routine entry: src=tree, dst=high RAM"
            },
            "0x8008E284": {
                "v0": "0x00000000",
                "_description": "Original PC0 after copy: BSS clear entry"
            },
            "0x80073670": {
                "a2": "0x80100000",
                "_description": "Huffman decompress: tree pointer should be relocated"
            }
        }
    })

    # Generate default function map if not found
    ghidra_map_path = args.ghidra_map
    if not os.path.exists(ghidra_map_path):
        print(f"[LIVE] Ghidra map not found, generating default...")
        default_map = generate_default_function_map()
        os.makedirs(os.path.dirname(ghidra_map_path) or ".", exist_ok=True)
        with open(ghidra_map_path, 'w') as f:
            json.dump(default_map, f, indent=2)

    ghidra = GhidraBridge(function_map_path=ghidra_map_path)

    sidecar = LiveAnalysisSidecar(
        pipe_name=args.pipe,
        constraint_map=constraints,
        golden_state=golden,
        ghidra=ghidra,
        output_path=args.output,
    )

    sidecar.run()


if __name__ == "__main__":
    main()
